# Changelog

## [1.2.4](https://github.com/NBC-GPMF/cx-fum-access-control-config/compare/v1.2.3...v1.2.4) (2026-11-05)


### Bug Fixes

* NWPI-14968 - update version for release ([#66](https://github.com/NBC-GPMF/cx-fum-access-control-config/issues/66)) ([8300d69](https://github.com/NBC-GPMF/cx-fum-access-control-config/commit/8300d694c7aa21569d315928a50fa9ca7185def3))

## [1.2.3](https://github.com/NBC-GPMF/cx-fum-access-control-config/compare/v1.2.2...v1.2.3) (2026-10-09)


### Bug Fixes

* Add V2 for Process accounts ([#63](https://github.com/NBC-GPMF/cx-fum-access-control-config/issues/63)) ([da36613](https://github.com/NBC-GPMF/cx-fum-access-control-config/commit/da36613395f98c8d85b2a97f1456bddfa146af06))

## [1.2.2](https://github.com/NBC-GPMF/cx-fum-access-control-config/compare/v1.2.1...v1.2.2) (2026-10-08)


### Bug Fixes

* Prepare payload for CRS-FATCA PROD v4.0.0 ([160b5ce](https://github.com/NBC-GPMF/cx-fum-access-control-config/commit/160b5cedcc4505286d876e710fbac4dbd841d843))

## [1.2.1](https://github.com/NBC-GPMF/cx-fum-access-control-config/compare/v1.2.0...v1.2.1) (2026-10-07)


### Bug Fixes

* add and update CRS FATCA submission access to user pacakges ([#59](https://github.com/NBC-GPMF/cx-fum-access-control-config/issues/59)) ([8384ff7](https://github.com/NBC-GPMF/cx-fum-access-control-config/commit/8384ff73fd20948ed01097ca8a82e83be9818159))

## [1.2.0](https://github.com/NBC-GPMF/cx-fum-access-control-config/compare/v1.1.2...v1.2.0) (2026-09-28)


### Features

* Add CRS FATCA submission resources to related firms and user roles ([#54](https://github.com/NBC-GPMF/cx-fum-access-control-config/issues/54)) ([eaaa124](https://github.com/NBC-GPMF/cx-fum-access-control-config/commit/eaaa124850a7ec0138a7b00afa85e93072698fda))
* **NOS-24724:** Remove manage request from admin level profile package ([#52](https://github.com/NBC-GPMF/cx-fum-access-control-config/issues/52)) ([c01e17d](https://github.com/NBC-GPMF/cx-fum-access-control-config/commit/c01e17d594294bc872072a49f4cf2486fd63c77f))


### Bug Fixes

* Add CRS FATCA submission rescources to related firm and user packages ([#55](https://github.com/NBC-GPMF/cx-fum-access-control-config/issues/55)) ([b0b5197](https://github.com/NBC-GPMF/cx-fum-access-control-config/commit/b0b5197be035ece9a320fac14349a127a15f3ac7))

## [1.1.2](https://github.com/NBC-GPMF/cx-fum-access-control-config/compare/v1.1.1...v1.1.2) (2026-09-22)


### Bug Fixes

* NWPI-14843: Adding back SZ for NBIN firm ([#50](https://github.com/NBC-GPMF/cx-fum-access-control-config/issues/50)) ([a1b6aec](https://github.com/NBC-GPMF/cx-fum-access-control-config/commit/a1b6aec3361e553a5a4c05e51dfd79586e74d650))

## [1.1.1](https://github.com/NBC-GPMF/cx-fum-access-control-config/compare/v1.1.0...v1.1.1) (2026-09-17)


### Bug Fixes

* updated for 3.2 release ([#47](https://github.com/NBC-GPMF/cx-fum-access-control-config/issues/47)) ([c3f0d2e](https://github.com/NBC-GPMF/cx-fum-access-control-config/commit/c3f0d2e026ac99e31c81cc5ba4656ee4c0821fd5))

## [1.1.0](https://github.com/NBC-GPMF/cx-fum-access-control-config/compare/v1.0.9...v1.1.0) (2026-09-17)


### Features

* **NOS-24506:** Add IB firm package ([#35](https://github.com/NBC-GPMF/cx-fum-access-control-config/issues/35)) ([dc8ddbe](https://github.com/NBC-GPMF/cx-fum-access-control-config/commit/dc8ddbe39b5259d91da6014ced10ee513ec66dea))
* **NOS-24506:** feature onboarding add crs-fatca-feature to user packages ([#32](https://github.com/NBC-GPMF/cx-fum-access-control-config/issues/32)) ([0e9c073](https://github.com/NBC-GPMF/cx-fum-access-control-config/commit/0e9c073b3061172503a3228a75030ad7c3f41151))

## [1.0.9](https://github.com/NBC-GPMF/cx-fum-access-control-config/compare/v1.0.8...v1.0.9) (2026-07-13)


### Bug Fixes

* package update 2.2.1 ([#12](https://github.com/NBC-GPMF/cx-fum-access-control-config/issues/12)) ([e78cf52](https://github.com/NBC-GPMF/cx-fum-access-control-config/commit/e78cf5231cf924302d3e62a9c380ca711368ad74))

## [1.0.8](https://github.com/NBC-GPMF/cx-fum-access-control-config/compare/v1.0.7...v1.0.8) (2026-07-08)


### Bug Fixes

* creating uat release ([0cbe0ab](https://github.com/NBC-GPMF/cx-fum-access-control-config/commit/0cbe0aba90d8f078baafea2d950b9853c58bd9a7))

## [1.0.7](https://github.com/NBC-GPMF/cx-fum-access-control-config/compare/v1.0.6...v1.0.7) (2026-06-25)


### Bug Fixes

* first release in github ([2ab40f4](https://github.com/NBC-GPMF/cx-fum-access-control-config/commit/2ab40f472b072bd77e8b49b8eafc7bc3ac693ef2))
