# cx-fum-access-control-config

![Version](https://img.shields.io/badge/version-1.0.7-blue)

A Docker-containerized Python utility that uploads FUM (Firm/User Management) system package JSON configurations to the Access Control API and triggers batch processing. It runs as a Kubernetes one-shot job managed by ArgoCD.

---

## Table of Contents

- [Overview](#overview)
- [Repository Structure](#repository-structure)
- [System Packages](#system-packages)
- [Upload Script](#upload-script)
  - [Environment Variables](#environment-variables)
  - [Authentication Modes](#authentication-modes)
  - [CLI Arguments](#cli-arguments)
- [Selective Execution - Folder and File Exclusion](#selective-execution---folder-and-file-exclusion)
- [Running Locally](#running-locally)
- [Docker](#docker)
- [GitHub Actions Workflows](#github-actions-workflows)
- [ArgoCD Deployment](#argocd-deployment)
- [Release Process](#release-process)

---

## Overview

`cx-fum-access-control-config` manages the lifecycle of FUM system package configurations. It provides:

- **Versioned JSON policy files** (`system-packages/`) organized by schema version and operation (add/delete) across three entity types: resources, firms, and users.
- **A Python upload script** (`upload-script/upload-and-trigger.py`) that authenticates via OAuth2, uploads JSON files to the FUM Access Control API in dependency order, and polls for batch processing completion.
- **A Docker image** that packages the script and is deployed as a Kubernetes job via ArgoCD.

---

## Repository Structure

```
cx-fum-access-control-config/
├── Dockerfile                        # Multi-stage Docker build (Python 3.11)
├── entrypoint.sh                     # Container entrypoint; handles Istio sidecar shutdown
├── argocd-config.yaml                # ArgoCD service and namespace mapping
├── .github/
│   ├── workflows/
│   │   ├── ci.yaml                   # CI on feature branches / PRs
│   │   ├── build-deploy.yaml         # Build + deploy to dev on merge to main
│   │   ├── staging-release.yaml      # Deploy to UAT on tag push
│   │   ├── release-trigger.yaml      # Release-please versioning
│   │   └── prod-promote.yaml         # Manual prod promotion
│   └── release-please/
│       ├── config.json               # Release-please configuration
│       └── manifest.json             # Current version manifest
├── system-packages/                  # Versioned JSON policy configurations
│   ├── final/                        # Production-ready package sets by version
│   └── test/                         # Test data organized by operation phase
├── fum2.0/                           # FUM 2.0 policy store data
│   └── policy-store/
│       ├── data/                     # Sample application/firm/user data
│       └── policy/                   # Sample OPA policies
└── upload-script/
    ├── upload-and-trigger.py         # Core upload and batch trigger script
    └── requirements.txt              # Python dependencies
```

---

## System Packages

System packages are JSON files that define access control configurations (resources, firm-level policies, and user-level policies) for the FUM platform. They are organized under `system-packages/` by schema version.

### Processing Order

Files within a version folder are processed in strict dependency order:
| Phase | Folder | Description |
|-------|--------|-------------|
| 1 | `delete/1-user` | Remove existing user assignments |
| 2 | `delete/2-firm` | Remove existing firm assignments |
| 3 | `delete/3-resource` | Remove existing resource definitions |
| 4 | `add/1-resource` | Create new resource definitions |
| 5 | `add/2-firm` | Create new firm assignments |
| 6 | `add/3-user` | Create new user assignments |

This ordering ensures referential integrity: resources are deleted before firms, and firms are deleted before users. When adding, resources are created first, then firms reference those resources, then users reference firms.

### Versioned Sets

Production-ready sets live under `system-packages/final/<version>/`. The version folder name corresponds to the schema version (e.g., `v1.26`, `v1.28`, `v2.2.1`).

---

## Upload Script

`upload-script/upload-and-trigger.py` is the core automation script. It:

1. Reads OAuth2 credentials from environment variables
2. Generates a JWT client assertion or uses a client secret to obtain an access token
3. Discovers JSON files in the target version folder following the processing order above
4. Uploads each file to the FUM Access Control API
5. Triggers batch processing and polls until completion
6. Reports a summary of successful batches and any failures

### Environment Variables

#### Required

| Variable | Description |
|----------|-------------|
| `OAUTH2_TOKEN_URL` | OAuth2 token endpoint URL |
| `OAUTH2_SCOPES` | Comma-separated list of OAuth2 scopes |
| `CXP_SYSTEM_CLIENT_ID` | OAuth2 client ID |
| `FUM_API_URL` | Base URL for the FUM Access Control API |

#### Authentication (choose one mode)

**RSA Key (default):**

| Variable | Description |
|----------|-------------|
| `RSA_PRIVATE_KEY` | RSA private key (PEM format or single-line base64) |
| `OAUTH2_AUDIENCE` | JWT audience claim |
| `RSA_PUBLIC_KEY` | *(Optional)* RSA public key for verification |

**Client Secret:**

| Variable | Description |
|----------|-------------|
| `CXP_SYSTEM_CLIENT_SECRET` | OAuth2 client secret |

#### Selective Execution (optional)

| Variable | Description |
|----------|-------------|
| `EXCLUDE_FOLDERS` | Comma-separated folder names or patterns to skip |
| `EXCLUDE_FILES` | Comma-separated file names or wildcard patterns to skip |

### Authentication Modes

The script supports two OAuth2 authentication methods:

**1. JWT Client Assertion (default)**
Creates a signed JWT using an RSA private key and exchanges it for an access token at the token endpoint. Requires `RSA_PRIVATE_KEY` and `OAUTH2_AUDIENCE`.

**2. Client Secret**
Uses the standard `client_credentials` grant with `client_id` and `client_secret`. Enable with the `--use-client-secret` flag.

Both modes accept RSA keys in either standard PEM format or as a single-line base64 string (automatically converted).

### CLI Arguments

```
usage: upload-and-trigger.py [-h] [--exclude-folders FOLDERS]
                              [--exclude-files FILES]
                              [--use-client-secret]
                              [--client-id CLIENT_ID]

optional arguments:
  --exclude-folders FOLDERS  Comma-separated folder names/patterns to exclude
  --exclude-files FILES      Comma-separated file names/patterns to exclude
  --use-client-secret        Use client_id/client_secret instead of RSA keys
  --client-id CLIENT_ID      Override CXP_SYSTEM_CLIENT_ID env variable
```

---

## Selective Execution

The script supports selective execution, allowing you to skip specific folders or files at runtime without modifying the repository or file system.

### Use Cases

1. **Skip specific phases** — Omit delete/add folders you don't need to run
2. **Exclude test files** — Skip files matching patterns such as `*_test.json`
3. **Partial deployment** — Run only specific operations
4. **Avoid repetition** — Skip folders/files already successfully processed

### Command-Line Arguments

#### Exclude Folders

```bash
# Exclude a single folder
python3 upload-and-trigger.py --exclude-folders "1-user"

# Exclude multiple folders (comma-separated)
python3 upload-and-trigger.py --exclude-folders "1-user,2-firm"

# Exclude an entire phase
python3 upload-and-trigger.py --exclude-folders "delete"
```

#### Exclude Files

```bash
# Exclude a specific file
python3 upload-and-trigger.py --exclude-files "test.json"

# Exclude multiple files
python3 upload-and-trigger.py --exclude-files "test.json,backup.json"

# Exclude files by wildcard pattern
python3 upload-and-trigger.py --exclude-files "*.test.json,*_DELETE.json,*.bak"
```

#### Combine Exclusions

```bash
python3 upload-and-trigger.py \
  --exclude-folders "1-user" \
  --exclude-files "Test_AdminOrders.json,*.test.json"
```

### Environment Variables

```bash
export EXCLUDE_FOLDERS="1-user,2-firm"
export EXCLUDE_FILES="*.test.json,*_backup.json"
python3 upload-and-trigger.py
```

### Kubernetes Job Configuration

```yaml
env:
  - name: EXCLUDE_FOLDERS
    value: "1-user,3-resource"
  - name: EXCLUDE_FILES
    value: "Test_AdminOrders.json,*.bak"
```

### Pattern Matching Rules

**Folders:**
- Exact match: `"1-user"` matches the folder named `1-user`
- Partial match: `"delete"` matches any path containing `delete`
- Case-sensitive

**Files:**
- Exact match: `"test.json"` matches the file named `test.json`
- Wildcards: `*.json`, `*_test.json`, `Test_*.json`, `*backup*`

### Script Output

When exclusions are active you will see:

```
Excluding folders: 1-user, 2-firm
Excluding files: *.test.json, Test_AdminOrders.json

✓ Found 4 numbered subfolder(s) to process in order:
  1. add/1-resource
  2. add/3-user

⚠ Excluded 2 folder(s) based on exclusion rules
⚠ Excluded 3 file(s) based on exclusion rules
```

---

## Running Locally

### Prerequisites

- Python 3.11+

```bash
pip install -r upload-script/requirements.txt
```

### RSA Key Authentication

```bash
export OAUTH2_TOKEN_URL="https://<your-idp>/token"
export OAUTH2_AUDIENCE="<audience>"
export OAUTH2_SCOPES="<scope1>,<scope2>"
export CXP_SYSTEM_CLIENT_ID="<client-id>"
export RSA_PRIVATE_KEY="$(cat path/to/private_key.pem)"
export FUM_API_URL="https://<fum-api-host>"

python3 upload-script/upload-and-trigger.py
```

### Client Secret Authentication

```bash
export CXP_SYSTEM_CLIENT_SECRET="<client-secret>"
python3 upload-script/upload-and-trigger.py --use-client-secret
```

---

## Docker

### Build

```bash
docker build -t cx-fum-access-control-config .
```

### Run

```bash
docker run --rm \
  -e OAUTH2_TOKEN_URL="https://<your-idp>/token" \
  -e OAUTH2_AUDIENCE="<audience>" \
  -e OAUTH2_SCOPES="<scope1>,<scope2>" \
  -e CXP_SYSTEM_CLIENT_ID="<client-id>" \
  -e RSA_PRIVATE_KEY="$(cat path/to/private_key.pem)" \
  -e FUM_API_URL="https://<fum-api-host>" \
  cx-fum-access-control-config
```

The container runs `entrypoint.sh`, which executes the Python script and then sends a shutdown signal to the Istio sidecar (`POST /quitquitquit`) before exiting. This ensures clean pod termination in Kubernetes.

---

## GitHub Actions Workflows

| Workflow | Trigger | Description |
|----------|---------|-------------|
| `ci.yaml` | Push to non-main/non-release branches; PRs | Builds Docker image (no deploy) |
| `build-deploy.yaml` | Push to `main` | Builds Docker image and deploys to **dev** namespace |
| `staging-release.yaml` | Push of `v*` tag | Builds Docker image and deploys to **UAT** namespace |
| `release-trigger.yaml` | Push to `main` | Runs release-please to manage versioning and changelog |
| `prod-promote.yaml` | Manual (`workflow_dispatch`) | Opens a PR on the prod helm values repo with the updated image tag |

All build/deploy workflows delegate to `nbc-actions/cx-workflows/.github/workflows/docker-standalone.yaml@main`.

### Prod Promotion

1. Go to **Actions → Prod Promote Release Entry**
2. Click **Run workflow**
3. Enter the `release_number` (e.g., `1.0.7`)
4. A PR is opened on `NBC-GPMF/cx-fum-helm-prd-values` with the updated image tag

---

## ArgoCD Deployment

The container runs as a Kubernetes job named `syspkg-upload-trigger`, managed by ArgoCD.

| Environment | Namespace | Helm Values Repo |
|-------------|-----------|-----------------|
| Development | `6900-nonproduction-development-dev` | `NBC-GPMF/cx-fum-helm-npr-values-gh` |
| Staging/UAT | `6900-nonproduction-staging-uat` | `NBC-GPMF/cx-fum-helm-npr-values-gh` |
| Production | *(via prod-promote PR)* | `NBC-GPMF/cx-fum-helm-prd-values` |

---

## Release Process

This repository uses [release-please](https://github.com/googleapis/release-please) with the `simple` release type.

1. Merge commits to `main` using [Conventional Commits](https://www.conventionalcommits.org/):
   - `fix: ...` → patch version bump
   - `feat: ...` → minor version bump
   - `feat!: ...` / `BREAKING CHANGE` → major version bump
2. Release-please opens a PR updating `CHANGELOG.md` and `README.md` (version badge)
3. Merge the release-please PR to cut the release
4. Pushing the resulting `v*` tag triggers the staging deploy workflow
5. Run the **Prod Promote** workflow manually to promote to production
