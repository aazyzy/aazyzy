# Branch Cleanup Report: access-control-configuration

Generated: 2026-06-09 12:42:12
Default Branch: develop
Total Branches: 4

---

## Summary

- Total Branches: 4
- Excluded from Deletion: 0
- Marked for Deletion: 4

---

## All Branches

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `v1.28` | 2025-08-22 15:39:53 -0400 | 2025-08-22 15:39:53 -0400 | MERGED |
| `release/2.1.3` | 2026-01-31 00:01:13 -0500 | 2026-01-31 00:01:13 -0500 | MERGED |
| `snyk-fix-b05ca6ad219c4679488ef1735b32914c` | 2026-02-12 00:52:10 -0500 | 2026-02-12 00:52:10 -0500 | MERGED |
| `release/2.1.1` | 2026-03-09 11:17:23 -0400 | 2026-03-09 11:17:23 -0400 | MERGED |

---

## Excluded from Deletion

Criteria: Unmerged branches with last commit less than 2 months old
Count: 0

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| No branches excluded | | | |

---

## Marked for Deletion

Criteria: All merged branches + unmerged branches with last commit older than 2 months
Count: 4

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `v1.28` | 2025-08-22 15:39:53 -0400 | 2025-08-22 15:39:53 -0400 | MERGED |
| `release/2.1.3` | 2026-01-31 00:01:13 -0500 | 2026-01-31 00:01:13 -0500 | MERGED |
| `snyk-fix-b05ca6ad219c4679488ef1735b32914c` | 2026-02-12 00:52:10 -0500 | 2026-02-12 00:52:10 -0500 | MERGED |
| `release/2.1.1` | 2026-03-09 11:17:23 -0400 | 2026-03-09 11:17:23 -0400 | MERGED |

---

## Deletion Results

Total Attempted: 4
Successfully Deleted: 4
Failed: 0
Skipped (Excluded Safety Gate): 0
