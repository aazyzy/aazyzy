#!/bin/sh
set -e

# Run the Python script in background
python3 upload-script/upload-and-trigger.py &
PYTHON_PID=$!

# Wait for Python process to complete
wait $PYTHON_PID
EXIT_CODE=$?

# Signal Istio sidecar to quit (if present)
curl -X POST http://localhost:15020/quitquitquit 2>/dev/null || true

# Give a moment for sidecar to shut down
sleep 2

# Exit with the captured exit code for safe exit of pod
exit $EXIT_CODE