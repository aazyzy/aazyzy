User policy files schemes location
    https://git.bnc.ca/projects/APP6900/repos/api-schemas-wealth/browse/user-policy-store-schema/src/main/resources