package module_access

default allow = false

allow {
    data.module_flags.trading.enabled == true
}

deny[msg] {
    not allow
    msg = "Trading is not avaiable by policy"
}
