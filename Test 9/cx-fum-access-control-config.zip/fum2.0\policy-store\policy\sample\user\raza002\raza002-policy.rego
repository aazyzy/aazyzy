package user.raza002

import future.keywords.if
import future.keywords.in

# Import user data from data files
user_data := data.user.raza002["raza002-data"]
user_feature := data.user.raza002["raza002-feature"]
user_identity := data.user.raza002["raza002-identity"]
user_system := data.user.raza002["raza002-system"]

# Default deny
default allow := false

# Allow access if all conditions are met
allow if {
    is_valid_user
    is_authorized_action
    is_authorized_resource
}

# Verify user identity and organization
is_valid_user if {
    user_identity.username == "raza002"
    user_identity.firmId == "NBIN"
    user_data.org == "OLGA"
}

# Check if the requested action is authorized
is_authorized_action if {
    input.action
    some action in user_feature.action
    startswith(input.action, extract_action_prefix(action))
}

# Check if the requested resource is authorized
is_authorized_resource if {
    input.resource
    some resource in user_feature.resource
    startswith(input.resource, extract_resource_prefix(resource))
}

# Check if user has specific package permissions
has_package(package_name) if {
    some pkg in user_feature.package
    pkg == package_name
}

# Check if user has administrator role
is_administrator if {
    user_system.cx.userRole == "administrator"
}

# Check if user has firm scope
has_firm_scope if {
    user_system.cx.isFirmScope == "true"
}

# Check if user belongs to specific RR codes
has_rr_code(code) if {
    some rr in user_data["rr-code"]
    rr == code
}

# Check if RR code falls within user's RR code range
in_rr_code_range(code) if {
    some range in user_data["rr-code-range"]
    code >= range.from
    code <= range.to
}

# Check if user has access to specific secure zone
has_secure_zone_access(zone_id) if {
    some zone in user_system.sz.secureZoneIds
    zone == zone_id
}

# Get user's firm ID
get_firm_id := user_identity.firmId

# Get user's organization
get_organization := user_data.org

# Get user's role
get_user_role := user_system.cx.userRole

# Get user's authorized packages
get_packages := user_feature.package

# Get user's authorized resources
get_resources := user_feature.resource

# Get user's authorized actions
get_actions := user_feature.action

# Helper function to extract action prefix
extract_action_prefix(action) := prefix if {
    parts := split(action, ":::")
    prefix := parts[0]
}

# Helper function to extract resource prefix
extract_resource_prefix(resource) := prefix if {
    parts := split(resource, ":::")
    prefix := parts[0]
}

# Profile access rules
allow_profile_read if {
    is_valid_user
    input.action == "profile:view"
    input.resource == "profile:read"
    has_package("ViewOnlyConfidentialProfile_V1.17")
}

# Orders access rules
allow_orders_list if {
    is_valid_user
    input.action == "orders:list"
    input.resource == "orders:history"
    has_package("StandardReadAccess_V2.0")
}

# Context-aware authorization
contextual_allow if {
    is_valid_user
    is_administrator
    has_firm_scope
    input.context.firmId == get_firm_id
}

# RR code based authorization
rr_code_allow if {
    is_valid_user
    input.rrCode
    {has_rr_code(input.rrCode)} or {in_rr_code_range(input.rrCode)}
}

# Secure zone based authorization
secure_zone_allow if {
    is_valid_user
    input.secureZoneId
    has_secure_zone_access(input.secureZoneId)
}

# Full authorization decision with reasons
authorization_result := {
    "allowed": allow,
    "user": user_identity.username,
    "firmId": get_firm_id,
    "organization": get_organization,
    "role": get_user_role,
    "packages": get_packages,
    "isAdministrator": is_administrator,
    "hasFirmScope": has_firm_scope,
}
