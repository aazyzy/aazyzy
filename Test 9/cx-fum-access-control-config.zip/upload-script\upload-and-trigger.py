#!/usr/bin/env python3

"""
FUM System Package Upload and Trigger Script (Merged)
This script generates OAuth2 token and uploads JSON files from the system-packages folder
and triggers system package processing using the generated token.

Combines functionality from:
- generate_token_local.py: OAuth2 token generation
- upload-and-trigger.py: Bulk upload and trigger operations
"""

import argparse
import fnmatch
import json
import os
import sys
import time
import uuid
from pathlib import Path
from typing import Dict, List, Optional, Tuple

try:
    import jwt  # type: ignore
    import requests  # type: ignore
except ImportError:
    print("❌ Missing required packages. Install with:", file=sys.stderr)
    print("   pip install PyJWT requests cryptography", file=sys.stderr)
    sys.exit(1)


# ANSI color codes
class Colors:
    RED = '\033[0;31m'
    GREEN = '\033[0;32m'
    YELLOW = '\033[1;33m'
    BLUE = '\033[0;34m'
    CYAN = '\033[0;36m'
    NC = '\033[0m'  # No Color


# Global tracking lists
# Format: (filename, filepath, http_code, message)
failed_uploads: List[Tuple[str, str, str, str]] = []
# Format: (filename, filepath, batch_id, http_code, message)
failed_triggers: List[Tuple[str, str, str, str, str]] = []
# Format: (filename, filepath, batch_id, status, details)
failed_processing: List[Tuple[str, str, str, str, str]] = []
# Format: (filename, filepath, batch_id, details)
successful_batches: List[Tuple[str, str, str, str]] = []


def convert_oneline_to_pem(one_line_text: str, key_type: str = "PRIVATE KEY") -> str:
    """
    Convert one-line certificate/key to PEM format
    
    Args:
        one_line_text: The certificate/key as a single line string
        key_type: Type of key - "PRIVATE KEY", "CERTIFICATE", "RSA PRIVATE KEY", etc.
    
    Returns:
        Properly formatted PEM string
    """
    # Remove any whitespace
    clean_text = one_line_text.strip().replace(" ", "").replace("\n", "").replace("\r", "")
    
    # Check if already in PEM format
    if "-----BEGIN" in clean_text and "-----END" in clean_text:
        return one_line_text  # Already in PEM format
    
    # Split into 64-character lines
    lines = [clean_text[i:i+64] for i in range(0, len(clean_text), 64)]
    
    # Build PEM format
    pem_content = f"-----BEGIN {key_type}-----\n"
    pem_content += "\n".join(lines)
    pem_content += f"\n-----END {key_type}-----\n"
    
    return pem_content


class TokenGenerator:
    """OAuth2 System Token Generator using JWT Client Assertion or Client Secret"""

    def __init__(self, use_client_secret: bool = False):
        """Initialize with OAuth2 configuration from environment variables
        
        Args:
            use_client_secret: Use client_id/client_secret instead of RSA keys
        """
        self.use_client_secret = use_client_secret
        self.token_url = os.getenv("OAUTH2_TOKEN_URL")
        self.audience = os.getenv("OAUTH2_AUDIENCE")
        
        if not self.token_url:
            raise ValueError("OAUTH2_TOKEN_URL environment variable is required")
        
        # Audience is optional when using client secret
        if not use_client_secret and not self.audience:
            raise ValueError("OAUTH2_AUDIENCE environment variable is required for RSA key authentication")
        
        # Scopes from environment (comma-separated)
        scopes_str = os.getenv("OAUTH2_SCOPES")
        if not scopes_str:
            raise ValueError("OAUTH2_SCOPES environment variable is required")
        self.scopes = [scope.strip() for scope in scopes_str.split(",")]

    def load_credentials(
        self, 
        client_id: Optional[str] = None
    ) -> Tuple[str, str, Optional[str]]:
        """Load OAuth2 credentials from environment variables
        
        Returns:
            Tuple of (client_id, private_key, public_key)
            public_key is optional and may be None
        """
        
        try:
            # Get client ID
            client_id = client_id or os.getenv("CXP_SYSTEM_CLIENT_ID")
            if not client_id:
                print(f"{Colors.RED}  ✗ Client ID not found{Colors.NC}")
                raise ValueError(
                    "CXP_SYSTEM_CLIENT_ID not provided. \n"
                    "Set via --client-id argument or CXP_SYSTEM_CLIENT_ID environment variable."
                )
            print(f"{Colors.GREEN}  ✓ Client ID loaded{Colors.NC}")

            # Get private key (mandatory)
            print(f"{Colors.BLUE}  → Looking for RSA_PRIVATE_KEY environment variable{Colors.NC}")
            private_key = os.getenv("RSA_PRIVATE_KEY")
            if not private_key:
                print(f"{Colors.RED}  ✗ RSA_PRIVATE_KEY not found{Colors.NC}")
                raise ValueError(
                    "RSA_PRIVATE_KEY environment variable is required\n"
                    "Set the private key as an environment variable (supports both one-line and PEM format)."
                )
            
            # Convert one-line key to PEM format if needed
            if "-----BEGIN" not in private_key:
                print(f"{Colors.YELLOW}  → Detected one-line private key format, converting to PEM...{Colors.NC}")
                private_key = convert_oneline_to_pem(private_key, "PRIVATE KEY")
                print(f"{Colors.GREEN}  ✓ Private key converted to PEM format{Colors.NC}")
            
            print(f"{Colors.GREEN}  ✓ Private key loaded from environment{Colors.NC}")

            # Get public key (optional)
            print(f"{Colors.BLUE}  → Looking for RSA_PUBLIC_KEY environment variable (optional){Colors.NC}")
            public_key = os.getenv("RSA_PUBLIC_KEY")
            if public_key:
                # Convert one-line key to PEM format if needed
                if "-----BEGIN" not in public_key:
                    print(f"{Colors.YELLOW}  → Detected one-line public key format, converting to PEM...{Colors.NC}")
                    public_key = convert_oneline_to_pem(public_key, "PUBLIC KEY")
                    print(f"{Colors.GREEN}  ✓ Public key converted to PEM format{Colors.NC}")
                print(f"{Colors.GREEN}  ✓ Public key loaded from environment{Colors.NC}")
            else:
                print(f"{Colors.YELLOW}  ⚠ No public key provided (optional - skipping){Colors.NC}")

            return client_id, private_key, public_key
            
        except Exception as e:
            print(f"{Colors.RED}  ✗ Credential loading failed: {e}{Colors.NC}")
            raise

    def load_credentials_with_secret(
        self,
        client_id: Optional[str] = None
    ) -> Tuple[str, str]:
        """Load OAuth2 credentials using client_id and client_secret
        
        Returns:
            Tuple of (client_id, client_secret)
        """
        try:
            # Get client ID
            client_id = client_id or os.getenv("CXP_SYSTEM_CLIENT_ID")
            if not client_id:
                print(f"{Colors.RED}  ✗ Client ID not found{Colors.NC}")
                raise ValueError(
                    "CXP_SYSTEM_CLIENT_ID not provided. \n"
                    "Set via --client-id argument or CXP_SYSTEM_CLIENT_ID environment variable."
                )
            print(f"{Colors.GREEN}  ✓ Client ID loaded{Colors.NC}")
            
            # Get client secret
            print(f"{Colors.BLUE}  → Looking for CXP_SYSTEM_CLIENT_SECRET environment variable{Colors.NC}")
            client_secret = os.getenv("CXP_SYSTEM_CLIENT_SECRET")
            if not client_secret:
                print(f"{Colors.RED}  ✗ CXP_SYSTEM_CLIENT_SECRET not found{Colors.NC}")
                raise ValueError(
                    "CXP_SYSTEM_CLIENT_SECRET environment variable is required\n"
                    "Set the client secret as an environment variable."
                )
            print(f"{Colors.GREEN}  ✓ Client secret loaded from environment{Colors.NC}")
            
            return client_id, client_secret
            
        except Exception as e:
            print(f"{Colors.RED}  ✗ Credential loading failed: {e}{Colors.NC}")
            raise

    def create_jwt_assertion(self, client_id: str, private_key: str) -> str:
        """Create JWT client assertion for OAuth2 token exchange"""
        try:
            now = int(time.time())
            exp = now + 300  # 5 minutes expiration

            payload = {
                "iss": client_id,
                "sub": client_id,
                "aud": self.audience,
                "exp": exp,
                "iat": now,
                "jti": str(uuid.uuid4()),
            }
            
            print(f"{Colors.BLUE}  → Creating JWT with {len(self.scopes)} scopes{Colors.NC}")
            print(f"{Colors.BLUE}  → Token will expire at: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(exp))}{Colors.NC}")

            jwt_token = jwt.encode(payload, private_key, algorithm="RS256")
            print(f"{Colors.GREEN}  ✓ JWT assertion created successfully{Colors.NC}")
            return jwt_token
            
        except Exception as e:
            print(f"{Colors.RED}  ✗ JWT creation failed: {e}{Colors.NC}")
            print(f"{Colors.YELLOW}  → Check that your private key is in valid PEM format{Colors.NC}")
            raise ValueError(f"Failed to create JWT assertion: {e}")

    def request_token(self, jwt_assertion: str) -> Dict:
        """Request access token from OAuth2 authorization server"""
        data = {
            "grant_type": "client_credentials",
            "client_assertion_type": "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
            "client_assertion": jwt_assertion,
            "scope": " ".join(self.scopes),
        }

        headers = {"Content-Type": "application/x-www-form-urlencoded"}

        try:
            print(f"{Colors.BLUE}  → Requesting token from: {self.token_url}{Colors.NC}")
            print(f"{Colors.BLUE}  → Grant type: client_credentials{Colors.NC}")
            
            timeout = int(os.getenv("TOKEN_REQUEST_TIMEOUT"))
            verify = os.getenv("REQUESTS_CA_BUNDLE", os.getenv("SSL_CERT_FILE", True))
            response = requests.post(
                self.token_url, 
                data=data, 
                headers=headers, 
                timeout=timeout,
                verify=verify
            )
            
            print(f"{Colors.BLUE}  → Response status: {response.status_code}{Colors.NC}")
            
            response.raise_for_status()
            token_data = response.json()
            
            # Validate token response
            if 'access_token' not in token_data:
                print(f"{Colors.RED}  ✗ Token response missing 'access_token' field{Colors.NC}")
                raise ValueError("Invalid token response: missing access_token")
                
            token_length = len(token_data.get('access_token', ''))
            print(f"{Colors.GREEN}  ✓ Token received ({token_length} characters){Colors.NC}")
            
            return token_data
            
        except requests.exceptions.Timeout as e:
            timeout = int(os.getenv("TOKEN_REQUEST_TIMEOUT"))
            print(f"{Colors.RED}  ✗ Request timeout after {timeout} seconds{Colors.NC}")
            raise RuntimeError(f"Token request timeout: {e}")
            
        except requests.exceptions.ConnectionError as e:
            print(f"{Colors.RED}  ✗ Connection error - unable to reach OAuth2 server{Colors.NC}")
            raise RuntimeError(f"Token request connection failed: {e}")
            
        except requests.exceptions.RequestException as e:
            print(f"{Colors.RED}  ✗ Token request failed with HTTP error{Colors.NC}")
            error_msg = f"Token request failed: {e}"
            if hasattr(e, "response") and e.response is not None:
                try:
                    error_details = e.response.json()
                    print(f"{Colors.RED}  Error details: {json.dumps(error_details, indent=2)}{Colors.NC}")
                    error_msg += f"\nDetails: {json.dumps(error_details, indent=2)}"
                except:
                    print(f"{Colors.RED}  Response: {e.response.text}{Colors.NC}")
                    error_msg += f"\nResponse: {e.response.text}"
            raise RuntimeError(error_msg)
            
        except json.JSONDecodeError as e:
            print(f"{Colors.RED}  ✗ Invalid JSON response from OAuth2 server{Colors.NC}")
            raise RuntimeError(f"Failed to parse token response: {e}")
            
        except Exception as e:
            print(f"{Colors.RED}  ✗ Unexpected error during token request: {e}{Colors.NC}")
            raise

    def request_token_with_secret(self, client_id: str, client_secret: str) -> Dict:
        """Request access token using client credentials (client_id + client_secret)"""
        data = {
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
            "scope": " ".join(self.scopes),
        }

        headers = {"Content-Type": "application/x-www-form-urlencoded"}

        try:
            print(f"{Colors.BLUE}  → Requesting token from: {self.token_url}{Colors.NC}")
            print(f"{Colors.BLUE}  → Grant type: client_credentials (with client_secret){Colors.NC}")
            
            timeout = int(os.getenv("TOKEN_REQUEST_TIMEOUT", "30"))
            verify = os.getenv("REQUESTS_CA_BUNDLE", os.getenv("SSL_CERT_FILE", True))
            response = requests.post(
                self.token_url, 
                data=data, 
                headers=headers, 
                timeout=timeout,
                verify=verify
            )
            
            print(f"{Colors.BLUE}  → Response status: {response.status_code}{Colors.NC}")
            
            response.raise_for_status()
            token_data = response.json()
            
            # Validate token response
            if 'access_token' not in token_data:
                print(f"{Colors.RED}  ✗ Token response missing 'access_token' field{Colors.NC}")
                raise ValueError("Invalid token response: missing access_token")
                
            token_length = len(token_data.get('access_token', ''))
            print(f"{Colors.GREEN}  ✓ Token received ({token_length} characters){Colors.NC}")
            
            return token_data
            
        except requests.exceptions.Timeout as e:
            timeout = int(os.getenv("TOKEN_REQUEST_TIMEOUT", "30"))
            print(f"{Colors.RED}  ✗ Request timeout after {timeout} seconds{Colors.NC}")
            raise RuntimeError(f"Token request timeout: {e}")
            
        except requests.exceptions.ConnectionError as e:
            print(f"{Colors.RED}  ✗ Connection error - unable to reach OAuth2 server{Colors.NC}")
            raise RuntimeError(f"Token request connection failed: {e}")
            
        except requests.exceptions.RequestException as e:
            print(f"{Colors.RED}  ✗ Token request failed with HTTP error{Colors.NC}")
            error_msg = f"Token request failed: {e}"
            if hasattr(e, "response") and e.response is not None:
                try:
                    error_details = e.response.json()
                    print(f"{Colors.RED}  Error details: {json.dumps(error_details, indent=2)}{Colors.NC}")
                    error_msg += f"\nDetails: {json.dumps(error_details, indent=2)}"
                except:
                    print(f"{Colors.RED}  Response: {e.response.text}{Colors.NC}")
                    error_msg += f"\nResponse: {e.response.text}"
            raise RuntimeError(error_msg)
            
        except json.JSONDecodeError as e:
            print(f"{Colors.RED}  ✗ Invalid JSON response from OAuth2 server{Colors.NC}")
            raise RuntimeError(f"Failed to parse token response: {e}")
            
        except Exception as e:
            print(f"{Colors.RED}  ✗ Unexpected error during token request: {e}{Colors.NC}")
            raise

    def generate(
        self,
        client_id: Optional[str] = None,
        verbose: bool = True,
    ) -> str:
        """Generate OAuth2 access token and return it
        
        Note: All keys are processed in-memory only and cleared after use.
        No temporary files are created.
        """
        
        private_key = None
        public_key = None
        jwt_assertion = None
        client_secret = None
        
        try:
            if verbose:
                print(f"{Colors.BLUE}🔐 Generating OAuth2 Access Token{Colors.NC}")
                print("=" * 60)

            if self.use_client_secret:
                # Use client_id and client_secret
                if verbose:
                    print(f"{Colors.YELLOW}📥 Loading credentials (client_id + client_secret)...{Colors.NC}")
                client_id, client_secret = self.load_credentials_with_secret(client_id)
                if verbose:
                    masked_id = f"{client_id[:10]}...{client_id[-10:]}"
                    print(f"{Colors.GREEN}✅ Credentials loaded (Client ID: {masked_id}){Colors.NC}")
                
                # Request token directly
                if verbose:
                    print(f"{Colors.YELLOW}🌐 Requesting access token...{Colors.NC}")
                token_response = self.request_token_with_secret(client_id, client_secret)
            else:
                # Use RSA keys with JWT assertion
                if verbose:
                    print(f"{Colors.YELLOW}📥 Loading credentials (RSA keys)...{Colors.NC}")
                client_id, private_key, public_key = self.load_credentials(client_id)
                if verbose:
                    masked_id = f"{client_id[:10]}...{client_id[-10:]}"
                    print(f"{Colors.GREEN}✅ Credentials loaded (Client ID: {masked_id}){Colors.NC}")
                    if public_key:
                        print(f"{Colors.GREEN}✅ Public key also loaded{Colors.NC}")

                # Create JWT assertion (in-memory only)
                if verbose:
                    print(f"{Colors.YELLOW}🔑 Creating JWT client assertion...{Colors.NC}")
                jwt_assertion = self.create_jwt_assertion(client_id, private_key)
                if verbose:
                    print(f"{Colors.GREEN}✅ JWT assertion created{Colors.NC}")

                # Request token
                if verbose:
                    print(f"{Colors.YELLOW}🌐 Requesting access token...{Colors.NC}")
                token_response = self.request_token(jwt_assertion)
            
            access_token = token_response.get("access_token", "")
            expires_in = token_response.get("expires_in", 0)
            
            if verbose:
                print(f"{Colors.GREEN}✅ Access token received (expires in {expires_in}s){Colors.NC}")
                print("=" * 60)
                print()

            return access_token
            
        finally:
            # Explicitly clear sensitive data from memory
            if private_key:
                del private_key
            if public_key:
                del public_key
            if jwt_assertion:
                del jwt_assertion
            if client_secret:
                del client_secret


class BulkUploadProcessor:
    """Handles system package upload and trigger operations"""

    def __init__(
        self, 
        auth_token: str,
        token_generator: Optional['TokenGenerator'] = None,
        api_base_url: Optional[str] = None,
        template_name: Optional[str] = None,
        firm_id: Optional[str] = None,
        system_packages_dir: Optional[Path] = None,
        poll_status: bool = False,
        status_check_interval: Optional[int] = None,
        status_check_max_attempts: Optional[int] = None
    ):
        """Initialize bulk upload processor with configuration from environment variables"""
        self.auth_token = auth_token
        self.token_generator = token_generator
        self.token_generated_at = time.time()
        self.token_expiry_seconds = 3600  # Token valid for 1 hour
        self.token_refresh_threshold = 3300  # Refresh after 55 minutes
        self.api_base_url = api_base_url or os.getenv("API_BASE_URL")
        self.template_name = template_name or os.getenv("TEMPLATE_NAME")
        self.firm_id = firm_id or os.getenv("FIRM_ID")
        
        if not self.api_base_url:
            raise ValueError("API_BASE_URL environment variable is required")
        if not self.template_name:
            raise ValueError("TEMPLATE_NAME environment variable is required")
        if not self.firm_id:
            raise ValueError("FIRM_ID environment variable is required")
        
        # System packages directory
        if system_packages_dir:
            self.system_packages_dir = system_packages_dir
        elif os.getenv("SYSTEM_PACKAGES_DIR"):
            self.system_packages_dir = Path(os.getenv("SYSTEM_PACKAGES_DIR"))
        else:
            raise ValueError("SYSTEM_PACKAGES_DIR environment variable is required")
        
        self.poll_status = poll_status
        self.status_check_interval = status_check_interval or int(os.getenv("STATUS_CHECK_INTERVAL", "10"))
        # Default to 0 = unlimited polling until completion
        self.status_check_max_attempts = status_check_max_attempts or int(os.getenv("STATUS_CHECK_MAX_ATTEMPTS", "0"))
        
        # Exclusion filters
        exclude_folders_str = os.getenv("EXCLUDE_FOLDERS", "").strip()
        self.exclude_folders = [f.strip() for f in exclude_folders_str.split(",") if f.strip()] if exclude_folders_str else []
        
        exclude_files_str = os.getenv("EXCLUDE_FILES", "").strip()
        self.exclude_files = [f.strip() for f in exclude_files_str.split(",") if f.strip()] if exclude_files_str else []
        
        # Project root - parent directory of the upload-script folder
        self.project_root = Path(__file__).resolve().parent.parent
    
    def refresh_token_if_needed(self) -> None:
        """Check if token is about to expire and refresh it if necessary"""
        if not self.token_generator:
            return  # No token generator provided, cannot refresh
        
        elapsed_time = time.time() - self.token_generated_at
        
        if elapsed_time >= self.token_refresh_threshold:
            time_remaining = self.token_expiry_seconds - elapsed_time
            print(f"{Colors.YELLOW}⚠ Token expires in {int(time_remaining)}s - refreshing...{Colors.NC}", file=sys.stderr)
            
            try:
                self.auth_token = self.token_generator.generate(verbose=True)
                self.token_generated_at = time.time()
                print(f"{Colors.GREEN}✓ Token refreshed successfully{Colors.NC}", file=sys.stderr)
                print()
            except Exception as e:
                print(f"{Colors.RED}✗ Token refresh failed: {e}{Colors.NC}", file=sys.stderr)
                print(f"{Colors.YELLOW}⚠ Continuing with existing token...{Colors.NC}", file=sys.stderr)
    
    def get_relative_path(self, file_path: Path) -> str:
        """Get path relative to project root"""
        try:
            return str(file_path.resolve().relative_to(self.project_root))
        except ValueError:
            # If file is outside project root, return absolute path
            return str(file_path.absolute())

    def validate_json_file(self, file_path: Path) -> Tuple[bool, str]:
        """Validate that the file contains valid JSON"""
        try:
            print(f"{Colors.BLUE}  → Validating JSON structure...{Colors.NC}")
            
            # Check file exists and is readable
            if not file_path.exists():
                return False, f"File does not exist: {file_path}"
                
            if not file_path.is_file():
                return False, f"Path is not a file: {file_path}"
                
            file_size = file_path.stat().st_size
            if file_size == 0:
                return False, "File is empty (0 bytes)"
                
            print(f"{Colors.BLUE}  → File size: {file_size} bytes{Colors.NC}")
            
            # Parse JSON (utf-8-sig strips BOM if present, works fine without one too)
            with open(file_path, 'r', encoding='utf-8-sig') as f:
                data = json.load(f)
            
            # Validate content
            if data is None:
                return False, "JSON file contains null"
                
            if not data:
                return False, "JSON file is empty"
            
            if isinstance(data, list):
                if len(data) == 0:
                    return False, "JSON array is empty"
                print(f"{Colors.BLUE}  → JSON contains {len(data)} items{Colors.NC}")
            elif isinstance(data, dict):
                print(f"{Colors.BLUE}  → JSON is a single object{Colors.NC}")
            else:
                return False, f"Unexpected JSON type: {type(data).__name__}"
            
            return True, "Valid JSON"
            
        except json.JSONDecodeError as e:
            return False, f"Invalid JSON syntax at line {e.lineno}, column {e.colno}: {e.msg}"
        except UnicodeDecodeError as e:
            return False, f"File encoding error: {str(e)}"
        except PermissionError as e:
            return False, f"Permission denied reading file: {str(e)}"
        except Exception as e:
            return False, f"Unexpected error reading file: {str(e)}"

    def upload_file(self, file_path: Path) -> Optional[str]:
        """Upload file and get batch ID"""
        # Check if token needs refresh before upload
        self.refresh_token_if_needed()
        
        file_name = file_path.name
        file_display_path = self.get_relative_path(file_path)
        file_size = file_path.stat().st_size
        print(f"{Colors.YELLOW}Uploading file: {file_display_path} ({file_size} bytes){Colors.NC}", file=sys.stderr)
        
        url = f"{self.api_base_url}/files/{self.template_name}"
        params = {"firmId": self.firm_id}
        headers = {
            "Authorization": f"Bearer {self.auth_token}",
            "accept": "*/*"
        }
        
        print(f"{Colors.BLUE}  → Endpoint: {url}{Colors.NC}", file=sys.stderr)
        print(f"{Colors.BLUE}  → Template: {self.template_name}, Firm: {self.firm_id}{Colors.NC}", file=sys.stderr)
        
        try:
            with open(file_path, 'rb') as f:
                files = {'file': (file_name, f, 'application/json')}
                print(f"{Colors.BLUE}  → Sending upload request...{Colors.NC}", file=sys.stderr)
                verify = os.getenv("REQUESTS_CA_BUNDLE", os.getenv("SSL_CERT_FILE", True))
                response = requests.post(url, headers=headers, params=params, files=files, verify=verify)
            
            print(f"{Colors.BLUE}  → Response status: {response.status_code}{Colors.NC}", file=sys.stderr)
            
            if response.status_code == 200:
                batch_id = response.text.strip()
                if not batch_id:
                    print(f"{Colors.RED}✗ Upload returned empty batch ID{Colors.NC}", file=sys.stderr)
                    failed_uploads.append((file_name, "EMPTY_BATCH_ID", "Server returned empty batch ID"))
                    return None
                print(f"{Colors.GREEN}✓ Upload successful - Batch ID: {batch_id}{Colors.NC}", file=sys.stderr)
                return batch_id
            elif response.status_code == 401:
                print(f"{Colors.RED}✗ Upload failed - Unauthorized (HTTP 401){Colors.NC}", file=sys.stderr)
                print(f"{Colors.YELLOW}  → Check your OAuth2 token is valid and not expired{Colors.NC}", file=sys.stderr)
                failed_uploads.append((file_name, file_display_path, "HTTP 401 UNAUTHORIZED", response.text))
                return None
            elif response.status_code == 403:
                print(f"{Colors.RED}✗ Upload failed - Forbidden (HTTP 403){Colors.NC}", file=sys.stderr)
                print(f"{Colors.YELLOW}  → Check your token has required scopes{Colors.NC}", file=sys.stderr)
                failed_uploads.append((file_name, file_display_path, "HTTP 403 FORBIDDEN", response.text))
                return None
            elif response.status_code == 400:
                print(f"{Colors.RED}✗ Upload failed - Bad Request (HTTP 400){Colors.NC}", file=sys.stderr)
                print(f"{Colors.YELLOW}  → Check JSON file format and structure{Colors.NC}", file=sys.stderr)
                print(f"{Colors.RED}Response: {response.text}{Colors.NC}", file=sys.stderr)
                failed_uploads.append((file_name, file_display_path, "HTTP 400 BAD_REQUEST", response.text))
                return None
            else:
                print(f"{Colors.RED}✗ Upload failed - HTTP {response.status_code}{Colors.NC}", file=sys.stderr)
                print(f"{Colors.RED}Response: {response.text}{Colors.NC}", file=sys.stderr)
                failed_uploads.append((file_name, file_display_path, f"HTTP {response.status_code}", response.text))
                return None
                
        except requests.exceptions.Timeout as e:
            print(f"{Colors.RED}✗ Upload timeout{Colors.NC}", file=sys.stderr)
            failed_uploads.append((file_name, file_display_path, "TIMEOUT", str(e)))
            return None
            
        except requests.exceptions.ConnectionError as e:
            print(f"{Colors.RED}✗ Upload failed - Connection error{Colors.NC}", file=sys.stderr)
            print(f"{Colors.YELLOW}  → Check network connectivity and API URL{Colors.NC}", file=sys.stderr)
            failed_uploads.append((file_name, file_display_path, "CONNECTION_ERROR", str(e)))
            return None
            
        except FileNotFoundError as e:
            print(f"{Colors.RED}✗ Upload failed - File not found: {file_path}{Colors.NC}", file=sys.stderr)
            failed_uploads.append((file_name, file_display_path, "FILE_NOT_FOUND", str(e)))
            return None
            
        except Exception as e:
            print(f"{Colors.RED}✗ Upload failed - Unexpected error: {str(e)}{Colors.NC}", file=sys.stderr)
            failed_uploads.append((file_name, file_display_path, "EXCEPTION", str(e)))
            return None

    def trigger_bulk_process(self, batch_id: str, file_name: str, file_display_path: str) -> bool:
        """Trigger bulk process for a batch"""
        print(f"{Colors.YELLOW}Triggering bulk process for batch: {batch_id}{Colors.NC}", file=sys.stderr)
        
        url = f"{self.api_base_url}/batches/trigger/{batch_id}"
        params = {"firmId": self.firm_id}
        headers = {
            "Authorization": f"Bearer {self.auth_token}",
            "accept": "*/*"
        }
        
        print(f"{Colors.BLUE}  → Endpoint: {url}{Colors.NC}", file=sys.stderr)
        
        try:
            print(f"{Colors.BLUE}  → Sending trigger request...{Colors.NC}", file=sys.stderr)
            verify = os.getenv("REQUESTS_CA_BUNDLE", os.getenv("SSL_CERT_FILE", True))
            response = requests.post(url, headers=headers, params=params, verify=verify)
            
            print(f"{Colors.BLUE}  → Response status: {response.status_code}{Colors.NC}", file=sys.stderr)
            
            if response.status_code == 200:
                print(f"{Colors.GREEN}✓ Bulk process triggered successfully{Colors.NC}", file=sys.stderr)
                return True
            elif response.status_code == 404:
                print(f"{Colors.RED}✗ Failed to trigger - Batch not found (HTTP 404){Colors.NC}", file=sys.stderr)
                print(f"{Colors.YELLOW}  → Batch ID may be invalid or expired{Colors.NC}", file=sys.stderr)
                failed_triggers.append((file_name, file_display_path, batch_id, "HTTP 404 NOT_FOUND", response.text))
                return False
            elif response.status_code == 401:
                print(f"{Colors.RED}✗ Failed to trigger - Unauthorized (HTTP 401){Colors.NC}", file=sys.stderr)
                failed_triggers.append((file_name, file_display_path, batch_id, "HTTP 401 UNAUTHORIZED", response.text))
                return False
            else:
                print(f"{Colors.RED}✗ Failed to trigger bulk process - HTTP {response.status_code}{Colors.NC}", file=sys.stderr)
                print(f"{Colors.RED}Response: {response.text}{Colors.NC}", file=sys.stderr)
                failed_triggers.append((file_name, file_display_path, batch_id, f"HTTP {response.status_code}", response.text))
                return False
                
        except requests.exceptions.Timeout as e:
            print(f"{Colors.RED}✗ Trigger timeout{Colors.NC}", file=sys.stderr)
            failed_triggers.append((file_name, file_display_path, batch_id, "TIMEOUT", str(e)))
            return False
            
        except requests.exceptions.ConnectionError as e:
            print(f"{Colors.RED}✗ Trigger failed - Connection error{Colors.NC}", file=sys.stderr)
            failed_triggers.append((file_name, file_display_path, batch_id, "CONNECTION_ERROR", str(e)))
            return False
            
        except Exception as e:
            print(f"{Colors.RED}✗ Failed to trigger bulk process - Unexpected error: {str(e)}{Colors.NC}", file=sys.stderr)
            failed_triggers.append((file_name, file_display_path, batch_id, "EXCEPTION", str(e)))
            return False

    def check_batch_status(self, batch_id: str) -> Optional[dict]:
        """Check batch status"""
        print(f"{Colors.YELLOW}Checking status for batch: {batch_id}{Colors.NC}", file=sys.stderr)
        
        url = f"{self.api_base_url}/batches/{batch_id}/status"
        params = {"firmId": self.firm_id, "getDetails": "false"}
        headers = {
            "Authorization": f"Bearer {self.auth_token}",
            "accept": "*/*"
        }
        
        try:
            verify = os.getenv("REQUESTS_CA_BUNDLE", os.getenv("SSL_CERT_FILE", True))
            response = requests.get(url, headers=headers, params=params, verify=verify)
            if response.status_code == 200:
                return response.json()
            else:
                print(f"{Colors.RED}✗ Status check failed - HTTP {response.status_code}{Colors.NC}", file=sys.stderr)
                return None
        except Exception as e:
            print(f"{Colors.RED}✗ Status check failed - {str(e)}{Colors.NC}", file=sys.stderr)
            return None

    def get_batch_details(self, batch_id: str) -> Optional[dict]:
        """Get detailed batch information including error messages"""
        print(f"{Colors.YELLOW}Retrieving detailed batch information for: {batch_id}{Colors.NC}", file=sys.stderr)
        
        url = f"{self.api_base_url}/batches/{batch_id}/status"
        params = {"firmId": self.firm_id, "getDetails": "true"}
        headers = {
            "Authorization": f"Bearer {self.auth_token}",
            "accept": "*/*"
        }
        
        try:
            verify = os.getenv("REQUESTS_CA_BUNDLE", os.getenv("SSL_CERT_FILE", True))
            response = requests.get(url, headers=headers, params=params, verify=verify)
            if response.status_code == 200:
                return response.json()
            else:
                print(f"{Colors.RED}✗ Failed to get batch details - HTTP {response.status_code}{Colors.NC}", file=sys.stderr)
                print(f"{Colors.RED}Response: {response.text}{Colors.NC}", file=sys.stderr)
                return None
        except Exception as e:
            print(f"{Colors.RED}✗ Failed to get batch details - {str(e)}{Colors.NC}", file=sys.stderr)
            return None

    def has_constraint_violation(self, batch_details: dict) -> bool:
        """Check if batch details contain constraint violation errors"""
        if not batch_details:
            return False
        
        # Keywords that indicate constraint violations
        constraint_keywords = [
            'unique_name_restriction',
            'already exists',
            'duplicate key',
            'constraint violation',
            'UNIQUE constraint failed'
        ]
        
        # Convert batch details to string for searching
        details_str = json.dumps(batch_details).lower()
        
        return any(keyword.lower() in details_str for keyword in constraint_keywords)
    
    def extract_error_info(self, batch_details: dict) -> str:
        """Extract and format error information from batch details"""
        errors = []
        
        if 'errorMessage' in batch_details:
            errors.append(f"Error: {batch_details['errorMessage']}")
        
        if 'message' in batch_details:
            errors.append(f"Message: {batch_details['message']}")
        
        if 'detailedReport' in batch_details and batch_details['detailedReport']:
            errors.append(f"Total Records: {batch_details.get('totalRecords', 0)}")
            errors.append(f"Failed Records: {batch_details.get('failedRecords', 0)}")
            errors.append(f"Successful Records: {batch_details.get('successfullyRecords', 0)}")
            errors.append("")
            errors.append("Failed Items:")
            
            for idx, item in enumerate(batch_details['detailedReport'][:10]):
                if item.get('status') == 'FAILED':
                    item_id = item.get('id', f'Item {idx + 1}')
                    error_msg = item.get('errorMessage', '')
                    
                    try:
                        if error_msg and isinstance(error_msg, str) and error_msg.startswith('{'):
                            nested_error = json.loads(error_msg)
                            if 'messages' in nested_error and 'errors' in nested_error['messages']:
                                for err in nested_error['messages']['errors']:
                                    errors.append(f"  • Record ID {item_id}: [{nested_error.get('httpCode', 'ERROR')}] {err.get('message', 'Unknown error')}")
                            elif 'description' in nested_error:
                                errors.append(f"  • Record ID {item_id}: [{nested_error.get('httpCode', 'ERROR')}] {nested_error['description']}")
                            else:
                                errors.append(f"  • Record ID {item_id}: {error_msg}")
                        else:
                            errors.append(f"  • Record ID {item_id}: {error_msg}")
                    except (json.JSONDecodeError, Exception):
                        errors.append(f"  • Record ID {item_id}: {error_msg}")
            
            if len(batch_details['detailedReport']) > 10:
                errors.append(f"  ... and {len(batch_details['detailedReport']) - 10} more failed items")
            return '\n    '.join(errors)
        
        if 'items' in batch_details and batch_details['items']:
            item_errors = []
            for idx, item in enumerate(batch_details['items'][:5]):
                if 'errorMessage' in item:
                    item_errors.append(f"Item {idx + 1}: {item['errorMessage']}")
                elif 'error' in item:
                    item_errors.append(f"Item {idx + 1}: {item['error']}")
            
            if item_errors:
                errors.append("Item Errors:")
                errors.extend(item_errors)
                if len(batch_details['items']) > 5:
                    errors.append(f"... and {len(batch_details['items']) - 5} more items")
        
        if not errors:
            relevant_fields = ['status', 'statusMessage', 'errorCode', 'reason', 'error', 'failureReason', 'validationErrors']
            for field in relevant_fields:
                if field in batch_details and batch_details[field]:
                    errors.append(f"{field}: {batch_details[field]}")
        
        if not errors or (len(errors) == 1 and errors[0].startswith('status:')):
            errors.append("\nFull Batch Response:")
            response_str = json.dumps(batch_details, indent=2)
            errors.append(response_str)
        
        return '\n    '.join(errors) if errors else "No detailed error information available"

    def poll_batch_status(self, batch_id: str, file_name: str, file_display_path: str) -> int:
        """Poll batch status until completion or timeout
        
        If status_check_max_attempts is 0, polls indefinitely until completion
        """
        print(f"{Colors.BLUE}Polling status for batch: {batch_id}{Colors.NC}", file=sys.stderr)
        
        if self.status_check_max_attempts == 0:
            print(f"{Colors.CYAN}  → Polling until completion (no timeout){Colors.NC}", file=sys.stderr)
        
        attempt = 0
        while True:
            # Check if we've exceeded max attempts (only if limit is set)
            if self.status_check_max_attempts > 0 and attempt >= self.status_check_max_attempts:
                print(f"{Colors.YELLOW}⚠ Status check timeout after {attempt} attempts - batch still processing{Colors.NC}", file=sys.stderr)
                return 3
            
            status_response = self.check_batch_status(batch_id)
            
            if not status_response:
                time.sleep(self.status_check_interval)
                attempt += 1
                continue
            
            status = status_response.get('status', 'UNKNOWN')
            total_count = status_response.get('totalCount', 0)
            success_count = status_response.get('successCount', 0)
            failed_count = status_response.get('failedCount', 0)
            
            print(f"{Colors.BLUE}  [Attempt {attempt + 1}] Status: {status} | Total: {total_count} | Success: {success_count} | Failed: {failed_count}{Colors.NC}", file=sys.stderr)
            
            if status in ["COMPLETED", "SUCCESS"]:
                print(f"{Colors.GREEN}✓ Batch processing completed successfully after {attempt + 1} attempts{Colors.NC}", file=sys.stderr)
                successful_batches.append((file_name, file_display_path, batch_id, f"{success_count}/{total_count}"))
                return 0
            elif status == "COMPLETED_WITH_ERRORS":
                print(f"{Colors.YELLOW}⚠ Batch completed with errors after {attempt + 1} attempts{Colors.NC}", file=sys.stderr)
                details = self.get_batch_details(batch_id)
                error_info = self.extract_error_info(details) if details else "No additional details available"
                
                # Check if this is a constraint violation
                if self.has_constraint_violation(details):
                    print(f"{Colors.YELLOW}⚠ Detected constraint violation in partial success{Colors.NC}", file=sys.stderr)
                    failed_processing.append((file_name, file_display_path, batch_id, "CONSTRAINT_VIOLATION", f"{success_count} succeeded, {failed_count} failed out of {total_count}\n    {error_info}"))
                    return 4  # Special return code for constraint violations
                
                failed_processing.append((file_name, file_display_path, batch_id, "PARTIAL", f"{success_count} succeeded, {failed_count} failed out of {total_count}\n    {error_info}"))
                return 2
            elif status == "FAILED":
                print(f"{Colors.RED}✗ Batch processing failed after {attempt + 1} attempts{Colors.NC}", file=sys.stderr)
                details = self.get_batch_details(batch_id)
                error_info = self.extract_error_info(details) if details else "No additional details available"
                print(f"{Colors.RED}Error Details: {error_info}{Colors.NC}", file=sys.stderr)
                
                # Check if this is a constraint violation
                if self.has_constraint_violation(details):
                    print(f"{Colors.YELLOW}⚠ Detected constraint violation - resource may already exist{Colors.NC}", file=sys.stderr)
                    failed_processing.append((file_name, file_display_path, batch_id, "CONSTRAINT_VIOLATION", f"{failed_count}/{total_count} failed\n    {error_info}"))
                    return 4  # Special return code for constraint violations
                
                failed_processing.append((file_name, file_display_path, batch_id, "FAILED", f"{failed_count}/{total_count} failed\n    {error_info}"))
                return 1
            
            # Wait before next attempt
            time.sleep(self.status_check_interval)
            attempt += 1

    def process_file(self, file_path: Path) -> int:
        """Process a single JSON file"""
        file_name = file_path.name
        file_display_path = self.get_relative_path(file_path)
        
        print()
        print("=" * 80)
        print(f"{Colors.YELLOW}Processing: {file_display_path}{Colors.NC}")
        print("=" * 80)
        
        # Validate JSON file
        is_valid, validation_msg = self.validate_json_file(file_path)
        if not is_valid:
            print(f"{Colors.RED}✗ JSON validation failed: {validation_msg}{Colors.NC}")
            failed_uploads.append((file_name, file_display_path, "VALIDATION_ERROR", validation_msg))
            return 1
        else:
            print(f"{Colors.GREEN}✓ JSON validation passed{Colors.NC}")
        
        # Upload file
        batch_id = self.upload_file(file_path)
        if not batch_id:
            print(f"{Colors.RED}Skipping trigger due to upload failure{Colors.NC}")
            return 1
        
        # Small delay
        time.sleep(1)
        
        # Trigger bulk process
        if not self.trigger_bulk_process(batch_id, file_name, file_display_path):
            print(f"{Colors.RED}✗ File processing failed at trigger stage{Colors.NC}")
            return 1
        
        print(f"{Colors.GREEN}✓ Batch triggered successfully{Colors.NC}")
        print(f"Batch ID: {batch_id}")
        
        # Poll status if enabled
        if self.poll_status:
            print()
            return self.poll_batch_status(batch_id, file_name, file_display_path)
        else:
            successful_batches.append((file_name, file_display_path, batch_id, "Triggered"))
            return 0

    def is_folder_excluded(self, folder_name: str) -> bool:
        """Check if folder should be excluded based on EXCLUDE_FOLDERS patterns"""
        if not self.exclude_folders:
            return False
        
        folder_lower = folder_name.lower()
        for pattern in self.exclude_folders:
            pattern_lower = pattern.lower()
            # Check if pattern matches folder name or is contained in it
            if pattern_lower == folder_lower or pattern_lower in folder_lower:
                return True
            # Support wildcard matching
            if fnmatch.fnmatch(folder_lower, pattern_lower):
                return True
        return False
    
    def is_file_excluded(self, file_name: str) -> bool:
        """Check if file should be excluded based on EXCLUDE_FILES patterns"""
        if not self.exclude_files:
            return False
        
        file_lower = file_name.lower()
        for pattern in self.exclude_files:
            pattern_lower = pattern.lower()
            # Check exact match or wildcard pattern match
            if pattern_lower == file_lower or fnmatch.fnmatch(file_lower, pattern_lower):
                return True
        return False

    def get_numbered_subfolders(self) -> List[Tuple[int, Path]]:
        """Get subfolders that start with a number OR are delete/add folders, sorted appropriately"""
        numbered_folders = []
        
        try:
            for item in self.system_packages_dir.iterdir():
                if item.is_dir():
                    folder_name = item.name
                    
                    # Check if folder is excluded
                    if self.is_folder_excluded(folder_name):
                        print(f"{Colors.YELLOW}  ⊗ Skipping excluded folder: {folder_name}{Colors.NC}")
                        continue
                    
                    # Check if folder name starts with a digit
                    if folder_name and folder_name[0].isdigit():
                        # Extract the leading number (support multi-digit numbers)
                        num_str = ""
                        for char in folder_name:
                            if char.isdigit():
                                num_str += char
                            elif char == '-':
                                break
                            else:
                                break
                        
                        if num_str:
                            folder_num = int(num_str)
                            numbered_folders.append((folder_num, item))
                    else:
                        # Check if it's a delete or add folder (without numbers)
                        folder_lower = folder_name.lower()
                        if any(keyword in folder_lower for keyword in ['delete', 'del', 'remove', 'add', 'create', 'insert']):
                            # Assign priority: delete=0, add=1, others=2
                            if any(keyword in folder_lower for keyword in ['delete', 'del', 'remove']):
                                priority = 0
                            elif any(keyword in folder_lower for keyword in ['add', 'create', 'insert']):
                                priority = 1
                            else:
                                priority = 2
                            numbered_folders.append((priority, item))
            
            # Sort by the number/priority
            numbered_folders.sort(key=lambda x: x[0])
            
        except Exception as e:
            print(f"{Colors.RED}✗ Error scanning for subfolders: {e}{Colors.NC}")
        
        return numbered_folders

    def process_folder_files(self, folder_path: Path) -> Tuple[int, int, int, Optional[Tuple[str, str]], bool]:
        """Process all JSON files in a folder
        
        Returns:
            Tuple of (success_count, partial_count, failure_count, first_failure_info, has_constraint_violation)
            first_failure_info is (file_name, file_path) if there was a failure, None otherwise
            has_constraint_violation is True if any file had a constraint violation error
        """
        print(f"{Colors.BLUE}{'=' * 60}{Colors.NC}")
        print(f"{Colors.BLUE}Processing folder: {folder_path.name}{Colors.NC}")
        print(f"{Colors.BLUE}{'=' * 60}{Colors.NC}")
        
        # Find all JSON files in this folder (recursively)
        all_json_files = sorted(folder_path.rglob("*.json"))
        
        # Filter out excluded files
        json_files = []
        for f in all_json_files:
            if self.is_file_excluded(f.name):
                print(f"{Colors.YELLOW}  ⊗ Skipping excluded file: {f.name}{Colors.NC}")
            else:
                json_files.append(f)
        
        if not json_files:
            print(f"{Colors.YELLOW}No JSON files found in {folder_path.name}{Colors.NC}")
            return 0, 0, 0, None, False
        
        print(f"{Colors.GREEN}✓ Found {len(json_files)} JSON file(s) in {folder_path.name}:{Colors.NC}")
        for idx, f in enumerate(json_files, 1):
            file_size = f.stat().st_size
            file_display_path = self.get_relative_path(f)
            print(f"{Colors.BLUE}  {idx}. {file_display_path} ({file_size} bytes){Colors.NC}")
        print()
        
        success_count = 0
        partial_count = 0
        failure_count = 0
        first_failure = None
        has_constraint_violation = False
        
        # Process each file
        for file_path in json_files:
            result = self.process_file(file_path)
            if result == 0:
                success_count += 1
            elif result == 2:
                partial_count += 1
            elif result == 4:  # Constraint violation
                failure_count += 1
                has_constraint_violation = True
                if first_failure is None:
                    first_failure = (file_path.name, str(file_path.absolute()))
            else:
                failure_count += 1
                if first_failure is None:
                    first_failure = (file_path.name, str(file_path.absolute()))
            print()
        
        return success_count, partial_count, failure_count, first_failure, has_constraint_violation

    def process_all_files(self) -> int:
        """Process all JSON files in the system packages directory with sequential folder processing"""
        global failed_processing
        
        print("=" * 60)
        print("System Package Upload and Trigger Processing")
        print("=" * 60)
        print(f"API Base URL: {self.api_base_url}")
        print(f"Template Name: {self.template_name}")
        print(f"Firm ID: {self.firm_id}")
        print(f"System Packages Dir: {self.system_packages_dir}")
        print(f"Poll Status: {self.poll_status}")
        if self.poll_status:
            print(f"Status Check Interval: {self.status_check_interval}s")
            print(f"Max Status Checks: {self.status_check_max_attempts}")
        if self.exclude_folders:
            print(f"{Colors.YELLOW}Excluded Folders: {', '.join(self.exclude_folders)}{Colors.NC}")
        if self.exclude_files:
            print(f"{Colors.YELLOW}Excluded Files: {', '.join(self.exclude_files)}{Colors.NC}")
        print("=" * 60)
        print()
        
        try:
            print(f"{Colors.BLUE}Scanning directory: {self.system_packages_dir.absolute()}{Colors.NC}")
            
            if not self.system_packages_dir.exists():
                print(f"{Colors.RED}✗ Directory not found: {self.system_packages_dir}{Colors.NC}")
                print(f"{Colors.YELLOW}  → Create the directory or specify a different path with --dir{Colors.NC}")
                return 1
                
            if not self.system_packages_dir.is_dir():
                print(f"{Colors.RED}✗ Path is not a directory: {self.system_packages_dir}{Colors.NC}")
                return 1
            
            # Check for numbered subfolders
            numbered_folders = self.get_numbered_subfolders()
            
            if numbered_folders:
                # Sequential folder processing mode
                print(f"{Colors.GREEN}✓ Found {len(numbered_folders)} subfolder(s){Colors.NC}")
                
                # Separate delete and add folders
                delete_folders = [(num, path) for num, path in numbered_folders 
                                 if any(keyword in path.name.lower() 
                                       for keyword in ['delete', 'del', 'remove'])]
                add_folders = [(num, path) for num, path in numbered_folders 
                              if any(keyword in path.name.lower() 
                                    for keyword in ['add', 'create', 'insert'])]
                other_folders = [(num, path) for num, path in numbered_folders 
                                if (num, path) not in delete_folders and (num, path) not in add_folders]
                
                # Process delete folders first, then add folders, then others
                folders_to_process = delete_folders + add_folders + other_folders
                
                if delete_folders:
                    print(f"{Colors.YELLOW}DELETE folders (will be processed first):{Colors.NC}")
                    for num, folder_path in delete_folders:
                        print(f"{Colors.BLUE}  {num}. {folder_path.name}{Colors.NC}")
                
                if add_folders:
                    print(f"{Colors.GREEN}ADD folders (will be processed after DELETE):{Colors.NC}")
                    for num, folder_path in add_folders:
                        print(f"{Colors.BLUE}  {num}. {folder_path.name}{Colors.NC}")
                
                if other_folders:
                    print(f"{Colors.BLUE}Other folders:{Colors.NC}")
                    for num, folder_path in other_folders:
                        print(f"{Colors.BLUE}  {num}. {folder_path.name}{Colors.NC}")
                print()
                
                total_success = 0
                total_partial = 0
                total_failure = 0
                
                # Track available delete folders for potential retry
                available_delete_folders = delete_folders.copy()
                
                # Process folders in order (delete -> add -> others)
                for folder_num, folder_path in folders_to_process:
                    success, partial, failure, first_failure, has_constraint = self.process_folder_files(folder_path)
                    
                    total_success += success
                    total_partial += partial
                    total_failure += failure
                    
                    # Print folder summary
                    print(f"{Colors.BLUE}Folder {folder_path.name} Summary:{Colors.NC}")
                    print(f"  Success: {success}, Partial: {partial}, Failed: {failure}")
                    print()
                    
                    # Check if constraint violation occurred and we have unprocessed delete folders
                    if has_constraint and available_delete_folders:
                        # Check if this folder is NOT a delete folder
                        is_delete_folder = (folder_num, folder_path) in delete_folders
                        
                        if not is_delete_folder:
                            print(f"{Colors.YELLOW}{'=' * 60}{Colors.NC}")
                            print(f"{Colors.YELLOW}CONSTRAINT VIOLATION DETECTED{Colors.NC}")
                            print(f"{Colors.YELLOW}Resources may already exist. Attempting DELETE folders...{Colors.NC}")
                            print(f"{Colors.YELLOW}{'=' * 60}{Colors.NC}")
                            print()
                            
                            # Process any remaining delete folders
                            for del_num, del_path in available_delete_folders:
                                print(f"{Colors.YELLOW}Processing DELETE folder: {del_path.name}{Colors.NC}")
                                del_success, del_partial, del_failure, del_first_failure, _ = self.process_folder_files(del_path)
                                
                                print(f"{Colors.BLUE}DELETE Folder {del_path.name} Summary:{Colors.NC}")
                                print(f"  Success: {del_success}, Partial: {del_partial}, Failed: {del_failure}")
                                print()
                            
                            # Clear the list so we don't retry again
                            available_delete_folders = []
                            
                            # Retry the current folder
                            print(f"{Colors.YELLOW}Retrying folder: {folder_path.name}{Colors.NC}")
                            print()
                            
                            # Clear previous constraint violation failures for retry
                            failed_processing = [(fn, fp, bid, st, det) for fn, fp, bid, st, det in failed_processing 
                                               if st != "CONSTRAINT_VIOLATION"]
                            
                            retry_success, retry_partial, retry_failure, retry_first_failure, retry_constraint = self.process_folder_files(folder_path)
                            
                            # Update totals with retry results (subtract previous, add new)
                            total_success = total_success - success + retry_success
                            total_partial = total_partial - partial + retry_partial
                            total_failure = total_failure - failure + retry_failure
                            
                            success = retry_success
                            partial = retry_partial
                            failure = retry_failure
                            first_failure = retry_first_failure
                            
                            print(f"{Colors.BLUE}Retry Result for {folder_path.name}:{Colors.NC}")
                            print(f"  Success: {success}, Partial: {partial}, Failed: {failure}")
                            print()
                    
                    # Remove processed folder from available delete folders if it was a delete folder
                    if (folder_num, folder_path) in available_delete_folders:
                        available_delete_folders.remove((folder_num, folder_path))
                    
                    # Stop if this folder had failures (after retry if applicable)
                    if failure > 0:
                        print(f"{Colors.RED}{'=' * 60}{Colors.NC}")
                        print(f"{Colors.RED}PROCESSING STOPPED DUE TO FAILURES IN FOLDER: {folder_path.name}{Colors.NC}")
                        print(f"{Colors.RED}{'=' * 60}{Colors.NC}")
                        if first_failure:
                            file_name, file_full_path = first_failure
                            print(f"{Colors.RED}First Failed File:{Colors.NC}")
                            print(f"  Name: {file_name}")
                            print(f"  Full Path: {file_full_path}")
                        print(f"{Colors.YELLOW}Subsequent folders will not be processed.{Colors.NC}")
                        print()
                        
                        # Print summary for what was processed
                        self.print_summary(total_success, total_partial, total_failure)
                        return 1
                
                # All folders processed successfully
                print(f"{Colors.GREEN}{'=' * 60}{Colors.NC}")
                print(f"{Colors.GREEN}ALL FOLDERS PROCESSED SUCCESSFULLY{Colors.NC}")
                print(f"{Colors.GREEN}{'=' * 60}{Colors.NC}")
                print()
                
                self.print_summary(total_success, total_partial, total_failure)
                return 0 if total_failure == 0 else 1
            
            else:
                # No numbered subfolders - process files directly in the directory
                all_json_files = sorted(self.system_packages_dir.glob("*.json"))
                
                # Filter out excluded files
                json_files = []
                for f in all_json_files:
                    if self.is_file_excluded(f.name):
                        print(f"{Colors.YELLOW}  ⊗ Skipping excluded file: {f.name}{Colors.NC}")
                    else:
                        json_files.append(f)
                
                if not json_files:
                    print(f"{Colors.YELLOW}No JSON files or numbered subfolders found in {self.system_packages_dir}{Colors.NC}")
                    print(f"{Colors.YELLOW}  → Expected: *.json files or subfolders starting with numbers (e.g., 1-delete, 2-add){Colors.NC}")
                    return 0
                
                print(f"{Colors.GREEN}✓ Found {len(json_files)} JSON file(s) to process:{Colors.NC}")
                for idx, f in enumerate(json_files, 1):
                    file_size = f.stat().st_size
                    file_display_path = self.get_relative_path(f)
                    print(f"{Colors.BLUE}  {idx}. {file_display_path} ({file_size} bytes){Colors.NC}")
                print()
                
                success_count = 0
                partial_count = 0
                failure_count = 0
                
                # Process each file
                for file_path in json_files:
                    result = self.process_file(file_path)
                    if result == 0:
                        success_count += 1
                    elif result == 2:
                        partial_count += 1
                    else:
                        failure_count += 1
                    print()
                
                # Summary
                self.print_summary(success_count, partial_count, failure_count)
                
                return 1 if failure_count > 0 else 0
            
        except PermissionError as e:
            print(f"{Colors.RED}✗ Permission denied accessing directory: {e}{Colors.NC}")
            return 1
        except Exception as e:
            print(f"{Colors.RED}✗ Error scanning directory: {e}{Colors.NC}")
            return 1

    def print_summary(self, success_count: int, partial_count: int, failure_count: int):
        """Print processing summary with detailed file paths"""
        total_count = success_count + partial_count + failure_count
        print()
        print("=" * 80)
        print("DETAILED EXECUTION SUMMARY")
        print("=" * 80)
        print(f"Total Files Processed: {total_count}")
        print(f"{Colors.GREEN}  ✓ Successful: {success_count}{Colors.NC}")
        if partial_count > 0:
            print(f"{Colors.YELLOW}  ⚠ Partial Success: {partial_count}{Colors.NC}")
        print(f"{Colors.RED}  ✗ Failed: {failure_count}{Colors.NC}")
        print("=" * 80)
        
        if successful_batches:
            print()
            print(f"{Colors.GREEN}✓ SUCCESSFUL BATCHES ({len(successful_batches)} file(s)):{Colors.NC}")
            for filename, filepath, batchid, details in successful_batches:
                print(f"  • File: {filepath}")
                print(f"    Batch ID: {batchid}")
                print(f"    Result: {details}")
                print()
        
        if failed_uploads:
            print()
            print(f"{Colors.RED}✗ UPLOAD FAILURES ({len(failed_uploads)} file(s)):{Colors.NC}")
            for filename, filepath, httpcode, message in failed_uploads:
                print(f"  • File: {filepath}")
                print(f"    Status: {httpcode}")
                print(f"    Error: {message}")
                print()
        
        if failed_triggers:
            print()
            print(f"{Colors.RED}✗ TRIGGER FAILURES ({len(failed_triggers)} file(s)):{Colors.NC}")
            for filename, filepath, batchid, httpcode, message in failed_triggers:
                print(f"  • File: {filepath}")
                print(f"    Batch ID: {batchid}")
                print(f"    Status: {httpcode}")
                print(f"    Error: {message}")
                print()
        
        if failed_processing:
            print()
            print(f"{Colors.RED}✗ PROCESSING FAILURES ({len(failed_processing)} file(s)):{Colors.NC}")
            for filename, filepath, batchid, status, details in failed_processing:
                print(f"  • File: {filepath}")
                print(f"    Batch ID: {batchid}")
                print(f"    Status: {status}")
                print(f"    Details: {details}")
                print()
        
        print("=" * 80)


def main():
    """Main execution function"""
    parser = argparse.ArgumentParser(
        description="Generate OAuth2 token and perform system package upload/trigger operations",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Using environment variables with default settings:
  %(prog)s

  # With custom client ID:
  %(prog)s --client-id "0oa..."

  # Enable status polling:
  %(prog)s --poll-status

  # Custom system packages directory:
  %(prog)s --dir /path/to/json/files

  # Custom API settings:
  %(prog)s --api-url https://custom.api.url --firm-id custom-firm

Setup:
  Set environment variables:
    export CXP_SYSTEM_CLIENT_ID=your-client-id
    export RSA_PRIVATE_KEY="MIIEvQIBADANBgkqhki..."
    export OAUTH2_TOKEN_URL=https://your-oauth-server/token
    export OAUTH2_AUDIENCE=your-audience
    export OAUTH2_SCOPES="scope1,scope2"
  
  Note: RSA_PRIVATE_KEY supports both one-line format and PEM format

Prerequisites:
  pip install PyJWT requests cryptography
        """,
    )

    # Token generation arguments
    parser.add_argument(
        "-c", "--client-id",
        help="OAuth2 client ID (or set CXP_SYSTEM_CLIENT_ID env var)",
    )
    
    parser.add_argument(
        "--use-secret",
        action="store_true",
        help="Force use of client_id and client_secret instead of RSA keys (auto-detects if not specified)",
    )
    
    parser.add_argument(
        "--test-token",
        action="store_true",
        help="Test token generation only without running upload/trigger operations",
    )

    # Upload/trigger arguments
    parser.add_argument(
        "-d", "--dir",
        default=os.getenv("TEST_PACKAGES_DIR", "../system-packages/test"),
        help="System packages directory containing JSON files (default: TEST_PACKAGES_DIR env var or ../system-packages/test)",
    )
    
    parser.add_argument(
        "-a", "--api-url",
        help="API base URL (or set API_BASE_URL env var)",
    )
    parser.add_argument(
        "-t", "--template",
        help="Template name (or set TEMPLATE_NAME env var)",
    )
    parser.add_argument(
        "-f", "--firm-id",
        help="Firm ID (or set FIRM_ID env var)",
    )
    parser.add_argument(
        "-p", "--poll-status",
        action="store_true",
        default=True,
        help="Enable batch status polling (default: enabled)",
    )
    parser.add_argument(
        "-i", "--interval",
        type=int,
        help="Status check interval in seconds (or set STATUS_CHECK_INTERVAL env var)",
    )
    parser.add_argument(
        "-m", "--max-attempts",
        type=int,
        help="Maximum status check attempts (or set STATUS_CHECK_MAX_ATTEMPTS env var)",
    )

    args = parser.parse_args()

    try:
        # Auto-detect authentication method if not explicitly specified
        use_client_secret = args.use_secret
        if not use_client_secret:
            # Check which credentials are available
            has_client_secret = bool(os.getenv("CXP_SYSTEM_CLIENT_SECRET"))
            has_rsa_key = bool(os.getenv("RSA_PRIVATE_KEY"))
            
            if has_client_secret:
                use_client_secret = True
                print(f"{Colors.CYAN}ℹ Auto-detected client_secret credentials{Colors.NC}")
            elif has_rsa_key:
                use_client_secret = False
                print(f"{Colors.CYAN}ℹ Auto-detected RSA key credentials{Colors.NC}")
            else:
                print(f"{Colors.RED}❌ Error: No credentials found{Colors.NC}", file=sys.stderr)
                print(f"{Colors.YELLOW}Set either:{Colors.NC}", file=sys.stderr)
                print(f"  - CXP_SYSTEM_CLIENT_SECRET (for client secret auth)", file=sys.stderr)
                print(f"  - RSA_PRIVATE_KEY (for RSA key auth)", file=sys.stderr)
                sys.exit(1)
        
        # Step 1: Generate OAuth2 token
        print(f"{Colors.BLUE}{'=' * 60}{Colors.NC}")
        print(f"{Colors.BLUE}STEP 1: GENERATING OAUTH2 TOKEN{Colors.NC}")
        print(f"{Colors.BLUE}{'=' * 60}{Colors.NC}")
        print()
        
        token_generator = TokenGenerator(use_client_secret=use_client_secret)
        access_token = token_generator.generate(
            client_id=args.client_id,
            verbose=True,
        )
        
        # If test-token mode, exit after generating token
        if args.test_token:
            print(f"{Colors.GREEN}{'=' * 60}{Colors.NC}")
            print(f"{Colors.GREEN}✅ Token generation test completed successfully{Colors.NC}")
            print(f"{Colors.GREEN}{'=' * 60}{Colors.NC}")
            print()
            print(f"{Colors.CYAN}Token preview (first 50 chars):{Colors.NC}")
            print(f"{access_token[:50]}...")
            print()
            print(f"{Colors.YELLOW}To run full upload/trigger process, remove --test-token flag{Colors.NC}")
            sys.exit(0)

        # Step 2: Process bulk uploads
        print()
        print(f"{Colors.BLUE}{'=' * 60}{Colors.NC}")
        print(f"{Colors.BLUE}STEP 2: SYSTEM PACKAGE UPLOAD AND TRIGGER{Colors.NC}")
        print(f"{Colors.BLUE}{'=' * 60}{Colors.NC}")
        print()

        # Set up directory
        system_packages_dir = None
        if args.dir:
            system_packages_dir = Path(args.dir)
        
        processor = BulkUploadProcessor(
            auth_token=access_token,
            token_generator=token_generator,
            api_base_url=args.api_url,
            template_name=args.template,
            firm_id=args.firm_id,
            system_packages_dir=system_packages_dir,
            poll_status=args.poll_status,
            status_check_interval=args.interval,
            status_check_max_attempts=args.max_attempts,
        )

        exit_code = processor.process_all_files()
        
        # Force cleanup of HTTP connection pools
        import gc
        gc.collect()
        
        # Force exit to avoid hanging on connection pools
        os._exit(exit_code)

    except Exception as e:
        print(f"{Colors.RED}❌ Error: {e}{Colors.NC}", file=sys.stderr)
        
        # Force cleanup even on error
        import gc
        gc.collect()
        
        # Force exit on error
        os._exit(1)


if __name__ == "__main__":
    main()