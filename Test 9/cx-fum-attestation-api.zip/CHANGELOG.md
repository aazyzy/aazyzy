# Changelog

## [5.0.2](https://github.com/NBC-GPMF/cx-fum-attestation-api/compare/v5.0.1...v5.0.2) (2026-11-20)


### Bug Fixes

* rebuild image on base image java-25-1.2.2 ([#67](https://github.com/NBC-GPMF/cx-fum-attestation-api/issues/67)) ([48d1e35](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/48d1e357c965c2d3e532f0342d1121c9b1c1d921))

## [5.0.1](https://github.com/NBC-GPMF/cx-fum-attestation-api/compare/v5.0.0...v5.0.1) (2026-11-02)


### Miscellaneous Chores

* call prod-promote.yaml@main, as the other FUM services do ([#58](https://github.com/NBC-GPMF/cx-fum-attestation-api/pull/58)) ([56a2c38](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/56a2c380e740477907399cd059ade73c2ddaf768))
* move to parent-pom-core 3.0.1, which fixes the Snyk findings of the 5.0.0 release: Tomcat 11.0.27, Jackson 3.2.4 and 2.22.4, Hibernate Validator 9.1.6.Final and java-jwt 4.6.2

## [5.0.0](https://github.com/NBC-GPMF/cx-fum-attestation-api/compare/v4.0.1...v5.0.0) (2026-10-29)


### Miscellaneous Chores

* move attestation-api to 5.0.0-SNAPSHOT on parent-pom-core 3.0.0-SNAPSHOT ([#48](https://github.com/NBC-GPMF/cx-fum-attestation-api/pull/48)) ([1c1b469](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/1c1b46966151633356ea9fcaacd8e083c09def07))
* skip Sonar in the release workflow on Java 25 ([#51](https://github.com/NBC-GPMF/cx-fum-attestation-api/pull/51)) ([1cbf703](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/1cbf703c5765c375e332e09b3a6930669e305d58))
* skip the SonarQube analysis for now ([#49](https://github.com/NBC-GPMF/cx-fum-attestation-api/pull/49)) ([2682baf](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/2682baf2302833cf9ef80df83b8136073f976dd8))
* sync 6900 dependency versions to develop SNAPSHOTs ([#50](https://github.com/NBC-GPMF/cx-fum-attestation-api/pull/50)) ([1f634fc](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/1f634fc59605b7fae838b03d62ed26bb9d4cbe56))

## [4.0.1](https://github.com/NBC-GPMF/cx-fum-attestation-api/compare/v4.0.0...v4.0.1) (2026-10-10)


### Miscellaneous Chores

* start on Aurora Global Database clusters: fum-commons-lib 14.0.0-SNAPSHOT lets preprod and production pin the AWS JDBC wrapper dialect (`postgres.iam.wrapperDialect`) ([cx-fum-commons-lib #43](https://github.com/NBC-GPMF/cx-fum-commons-lib/pull/43))

## [4.0.0](https://github.com/NBC-GPMF/cx-fum-attestation-api/compare/v3.2.0...v4.0.0) (2026-10-10)


### Miscellaneous Chores

* move attestation-api to Spring Boot 4.1.1 on develop (4.0.0-SNAPSHOT) ([#38](https://github.com/NBC-GPMF/cx-fum-attestation-api/pull/38)) ([5567f35](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/5567f351da93c078dad3056113f4ddac51414b86))
* pin spring-boot-maven-plugin to the Spring Boot version ([#33](https://github.com/NBC-GPMF/cx-fum-attestation-api/pull/33)) ([ace658a](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/ace658a626b247b03a58b8caf4ff637ea3b131cd))
* revert the spring-boot-maven-plugin pin (Spring Boot 4 work stays off develop) ([#34](https://github.com/NBC-GPMF/cx-fum-attestation-api/pull/34)) ([e4d2c57](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/e4d2c571516f7e812a4ef630cc23abedd85d8ad8))
* sync 6900 dependency versions to develop SNAPSHOTs ([b2924b1](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/b2924b17d822bf2dfd07659e6110d8988f758588))

## [3.2.0](https://github.com/NBC-GPMF/cx-fum-attestation-api/compare/v3.0.0...v3.2.0) (2026-09-16)


### Bug Fixes

* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([937ae91](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/937ae9183e897efe31cbc26121c1c5ef3167878c))
* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([e19f0b6](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/e19f0b6dd328afbb3b209e0c4a15b9fec0fa5691))


### Miscellaneous Chores

* pin released 6900 dependency versions for release 3.2.0 ([6c33d4d](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/6c33d4d1ad5399e48d77dcd096b66394f1e49581))

## [3.0.0](https://github.com/NBC-GPMF/cx-fum-attestation-api/compare/v2.2.2...v3.0.0) (2026-08-19)


### Miscellaneous Chores

* release 3.0.0 ([9bc194f](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/9bc194f5f6a1dd32fac472d02bf262b20205fbfb))

## [2.2.2](https://github.com/NBC-GPMF/cx-fum-attestation-api/compare/v2.2.1...v2.2.2) (2026-08-19)


### Bug Fixes

* **deps:** pin tomcat-embed 10.1.56 and logback-core 1.5.36 (Snyk HIGH) ([#14](https://github.com/NBC-GPMF/cx-fum-attestation-api/issues/14)) ([941eda2](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/941eda2c2d89c4ffc67b3a19257d9bb3d63be327))
* **deps:** pin vulnerable transitive dependencies for Snyk remediation ([#20](https://github.com/NBC-GPMF/cx-fum-attestation-api/issues/20)) ([67967ac](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/67967accf60b4ebb9e30327b55f65b61a570a900))

## [2.2.1](https://github.com/NBC-GPMF/cx-fum-attestation-api/compare/v2.2.0...v2.2.1) (2026-06-29)


### Bug Fixes

* release 2.2.1 ([434e159](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/434e159b668df554073225b1f67269cc6229ec4b))
* release 2.2.1 ([c1afc2c](https://github.com/NBC-GPMF/cx-fum-attestation-api/commit/c1afc2c4ae6af1f57c5272fd47b511129cedcaad))
