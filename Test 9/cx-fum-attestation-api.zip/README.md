# Attestation API

Spring Boot microservice for managing firm attestation labels, source data, and firm attestation workflows. Part of the CompassX Wealth platform..

| | |
|---|---|
| **Artifact** | `ca.bnc.wealth.api:attestation-api:1.0.0-SNAPSHOT` |
| **Java** | 17 |
| **Spring Boot** | via `spring-boot-maven-plugin` 2.6.8 |
| **Database** | PostgreSQL |
| **API Spec** | OpenAPI 3.0.3 (contract-first, from `attestation-schema`) |

## Prerequisites

- Java 17
- Maven
- Access to internal Maven repository (for parent POM and shared libraries)

## Build & Test

```bash
# Compile
mvn compile

# Run all tests (generates JaCoCo coverage report)
mvn test

# Run a single test class
mvn test -Dtest=AttestationControllerTests

# Run a single test method
mvn test -Dtest=AttestationControllerTests#testGetAttestationLabels

# Build executable JAR
mvn clean package -DskipTests

# Full build with tests
mvn clean install
```

Coverage report: `target/site/jacoco/index.html`

**Minimum test coverage: 80%** (JaCoCo instruction coverage). Current: 89.9% (73 tests).

## Run

```bash
java -jar target/attestation-api-exec.jar
```

The application starts on port `8081` with context path `/attestation`.

Management endpoints are available at `/attestation/manage/health` and `/attestation/manage/info`.

## API Endpoints

All endpoints require Bearer JWT authentication. Base path: `/attestation`.

### Attestation Labels

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/attestations` | List all attestation labels |
| `POST` | `/attestations` | Create a new attestation |
| `GET` | `/attestations/{attestation-id}` | Get attestation details by ID |
| `PUT` | `/attestations/{attestation-id}` | Update attestation (publish / cancel) |
| `DELETE` | `/attestations/{attestation-id}` | Delete attestation by ID |

### Source Data

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/attestations/source/types` | List source types |
| `GET` | `/attestations/source/files` | List source files |
| `GET` | `/attestations/{attestation-id}/source/data` | Get source data for an attestation |

### Firm Attestations

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/attestations/firms` | Get firm attestations by stage (paginated) |
| `PATCH` | `/attestations/firms/{firm-attestation-id}` | Acknowledge or cancel a firm attestation |
| `DELETE` | `/attestations/firms/{firm-attestation-id}` | Delete a firm attestation |

### Files

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/attestations/files` | List attestation firm files by stage |
| `GET` | `/attestations/files/{file-id}` | Download a file by ID |

## Project Structure

```
src/main/java/ca/bnc/wealth/api/attestation/
├── Application.java                          # Spring Boot entry point
├── client/
│   └── UserManagementClient.java             # Feign client for User Management API
├── config/
│   └── ServiceConfig.java                    # Microservice starter component scan
├── controller/
│   └── AttestationController.java            # REST controller (implements FirmAttestationApi)
├── dao/
│   └── ReportRequestAdditionalCriteria.java  # S3 report request criteria
├── service/
│   ├── AttestationService.java               # Business logic (fully implemented)
│   └── AttestationValidationService.java     # Request validation (fully implemented)
└── util/
    ├── AttestationConstants.java             # Error codes, S3 config, pagination defaults
    └── EntityMapperUtils.java                # Entity-to-DTO mapping utilities

src/test/java/ca/bnc/wealth/api/attestation/
├── config/
│   └── TestConfiguration.java
├── controller/
│   └── AttestationControllerTests.java       # 13 endpoint tests (MockMvc)
├── service/
│   ├── AttestationServiceTest.java           # 41 service method tests
│   └── AttestationValidationServiceTest.java # 19 validation tests
└── utility/
    └── MockData.java                         # Test data factories
```

## Docker

```bash
docker build -t attestation-api .
docker run -p 8080:8080 attestation-api
```

Base image: `docker-staging.bnc.ca/7461/compassx-base-docker-image:1.0.24`

## Documentation

- [Software Design Document](.github/sdd.md) — classes, endpoints, models, dependencies, config
- [Copilot Instructions](.github/copilot-instructions.md) — project guidelines for AI assistants
- [API Specification Wiki](https://wiki.bnc.ca/display/NBINDM/Firm+Attestation+API)

### Copilot Agents

| Agent | Purpose |
|-------|---------|
| [api-developer](.github/agents/api-developer.agent.md) | Make code changes: implement endpoints, service methods, tests |
| [api-explorer](.github/agents/api-explorer.agent.md) | Read-only: explore code, understand request flow, check coverage |

### Copilot Prompts

| Prompt | Purpose |
|--------|---------|
| [implement-service-method](.github/prompts/implement-service-method.prompt.md) | Implement a stub method in AttestationService |
| [add-validation](.github/prompts/add-validation.prompt.md) | Add validation logic to AttestationValidationService |
| [add-endpoint](.github/prompts/add-endpoint.prompt.md) | Add a new endpoint from the API spec |
| [review-api](.github/prompts/review-api.prompt.md) | Review project for convention compliance |

### Copilot Instructions (context-aware)

| Instruction | Applies To |
|-------------|------------|
| [controller-patterns](.github/instructions/controller-patterns.instructions.md) | `**/controller/*.java` |
| [service-patterns](.github/instructions/service-patterns.instructions.md) | `**/service/*.java` |
| [testing-patterns](.github/instructions/testing-patterns.instructions.md) | `**/*Test*.java` |
| [pom-config](.github/instructions/pom-config.instructions.md) | `pom.xml` |
