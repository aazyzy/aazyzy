# Branch Cleanup Report: attestation-api

Generated: 2026-06-08 10:47:48
Default Branch: develop
Total Branches: 1

---

## Summary

- Total Branches: 1
- Excluded from Deletion: 1
- Marked for Deletion: 0

---

## All Branches

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `feature/testing-cleanup` | 2026-06-08 10:32:32 -0400 | 2026-06-08 10:32:32 -0400 | UNMERGED |

---

## Excluded from Deletion

Criteria: Unmerged branches with last commit less than 2 months old
Count: 1

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `feature/testing-cleanup` | 2026-06-08 10:32:32 -0400 | 2026-06-08 10:32:32 -0400 | UNMERGED |

---

## Marked for Deletion

Criteria: All merged branches + unmerged branches with last commit older than 2 months
Count: 0

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| No branches marked for deletion | | | |
