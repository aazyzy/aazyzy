package ca.bnc.wealth.api.attestation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.jdbc.autoconfigure.DataSourceAutoConfiguration;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(
    exclude = DataSourceAutoConfiguration.class,
    scanBasePackages = {
      "ca.bnc.wealth.api.*",
      "ca.bnc.wealth.common.exception.*",
      "ca.bnc.wealth.common.fum.*",
      "ca.bnc.wealth.common.core.cors",
      "ca.bnc.wealth.common.health.*",
      "ca.bnc.wealth.common.jpa.*",
      "ca.bnc.wealth.common.report.*"
    })
@EnableFeignClients(basePackages = {"ca.bnc.wealth.api.attestation.client"})
@EnableJpaRepositories({"ca.bnc.wealth.common.jpa.repo"})
@EntityScan(basePackages = {"ca.bnc.wealth.common.jpa.entity"})
public class Application {

  public static void main(String[] args) {
    SpringApplication.run(Application.class, args);
  }

}
