package ca.bnc.wealth.api.attestation.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "userManagementClient", url = "${feign.userManagementApi.url}")
public interface UserManagementClient {

  @PostMapping(path = "attestation/{attestationId}")
  ResponseEntity<Void> generateAttestation(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @PathVariable(value = "attestationId") Integer attestationId);
}
