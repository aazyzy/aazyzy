package ca.bnc.wealth.api.attestation.controller;

import static org.springframework.http.HttpHeaders.CONTENT_DISPOSITION;

import ca.bnc.wealth.api.attestation.service.AttestationService;
import ca.bnc.wealth.api.attestation.service.AttestationValidationService;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.common.attestation.api.FirmAttestationApi;
import ca.bnc.wealth.common.attestation.model.AttestationFirmByStage;
import ca.bnc.wealth.common.attestation.model.AttestationFirmByStageResponse;
import ca.bnc.wealth.common.attestation.model.AttestationFirmFile;
import ca.bnc.wealth.common.attestation.model.AttestationLabel;
import ca.bnc.wealth.common.attestation.model.AttestationLabelDetails;
import ca.bnc.wealth.common.attestation.model.CreateAttestationRequest;
import ca.bnc.wealth.common.attestation.model.CreateAttestationResponse;
import ca.bnc.wealth.common.attestation.model.FirmAttestationPatchRequest;
import ca.bnc.wealth.common.attestation.model.SourceData;
import ca.bnc.wealth.common.attestation.model.SourceType;
import ca.bnc.wealth.common.attestation.model.UpdateAttestationRequest;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class AttestationController implements FirmAttestationApi {

  private final AttestationService attestationService;
  private final AttestationValidationService attestationValidationService;

  @Override
  public ResponseEntity<List<AttestationLabel>> getAttestationLabels() {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getAttestationLabels # Start: idpSubject: {}", user.getIdpSubject());
    log.info("GLOBAL_DATA_ACCESS: user={}, endpoint=getAttestationLabels, firmId={}",
        user.getIdpSubject(), user.getFirmId());
    return new ResponseEntity<>(attestationService.getAttestationLabels(), HttpStatus.OK);
  }

  @Override
  public ResponseEntity<List<SourceType>> getAttestationSourceTypes() {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getAttestationSourceTypes # Start: idpSubject: {}", user.getIdpSubject());
    log.info("GLOBAL_DATA_ACCESS: user={}, endpoint=getAttestationSourceTypes, firmId={}",
        user.getIdpSubject(), user.getFirmId());
    return new ResponseEntity<>(attestationService.getAttestationSourceTypes(), HttpStatus.OK);
  }

  @Override
  public ResponseEntity<List<SourceData>> getAttestationSourceDataByAttestationId(Long attestationId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getAttestationSourceDataByAttestationId # Start: idpSubject: {} attestationId: {}",
        user.getIdpSubject(), attestationId);
    return new ResponseEntity<>(
        attestationService.getAttestationSourceDataByAttestationId(attestationId), HttpStatus.OK);
  }

  @Override
  public ResponseEntity<AttestationFirmByStageResponse> getAttestationByStage(String stage,
      Integer attestationId, String firmId, Integer pageNo, Integer pageSize) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getAttestationByStage # Start: idpSubject: {} attestationId: {} firmId: {}",
        user.getIdpSubject(), attestationId, firmId);

    AttestationFirmByStageResponse attestationFirmByStage = attestationService
        .getAttestationFirmByStageByPagination(stage, attestationId, firmId, user, pageNo, pageSize);
    return new ResponseEntity<>(attestationFirmByStage, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<CreateAttestationResponse> createAttestation(
      CreateAttestationRequest createAttestationRequest) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("createAttestation # Start: idpSubject: {} createAttestationRequest: {}",
        user.getIdpSubject(), createAttestationRequest);

    attestationValidationService.validateCreateAttestationRequest(createAttestationRequest);
    CreateAttestationResponse response = attestationService.createAttestation(
        createAttestationRequest, user.getIdpSubject());
    attestationService.callUserManagementEtl(response.getAttestationId());

    return new ResponseEntity<>(response, HttpStatus.CREATED);
  }

  @Override
  public ResponseEntity<List<SourceData>> getAttestationSourceFiles() {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getAttestationSourceFiles # Start: idpSubject: {}", user.getIdpSubject());
    log.info("GLOBAL_DATA_ACCESS: user={}, endpoint=getAttestationSourceFiles, firmId={}",
        user.getIdpSubject(), user.getFirmId());
    return new ResponseEntity<>(attestationService.getAttestationSourceFiles(), HttpStatus.OK);
  }

  @Override
  public ResponseEntity<AttestationFirmByStage> patchFirmAttestation(Long firmAttestationId,
      FirmAttestationPatchRequest firmAttestationPatchRequest) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("patchFirmAttestation # Start: idpSubject: {} firmAttestationId: {} firmAttestationPatchRequest: {}",
        user.getIdpSubject(), firmAttestationId, firmAttestationPatchRequest);

    attestationValidationService.validatePatchFirmAttestationRequest(firmAttestationPatchRequest);
    AttestationFirmByStage response = attestationService.patchFirmAttestation(
        firmAttestationId, firmAttestationPatchRequest, user);

    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Void> deleteFirmAttestation(Long firmAttestationId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("deleteFirmAttestation # Start: idpSubject: {} firmAttestationId: {}",
        user.getIdpSubject(), firmAttestationId);

    attestationValidationService.validateDeleteFirmAttestationRequest(firmAttestationId);
    attestationService.deleteFirmAttestation(firmAttestationId, user);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Resource> getFilesByFileId(Long fileId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getFilesByFileId # Start: idpSubject: {} fileId: {}", user.getIdpSubject(), fileId);
    Pair<String, ByteArrayResource> pair = attestationService.getFilesByFileId(user, fileId);
    String filename = sanitizeFilename(pair.getKey(), user, fileId);
    String headerValue = "attachment; filename=\"" + filename + "\"";
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION, headerValue)
        .body(pair.getValue());
  }

  private String sanitizeFilename(String name, User user, Long fileId) {
    if (name == null) {
      return "";
    }
    if (name.indexOf('\r') >= 0 || name.indexOf('\n') >= 0) {
      log.warn("HEADER_INJECTION_ATTEMPT: suspicious filename detected, user={}, fileId={}",
          user.getIdpSubject(), fileId);
    }
    return name.replaceAll("[\\r\\n\\x00-\\x1f]", "_");
  }

  @Override
  public ResponseEntity<List<AttestationFirmFile>> getAttestationFirmFileByStage(String stage,
      Integer firmAttestationId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getAttestationFirmFileByStage # Start: idpSubject: {} stage: {} firmAttestationId: {}",
        user.getIdpSubject(), stage, firmAttestationId);

    List<AttestationFirmFile> files = attestationService
        .getFirmAttestationFiles(firmAttestationId, stage, user.getIdpSubject());

    return new ResponseEntity<>(files, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Void> updateAttestationByAttestationId(Long attestationId,
      UpdateAttestationRequest updateAttestationRequest) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("updateAttestationByAttestationId # Start: idpSubject: {} attestationId: {} updateAttestationRequest {}",
        user.getIdpSubject(), attestationId, updateAttestationRequest);
    attestationValidationService.validateUpdateAttestationRequest(updateAttestationRequest);
    attestationService.updateAttestationByAttestationId(
        attestationId, updateAttestationRequest, user);
    return new ResponseEntity<>(HttpStatus.OK);
  }

  @Override
  public ResponseEntity<AttestationLabelDetails> getAttestationById(Long attestationId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getAttestationById # Start: idpSubject: {} attestationId: {}",
        user.getIdpSubject(), attestationId);

    return new ResponseEntity<>(attestationService.getAttestationById(attestationId), HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Void> deleteAttestationByAttestationId(Long attestationId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("deleteAttestationByAttestationId # Start: idpSubject: {} attestationId: {}",
        user.getIdpSubject(), attestationId);

    attestationService.deleteAttestation(attestationId, user);

    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }
}
