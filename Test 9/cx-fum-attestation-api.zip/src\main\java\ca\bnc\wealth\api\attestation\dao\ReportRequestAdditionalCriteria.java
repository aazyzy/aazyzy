package ca.bnc.wealth.api.attestation.dao;

import lombok.Data;

@Data
public class ReportRequestAdditionalCriteria {
  private String s3SubPrefix;
}
