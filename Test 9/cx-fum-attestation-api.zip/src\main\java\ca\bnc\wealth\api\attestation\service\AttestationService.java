package ca.bnc.wealth.api.attestation.service;

import ca.bnc.wealth.api.attestation.client.UserManagementClient;
import ca.bnc.wealth.api.attestation.dao.ReportRequestAdditionalCriteria;
import ca.bnc.wealth.api.attestation.util.AttestationConstants;
import ca.bnc.wealth.api.attestation.util.EntityMapperUtils;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.common.attestation.model.AttestationFirmByStage;
import ca.bnc.wealth.common.attestation.model.AttestationFirmByStageResponse;
import ca.bnc.wealth.common.attestation.model.AttestationFirmFile;
import ca.bnc.wealth.common.attestation.model.AttestationLabel;
import ca.bnc.wealth.common.attestation.model.AttestationLabelDetails;
import ca.bnc.wealth.common.attestation.model.CreateAttestationRequest;
import ca.bnc.wealth.common.attestation.model.CreateAttestationResponse;
import ca.bnc.wealth.common.attestation.model.FirmAttestationPatchRequest;
import ca.bnc.wealth.common.attestation.model.SourceData;
import ca.bnc.wealth.common.attestation.model.SourceType;
import ca.bnc.wealth.common.attestation.model.UpdateAttestationRequest;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.enums.AttestationStatusType;
import ca.bnc.wealth.common.jpa.entity.iam.Attestation;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirm;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmPublished;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmStaging;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationSourceData;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationSourceType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationFirmFileRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationFirmHistoryRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationFirmPublishedRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationFirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationFirmStagingRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationSourceDataRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationSourceTypeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserConfigSearchMaterializedViewRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.report.feign.client.ReportApiClient;
import ca.bnc.wealth.common.report.model.ReportRequest;
import ca.bnc.wealth.common.report.model.S3Details;
import jakarta.transaction.Transactional;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.BeanUtils;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import tools.jackson.databind.json.JsonMapper;

@Slf4j
@Service
@RequiredArgsConstructor
public class AttestationService {

  private final AttestationRepository attestationRepository;
  private final AttestationSourceTypeRepository attestationSourceTypeRepository;
  private final AttestationSourceDataRepository attestationSourceDataRepository;
  private final AttestationFirmStagingRepository attestationFirmStagingRepository;
  private final AttestationFirmPublishedRepository attestationFirmPublishedRepository;
  private final AttestationFirmRepository attestationFirmRepository;
  private final AttestationFirmFileRepository attestationFirmFileRepository;
  private final AttestationFirmHistoryRepository attestationFirmHistoryRepository;
  private final FirmRepository firmRepository;
  private final UserConfigSearchMaterializedViewRepository userConfigSearchMaterializedViewRepository;
  private final SystemTokenFactory systemTokenFactory;
  private final UserManagementClient userManagementClient;
  private final ReportApiClient reportApiClient;
  private final JsonMapper objectMapper;

  public List<AttestationLabel> getAttestationLabels() {
    List<Attestation> attestationEntities = attestationRepository.findAllByOrderByCreatedDateDesc();

    return attestationEntities.stream()
        .map(EntityMapperUtils::toAttestationLabelDto)
        .toList();
  }

  public List<SourceType> getAttestationSourceTypes() {
    List<AttestationSourceType> sourceTypeEntities = attestationSourceTypeRepository.findAll();

    return sourceTypeEntities.stream()
        .map(EntityMapperUtils::toSourceTypeDto)
        .toList();
  }

  public List<SourceData> getAttestationSourceDataByAttestationId(Long attestationId) {
    List<AttestationSourceData> sourceDataEntities =
        attestationSourceDataRepository.findAllByAttestation_AttestationId(attestationId.intValue());
    return sourceDataEntities.stream()
        .map(EntityMapperUtils::toSourceDataDto)
        .toList();
  }

  public AttestationFirmByStageResponse getAttestationFirmByStageByPagination(String stage,
      Integer attestationId, String firmId, User user, Integer pageNo, Integer pageSize) {

    firmId = validateUserFirmAccess(firmId, user);

    Page<AttestationFirm> page = attestationFirmRepository.findAll(
        new Specification<>(getFieldMapForAttestationFirm(attestationId, firmId, stage)),
        configurePagination(pageNo, pageSize));

    int totalRecords = (int) page.getTotalElements();
    int totalPages = page.getTotalPages();

    List<AttestationFirmByStage> paginatedList = page.getContent().stream()
        .map(EntityMapperUtils::toDto)
        .toList();

    return EntityMapperUtils.toDto(paginatedList, totalRecords, totalPages);
  }

  private Pageable configurePagination(Integer pageNo, Integer pageSize) {
    if (pageNo == null || pageNo <= 0) {
      pageNo = AttestationConstants.DEFAULT_PAGE_NO;
    }

    if (pageSize == null || pageSize <= 0) {
      pageSize = AttestationConstants.DEFAULT_PAGE_SIZE;
    }

    if (pageSize > AttestationConstants.MAX_PAGE_SIZE) {
      log.warn("PAGINATION_LIMIT: pageSize={} exceeded max={}", pageSize,
          AttestationConstants.MAX_PAGE_SIZE);
      pageSize = AttestationConstants.MAX_PAGE_SIZE;
    }

    Sort sort = Sort.by(Sort.Order.desc("createdDate"));
    return PageRequest.of(pageNo - 1, pageSize, sort);
  }

  @Transactional
  public CreateAttestationResponse createAttestation(
      CreateAttestationRequest createAttestationRequest, String idpSubject) {
    Attestation attestationEntity;
    List<Firm> firmEntities;

    if (createAttestationRequest.getAttestationId() == null) {
      log.debug("Creating new attestation label: {}", createAttestationRequest.getLabel());
      firmEntities = getFirmsByFirmIds(createAttestationRequest.getFirms());

      attestationEntity = new Attestation();
      attestationEntity.setLabel(createAttestationRequest.getLabel());
      attestationEntity.setCount(firmEntities != null ? firmEntities.size() : 0);
      attestationEntity.setCreatedBy(idpSubject);
      attestationEntity.setCreatedDate(Timestamp.from(Instant.now()));
      attestationEntity.setAttestationStatusType(AttestationStatusType.PENDING);
      attestationEntity = attestationRepository.save(attestationEntity);
    } else {
      attestationEntity = attestationRepository.findById(
              createAttestationRequest.getAttestationId().longValue())
          .orElseThrow(() -> new FumNotFoundException(AttestationConstants.ATTESTATION_NOT_FOUND_CODE,
              String.format(AttestationConstants.ATTESTATION_NOT_FOUND_MESSAGE,
                  createAttestationRequest.getAttestationId())));

      log.debug("Regenerating existing attestation label: {}", createAttestationRequest.getLabel());
      if (isPublishedAttestation(attestationEntity)) {
        firmEntities = attestationFirmPublishedRepository
            .findAllByAttestation_AttestationId(attestationEntity.getAttestationId()).stream()
            .map(AttestationFirmPublished::getFirm)
            .filter(Objects::nonNull)
            .toList();
      } else {
        firmEntities = attestationFirmStagingRepository
            .findAllByAttestation_AttestationId(attestationEntity.getAttestationId()).stream()
            .map(AttestationFirmStaging::getFirm)
            .filter(Objects::nonNull)
            .toList();
      }
      deleteAttestationDependencies(attestationEntity.getAttestationId());
    }

    Map<Long, AttestationSourceType> sourceTypeEntityMap =
        getAttestationSourceTypesFromSourceData(createAttestationRequest.getSource());

    List<AttestationFirmStaging> attestationFirmStagingEntities = new ArrayList<>();
    for (Firm firmEntity : firmEntities) {
      AttestationFirmStaging attestationFirmStagingEntity = new AttestationFirmStaging();
      attestationFirmStagingEntity.setAttestation(attestationEntity);
      attestationFirmStagingEntity.setFirm(firmEntity);
      attestationFirmStagingEntity.setCreatedBy(idpSubject);
      attestationFirmStagingEntity.setCreatedDate(Timestamp.from(Instant.now()));
      attestationFirmStagingEntity.setAttestationStatusType(AttestationStatusType.PENDING);

      attestationFirmStagingEntities.add(attestationFirmStagingEntity);
    }
    attestationFirmStagingRepository.saveAll(attestationFirmStagingEntities);

    List<AttestationSourceData> attestationSourceDataEntities = new ArrayList<>();
    for (SourceData sourceData : createAttestationRequest.getSource()) {
      AttestationSourceData attestationSourceDataEntity = new AttestationSourceData();
      attestationSourceDataEntity.setAttestation(attestationEntity);
      attestationSourceDataEntity.setAttestationSourceType(
          sourceTypeEntityMap.get(sourceData.getTypeId().longValue()));
      attestationSourceDataEntity.setReportId(sourceData.getReportId());
      attestationSourceDataEntity.setReportVersionId(sourceData.getReportVersionId());
      attestationSourceDataEntity.setCreatedBy(idpSubject);
      attestationSourceDataEntity.setCreatedDate(Timestamp.from(Instant.now()));
      attestationSourceDataEntity.setDataName(
          sourceData.getName() == null ? "" : sourceData.getName());

      attestationSourceDataEntities.add(attestationSourceDataEntity);
    }
    attestationSourceDataRepository.saveAll(attestationSourceDataEntities);

    return new CreateAttestationResponse((int) attestationEntity.getAttestationId());
  }

  private void deleteAttestationDependencies(long attestationId) {
    attestationSourceDataRepository.deleteAllByAttestation_AttestationId(attestationId);
    attestationFirmFileRepository
        .deleteAllByAttestationFirmStaging_Attestation_AttestationId(attestationId);
    attestationFirmFileRepository
        .deleteAllByAttestationFirmPublished_Attestation_AttestationId(attestationId);
    attestationFirmHistoryRepository.deleteAllByAttestation_AttestationId(attestationId);
    attestationFirmStagingRepository.deleteAllByAttestation_AttestationId(attestationId);
    attestationFirmPublishedRepository.deleteAllByAttestation_AttestationId(attestationId);
  }

  public AttestationFirmByStage patchFirmAttestation(Long firmAttestationId,
      FirmAttestationPatchRequest firmAttestationPatchRequest, User user) {
    AttestationFirmByStage response;
    switch (firmAttestationPatchRequest.getAction()) {
      case ACKNOWLEDGE -> response = acknowledgeFirmAttestation(firmAttestationId, user);
      case CANCEL -> response = cancelFirmAttestation(firmAttestationId, user);
      default -> throw new FumValidationException(
          AttestationConstants.PATCH_FIRM_ATTESTATION_ACTION_INVALID_CODE,
          AttestationConstants.PATCH_FIRM_ATTESTATION_ACTION_INVALID_MESSAGE);
    }
    log.info("ATTESTATION_MUTATION_COMPLETE: action={}, firmAttestationId={}, newStatus={}, "
            + "user={}", firmAttestationPatchRequest.getAction(), firmAttestationId,
        response.getStatus(), user.getIdpSubject());
    return response;
  }

  @Transactional
  public AttestationFirmByStage cancelFirmAttestation(Long firmAttestationId, User user) {
    validateUsersFirm(user, AttestationConstants.NBIN, firmAttestationId);
    return attestationFirmPublishedRepository.findById(firmAttestationId)
        .map(firmAttestationPublished -> {
          firmAttestationPublished.setAttestationStatusType(AttestationStatusType.CANCELLED);
          firmAttestationPublished.setUpdatedBy(user.getIdpSubject());
          firmAttestationPublished.setUpdatedDate(Timestamp.from(Instant.now()));
          attestationFirmPublishedRepository.save(firmAttestationPublished);
          return EntityMapperUtils.toDto(firmAttestationPublished);
        })
        .orElseThrow(() -> new FumNotFoundException(
            AttestationConstants.FIRM_ATTESTATION_NOT_FOUND_CODE,
            String.format(AttestationConstants.FIRM_ATTESTATION_NOT_FOUND_MESSAGE,
                firmAttestationId)));
  }

  @Transactional
  public AttestationFirmByStage acknowledgeFirmAttestation(Long firmAttestationId, User user) {
    return attestationFirmPublishedRepository.findById(firmAttestationId)
        .map(firmAttestationPublished -> {
          validateUsersFirm(user, firmAttestationPublished.getFirm().getFirmId(),
              firmAttestationId);
          firmAttestationPublished.setAttestationStatusType(AttestationStatusType.COMPLETE);
          firmAttestationPublished.setAcknowledgedBy(user.getIdpSubject());
          firmAttestationPublished.setAcknowledgedDate(Timestamp.from(Instant.now()));
          attestationFirmPublishedRepository.save(firmAttestationPublished);
          return EntityMapperUtils.toDto(firmAttestationPublished);
        })
        .orElseThrow(() -> new FumNotFoundException(
            AttestationConstants.FIRM_ATTESTATION_NOT_FOUND_CODE,
            String.format(AttestationConstants.FIRM_ATTESTATION_NOT_FOUND_MESSAGE,
                firmAttestationId)));
  }

  @Transactional
  public void deleteFirmAttestation(Long firmAttestationId, User user) {
    AttestationFirmStaging attestationFirmStaging = attestationFirmStagingRepository
        .findById(firmAttestationId)
        .orElseThrow(() -> new FumNotFoundException(
            AttestationConstants.FIRM_ATTESTATION_NOT_FOUND_CODE,
            String.format(AttestationConstants.FIRM_ATTESTATION_NOT_FOUND_MESSAGE,
                firmAttestationId)));

    String attestationFirmId = attestationFirmStaging.getFirm() != null
        ? attestationFirmStaging.getFirm().getFirmId() : null;
    validateUsersFirm(user, attestationFirmId, firmAttestationId);

    log.info("FIRM_ATTESTATION_DELETE: user={}, firmAttestationId={}, attestationFirm={}, "
            + "userFirm={}", user.getIdpSubject(), firmAttestationId, attestationFirmId,
        user.getFirmId());

    attestationFirmFileRepository.deleteByAttestationFirmStaging(attestationFirmStaging);
    attestationFirmStagingRepository.delete(attestationFirmStaging);
  }

  public void callUserManagementEtl(Integer attestationId) {
    String token = systemTokenFactory.getBearerToken(AttestationConstants.SYSTEM_TOKEN_FUM);
    ResponseEntity<Void> response = userManagementClient.generateAttestation(token, attestationId);
    if (!response.getStatusCode().is2xxSuccessful()) {
      log.info("Failed to generate attestation in User Management Service for attestationId: {}",
          attestationId);
      throw new FumServiceException(AttestationConstants.CREATE_ATTESTATION_ETL_CALL_CODE,
          AttestationConstants.CREATE_ATTESTATION_ETL_CALL);
    }
  }

  List<Firm> getFirmsByFirmIds(List<String> firmIds) {
    if (firmIds.isEmpty()) {
      return firmRepository.findAll();
    }
    List<Firm> firmEntities = firmRepository.findAllByFirmIdIn(firmIds);
    if (firmEntities.size() != firmIds.size()) {
      throw new FumValidationException(AttestationConstants.CREATE_ATTESTATION_FIRMS_INVALID_CODE,
          AttestationConstants.CREATE_ATTESTATION_FIRMS_INVALID_MESSAGE);
    }
    return firmEntities;
  }

  Map<Long, AttestationSourceType> getAttestationSourceTypesFromSourceData(
      List<SourceData> sourceDataList) {
    List<Integer> sourceTypeIds = sourceDataList.stream()
        .map(SourceData::getTypeId)
        .distinct()
        .toList();

    List<AttestationSourceType> sourceTypeEntities =
        attestationSourceTypeRepository.findAllByAttestationSourceTypeIdIn(sourceTypeIds);
    if (sourceTypeEntities.size() != sourceTypeIds.size()) {
      throw new FumValidationException(AttestationConstants.CREATE_ATTESTATION_SOURCE_TYPES_CODE,
          AttestationConstants.CREATE_ATTESTATION_SOURCE_TYPES_MESSAGE);
    }

    boolean isSzSourceTypePresent = sourceTypeEntities.stream()
        .anyMatch(sourceType -> AttestationConstants.SZ_SOURCE_TYPE_CODE
            .equalsIgnoreCase(sourceType.getCode()));
    if (!isSzSourceTypePresent) {
      throw new FumValidationException(AttestationConstants.CREATE_ATTESTATION_SOURCE_TYPES_CODE,
          AttestationConstants.CREATE_ATTESTATION_SOURCE_TYPES_SZ_MESSAGE);
    }

    return sourceTypeEntities.stream()
        .collect(Collectors.toMap(
            AttestationSourceType::getAttestationSourceTypeId, sourceType -> sourceType));
  }

  public String validateUserFirmAccess(String firmId, User user) {
    String normalizedFirmId = firmId != null ? firmId.toUpperCase() : null;
    String userFirmId = user.getFirmId() != null ? user.getFirmId().toUpperCase() : null;

    if (normalizedFirmId != null && !normalizedFirmId.equals(userFirmId)
        && !AttestationConstants.NBIN.equals(userFirmId)) {
      log.warn("AUTHZ_FIRM_DENIED: user={}, userFirm={}, requestedFirm={}",
          user.getIdpSubject(), user.getFirmId(), firmId);
      throw new FumNotFoundException(AttestationConstants.FIRM_CONFIGURATION_NOT_FOUND_CODE,
          String.format(AttestationConstants.FIRM_CONFIGURATION_NOT_FOUND_MESSAGE, firmId));
    }

    if (!AttestationConstants.NBIN.equals(userFirmId) && normalizedFirmId == null) {
      normalizedFirmId = userFirmId;
    }

    if (normalizedFirmId != null && AttestationConstants.NBIN.equals(userFirmId)
        && AttestationConstants.NBIN.equals(normalizedFirmId)) {
      normalizedFirmId = null;
    }

    return normalizedFirmId;
  }

  private void validateUsersFirm(User user, String firmId, Long firmAttestationId) {
    if (user.getFirmId() == null || !user.getFirmId().equals(firmId)) {
      log.info("User {} does not have access to firmAttestationId {}",
          user.getIdpSubject(), firmAttestationId);
      throw new FumNotFoundException(AttestationConstants.FIRM_ATTESTATION_NOT_FOUND_CODE,
          String.format(AttestationConstants.FIRM_ATTESTATION_NOT_FOUND_MESSAGE,
              firmAttestationId));
    }
  }

  private Map<String, Pair<EnumQueryCriteria, Object>> getFieldMapForAttestationFirm(
      Integer attestationId, String firmId, String stage) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();

    if (firmId != null) {
      fieldValueMap.put("firmId", Pair.of(EnumQueryCriteria.EQUALS, firmId));
    }
    if (attestationId != null) {
      fieldValueMap.put("attestationId", Pair.of(EnumQueryCriteria.EQUALS, attestationId));
    }
    if (stage != null && !stage.isBlank()) {
      fieldValueMap.put("stage", Pair.of(EnumQueryCriteria.EQUALS, stage.toUpperCase()));
    }
    return fieldValueMap;
  }

  public List<SourceData> getAttestationSourceFiles() {
    List<AttestationSourceType> sourceTypeEntities =
        attestationSourceTypeRepository.findAllByActive(true);
    List<SourceData> sourceDataList = new ArrayList<>();

    for (AttestationSourceType sourceType : sourceTypeEntities) {
      SourceData sourceData = EntityMapperUtils.toSourceDataDto(sourceType);

      if (AttestationConstants.SZ_SOURCE_TYPE_CODE.equalsIgnoreCase(sourceType.getCode())) {
        S3Details s3Details = getLatestSzS3Details(sourceType.getParams());
        sourceData.setReportId(s3Details.getS3Uri());
        sourceData.setReportVersionId(s3Details.getVersionId());
        if (s3Details.getS3Uri() != null) {
          int fileNameIndex = s3Details.getS3Uri()
              .indexOf(AttestationConstants.S3_SZ_STARTS_WITH_VALUE);
          fileNameIndex = Math.max(fileNameIndex, 0);
          sourceData.setName(s3Details.getS3Uri().substring(fileNameIndex));
        }
        sourceDataList.add(sourceData);
      } else if (AttestationConstants.OTHER_SOURCE_TYPE_CODE
          .equalsIgnoreCase(sourceType.getCode())) {
        List<S3Details> s3DetailsList = getS3Details(sourceType.getParams(),
            AttestationConstants.S3_OTHER_STARTS_WITH_VALUE);
        sourceData.setOther(false);
        sourceDataList.add(sourceData);

        for (S3Details s3Details : s3DetailsList) {
          SourceData otherSourceData = EntityMapperUtils.toSourceDataDto(sourceType);
          otherSourceData.setReportId(s3Details.getS3Uri());
          otherSourceData.setReportVersionId(s3Details.getVersionId());
          if (s3Details.getS3Uri() != null) {
            int fileNameIndex = s3Details.getS3Uri()
                .indexOf(AttestationConstants.S3_OTHER_STARTS_WITH_VALUE);
            fileNameIndex = Math.max(fileNameIndex, 0);
            otherSourceData.setName(s3Details.getS3Uri().substring(fileNameIndex));
          }
          sourceDataList.add(otherSourceData);
        }
      } else {
        sourceDataList.add(sourceData);
      }
    }

    return sourceDataList;
  }

  private S3Details getLatestSzS3Details(String params) {
    List<S3Details> szS3DetailsList = getS3Details(params,
        AttestationConstants.S3_SZ_STARTS_WITH_VALUE);
    szS3DetailsList = Objects.requireNonNullElse(szS3DetailsList, new ArrayList<>());

    return szS3DetailsList.stream()
        .max(Comparator.comparing(S3Details::getLastUpdated))
        .orElse(new S3Details());
  }

  List<S3Details> getS3Details(String params, String startsWith) {
    ReportRequestAdditionalCriteria criteria;
    try {
      criteria = objectMapper.readValue(params, ReportRequestAdditionalCriteria.class);
    } catch (Exception e) {
      log.error("S3_CRITERIA_PARSE_FAILURE: failed to parse S3 additional criteria, paramsLength={}",
          params != null ? params.length() : 0, e);
      throw new FumServiceException("error.parseS3.fail",
          "Failed to parse S3 additional criteria");
    }

    Map<String, String> additionalCriteriaMap = new HashMap<>();
    additionalCriteriaMap.put(AttestationConstants.S3_LATEST_VERSION_ID,
        AttestationConstants.S3_LATEST_VERSION_ID_VALUE);
    additionalCriteriaMap.put(AttestationConstants.S3_STARTS_WITH, startsWith);
    additionalCriteriaMap.put(AttestationConstants.S3_SUB_PREFIX, criteria.getS3SubPrefix());

    ReportRequest reportRequest = new ReportRequest();
    reportRequest.set_object(AttestationConstants.S3_OBJECT_NAME);
    reportRequest.setFunction(AttestationConstants.S3_FUNCTION);
    reportRequest.setAdditionalCriteria(additionalCriteriaMap);

    String token = systemTokenFactory.getBearerToken(AttestationConstants.SYSTEM_TOKEN_FUM);
    ResponseEntity<List<S3Details>> szS3ResponseEntity =
        reportApiClient.getS3Details(token, reportRequest);

    return szS3ResponseEntity == null || szS3ResponseEntity.getBody() == null
        ? new ArrayList<>()
        : szS3ResponseEntity.getBody();
  }

  public Pair<String, ByteArrayResource> getFilesByFileId(User user, Long fileId) {
    ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmFile attestationFirmFile =
        attestationFirmFileRepository.findById(fileId)
            .orElseThrow(() -> new FumNotFoundException(
                AttestationConstants.FIRM_ATTESTATION_FILE_NOT_FOUND_CODE,
                String.format(AttestationConstants.FIRM_ATTESTATION_FILE_NOT_FOUND_MESSAGE,
                    fileId)));

    AttestationFirmPublished attestationFirmPublished = null;

    if (attestationFirmFile.getAttestationFirmPublished() != null) {
      attestationFirmPublished = attestationFirmFile.getAttestationFirmPublished();
      validateUserFirmAccess(attestationFirmPublished.getFirm().getFirmId(), user);
    } else if (attestationFirmFile.getAttestationFirmStaging() != null) {
      validateUserFirmAccess(
          attestationFirmFile.getAttestationFirmStaging().getFirm().getFirmId(), user);
    } else {
      throw new FumNotFoundException(
          AttestationConstants.FIRM_ATTESTATION_FILE_FIRM_ID_NOT_FOUND_CODE,
          String.format(AttestationConstants.FIRM_ATTESTATION_FILE_FIRM_ID_NOT_FOUND_MESSAGE,
              fileId));
    }

    Map<String, String> additionalCriteriaMap = new HashMap<>();
    additionalCriteriaMap.put(AttestationConstants.S3_URI, attestationFirmFile.getReportId());
    additionalCriteriaMap.put(AttestationConstants.S3_URI_VERSION,
        attestationFirmFile.getReportVersionId());

    ReportRequest reportRequest = new ReportRequest();
    reportRequest.set_object(AttestationConstants.S3_OBJECT_NAME);
    reportRequest.setFunction(AttestationConstants.S3_FUNCTION_DOWNLOAD);
    reportRequest.setAdditionalCriteria(additionalCriteriaMap);

    String token = systemTokenFactory.getBearerToken(AttestationConstants.SYSTEM_TOKEN_FUM);
    ResponseEntity<ByteArrayResource> responseEntity =
        reportApiClient.download(token, reportRequest);

    if (responseEntity != null && responseEntity.getBody() != null) {
      if (user.getFirmId() != null && attestationFirmPublished != null
          && user.getFirmId().equalsIgnoreCase(attestationFirmPublished.getFirm().getFirmId())
          && AttestationStatusType.AWAITING_REVIEW
              == attestationFirmPublished.getAttestationStatusType()) {
        attestationFirmPublished.setAttestationStatusType(AttestationStatusType.UNDER_REVIEW);
        attestationFirmPublished.setUpdatedBy(user.getIdpSubject());
        attestationFirmPublished.setUpdatedDate(Timestamp.from(Instant.now()));
        attestationFirmPublishedRepository.save(attestationFirmPublished);
        log.info("STATUS_TRANSITION: attestation={}, from=AWAITING_REVIEW, to=UNDER_REVIEW, "
                + "user={}", attestationFirmPublished.getAttestationFirmPublishedId(),
            user.getIdpSubject());
      }
      attestationFirmFile.setDownloadedBy(user.getIdpSubject());
      attestationFirmFile.setDownloadedDate(Timestamp.valueOf(LocalDateTime.now()));
      attestationFirmFileRepository.save(attestationFirmFile);
      return Pair.of(
          attestationFirmFile.getReportId()
              .substring(attestationFirmFile.getReportId().lastIndexOf('/') + 1),
          responseEntity.getBody());
    }

    throw new FumServiceException(AttestationConstants.FIRM_ATTESTATION_FILE_DOWNLOAD_ERROR,
        String.format(AttestationConstants.FIRM_ATTESTATION_FILE_DOWNLOAD_ERROR_MESSAGE, fileId));
  }

  public List<AttestationFirmFile> getFirmAttestationFiles(
      Integer firmAttestationId, String staging, String idpSubject) {

    if (validateAttestationFirmParams(firmAttestationId, staging)) {
      log.info("getFirmAttestationFiles # Invalid parameters: firmAttestationId: {}, staging: {}",
          firmAttestationId, staging);
      return new ArrayList<>();
    }

    Map<String, Pair<EnumQueryCriteria, Object>> fieldMap =
        getFieldMapForAttestationFirmFiles(firmAttestationId, staging);

    log.info("getFirmAttestationFiles # Field Map: {}", fieldMap);

    Specification<ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmFile> spec =
        new Specification<>(fieldMap);
    List<ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmFile> lst =
        attestationFirmFileRepository.findAll(spec, Sort.by(Sort.Order.desc("generated")));

    List<String> idpSubjects = lst.stream()
        .filter(file -> file.getDownloadedByName() != null)
        .map(file -> file.getDownloadedByName().getIdpSubject())
        .toList();

    Map<String, String> userDownloadedFirmIdMap =
        userConfigSearchMaterializedViewRepository.findAllByIdpSubjectIn(idpSubjects).stream()
            .collect(Collectors.toMap(
                UserConfigSearchMaterializedView::getIdpSubject,
                UserConfigSearchMaterializedView::getFirmId));

    UserConfigSearchMaterializedView userConfig =
        userConfigSearchMaterializedViewRepository.findByIdpSubject(idpSubject);
    String userFirmId = userConfig != null ? userConfig.getFirmId() : null;

    return lst.stream()
        .map(attestationFirmFile -> EntityMapperUtils.toDto(
            attestationFirmFile, userDownloadedFirmIdMap, userFirmId))
        .toList();
  }

  private boolean validateAttestationFirmParams(Integer firmAttestationId, String staging) {
    return (firmAttestationId != null && staging == null) || (staging != null
        && !staging.equalsIgnoreCase(AttestationConstants.ATTESTATION_FIRM_STAGING)
        && !staging.equalsIgnoreCase(AttestationConstants.ATTESTATION_FIRM_PUBLISHED));
  }

  private Map<String, Pair<EnumQueryCriteria, Object>> getFieldMapForAttestationFirmFiles(
      Integer firmAttestationId, String staging) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();

    if (staging != null) {
      if (staging.equalsIgnoreCase(AttestationConstants.ATTESTATION_FIRM_STAGING)) {
        fieldValueMap.put("attestationFirmStaging",
            Pair.of(EnumQueryCriteria.IS_NOT_NULL, null));

        if (firmAttestationId != null) {
          fieldValueMap.put("attestationFirmStaging.attestationFirmStagingId",
              Pair.of(EnumQueryCriteria.EQUALS, firmAttestationId));
        }
      }
      if (staging.equalsIgnoreCase(AttestationConstants.ATTESTATION_FIRM_PUBLISHED)) {
        fieldValueMap.put("attestationFirmPublished",
            Pair.of(EnumQueryCriteria.IS_NOT_NULL, null));

        if (firmAttestationId != null) {
          fieldValueMap.put("attestationFirmPublished.attestationFirmPublishedId",
              Pair.of(EnumQueryCriteria.EQUALS, firmAttestationId));
        }
      }
    }
    return fieldValueMap;
  }

  @Transactional
  public void updateAttestationByAttestationId(Long attestationId,
      UpdateAttestationRequest updateAttestationRequest, User user) {
    Attestation attestation = attestationRepository.findById(attestationId)
        .orElseThrow(() -> new FumNotFoundException(
            AttestationConstants.ATTESTATION_NOT_FOUND_CODE,
            String.format(AttestationConstants.ATTESTATION_NOT_FOUND_MESSAGE,
                attestationId)));

    switch (updateAttestationRequest.getAction()) {
      case PUBLISH -> {
        List<AttestationFirmStaging> stagingAttestationFirms =
            attestationFirmStagingRepository
                .findAllByAttestation_AttestationId(attestationId);

        List<AttestationFirmPublished> publishedAttestationFirms = new ArrayList<>();
        for (AttestationFirmStaging stagingFirm : stagingAttestationFirms) {
          AttestationFirmPublished publishedFirm = new AttestationFirmPublished();
          publishedFirm.setAttestation(stagingFirm.getAttestation());
          publishedFirm.setFirm(stagingFirm.getFirm());
          publishedFirm.setCreatedBy(user.getIdpSubject());
          publishedFirm.setCreatedDate(Timestamp.from(Instant.now()));
          publishedFirm.setAttestationStatusType(AttestationStatusType.AWAITING_REVIEW);
          publishedAttestationFirms.add(publishedFirm);
        }
        publishedAttestationFirms = attestationFirmPublishedRepository.saveAll(
            publishedAttestationFirms);
        Map<String, AttestationFirmPublished> publishedAttestationFirmMap =
            publishedAttestationFirms.stream()
                .collect(Collectors.toMap(
                    pub -> pub.getFirm().getFirmId(), pub -> pub));

        List<ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmFile> attestationFirmFiles =
            attestationFirmFileRepository.findAllByAttestationFirmStagingIn(
                stagingAttestationFirms);
        for (ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmFile attestationFirmFile
            : attestationFirmFiles) {
          AttestationFirmStaging stagingFirm =
              attestationFirmFile.getAttestationFirmStaging();
          attestationFirmFile.setAttestationFirmPublished(
              publishedAttestationFirmMap.get(stagingFirm.getFirm().getFirmId()));
          attestationFirmFile.setAttestationFirmStaging(null);
        }
        attestationFirmFileRepository.saveAll(attestationFirmFiles);

        attestationFirmStagingRepository.deleteAll(stagingAttestationFirms);

        attestation.setAttestationStatusType(AttestationStatusType.PUBLISHED);
        attestation.setPublishedDate(Timestamp.from(Instant.now()));
        attestation.setPublishedBy(user.getIdpSubject());
        attestationRepository.save(attestation);
      }
      case CANCEL -> {
        List<AttestationFirmPublished> publishAttestationFirms =
            attestationFirmPublishedRepository
                .findAllByAttestation_AttestationId(attestationId);

        for (AttestationFirmPublished publishedFirm : publishAttestationFirms) {
          cancelFirmAttestation(publishedFirm.getAttestationFirmPublishedId(), user);
        }

        attestation.setAttestationStatusType(AttestationStatusType.CANCELLED);
        attestationRepository.save(attestation);
      }
      default -> throw new FumValidationException(
          AttestationConstants.UPDATE_ATTESTATION_ACTION_INVALID_CODE,
          AttestationConstants.UPDATE_ATTESTATION_ACTION_INVALID_MESSAGE);
    }
  }

  public AttestationLabelDetails getAttestationById(Long attestationId) {
    return attestationRepository.findById(attestationId)
        .map(attestationEntity -> {
          AttestationLabel attestationLabel =
              EntityMapperUtils.toAttestationLabelDto(attestationEntity);
          AttestationLabelDetails attestationLabelDetails = new AttestationLabelDetails();
          BeanUtils.copyProperties(attestationLabel, attestationLabelDetails);

          Map<AttestationStatusType, Long> statusCountMap = new HashMap<>();
          List<String> firms = new ArrayList<>();

          if (isPublishedAttestation(attestationEntity)) {
            collectPublishedFirmStatuses(
                attestationEntity.getAttestationId(), firms, statusCountMap);
          } else {
            collectStagingFirmStatuses(
                attestationEntity.getAttestationId(), firms, statusCountMap);
          }

          attestationLabelDetails.setFirms(firms);
          attestationLabelDetails.setCountDetails(buildCountDetails(statusCountMap));

          return attestationLabelDetails;
        })
        .orElseThrow(() -> new FumNotFoundException(
            AttestationConstants.ATTESTATION_NOT_FOUND_CODE,
            String.format(AttestationConstants.ATTESTATION_NOT_FOUND_MESSAGE, attestationId)));
  }

  private boolean isPublishedAttestation(Attestation attestationEntity) {
    AttestationStatusType status = attestationEntity.getAttestationStatusType();
    if (status == null) {
      return false;
    }
    return switch (status) {
      case PUBLISHED, COMPLETE, AWAITING_REVIEW, UNDER_REVIEW, CANCELLED -> true;
      default -> false;
    };
  }

  private void collectPublishedFirmStatuses(Long attestationId, List<String> firms,
      Map<AttestationStatusType, Long> statusCountMap) {
    attestationFirmPublishedRepository.findAllByAttestation_AttestationId(attestationId).stream()
        .filter(f -> f.getAttestationStatusType() != null && f.getFirm() != null)
        .forEach(f -> {
          firms.add(f.getFirm().getFirmId());
          statusCountMap.merge(f.getAttestationStatusType(), 1L, Long::sum);
        });
  }

  private void collectStagingFirmStatuses(Long attestationId, List<String> firms,
      Map<AttestationStatusType, Long> statusCountMap) {
    attestationFirmStagingRepository.findAllByAttestation_AttestationId(attestationId).stream()
        .filter(f -> f.getAttestationStatusType() != null && f.getFirm() != null)
        .forEach(f -> {
          firms.add(f.getFirm().getFirmId());
          statusCountMap.merge(f.getAttestationStatusType(), 1L, Long::sum);
        });
  }

  private Map<String, String> buildCountDetails(
      Map<AttestationStatusType, Long> statusCountMap) {
    Map<String, String> countDetails = new HashMap<>();
    statusCountMap.entrySet().stream()
        .filter(e -> e.getKey() != null && e.getValue() != null)
        .sorted(Map.Entry.comparingByKey(Comparator.comparing(Enum::name)))
        .forEach(e -> countDetails.put(e.getKey().name(), String.valueOf(e.getValue())));
    return countDetails;
  }

  @Transactional
  public void deleteAttestation(Long attestationId, User user) {
    if (!AttestationConstants.NBIN.equalsIgnoreCase(user.getFirmId())) {
      log.warn("UNAUTHORIZED_DELETE_ATTEMPT: user={}, attestationId={}, userFirm={}",
          user.getIdpSubject(), attestationId, user.getFirmId());
      throw new FumNotFoundException(AttestationConstants.ATTESTATION_NOT_FOUND_CODE,
          String.format(AttestationConstants.ATTESTATION_NOT_FOUND_MESSAGE, attestationId));
    }
    deleteAttestationDependencies(attestationId);
    attestationRepository.deleteById(attestationId);
  }

}
