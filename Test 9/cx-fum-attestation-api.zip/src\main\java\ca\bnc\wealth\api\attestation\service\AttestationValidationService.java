package ca.bnc.wealth.api.attestation.service;

import ca.bnc.wealth.api.attestation.util.AttestationConstants;
import ca.bnc.wealth.common.attestation.model.CreateAttestationRequest;
import ca.bnc.wealth.common.attestation.model.FirmAttestationPatchRequest;
import ca.bnc.wealth.common.attestation.model.UpdateAttestationRequest;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class AttestationValidationService {

  public void validateCreateAttestationRequest(CreateAttestationRequest request) {
    if (request == null) {
      throw new FumValidationException(AttestationConstants.CREATE_ATTESTATION_INPUT_CODE,
          AttestationConstants.CREATE_ATTESTATION_INPUT_MESSAGE);
    }
    if (StringUtils.isEmpty(request.getLabel())) {
      throw new FumValidationException(AttestationConstants.CREATE_ATTESTATION_LABEL_CODE,
          AttestationConstants.CREATE_ATTESTATION_LABEL_MESSAGE);
    }
    if (request.getFirms() == null) {
      throw new FumValidationException(AttestationConstants.CREATE_ATTESTATION_FIRMS_CODE,
          AttestationConstants.CREATE_ATTESTATION_FIRMS_MESSAGE);
    }
    if (CollectionUtils.isEmpty(request.getSource())) {
      throw new FumValidationException(AttestationConstants.CREATE_ATTESTATION_SOURCE_CODE,
          AttestationConstants.CREATE_ATTESTATION_SOURCE_MESSAGE);
    }
  }

  public void validatePatchFirmAttestationRequest(FirmAttestationPatchRequest request) {
    if (request == null) {
      throw new FumValidationException(AttestationConstants.PATCH_FIRM_ATTESTATION_INPUT_CODE,
          AttestationConstants.PATCH_FIRM_ATTESTATION_INPUT_MESSAGE);
    }
    if (request.getAction() == null) {
      throw new FumValidationException(AttestationConstants.PATCH_FIRM_ATTESTATION_ACTION_CODE,
          AttestationConstants.PATCH_FIRM_ATTESTATION_ACTION_MESSAGE);
    }
  }

  public void validateDeleteFirmAttestationRequest(Long firmAttestationId) {
    if (firmAttestationId == null || firmAttestationId <= 0) {
      throw new FumValidationException(AttestationConstants.DELETE_FIRM_ATTESTATION_ID_CODE,
          AttestationConstants.DELETE_FIRM_ATTESTATION_ID_MESSAGE);
    }
  }

  public void validateUpdateAttestationRequest(UpdateAttestationRequest request) {
    if (request == null) {
      throw new FumValidationException(AttestationConstants.UPDATE_FIRM_ATTESTATION_EMPTY_CODE,
          AttestationConstants.UPDATE_FIRM_ATTESTATION_EMPTY_MESSAGE);
    }
    if (request.getAction() == null) {
      throw new FumValidationException(AttestationConstants.UPDATE_FIRM_ATTESTATION_EMPTY_ACTION_CODE,
          AttestationConstants.UPDATE_FIRM_ATTESTATION_EMPTY_ACTION_MESSAGE);
    }
  }

}
