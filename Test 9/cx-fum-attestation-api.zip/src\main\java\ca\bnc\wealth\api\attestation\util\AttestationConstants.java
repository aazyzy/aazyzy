package ca.bnc.wealth.api.attestation.util;

public class AttestationConstants {

  public static final String ATTESTATION_FIRM_STAGING = "STAGING";
  public static final String ATTESTATION_FIRM_PUBLISHED = "PUBLISHED";

  public static final String CREATE_ATTESTATION_INPUT_CODE = "error.createAttestation.null";
  public static final String CREATE_ATTESTATION_INPUT_MESSAGE = "Create Attestation request is null";
  public static final String CREATE_ATTESTATION_LABEL_CODE = "error.createAttestation.label.null";
  public static final String CREATE_ATTESTATION_LABEL_MESSAGE = "Create Attestation label is null or empty";
  public static final String CREATE_ATTESTATION_FIRMS_CODE = "error.createAttestation.firms.null";
  public static final String CREATE_ATTESTATION_FIRMS_MESSAGE = "Create Attestation firms is null";
  public static final String CREATE_ATTESTATION_FIRMS_INVALID_CODE = "error.createAttestation.firms.invalid";
  public static final String CREATE_ATTESTATION_FIRMS_INVALID_MESSAGE = "One or more firms do not exist";
  public static final String CREATE_ATTESTATION_SOURCE_CODE = "error.createAttestation.source.null";
  public static final String CREATE_ATTESTATION_SOURCE_MESSAGE = "Create Attestation source is null";
  public static final String CREATE_ATTESTATION_SOURCE_TYPES_CODE = "error.createAttestation.sourceTypes.invalid";
  public static final String CREATE_ATTESTATION_SOURCE_TYPES_MESSAGE = "One or more source types do not exist";
  public static final String CREATE_ATTESTATION_SOURCE_TYPES_SZ_MESSAGE = "Source type secureZone is required but not found in the provided source types";

  public static final String PATCH_FIRM_ATTESTATION_INPUT_CODE = "error.patchFirmAttestation.null";
  public static final String PATCH_FIRM_ATTESTATION_INPUT_MESSAGE = "Patch Firm Attestation request is null";
  public static final String PATCH_FIRM_ATTESTATION_ACTION_CODE = "error.patchFirmAttestation.action.null";
  public static final String PATCH_FIRM_ATTESTATION_ACTION_MESSAGE = "Patch Firm Attestation action is null";
  public static final String PATCH_FIRM_ATTESTATION_ACTION_INVALID_CODE = "error.patchFirmAttestation.action.invalid";
  public static final String PATCH_FIRM_ATTESTATION_ACTION_INVALID_MESSAGE = "Patch Firm Attestation action is invalid";

  public static final String DELETE_FIRM_ATTESTATION_ID_CODE = "error.deleteFirmAttestation.id.null";
  public static final String DELETE_FIRM_ATTESTATION_ID_MESSAGE = "Delete Firm Attestation ID is null";

  public static final String FIRM_ATTESTATION_NOT_FOUND_CODE = "error.firmAttestation.notFound";
  public static final String FIRM_ATTESTATION_NOT_FOUND_MESSAGE = "Firm Attestation not found for ID: %d";

  public static final String FIRM_ATTESTATION_FILE_NOT_FOUND_CODE = "error.firmAttestationFile.notFound";
  public static final String FIRM_ATTESTATION_FILE_NOT_FOUND_MESSAGE = "Firm Attestation File not found for ID: %d";

  public static final String FIRM_ATTESTATION_FILE_FIRM_ID_NOT_FOUND_CODE = "error.firmAttestationFile.firm.notFound";
  public static final String FIRM_ATTESTATION_FILE_FIRM_ID_NOT_FOUND_MESSAGE = "Firm not found for Attestation firm file ID: %d";

  public static final String FIRM_ATTESTATION_FILE_DOWNLOAD_ERROR = "error.firmAttestationFile.download";
  public static final String FIRM_ATTESTATION_FILE_DOWNLOAD_ERROR_MESSAGE = "Unable to download file id %s";


  public static final String UPDATE_FIRM_ATTESTATION_EMPTY_CODE = "error.updateAttestation.null";
  public static final String UPDATE_FIRM_ATTESTATION_EMPTY_MESSAGE = "Update Attestation request is null";
  public static final String UPDATE_FIRM_ATTESTATION_EMPTY_ACTION_CODE = "error.updateAttestation.source.null";
  public static final String UPDATE_FIRM_ATTESTATION_EMPTY_ACTION_MESSAGE = "Update Attestation request Action is null";
  public static final String ATTESTATION_NOT_FOUND_CODE = "error.attestation.notFound";
  public static final String ATTESTATION_NOT_FOUND_MESSAGE = "Attestation not found for ID: %d";

  public static final String UPDATE_ATTESTATION_ACTION_INVALID_CODE = "error.updateAttestation.action.invalid";
  public static final String UPDATE_ATTESTATION_ACTION_INVALID_MESSAGE = "Update Attestation action is invalid";

  public static final String FIRM_CONFIGURATION_NOT_FOUND_CODE = "error.firmConfiguration.notFound";
  public static final String FIRM_CONFIGURATION_NOT_FOUND_MESSAGE = "Firm Configuration %s not found";

  public static final String SZ_SOURCE_TYPE_CODE = "secureZone";
  public static final String OTHER_SOURCE_TYPE_CODE = "other";
  public static final String SYSTEM_TOKEN_FUM = "fum";
  public static final String CREATE_ATTESTATION_ETL_CALL_CODE = "error.userManagementEtl";
  public static final String CREATE_ATTESTATION_ETL_CALL = "Unable to create attestation via User Management ETL";
  public static final String NBIN = "NBIN";

  public static final String S3_LATEST_VERSION_ID = "GET_LATEST_VERSION_ID";
  public static final String S3_LATEST_VERSION_ID_VALUE = "true";
  public static final String S3_STARTS_WITH = "STARTS_WITH";
  public static final String S3_SZ_STARTS_WITH_VALUE = "List_Users_NBIN";
  public static final String S3_OTHER_STARTS_WITH_VALUE = "User Access Review";
  public static final String S3_OBJECT_NAME = "Attestation_User_Data";
  public static final String S3_FUNCTION = "LS";
  public static final String S3_FUNCTION_DOWNLOAD = "DOWNLOAD";
  public static final String S3_SUB_PREFIX = "S3_SUB_PREFIX";
  public static final String S3_URI = "S3_URI";
  public static final String S3_URI_VERSION = "S3_URI_VERSION";

  public static final Integer DEFAULT_PAGE_NO = 1;
  public static final Integer DEFAULT_PAGE_SIZE = 50;
  public static final Integer MAX_PAGE_SIZE = 1000;

  private AttestationConstants() {
    throw new IllegalStateException("Utility class");
  }
}
