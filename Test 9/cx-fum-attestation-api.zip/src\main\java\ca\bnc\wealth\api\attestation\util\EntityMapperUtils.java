package ca.bnc.wealth.api.attestation.util;

import static ca.bnc.wealth.api.attestation.util.AttestationConstants.NBIN;

import ca.bnc.wealth.common.attestation.model.AttestationFirmByStage;
import ca.bnc.wealth.common.attestation.model.AttestationFirmByStageResponse;
import ca.bnc.wealth.common.attestation.model.AttestationLabel;
import ca.bnc.wealth.common.attestation.model.SourceData;
import ca.bnc.wealth.common.attestation.model.SourceType;
import ca.bnc.wealth.common.jpa.entity.iam.Attestation;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirm;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmFile;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmPublished;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmStaging;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationSourceData;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationSourceType;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class EntityMapperUtils {

  private EntityMapperUtils() {
    throw new IllegalStateException("Utility class");
  }

  public static AttestationLabel toAttestationLabelDto(Attestation attestation) {
    AttestationLabel attestationLabel = new AttestationLabel();
    attestationLabel.setId((int) attestation.getAttestationId());
    attestationLabel.setLabel(attestation.getLabel());
    attestationLabel.setCount(attestation.getCount());
    attestationLabel.setCreatedBy(getName(attestation.getCreatedByName()));
    Optional.ofNullable(attestation.getCreatedDate())
        .ifPresent(timestamp -> attestationLabel.setCreatedDate(timestamp.toLocalDateTime()));
    attestationLabel.setPublishedBy(getName(attestation.getPublishedByName()));
    Optional.ofNullable(attestation.getPublishedDate())
        .ifPresent(timestamp -> attestationLabel.setPublishedDate(timestamp.toLocalDateTime()));
    Optional.ofNullable(attestation.getAttestationStatusType())
        .ifPresent(status -> attestationLabel.setStatus(status.name()));
    return attestationLabel;
  }

  private static String getName(IamUserConfiguration userConfig) {
    return Optional.ofNullable(userConfig)
        .map(cfg -> String.format("%s %s", cfg.getFirstName(), cfg.getLastName()))
        .orElse(null);
  }

  public static SourceType toSourceTypeDto(AttestationSourceType attestationSourceType) {
    SourceType sourceType = new SourceType();
    sourceType.setTypeId((int) attestationSourceType.getAttestationSourceTypeId());
    sourceType.setCode(attestationSourceType.getCode());
    sourceType.setLatest(attestationSourceType.getLatest());
    return sourceType;
  }

  public static SourceData toSourceDataDto(AttestationSourceData attestationSourceData) {
    SourceData sourceData = new SourceData();
    sourceData.setTypeId((int) attestationSourceData.getAttestationSourceType().getAttestationSourceTypeId());
    sourceData.setCode(attestationSourceData.getAttestationSourceType().getCode());
    sourceData.setLatest(attestationSourceData.getAttestationSourceType().getLatest());
    sourceData.setName(attestationSourceData.getDataName());
    sourceData.setReportId(attestationSourceData.getReportId());
    sourceData.setReportVersionId(attestationSourceData.getReportVersionId());
    sourceData.setOther(AttestationConstants.OTHER_SOURCE_TYPE_CODE.equalsIgnoreCase(
        attestationSourceData.getAttestationSourceType().getCode()));
    sourceData.setUpdateDate(attestationSourceData.getUpdatedDate() != null
        ? attestationSourceData.getUpdatedDate().toLocalDateTime() : null);
    return sourceData;
  }

  public static SourceData toSourceDataDto(AttestationSourceType attestationSourceType) {
    SourceData sourceData = new SourceData();
    sourceData.setTypeId((int) attestationSourceType.getAttestationSourceTypeId());
    sourceData.setCode(attestationSourceType.getCode());
    sourceData.setLatest(attestationSourceType.getLatest());
    sourceData.setOther(AttestationConstants.OTHER_SOURCE_TYPE_CODE.equalsIgnoreCase(
        attestationSourceType.getCode()));
    sourceData.setUpdateDate(attestationSourceType.getUpdatedDate() != null
        ? attestationSourceType.getUpdatedDate().toLocalDateTime() : null);
    return sourceData;
  }

  public static AttestationFirmByStage toDto(AttestationFirm attestationFirm) {
    AttestationFirmByStage dto = new AttestationFirmByStage();
    dto.setLabel(attestationFirm.getLabel());
    dto.setAttestationId(Math.toIntExact(attestationFirm.getAttestationId()));
    dto.setId(Math.toIntExact(attestationFirm.getAttestationFirmId()));
    dto.setStage(attestationFirm.getStage());
    dto.setFirmId(attestationFirm.getFirmId());
    dto.setFirmName(attestationFirm.getFirmName());
    dto.setStatus(attestationFirm.getStatus().name());
    dto.count(attestationFirm.getRecordCount());
    dto.setCreatedBy(attestationFirm.getCreatedByName());
    Optional.ofNullable(attestationFirm.getCreatedDate())
        .ifPresent(timestamp -> dto.setCreatedDate(timestamp.toLocalDateTime()));
    dto.setAcknowledgedBy(attestationFirm.getAcknowledgedByName());
    Optional.ofNullable(attestationFirm.getAcknowledgedDate())
        .ifPresent(timestamp -> dto.setAcknowledgedDate(timestamp.toLocalDateTime()));
    return dto;
  }

  public static AttestationFirmByStage toDto(AttestationFirmStaging attestationFirmStaging) {
    AttestationFirmByStage dto = new AttestationFirmByStage();
    dto.setLabel(attestationFirmStaging.getAttestation().getLabel());
    dto.setAttestationId((int) attestationFirmStaging.getAttestation().getAttestationId());
    dto.setId((int) attestationFirmStaging.getAttestationFirmStagingId());
    dto.setStage(AttestationConstants.ATTESTATION_FIRM_STAGING);
    dto.setFirmId(attestationFirmStaging.getFirm().getFirmId());
    dto.setFirmName(attestationFirmStaging.getFirm().getName());
    dto.setStatus(attestationFirmStaging.getAttestationStatusType().name());
    dto.count(getCount(attestationFirmStaging.getAttestationFirmFiles()));
    dto.setCreatedBy(getName(attestationFirmStaging.getCreatedByName()));
    Optional.ofNullable(attestationFirmStaging.getCreatedDate())
        .ifPresent(timestamp -> dto.setCreatedDate(timestamp.toLocalDateTime()));
    return dto;
  }

  public static AttestationFirmByStage toDto(AttestationFirmPublished attestationFirmPublished) {
    AttestationFirmByStage dto = new AttestationFirmByStage();
    dto.setLabel(attestationFirmPublished.getAttestation().getLabel());
    dto.setAttestationId((int) attestationFirmPublished.getAttestation().getAttestationId());
    dto.setId((int) attestationFirmPublished.getAttestationFirmPublishedId());
    dto.setStage(AttestationConstants.ATTESTATION_FIRM_PUBLISHED);
    dto.setFirmId(attestationFirmPublished.getFirm().getFirmId());
    dto.setFirmName(attestationFirmPublished.getFirm().getName());
    dto.setStatus(attestationFirmPublished.getAttestationStatusType().name());
    dto.count(!attestationFirmPublished.getAttestationFirmFiles().isEmpty()
        ? getCount(attestationFirmPublished.getAttestationFirmFiles()) : null);

    dto.setCreatedBy(getName(attestationFirmPublished.getCreatedByName()));
    Optional.ofNullable(attestationFirmPublished.getCreatedDate())
        .ifPresent(timestamp -> dto.setCreatedDate(timestamp.toLocalDateTime()));
    dto.setAcknowledgedBy(getName(attestationFirmPublished.getAcknowledgeByName()));
    Optional.ofNullable(attestationFirmPublished.getAcknowledgedDate())
        .ifPresent(timestamp -> dto.setAcknowledgedDate(timestamp.toLocalDateTime()));
    return dto;
  }

  private static Integer getCount(List<AttestationFirmFile> firmFiles) {
    Optional<AttestationFirmFile> file = firmFiles.stream()
        .filter(f -> f.getGenerated() != null && f.getGenerated())
        .findFirst();
    return file.map(AttestationFirmFile::getRecordCount).orElse(null);
  }

  public static AttestationFirmByStageResponse toDto(
      List<AttestationFirmByStage> attestationFirmByStages, int totalCount, int numberOfPages) {
    AttestationFirmByStageResponse response = new AttestationFirmByStageResponse();
    response.setTotalCount(totalCount);
    response.setNumberOfPages(numberOfPages);
    response.setData(attestationFirmByStages);
    return response;
  }

  public static ca.bnc.wealth.common.attestation.model.AttestationFirmFile toDto(
      AttestationFirmFile attestationFirmFile, Map<String, String> idpSubjectFirmIdMap,
      String userFirmId) {
    ca.bnc.wealth.common.attestation.model.AttestationFirmFile dto =
        new ca.bnc.wealth.common.attestation.model.AttestationFirmFile();

    dto.setAttestationFileId(Math.toIntExact(attestationFirmFile.getAttestationFirmFileId()));
    dto.setAttestationFirmId(Math.toIntExact(getAttestationFirmId(attestationFirmFile)));
    dto.setReportId(attestationFirmFile.getReportId());
    dto.setReportVersionId(attestationFirmFile.getReportVersionId());
    dto.setStage(attestationFirmFile.getAttestationFirmStaging() != null
        ? AttestationConstants.ATTESTATION_FIRM_STAGING : AttestationConstants.ATTESTATION_FIRM_PUBLISHED);
    dto.setRecordCount(attestationFirmFile.getRecordCount());
    dto.setGenerated(attestationFirmFile.getGenerated());
    dto.setCreatedBy(getName(attestationFirmFile.getCreatedByName()));
    Optional.ofNullable(attestationFirmFile.getCreatedDate())
        .ifPresent(timestamp -> dto.setCreatedDate(timestamp.toLocalDateTime()));
    dto.setUpdatedBy(getName(attestationFirmFile.getUpdatedByName()));
    Optional.ofNullable(attestationFirmFile.getUpdatedDate())
        .ifPresent(timestamp -> dto.setUpdateDate(timestamp.toLocalDateTime()));

    String userDownloadedFirmId = attestationFirmFile.getDownloadedByName() != null
        ? idpSubjectFirmIdMap.get(attestationFirmFile.getDownloadedByName().getIdpSubject())
        : null;
    if (!NBIN.equalsIgnoreCase(userFirmId)) {
      String fileFirmId = getFirmIdFromAttestationFirmFile(attestationFirmFile);
      if (fileFirmId != null && fileFirmId.equalsIgnoreCase(userDownloadedFirmId)) {
        dto.setDownloadedBy(getName(attestationFirmFile.getDownloadedByName()));
        Optional.ofNullable(attestationFirmFile.getDownloadedDate())
            .ifPresent(timestamp -> dto.setDownloadedDate(timestamp.toLocalDateTime()));
      }
    }

    return dto;
  }

  static String getFirmIdFromAttestationFirmFile(AttestationFirmFile attestationFirmFile) {
    if (attestationFirmFile.getAttestationFirmStaging() != null) {
      return attestationFirmFile.getAttestationFirmStaging().getFirm().getFirmId();
    }
    if (attestationFirmFile.getAttestationFirmPublished() != null) {
      return attestationFirmFile.getAttestationFirmPublished().getFirm().getFirmId();
    }
    return null;
  }

  private static Long getAttestationFirmId(AttestationFirmFile attestationFirmFile) {
    if (attestationFirmFile.getAttestationFirmStaging() != null) {
      return attestationFirmFile.getAttestationFirmStaging().getAttestationFirmStagingId();
    }
    if (attestationFirmFile.getAttestationFirmPublished() != null) {
      return attestationFirmFile.getAttestationFirmPublished().getAttestationFirmPublishedId();
    }
    return 0L;
  }
}
