package ca.bnc.wealth.api.attestation.config;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestConfiguration {

}
