package ca.bnc.wealth.api.attestation.controller;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ca.bnc.wealth.api.attestation.service.AttestationService;
import ca.bnc.wealth.api.attestation.service.AttestationValidationService;
import ca.bnc.wealth.api.attestation.utility.MockData;
import ca.bnc.wealth.api.authorization.security.SecurityConfigAdapter;
import ca.bnc.wealth.api.authorization.security.test.TestAuthConfiguration;
import ca.bnc.wealth.common.attestation.model.AttestationFirmByStage;
import ca.bnc.wealth.common.attestation.model.AttestationFirmByStageResponse;
import ca.bnc.wealth.common.attestation.model.AttestationFirmFile;
import ca.bnc.wealth.common.attestation.model.AttestationLabel;
import ca.bnc.wealth.common.attestation.model.AttestationLabelDetails;
import ca.bnc.wealth.common.attestation.model.CreateAttestationRequest;
import ca.bnc.wealth.common.attestation.model.CreateAttestationResponse;
import ca.bnc.wealth.common.attestation.model.FirmAttestationPatchRequest;
import ca.bnc.wealth.common.attestation.model.SourceData;
import ca.bnc.wealth.common.attestation.model.SourceType;
import ca.bnc.wealth.common.attestation.model.UpdateAttestationRequest;
import java.util.List;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.json.JsonMapper;

@WebMvcTest(properties = {"spring.profiles.active=test"})
@ExtendWith(SpringExtension.class)
@AutoConfigureMockMvc
@ContextConfiguration(
    classes = {
        SecurityConfigAdapter.class,
        TestAuthConfiguration.class,
        AttestationController.class,
        ca.bnc.wealth.common.spring.microservice.starter.core.exception.GlobalDefaultExceptionHandler
            .class
    })
class AttestationControllerTests {

  @Autowired
  WebApplicationContext webApplicationContext;
  @Autowired
  private MockMvc mockMvc;
  @Autowired
  private JsonMapper objectMapper;
  @MockitoBean
  private AttestationService attestationService;
  @MockitoBean
  private AttestationValidationService attestationValidationService;

  @BeforeEach
  void setup() {
    mockMvc =
        MockMvcBuilders.webAppContextSetup(webApplicationContext).apply(springSecurity()).build();
  }

  @Test
  void testGetAttestationLabels() throws Exception {
    List<AttestationLabel> expectedLabels = MockData.getAttestationLabels();
    when(attestationService.getAttestationLabels()).thenReturn(expectedLabels);
    MvcResult mvcResult =
        mockMvc
            .perform(get("/attestations").header(HttpHeaders.AUTHORIZATION, ""))
            .andExpect(status().isOk())
            .andReturn();

    List<AttestationLabel> actualLabels =
        objectMapper.readValue(
            mvcResult.getResponse().getContentAsString(), new TypeReference<>() {});
    assertThat(expectedLabels, is(actualLabels));
  }

  @Test
  void testGetAttestationSourceTypes() throws Exception {
    List<SourceType> expectedSourceTypes = MockData.getSourceTypes();
    when(attestationService.getAttestationSourceTypes()).thenReturn(expectedSourceTypes);
    MvcResult mvcResult =
        mockMvc
            .perform(get("/attestations/source/types").header(HttpHeaders.AUTHORIZATION, ""))
            .andExpect(status().isOk())
            .andReturn();

    List<SourceType> actualSourceTypes =
        objectMapper.readValue(
            mvcResult.getResponse().getContentAsString(), new TypeReference<>() {});
    assertThat(expectedSourceTypes, is(actualSourceTypes));
  }

  @Test
  void testGetAttestationSourceDataByAttestationId() throws Exception {
    List<SourceData> expectedSourceData = MockData.getSourceData();
    when(attestationService.getAttestationSourceDataByAttestationId(any())).thenReturn(expectedSourceData);
    MvcResult mvcResult =
        mockMvc
            .perform(get("/attestations/{id}/source/data", 1).header(HttpHeaders.AUTHORIZATION, ""))
            .andExpect(status().isOk())
            .andReturn();

    List<SourceData> actualSourceData =
        objectMapper.readValue(
            mvcResult.getResponse().getContentAsString(), new TypeReference<>() {});
    assertThat(expectedSourceData, is(actualSourceData));
  }

  @Test
  void testGetAttestationByStage() throws Exception {
    AttestationFirmByStageResponse expectedResponse = MockData.getAttestationFirmByStageResponse();
    doReturn(expectedResponse).when(attestationService)
        .getAttestationFirmByStageByPagination(any(), any(), any(), any(), any(), any());
    MvcResult mvcResult =
        mockMvc
            .perform(
                get("/attestations/firms?stage=published&attestation-id=123&firm-id=CORD&pageNo=2&pageSize=10")
                    .header(HttpHeaders.AUTHORIZATION, ""))
            .andExpect(status().isOk())
            .andReturn();

    AttestationFirmByStageResponse actualResponse =
        objectMapper.readValue(
            mvcResult.getResponse().getContentAsString(), new TypeReference<>() {});
    assertEquals(expectedResponse.getTotalCount(), actualResponse.getTotalCount());
  }

  @Test
  void testCreateAttestation() throws Exception {
    CreateAttestationRequest request = MockData.getCreateAttestationRequest();
    CreateAttestationResponse expectedResponse = MockData.getCreateAttestationResponse();
    when(attestationService.createAttestation(any(), any())).thenReturn(expectedResponse);

    MvcResult mvcResult =
        mockMvc
            .perform(
                post("/attestations")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(objectMapper.writeValueAsString(request))
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isCreated())
            .andReturn();

    CreateAttestationResponse actualResponse =
        objectMapper.readValue(
            mvcResult.getResponse().getContentAsString(), CreateAttestationResponse.class);
    assertEquals(expectedResponse.getAttestationId(), actualResponse.getAttestationId());
    verify(attestationService).callUserManagementEtl(expectedResponse.getAttestationId());
  }

  @Test
  void testGetAttestationSourceFiles() throws Exception {
    List<SourceData> expectedSourceData = MockData.getSourceData();
    when(attestationService.getAttestationSourceFiles()).thenReturn(expectedSourceData);
    MvcResult mvcResult =
        mockMvc
            .perform(get("/attestations/source/files").header(HttpHeaders.AUTHORIZATION, ""))
            .andExpect(status().isOk())
            .andReturn();

    List<SourceData> actualSourceData =
        objectMapper.readValue(
            mvcResult.getResponse().getContentAsString(), new TypeReference<>() {});
    assertThat(expectedSourceData, is(actualSourceData));
  }

  @Test
  void testPatchFirmAttestation() throws Exception {
    FirmAttestationPatchRequest patchRequest = MockData.getPatchRequest();
    AttestationFirmByStage expectedResponse = MockData.getAttestationFirmByStage();
    when(attestationService.patchFirmAttestation(anyLong(), any(), any())).thenReturn(expectedResponse);

    MvcResult mvcResult =
        mockMvc
            .perform(
                patch("/attestations/firms/{firmAttestationId}", 1)
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(objectMapper.writeValueAsString(patchRequest))
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();

    AttestationFirmByStage actualResponse =
        objectMapper.readValue(
            mvcResult.getResponse().getContentAsString(), AttestationFirmByStage.class);
    assertEquals(expectedResponse.getFirmId(), actualResponse.getFirmId());
  }

  @Test
  void testDeleteFirmAttestation() throws Exception {
    mockMvc
        .perform(
            delete("/attestations/firms/{firmAttestationId}", 1)
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf()))
        .andExpect(status().isNoContent())
        .andReturn();

    verify(attestationService).deleteFirmAttestation(anyLong(), any());
  }

  @Test
  void testGetFilesByFileId() throws Exception {
    ByteArrayResource resource = new ByteArrayResource("content".getBytes());
    Pair<String, ByteArrayResource> pair = Pair.of("test.csv", resource);
    when(attestationService.getFilesByFileId(any(), anyLong())).thenReturn(pair);
    MvcResult mvcResult =
        mockMvc
            .perform(get("/attestations/files/{file_id}", 1).header(HttpHeaders.AUTHORIZATION, ""))
            .andExpect(status().isOk())
            .andReturn();

    assertEquals("attachment; filename=\"test.csv\"",
        mvcResult.getResponse().getHeader("Content-Disposition"));
  }

  @Test
  void testGetAttestationFirmFileByStage() throws Exception {
    List<AttestationFirmFile> expectedFiles = MockData.getAttestationFirmFiles();
    when(attestationService.getFirmAttestationFiles(anyInt(), any(), any())).thenReturn(expectedFiles);
    MvcResult mvcResult =
        mockMvc
            .perform(
                get("/attestations/files?firm-attestation-id=247&stage=PUBLISHED")
                    .header(HttpHeaders.AUTHORIZATION, ""))
            .andExpect(status().isOk())
            .andReturn();

    List<AttestationFirmFile> actualFiles =
        objectMapper.readValue(
            mvcResult.getResponse().getContentAsString(), new TypeReference<>() {});
    assertThat(expectedFiles.get(0), is(actualFiles.get(0)));
  }

  @Test
  void testUpdateAttestationByAttestationId() throws Exception {
    UpdateAttestationRequest updateRequest = MockData.getUpdateAttestationRequest();

    mockMvc
        .perform(
            put("/attestations/{attestationId}", 1)
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(updateRequest))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andReturn();

    verify(attestationService).updateAttestationByAttestationId(anyLong(), any(), any());
  }

  @Test
  void testGetAttestationById() throws Exception {
    AttestationLabelDetails expectedDetails = MockData.getAttestationLabelDetails();
    when(attestationService.getAttestationById(anyLong())).thenReturn(expectedDetails);
    MvcResult mvcResult =
        mockMvc
            .perform(get("/attestations/{id}", 1).header(HttpHeaders.AUTHORIZATION, ""))
            .andExpect(status().isOk())
            .andReturn();

    AttestationLabelDetails actualDetails =
        objectMapper.readValue(
            mvcResult.getResponse().getContentAsString(), AttestationLabelDetails.class);
    assertEquals(expectedDetails.getLabel(), actualDetails.getLabel());
    assertEquals(expectedDetails.getFirms(), actualDetails.getFirms());
  }

  @Test
  void testDeleteAttestationByAttestationId() throws Exception {
    mockMvc
        .perform(
            delete("/attestations/{attestationId}", 1)
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf()))
        .andExpect(status().isNoContent())
        .andReturn();

    verify(attestationService).deleteAttestation(anyLong(), any());
  }
}
