package ca.bnc.wealth.api.attestation.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.attestation.client.UserManagementClient;
import ca.bnc.wealth.api.attestation.dao.ReportRequestAdditionalCriteria;
import ca.bnc.wealth.api.attestation.util.AttestationConstants;
import ca.bnc.wealth.api.attestation.utility.MockData;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.common.attestation.model.AttestationFirmByStage;
import ca.bnc.wealth.common.attestation.model.AttestationFirmByStageResponse;
import ca.bnc.wealth.common.attestation.model.AttestationLabel;
import ca.bnc.wealth.common.attestation.model.AttestationLabelDetails;
import ca.bnc.wealth.common.attestation.model.CreateAttestationRequest;
import ca.bnc.wealth.common.attestation.model.CreateAttestationResponse;
import ca.bnc.wealth.common.attestation.model.FirmAttestationPatchRequest;
import ca.bnc.wealth.common.attestation.model.SourceData;
import ca.bnc.wealth.common.attestation.model.SourceType;
import ca.bnc.wealth.common.attestation.model.UpdateAttestationRequest;
import ca.bnc.wealth.common.attestation.model.UpdateAttestationRequest.ActionEnum;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.enums.AttestationStatusType;
import ca.bnc.wealth.common.jpa.entity.iam.Attestation;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirm;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmFile;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmPublished;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmStaging;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationSourceData;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationSourceType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationFirmFileRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationFirmHistoryRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationFirmPublishedRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationFirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationFirmStagingRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationSourceDataRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationSourceTypeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserConfigSearchMaterializedViewRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.report.feign.client.ReportApiClient;
import ca.bnc.wealth.common.report.model.S3Details;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.SneakyThrows;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import tools.jackson.databind.json.JsonMapper;

@ExtendWith(SpringExtension.class)
class AttestationServiceTest {

  private AttestationService attestationService;

  @MockitoBean
  private AttestationRepository attestationRepository;

  @MockitoBean
  private AttestationSourceTypeRepository attestationSourceTypeRepository;

  @MockitoBean
  private AttestationSourceDataRepository attestationSourceDataRepository;

  @MockitoBean
  private AttestationFirmStagingRepository attestationFirmStagingRepository;

  @MockitoBean
  private AttestationFirmPublishedRepository attestationFirmPublishedRepository;

  @MockitoBean
  private AttestationFirmRepository attestationFirmRepository;

  @MockitoBean
  private AttestationFirmFileRepository attestationFirmFileRepository;

  @MockitoBean
  private AttestationFirmHistoryRepository attestationFirmHistoryRepository;

  @MockitoBean
  private FirmRepository firmRepository;

  @MockitoBean
  private UserConfigSearchMaterializedViewRepository userConfigSearchMaterializedViewRepository;

  @MockitoBean
  private SystemTokenFactory systemTokenFactory;

  @MockitoBean
  private UserManagementClient userManagementClient;

  @MockitoBean
  private ReportApiClient reportApiClient;

  @MockitoBean
  private JsonMapper objectMapper;

  @BeforeEach
  void setup() {
    attestationService = new AttestationService(attestationRepository,
        attestationSourceTypeRepository, attestationSourceDataRepository,
        attestationFirmStagingRepository, attestationFirmPublishedRepository,
        attestationFirmRepository, attestationFirmFileRepository, attestationFirmHistoryRepository,
        firmRepository, userConfigSearchMaterializedViewRepository, systemTokenFactory,
        userManagementClient, reportApiClient, objectMapper);
  }

  @Test
  void testGetAttestationLabels() {
    List<Attestation> expectedAttestations = MockData.getAttestations();
    when(attestationRepository.findAllByOrderByCreatedDateDesc()).thenReturn(expectedAttestations);

    List<AttestationLabel> actualLabels = attestationService.getAttestationLabels();
    assertEquals(expectedAttestations.size(), actualLabels.size());
    assertEquals((int) expectedAttestations.get(0).getAttestationId(), actualLabels.get(0).getId());
    assertEquals(expectedAttestations.get(0).getCount(), actualLabels.get(0).getCount());
    assertEquals(expectedAttestations.get(0).getAttestationStatusType().name(),
        actualLabels.get(0).getStatus());
  }

  @Test
  void testGetAttestationSourceTypes() {
    List<AttestationSourceType> expectedSourceTypes = MockData.getAttestationSourceType();
    when(attestationSourceTypeRepository.findAll()).thenReturn(expectedSourceTypes);

    List<SourceType> actualSourceTypes = attestationService.getAttestationSourceTypes();
    assertEquals(expectedSourceTypes.size(), actualSourceTypes.size());
    assertEquals((int) expectedSourceTypes.get(0).getAttestationSourceTypeId(),
        actualSourceTypes.get(0).getTypeId());
    assertEquals(expectedSourceTypes.get(0).getCode(), actualSourceTypes.get(0).getCode());
    assertEquals(expectedSourceTypes.get(0).getLatest(), actualSourceTypes.get(0).getLatest());
  }

  @Test
  void testGetAttestationSourceDataByAttestationId() {
    List<AttestationSourceData> expectedSourceData = MockData.getAttestationSourceData();
    when(attestationSourceDataRepository.findAllByAttestation_AttestationId(anyInt()))
        .thenReturn(expectedSourceData);

    List<SourceData> actualSourceData =
        attestationService.getAttestationSourceDataByAttestationId(1L);
    assertEquals(expectedSourceData.size(), actualSourceData.size());
    assertEquals(
        (int) expectedSourceData.get(0).getAttestationSourceType().getAttestationSourceTypeId(),
        actualSourceData.get(0).getTypeId());
    assertEquals(expectedSourceData.get(0).getAttestationSourceType().getCode(),
        actualSourceData.get(0).getCode());
    assertEquals(expectedSourceData.get(0).getDataName(), actualSourceData.get(0).getName());
    assertEquals(expectedSourceData.get(0).getReportId(), actualSourceData.get(0).getReportId());
    assertEquals(expectedSourceData.get(0).getReportVersionId(),
        actualSourceData.get(0).getReportVersionId());
    assertFalse(actualSourceData.get(0).getOther());
  }

  @Test
  void testGetAttestationFirmByStageByPagination_whenPageNoAndPageSizeIsNull() {
    Page<AttestationFirm> mockedPage = MockData.getAttestationFirmPage();
    when(attestationFirmRepository.findAll(any(Specification.class), any(Pageable.class)))
        .thenReturn(mockedPage);

    User user = MockData.getUser();

    AttestationFirmByStageResponse result = attestationService
        .getAttestationFirmByStageByPagination(AttestationConstants.ATTESTATION_FIRM_STAGING, 1,
            "firm1", user, null, null);

    assertNotNull(result);
    assertEquals(50, result.getTotalCount());
    assertEquals(11, result.getNumberOfPages());
    assertEquals(1, result.getData().size());
  }

  @Test
  void testCreateAttestation_whenNewAttestation_shouldReturnResponse() {
    CreateAttestationRequest request = MockData.getCreateAttestationRequest();

    Firm firm1 = new Firm();
    firm1.setFirmEntityId(1L);
    Firm firm2 = new Firm();
    firm2.setFirmEntityId(2L);
    when(firmRepository.findAllByFirmIdIn(any())).thenReturn(List.of(firm1, firm2));

    AttestationSourceType sourceType = new AttestationSourceType();
    sourceType.setAttestationSourceTypeId(1L);
    sourceType.setCode(AttestationConstants.SZ_SOURCE_TYPE_CODE);
    when(attestationSourceTypeRepository.findAllByAttestationSourceTypeIdIn(any()))
        .thenReturn(List.of(sourceType));

    long expectedAttestationId = 123L;
    Attestation attestation = new Attestation();
    attestation.setAttestationId(expectedAttestationId);
    when(attestationRepository.save(any())).thenReturn(attestation);

    CreateAttestationResponse response =
        attestationService.createAttestation(request, "user");
    assertEquals((int) expectedAttestationId, response.getAttestationId());
  }

  @Test
  void testCreateAttestation_whenRegeneratePublished_shouldReturnResponse() {
    long expectedAttestationId = 123L;

    CreateAttestationRequest request = MockData.getCreateAttestationRequest();
    request.setAttestationId((int) expectedAttestationId);

    AttestationSourceType sourceType = new AttestationSourceType();
    sourceType.setAttestationSourceTypeId(1L);
    sourceType.setCode(AttestationConstants.SZ_SOURCE_TYPE_CODE);
    when(attestationSourceTypeRepository.findAllByAttestationSourceTypeIdIn(any()))
        .thenReturn(List.of(sourceType));

    Attestation attestation = new Attestation();
    attestation.setAttestationId(expectedAttestationId);
    attestation.setAttestationStatusType(AttestationStatusType.PUBLISHED);
    when(attestationRepository.findById(any())).thenReturn(Optional.of(attestation));

    CreateAttestationResponse response =
        attestationService.createAttestation(request, "user");
    assertEquals((int) expectedAttestationId, response.getAttestationId());
    verify(attestationRepository, never()).save(any());
    verify(attestationSourceDataRepository, times(1))
        .deleteAllByAttestation_AttestationId(anyLong());
    verify(attestationFirmFileRepository, times(1))
        .deleteAllByAttestationFirmStaging_Attestation_AttestationId(anyLong());
    verify(attestationFirmFileRepository, times(1))
        .deleteAllByAttestationFirmPublished_Attestation_AttestationId(anyLong());
    verify(attestationFirmHistoryRepository, times(1))
        .deleteAllByAttestation_AttestationId(anyLong());
    verify(attestationFirmStagingRepository, times(1))
        .deleteAllByAttestation_AttestationId(anyLong());
    verify(attestationFirmPublishedRepository, times(1))
        .deleteAllByAttestation_AttestationId(anyLong());
  }

  @Test
  void testCreateAttestation_whenRegenerateStaging_shouldReturnResponse() {
    long expectedAttestationId = 123L;

    CreateAttestationRequest request = MockData.getCreateAttestationRequest();
    request.setAttestationId((int) expectedAttestationId);

    AttestationSourceType sourceType = new AttestationSourceType();
    sourceType.setAttestationSourceTypeId(1L);
    sourceType.setCode(AttestationConstants.SZ_SOURCE_TYPE_CODE);
    when(attestationSourceTypeRepository.findAllByAttestationSourceTypeIdIn(any()))
        .thenReturn(List.of(sourceType));

    Attestation attestation = new Attestation();
    attestation.setAttestationId(expectedAttestationId);
    attestation.setAttestationStatusType(AttestationStatusType.PENDING);
    when(attestationRepository.findById(any())).thenReturn(Optional.of(attestation));

    CreateAttestationResponse response =
        attestationService.createAttestation(request, "user");
    assertEquals((int) expectedAttestationId, response.getAttestationId());
    verify(attestationRepository, never()).save(any());
  }

  @Test
  void testCreateAttestation_whenNotFound_shouldThrowException() {
    CreateAttestationRequest request = MockData.getCreateAttestationRequest();
    request.setAttestationId(123);

    when(attestationRepository.findById(any())).thenReturn(Optional.empty());

    assertThrows(FumNotFoundException.class, () ->
        attestationService.createAttestation(request, "user"));
  }

  @Test
  void testGetFirmsByFirmIds_whenEmptyList_shouldReturnAllFirms() {
    when(firmRepository.findAll()).thenReturn(List.of(new Firm()));
    List<Firm> firms = attestationService.getFirmsByFirmIds(new ArrayList<>());
    assertNotNull(firms);
  }

  @Test
  void testGetFirmsByFirmIds_whenFirmsMissing_shouldThrowException() {
    when(firmRepository.findAllByFirmIdIn(any())).thenReturn(List.of(new Firm()));
    assertThrows(FumValidationException.class, () ->
        attestationService.getFirmsByFirmIds(List.of("NBIN", "WATER")));
  }

  @Test
  void testGetAttestationSourceTypesFromSourceData_valid_shouldReturnEntity() {
    when(attestationSourceTypeRepository.findAllByAttestationSourceTypeIdIn(any()))
        .thenReturn(MockData.getAttestationSourceType());
    var result = attestationService.getAttestationSourceTypesFromSourceData(
        MockData.getSourceData());
    assertNotNull(result);
  }

  @Test
  void testGetAttestationSourceTypesFromSourceData_missingSz_shouldThrowException() {
    List<AttestationSourceType> sourceTypes = MockData.getAttestationSourceType();
    sourceTypes.get(0).setCode("other");
    when(attestationSourceTypeRepository.findAllByAttestationSourceTypeIdIn(any()))
        .thenReturn(sourceTypes);
    assertThrows(FumValidationException.class, () ->
        attestationService.getAttestationSourceTypesFromSourceData(MockData.getSourceData()));
  }

  @Test
  void testGetAttestationSourceTypesFromSourceData_notFound_shouldThrowException() {
    when(attestationSourceTypeRepository.findAllByAttestationSourceTypeIdIn(any()))
        .thenReturn(List.of());
    assertThrows(FumValidationException.class, () ->
        attestationService.getAttestationSourceTypesFromSourceData(MockData.getSourceData()));
  }

  @Test
  void testCallUserManagementEtl_whenValid_shouldNotThrowException() {
    when(systemTokenFactory.getBearerToken(AttestationConstants.SYSTEM_TOKEN_FUM))
        .thenReturn("Bearer token");
    when(userManagementClient.generateAttestation(any(), any()))
        .thenReturn(ResponseEntity.ok().build());

    assertDoesNotThrow(() -> attestationService.callUserManagementEtl(1));
  }

  @Test
  void testCallUserManagementEtl_whenInvalid_shouldThrowException() {
    when(systemTokenFactory.getBearerToken(AttestationConstants.SYSTEM_TOKEN_FUM))
        .thenReturn("Bearer token");
    when(userManagementClient.generateAttestation(any(), any()))
        .thenReturn(ResponseEntity.internalServerError().build());
    assertThrows(FumServiceException.class, () ->
        attestationService.callUserManagementEtl(1));
  }

  @Test
  void testGetAttestationSourceFiles_whenReportingApiReturnsFiles() throws Exception {
    AttestationSourceType otherSourceType = new AttestationSourceType();
    otherSourceType.setCode(AttestationConstants.OTHER_SOURCE_TYPE_CODE);
    otherSourceType.setParams("{\"s3SubPrefix\":\"prefix\"}");
    AttestationSourceType compassSourceType = new AttestationSourceType();
    compassSourceType.setCode("compass");
    List<AttestationSourceType> sourceTypes =
        new ArrayList<>(MockData.getAttestationSourceType());
    sourceTypes.add(otherSourceType);
    sourceTypes.add(compassSourceType);
    when(attestationSourceTypeRepository.findAllByActive(anyBoolean())).thenReturn(sourceTypes);

    ReportRequestAdditionalCriteria additionalCriteria = new ReportRequestAdditionalCriteria();
    additionalCriteria.setS3SubPrefix("prefix");
    when(objectMapper.readValue(anyString(), eq(ReportRequestAdditionalCriteria.class)))
        .thenReturn(additionalCriteria);

    S3Details s3Details = new S3Details();
    s3Details.setS3Uri("uri");
    s3Details.setVersionId("v1");
    s3Details.setLastUpdated(LocalDateTime.now());
    when(systemTokenFactory.getBearerToken(anyString())).thenReturn("Bearer token");
    when(reportApiClient.getS3Details(anyString(), any()))
        .thenReturn(ResponseEntity.ok(List.of(s3Details)));

    List<SourceData> result = attestationService.getAttestationSourceFiles();
    assertNotNull(result);
    assertEquals(sourceTypes.size() + 1, result.size());
  }

  @Test
  void testGetAttestationSourceFiles_whenReportingApiReturnsEmpty() throws Exception {
    AttestationSourceType otherSourceType = new AttestationSourceType();
    otherSourceType.setCode(AttestationConstants.OTHER_SOURCE_TYPE_CODE);
    otherSourceType.setParams("{\"s3SubPrefix\":\"prefix\"}");
    List<AttestationSourceType> sourceTypes =
        new ArrayList<>(MockData.getAttestationSourceType());
    sourceTypes.add(otherSourceType);
    when(attestationSourceTypeRepository.findAllByActive(anyBoolean())).thenReturn(sourceTypes);

    ReportRequestAdditionalCriteria additionalCriteria = new ReportRequestAdditionalCriteria();
    additionalCriteria.setS3SubPrefix("prefix");
    when(objectMapper.readValue(anyString(), eq(ReportRequestAdditionalCriteria.class)))
        .thenReturn(additionalCriteria);

    when(systemTokenFactory.getBearerToken(anyString())).thenReturn("Bearer token");
    when(reportApiClient.getS3Details(anyString(), any()))
        .thenReturn(ResponseEntity.ok(null));

    List<SourceData> result = attestationService.getAttestationSourceFiles();
    assertNotNull(result);
    assertEquals(sourceTypes.size(), result.size());
  }

  @Test
  void testGetFilesByFileId_shouldReturnFileNameAndResource() {
    Long fileId = 1L;
    User user = new User();
    user.setFirmId("firm1");

    AttestationFirmFile attestationFirmFile = new AttestationFirmFile();
    attestationFirmFile.setReportId("s3://bucket/path/to/file.txt");
    attestationFirmFile.setReportVersionId("v1");
    AttestationFirmPublished published = new AttestationFirmPublished();
    Firm firm = new Firm();
    firm.setFirmId("firm1");
    published.setFirm(firm);
    attestationFirmFile.setAttestationFirmPublished(published);

    ByteArrayResource resource = new ByteArrayResource("test content".getBytes());

    when(attestationFirmFileRepository.findById(fileId))
        .thenReturn(Optional.of(attestationFirmFile));
    when(systemTokenFactory.getBearerToken(anyString())).thenReturn("Bearer token");
    when(reportApiClient.download(anyString(), any()))
        .thenReturn(ResponseEntity.ok(resource));

    Pair<String, ByteArrayResource> result = attestationService.getFilesByFileId(user, fileId);

    assertEquals("file.txt", result.getLeft());
    assertEquals(resource, result.getRight());
  }

  @Test
  void testGetFilesByFileId_shouldThrowExceptionWhenFileNotFound() {
    Long fileId = 99L;
    User user = new User();
    user.setFirmId("firm1");

    when(attestationFirmFileRepository.findById(fileId)).thenReturn(Optional.empty());

    assertThrows(FumNotFoundException.class, () ->
        attestationService.getFilesByFileId(user, fileId));
  }

  @Test
  void testGetFilesByFileId_shouldThrowExceptionWhenFileIsNotPresent() {
    Long fileId = 1L;
    User user = new User();
    user.setFirmId("firm1");

    AttestationFirmFile attestationFirmFile = new AttestationFirmFile();
    attestationFirmFile.setReportId("s3://bucket/path/to/file.txt");
    attestationFirmFile.setReportVersionId("v1");
    AttestationFirmStaging staging = new AttestationFirmStaging();
    Firm firm = new Firm();
    firm.setFirmId("firm1");
    staging.setFirm(firm);
    attestationFirmFile.setAttestationFirmStaging(staging);

    when(attestationFirmFileRepository.findById(fileId)).thenReturn(Optional.of(attestationFirmFile));
    when(systemTokenFactory.getBearerToken(anyString())).thenReturn("Bearer token");
    when(reportApiClient.download(anyString(), any())).thenReturn(ResponseEntity.of(Optional.empty()));

    assertThrows(FumServiceException.class, () -> attestationService.getFilesByFileId(user, fileId));
  }

  @Test
  void testUpdateAttestationByAttestationId_whenNotFound_shouldThrowException() {
    when(attestationRepository.findById(anyLong())).thenReturn(Optional.empty());
    assertThrows(FumNotFoundException.class, () ->
        attestationService.updateAttestationByAttestationId(1L,
            new UpdateAttestationRequest(), new User()));
  }

  @Test
  void testUpdateAttestationByAttestationId_whenPublish_shouldPublish() {
    when(attestationRepository.findById(anyLong()))
        .thenReturn(Optional.of(MockData.getAttestations().get(0)));
    when(attestationFirmStagingRepository.findAllByAttestation_AttestationId(anyLong()))
        .thenReturn(MockData.getAttestationFirmStagingEntities());
    when(attestationFirmPublishedRepository.saveAll(any()))
        .thenReturn(MockData.getAttestationFirmPublishedEntities());
    when(attestationFirmFileRepository.findAllByAttestationFirmStagingIn(any()))
        .thenReturn(List.of(MockData.getAttestationFirmFileEntity()));

    UpdateAttestationRequest request = new UpdateAttestationRequest();
    request.setAction(ActionEnum.PUBLISH);
    attestationService.updateAttestationByAttestationId(1L, request, MockData.getUser());

    verify(attestationFirmFileRepository, times(1)).saveAll(any());
    verify(attestationFirmStagingRepository, times(1)).deleteAll(any());
  }

  @Test
  void testUpdateAttestationByAttestationId_whenCancel_shouldCancel() {
    when(attestationRepository.findById(anyLong()))
        .thenReturn(Optional.of(MockData.getAttestations().get(0)));
    when(attestationFirmPublishedRepository.findAllByAttestation_AttestationId(anyLong()))
        .thenReturn(MockData.getAttestationFirmPublishedEntities());
    when(attestationFirmPublishedRepository.findById(any()))
        .thenReturn(Optional.ofNullable(MockData.getAttestationFirmPublishedEntities().get(0)));

    UpdateAttestationRequest request = new UpdateAttestationRequest();
    request.setAction(ActionEnum.CANCEL);
    attestationService.updateAttestationByAttestationId(1L, request, MockData.getUser());

    verify(attestationFirmPublishedRepository, times(1)).save(any());
  }

  @Test
  void testGetFirmAttestationFiles_whenValidParams_shouldReturnFiles() {
    AttestationFirmFile file = new AttestationFirmFile();
    file.setAttestationFirmStaging(new AttestationFirmStaging());
    file.getAttestationFirmStaging().setAttestation(new Attestation());
    file.getAttestationFirmStaging().getAttestation().setAttestationId(1L);
    file.getAttestationFirmStaging().setFirm(new Firm());
    file.getAttestationFirmStaging().getFirm().setFirmId("NBIN");
    file.setReportId("s3://bucket/file1.txt");
    file.setReportVersionId("v1");

    when(attestationFirmFileRepository.findAll(any(Specification.class), any(Sort.class)))
        .thenReturn(List.of(file));
    when(userConfigSearchMaterializedViewRepository.findAllByIdpSubjectIn(any()))
        .thenReturn(new ArrayList<>());
    when(userConfigSearchMaterializedViewRepository.findByIdpSubject(any()))
        .thenReturn(new UserConfigSearchMaterializedView());

    List<ca.bnc.wealth.common.attestation.model.AttestationFirmFile> result =
        attestationService.getFirmAttestationFiles(1, "STAGING", "idpSubject");
    assertNotNull(result);
    assertEquals(1, result.size());
  }

  @Test
  void testGetFirmAttestationFiles_whenInvalidParams_shouldReturnEmpty() {
    List<ca.bnc.wealth.common.attestation.model.AttestationFirmFile> result =
        attestationService.getFirmAttestationFiles(1, "invalid", "idpSubject");
    assertNotNull(result);
    assertEquals(0, result.size());
  }

  @Test
  void testGetAttestationById_shouldReturnDetails() {
    Attestation attestation = MockData.getAttestations().get(0);
    when(attestationRepository.findById(anyLong())).thenReturn(Optional.of(attestation));

    AttestationLabelDetails result = attestationService.getAttestationById(1L);
    assertNotNull(result);
    assertEquals(attestation.getLabel(), result.getLabel());
  }

  @Test
  void testGetAttestationById_whenNotFound_shouldThrowException() {
    when(attestationRepository.findById(anyLong())).thenReturn(Optional.empty());
    assertThrows(FumNotFoundException.class, () ->
        attestationService.getAttestationById(1L));
  }

  @Test
  void testDeleteAttestation_shouldDeleteDependenciesAndAttestation() {
    User nbinUser = new User();
    nbinUser.setFirmId(AttestationConstants.NBIN);
    nbinUser.setIdpSubject("nbinAdmin");

    attestationService.deleteAttestation(1L, nbinUser);
    verify(attestationRepository, times(1)).deleteById(1L);
    verify(attestationSourceDataRepository, times(1))
        .deleteAllByAttestation_AttestationId(1L);
  }

  // ── patchFirmAttestation ──

  @Test
  void testPatchFirmAttestation_acknowledge_shouldComplete() {
    User user = MockData.getUser();
    Long firmAttestationId = 1L;

    AttestationFirmPublished published = MockData.getAttestationFirmPublishedEntities().get(0);
    published.setFirm(new Firm());
    published.getFirm().setFirmId(user.getFirmId());

    when(attestationFirmPublishedRepository.findById(firmAttestationId))
        .thenReturn(Optional.of(published));
    when(attestationFirmPublishedRepository.save(any())).thenReturn(published);

    FirmAttestationPatchRequest request = new FirmAttestationPatchRequest();
    request.setAction(FirmAttestationPatchRequest.ActionEnum.ACKNOWLEDGE);

    AttestationFirmByStage result =
        attestationService.patchFirmAttestation(firmAttestationId, request, user);
    assertNotNull(result);
    verify(attestationFirmPublishedRepository, times(1)).save(any());
  }

  @Test
  void testPatchFirmAttestation_cancel_shouldCancel() {
    User nbinUser = new User();
    nbinUser.setFirmId(AttestationConstants.NBIN);
    nbinUser.setIdpSubject("nbinAdmin");
    Long firmAttestationId = 1L;

    AttestationFirmPublished published = MockData.getAttestationFirmPublishedEntities().get(0);
    when(attestationFirmPublishedRepository.findById(firmAttestationId))
        .thenReturn(Optional.of(published));
    when(attestationFirmPublishedRepository.save(any())).thenReturn(published);

    FirmAttestationPatchRequest request = new FirmAttestationPatchRequest();
    request.setAction(FirmAttestationPatchRequest.ActionEnum.CANCEL);

    AttestationFirmByStage result =
        attestationService.patchFirmAttestation(firmAttestationId, request, nbinUser);
    assertNotNull(result);
    verify(attestationFirmPublishedRepository).save(any());
  }

  @Test
  void testPatchFirmAttestation_acknowledge_notFound_shouldThrow() {
    User user = MockData.getUser();
    Long firmAttestationId = 999L;

    when(attestationFirmPublishedRepository.findById(firmAttestationId))
        .thenReturn(Optional.empty());

    FirmAttestationPatchRequest request = new FirmAttestationPatchRequest();
    request.setAction(FirmAttestationPatchRequest.ActionEnum.ACKNOWLEDGE);

    assertThrows(FumNotFoundException.class, () ->
        attestationService.patchFirmAttestation(firmAttestationId, request, user));
  }

  @Test
  void testPatchFirmAttestation_cancel_notFound_shouldThrow() {
    User nbinUser = new User();
    nbinUser.setFirmId(AttestationConstants.NBIN);
    nbinUser.setIdpSubject("nbinAdmin");
    Long firmAttestationId = 999L;

    when(attestationFirmPublishedRepository.findById(firmAttestationId))
        .thenReturn(Optional.empty());

    FirmAttestationPatchRequest request = new FirmAttestationPatchRequest();
    request.setAction(FirmAttestationPatchRequest.ActionEnum.CANCEL);

    assertThrows(FumNotFoundException.class, () ->
        attestationService.patchFirmAttestation(firmAttestationId, request, nbinUser));
  }

  // ── deleteFirmAttestation ──

  @Test
  void testDeleteFirmAttestation_success_shouldDelete() {
    User nbinUser = new User();
    nbinUser.setFirmId(AttestationConstants.NBIN);
    nbinUser.setIdpSubject("nbinAdmin");
    Long firmAttestationId = 1L;

    AttestationFirmStaging staging = MockData.getAttestationFirmStagingEntities().get(0);
    staging.getFirm().setFirmId(AttestationConstants.NBIN);
    when(attestationFirmStagingRepository.findById(firmAttestationId))
        .thenReturn(Optional.of(staging));

    attestationService.deleteFirmAttestation(firmAttestationId, nbinUser);

    verify(attestationFirmFileRepository, times(1))
        .deleteByAttestationFirmStaging(staging);
    verify(attestationFirmStagingRepository, times(1)).delete(staging);
  }

  @Test
  void testDeleteFirmAttestation_notFound_shouldThrow() {
    User nbinUser = new User();
    nbinUser.setFirmId(AttestationConstants.NBIN);
    nbinUser.setIdpSubject("nbinAdmin");
    Long firmAttestationId = 999L;

    when(attestationFirmStagingRepository.findById(firmAttestationId))
        .thenReturn(Optional.empty());

    assertThrows(FumNotFoundException.class, () ->
        attestationService.deleteFirmAttestation(firmAttestationId, nbinUser));
  }

  @Test
  void testDeleteFirmAttestation_wrongFirm_shouldThrow() {
    User nonNbinUser = new User();
    nonNbinUser.setFirmId("ACAD");
    nonNbinUser.setIdpSubject("acadUser");
    Long firmAttestationId = 1L;

    AttestationFirmStaging staging = MockData.getAttestationFirmByStaging(1);
    staging.getFirm().setFirmId("OTHER");
    when(attestationFirmStagingRepository.findById(firmAttestationId))
        .thenReturn(Optional.of(staging));

    assertThrows(FumNotFoundException.class, () ->
        attestationService.deleteFirmAttestation(firmAttestationId, nonNbinUser));
  }

  // ── validateUserFirmAccess ──

  @Test
  void testValidateUserFirmAccess_nbinUser_withNullFirmId_returnsNull() {
    User nbinUser = new User();
    nbinUser.setFirmId(AttestationConstants.NBIN);

    String result = attestationService.validateUserFirmAccess(null, nbinUser);
    assertNull(result);
  }

  @Test
  void testValidateUserFirmAccess_nbinUser_withNbinFirmId_returnsNull() {
    User nbinUser = new User();
    nbinUser.setFirmId(AttestationConstants.NBIN);

    String result = attestationService.validateUserFirmAccess(AttestationConstants.NBIN, nbinUser);
    assertNull(result);
  }

  @Test
  void testValidateUserFirmAccess_nbinUser_withOtherFirmId_returnsFirmId() {
    User nbinUser = new User();
    nbinUser.setFirmId(AttestationConstants.NBIN);

    String result = attestationService.validateUserFirmAccess("ACAD", nbinUser);
    assertEquals("ACAD", result);
  }

  @Test
  void testValidateUserFirmAccess_nonNbinUser_withNullFirmId_returnsOwnFirm() {
    User user = new User();
    user.setFirmId("ACAD");

    String result = attestationService.validateUserFirmAccess(null, user);
    assertEquals("ACAD", result);
  }

  @Test
  void testValidateUserFirmAccess_nonNbinUser_withOwnFirmId_returnsFirmId() {
    User user = new User();
    user.setFirmId("ACAD");

    String result = attestationService.validateUserFirmAccess("ACAD", user);
    assertEquals("ACAD", result);
  }

  @Test
  void testValidateUserFirmAccess_nonNbinUser_withDifferentFirmId_shouldThrow() {
    User user = new User();
    user.setFirmId("ACAD");

    assertThrows(FumNotFoundException.class, () ->
        attestationService.validateUserFirmAccess("OTHER", user));
  }

  // ── getAttestationById with staging attestation ──

  @Test
  void testGetAttestationById_withStagingAttestation_shouldReturnDetails() {
    Attestation attestation = MockData.getAttestations().get(0);
    attestation.setAttestationStatusType(AttestationStatusType.PENDING);
    when(attestationRepository.findById(anyLong())).thenReturn(Optional.of(attestation));
    when(attestationFirmStagingRepository.findAllByAttestation_AttestationId(anyLong()))
        .thenReturn(MockData.getAttestationFirmStagingEntities());

    AttestationLabelDetails result = attestationService.getAttestationById(1L);
    assertNotNull(result);
    assertNotNull(result.getFirms());
    assertFalse(result.getFirms().isEmpty());
  }

  @SneakyThrows
  @Test
  void testGetS3Details_whenUnableToParseS3File_shouldThrowException() {
    when(objectMapper.readValue(anyString(), (Class<Object>) any())).thenThrow(new RuntimeException());
    assertThrows(FumServiceException.class, () -> attestationService.getS3Details("params", "startsWith"));
  }
}
