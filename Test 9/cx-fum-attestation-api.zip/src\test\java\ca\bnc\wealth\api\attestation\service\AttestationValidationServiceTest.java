package ca.bnc.wealth.api.attestation.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

import ca.bnc.wealth.common.attestation.model.CreateAttestationRequest;
import ca.bnc.wealth.common.attestation.model.FirmAttestationPatchRequest;
import ca.bnc.wealth.common.attestation.model.SourceData;
import ca.bnc.wealth.common.attestation.model.UpdateAttestationRequest;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AttestationValidationServiceTest {

  private AttestationValidationService attestationValidationService;

  @BeforeEach
  void setUp() {
    attestationValidationService = new AttestationValidationService();
  }

  // ── validateCreateAttestationRequest ──

  @Test
  void testValidateCreateAttestationRequest_withValidRequest_doesNotThrow() {
    CreateAttestationRequest request = new CreateAttestationRequest();
    request.setLabel("JUN2024");
    request.setFirms(List.of("NBIN"));
    request.setSource(List.of(new SourceData()));
    assertDoesNotThrow(() ->
        attestationValidationService.validateCreateAttestationRequest(request));
  }

  @Test
  void testValidateCreateAttestationRequest_withNullRequest_shouldThrow() {
    assertThrows(FumValidationException.class, () ->
        attestationValidationService.validateCreateAttestationRequest(null));
  }

  @Test
  void testValidateCreateAttestationRequest_withNullLabel_shouldThrow() {
    CreateAttestationRequest request = new CreateAttestationRequest();
    request.setLabel(null);
    request.setFirms(List.of("NBIN"));
    request.setSource(List.of(new SourceData()));
    assertThrows(FumValidationException.class, () ->
        attestationValidationService.validateCreateAttestationRequest(request));
  }

  @Test
  void testValidateCreateAttestationRequest_withEmptyLabel_shouldThrow() {
    CreateAttestationRequest request = new CreateAttestationRequest();
    request.setLabel("");
    request.setFirms(List.of("NBIN"));
    request.setSource(List.of(new SourceData()));
    assertThrows(FumValidationException.class, () ->
        attestationValidationService.validateCreateAttestationRequest(request));
  }

  @Test
  void testValidateCreateAttestationRequest_withNullFirms_shouldThrow() {
    CreateAttestationRequest request = new CreateAttestationRequest();
    request.setLabel("JUN2024");
    request.setFirms(null);
    request.setSource(List.of(new SourceData()));
    assertThrows(FumValidationException.class, () ->
        attestationValidationService.validateCreateAttestationRequest(request));
  }

  @Test
  void testValidateCreateAttestationRequest_withEmptySource_shouldThrow() {
    CreateAttestationRequest request = new CreateAttestationRequest();
    request.setLabel("JUN2024");
    request.setFirms(List.of("NBIN"));
    request.setSource(List.of());
    assertThrows(FumValidationException.class, () ->
        attestationValidationService.validateCreateAttestationRequest(request));
  }

  @Test
  void testValidateCreateAttestationRequest_withNullSource_shouldThrow() {
    CreateAttestationRequest request = new CreateAttestationRequest();
    request.setLabel("JUN2024");
    request.setFirms(List.of("NBIN"));
    request.setSource(null);
    assertThrows(FumValidationException.class, () ->
        attestationValidationService.validateCreateAttestationRequest(request));
  }

  // ── validatePatchFirmAttestationRequest ──

  @Test
  void testValidatePatchFirmAttestationRequest_withAcknowledgeAction_doesNotThrow() {
    FirmAttestationPatchRequest request = new FirmAttestationPatchRequest();
    request.setAction(FirmAttestationPatchRequest.ActionEnum.ACKNOWLEDGE);
    assertDoesNotThrow(() ->
        attestationValidationService.validatePatchFirmAttestationRequest(request));
  }

  @Test
  void testValidatePatchFirmAttestationRequest_withCancelAction_doesNotThrow() {
    FirmAttestationPatchRequest request = new FirmAttestationPatchRequest();
    request.setAction(FirmAttestationPatchRequest.ActionEnum.CANCEL);
    assertDoesNotThrow(() ->
        attestationValidationService.validatePatchFirmAttestationRequest(request));
  }

  @Test
  void testValidatePatchFirmAttestationRequest_withNullRequest_shouldThrow() {
    assertThrows(FumValidationException.class, () ->
        attestationValidationService.validatePatchFirmAttestationRequest(null));
  }

  @Test
  void testValidatePatchFirmAttestationRequest_withNullAction_shouldThrow() {
    FirmAttestationPatchRequest request = new FirmAttestationPatchRequest();
    assertThrows(FumValidationException.class, () ->
        attestationValidationService.validatePatchFirmAttestationRequest(request));
  }

  // ── validateDeleteFirmAttestationRequest ──

  @Test
  void testValidateDeleteFirmAttestationRequest_withValidId_doesNotThrow() {
    assertDoesNotThrow(() ->
        attestationValidationService.validateDeleteFirmAttestationRequest(1L));
  }

  @Test
  void testValidateDeleteFirmAttestationRequest_withNullId_shouldThrow() {
    assertThrows(FumValidationException.class, () ->
        attestationValidationService.validateDeleteFirmAttestationRequest(null));
  }

  @Test
  void testValidateDeleteFirmAttestationRequest_withZeroId_shouldThrow() {
    assertThrows(FumValidationException.class, () ->
        attestationValidationService.validateDeleteFirmAttestationRequest(0L));
  }

  @Test
  void testValidateDeleteFirmAttestationRequest_withNegativeId_shouldThrow() {
    assertThrows(FumValidationException.class, () ->
        attestationValidationService.validateDeleteFirmAttestationRequest(-5L));
  }

  // ── validateUpdateAttestationRequest ──

  @Test
  void testValidateUpdateAttestationRequest_withPublishAction_doesNotThrow() {
    UpdateAttestationRequest request = new UpdateAttestationRequest();
    request.setAction(UpdateAttestationRequest.ActionEnum.PUBLISH);
    assertDoesNotThrow(() ->
        attestationValidationService.validateUpdateAttestationRequest(request));
  }

  @Test
  void testValidateUpdateAttestationRequest_withCancelAction_doesNotThrow() {
    UpdateAttestationRequest request = new UpdateAttestationRequest();
    request.setAction(UpdateAttestationRequest.ActionEnum.CANCEL);
    assertDoesNotThrow(() ->
        attestationValidationService.validateUpdateAttestationRequest(request));
  }

  @Test
  void testValidateUpdateAttestationRequest_withNullRequest_shouldThrow() {
    assertThrows(FumValidationException.class, () ->
        attestationValidationService.validateUpdateAttestationRequest(null));
  }

  @Test
  void testValidateUpdateAttestationRequest_withNullAction_shouldThrow() {
    UpdateAttestationRequest request = new UpdateAttestationRequest();
    assertThrows(FumValidationException.class, () ->
        attestationValidationService.validateUpdateAttestationRequest(request));
  }
}
