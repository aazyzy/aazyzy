package ca.bnc.wealth.api.attestation.utility;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.common.attestation.model.AttestationFirmByStage;
import ca.bnc.wealth.common.attestation.model.AttestationFirmByStageResponse;
import ca.bnc.wealth.common.attestation.model.AttestationFirmFile;
import ca.bnc.wealth.common.attestation.model.AttestationLabel;
import ca.bnc.wealth.common.attestation.model.AttestationLabelDetails;
import ca.bnc.wealth.common.attestation.model.CreateAttestationRequest;
import ca.bnc.wealth.common.attestation.model.CreateAttestationResponse;
import ca.bnc.wealth.common.attestation.model.FirmAttestationPatchRequest;
import ca.bnc.wealth.common.attestation.model.SourceData;
import ca.bnc.wealth.common.attestation.model.SourceType;
import ca.bnc.wealth.common.attestation.model.UpdateAttestationRequest;
import ca.bnc.wealth.common.jpa.entity.enums.AttestationStatusType;
import ca.bnc.wealth.common.jpa.entity.iam.Attestation;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirm;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmPublished;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmStaging;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationSourceData;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationSourceType;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;

public class MockData {

  public static final String IDP_USER_SUBJECT = "idpSubject";

  public static User getUser() {
    User user = new User();
    user.setIdpSubject(IDP_USER_SUBJECT);
    user.setFirmId("NBIN");
    return user;
  }

  // ── DTO mock data (used by controller tests) ──

  public static List<AttestationLabel> getAttestationLabels() {
    AttestationLabel attestationLabel = new AttestationLabel();
    attestationLabel.setId(1);
    attestationLabel.setLabel("JUN2024");
    attestationLabel.setCount(100);
    attestationLabel.setCreatedDate(Timestamp.from(Instant.now()).toLocalDateTime());
    attestationLabel.setPublishedDate(Timestamp.from(Instant.now()).toLocalDateTime());
    attestationLabel.setCreatedBy(IDP_USER_SUBJECT);
    attestationLabel.setPublishedBy(IDP_USER_SUBJECT);
    return List.of(attestationLabel);
  }

  public static AttestationLabelDetails getAttestationLabelDetails() {
    AttestationLabelDetails details = new AttestationLabelDetails();
    details.setId(1);
    details.setLabel("JUN2024");
    details.setCount(100);
    details.setCreatedBy(IDP_USER_SUBJECT);
    details.setFirms(List.of("ACAD", "NBIN"));
    details.setCountDetails(Map.of("ACAD", "50", "NBIN", "50"));
    return details;
  }

  public static List<SourceType> getSourceTypes() {
    SourceType sourceType = new SourceType();
    sourceType.setTypeId(1);
    sourceType.setCode("compass");
    sourceType.setLatest(true);
    return List.of(sourceType);
  }

  public static List<SourceData> getSourceData() {
    SourceData sourceData = new SourceData();
    sourceData.setTypeId(1);
    sourceData.setCode("secureZone");
    sourceData.setLatest(true);
    sourceData.setName("name");
    sourceData.setReportId("reportId");
    sourceData.setReportVersionId("reportVersionId");
    sourceData.setOther(false);
    sourceData.setUpdateDate(Timestamp.from(Instant.now()).toLocalDateTime());
    return List.of(sourceData);
  }

  public static CreateAttestationRequest getCreateAttestationRequest() {
    CreateAttestationRequest request = new CreateAttestationRequest();
    request.setLabel("JUN2024");
    request.setFirms(List.of("NBIN", "ACAD"));
    request.setSource(getSourceData());
    return request;
  }

  public static CreateAttestationResponse getCreateAttestationResponse() {
    CreateAttestationResponse response = new CreateAttestationResponse();
    response.setAttestationId(1);
    return response;
  }

  public static AttestationFirmByStageResponse getAttestationFirmByStageResponse() {
    AttestationFirmByStageResponse response = new AttestationFirmByStageResponse();
    response.setTotalCount(1);
    response.setNumberOfPages(1);
    response.setData(List.of(getAttestationFirmByStage()));
    return response;
  }

  public static AttestationFirmByStage getAttestationFirmByStage() {
    AttestationFirmByStage firmByStage = new AttestationFirmByStage();
    firmByStage.setId(1);
    firmByStage.setAttestationId(1);
    firmByStage.setLabel("JUN2024");
    firmByStage.setStage("STAGING");
    firmByStage.setFirmId("NBIN");
    firmByStage.setFirmName("Test Firm");
    firmByStage.setStatus("DRAFT");
    firmByStage.setCount(100);
    firmByStage.setCreatedBy(IDP_USER_SUBJECT);
    firmByStage.setCreatedDate(Timestamp.from(Instant.now()).toLocalDateTime());
    return firmByStage;
  }

  public static FirmAttestationPatchRequest getPatchRequest() {
    FirmAttestationPatchRequest request = new FirmAttestationPatchRequest();
    request.setAction(FirmAttestationPatchRequest.ActionEnum.ACKNOWLEDGE);
    return request;
  }

  public static UpdateAttestationRequest getUpdateAttestationRequest() {
    UpdateAttestationRequest request = new UpdateAttestationRequest();
    request.setAction(UpdateAttestationRequest.ActionEnum.PUBLISH);
    return request;
  }

  public static List<AttestationFirmFile> getAttestationFirmFiles() {
    AttestationFirmFile file = new AttestationFirmFile();
    file.setAttestationFileId(1);
    file.setAttestationFirmId(1);
    file.setReportId("s3://bucket/path/file.csv");
    file.setReportVersionId("v1");
    file.setStage("STAGING");
    file.setGenerated(true);
    file.setRecordCount(1500);
    file.setCreatedBy(IDP_USER_SUBJECT);
    file.setCreatedDate(Timestamp.from(Instant.now()).toLocalDateTime());
    return List.of(file);
  }

  // ── Entity mock data (used by service tests) ──

  public static List<Attestation> getAttestations() {
    Attestation attestation = new Attestation();
    attestation.setAttestationId(1);
    attestation.setLabel("label");
    attestation.setCount(100);
    attestation.setCreatedDate(Timestamp.from(Instant.now()));
    attestation.setUpdatedDate(Timestamp.from(Instant.now()));
    attestation.setPublishedDate(Timestamp.from(Instant.now()));
    attestation.setCreatedBy(IDP_USER_SUBJECT);
    attestation.setUpdatedBy(IDP_USER_SUBJECT);
    attestation.setPublishedBy("Joe Doe");
    attestation.setAttestationStatusType(AttestationStatusType.PUBLISHED);
    IamUserConfiguration publishedByName = new IamUserConfiguration();
    publishedByName.setUserConfigurationId(123L);
    publishedByName.setFirstName("Joe");
    publishedByName.setLastName("Doe");
    attestation.setPublishedByName(publishedByName);
    return List.of(attestation);
  }

  public static List<AttestationSourceType> getAttestationSourceType() {
    AttestationSourceType attestationSourceType = new AttestationSourceType();
    attestationSourceType.setAttestationSourceTypeId(1);
    attestationSourceType.setName("name");
    attestationSourceType.setCode("secureZone");
    attestationSourceType.setParams("params");
    attestationSourceType.setActive(true);
    attestationSourceType.setLatest(true);
    attestationSourceType.setCreatedBy("createdBy");
    attestationSourceType.setCreatedDate(Timestamp.from(Instant.now()));
    attestationSourceType.setUpdatedBy("updatedBy");
    attestationSourceType.setUpdatedDate(Timestamp.from(Instant.now()));
    return List.of(attestationSourceType);
  }

  public static List<AttestationSourceData> getAttestationSourceData() {
    AttestationSourceData attestationSourceData = new AttestationSourceData();
    attestationSourceData.setAttestationSourceType(getAttestationSourceType().get(0));
    attestationSourceData.setAttestation(new Attestation());
    attestationSourceData.setDataName("name");
    attestationSourceData.setReportId("reportId");
    attestationSourceData.setReportVersionId("reportVersionId");
    attestationSourceData.setCreatedDate(Timestamp.from(Instant.now()));
    attestationSourceData.setUpdatedDate(Timestamp.from(Instant.now()));
    return List.of(attestationSourceData);
  }

  public static List<AttestationFirmStaging> getAttestationFirmStagingEntities() {
    return List.of(getAttestationFirmByStaging(1));
  }

  public static AttestationFirmStaging getAttestationFirmByStaging(Integer serialNumber) {
    AttestationFirmStaging attestationFirmStaging = new AttestationFirmStaging();
    attestationFirmStaging.setAttestationFirmStagingId(serialNumber);
    attestationFirmStaging.setAttestation(new Attestation());
    attestationFirmStaging.setFirm(new Firm());
    attestationFirmStaging.setAttestationStatusType(AttestationStatusType.DRAFT);
    attestationFirmStaging.setBulkUpload(new BulkUpload());
    attestationFirmStaging.setCreatedBy("creator");
    attestationFirmStaging.setCreatedDate(Timestamp.from(Instant.now()));
    attestationFirmStaging.setUpdatedBy("updater");
    attestationFirmStaging.setUpdatedDate(Timestamp.from(Instant.now()));
    attestationFirmStaging.setAttestationFirmFiles(
        Arrays.asList(getAttestationFirmFileEntity()));
    return attestationFirmStaging;
  }

  public static List<AttestationFirmPublished> getAttestationFirmPublishedEntities() {
    AttestationFirmPublished attestationFirmPublished = new AttestationFirmPublished();
    attestationFirmPublished.setAttestationFirmPublishedId(1L);
    attestationFirmPublished.setAttestation(new Attestation());
    attestationFirmPublished.setFirm(new Firm());
    attestationFirmPublished.setAttestationStatusType(AttestationStatusType.PUBLISHED);
    attestationFirmPublished.setAcknowledgedBy("acknowledger");
    attestationFirmPublished.setAcknowledgedDate(Timestamp.from(Instant.now()));
    attestationFirmPublished.setCreatedBy("creator");
    attestationFirmPublished.setCreatedDate(Timestamp.from(Instant.now()));
    attestationFirmPublished.setUpdatedBy("updater");
    attestationFirmPublished.setAttestationFirmFiles(
        Arrays.asList(getAttestationFirmFileEntity()));
    return List.of(attestationFirmPublished);
  }

  public static ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmFile getAttestationFirmFileEntity() {
    ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmFile attestationFirmFile =
        new ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmFile();
    attestationFirmFile.setAttestationFirmFileId(1L);
    attestationFirmFile.setDownloadedBy("downloader");
    attestationFirmFile.setDownloadedDate(Timestamp.from(Instant.now()));
    attestationFirmFile.setReportId("reportId");
    attestationFirmFile.setReportVersionId("reportVersionId");
    attestationFirmFile.setRecordCount(100);
    attestationFirmFile.setGenerated(true);
    attestationFirmFile.setCreatedBy("creator");
    attestationFirmFile.setCreatedDate(Timestamp.from(Instant.now()));
    attestationFirmFile.setUpdatedBy("updater");
    attestationFirmFile.setUpdatedDate(Timestamp.from(Instant.now()));
    Firm firm = new Firm();
    firm.setFirmId("WATER");
    AttestationFirmStaging attestationFirmStaging = new AttestationFirmStaging();
    attestationFirmStaging.setFirm(firm);
    attestationFirmFile.setAttestationFirmStaging(attestationFirmStaging);
    return attestationFirmFile;
  }

  @SuppressWarnings("unchecked")
  public static Page<AttestationFirm> getAttestationFirmPage() {
    AttestationFirm attestationFirm = new AttestationFirm();
    attestationFirm.setId(1L);
    attestationFirm.setAttestationFirmId(1L);
    attestationFirm.setAttestationId(1L);
    attestationFirm.setLabel("label");
    attestationFirm.setStage("DRAFT");
    attestationFirm.setFirmId("NBIN");
    attestationFirm.setFirmName("Test Firm");
    attestationFirm.setStatus(AttestationStatusType.DRAFT);
    attestationFirm.setRecordCount(100);
    attestationFirm.setCreatedByName("Joe Doe");
    attestationFirm.setCreatedDate(Timestamp.from(Instant.now()));
    attestationFirm.setAcknowledgedByName("Acknowledger Name");
    attestationFirm.setAcknowledgedDate(Timestamp.from(Instant.now()));

    Page<AttestationFirm> mockedPage = mock(Page.class);
    when(mockedPage.getContent()).thenReturn(Collections.singletonList(attestationFirm));
    when(mockedPage.getTotalElements()).thenReturn(50L);
    when(mockedPage.getTotalPages()).thenReturn(11);
    when(mockedPage.hasNext()).thenReturn(false);
    return mockedPage;
  }
}
