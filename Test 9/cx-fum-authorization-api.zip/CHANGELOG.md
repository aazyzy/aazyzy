# Changelog

## [5.0.3](https://github.com/NBC-GPMF/cx-fum-authorization-api/compare/v5.0.2...v5.0.3) (2026-11-20)


### Bug Fixes

* trigger 5.0.2 release ([7e5da90](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/7e5da9058d15de15eca2180528a2174a6cf34065))

## [5.0.2](https://github.com/NBC-GPMF/cx-fum-authorization-api/compare/v5.0.1...v5.0.2) (2026-11-20)


### Bug Fixes

* rebuild image on base image java-25-1.2.2 ([#67](https://github.com/NBC-GPMF/cx-fum-authorization-api/issues/67)) ([c96d1a5](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/c96d1a53a537b79cd6cf07e17872fec6916c1e10))

## [5.0.1](https://github.com/NBC-GPMF/cx-fum-authorization-api/compare/v5.0.0...v5.0.1) (2026-11-02)


### Miscellaneous Chores

* move to parent-pom-core 3.0.1, which fixes the Snyk findings of the 5.0.0 release: Tomcat 11.0.27, Jackson 3.2.4 and 2.22.4, Hibernate Validator 9.1.6.Final and java-jwt 4.6.2

## [5.0.0](https://github.com/NBC-GPMF/cx-fum-authorization-api/compare/v4.0.1...v5.0.0) (2026-10-29)


### Miscellaneous Chores

* align develop versions with main after the 4.0.1 release ([#46](https://github.com/NBC-GPMF/cx-fum-authorization-api/pull/46)) ([2c94954](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/2c94954e08c09350d5c4552302ceb7bb260878ac))
* move authorization-api to Spring Boot 4.1.1 in develop ([#48](https://github.com/NBC-GPMF/cx-fum-authorization-api/pull/48)) ([2c58571](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/2c585716e9657c983524129a593a2bd91a415fc2))
* skip Sonar in the release workflow on Java 25 ([#52](https://github.com/NBC-GPMF/cx-fum-authorization-api/pull/52)) ([81effbe](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/81effbe343d7e1ad41f93b5720a3e66062be6934))
* skip the SonarQube analysis for now ([#50](https://github.com/NBC-GPMF/cx-fum-authorization-api/pull/50)) ([a8cbaec](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/a8cbaec66c663e361c6456b15384c8f25cd42a8d))
* sync 6900 dependency versions to develop SNAPSHOTs ([#51](https://github.com/NBC-GPMF/cx-fum-authorization-api/pull/51)) ([0b4fe31](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/0b4fe312c6a81f5699df9c0a47eb9d716cee0ade))

## [4.0.1](https://github.com/NBC-GPMF/cx-fum-authorization-api/compare/v4.0.0...v4.0.1) (2026-10-14)


### Miscellaneous Chores

* remediate Snyk vulnerabilities on the 4.0 release line ([#42](https://github.com/NBC-GPMF/cx-fum-authorization-api/issues/42)) ([b4deaca](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/b4deaca715eba5c379939cf427dd1a62e8f6902e))

## [4.0.0](https://github.com/NBC-GPMF/cx-fum-authorization-api/compare/v3.2.0...v4.0.0) (2026-10-14)


### Miscellaneous Chores

* pin released 6900 dependency versions for release 4.0.0: commons-lib 2.1.42 (NWPI-15097), api-schemas-wealth 1.11.58 ([fdd4694](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/fdd4694b6fb5efa532850ff9a8d4d0c61845e858))

## [3.2.0](https://github.com/NBC-GPMF/cx-fum-authorization-api/compare/v3.0.0...v3.2.0) (2026-09-16)


### Bug Fixes

* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([e0745f4](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/e0745f4c7d25fcaa9c685a1ed1bde4bb3bdf7a38))
* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([0dd04ee](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/0dd04ee7bc9dc85a6a3104976384904d303abf69))


### Miscellaneous Chores

* pin released 6900 dependency versions for release 3.2.0 ([981358a](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/981358a87ec790bb8f072efaa46cb330de86b5f5))

## [3.0.0](https://github.com/NBC-GPMF/cx-fum-authorization-api/compare/v2.2.3...v3.0.0) (2026-08-19)


### Miscellaneous Chores

* release 3.0.0 ([482071f](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/482071fb5957375c32a836a17efede363ec18632))

## [2.2.3](https://github.com/NBC-GPMF/cx-fum-authorization-api/compare/v2.2.2...v2.2.3) (2026-08-19)


### Bug Fixes

* **deps:** pin at.yawk.lz4:lz4-java 1.11.1 for CVE-2026-59949 ([#19](https://github.com/NBC-GPMF/cx-fum-authorization-api/issues/19)) ([31841b3](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/31841b318afa172774584d1ee3a6f2ae278ae1d5))
* **deps:** pin at.yawk.lz4:lz4-java 1.11.1 for CVE-2026-59949 ([#20](https://github.com/NBC-GPMF/cx-fum-authorization-api/issues/20)) ([7b5fe11](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/7b5fe115b2acdc23d0ee6484dbf57b231ee4b865))
* **deps:** pin tomcat-embed 10.1.56 and logback-core 1.5.36 (Snyk HIGH) ([#14](https://github.com/NBC-GPMF/cx-fum-authorization-api/issues/14)) ([4d9a2f6](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/4d9a2f6e5b23138d212f680724cefa387f1b4752))
* **deps:** pin vulnerable transitive dependencies for Snyk remediation ([#22](https://github.com/NBC-GPMF/cx-fum-authorization-api/issues/22)) ([f4af7b5](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/f4af7b519e23a3c80588dd3c1a13255192081b12))

## [2.2.2](https://github.com/NBC-GPMF/cx-fum-authorization-api/compare/v2.2.1...v2.2.2) (2026-06-29)


### Bug Fixes

* release 2.2.1 ([4b206c5](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/4b206c502a17aaf06f11b469482ac4a715a3ef3c))

## [2.2.1](https://github.com/NBC-GPMF/cx-fum-authorization-api/compare/v2.2.0...v2.2.1) (2026-06-09)


### Bug Fixes

* first release in github ([f705aeb](https://github.com/NBC-GPMF/cx-fum-authorization-api/commit/f705aebab93d071379a4b8c26b3bf683290f29ca))
