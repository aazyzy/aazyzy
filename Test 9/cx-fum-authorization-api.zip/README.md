# Authorization API

Authorization service for role-based permissions, capabilities, resources, feature packages, and group management in CX FUM.

## Repository layout

This is a multi-module Maven project:

- `authorization`: core API implementation (controllers, services, security, Kafka integration)
- `authorization-application`: Spring Boot application entry point and executable packaging

Root artifact:

- `groupId`: `ca.nbc.gpmf.cx-fum-authorization-api`
- `artifactId`: `authorization-api`
- Java version: `17`

## What this service does

The service exposes authorization capabilities consumed by CX applications, including:

- capabilities CRUD
- roles and permissions management
- permission checks for the authenticated user
- resource and entitlement management
- user group management and role assignments
- feature package and template management
- audit event publication (Kafka)

Note: API paths are defined by the shared contract library (`ca.bnc.wealth.common:authorization-schema`) and implemented via `*Api` interfaces in controllers.

## Key components

- Controllers in `authorization/src/main/java/.../controller/`
- Business services in `authorization/src/main/java/.../service/`
- App bootstrap class in `authorization-application/src/main/java/.../application/`
- Runtime config in:
	- `authorization/src/main/resources/application.yml`
	- `authorization-application/src/main/resources/application.yml`

## Prerequisites

- JDK 17
- Maven (or use the Maven Wrapper included in this repo)
- Access to internal artifact repositories (for internal dependencies)

## Build

From repository root:

```bash
./mvnw clean verify
```

Build without tests:

```bash
./mvnw clean package -DskipTests
```

## Run locally

The executable module is `authorization-application`.

1. Create a local override file (for secrets and environment-specific values), for example:
	 - `authorization-application/src/main/resources/application-local.yml`
2. Launch with additional config location:

```bash
./mvnw -pl authorization-application spring-boot:run \
	-Dspring-boot.run.jvmArguments='-Dspring.config.additional-location=<path_to_application-local.yml>'
```

You can also run from your IDE by setting VM options:

```text
-Dspring.config.additional-location=<path_to_application-local.yml>
```

Default runtime values:

- Port: `8081`
- Context path: `/iam` (from `authorization-application` config)
- Management base path: `/manage`

## Environment variables

At minimum, local runs typically require values for:

- `KAFKA_API_KEY`
- `KAFKA_API_SECRET`
- `KAFKA_ENV`

Additional values may be required depending on your local profile and downstream connectivity.

## Testing

Run all tests:

```bash
./mvnw test
```

Run tests for a single module:

```bash
./mvnw -pl authorization test
```

## CI/CD workflows

GitHub workflows used by this repository:

- `ci.yaml`: build and test for PRs and non-main pushes
- `build-deploy.yaml`: build and deploy on `main`
- `release-trigger.yaml`: release-please trigger on releasable commits
- `staging-release.yaml`: post-release build/deploy and snapshot bump on tag pushes (`v*`)

## Security and operations notes

- Security context is required for most operations; controllers resolve the authenticated principal from Spring Security context.
- Health/info endpoints are exposed under `/manage`.
- Logging includes trace/span identifiers when present.

## Quick troubleshooting

- Build fails on dependency resolution:
	- verify access to internal Maven repositories and credentials setup.
- App starts but fails on Kafka/config:
	- verify required environment variables and local config overrides.
- 401/403 during API calls:
	- ensure a valid bearer token and required permissions/groups.