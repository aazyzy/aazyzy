package ca.bnc.wealth.api.authorization.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(
    scanBasePackages = {
      "ca.bnc.wealth.api.*",
      "ca.bnc.wealth.common.exception.*",
      "ca.bnc.wealth.common.fum.service",
      "ca.bnc.wealth.common.core.cors",
      "ca.bnc.wealth.common.health.*",
      "ca.bnc.wealth.common.bma.*",
      "ca.bnc.wealth.common.jpa.*"
    })
@EnableJpaRepositories({"ca.bnc.wealth.common.jpa.repo"})
@EntityScan(basePackages = {"ca.bnc.wealth.common.jpa.entity"})
public class Application {

  public static void main(String[] args) {
    SpringApplication.run(Application.class, args);
  }
}
