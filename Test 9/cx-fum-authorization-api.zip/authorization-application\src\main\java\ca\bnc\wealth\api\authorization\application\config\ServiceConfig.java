package ca.bnc.wealth.api.authorization.application.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {"ca.bnc.wealth.common.spring.microservice.starter.core"})
public class ServiceConfig {

}
