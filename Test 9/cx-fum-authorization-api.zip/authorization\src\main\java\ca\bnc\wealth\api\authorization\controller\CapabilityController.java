package ca.bnc.wealth.api.authorization.controller;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.service.CapabilityService;
import ca.bnc.wealth.common.authorization.api.CapabilityApi;
import ca.bnc.wealth.common.authorization.model.Capability;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class CapabilityController implements CapabilityApi {

  private final CapabilityService capabilityService;

  public CapabilityController(@Autowired CapabilityService capabilityService) {
    this.capabilityService = capabilityService;
  }


  @Override
  public ResponseEntity<List<Capability>> getCapabilities(String authorization) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getCapabilities # Start: idpSubject {} ", user.getIdpSubject());
    List<Capability> capabilities = capabilityService.getCapabilities();
    log.info("getCapabilities # End: idpSubject {} ", user.getIdpSubject());
    return new ResponseEntity<>(capabilities, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Capability> createCapability(String authorization, Capability capability) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("createCapability # Start: idpSubject {} , Capability: {}", user.getIdpSubject(), capability.getName());
    capabilityService.createCapability(user.getIdpSubject(),capability);
    log.info("createCapability # End: idpSubject {} , Capability: {}", user.getIdpSubject(), capability.getName());
    return new ResponseEntity<>(capability,HttpStatus.CREATED);
  }

  @Override
  public ResponseEntity<Void> deleteCapability(String authorization, String capability) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("deleteCapability # Start: idpSubject {} , capability Name: {}", user.getIdpSubject(),
        capability);
    capabilityService.deleteCapability(capability);
    log.info("deleteCapability # End: idpSubject {} , capability Name: {}", user.getIdpSubject(),
        capability);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);

  }


}
