package ca.bnc.wealth.api.authorization.controller;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.service.FeaturePackageService;
import ca.bnc.wealth.common.authorization.api.FeaturePackageApi;
import ca.bnc.wealth.common.authorization.model.FeaturePackageCreateResponse;
import ca.bnc.wealth.common.authorization.model.FeaturePackageRequest;
import ca.bnc.wealth.common.authorization.model.GetFeaturePackage;
import ca.bnc.wealth.common.authorization.model.UpdateFeaturePackage;
import ca.bnc.wealth.common.fum.service.FeaturePackageServiceHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class FeaturePackageController implements FeaturePackageApi {

  private final FeaturePackageService featurePackageService;

  private final FeaturePackageServiceHelper featurePackageServiceHelper;

  public FeaturePackageController(@Autowired FeaturePackageService featurePackageService,
      @Autowired FeaturePackageServiceHelper featurePackageServiceHelper) {
    this.featurePackageService = featurePackageService;
    this.featurePackageServiceHelper = featurePackageServiceHelper;
  }

  @Override
  public ResponseEntity<Void> updateFeaturePackage(
      String authorization, Integer packageId, UpdateFeaturePackage featurePackage) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info(
        "updateFeaturePackage : # Start: idpSubject: {} packageId {}, featurePackage {} ",
        user.getIdpSubject(),
        packageId,
        featurePackage);
    featurePackageServiceHelper.updateFeaturePackageStatus(user.getIdpSubject(), packageId, featurePackage.getStatus());
    log.info(
        "updateFeaturePackage : # End: issuer: {} template {}, featurePackageTemplate {} ",
        user.getIdpSubject(),
        packageId,
        featurePackage);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<GetFeaturePackage> getFeaturePackage(Integer packageId, Boolean details) {
    log.info("getFeaturePackage # Start: packageId {}, details {} ", packageId, details);
    GetFeaturePackage featurePackageOutput = featurePackageService.getFeaturePackage(packageId,
        details);
    return new ResponseEntity<>(featurePackageOutput, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<FeaturePackageCreateResponse> createFeaturePackage(FeaturePackageRequest featurePackageRequest) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    FeaturePackageCreateResponse featurePackage = featurePackageService.createFeaturePackage(featurePackageRequest, user.getIdpSubject());
    return new ResponseEntity<>(featurePackage, HttpStatus.CREATED);
  }

  @Override
  public ResponseEntity<Void> deleteFeaturePackage(String packageId) {
    featurePackageServiceHelper.deleteFeaturePackage(Integer.valueOf(packageId));
    return new ResponseEntity<>(HttpStatus.OK);

  }

  @Override
  public ResponseEntity<Void> updateFeaturePackageAssignments(Integer packageId, FeaturePackageRequest featurePackageRequest) {
    log.info("updateFeaturePackageAssignments # Start: packageId {}, featurePackageRequest {} ", packageId, featurePackageRequest);
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    featurePackageService.updateFeaturePackageAssignments(packageId, featurePackageRequest, user.getIdpSubject());
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }
}
