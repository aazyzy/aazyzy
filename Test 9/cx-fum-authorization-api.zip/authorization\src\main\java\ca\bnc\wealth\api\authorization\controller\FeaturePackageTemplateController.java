package ca.bnc.wealth.api.authorization.controller;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.service.AuditLogService;
import ca.bnc.wealth.api.authorization.service.AuthorizationServiceJpa;
import ca.bnc.wealth.api.authorization.service.FeaturePackageTemplateService;
import ca.bnc.wealth.common.authorization.api.FeaturePackageTemplateApi;
import ca.bnc.wealth.common.authorization.model.PackageTemplate;
import ca.bnc.wealth.common.authorization.model.TemplateType;
import ca.bnc.wealth.common.authorization.model.UpdateFeaturePackageTemplate;
import ca.bnc.wealth.common.authorization.model.UpdateTemplateResourceAssignment;
import ca.bnc.wealth.common.bma.service.BulkManagementApiCallBack;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class FeaturePackageTemplateController implements FeaturePackageTemplateApi {
  private final AuthorizationServiceJpa authorizationServiceJpa;

  private final FeaturePackageTemplateService featurePackageTemplateService;

  private final AuditLogService auditLogService;

  public FeaturePackageTemplateController(
      @Autowired AuthorizationServiceJpa authorizationServiceJpa,
      @Autowired FeaturePackageTemplateService featurePackageTemplateService,
      @Autowired AuditLogService auditLogService) {
    this.authorizationServiceJpa = authorizationServiceJpa;
    this.featurePackageTemplateService = featurePackageTemplateService;
    this.auditLogService = auditLogService;

  }

  @Override
  public ResponseEntity<Void> updateFeaturePackageTemplate(
      String authorization, String template, UpdateFeaturePackageTemplate featurePackageTemplate) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info(
        "updateFeaturePackageTemplate : # Start: idpSubject: {} template {}, featurePackageTemplate {} ",
        user.getIdpSubject(),
        template,
        featurePackageTemplate);
    featurePackageTemplateService.updateFeaturePackageTemplate(
        user.getIdpSubject(), template, featurePackageTemplate);
    log.info(
        "updateFeaturePackageTemplate : # End: issuer: {} template {}, featurePackageTemplate {} ",
        user.getIdpSubject(),
        template,
        featurePackageTemplate);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<PackageTemplate> createPackageTemplate(String authorization,
      PackageTemplate packageTemplate) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getFeaturePackage # Start: idpSubject: {} packageTemplate {} ", user.getIdpSubject(), packageTemplate);
    PackageTemplate createdPackageTemplate = featurePackageTemplateService.createPackageTemplate(packageTemplate);
    return new ResponseEntity<>(createdPackageTemplate, HttpStatus.CREATED);
  }

  @Override
  public  ResponseEntity<Void> deleteTemplate(String authorization, String template) {
    authorizationServiceJpa.deleteTemplate(template);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<List<PackageTemplate>> getTemplates(
      String authorization, Boolean details, TemplateType templateType, String firmType) {
    List<PackageTemplate> packageTemplates =
        authorizationServiceJpa.getTemplate(firmType, templateType, details);

    return new ResponseEntity<>(packageTemplates, HttpStatus.OK);
  }

  @Override
  @BulkManagementApiCallBack
  public ResponseEntity<Void> updateTemplateResources(String authorization, String template,
      UpdateTemplateResourceAssignment updateTemplateResourceAssignment) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("updateTemplateResources # Start: idpSubject: {}, packageTemplate: {},  update Resources: {}", user.getIdpSubject(), template, updateTemplateResourceAssignment);
    this.auditLogService.publishUpdateTemplateResourcesAuditLog(template, () -> authorizationServiceJpa.updateTemplateResourcesSynchronous(template, updateTemplateResourceAssignment,
        user.getIdpSubject()));
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }
}
