package ca.bnc.wealth.api.authorization.controller;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.service.AuthorizationServiceJpa;
import ca.bnc.wealth.common.authorization.api.GroupApi;
import ca.bnc.wealth.common.authorization.model.UserGroup;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class GroupController implements GroupApi {

  @Autowired
  private AuthorizationServiceJpa authorizationServiceJpa;

  /**
   * Get all the user groups setup in IAM.
   *
   * @param authorization JWT Bearer token passed in the request header (required)
   * @return
   */
  @Override
  public ResponseEntity<List<UserGroup>> getAllGroups(String authorization) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getAllGroups # Start: idpSubject: {}", user.getIdpSubject());
    List<UserGroup> userGroupList = new ArrayList<>(authorizationServiceJpa.getAllUserGroups());
    userGroupList.sort(
        Comparator.comparing(UserGroup::getDescription, String.CASE_INSENSITIVE_ORDER));
    return new ResponseEntity<>(userGroupList, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<List<UserGroup>> getGroupsMe(String authorization) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getAllGroups # Start: idpSubject: {}", user.getIdpSubject());
    List<UserGroup> userGroupList = new ArrayList<>(authorizationServiceJpa.getGroupsMe(user.getIdpSubject()));
    userGroupList.sort(
        Comparator.comparing(UserGroup::getDescription, String.CASE_INSENSITIVE_ORDER));
    return new ResponseEntity<>(userGroupList, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<UserGroup> createGroup(String authorization, UserGroup userGroup) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    UserGroup response = authorizationServiceJpa.createUserGroup(user.getIdpSubject(), userGroup);
    return new ResponseEntity<>(response, HttpStatus.CREATED);
  }

  @Override
  public ResponseEntity<Void> deleteUserGroup(String authorization, String userGroup) {
    authorizationServiceJpa.deleteUserGroup(userGroup);
    return new ResponseEntity<>(HttpStatus.OK);

  }

  @Override
  public ResponseEntity<UserGroup> updateUserGroup(String authorization, String groupId,
      UserGroup userGroup) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    UserGroup response = authorizationServiceJpa.updateUserGroup(user.getIdpSubject(), groupId,
        userGroup);
    return new ResponseEntity<>(response, HttpStatus.OK);

  }

  @Override
  public ResponseEntity<Void> addUserGroupAndRoleAssignment(String authorization, String userGroup,
      List<String> roles) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    authorizationServiceJpa.addUserGroupAndRoleAssignment(user.getIdpSubject(), userGroup, roles);
    return new ResponseEntity<>(HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Void> deleteUserGroupAndRoleAssignment(String authorization,
      String userGroup) {
    authorizationServiceJpa.deleteUserGroupAndRoleAssignment(userGroup);
    return new ResponseEntity<>(HttpStatus.OK);
  }
}
