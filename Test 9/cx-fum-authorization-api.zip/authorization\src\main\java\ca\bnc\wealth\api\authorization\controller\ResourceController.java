package ca.bnc.wealth.api.authorization.controller;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.util.DisablePermissionCheck;
import ca.bnc.wealth.api.authorization.service.AuthorizationServiceJpa;
import ca.bnc.wealth.common.authorization.api.ResourceApi;
import ca.bnc.wealth.common.authorization.model.ResourceData;
import ca.bnc.wealth.common.authorization.model.ResourceEntitlement;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;
import ca.bnc.wealth.api.authorization.util.AuthorizationConstants;


@Slf4j
@RestController
public class ResourceController implements ResourceApi {

  private AuthorizationServiceJpa authorizationServiceJpa;

  @Autowired
  public ResourceController(AuthorizationServiceJpa authorizationServiceJpa) {
    this.authorizationServiceJpa = authorizationServiceJpa;
  }

  /**
   * Get the list of resources the user is entitled to based on his user group and firm associations
   *
   * @param authorization JWT Bearer token passed in the request header (required)
   * @param resourceType resource-type (required)
   * @return
   */
  // @DisablePermissionCheck is intentional here: this is a self-scoping endpoint.
  // It only returns the authenticated caller's own entitlements, resolved from
  // user.getIdpSubject() in the SecurityContext, so no cross-user access is possible.
  @Override
  @DisablePermissionCheck
  public ResponseEntity<List<ResourceEntitlement>> getResourceEntitlements(
      String authorization, String resourceType) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info(
        "RESOURCE_ENTITLEMENT_QUERY: user={}, resourceType={}",
        user.getIdpSubject(),
        resourceType);
    List<ResourceEntitlement> resourceEntitlementList =
        authorizationServiceJpa.getResourceEntitlements(resourceType, user.getIdpSubject());
    return new ResponseEntity<>(resourceEntitlementList, HttpStatus.OK);
  }

  /**
   * @param resourceType resource-type (required)
   * @param resource resource (required)
   * @return
   */
  @Override
  public ResponseEntity<Void> deleteResource(
      String authorization, String resourceType, String resource) {

    authorizationServiceJpa.deleteResource(resourceType, resource);

    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  /**
   * @param authorization JWT Bearer token passed in the request header (required)
   * @param resourceType resource-type (required)
   * @param resource resource (required)
   * @param resourceData resourceData (required)
   * @return
   */
  @Override
  public ResponseEntity<Void> updateResource(
      String authorization, String resourceType, String resource, ResourceData resourceData) {

    authorizationServiceJpa.patchResource(resourceType, resource, resourceData);

    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  /**
   * @param resourceType resource-type (required)
   * @param resourceData resource (required)
   * @return resourceData
   */
  @Override
  public ResponseEntity<ResourceData> createResource(
      String authorization, String resourceType, ResourceData resourceData) {
    if(authorizationServiceJpa.checkResourceByNameAndRestriction(resourceType, resourceData)) {
      log.info( String.format(AuthorizationConstants.RESOURCE_ADD_INVALID_MESSAGE,
              resourceData.getName(), resourceData.getRestriction()));
      return new ResponseEntity<>(resourceData, HttpStatus.OK);
    }
    return new ResponseEntity<>(
        authorizationServiceJpa.createResource(
            ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
                .getIdpSubject(),
            resourceType,
            resourceData),
        HttpStatus.CREATED);
  }

  @Override
  public ResponseEntity<List<ResourceData>> getResource(String authorization, String resourceType) {
    log.info("getResource # Start:  resourceType: {}", resourceType);
    List<ResourceData> resourceDataList =
        authorizationServiceJpa.getResourceByResourceType(resourceType);
    return new ResponseEntity<>(resourceDataList, HttpStatus.OK);
  }

  /**
   * @param resourceType resource-type (required)
   * @param resource resource (required)
   * @return resourceData
   */
  @Override
  public ResponseEntity<ResourceData> getResourceByName(
      String authorization, String resourceType, String resource) {
    return new ResponseEntity<>(
        authorizationServiceJpa.getResourceByTypeAndName(resourceType, resource), HttpStatus.OK);
  }

  @Override
  public ResponseEntity<List<ResourceData>> getResourceByResourceTypeAndRrCode(
      String resourceType, String rrCode) {
    log.info(
        "getResourceByResourceTypeAndRrCode # Start:  resourceType: {}, rrCode {}",
        resourceType,
        rrCode);
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    List<ResourceData> resourceDataList =
        authorizationServiceJpa.getResourceByResourceTypeAndRrCode(resourceType, rrCode, user);
    return new ResponseEntity<>(resourceDataList, HttpStatus.OK);
  }
}
