package ca.bnc.wealth.api.authorization.controller;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.util.DisablePermissionCheck;
import ca.bnc.wealth.api.authorization.service.AuthorizationServiceJpa;
import ca.bnc.wealth.common.authorization.api.RolePermissionApi;
import ca.bnc.wealth.common.authorization.model.PermissionInfo;
import ca.bnc.wealth.common.authorization.model.Role;
import ca.bnc.wealth.common.authorization.model.TogglePermission;
import java.util.List;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class RolePermissionController implements RolePermissionApi {

  private final AuthorizationServiceJpa authorizationServiceJpa;

  @Autowired
  public RolePermissionController(AuthorizationServiceJpa authorizationServiceJpa) {
    this.authorizationServiceJpa = authorizationServiceJpa;
  }

  /**
   * Employee (IAMi) tokens prefix AD group names with the enterprise {@code <appId>-<ENV>-ACC-}
   * convention, while IAM_V2.USER_GROUP stores the bare name shared with the external tenant and
   * never contains a hyphen. Everything up to the last hyphen is therefore the prefix; the bare
   * alias is added next to the raw name so one row serves every issuing tenant.
   */
  private List<String> resolveUserGroups(User user) {
    List<String> groups = user.getGroups();
    if (!user.isEmployeeToken() || groups == null || groups.isEmpty()) {
      return groups;
    }
    return groups.stream()
        .filter(group -> group != null && !group.isBlank())
        .flatMap(
            group -> {
              String bare = group.substring(group.lastIndexOf('-') + 1);
              return bare.isEmpty() || bare.equals(group)
                  ? Stream.of(group)
                  : Stream.of(group, bare);
            })
        .distinct()
        .toList();
  }

  @Override
  public ResponseEntity<List<PermissionInfo>> getRolePermissions(
      String authorization, String capability) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info(
        "getRolePermissions # Start: capability: {} usergroup: {}", capability, user.getGroups());
    List<PermissionInfo> permissionList =
        authorizationServiceJpa.getRolePermissions(capability, resolveUserGroups(user));
    return new ResponseEntity<>(permissionList, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<List<Role>> getRolesAssignments(String authorization, String capability) {
    log.info("getRolesAssignments # Start: capability: {} ", capability);
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    List<String> userGroupList = resolveUserGroups(user);
    List<Role> roleList = authorizationServiceJpa.getUserRoles(capability, userGroupList, true);
    return new ResponseEntity<>(roleList, HttpStatus.OK);
  }

  @Override
  @DisablePermissionCheck
  public ResponseEntity<List<Role>> getRolesAssignmentsMe(String authorization, String capability) {
    log.info("getRolesAssignmentsMe # Start: capability: {}", capability);
    return this.getRolesAssignments(authorization, capability);
  }

  @Override
  public ResponseEntity<List<Role>> getRoles(
      String authorization, String capability, Boolean includePermissions) {
    log.info(
        "getRoles # Start: capability: {}, includePermissions {} ", capability, includePermissions);
    List<Role> roleList = authorizationServiceJpa.getRoles(capability, includePermissions);
    return new ResponseEntity<>(roleList, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Void> userHasPermissions(
      String authorization, String capability, String permission) {
    log.info("userHasPermissions # Start: capability: {}, permission {} ", capability, permission);
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    List<PermissionInfo> permissionList =
        authorizationServiceJpa.getRolePermissions(capability, resolveUserGroups(user));
    return new ResponseEntity<>(
        permissionList.stream().anyMatch(per -> per.getName().equalsIgnoreCase(permission))
            ? HttpStatus.OK
            : HttpStatus.FORBIDDEN);
  }

  @Override
  public ResponseEntity<Role> createRole(String capability, Role role) {
    log.info("createRole # Start: capability: {}, role: {} ", capability, role);
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    return new ResponseEntity<>(
        authorizationServiceJpa.createRole(user.getIdpSubject(), capability, role),
        HttpStatus.CREATED);
  }

  @Override
  public ResponseEntity<Void> deleteRole(String capability, String role) {
    log.info("deleteRole # Start: capability: {}, role: {} ", capability, role);
    authorizationServiceJpa.deleteRole(capability, role);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Role> updateRolePermission(
      String capability, String role, List<String> permissions) {
    log.info(
        "updateRolePermission # Start: capability: {}, role: {}, permissions: {}",
        capability,
        role,
        permissions);
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    Role roleOutput =
        authorizationServiceJpa.updateRolePermission(
            user.getIdpSubject(), capability, role, permissions);
    return new ResponseEntity<>(roleOutput, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Void> deleteRolePermission(String capability, String role) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("deleteRolePermission # Start: idpSubject {} capability {} role {}", user.getIdpSubject(), capability, role);
    authorizationServiceJpa.deleteRolePermission(capability, role);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<PermissionInfo> getPermission(String capability, String permission) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getPermission # Start: idpSubject {} capability {} permission {}", user.getIdpSubject(), capability, permission);
    return new ResponseEntity<>(
        authorizationServiceJpa.getPermission(capability, permission), HttpStatus.OK);
  }

  @Override
  public ResponseEntity<PermissionInfo> createPermission(
      String authorization, String capability, PermissionInfo permission) {
    log.info("createNewPermission # Start: capability {} ", capability);
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    PermissionInfo permissionInfo =
        authorizationServiceJpa.createPermission(user.getIdpSubject(), capability, permission);
    return new ResponseEntity<>(permissionInfo, HttpStatus.CREATED);
  }

  @Override
  public ResponseEntity<String> togglePermission(
      String authorization,
      String capability,
      String permission,
      TogglePermission togglePermission) {
    log.info("togglePermission # Start: capability {}, permission {} ", capability, permission);
    authorizationServiceJpa.togglePermission(capability, permission, togglePermission.getActive());
    return new ResponseEntity<>(
        togglePermissionStatusSuccessful(permission, togglePermission.getActive()), HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Void> deletePermission(
      String authorization, String capability, String permission) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("deletePermission # Start: idpSubject {} capability {}, permission {} ", user.getIdpSubject(), capability, permission);
    authorizationServiceJpa.deletePermission(capability, permission);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<List<String>> getScopes(String authorization, String capability) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getRoles # Start: idpSUbject {} capability: {}", user.getIdpSubject(), capability);
    List<String> scopes = authorizationServiceJpa.getScopes(capability);
    return new ResponseEntity<>(scopes, HttpStatus.OK);
  }

  private String togglePermissionStatusSuccessful(String permission, boolean isActive) {
    String permissionStatus = isActive ? "activated" : "deactivated";
    return String.format("Permission %s is %s successfully.", permission, permissionStatus);
  }
  
}
