package ca.bnc.wealth.api.authorization.service;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.util.AuthorizationConstants;
import ca.bnc.wealth.api.authorization.util.GeneralUtils;
import ca.bnc.wealth.api.authorization.util.MapperUtils;
import ca.bnc.wealth.common.authorization.model.ActionType;
import ca.bnc.wealth.common.authorization.model.PackageTemplate.TypeEnum;
import ca.bnc.wealth.common.authorization.model.PackageTemplateDetails;
import ca.bnc.wealth.common.authorization.model.PackageTemplateDetails.AssignmentModeEnum;
import ca.bnc.wealth.common.authorization.model.PackageTemplateDetails.AssignmentTypeEnum;
import ca.bnc.wealth.common.authorization.model.PermissionInfo;
import ca.bnc.wealth.common.authorization.model.ResourceData;
import ca.bnc.wealth.common.authorization.model.ResourceEntitlement;
import ca.bnc.wealth.common.authorization.model.Role;
import ca.bnc.wealth.common.authorization.model.TemplateResourceAssignment;
import ca.bnc.wealth.common.authorization.model.TemplateType;
import ca.bnc.wealth.common.authorization.model.UpdateTemplateResourceAssignment;
import ca.bnc.wealth.common.authorization.model.UserGroup;
import ca.bnc.wealth.common.exception.Entity.FumConflictException;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.service.PackageTemplateServiceHelper;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.Capability;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.Permission;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.entity.iam.RolePermissionAssignment;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.UserGroupRoleAssignment;
import ca.bnc.wealth.common.jpa.repo.iam.CapabilityRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PermissionRepository;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.RolePermissionAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.RoleRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserGroupRoleAssignmentRepository;
import ca.bnc.wealth.common.jpa.service.IamScheduleService;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.security.core.parameters.P;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

@Slf4j
@Repository
public class AuthorizationServiceJpa {

  private static final String GET_ROLE_CACHE_NAME = "Authorization-API-GetRole-By-Capability-UserGroup-IncludePermissions";
  private static final String GET_RESOURCE_CACHE_NAME = "Authorization-API-GetResources-By-ResourceType-IdpSubject";
  private static final String ASSIGNMENT_TYPE = "assignmentType";
  private static final String TRUE = "true";
  private static final String FALSE = "false";

  @Autowired
  private UserGroupRepository userGroupRepository;

  @Autowired
  private PermissionRepository permissionRepository;

  @Autowired
  private RoleRepository roleRepository;

  @Autowired
  private CapabilityRepository capabilityRepository;

  @Autowired
  private AuthorizationValidationService authorizationValidationService;

  @Autowired
  private UserGroupRoleAssignmentRepository userGroupRoleAssignmentRepository;

  @Autowired
  private RolePermissionAssignmentRepository rolePermissionAssignmentRepository;

  @Autowired
  private ResourceRepository resourceRepository;

  @Autowired
  private PackageTemplateRepository packageTemplateRepository;

  @Autowired
  private PackageTemplateAssignmentUserGroupRepository packageTemplateAssignmentUserGroupRepository;

  @Autowired
  private UserAssignmentUserGroupRepository userAssignmentUserGroupRepository;

  @Autowired
  private RedisCacheOperationService redisCacheOperationService;

  @Qualifier("postgresJdbcTemplate")
  @Autowired
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @Autowired
  private PackageTemplateServiceHelper packageTemplateServiceHelper;

  @Autowired
  private PackageTemplateAssignmentResourceRepository packageTemplateAssignmentResourceRepository;

  @Value("${redis.cache.enable:false}")
  private boolean enableCache;

  @Cacheable(value = AuthorizationConstants.GET_TEMPLATE_CACHE_NAME, key = "#templateType.getValue().concat('-').concat(#details).concat('-').concat((#firmType ?: 'null').toString())", cacheManager = "redisCacheManager", condition = "#root.getTarget().redisCacheEnabled()")
  public List<ca.bnc.wealth.common.authorization.model.PackageTemplate> getTemplate(String firmType,
      TemplateType templateType, Boolean details) {

    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    if (firmType != null) {
      fieldValueMap.put("firmType", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, firmType));
    }
    fieldValueMap.put("type", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, templateType.getValue()));
    Specification<PackageTemplate> spec = new Specification<>(fieldValueMap);
    List<ca.bnc.wealth.common.authorization.model.PackageTemplate> packTemps = new ArrayList<>();
    List<PackageTemplate> templates = packageTemplateRepository.findAll(spec);


    if (CollectionUtils.isEmpty(templates)) {
       return new ArrayList<>();
    }

    templates.stream()
        .forEach(
            temp -> {
              ca.bnc.wealth.common.authorization.model.PackageTemplate packTemp =
                  new ca.bnc.wealth.common.authorization.model.PackageTemplate();
              updateTemplate(packTemp, temp);
              if (Boolean.TRUE.equals(details)) {
                updateTemplateWithDetails(packTemp, temp);
              }
              packTemps.add(packTemp);
            });
    return packTemps;
  }

  private void updateTemplate(ca.bnc.wealth.common.authorization.model.PackageTemplate packTemp,
      PackageTemplate temp) {
    packTemp.setPackageTemplateId(temp.getPackageTemplateId());
    packTemp.setName(temp.getName());
    packTemp.setDescription(temp.getDescription());
    packTemp.setType(temp.getType().equals(PackageType.F) ? TypeEnum.FIRM : TypeEnum.USER);
    packTemp.setFirmType(temp.getFirmType().name());
    packTemp.setActive(temp.isActive());
  }

  private void updateTemplateWithDetails(
      ca.bnc.wealth.common.authorization.model.PackageTemplate packTemp, PackageTemplate temp) {
    packTemp.setDetails(new ArrayList<>());

    java.util.List<PackageTemplateAssignmentResource> resourceList = temp.getPackageTemplateAssignmentResources();
    java.util.List<PackageTemplateAssignmentUserGroup> userGroupList = temp.getPackageTemplateAssignmentUserGroups();

    if(!CollectionUtils.isEmpty(resourceList)) {
      resourceList.stream().forEach(assignment -> {
        if (assignment.getAssignmentType().toString()
            .equals(AuthorizationConstants.ASSIGNMENT_TYPE_RESOURCE)) {
          PackageTemplateDetails detail = new ca.bnc.wealth.common.authorization.model.PackageTemplateDetails();
          packTemp.getDetails().add(detail);
          updateResource(detail, assignment);
        }

      });
    }

    if(!CollectionUtils.isEmpty(userGroupList)) {
      userGroupList.stream().forEach(assignment -> {
        if (assignment.getAssignmentType().toString()
            .equals(AuthorizationConstants.ASSIGNMENT_TYPE_USERGROUP)) {
          PackageTemplateDetails detail = new ca.bnc.wealth.common.authorization.model.PackageTemplateDetails();
          packTemp.getDetails().add(detail);
          updateGroup(detail, assignment);
        }
      });
    }
  }

  public void deleteTemplate(String template) {
    packageTemplateServiceHelper.deletePackageTemplate(template);
    redisCacheOperationService.deleteCacheByCacheName(AuthorizationConstants.GET_TEMPLATE_CACHE_NAME);
  }

  private void updateResource(PackageTemplateDetails detail,
      PackageTemplateAssignmentResource assignment) {
    ca.bnc.wealth.common.authorization.model.Resource resource =
        new ca.bnc.wealth.common.authorization.model.Resource();
    detail.setTemplateDetailId(assignment.getTemplateAssignmentId());
    detail.setAssignmentType( assignment.getAssignmentType() == PackageAssignmentType.G ?
        AssignmentTypeEnum.G : AssignmentTypeEnum.S);
    detail.setAssignmentMode(assignment.getAssignmentMode() == PackageAssignmentMode.M ?
        AssignmentModeEnum.M : AssignmentModeEnum.O);
    detail.setSelectionDefault(assignment.isSelectionDefault());
    detail.setResource(resource);
    resource.setResourceId(assignment.getResource().getResourceId());
    resource.setName(assignment.getResource().getName());
    resource.setDescription(assignment.getResource().getDescription());
    resource.setType(assignment.getResource().getType());
    resource.setGroup(assignment.getResource().getGroupName());
    resource.setLabel(assignment.getResource().getLabel());
    resource.setPurpose(assignment.getResource().getPurpose());
    resource.setRestriction(assignment.getResource().getRestriction());
  }

  private void updateGroup(PackageTemplateDetails detail ,
      PackageTemplateAssignmentUserGroup assignment) {
    ca.bnc.wealth.common.authorization.model.UserGroup userGroup =
        new ca.bnc.wealth.common.authorization.model.UserGroup();
    detail.setTemplateDetailId(assignment.getTemplateAssignmentId());
    detail.setAssignmentType(assignment.getAssignmentType() ==
        PackageAssignmentType.G?AssignmentTypeEnum.G:AssignmentTypeEnum.S);
    detail.setAssignmentMode(assignment.getAssignmentMode() ==
        PackageAssignmentMode.M? AssignmentModeEnum.M:AssignmentModeEnum.O);
    detail.setUserGroup(userGroup);
    userGroup.setUserGroupId(assignment.getUserGroup().getUserGroupId());
    userGroup.setName(assignment.getUserGroup().getName());
    userGroup.setDescription(assignment.getUserGroup().getDescription());
    userGroup.setIsFirmScope(assignment.getUserGroup().getIsFirmScope());
    userGroup.setIsInternal(assignment.getUserGroup().getIsInternal());

  }

  public List<UserGroup> getAllUserGroups() {
    return userGroupRepository.findAll().stream()
        .map(MapperUtils::toDto)
        .toList();
  }

  public List<UserGroup> getGroupsMe(String idpSubject) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("isActive", Pair.of(EnumQueryCriteria.EQUALS, true));
    fieldValueMap.put("userAssignmentUserGroups.userConfiguration.idpSubject", Pair.of(EnumQueryCriteria.EQUALS, idpSubject));
    fieldValueMap.put("userAssignmentUserGroups.assignmentType", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.G.name()));

    Specification<ca.bnc.wealth.common.jpa.entity.iam.UserGroup> spec = new Specification<>(fieldValueMap);
    return userGroupRepository.findAll(spec).stream()
        .map(MapperUtils::toDto)
        .toList();
  }

  @Cacheable(value = "Authorization-API-GetResources-By-ResourceType-IdpSubject", key = "#resourceType.concat('-').concat(#idpSubject)", cacheManager = "redisCacheManager", condition = "#root.getTarget().redisCacheEnabled()")
  public List<ResourceEntitlement> getResourceEntitlements(
      String resourceType, String idpSubject) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("active", Pair.of(EnumQueryCriteria.EQUALS, true));
    fieldValueMap.put("type", Pair.of(EnumQueryCriteria.EQUALS, resourceType));
    fieldValueMap.put("userAssignmentResources.userConfiguration.idpSubject", Pair.of(EnumQueryCriteria.EQUALS, idpSubject));
    fieldValueMap.put("userAssignmentResources.assignmentType", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER,
        UserAssignmentType.S.name()));

    Specification<Resource> spec = new Specification<>(fieldValueMap);
    List<Resource> resources = this.resourceRepository.findAll(spec);

    Set<String> excludes = resources.stream()
        .filter(Resource::getRestriction)
        .map(Resource::getName)
        .collect(Collectors.toSet());

    return resources.stream()
        .filter(Predicate.not(r -> excludes.contains(r.getName())))
        .map(MapperUtils::toResourceEntitlement)
        .toList();
  }

  public List<PermissionInfo> getRolePermissions(String capability, List<String> userGroupList) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("capability.name", Pair.of(EnumQueryCriteria.EQUALS, capability));
    fieldValueMap.put("rolePermissionAssignments.role.userGroupRoleAssignments.userGroup.name",
        Pair.of(EnumQueryCriteria.IN, userGroupList));
    fieldValueMap.put("isActive", Pair.of(EnumQueryCriteria.EQUALS, true));
    Specification<Permission> spec = new Specification<>(fieldValueMap);
    return this.permissionRepository.findAll(spec).stream()
        .map(p -> MapperUtils.toPermissionInfo(p, capability))
        .distinct()
        .toList();
  }

  @Cacheable(value = "Authorization-API-GetRole-By-Capability-UserGroup-IncludePermissions", key = "#capability.concat('-').concat(#userGroupList.toString()).concat('-').concat(#includePermissions)", cacheManager = "redisCacheManager", condition = "#root.getTarget().redisCacheEnabled()")
  public List<Role> getUserRoles(
      String capability, List<String> userGroupList, Boolean includePermissions) {
    SqlParameterSource parameters = new MapSqlParameterSource()
        .addValue("capability", capability)
        .addValue("userGroupList", userGroupList);
    List<Role> lst = namedParameterJdbcTemplate.queryForList(AuthorizationConstants.GET_ROLES_FROM_USERGROUPLIST_QUERY, parameters).stream()
        .map(MapperUtils::toRoleDto)
        .toList();

    if (includePermissions != null && includePermissions) {
      this.updatePermissions(lst);

    }
    return lst;
  }

  public List<Role> getRoles(String capability, Boolean includePermissions) {
    SqlParameterSource parameters = new MapSqlParameterSource().addValue("capability", capability);
    List<Role> lst = namedParameterJdbcTemplate.queryForList(AuthorizationConstants.GET_ROLES_QUERY, parameters).stream()
        .map(MapperUtils::toRoleDto)
        .toList();

    if (includePermissions != null && includePermissions) {
      this.updatePermissions(lst);
    }

    return lst;
  }

  public List<String> getScopes(String capability) {
    List<String> lst = new ArrayList();
    List<Role> list = this.getRoles(capability, false);
    list.stream()
        .forEach(
            role -> lst.add(role.getRoleName()));
    return lst;
  }

  @SneakyThrows
  public Role createRole(String idpSubject, String capabilityCode, Role role) {
    Capability capability = capabilityRepository.findFirstByName(capabilityCode);
    if (capability == null) {
      throw new FumNotFoundException(
          AuthorizationConstants.CAPABILITY_NOT_FOUND_CODE,
          String.format(AuthorizationConstants.CAPABILITY_NOT_FOUND_MESSAGE, capabilityCode));
    }

    authorizationValidationService.validateRole(capabilityCode, role);

    ca.bnc.wealth.common.jpa.entity.iam.Role roleEntity =
        new ca.bnc.wealth.common.jpa.entity.iam.Role();
    roleEntity.setName(role.getRoleName());
    roleEntity.setCapability(capability);
    roleEntity.setCreatedBy(idpSubject);
    roleEntity.setCreationDate(new Timestamp(System.currentTimeMillis()));

    try {
      ca.bnc.wealth.common.jpa.entity.iam.Role savedRoleEntity = roleRepository.save(roleEntity);
      redisCacheOperationService.deleteCacheByCacheNameAndPattern(GET_ROLE_CACHE_NAME, capability.getName());
      return MapperUtils.toDto(savedRoleEntity);
    } catch (Exception e) {
      if (e.getMessage().contains("constraint [uk_role_capability]") || e.getMessage()
          .contains("constraint [uk_role]")) {
        throw new FumConflictException(
            AuthorizationConstants.ROLE_EXISTS,
            String.format(
                AuthorizationConstants.ROLE_EXISTS_MESSAGE, role.getRoleName(), capabilityCode));
      }

      throw new FumServiceException(AuthorizationConstants.ROLE_NOT_CREATED,
          String.format(AuthorizationConstants.ROLE_NOT_CREATED_MESSAGE, role.getRoleName(), capabilityCode));
    }
  }

  @SneakyThrows
  public void deleteRole(String capabilityCode, String role) {
    Capability capabilityEntity;
    try {
      capabilityEntity = capabilityRepository.findFirstByName(capabilityCode);
      int isDeleted = roleRepository.deleteByNameAndCapability(role, capabilityEntity);
      if (isDeleted == 0) {
        throw new FumNotFoundException(
            AuthorizationConstants.ROLE_NOT_FOUND_CODE,
            String.format(AuthorizationConstants.ROLE_NOT_FOUND_MESSAGE, role, capabilityCode));
      }
    } catch (Exception e) {
      if (e instanceof FumNotFoundException) {
        throw e;
      }

      throw new FumServiceException(AuthorizationConstants.ROLE_NOT_DELETED,
          String.format(AuthorizationConstants.ROLE_NOT_DELETED_MESSAGE, role, capabilityCode));
    }
    redisCacheOperationService.deleteCacheByCacheNameAndPattern(GET_ROLE_CACHE_NAME,
        capabilityEntity.getName());
  }

  @SneakyThrows
  @Transactional(rollbackFor = Exception.class)
  public Role updateRolePermission(
      String idpSubject, String capabilityCode, String role, List<String> permissions) {
    if (permissions == null) {
      throw new FumValidationException(
          AuthorizationConstants.PERMISSION_NULL_CODE,
          AuthorizationConstants.PERMISSION_NULL_MESSAGE);
    }

    Capability capabilityEntity = capabilityRepository.findFirstByName(capabilityCode);
    if (capabilityEntity == null) {
      throw new FumNotFoundException(
          AuthorizationConstants.CAPABILITY_NOT_FOUND_CODE,
          String.format(AuthorizationConstants.CAPABILITY_NOT_FOUND_MESSAGE, capabilityCode));
    }

    ca.bnc.wealth.common.jpa.entity.iam.Role roleEntity =
        roleRepository.findByNameAndCapability(role, capabilityEntity);
    if (roleEntity == null) {
      throw new FumNotFoundException(
          AuthorizationConstants.ROLE_NOT_FOUND_CODE,
          String.format(AuthorizationConstants.ROLE_NOT_FOUND_MESSAGE, role, capabilityCode));
    }

    List<Permission> permissionEntityList =
        permissionRepository.findByNameInAndCapability(permissions, capabilityEntity);
    if (permissions.size() != permissionEntityList.size()) {
      throw new FumValidationException(
          AuthorizationConstants.PERMISSIONS_NOT_FOUND_CODE,
          String.format(
              AuthorizationConstants.PERMISSIONS_NOT_FOUND_MESSAGE, permissions, capabilityCode));
    }

    if (!CollectionUtils.isEmpty(roleEntity.getRolePermissionAssignments())) {
      rolePermissionAssignmentRepository.deleteAll(roleEntity.getRolePermissionAssignments());
      rolePermissionAssignmentRepository.flush();
    }

    List<RolePermissionAssignment> rolePermissionAssignments = new ArrayList<>();
    permissionEntityList.forEach(
        permission -> {
          RolePermissionAssignment rolePermissionAssignment = new RolePermissionAssignment();
          rolePermissionAssignment.setRole(roleEntity);
          rolePermissionAssignment.setPermission(permission);
          rolePermissionAssignment.setCreatedBy(idpSubject);
          rolePermissionAssignment.setCreationDate(new Timestamp(System.currentTimeMillis()));
          rolePermissionAssignments.add(rolePermissionAssignment);
        });
    List<RolePermissionAssignment> savedRolePermissionAssignmentList =
        rolePermissionAssignmentRepository.saveAllAndFlush(rolePermissionAssignments);
    roleEntity.setRolePermissionAssignments(savedRolePermissionAssignmentList);

    redisCacheOperationService.deleteCacheByCacheNameAndPattern(GET_ROLE_CACHE_NAME, capabilityEntity.getName());

    return MapperUtils.toDto(roleEntity);
  }

  @Transactional
  public void deleteRolePermission(String capabilityCode, String role) {
    Optional.ofNullable(capabilityRepository.findFirstByName(capabilityCode))
        .ifPresentOrElse(
            capability -> Optional.ofNullable(roleRepository.findByNameAndCapability(role, capability))
                .ifPresentOrElse(
                    roleEntity -> {
                      rolePermissionAssignmentRepository.deleteRolePermissionAssignmentsByRole(roleEntity);
                      redisCacheOperationService.deleteCacheByCacheNameAndPattern(GET_ROLE_CACHE_NAME, capability.getName());
                    },
                    () ->
                        new FumNotFoundException(
                            AuthorizationConstants.ROLE_NOT_FOUND_CODE,
                            String.format(AuthorizationConstants.ROLE_NOT_FOUND_MESSAGE, role, capabilityCode))
                ),
            () ->
                new FumNotFoundException(
                    AuthorizationConstants.CAPABILITY_NOT_FOUND_CODE,
                    String.format(AuthorizationConstants.CAPABILITY_NOT_FOUND_MESSAGE, capabilityCode))
        );

  }

  public PermissionInfo createPermission(
      String idpSubject, String capabilityCode, PermissionInfo permission) {
    Capability capability = capabilityRepository.findFirstByName(capabilityCode);
    if (capability == null) {
      throw new FumNotFoundException(
          AuthorizationConstants.CAPABILITY_NOT_FOUND_CODE,
          String.format(AuthorizationConstants.CAPABILITY_NOT_FOUND_MESSAGE, capabilityCode));
    }
    authorizationValidationService.validatePermission(permission);
    Permission permissionEntity = MapperUtils.toEntity(permission);
    permissionEntity.setActive(true);
    permissionEntity.setCapability(capability);
    permissionEntity.setCreatedBy(idpSubject);
    permissionEntity.setCreationDate(new Timestamp(System.currentTimeMillis()));
    Permission savedPermission;
    try {
        savedPermission = permissionRepository.save(permissionEntity);
    } catch (DataIntegrityViolationException e) {
      if (e.getMessage().contains("uk_permission")) {
        throw new FumValidationException(
            AuthorizationConstants.PERMISSION_ALREADY_EXIST_CODE,
            String.format(
                AuthorizationConstants.PERMISSION_ALREADY_EXIST_MESSAGE,
                permission.getName()));
      }
      throw e;
    }
    redisCacheOperationService.deleteCacheByCacheNameAndPattern(GET_ROLE_CACHE_NAME, capability.getName());

    return MapperUtils.toDto(savedPermission);
  }

  public void togglePermission(String capability, String permission, boolean isActivate) {
    List<Permission> permissions = findPermissions(capability, permission);

    if (CollectionUtils.isEmpty(permissions)) {
      throw new FumNotFoundException(
          AuthorizationConstants.PERMISSION_INVALID_CODE,
          String.format(AuthorizationConstants.PERMISSION_DOES_NOT_EXIST_MESSAGE, permission));
    }
    Permission togglePermission = permissions.get(0);
    togglePermission.setActive(isActivate);
    permissionRepository.save(togglePermission);
    redisCacheOperationService.deleteCacheByCacheNameAndPattern(GET_ROLE_CACHE_NAME, capability);
  }

  public void deletePermission(String capability, String permission) {
    List<Permission> permissionToDelete = findPermissions(capability, permission);

    if (!CollectionUtils.isEmpty(permissionToDelete)) {
      permissionRepository.delete(permissionToDelete.get(0));
      redisCacheOperationService.deleteCacheByCacheNameAndPattern(GET_ROLE_CACHE_NAME, capability);
    }
  }

  public UserGroup createUserGroup(String idpSubject, UserGroup userGroup) {
    authorizationValidationService.validateUserGroup(userGroup);

    getUserGroup(userGroup.getName())
        .ifPresent(
            ug -> {
              throw new FumValidationException(
                  AuthorizationConstants.USER_GROUP_ALREADY_EXIST_CODE,
                  String.format(
                      AuthorizationConstants.USER_GROUP_ALREADY_EXIST_MESSAGE, userGroup));
            });

    ca.bnc.wealth.common.jpa.entity.iam.UserGroup entity = MapperUtils.toEntity(userGroup);
    entity.setCreatedBy(idpSubject);
    entity.setCreationDate(new Timestamp(System.currentTimeMillis()));
    return MapperUtils.toDto(userGroupRepository.save(entity));
  }

  public void deleteUserGroup(String userGroup) {

    Optional<ca.bnc.wealth.common.jpa.entity.iam.UserGroup> optional = getUserGroup(userGroup);
    if(optional.isPresent()) {
      if(userGroupAsAssignments(optional.get())) {
        throw new FumValidationException(
            AuthorizationConstants.USER_GROUP_HAS_ASSIGNMENT_CODE,
            String.format(
                AuthorizationConstants.USER_GROUP_HAS_ASSIGNMENT_MESSAGE, userGroup));
      }
      userGroupRepository.delete(optional.get());
    }

  }

  public UserGroup updateUserGroup(String idpSubject, String userGroupId, UserGroup userGroup) {
    authorizationValidationService.validateUserGroup(userGroup);

    ca.bnc.wealth.common.jpa.entity.iam.UserGroup entity =
        getUserGroup(userGroupId)
            .orElseThrow(
                () ->
                    new FumValidationException(
                        AuthorizationConstants.USER_GROUP_NOT_EXIST_CODE,
                        String.format(
                            AuthorizationConstants.USER_GROUP_NOT_EXIST_MESSAGE, userGroup)));

    entity.setName(userGroup.getName());
    entity.setDescription(userGroup.getDescription());
    entity.setIsFirmScope(userGroup.getIsFirmScope());
    entity.setIsInternal(userGroup.getIsInternal());
    entity.setIsActive(userGroup.getIsActive());
    entity.setUpdatedBy(idpSubject);
    entity.setUpdateDate(new Timestamp(System.currentTimeMillis()));
    return MapperUtils.toDto(userGroupRepository.save(entity));
  }

  @Transactional(rollbackFor = Exception.class)
  public void addUserGroupAndRoleAssignment(
      String idpSubject, String userGroupId, List<String> roles) {

    ca.bnc.wealth.common.jpa.entity.iam.UserGroup userGroup =
        getUserGroup(userGroupId)
            .orElseThrow(
                () ->
                    new FumValidationException(
                        AuthorizationConstants.USER_GROUP_NOT_EXIST_CODE,
                        String.format(
                            AuthorizationConstants.USER_GROUP_NOT_EXIST_MESSAGE, userGroupId)));

    List<ca.bnc.wealth.common.jpa.entity.iam.Role> lst = getRoles(roles);

    if ((new HashSet<>(roles)).size() != lst.size()) {
      throw new FumValidationException(
          AuthorizationConstants.ROLE_LIST_NOT_FOUND_CODE,
          String.format(AuthorizationConstants.ROLE_LIST_NOT_FOUND_MESSAGE, roles));
    }

    List<UserGroupRoleAssignment> userGroupRoleAssignments =
        getUserGroupRoleAssignment(userGroup.getUserGroupId());

    List<String> existingAssignment = new ArrayList<>();
    userGroupRoleAssignments.stream()
        .filter(ugr -> ugr.getRole() != null && roles.contains(ugr.getRole().getName()))
        .map(urg -> urg.getRole().getName())
        .forEach(existingAssignment::add);

    userGroupRoleAssignments.stream()
        .filter(ugr -> ugr.getRole() == null || !roles.contains(ugr.getRole().getName()))
        .forEach(userGroupRoleAssignmentRepository::delete);

    lst.stream()
        .filter(role -> !existingAssignment.contains(role.getName()))
        .forEach(
            role -> {
              UserGroupRoleAssignment userGroupRoleAssignment = new UserGroupRoleAssignment();
              userGroupRoleAssignment.setUserGroup(userGroup);
              userGroupRoleAssignment.setRole(role);
              userGroupRoleAssignment.setCreatedBy(idpSubject);
              userGroupRoleAssignment.setCreationDate(new Timestamp(System.currentTimeMillis()));
              userGroupRoleAssignmentRepository.save(userGroupRoleAssignment);
            });
  }

  public void deleteUserGroupAndRoleAssignment(String userGroupId) {
    ca.bnc.wealth.common.jpa.entity.iam.UserGroup userGroup =
        getUserGroup(userGroupId)
            .orElseThrow(
                () ->
                    new FumValidationException(
                        AuthorizationConstants.USER_GROUP_NOT_EXIST_CODE,
                        String.format(
                            AuthorizationConstants.USER_GROUP_NOT_EXIST_MESSAGE, userGroupId)));

    getUserGroupRoleAssignment(userGroup.getUserGroupId())
        .forEach(userGroupRoleAssignmentRepository::delete);
  }

  private List<ca.bnc.wealth.common.jpa.entity.iam.Role> getRoles(List<String> roles) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("name", Pair.of(EnumQueryCriteria.IN, roles));
    Specification<ca.bnc.wealth.common.jpa.entity.iam.Role> spec =
        new Specification<>(fieldValueMap);
    return roleRepository.findAll(spec);
  }

  private Optional<ca.bnc.wealth.common.jpa.entity.iam.UserGroup> getUserGroup(String userGroup) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    if (GeneralUtils.isNumber(userGroup)) {
      fieldValueMap.put(
          "userGroupId", Pair.of(EnumQueryCriteria.EQUALS, Integer.valueOf(userGroup)));
    } else {
      fieldValueMap.put("name", Pair.of(EnumQueryCriteria.EQUALS, userGroup));
    }

    Specification<ca.bnc.wealth.common.jpa.entity.iam.UserGroup> spec =
        new Specification<>(fieldValueMap);
    return userGroupRepository.findOne(spec);
  }

  private List<UserGroupRoleAssignment> getUserGroupRoleAssignment(Long userGroupId) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("userGroup.userGroupId", Pair.of(EnumQueryCriteria.EQUALS, userGroupId));
    Specification<UserGroupRoleAssignment> spec = new Specification<>(fieldValueMap);
    return userGroupRoleAssignmentRepository.findAll(spec);
  }

  private boolean userGroupAsAssignments(ca.bnc.wealth.common.jpa.entity.iam.UserGroup userGroup) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap1 = new HashMap<>();
    fieldValueMap1.put(
        ASSIGNMENT_TYPE, Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, PackageAssignmentType.G.name()));
    fieldValueMap1.put("userGroup.userGroupId", Pair.of(EnumQueryCriteria.EQUALS, userGroup.getUserGroupId()));
    Specification<PackageTemplateAssignmentUserGroup> spec1 = new Specification<>(fieldValueMap1);
    if(packageTemplateAssignmentUserGroupRepository.exists(spec1))
      return true;

    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap2 = new HashMap<>();
    fieldValueMap2.put("userGroup.userGroupId", Pair.of(EnumQueryCriteria.EQUALS, userGroup.getUserGroupId()));
    Specification<UserGroupRoleAssignment> spec2 = new Specification<>(fieldValueMap2);
    if(userGroupRoleAssignmentRepository.exists(spec2))
      return true;

    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap3 = new HashMap<>();
    fieldValueMap3.put(
        ASSIGNMENT_TYPE, Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.G.name()));
    fieldValueMap3.put("userGroup.userGroupId", Pair.of(EnumQueryCriteria.EQUALS, userGroup.getUserGroupId()));
    Specification<UserAssignmentUserGroup> spec3 = new Specification<>(fieldValueMap3);
    return userAssignmentUserGroupRepository.exists(spec3);
  }

  public void deleteResource(String resourceType, String resource) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("name", Pair.of(EnumQueryCriteria.EQUALS, resource));
    fieldValueMap.put("type", Pair.of(EnumQueryCriteria.EQUALS, resourceType));
    Specification<Resource> spec = new Specification<>(fieldValueMap);
    List<Resource> resources = resourceRepository.findAll(spec);

    if (CollectionUtils.isEmpty(resources)) {
      log.info( String.format(AuthorizationConstants.RESOURCE_DOES_NOT_EXIST_MESSAGE, resource, resourceType));
    }
    else {
      Resource resourceEntity = resources.get(0);
      resourceRepository.delete(resourceEntity);
      redisCacheOperationService.deleteCacheByCacheNameAndPattern(GET_RESOURCE_CACHE_NAME, resourceEntity.getName());
    }
  }

  public void patchResource(String resourceType, String resource, ResourceData resourceData) {

    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("name", Pair.of(EnumQueryCriteria.EQUALS, resource));
    fieldValueMap.put("type", Pair.of(EnumQueryCriteria.EQUALS, resourceType));
    Specification<Resource> spec = new Specification<>(fieldValueMap);
    List<Resource> resources = resourceRepository.findAll(spec);

    if (CollectionUtils.isEmpty(resources)) {
      throw new FumValidationException(
          AuthorizationConstants.RESOURCE_INVALID_CODE,
          String.format(
              AuthorizationConstants.RESOURCE_DOES_NOT_EXIST_MESSAGE, resource, resourceType));
    }
    Resource resourceEntity = resources.get(0);
    resourceEntity.setActive(resourceData.getActive());
    resourceEntity.setDescription(resourceData.getDescription());
    resourceEntity.setName(resourceData.getName());
    resourceEntity.setRestriction(resourceData.getRestriction());
    resourceRepository.save(resourceEntity);
    redisCacheOperationService.deleteCacheByCacheNameAndPattern(GET_RESOURCE_CACHE_NAME, resourceEntity.getName());
  }

  private void updatePermissions(List<Role> lst) {
    ExecutorService executorService = Executors.newFixedThreadPool(5);
    lst.forEach(
        role -> executorService.submit(
            () -> {
              SqlParameterSource parameters = new MapSqlParameterSource()
                  .addValue("capability", role.getCapability())
                  .addValue("roleName", role.getRoleName())
                  .addValue("active", true);

              role.setPermissions(
                  namedParameterJdbcTemplate.queryForList(AuthorizationConstants.GET_PERMISSION_QUERY, parameters).stream()
                      .map(MapperUtils::toDto)
                      .collect(Collectors.toList()));
            }));
    this.shutdownAndAwait(executorService);
  }

  private List<Permission> findPermissions(String capability, String permission) {
    return permissionRepository.findAll().stream()
        .filter(
            x -> x.getName().equals(permission) && x.getCapability().getName().equals(capability))
        .toList();
  }

  @SneakyThrows
  private void shutdownAndAwait(ExecutorService executorService) {
    executorService.shutdown();
    try {
      executorService.awaitTermination(20, TimeUnit.MINUTES);
    } catch (InterruptedException e) {
      executorService.shutdownNow();
      log.error("Error in executor service: {}", e.getMessage());
      throw e;
    }
  }

  public ResourceData createResource(String idpSubject, String resourceType,
      ResourceData resourceData) {
    Resource resource = MapperUtils.toEntity(resourceData);
    resource.setType(resourceType);
    resource.setCreatedBy(idpSubject);
    resource.setCreationDate(new Timestamp(System.currentTimeMillis()));
    return MapperUtils.toDto(resourceRepository.save(resource));
  }

  public List<ResourceData> getResourceByResourceType(String resourceType) {
    List<Resource> resourceList = resourceRepository.findByType(resourceType);
    if (CollectionUtils.isEmpty(resourceList)) {
      return new ArrayList<>();
    }

    return resourceList.stream().map(MapperUtils::toDto).toList();
  }

  public ResourceData getResourceByTypeAndName(String resourceType, String name) {
    return resourceRepository.findFirstByTypeAndName(resourceType, name)
        .map(MapperUtils::toDto)
        .orElseThrow(() -> new FumNotFoundException(
            AuthorizationConstants.RESOURCE_NOT_FOUND_CODE,
            String.format(AuthorizationConstants.RESOURCE_NOT_FOUND_MESSAGE, name)));
  }

  public boolean checkResourceByNameAndRestriction(String resourceType, ResourceData resourceData) {
    authorizationValidationService.validateResourceForCreate(resourceType, resourceData);
    Resource resource = MapperUtils.toEntity(resourceData);
    Optional<Resource> checkResourceNameAndRestriction = resourceRepository
            .findFirstByNameAndRestriction(resource.getName(), resource.getRestriction());
    if(checkResourceNameAndRestriction.isPresent()) {
      return true;
    }
      return false;
  }

  public List<ResourceData> getResourceByResourceTypeAndRrCode(String resourceType, String rrCode, User user) {
    SqlParameterSource decodeB10Parameters = new MapSqlParameterSource().addValue("rrCode", rrCode);
    long rrCodeB10 = (Long) namedParameterJdbcTemplate
        .queryForMap(AuthorizationConstants.DECODE_RRCODE_QUERY, decodeB10Parameters).get("b36_decode");

    SqlParameterSource rrCodeParameters = new MapSqlParameterSource()
        .addValue("idpSubject", user.getIdpSubject())
        .addValue(ASSIGNMENT_TYPE, UserAssignmentType.R.name())
        .addValue("active", true)
        .addValue("rrCodeB10", rrCodeB10);
    List<Map<String, Object>> rrCodeMapList = namedParameterJdbcTemplate
        .queryForList(AuthorizationConstants.GET_RRCODE_BY_USER_AND_B10_QUERY, rrCodeParameters);

    if (rrCodeMapList.isEmpty()) {
      log.debug("RR Code {} is not assigned to user {}", rrCode, user.getUsername());
      return new ArrayList<>();
    }

    SqlParameterSource resourceParameters = new MapSqlParameterSource()
        .addValue("rrCode", rrCode)
        .addValue("resourceType", resourceType);
    List<Map<String, Object>> resourceMapList = namedParameterJdbcTemplate
        .queryForList(AuthorizationConstants.GET_RESOURCES_BY_RRCODE_QUERY, resourceParameters);
    return resourceMapList.stream().map(MapperUtils::toResourceDataDto).toList();
  }

  public PermissionInfo getPermission(String capabilityCode, String permissionName) {
    return Optional.ofNullable(capabilityRepository.findFirstByName(capabilityCode))
        .map(
            capability -> permissionRepository.findFirstByNameAndCapability(permissionName, capability)
                .map(
                    permission -> MapperUtils.toPermissionInfo(permission, capabilityCode)
                )
                .orElseThrow(
                    () -> new FumNotFoundException(
                        AuthorizationConstants.PERMISSION_NOT_FOUND_CODE,
                        String.format(AuthorizationConstants.PERMISSION_NOT_FOUND_MESSAGE, permissionName, capabilityCode))
                ))
        .orElseThrow(
            () -> new FumNotFoundException(
                AuthorizationConstants.CAPABILITY_NOT_FOUND_CODE,
                String.format(AuthorizationConstants.CAPABILITY_NOT_FOUND_MESSAGE, capabilityCode))
        );
  }

  public void updateTemplateResourcesSynchronous(String templateName,
      UpdateTemplateResourceAssignment updateTemplateResourceAssignment, String requestedBy) {
    updateTemplateResources(templateName, updateTemplateResourceAssignment, requestedBy);
  }

  public void updateTemplateResources(String templateName,
      UpdateTemplateResourceAssignment updateTemplateResourceAssignment, String requestedBy) {
    validateAndUpdateTemplateResourceAssignmentPayload(updateTemplateResourceAssignment, templateName);
    if(updateTemplateResourceAssignment.getResources().isEmpty()) {
      log.info("No resources to update for PT {}", templateName);
      return;
    }
    switch (updateTemplateResourceAssignment.getAction()) {
      case ADD:
        List<String> addPtds = createPtds(updateTemplateResourceAssignment.getResources());
        log.info("Adding PTDs {} to PT {}", addPtds, templateName);
        packageTemplateRepository.addPtdToPt(templateName, String.join(",", addPtds), requestedBy);
        log.info("Added PTDs {} to PT {}", addPtds, templateName);
        break;
      case DELETE:
        List<String> deletePtds = deletePtds(updateTemplateResourceAssignment.getResources());
        log.info("Deleting PTDs {} from PT {}", deletePtds, templateName);
        packageTemplateRepository.deletePtdFromPt(templateName, String.join(",", deletePtds));
        log.info("Deleted PTDs {} from PT {}", deletePtds, templateName);
        break;
      case REPLACE:
        List<String> replacePtds = createPtds(updateTemplateResourceAssignment.getResources());
        log.info("Replacing PTDs {} in PT {}", replacePtds, templateName);
        packageTemplateRepository.replacePtdForPt(templateName,String.join(",", replacePtds), requestedBy);
        log.info("Replaced PTDs {} in PT {}", replacePtds, templateName);
        break;
    }
    redisCacheOperationService.deleteCacheByCacheName(AuthorizationConstants.GET_TEMPLATE_CACHE_NAME);
    redisCacheOperationService.deleteCacheByCacheName(GET_RESOURCE_CACHE_NAME);
  }

  public PackageTemplate getPackageTemplateEntity(String templateName) {
    return packageTemplateRepository.findByName(templateName)
        .orElseThrow(() -> new FumNotFoundException(AuthorizationConstants
            .FEATURE_PACKAGE_TEMPLATE_NOT_FOUND_CODE,
            String.format(AuthorizationConstants.FEATURE_PACKAGE_TEMPLATE_NOT_FOUND_MESSAGE,
                templateName)));
  }

  private List<String> createPtds(List<TemplateResourceAssignment> resources) {
    List<String> ptds = new ArrayList<>();
    resources.forEach(resource -> {
      if (resource.getModuleOverride() == null) {
        resource.setModuleOverride(false);
      }
      String ptd = resource.getName() + ":" + (Boolean.TRUE.equals(resource.getRestriction()) ? TRUE : FALSE) + ":S:"
          + resource.getAssignmentMode().name() + ":" + (Boolean.TRUE.equals(resource.getSelectionDefault()) ? TRUE
          : FALSE) + ":" + (Boolean.TRUE.equals(resource.getModuleOverride()) ? TRUE : FALSE);
      ptds.add(ptd);
    });
    return ptds;
  }

  private List<String> deletePtds(List<TemplateResourceAssignment> resources) {
    List<String> ptds = new ArrayList<>();
    resources.forEach(resource -> {
      String ptd = resource.getName() + ":" + (Boolean.TRUE.equals(resource.getRestriction()) ? TRUE : FALSE);
      ptds.add(ptd);
    });
    return ptds;
  }

  protected void validateAndUpdateTemplateResourceAssignmentPayload(
      UpdateTemplateResourceAssignment resourceAssignment, String templateName) {
    List<String> resourceNames = new ArrayList<>();
    PackageTemplate packageTemplate = getPackageTemplateEntity(templateName);
    validateUpdateTemplateResourceAssignmentDto(resourceAssignment, packageTemplate);

    Map<String, List<Resource>> resourceGroupByName = resourceRepository.findAll().stream()
        .collect(Collectors.groupingBy(Resource::getName));
    Map<String, List<Resource>> ptdResourceGroupByName = getPackageTemplateResources(packageTemplate.getPackageTemplateId()).stream()
        .collect(Collectors.groupingBy(Resource::getName));

    Map<String, List<TemplateResourceAssignment>> resourceData = resourceAssignment.getResources().stream()
        .collect(Collectors.groupingBy(TemplateResourceAssignment::getName));

    resourceData.forEach((resourceName, tralist) -> {
      if(!resourceGroupByName.containsKey(resourceName)) {
        throw new FumNotFoundException(
            AuthorizationConstants.RESOURCE_NOT_FOUND_CODE,
            String.format(AuthorizationConstants.RESOURCE_NOT_FOUND_MESSAGE, resourceName));
      }

      //Validation for input and resource
      if(tralist.size() == 1 && tralist.get(0).getRestriction()) {
        throw new FumValidationException(AuthorizationConstants.RESOURCE_INPUT_INVALID_CODE,
            String.format(AuthorizationConstants.RESOURCE_INPUT_INVALID_RESTRICTION_MESSAGE, resourceName));
      } else if(tralist.size() == 1 && resourceGroupByName.get(resourceName).size() != 1) {
        throw new FumValidationException(AuthorizationConstants.RESOURCE_INPUT_INVALID_CODE,
            String.format("other pair of the resource should be add %s", resourceName));
      } else if(tralist.size() == 2 && ! (tralist.get(0).getRestriction() ^ tralist.get(1).getRestriction())) {
        throw new FumValidationException(AuthorizationConstants.RESOURCE_INPUT_INVALID_CODE,
            String.format("Restricted resource %s should be paired in true/false", resourceName));
      } else if(tralist.size() == 2 && resourceGroupByName.get(resourceName).size() != 2) {
        throw new FumValidationException(AuthorizationConstants.RESOURCE_INPUT_INVALID_CODE,
            String.format("Restricted resource %s pair not found in DB", resourceName));
      } else if(tralist.size() == 2 && !isValidOptionalResources(tralist)) {
        throw new FumValidationException(AuthorizationConstants.RESOURCE_INPUT_INVALID_CODE,
            String.format("Optional resources %s assignment modes do not match with the given resource restrictions", resourceName));
      }
      else if(tralist.size() > 2) {
        throw new FumValidationException(AuthorizationConstants.RESOURCE_INPUT_INVALID_CODE,
            String.format("can not have more than 2 resource with same resource name %s", resourceName));
      }

      if(ActionType.ADD.getValue().equalsIgnoreCase(resourceAssignment.getAction().getValue()) &&
          ptdResourceGroupByName.containsKey(resourceName)) {
        resourceNames.add(resourceName);
      } else if(ActionType.DELETE.getValue().equalsIgnoreCase(resourceAssignment.getAction().getValue())
          && !ptdResourceGroupByName.containsKey(resourceName)) {
        resourceNames.add(resourceName);
      }
    });

    log.info("Removing the resources: {} that are already updated", resourceNames);
    resourceAssignment.setResources(resourceAssignment.getResources().stream()
        .filter(resource -> !resourceNames.contains(resource.getName()))
        .collect(Collectors.toList()));
  }

  protected boolean isValidOptionalResources(List<TemplateResourceAssignment> tralist) {

    TemplateResourceAssignment tra1 = tralist.get(0);
    TemplateResourceAssignment tra2 = tralist.get(1);

    return (tra1.getRestriction()
          && tra1.getAssignmentMode() == TemplateResourceAssignment.AssignmentModeEnum.O
          && !tra2.getRestriction()
          && tra2.getAssignmentMode() == TemplateResourceAssignment.AssignmentModeEnum.M)
        || (!tra1.getRestriction()
          && tra1.getAssignmentMode() == TemplateResourceAssignment.AssignmentModeEnum.M
          && tra2.getRestriction()
          && tra2.getAssignmentMode() == TemplateResourceAssignment.AssignmentModeEnum.O);
  }

  private List<Resource> getPackageTemplateResources(long packageTemplateId) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("packageTemplateAssignmentResources.packageTemplate.packageTemplateId",
        Pair.of(EnumQueryCriteria.EQUALS, packageTemplateId));
    fieldValueMap.put("packageTemplateAssignmentResources.assignmentType",
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, PackageAssignmentType.S.name()));
    Specification<Resource> spec = new Specification<>(fieldValueMap);

    return resourceRepository.findAll(spec);
  }

  protected void validateUpdateTemplateResourceAssignmentDto(UpdateTemplateResourceAssignment resourceAssignment, PackageTemplate packageTemplate) {
    if(resourceAssignment == null) {
      throw new FumValidationException(
          AuthorizationConstants.UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_NULL_CODE,
          AuthorizationConstants.UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_NULL_MESSAGE);
    }

    if (resourceAssignment.getResources() == null || resourceAssignment.getResources().isEmpty()) {
      throw new FumValidationException(
          AuthorizationConstants.UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_EMPTY_CODE,
          AuthorizationConstants.UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_EMPTY_MESSAGE);
    }

    resourceAssignment.getResources().forEach(
        resource -> {
          if (StringUtils.isEmpty(resource.getName())) {
            throw new FumValidationException(
                AuthorizationConstants.UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_RESOURCE_ID_NULL_CODE,
                AuthorizationConstants.UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_RESOURCE_ID_NULL_MESSAGE);
          }

          if (resource.getRestriction() == null) {
            throw new FumValidationException(
                AuthorizationConstants.UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_ASSIGNMENT_TYPE_NULL_CODE,
                AuthorizationConstants.UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_ASSIGNMENT_TYPE_NULL_MESSAGE);
          }

          if (resource.getAssignmentMode() == null) {
            throw new FumValidationException(
                AuthorizationConstants.UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_ASSIGNMENT_MODE_NULL_CODE,
                AuthorizationConstants.UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_ASSIGNMENT_MODE_NULL_MESSAGE);
          }

          if (resource.getSelectionDefault() == null) {
            throw new FumValidationException(
                AuthorizationConstants.UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_SELECTION_DEFAULT_NULL_CODE,
                AuthorizationConstants.UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_SELECTION_DEFAULT_NULL_MESSAGE);
          }
          // for user packages, if assignmentMode is O then selectionDefault should always be false
          if(PackageType.U.equals(packageTemplate.getType())
                  && TemplateResourceAssignment.AssignmentModeEnum.O.equals(resource.getAssignmentMode())
                  && Boolean.TRUE.equals(resource.getSelectionDefault())) {
            throw new FumValidationException(AuthorizationConstants.UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_RESOURCE_INCORRECT_INPUT,
                    String.format(AuthorizationConstants.UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_RESOURCE_INCORRECT_INPUT_MESSAGE, resource.getName()));
          }
        });
  }

  public boolean redisCacheEnabled() {
    return enableCache;
  }

}
