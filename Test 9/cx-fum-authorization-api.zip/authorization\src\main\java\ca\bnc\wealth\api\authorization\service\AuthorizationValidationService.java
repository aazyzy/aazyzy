package ca.bnc.wealth.api.authorization.service;

import ca.bnc.wealth.api.authorization.util.AuthorizationConstants;
import ca.bnc.wealth.common.authorization.model.FeaturePackageRequest;
import ca.bnc.wealth.common.authorization.model.PermissionInfo;
import ca.bnc.wealth.common.authorization.model.ResourceData;
import ca.bnc.wealth.common.authorization.model.Role;
import ca.bnc.wealth.common.authorization.model.UserGroup;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import java.util.Optional;
import java.util.regex.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class AuthorizationValidationService {

  public void validateRole(String capabilityCode, Role role) {
    if (role == null) {
      throw new FumValidationException(
          AuthorizationConstants.ROLE_NULL_CODE, AuthorizationConstants.ROLE_NULL_MESSAGE);
    }

    if (StringUtils.isEmpty(role.getRoleName())) {
      throw new FumValidationException(AuthorizationConstants.ROLE_NAME_NULL_CODE,
          AuthorizationConstants.ROLE_NAME_NULL_MESSAGE);
    }
    /** Disabling this check as soma scopes don't honor this naming pattern
    if (!Pattern.matches(String.format(AuthorizationConstants.ROLE_NAME_REGEX, capabilityCode),
        role.getRoleName())) {
      throw new FumValidationException(AuthorizationConstants.ROLE_NAME_INVALID_CODE,
          String.format(AuthorizationConstants.ROLE_NAME_INVALID_MESSAGE, capabilityCode));
    }
     */
  }

  public void validatePermission(PermissionInfo permission) {
    if (permission == null || StringUtils.isEmpty(permission.getName())) {
      throw new FumValidationException(
          AuthorizationConstants.PERMISSION_NULL_CODE,
          AuthorizationConstants.PERMISSION_NULL_MESSAGE);
    }

    if (StringUtils.isEmpty(permission.getDescription())) {
      throw new FumValidationException(
          AuthorizationConstants.PERMISSION_DESC_NULL_CODE,
          AuthorizationConstants.PERMISSION_DESC_NULL_MESSAGE);
    }

    if (!Pattern.matches(AuthorizationConstants.PERMISSION_NAME_REGEX, permission.getName())) {
      throw new FumValidationException(
          AuthorizationConstants.PERMISSION_INVALID_CODE,
          AuthorizationConstants.PERMISSION_NAME_INVALID_MESSAGE);
    }
  }

  public void validateUserGroup(UserGroup userGroup) {
    if (userGroup == null) {
      throw new FumValidationException(
          AuthorizationConstants.USER_GROUP_NULL_CODE,
          AuthorizationConstants.USER_GROUP_NULL_MESSAGE);
    }

    if (StringUtils.isEmpty(userGroup.getName())) {
      throw new FumValidationException(AuthorizationConstants.USER_GROUP_NAME_NULL_CODE,
          AuthorizationConstants.USER_GROUP_NAME_NULL_MESSAGE);
    }

    if (userGroup.getIsFirmScope() == null) {
      throw new FumValidationException(AuthorizationConstants.USER_GROUP_IS_FIRM_NULL_CODE,
          AuthorizationConstants.USER_GROUP_IS_FIRM_NULL_MESSAGE);
    }

    if (userGroup.getIsInternal() == null) {
      throw new FumValidationException(AuthorizationConstants.USER_GROUP_IS_INTERNAL_NULL_CODE,
          AuthorizationConstants.USER_GROUP_IS_INTERNAL_NULL_MESSAGE);
    }

    if (userGroup.getIsActive() == null) {
      throw new FumValidationException(AuthorizationConstants.USER_GROUP_IS_ACTIVE_NULL_CODE,
          AuthorizationConstants.USER_GROUP_IS_ACTIVE_NULL_MESSAGE);
    }
  }

  public void validateResourceForCreate(String resourceType, ResourceData resourceData) {
    Optional.ofNullable(resourceType).ifPresentOrElse(
        type -> {
          if (type.isBlank()) {
            throw new FumValidationException(
                AuthorizationConstants.RESOURCE_TYPE_EMPTY_CODE,
                AuthorizationConstants.RESOURCE_TYPE_EMPTY_MESSAGE);
          }
        }, () -> {
          throw new FumValidationException(
              AuthorizationConstants.RESOURCE_TYPE_NULL_CODE,
              AuthorizationConstants.RESOURCE_TYPE_NULL_MESSAGE);
        }
    );
    Optional.ofNullable(resourceData).ifPresentOrElse(
        info -> {
          Optional.ofNullable(info.getName()).ifPresentOrElse (
              name -> {
                if (name.isBlank()) {
                  throw new FumValidationException(
                      AuthorizationConstants.RESOURCE_NAME_EMPTY_CODE,
                      AuthorizationConstants.RESOURCE_NAME_EMPTY_MESSAGE);
                }
              }, () -> {
                throw new FumValidationException(
                    AuthorizationConstants.RESOURCE_NAME_NULL_CODE,
                    AuthorizationConstants.RESOURCE_NAME_NULL_MESSAGE);
              });
          Optional.ofNullable(info.getConfUri()).ifPresentOrElse (
              version -> {
                if (version.isBlank()) {
                  throw new FumValidationException(
                      AuthorizationConstants.RESOURCE_CONFURI_EMPTY_CODE,
                      AuthorizationConstants.RESOURCE_CONFURI_EMPTY_MESSAGE);
                }
              }, () -> {
                throw new FumValidationException(
                    AuthorizationConstants.RESOURCE_CONFURI_NULL_CODE,
                    AuthorizationConstants.RESOURCE_CONFURI_NULL_MESSAGE);
              });
          Optional.ofNullable(info.getVersion()).ifPresentOrElse (
              version -> {
                if (version.isBlank()) {
                  throw new FumValidationException(
                      AuthorizationConstants.RESOURCE_VERSION_EMPTY_CODE,
                      AuthorizationConstants.RESOURCE_VERSION_EMPTY_MESSAGE);
                }
              }, () -> {
                throw new FumValidationException(
                    AuthorizationConstants.RESOURCE_VERSION_NULL_CODE,
                    AuthorizationConstants.RESOURCE_VERSION_NULL_MESSAGE);
              });
        }, () -> {
          throw new FumValidationException(
              AuthorizationConstants.RESOURCE_INFO_NULL_CODE,
              AuthorizationConstants.RESOURCE_INFO_NULL_MESSAGE);
        }
    );
  }

  public void validateFeaturePackageMandatoryFields(FeaturePackageRequest featurePackageRequest) {
    if (featurePackageRequest == null) {
      throw new FumValidationException(
          AuthorizationConstants.FEATURE_PACKAGE_NULL_CODE,
          AuthorizationConstants.FEATURE_PACKAGE_NULL_MESSAGE);
    }

    if (featurePackageRequest.getPackageTemplateId() == null) {
      throw new FumValidationException(
          AuthorizationConstants.FEATURE_PACKAGE_TEMPLATE_NULL,
          AuthorizationConstants.FEATURE_PACKAGE_TEMPLATE_NULL_MESSAGE);
    }
  }

}
