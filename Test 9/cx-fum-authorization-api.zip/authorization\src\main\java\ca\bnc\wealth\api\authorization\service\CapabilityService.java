package ca.bnc.wealth.api.authorization.service;

import ca.bnc.wealth.api.authorization.util.AuthorizationConstants;
import ca.bnc.wealth.api.authorization.util.MapperUtils;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.iam.Capability;
import ca.bnc.wealth.common.jpa.entity.iam.Permission;
import ca.bnc.wealth.common.jpa.entity.iam.Role;
import ca.bnc.wealth.common.jpa.repo.iam.CapabilityRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PermissionRepository;
import ca.bnc.wealth.common.jpa.repo.iam.RoleRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class CapabilityService {

  @Autowired
  private CapabilityRepository capabilityRepository;

  @Autowired
  private PermissionRepository permissionRepository;

  @Autowired
  private RoleRepository roleRepository;

  public void deleteCapability(String capabilityName) {
    Capability capability = Optional.ofNullable(capabilityRepository.findFirstByName(capabilityName))
        .orElseThrow(
            () -> new FumNotFoundException(AuthorizationConstants.CAPABILITY_NOT_FOUND_CODE,
                String.format(AuthorizationConstants.CAPABILITY_NOT_FOUND_MESSAGE,capabilityName)));

    //Find if linked permissions exists
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("capability.name", Pair.of(EnumQueryCriteria.EQUALS, capability.getName()));
    Specification<Permission> spec = new Specification<>(fieldValueMap);
    List<Permission> lst1 = this.permissionRepository.findAll(spec);
    if (lst1.size() > 0) {
      log.error(String.format(
              AuthorizationConstants.HAS_FK_DEPENDENCY_MESSAGE,
              capability.getName(), "permissions"));
      throw new FumValidationException(
          AuthorizationConstants.HAS_FK_DEPENDENCY_CODE,
          String.format(
              AuthorizationConstants.HAS_FK_DEPENDENCY_MESSAGE,
              capability.getName(), "permissions"));
    }

    //Find if linked role exists
    fieldValueMap = new HashMap<>();
    fieldValueMap.put("capability.name", Pair.of(EnumQueryCriteria.EQUALS, capability.getName()));
    Specification<Role> spec1 = new Specification<>(fieldValueMap);
    List<Role> lst2 = this.roleRepository.findAll(spec1);
    if (lst2.size() > 0) {
      log.error(String.format(
              AuthorizationConstants.HAS_FK_DEPENDENCY_MESSAGE,
              capability.getName(), "role"));
      throw new FumValidationException(
              AuthorizationConstants.HAS_FK_DEPENDENCY_CODE,
              String.format(
                      AuthorizationConstants.HAS_FK_DEPENDENCY_MESSAGE,
                      capability.getName(), "role"));
    }

    capabilityRepository.delete(capability);
  }

  public ca.bnc.wealth.common.authorization.model.Capability createCapability(String idpSubject,
      ca.bnc.wealth.common.authorization.model.Capability capability) {
    if(!this.getCapability(capability).isEmpty()){
      log.error(String.format(
              AuthorizationConstants.CAPABILITY_EXISTS_MESSAGE,
              capability.getName()));
      throw new FumValidationException(
              AuthorizationConstants.CAPABILITY_EXISTS_CODE,
              String.format(
                      AuthorizationConstants.CAPABILITY_EXISTS_MESSAGE,
                      capability.getName()));
    }
    Capability capabilityEntity = MapperUtils.toEntity(capability);
    capabilityEntity.setCreatedBy(idpSubject);
    Capability saved = capabilityRepository.save(capabilityEntity);
    capability.setCapabilityID(saved.getCapabilityID());
    return capability;
  }

 public List<ca.bnc.wealth.common.authorization.model.Capability> getCapabilities() {
    List<Capability> capabilities = capabilityRepository.findAll();
    return capabilities.stream().map(MapperUtils::toDto).toList();
 }

 public List<Capability> getCapability(ca.bnc.wealth.common.authorization.model.Capability capability) {
   Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
   fieldValueMap.put("name", Pair.of(EnumQueryCriteria.EQUALS, capability.getName()));
   Specification<Capability> spec = new Specification<>(fieldValueMap);
   return capabilityRepository.findAll(spec);
 }
}
