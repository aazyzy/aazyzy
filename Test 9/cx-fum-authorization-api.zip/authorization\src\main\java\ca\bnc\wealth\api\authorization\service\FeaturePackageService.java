package ca.bnc.wealth.api.authorization.service;

import ca.bnc.wealth.api.authorization.util.AuthorizationConstants;
import ca.bnc.wealth.api.authorization.util.MapperUtils;
import ca.bnc.wealth.common.authorization.model.FeaturePackageCreateResponse;
import ca.bnc.wealth.common.authorization.model.FeaturePackageDetails;
import ca.bnc.wealth.common.authorization.model.FeaturePackageRequest;
import ca.bnc.wealth.common.authorization.model.GetFeaturePackage;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.fum.service.FeaturePackageServiceHelper;
import ca.bnc.wealth.common.fum.service.PackageTemplateServiceHelper;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackageAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackageAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
public class FeaturePackageService {


  @Autowired
  private FeaturePackageRepository featurePackageRepository;

  @Autowired
  private AuthorizationValidationService authorizationValidationService;

  @Autowired
  private PackageTemplateServiceHelper packageTemplateServiceHelper;

  @Autowired
  private FeaturePackageServiceHelper featurePackageServiceHelper;

  public FeaturePackageCreateResponse createFeaturePackage(FeaturePackageRequest featurePackageRequest, String idpSubject) {
    FeaturePackage response = null;
    if(StringUtils.isNotBlank(featurePackageRequest.getPackageName())) {
      response = featurePackageServiceHelper.createFeaturePackage(featurePackageRequest.getPackageName(), featurePackageRequest.getModuleOverrides(), featurePackageRequest.getFeatures(), idpSubject);
    } else {
      authorizationValidationService.validateFeaturePackageMandatoryFields(featurePackageRequest);

      List<Pair<Integer, Boolean>> assignmentSelectionPairList = new ArrayList<>();

      featurePackageRequest.getAssignments().forEach(assignments -> assignmentSelectionPairList.add(Pair.of(assignments.getAssignmentId(), assignments.getSelected())));
      response = featurePackageServiceHelper.createFeaturePackage(featurePackageRequest.getPackageTemplateId().longValue(), assignmentSelectionPairList, idpSubject);
    }

    FeaturePackageCreateResponse featurePackageCreateResponse = new FeaturePackageCreateResponse();
    featurePackageCreateResponse.setFeaturePackageId(response.getFeaturePackageId());
    return featurePackageCreateResponse;
  }

  @Transactional(rollbackFor = Exception.class)
  public void updateFeaturePackageAssignments(Integer featurePackageId, FeaturePackageRequest featurePackageRequest, String idpSubject) {
    authorizationValidationService.validateFeaturePackageMandatoryFields(featurePackageRequest);
    List<Pair<Integer, Boolean>> assignmentSelectionPairList = new ArrayList<>();

    featurePackageRequest.getAssignments().forEach(assignments -> assignmentSelectionPairList.add(Pair.of(assignments.getAssignmentId(), assignments.getSelected())));
    featurePackageServiceHelper.updateFeaturePackage(featurePackageId.longValue(), featurePackageRequest.getPackageTemplateId().longValue(), assignmentSelectionPairList, idpSubject);

  }

  public GetFeaturePackage getFeaturePackage(Integer featurePackageId, Boolean details) {
    FeaturePackage featurePackageEntity = featurePackageRepository.findById(
            Long.valueOf(featurePackageId))
        .orElseThrow(() -> new FumNotFoundException(AuthorizationConstants.FEATURE_PACKAGE_NOT_FOUND_CODE,
            String.format(AuthorizationConstants.FEATURE_PACKAGE_NOT_FOUND_MESSAGE, featurePackageId)));

    GetFeaturePackage output = MapperUtils.toDto(featurePackageEntity);

    if (details == null || !details) {
      return output;
    }

    List<FeaturePackageDetails> featurePackageDetails = new ArrayList<>();

    List<FeaturePackageAssignmentResource> fpars = featurePackageServiceHelper.getFeaturePackageAssignment(featurePackageId,
        PackageAssignmentType.S);
    Map<Long, PackageTemplateAssignmentResource> ptars = packageTemplateServiceHelper.getPackageTemplateAssignment(
        featurePackageEntity.getPackageTemplate().getPackageTemplateId(), PackageAssignmentType.S);

    fpars.forEach(fpar -> {
      FeaturePackageDetails featurePackageDetail = new FeaturePackageDetails();
      featurePackageDetail.setSelected(fpar.isSelected());
      PackageTemplateAssignmentResource ptar = ptars.get(fpar.getPackageTemplateAssignmentResource().getTemplateAssignmentId());
      featurePackageDetail.setTemplateDetailId(ptar.getTemplateAssignmentId());
      featurePackageDetail.setAssignmentType(MapperUtils.toEnum(ptar.getAssignmentType()));
      featurePackageDetail.setAssignmentMode(MapperUtils.toEnum(ptar.getAssignmentMode()));
      featurePackageDetail.setSelectionDefault(ptar.isSelectionDefault());
      featurePackageDetail.setResource(MapperUtils.toDto(ptar));
      featurePackageDetails.add(featurePackageDetail);
    });

    List<FeaturePackageAssignmentUserGroup> fpaugs = featurePackageServiceHelper.getFeaturePackageAssignment(featurePackageId,
        PackageAssignmentType.G);
    Map<Long, PackageTemplateAssignmentUserGroup> ptaugs = packageTemplateServiceHelper.getPackageTemplateAssignment(
        featurePackageEntity.getPackageTemplate().getPackageTemplateId(), PackageAssignmentType.G);
    fpaugs.forEach(fpaug -> {
      FeaturePackageDetails featurePackageDetail = new FeaturePackageDetails();
      featurePackageDetail.setSelected(fpaug.isSelected());
      PackageTemplateAssignmentUserGroup ptaug = ptaugs.get(fpaug.getPackageTemplateAssignmentUserGroup().getTemplateAssignmentId());
      featurePackageDetail.setTemplateDetailId(ptaug.getTemplateAssignmentId());
      featurePackageDetail.setAssignmentType(MapperUtils.toEnum(ptaug.getAssignmentType()));
      featurePackageDetail.setAssignmentMode(MapperUtils.toEnum(ptaug.getAssignmentMode()));
      featurePackageDetail.setSelectionDefault(ptaug.isSelectionDefault());
      featurePackageDetail.setUserGroup(MapperUtils.toDto(ptaug));
      featurePackageDetails.add(featurePackageDetail);
    });

    output.setDetails(featurePackageDetails);
    return output;
  }

}
