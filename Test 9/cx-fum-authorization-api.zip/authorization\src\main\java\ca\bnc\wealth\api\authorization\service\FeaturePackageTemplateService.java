package ca.bnc.wealth.api.authorization.service;

import ca.bnc.wealth.api.authorization.util.AuthorizationConstants;
import ca.bnc.wealth.api.authorization.util.MapperUtils;
import ca.bnc.wealth.common.authorization.model.PackageTemplate;
import ca.bnc.wealth.common.authorization.model.PackageTemplateDetails;
import ca.bnc.wealth.common.authorization.model.PackageTemplateDetails.AssignmentModeEnum;
import ca.bnc.wealth.common.authorization.model.PackageTemplateDetails.AssignmentTypeEnum;
import ca.bnc.wealth.common.authorization.model.UpdateFeaturePackageTemplate;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.fum.service.PackageTemplateServiceHelper;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

@Slf4j
@Service
public class FeaturePackageTemplateService {

  @Autowired
  private PackageTemplateRepository packageTemplateRepository;

  @Autowired
  private PackageTemplateServiceHelper packageTemplateServiceHelper;

  @Autowired
  private RedisCacheOperationService redisCacheOperationService;

  @Transactional
  public void updateFeaturePackageTemplate(
      String idpSubject, String template, UpdateFeaturePackageTemplate featurePackageTemplate) {
    ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate found = packageTemplateRepository.findByName(template)
        .orElseThrow( () ->
            new FumNotFoundException(
                AuthorizationConstants.FEATURE_PACKAGE_TEMPLATE_NOT_FOUND_CODE,
                String.format(
                    AuthorizationConstants.FEATURE_PACKAGE_TEMPLATE_NOT_FOUND_MESSAGE, template)));
    found.setName(featurePackageTemplate.getName());
    found.setDescription(featurePackageTemplate.getDescription());
    found.setActive(featurePackageTemplate.getStatus());
    found.setUpdateDate(new Timestamp(System.currentTimeMillis()));
    found.setUpdatedBy(idpSubject);
    log.info("updateFeaturePackageTemplate: updated template {} ", template);
    packageTemplateRepository.save(found);
    redisCacheOperationService.deleteCacheByCacheName(AuthorizationConstants.GET_TEMPLATE_CACHE_NAME);
  }

  public PackageTemplate createPackageTemplate(PackageTemplate packageTemplate) {
    ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate packageTemplateEntity
        = MapperUtils.toEntity(packageTemplate);

    Map<AssignmentTypeEnum, List<PackageTemplateDetails>> map = new HashMap<>();
    if(!CollectionUtils.isEmpty(packageTemplate.getDetails())) {
      map = packageTemplate.getDetails().stream().collect(
          Collectors.groupingBy(PackageTemplateDetails::getAssignmentType));
    }
    List<String> userGroup = Optional.ofNullable(map.get(AssignmentTypeEnum.G)).orElse(new ArrayList<>()).stream()
        .map(PackageTemplateDetails::getAssignee)
        .toList();

    List<Pair<Pair<String, Boolean>, Pair<PackageAssignmentMode, Boolean>>> resources = Optional.ofNullable(map.get(AssignmentTypeEnum.S)).orElse(new ArrayList<>()).stream()
        .map(ptd -> Pair.of(Pair.of(ptd.getAssignee(), ptd.getResource().getRestriction() != null ? ptd.getResource().getRestriction(): false),
            Pair.of(isAssignmentModeMandatory(ptd) ? PackageAssignmentMode.M : PackageAssignmentMode.O, isAssignmentModeMandatory(ptd) || ptd.getSelectionDefault())))
        .toList();

    ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate createdPackageTemplate = packageTemplateServiceHelper.createPackageTemplate(packageTemplateEntity, userGroup, resources);

    PackageTemplate savedPackageTemplate = new PackageTemplate();
    savedPackageTemplate.setPackageTemplateId(createdPackageTemplate.getPackageTemplateId());
    redisCacheOperationService.deleteCacheByCacheName(AuthorizationConstants.GET_TEMPLATE_CACHE_NAME);
    return savedPackageTemplate;
  }

  private boolean isAssignmentModeMandatory(PackageTemplateDetails details) {
    return details.getAssignmentMode() != null && details.getAssignmentMode() == AssignmentModeEnum.M;
  }

}