package ca.bnc.wealth.api.authorization.util;

public class AuthorizationConstants {

  public static final String GET_TEMPLATE_CACHE_NAME = "Authorization-API-GetTemplate-By-TemplateType";
  public static final String CAPABILITY_NOT_FOUND_CODE = "error.capability.notFound";
  public static final String CAPABILITY_NOT_FOUND_MESSAGE = "Capability %s not found";
  public static final String ROLE_NULL_CODE = "error.role.input.null";
  public static final String ROLE_NULL_MESSAGE = "Input is null";
  public static final String ROLE_NAME_NULL_CODE = "error.roleName.null";
  public static final String ROLE_NAME_NULL_MESSAGE = "Role name is null";
  public static final String ROLE_NOT_CREATED = "error.role.notCreated";
  public static final String ROLE_NOT_CREATED_MESSAGE =
      "Unable to create new role %s under capability %s";
  public static final String ROLE_EXISTS = "error.role.alreadyExists";
  public static final String ROLE_EXISTS_MESSAGE = "Role %s under capability %s already exists";
  public static final String ROLE_NOT_DELETED = "error.role.notDeleted";
  public static final String ROLE_NOT_DELETED_MESSAGE =
      "Unable to delete role %s under capability %s";
  public static final String ROLE_NOT_FOUND_CODE = "error.role.notFound";
  public static final String ROLE_NOT_FOUND_MESSAGE = "Role %s not found under capability %s";
  public static final String PERMISSION_NOT_FOUND_CODE = "error.permission.notFound";
  public static final String PERMISSION_NOT_FOUND_MESSAGE = "Permission %s not found under capability %s";
  public static final String PERMISSION_NULL_CODE = "error.permission.input.null";
  public static final String PERMISSION_NULL_MESSAGE = "Permission is null";
  public static final String PERMISSION_DESC_NULL_CODE = "error.permission.description.null";
  public static final String PERMISSION_DESC_NULL_MESSAGE = "Permission description is null";
  public static final String PERMISSION_INVALID_CODE = "error.permission.invalid";
  public static final String PERMISSION_NAME_REGEX = "^([\\w-]+):([\\w-]+)$";
  public static final String PERMISSION_NAME_INVALID_MESSAGE =
      "Permission must match [capability_code]:[permission]";
  public static final String PERMISSION_ALREADY_EXIST_CODE = "error.permission.exist";
  public static final String PERMISSION_ALREADY_EXIST_MESSAGE = "Permission %s already exist";
  public static final String PERMISSION_DOES_NOT_EXIST_MESSAGE = "Permission %s does not exist";
  public static final String PERMISSIONS_NOT_FOUND_CODE = "error.permissions.notFound";
  public static final String PERMISSIONS_NOT_FOUND_MESSAGE =
      "One or more permission %s not found under capability %s";
  public static final String USER_GROUP_NULL_CODE = "error.userGroup.input.null";
  public static final String USER_GROUP_NULL_MESSAGE = "Input is null";
  public static final String USER_GROUP_NAME_NULL_CODE = "error.userGroup.name.null";
  public static final String USER_GROUP_NAME_NULL_MESSAGE = "User Group name is null";
  public static final String USER_GROUP_IS_FIRM_NULL_CODE = "error.userGroup.isFirm.null";
  public static final String USER_GROUP_IS_FIRM_NULL_MESSAGE = "User Group isFirm is null";
  public static final String USER_GROUP_IS_INTERNAL_NULL_CODE = "error.userGroup.isInternal.null";
  public static final String USER_GROUP_IS_INTERNAL_NULL_MESSAGE = "User Group isInternal is null";
  public static final String USER_GROUP_ALREADY_EXIST_CODE = "error.userGroup.exist";
  public static final String USER_GROUP_ALREADY_EXIST_MESSAGE = "User Group %s already exist";
  public static final String USER_GROUP_HAS_ASSIGNMENT_CODE = "error.userGroup.hasAssignments";
  public static final String USER_GROUP_HAS_ASSIGNMENT_MESSAGE = "User Group %s has Assignments";
  public static final String USER_GROUP_NOT_EXIST_CODE = "error.userGroup.notExist";
  public static final String USER_GROUP_NOT_EXIST_MESSAGE = "User Group %s does not exists";
  public static final String ROLE_LIST_NOT_FOUND_CODE = "error.roleList.notExist";
  public static final String ROLE_LIST_NOT_FOUND_MESSAGE = "Some of Role %s not exist";
  public static final String USER_GROUP_IS_ACTIVE_NULL_CODE = "error.userGroup.isActive.null";
  public static final String USER_GROUP_IS_ACTIVE_NULL_MESSAGE = "User Group isActive is null";
  public static final String RESOURCE_ADD_INVALID_MESSAGE = "Resource %s with resource restriction %s is invalid, already exists";
  public static final String RESOURCE_INVALID_CODE = "resource.invalid";
  public static final String RESOURCE_DOES_NOT_EXIST_MESSAGE = "Resource %s with resource type %s does not exist";
  public static final String RESOURCE_TYPE_EMPTY_CODE = "error.resource.type.empty";
  public static final String RESOURCE_TYPE_EMPTY_MESSAGE = "Resource Type is Invalid";
  public static final String RESOURCE_INFO_NULL_CODE = "error.resource.info.null";
  public static final String RESOURCE_INFO_NULL_MESSAGE = "Resource Info is null";
  public static final String RESOURCE_NAME_EMPTY_CODE = "error.resource.name.empty";
  public static final String RESOURCE_NAME_EMPTY_MESSAGE = "Resource Name is empty";
  public static final String RESOURCE_NAME_NULL_CODE = "error.resource.name.null";
  public static final String RESOURCE_NAME_NULL_MESSAGE = "Resource Name is null";
  public static final String RESOURCE_TYPE_NULL_CODE = "error.resource.type.null";
  public static final String RESOURCE_TYPE_NULL_MESSAGE = "Resource type is null";
  public static final String RESOURCE_VERSION_EMPTY_CODE = "error.resource.version.empty";
  public static final String RESOURCE_VERSION_EMPTY_MESSAGE = "Resource Version is empty";
  public static final String RESOURCE_VERSION_NULL_CODE = "error.resource.version.null";
  public static final String RESOURCE_VERSION_NULL_MESSAGE = "Resource Version is null";
  public static final String RESOURCE_CONFURI_EMPTY_CODE = "error.resource.confuri.empty";
  public static final String RESOURCE_CONFURI_EMPTY_MESSAGE = "Resource Conf URI is empty";
  public static final String RESOURCE_CONFURI_NULL_CODE = "error.resource.confuri.null";
  public static final String RESOURCE_INPUT_INVALID_CODE = "error.resource.invalid.payload";
  public static final String RESOURCE_INPUT_INVALID_RESTRICTION_MESSAGE = "Only one restricted resource %s is provided.";
  public static final String RESOURCE_CONFURI_NULL_MESSAGE = "Resource Conf URI is null";
  public static final String FEATURE_PACKAGE_NULL_CODE = "error.featurePackage.input.null";
  public static final String FEATURE_PACKAGE_NULL_MESSAGE = "Input is null";
  public static final String FEATURE_PACKAGE_NOT_FOUND_CODE = "error.featurePackage.notFound";
  public static final String FEATURE_PACKAGE_NOT_FOUND_MESSAGE = "Feature Package %s not found";
  public static final String FEATURE_PACKAGE_TEMPLATE_NULL = "error.featurePackage.templateId.null";
  public static final String FEATURE_PACKAGE_TEMPLATE_NULL_MESSAGE = "Template Id is null";
  public static final String FEATURE_PACKAGE_TEMPLATE_NOT_FOUND_CODE = "error.feature.package.template.notFound";
  public static final String FEATURE_PACKAGE_TEMPLATE_NOT_FOUND_MESSAGE = "Feature Package Template %s not found";
  public static final String ASSIGNMENT_TYPE_RESOURCE = "S";
  public static final String ASSIGNMENT_TYPE_USERGROUP = "G";
  public static final String HAS_FK_DEPENDENCY_CODE = "error.hasFk.dependency";
  public static final String HAS_FK_DEPENDENCY_MESSAGE = "%s has linked foreign key dependencies on %s";
  public static final String CAPABILITY_EXISTS_CODE = "error.capability.exists";
  public static final String CAPABILITY_EXISTS_MESSAGE = "Capability %s already exists";
  public static final String RESOURCE_NOT_FOUND_CODE = "error.feature.resource.notFound";
  public static final String RESOURCE_NOT_FOUND_MESSAGE = "Resource %s not found";
  public static final String UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_NULL_CODE = "error.updateTemplateResourceAssignment.null";
  public static final String UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_NULL_MESSAGE = "Template Resource Assignment is null";
  public static final String UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_EMPTY_CODE = "error.updateTemplateResourceAssignment.empty";
  public static final String UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_EMPTY_MESSAGE = "Template Resource Assignment is empty";
  public static final String UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_RESOURCE_ID_NULL_CODE = "error.updateTemplateResourceAssignment.resourceId.null";
  public static final String UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_RESOURCE_ID_NULL_MESSAGE = "Resource Id is null";
  public static final String UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_ASSIGNMENT_TYPE_NULL_CODE = "error.updateTemplateResourceAssignment.assignmentType.null";
  public static final String UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_ASSIGNMENT_TYPE_NULL_MESSAGE = "Assignment Type is null";
  public static final String UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_ASSIGNMENT_MODE_NULL_CODE = "error.updateTemplateResourceAssignment.assignmentMode.null";
  public static final String UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_ASSIGNMENT_MODE_NULL_MESSAGE = "Assignment Mode is null";
  public static final String UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_SELECTION_DEFAULT_NULL_CODE = "error.updateTemplateResourceAssignment.selectionDefault.null";
  public static final String UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_SELECTION_DEFAULT_NULL_MESSAGE = "Selection Default is null";
  public static final String UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_RESOURCE_INCORRECT_INPUT = "error.updateTemplateResourceAssignment.resource.incorrectInput";
  public static final String UPDATE_TEMPLATE_RESOURCE_ASSIGNMENT_RESOURCE_INCORRECT_INPUT_MESSAGE = "selectionDefault should be false for assignmentMode O for resource %s";

  public static final String GET_ROLES_QUERY = """
    select
        distinct r1_0."ROLE_ID",
        r1_0."CAPABILITY",
        r1_0."CREATED_BY",
        r1_0."CREATED_DT",
        r1_0."NAME",
        r1_0."UPDATED_DT",
        r1_0."UPDATED_BY"
    from
        "IAM_V2"."ROLE" r1_0
    where
        r1_0."CAPABILITY"=:capability
    """;
  public static final String GET_PERMISSION_QUERY = """
    select
        distinct p1_0."PERMISSION_ID",
        p1_0."CAPABILITY",
        p1_0."CREATED_BY",
        p1_0."CREATED_DT",
        p1_0."DESCRIPTION",
        p1_0."ACTIVE",
        p1_0."NAME",
        p1_0."UPDATED_DT",
        p1_0."UPDATED_BY"
    from
        "IAM_V2"."PERMISSION" p1_0
    join
        "IAM_V2"."ROLE_ASSIGNMENT" r1_0
            on p1_0."PERMISSION_ID"=r1_0."PERMISSION_ID"
    join
        "IAM_V2"."ROLE" r2_0
            on r2_0."ROLE_ID"=r1_0."ROLE_ID"
    where
        r2_0."NAME"=:roleName
        and p1_0."CAPABILITY"=:capability
        and p1_0."ACTIVE"=:active
    """;
  public static final String GET_ROLES_FROM_USERGROUPLIST_QUERY = """
    select
        distinct r1_0."ROLE_ID",
        r1_0."CAPABILITY",
        r1_0."CREATED_BY",
        r1_0."CREATED_DT",
        r1_0."NAME",
        r1_0."UPDATED_DT",
        r1_0."UPDATED_BY"
    from
        "IAM_V2"."ROLE" r1_0
    join
        "IAM_V2"."CAPABILITY" c1_0
            on c1_0."NAME"=r1_0."CAPABILITY"
    join
        "IAM_V2"."USER_GROUP_ASSIGNMENT" u1_0
            on r1_0."ROLE_ID"=u1_0."ROLE_ID"
    join
        "IAM_V2"."USER_GROUP" u2_0
            on u2_0."USER_GROUP_ID"=u1_0."USER_GROUP_ID"
    where
        r1_0."CAPABILITY"=:capability
        and u2_0."NAME" in (:userGroupList)
      """;
  public static final String DECODE_RRCODE_QUERY = """
    select *
      from "IAM_V2".b36_decode(:rrCode);
  """;
  public static final String GET_RRCODE_BY_USER_AND_B10_QUERY = """
    select
        u1_0."USER_CONFIGURATION_ID",
        u1_0."ACTIVE",
        u1_0."CREATED_BY",
        u1_0."CREATION_DATE",
        u1_0."EMAIL",
        u1_0."FIRST_NAME",
        u1_0."IDP_SUBJECT",
        u1_0."IDP_USER_ID",
        u1_0."LAST_NAME",
        u1_0."LAST_UPDATE_DATE",
        u1_0."LAST_UPDATED_BY",
        u1_0."USERNAME",
        r1_0."RR_CODE_RANGE_ID",
        r1_0."FROM_RR_CODE",
        r1_0."TO_RR_CODE"
    from
        "IAM_V2"."USER_CONFIGURATION" u1_0
    join
        "IAM_V2"."USER_ASSIGNMENT" u2_0
            on u1_0."IDP_SUBJECT"=u2_0."IDP_SUBJECT"
    join
        "IAM_V2"."RR_CODE_RANGE" r1_0
            on u2_0."ASSIGNEE_ID"=r1_0."RR_CODE_RANGE_ID"
    where
        u1_0."IDP_SUBJECT" = :idpSubject
        and cast(u2_0."ASSIGNMENT_TYPE" as text) = :assignmentType
        and r1_0."ACTIVE" = :active
        and :rrCodeB10 between r1_0."FROM_RR_CODE_B10" and r1_0."TO_RR_CODE_B10"
  """;
  public static final String GET_RESOURCES_BY_RRCODE_QUERY = """
    select *
      from "IAM_V2".GET_RESOURCES_BY_RR_CODE(:rrCode, :resourceType)
  """;

  private AuthorizationConstants() {
    throw new IllegalStateException("Utility class");
  }
}
