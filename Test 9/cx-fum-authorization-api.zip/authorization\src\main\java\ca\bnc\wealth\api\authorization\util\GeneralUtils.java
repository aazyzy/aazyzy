package ca.bnc.wealth.api.authorization.util;

public class GeneralUtils {

    public static boolean isNumber(String string) {
        try {
            Integer.parseInt(string);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
