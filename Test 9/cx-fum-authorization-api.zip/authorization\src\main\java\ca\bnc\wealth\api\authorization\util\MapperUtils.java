package ca.bnc.wealth.api.authorization.util;

import ca.bnc.wealth.common.authorization.model.Capability;
import ca.bnc.wealth.common.authorization.model.FeaturePackageDetails;
import ca.bnc.wealth.common.authorization.model.GetFeaturePackage;
import ca.bnc.wealth.common.authorization.model.PackageTemplate;
import ca.bnc.wealth.common.authorization.model.PackageTemplate.TypeEnum;
import ca.bnc.wealth.common.authorization.model.PermissionInfo;
import ca.bnc.wealth.common.authorization.model.ResourceData;
import ca.bnc.wealth.common.authorization.model.ResourceEntitlement;
import ca.bnc.wealth.common.authorization.model.Role;
import ca.bnc.wealth.common.authorization.model.TemplateResourceAssignment.AssignmentModeEnum;
import ca.bnc.wealth.common.authorization.model.UserGroup;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.Permission;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class MapperUtils {

  public static PermissionInfo toDto(Permission permissionEntity) {
    PermissionInfo permission = new PermissionInfo();
    permission.setPermissionId(Long.toString(permissionEntity.getPermissionId()));
    permission.setName(permissionEntity.getName());
    permission.setCapability(permissionEntity.getCapability() != null ?
        permissionEntity.getCapability().getName() : null);
    permission.isActive(permissionEntity.isActive());
    return permission;
  }

  public static PermissionInfo toDto(Map<String, Object> permissionMap) {
    PermissionInfo permission = new PermissionInfo();
    permission.setPermissionId(String.valueOf(permissionMap.get("PERMISSION_ID")));
    permission.setName(String.valueOf(permissionMap.get("NAME")));
    permission.setCapability(String.valueOf(permissionMap.get("CAPABILITY")));
    permission.setIsActive((Boolean) permissionMap.get("ACTIVE"));
    return permission;
  }

  public static Permission toEntity(PermissionInfo permission) {
    Permission permissionEntity = new Permission();
    permissionEntity.setName(permission.getName());
    permissionEntity.setDescription(permission.getDescription());
    permissionEntity.setActive(permission.getIsActive() != null ? permission.getIsActive() : true);
    return permissionEntity;
  }


  public static PermissionInfo toPermissionInfo(Permission permission, String capability) {
    PermissionInfo permissionInfo = new PermissionInfo();
    permissionInfo.setName(permission.getName());
    permissionInfo.setCapability(Optional.ofNullable(capability).orElseGet(() -> permission.getCapability().getName()));
    permissionInfo.setDescription(permission.getDescription());
    permissionInfo.setIsActive(permission.isActive());

    return permissionInfo;
  }

  public static UserGroup toDto(ca.bnc.wealth.common.jpa.entity.iam.UserGroup userGroup) {
    UserGroup ug = new UserGroup();
    ug.setUserGroupId(userGroup.getUserGroupId());
    ug.setName(userGroup.getName());
    ug.setDescription(userGroup.getDescription());
    ug.setIsFirmScope(userGroup.getIsFirmScope());
    ug.setIsInternal(userGroup.getIsInternal());
    ug.setIsActive(userGroup.getIsActive());
    return ug;
  }

  public static Role toDto(ca.bnc.wealth.common.jpa.entity.iam.Role role) {
    Role r = new Role();
    r.setRoleName(role.getName());
    r.setCapability(role.getCapability().getName());
    r.setRoleId(String.valueOf(role.getRoleId()));
    if (role.getRolePermissionAssignments() != null) {
      List<PermissionInfo> permissionInfoList = new ArrayList<>();
      role.getRolePermissionAssignments().forEach(
          rolePermissionAssignment -> permissionInfoList.add(
              toDto(rolePermissionAssignment.getPermission())));
      r.setPermissions(permissionInfoList);
    }
    return r;
  }

  public static Role toRoleDto(Map<String, Object> roleMap) {
    Role r = new Role();
    r.setRoleName(String.valueOf(roleMap.get("NAME")));
    r.setCapability(String.valueOf(roleMap.get("CAPABILITY")));
    r.setRoleId(String.valueOf(roleMap.get("ROLE_ID")));
    return r;
  }

  public static ca.bnc.wealth.common.jpa.entity.iam.UserGroup toEntity(UserGroup userGroup) {
    ca.bnc.wealth.common.jpa.entity.iam.UserGroup entity = new ca.bnc.wealth.common.jpa.entity.iam.UserGroup();
    entity.setName(userGroup.getName());
    entity.setDescription(userGroup.getDescription());
    entity.setIsInternal(userGroup.getIsInternal());
    entity.setIsFirmScope(userGroup.getIsFirmScope());
    entity.setIsActive(userGroup.getIsActive());
    return entity;
  }

  public static ResourceData toDto(Resource resource) {
    return ResourceData.builder()
        .resourceId(resource.getResourceId())
        .name(resource.getName())
        .description(resource.getDescription())
        .active(resource.isActive())
        .confUri(resource.getConfUri())
        .version(resource.getVersion())
        .groupName(resource.getGroupName())
        .label(resource.getLabel())
        .purpose(resource.getPurpose())
        .restriction(resource.getRestriction())
        .build();
  }

  public static ResourceData toResourceDataDto(Map<String, Object> resourceMap) {
    return ResourceData.builder()
        .name(String.valueOf(resourceMap.get("NAME")))
        .description(String.valueOf(resourceMap.get("DESCRIPTION")))
        .active((Boolean) resourceMap.get("ACTIVE"))
        .confUri(String.valueOf(resourceMap.get("CONF_URI")))
        .version(String.valueOf(resourceMap.get("VERSION")))
        .groupName(String.valueOf(resourceMap.get("GROUP_NAME")))
        .label(String.valueOf(resourceMap.get("LABEL")))
        .purpose(String.valueOf(resourceMap.get("PURPOSE")))
        .build();
  }

  public static ResourceEntitlement toResourceEntitlement(Resource resource) {
    return ResourceEntitlement.builder()
        .resourceId(resource.getResourceId())
        .resourceType(resource.getType())
        .resourceName(resource.getName())
        .description(resource.getDescription())
        .active(resource.isActive())
        .confUri(resource.getConfUri())
        .version(resource.getVersion())
        .groupName(resource.getGroupName())
        .label(resource.getLabel())
        .purpose(resource.getPurpose())
        .restriction(resource.getRestriction())
        .build();
  }

  public static ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate toEntity(
      PackageTemplate packageTemplate) {
    ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate packageTemplateEntity
        = new ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate();
    packageTemplateEntity.setName(packageTemplate.getName());
    packageTemplateEntity.setDescription(packageTemplate.getDescription());
    packageTemplateEntity.setActive(packageTemplate.getActive());
    packageTemplateEntity.setFirmType(FirmType.valueOf(packageTemplate.getFirmType()));
    packageTemplateEntity.setType(packageTemplate.getType() != null ?
        packageTemplate.getType() == TypeEnum.FIRM ? PackageType.F : PackageType.U : null);
    return packageTemplateEntity;
  }

  public static PackageTemplate toDto(
      ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate packageTemplateEntity) {
    PackageTemplate packageTemplate = new PackageTemplate();
    packageTemplate.setName(packageTemplateEntity.getName());
    packageTemplate.setDescription(packageTemplateEntity.getDescription());
    packageTemplate.setActive(packageTemplateEntity.isActive());
    packageTemplate.setFirmType(packageTemplateEntity.getFirmType().name());
    packageTemplate.setType(packageTemplateEntity.getType() != null ?
        packageTemplateEntity.getType() == PackageType.F ? TypeEnum.FIRM : TypeEnum.USER : null);
    return packageTemplate;
  }

  public static GetFeaturePackage toDto(FeaturePackage featurePackageEntity) {
    PackageTemplate packageTemplate = toDto(featurePackageEntity.getPackageTemplate());
    GetFeaturePackage featurePackage = new GetFeaturePackage();
    featurePackage.setPackageTemplateId(featurePackageEntity.getPackageTemplate().getPackageTemplateId());
    featurePackage.setName(packageTemplate.getName());
    featurePackage.setDescription(packageTemplate.getDescription());
    featurePackage.setType(packageTemplate.getType() != null ?
        (packageTemplate.getType() == TypeEnum.FIRM ? GetFeaturePackage.TypeEnum.FIRM
            : GetFeaturePackage.TypeEnum.USER) : null);
    featurePackage.setFirmType(packageTemplate.getFirmType());
    featurePackage.setActive(featurePackageEntity.isActive());
    return featurePackage;
  }

  public static ca.bnc.wealth.common.authorization.model.Resource toDto(
      PackageTemplateAssignmentResource ptar) {
    ca.bnc.wealth.common.authorization.model.Resource resource = new ca.bnc.wealth.common.authorization.model.Resource();
    if (ptar.getResource() == null) {
      return resource;
    }

    Resource resourceEntity = ptar.getResource();
    resource.setResourceId(resourceEntity.getResourceId());
    resource.setName(resourceEntity.getName());
    resource.setDescription(resourceEntity.getDescription());
    resource.setType(resourceEntity.getType());
    resource.setGroup(resourceEntity.getGroupName());
    resource.setLabel(resourceEntity.getLabel());
    resource.setPurpose(resourceEntity.getPurpose());
    resource.setRestriction(resourceEntity.getRestriction());
    return resource;
  }

  public static UserGroup toDto(PackageTemplateAssignmentUserGroup ptaug) {
    UserGroup userGroup = new UserGroup();
    if (ptaug.getUserGroup() == null) {
      return userGroup;
    }

    userGroup.setUserGroupId(ptaug.getUserGroup().getUserGroupId());
    userGroup.setName(ptaug.getUserGroup().getName());
    userGroup.setDescription(ptaug.getUserGroup().getDescription());
    userGroup.setIsFirmScope(ptaug.getUserGroup().getIsFirmScope());
    userGroup.setIsInternal(ptaug.getUserGroup().getIsInternal());
    return userGroup;
  }

  public static Capability toDto(ca.bnc.wealth.common.jpa.entity.iam.Capability _capability) {
    Capability capability = new Capability();
    capability.setCapabilityID(_capability.getCapabilityID());
    capability.setName(_capability.getName());
    capability.setLob(_capability.getLob());
    return capability;
  }

  public static ca.bnc.wealth.common.jpa.entity.iam.Capability toEntity(Capability capability) {
    ca.bnc.wealth.common.jpa.entity.iam.Capability capabilityEntity = new ca.bnc.wealth.common.jpa.entity.iam.Capability();
    capabilityEntity.setName(capability.getName());
    capabilityEntity.setDescription(capability.getDescription());
    capabilityEntity.setLob(capability.getLob());
    capabilityEntity.setCreationDate(new Timestamp(System.currentTimeMillis()));
    return capabilityEntity;
  }

  public static FeaturePackageDetails.AssignmentModeEnum toEnum(
      PackageAssignmentMode packageAssignmentMode) {
    return packageAssignmentMode != null ?
        (packageAssignmentMode == PackageAssignmentMode.M
            ? FeaturePackageDetails.AssignmentModeEnum.M
            : FeaturePackageDetails.AssignmentModeEnum.O) : null;
  }

  public static FeaturePackageDetails.AssignmentTypeEnum toEnum(
      PackageAssignmentType packageAssignmentType) {
    return packageAssignmentType != null ?
        (packageAssignmentType == PackageAssignmentType.G
            ? FeaturePackageDetails.AssignmentTypeEnum.G
            : FeaturePackageDetails.AssignmentTypeEnum.S) : null;
  }

  public static Resource toEntity(ResourceData resourceData) {
    Resource resource = new Resource();
    resource.setName(resourceData.getName());
    resource.setDescription(resourceData.getDescription());
    resource.setActive(resourceData.getActive());
    resource.setConfUri(resourceData.getConfUri());
    resource.setVersion(resourceData.getVersion());
    resource.setGroupName(resourceData.getGroupName());
    resource.setLabel(resourceData.getLabel());
    resource.setPurpose(resourceData.getPurpose());
    resource.setRestriction(resourceData.getRestriction());
    return resource;
  }

  public static PackageAssignmentMode toEnum(AssignmentModeEnum assignmentModeEnum) {
    return assignmentModeEnum != null ?
        (assignmentModeEnum == AssignmentModeEnum.M
            ? PackageAssignmentMode.M
            : PackageAssignmentMode.O) : null;
  }
}