package ca.bnc.wealth.api.authorization.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestConfiguration {

  public static void main(String[] args) {
    SpringApplication.run(TestConfiguration.class, args);
  }
}
