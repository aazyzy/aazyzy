package ca.bnc.wealth.api.authorization.controller;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ca.bnc.wealth.api.authorization.security.SecurityConfigAdapter;
import ca.bnc.wealth.api.authorization.security.test.TestAuthConfiguration;
import ca.bnc.wealth.api.authorization.service.AuthorizationServiceJpa;
import ca.bnc.wealth.api.authorization.utility.MockData;
import ca.bnc.wealth.common.authorization.model.UserGroup;
import tools.jackson.databind.ObjectMapper;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@ContextConfiguration(
    classes = {
        SecurityConfigAdapter.class,
        TestAuthConfiguration.class,
        GroupController.class,
        ca.bnc.wealth.common.exception.handler.ServiceExceptionHandler.class,
        ca.bnc.wealth.common.spring.microservice.starter.core.exception.GlobalDefaultExceptionHandler
            .class
    })
@WebMvcTest(properties = {"spring.profiles.active=test"})
public class GroupControllerTest {

  private static final String ACCESS_TOKEN =
      "Bearer eyJraWQiOiJRdUZPcVhpYkwwYjc0emltbDNaYmU5NnNPWEpJMlNpRGR4ZThkZThlZG13IiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULjVfcTQwRlY2OHM3TlJSX1pQTERFLTdyemtNYmFIZnVLdjV1cnVGSVNDQjAiLCJpc3MiOiJodHRwczovL2F1dGgtcHAubmJpbi5jYS9vYXV0aDIvYXVzc2c0d3lkMkhaRUJHUjMwaDciLCJhdWQiOiJhcGk6Ly9kZWZhdWx0IiwiaWF0IjoxNjQ1MjgxMzc3LCJleHAiOjE2NDUyODE2NzcsImNpZCI6IjBvYTEwcmd6cThyTDNsQ1pHMGg4IiwidWlkIjoiMDB1MTRxa3BlZDNPSFZ5Qk0waDgiLCJzY3AiOlsiY2lhbTpwcm9maWxlczp3cml0ZSIsIndlYWx0aDphY2Nlc3MtY29udHJvbDp2aWV3ZXIiLCJvcGVuaWQiLCJjaWFtOnByb2ZpbGVzOnJlYWQiXSwic3ViIjoiMG9hMTByZ3pxOHJMM2xDWkcwaDgiLCJwcmVmZXJyZWRMYW5ndWFnZSI6ImVuIiwiYm5nZlNlY3VyZVpvbmVJZCI6WyJKT05FU01BIl0sImJuZ2ZJZGVudGl0eVNvdXJjZSI6IlNaIiwiYm5nZlBhcnRuZXJJZCI6IklBUyIsImdyb3VwcyI6WyJXZWFsdGguQ29tcGFzc1giLCJXZWFsdGguQ29tcGFzc1guVHJhZGVyIiwiV2VhbHRoIl19.dADByl5zkW4QP0WU3DhIdgPI9hipdYbDFnok8csB__a2_hqbHvFVWjD5BHEtNKOgSQVZ0L4sZazHPl0VlNOP8kArBWg80nx35ufYeXkrYGvT-1RK99KAZnhgnIQ77eSg-Ubb2ujbcx5cTiiFOKbeNLCK7UUSC7WHhzLMP39iXDhBIPfy3zI6NI-YfYgFVHzkbnNK-UpLZ09rq7hJMSJuef6P6xreooGXxenFIQHQAGhHTJPxBU85rG6cNLUbNrLG8mpQIgliDft5mZ7nNtZAq7o8DD0TGVNj4fUUyayb40WVmBOx0di6EHsfBnFQ8qtHGaT-hT7z8G-yX_V2NkmGbQ";
  @Autowired
  private MockMvc mockMvc;
  @Autowired
  private WebApplicationContext context;

  @Autowired
  private ObjectMapper objectMapper;

  @MockitoBean
  private AuthorizationServiceJpa authorizationService;

  @Before
  public void setup() {
//    mockMvc = MockMvcBuilders.webAppContextSetup(context).apply(springSecurity()).build();
    mockMvc = MockMvcBuilders.webAppContextSetup(context).apply(springSecurity()).build();
  }

  @Test
  public void testGetAllGroups() throws Exception {
    List<UserGroup> userGroupList = MockData.createUserGroupList();
    when(authorizationService.getAllUserGroups()).thenReturn(userGroupList);
    MvcResult mvcResult =
        this.mockMvc
            .perform(get("/access-control/groups").header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void testGetGroupsMe() throws Exception {
    List<UserGroup> userGroupList = MockData.createUserGroupList();
    when(authorizationService.getGroupsMe(anyString())).thenReturn(userGroupList);
    MvcResult mvcResult =
        this.mockMvc
            .perform(get("/access-control/groups/me").header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void testCreateGroup() throws Exception {
    UserGroup userGroup = MockData.createUserGroup();
    when(authorizationService.createUserGroup(anyString(), any())).thenReturn(userGroup);
    MvcResult mvcResult =
        mockMvc
            .perform(post("/access-control/groups")
                .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(userGroup)))
            .andExpect(status().isCreated())
            .andReturn();
    assertNotNull(mvcResult);

    // TODO: fix it.
//    UserGroup actualUserGroupOutput = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
//        UserGroup.class);
//    assertEquals(userGroup.getUserGroupId(), actualUserGroupOutput.getUserGroupId());
  }

  @Test
  public void testDeleteUserGroup() throws Exception {
    doNothing().when(authorizationService).deleteUserGroup(anyString());
    MvcResult mvcResult =
        mockMvc
            .perform(delete("/access-control/groups/1234")
                .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void testUpdateUserGroup() throws Exception {
    UserGroup userGroup = MockData.createUserGroup();
    when(authorizationService.updateUserGroup(anyString(), anyString(), any())).thenReturn(userGroup);
    MvcResult mvcResult =
        mockMvc
            .perform(put("/access-control/groups/1234")
                .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(userGroup)))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);

    // TODO: fix it.
//    UserGroup actualUserGroupOutput = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
//        UserGroup.class);
//    assertEquals(userGroup.getUserGroupId(), actualUserGroupOutput.getUserGroupId());
  }

  @Test
  public void testAddUserGroupAndRoleAssignment() throws Exception {
    List<String> roles = Arrays.asList("wealth");
    doNothing().when(authorizationService).addUserGroupAndRoleAssignment(anyString(), anyString(), anyList());
    MvcResult mvcResult =
        mockMvc
            .perform(post("/access-control/groups/1234/assignments/role")
                .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(roles)))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void testDeleteUserGroupAndRoleAssignment() throws Exception {
    doNothing().when(authorizationService).deleteUserGroupAndRoleAssignment(anyString());
    MvcResult mvcResult =
        mockMvc
            .perform(delete("/access-control/groups/1234/assignments/role")
                .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

}
