package ca.bnc.wealth.api.authorization.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ca.bnc.wealth.api.authorization.security.SecurityConfigAdapter;
import ca.bnc.wealth.api.authorization.security.test.TestAuthConfiguration;
import ca.bnc.wealth.api.authorization.security.test.TestUserSingleton;
import ca.bnc.wealth.api.authorization.service.AuthorizationServiceJpa;
import ca.bnc.wealth.api.authorization.utility.MockData;
import ca.bnc.wealth.common.authorization.model.ResourceData;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@ContextConfiguration(
    classes = {
        SecurityConfigAdapter.class,
        TestAuthConfiguration.class,
        ResourceController.class,
        ca.bnc.wealth.common.spring.microservice.starter.core.exception.GlobalDefaultExceptionHandler
            .class
    })
@WebMvcTest(properties = {"spring.profiles.active=test"})
public class ResourceControllerTest {

  String accessToken =
      "Bearer eyJraWQiOiJRdUZPcVhpYkwwYjc0emltbDNaYmU5NnNPWEpJMlNpRGR4ZThkZThlZG13IiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULjVfcTQwRlY2OHM3TlJSX1pQTERFLTdyemtNYmFIZnVLdjV1cnVGSVNDQjAiLCJpc3MiOiJodHRwczovL2F1dGgtcHAubmJpbi5jYS9vYXV0aDIvYXVzc2c0d3lkMkhaRUJHUjMwaDciLCJhdWQiOiJhcGk6Ly9kZWZhdWx0IiwiaWF0IjoxNjQ1MjgxMzc3LCJleHAiOjE2NDUyODE2NzcsImNpZCI6IjBvYTEwcmd6cThyTDNsQ1pHMGg4IiwidWlkIjoiMDB1MTRxa3BlZDNPSFZ5Qk0waDgiLCJzY3AiOlsiY2lhbTpwcm9maWxlczp3cml0ZSIsIndlYWx0aDphY2Nlc3MtY29udHJvbDp2aWV3ZXIiLCJvcGVuaWQiLCJjaWFtOnByb2ZpbGVzOnJlYWQiXSwic3ViIjoiMG9hMTByZ3pxOHJMM2xDWkcwaDgiLCJwcmVmZXJyZWRMYW5ndWFnZSI6ImVuIiwiYm5nZlNlY3VyZVpvbmVJZCI6WyJKT05FU01BIl0sImJuZ2ZJZGVudGl0eVNvdXJjZSI6IlNaIiwiYm5nZlBhcnRuZXJJZCI6IklBUyIsImdyb3VwcyI6WyJXZWFsdGguQ29tcGFzc1giLCJXZWFsdGguQ29tcGFzc1guVHJhZGVyIiwiV2VhbHRoIl19.dADByl5zkW4QP0WU3DhIdgPI9hipdYbDFnok8csB__a2_hqbHvFVWjD5BHEtNKOgSQVZ0L4sZazHPl0VlNOP8kArBWg80nx35ufYeXkrYGvT-1RK99KAZnhgnIQ77eSg-Ubb2ujbcx5cTiiFOKbeNLCK7UUSC7WHhzLMP39iXDhBIPfy3zI6NI-YfYgFVHzkbnNK-UpLZ09rq7hJMSJuef6P6xreooGXxenFIQHQAGhHTJPxBU85rG6cNLUbNrLG8mpQIgliDft5mZ7nNtZAq7o8DD0TGVNj4fUUyayb40WVmBOx0di6EHsfBnFQ8qtHGaT-hT7z8G-yX_V2NkmGbQ";
  String path = "/access-control/resources/{resource-type}/assignments/users/me";
  @Autowired
  private WebApplicationContext context;
  @Autowired
  private MockMvc mockMvc;
  @MockitoBean
  private AuthorizationServiceJpa authorizationService;
  @Autowired
  private ObjectMapper objectMapper;

  @Before
  public void setup() {
    mockMvc = MockMvcBuilders.webAppContextSetup(context).apply(springSecurity()).build();
  }

  @Test
  public void testValid() throws Exception {
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get(path, "moe", "cx_ui_module").header(HttpHeaders.AUTHORIZATION, accessToken))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void testUnauthorized() throws Exception {
    TestUserSingleton.USER_IS_UNAUTHORIZED = true;
    MvcResult mvcResult =
        this.mockMvc
            .perform(get(path, "moe", "cx_ui_module"))
            .andExpect(status().isUnauthorized())
            .andReturn();
  }

  @Test
  public void testInvalid() throws Exception {
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get(path + "/notFound", "moe", "test")
                    .header(HttpHeaders.AUTHORIZATION, accessToken))
            .andExpect(status().isNotFound())
            .andReturn();
  }

  @Test
  public void testCreateResource() throws Exception {
    TestUserSingleton.setTestUser(MockData.getUser());

    String resourceType = "test_type";
    ResourceData expectedResourceOutput = MockData.getResourceData();

    when(authorizationService.createResource(anyString(), anyString(), any())).thenReturn(
        expectedResourceOutput);

    MvcResult mvcResult =
        mockMvc
            .perform(post("/access-control/resources/" + resourceType)
                .header(HttpHeaders.AUTHORIZATION, accessToken)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(MockData.getResourceData())))
            .andExpect(status().isCreated())
            .andReturn();

    ResourceData actualResourceOutput = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
        ResourceData.class);

    assertEquals(expectedResourceOutput.getName(), actualResourceOutput.getName());
  }

  @Test
  public void testDeleteResource() throws Exception {
    doNothing().when(authorizationService).deleteResource(anyString(), anyString());

    MvcResult mvcResult =
        mockMvc
            .perform(delete("/access-control/resources/resource-type/1234")
                .header(HttpHeaders.AUTHORIZATION, accessToken)
                .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent())
            .andReturn();
  }

  @Test
  public void testUpdateResource() throws Exception {
    doNothing().when(authorizationService).deleteResource(anyString(), anyString());

    MvcResult mvcResult =
        mockMvc
            .perform(patch("/access-control/resources/resource-type/1234")
                .header(HttpHeaders.AUTHORIZATION, accessToken)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(MockData.getResourceData())))
            .andExpect(status().isNoContent())
            .andReturn();
  }

  @Test
  public void testGetResource() throws Exception {
    List<ResourceData> resourceDataList = Arrays.asList(MockData.getResourceData());
    doReturn(resourceDataList).when(authorizationService)
        .getResourceByResourceType(anyString());

    MvcResult mvcResult =
        mockMvc
            .perform(get("/access-control/resources/resource-type")
                .header(HttpHeaders.AUTHORIZATION, accessToken)
                .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();

    List<ResourceData> actualResourceDataOutput = objectMapper.readerForListOf(ResourceData.class)
        .readValue(mvcResult.getResponse().getContentAsString());

    assertEquals(resourceDataList.get(0).getName(), actualResourceDataOutput.get(0).getName());
  }

  @Test
  public void testGetResourceByName() throws Exception {
    ResourceData mockResourceData = MockData.getResourceData();
    doReturn(mockResourceData).when(authorizationService).getResourceByTypeAndName(anyString(), anyString());

    MvcResult mvcResult =
        mockMvc
            .perform(get("/access-control/resources/resource-type/testResource")
                .header(HttpHeaders.AUTHORIZATION, accessToken)
                .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();

    ResourceData actualResourceOutput = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
        ResourceData.class);

    assertEquals(mockResourceData.getName(), actualResourceOutput.getName());
  }

  @Test
  public void testGetResourceByResourceTypeAndRrCode() throws Exception {
    ResourceData mockResourceData = MockData.getResourceData();
    doReturn(List.of(mockResourceData)).when(authorizationService).getResourceByResourceTypeAndRrCode(anyString(), anyString(), any());

    MvcResult mvcResult =
        mockMvc
            .perform(get("/access-control/resources/resourceType/assignments/firm/rrCode")
                .header(HttpHeaders.AUTHORIZATION, accessToken)
                .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();

    List<ResourceData> actualResourceOutput = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), new TypeReference<>() {});
    assertFalse(actualResourceOutput.isEmpty());
    assertEquals(mockResourceData.getName(), actualResourceOutput.get(0).getName());
    assertEquals(mockResourceData.getDescription(), actualResourceOutput.get(0).getDescription());
    assertEquals(mockResourceData.getActive(), actualResourceOutput.get(0).getActive());
    assertEquals(mockResourceData.getVersion(), actualResourceOutput.get(0).getVersion());
    assertEquals(mockResourceData.getConfUri(), actualResourceOutput.get(0).getConfUri());
    assertEquals(mockResourceData.getGroupName(), actualResourceOutput.get(0).getGroupName());
    assertEquals(mockResourceData.getLabel(), actualResourceOutput.get(0).getLabel());
    assertEquals(mockResourceData.getPurpose(), actualResourceOutput.get(0).getPurpose());
  }
}
