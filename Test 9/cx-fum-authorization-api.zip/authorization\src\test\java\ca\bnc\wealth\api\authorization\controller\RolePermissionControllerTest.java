package ca.bnc.wealth.api.authorization.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ca.bnc.wealth.api.authorization.security.SecurityConfigAdapter;
import ca.bnc.wealth.api.authorization.security.test.TestAuthConfiguration;
import ca.bnc.wealth.api.authorization.security.test.TestUserSingleton;
import ca.bnc.wealth.api.authorization.service.AuthorizationServiceJpa;
import ca.bnc.wealth.api.authorization.utility.MockData;
import ca.bnc.wealth.common.authorization.model.PermissionInfo;
import ca.bnc.wealth.common.authorization.model.Role;
import ca.bnc.wealth.common.authorization.model.TogglePermission;
import ca.bnc.wealth.common.authorization.model.UserGroup;
import ca.bnc.wealth.common.exception.Entity.ErrorMessage;
import ca.bnc.wealth.common.exception.Entity.Errors;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import tools.jackson.databind.ObjectMapper;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@ContextConfiguration(
    classes = {
        SecurityConfigAdapter.class,
        TestAuthConfiguration.class,
        RolePermissionController.class,
        GroupController.class,
        ca.bnc.wealth.common.exception.handler.ServiceExceptionHandler.class,
        ca.bnc.wealth.common.spring.microservice.starter.core.exception.GlobalDefaultExceptionHandler
            .class
    })
@WebMvcTest(properties = {"spring.profiles.active=test"})
public class RolePermissionControllerTest {

  private static final String ACCESS_TOKEN =
      "Bearer eyJraWQiOiJRdUZPcVhpYkwwYjc0emltbDNaYmU5NnNPWEpJMlNpRGR4ZThkZThlZG13IiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULjVfcTQwRlY2OHM3TlJSX1pQTERFLTdyemtNYmFIZnVLdjV1cnVGSVNDQjAiLCJpc3MiOiJodHRwczovL2F1dGgtcHAubmJpbi5jYS9vYXV0aDIvYXVzc2c0d3lkMkhaRUJHUjMwaDciLCJhdWQiOiJhcGk6Ly9kZWZhdWx0IiwiaWF0IjoxNjQ1MjgxMzc3LCJleHAiOjE2NDUyODE2NzcsImNpZCI6IjBvYTEwcmd6cThyTDNsQ1pHMGg4IiwidWlkIjoiMDB1MTRxa3BlZDNPSFZ5Qk0waDgiLCJzY3AiOlsiY2lhbTpwcm9maWxlczp3cml0ZSIsIndlYWx0aDphY2Nlc3MtY29udHJvbDp2aWV3ZXIiLCJvcGVuaWQiLCJjaWFtOnByb2ZpbGVzOnJlYWQiXSwic3ViIjoiMG9hMTByZ3pxOHJMM2xDWkcwaDgiLCJwcmVmZXJyZWRMYW5ndWFnZSI6ImVuIiwiYm5nZlNlY3VyZVpvbmVJZCI6WyJKT05FU01BIl0sImJuZ2ZJZGVudGl0eVNvdXJjZSI6IlNaIiwiYm5nZlBhcnRuZXJJZCI6IklBUyIsImdyb3VwcyI6WyJXZWFsdGguQ29tcGFzc1giLCJXZWFsdGguQ29tcGFzc1guVHJhZGVyIiwiV2VhbHRoIl19.dADByl5zkW4QP0WU3DhIdgPI9hipdYbDFnok8csB__a2_hqbHvFVWjD5BHEtNKOgSQVZ0L4sZazHPl0VlNOP8kArBWg80nx35ufYeXkrYGvT-1RK99KAZnhgnIQ77eSg-Ubb2ujbcx5cTiiFOKbeNLCK7UUSC7WHhzLMP39iXDhBIPfy3zI6NI-YfYgFVHzkbnNK-UpLZ09rq7hJMSJuef6P6xreooGXxenFIQHQAGhHTJPxBU85rG6cNLUbNrLG8mpQIgliDft5mZ7nNtZAq7o8DD0TGVNj4fUUyayb40WVmBOx0di6EHsfBnFQ8qtHGaT-hT7z8G-yX_V2NkmGbQ";
  @Autowired
  private MockMvc mockMvc;
  @Autowired
  private WebApplicationContext context;
  @Autowired
  private ObjectMapper objectMapper;
  @MockitoBean
  private AuthorizationServiceJpa authorizationService;

  @Before
  public void setup() {
    mockMvc = MockMvcBuilders.webAppContextSetup(context).apply(springSecurity()).build();
  }

  @Test
  public void test_getRoles() throws Exception {
    List<PermissionInfo> permissionList = MockData.createMockPermisionList();
    when(authorizationService.getRolePermissions(anyString(), anyList())).thenReturn(
        permissionList);
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get("/access-control/capabilities/{capability}/roles", "mf-orders")
                    .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_getRolesAssignments() throws Exception {
    List<PermissionInfo> permissionAssignmentList = MockData.createPermissionAssignments();
    List<String> roles = MockData.createRoles();
    when(authorizationService.getRolePermissions("aom", roles))
        .thenReturn(permissionAssignmentList);
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get(
                    "/access-control/capabilities/{capability}/roles/assignments/users/me",
                    "mf-orders")
                    .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_getRolePermissions() throws Exception {
    List<Role> roleList = MockData.createMockRoleList();
    when(authorizationService.getRoles(anyString(), anyBoolean())).thenReturn(roleList);
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get(
                    "/access-control/capabilities/{capability}/permissions/assignments/users/me",
                    "mf-orders")
                    .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_userHasPermissionSuccessful() throws Exception {
    List<PermissionInfo> lst = MockData.createMockPermission();
    when(authorizationService.getRolePermissions(anyString(), any())).thenReturn(lst);
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get(
                    "/access-control/capabilities/{capability}/permissions/assignments/users/me/{permission}",
                    "mf-orders", "access-control:list_roles")
                    .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_userHasPermissionFailed() throws Exception {
    List<PermissionInfo> lst = MockData.createMockPermission();
    when(authorizationService.getRolePermissions(anyString(), anyList()))
        .thenReturn(lst);
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get(
                    "/access-control/capabilities/{capability}/permissions/assignments/users/me/{permission}",
                    "mf-orders", "access-control:list_firms")
                    .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN))
            .andExpect(status().isForbidden())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_getRolesAssignmentsMe() throws Exception {
    List<Role> roles = MockData.createMockRoleList();
    when(authorizationService.getRoles("moe", false)).thenReturn(roles);
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get("/access-control/capabilities/{capability}/scopes/me", "mf-orders")
                    .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_Unauthorized() throws Exception {
    TestUserSingleton.USER_IS_UNAUTHORIZED = true;
    MvcResult mvcResult =
        this.mockMvc
            .perform(get("/access-control/capabilities/{capability}/scopes/me", "moe"))
            .andExpect(status().isUnauthorized())
            .andReturn();
  }

  @Test
  public void test_Invalid() throws Exception {
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get("/access-control/capabilities/{capability}/scopes/notFound", "moe")
                    .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN))
            .andExpect(status().isNotFound())
            .andReturn();
  }

  @Test
  public void test_getAllRoles() throws Exception {
    List<UserGroup> userGroupList = MockData.createUserGroupList();
    when(authorizationService.getAllUserGroups()).thenReturn(userGroupList);
    MvcResult mvcResult =
        this.mockMvc
            .perform(get("/access-control/groups").header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_createRole() throws Exception {
    TestUserSingleton.setTestUser(MockData.getUser());

    String capability = "abm";
    Role expectedRoleOutput = MockData.getRole();
    expectedRoleOutput.setRoleId("1234");
    expectedRoleOutput.setCapability(capability);

    when(authorizationService.createRole(anyString(), anyString(), any())).thenReturn(
        expectedRoleOutput);

    MvcResult mvcResult =
        mockMvc
            .perform(post("/access-control/capabilities/" + capability + "/roles")
                .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(MockData.getRole())))
            .andExpect(status().isCreated())
            .andReturn();

    Role actualRoleOutput = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
        Role.class);

    assertEquals(expectedRoleOutput.getRoleId(), actualRoleOutput.getRoleId());
    assertEquals(expectedRoleOutput.getRoleName(), actualRoleOutput.getRoleName());
    assertEquals(expectedRoleOutput.getCapability(), actualRoleOutput.getCapability());
  }

  @Test
  public void test_createRole_whenInvalidCapabilityCode() throws Exception {
    TestUserSingleton.setTestUser(MockData.getUser());

    String errorCode = "error.code";
    String errorMessage = "error message";
    when(authorizationService.createRole(anyString(), anyString(), any())).thenThrow(
        new FumNotFoundException(errorCode, errorMessage));

    MvcResult mvcResult =
        mockMvc
            .perform(post("/access-control/capabilities/invalid/roles")
                .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(MockData.getRole())))
            .andExpect(status().isNotFound())
            .andReturn();

    ErrorMessage errorOutput = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
        ErrorMessage.class);
    validateErrorMessage(HttpStatus.NOT_FOUND, errorCode, errorMessage, errorOutput);
  }

  @Test
  public void test_createRole_whenInvalidRoleName() throws Exception {
    TestUserSingleton.setTestUser(MockData.getUser());

    String errorCode = "error.invalid";
    String errorMessage = "error invalid field";
    when(authorizationService.createRole(anyString(), anyString(), any())).thenThrow(
        new FumValidationException(errorCode, errorMessage));

    Role role = MockData.getRole();
    role.setRoleName("invalid");

    MvcResult mvcResult =
        mockMvc
            .perform(post("/access-control/capabilities/abm/roles")
                .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(role)))
            .andExpect(status().isBadRequest())
            .andReturn();

    ErrorMessage errorOutput = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
        ErrorMessage.class);
    validateErrorMessage(HttpStatus.BAD_REQUEST, errorCode, errorMessage, errorOutput);
  }

  @Test
  public void test_deleteRole() throws Exception {
    doNothing().when(authorizationService).deleteRole(anyString(), anyString());
    MvcResult mvcResult =
        mockMvc
            .perform(delete("/access-control/capabilities/capability/roles/role")
                .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent())
            .andReturn();
  }

  @Test
  public void test_deleteRolePermission() throws Exception {
    doNothing().when(authorizationService).deleteRolePermission(anyString(), anyString());
    MvcResult mvcResult =
        mockMvc
            .perform(delete("/access-control/capabilities/capability/roles/role/assignments/permission")
                .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent())
            .andReturn();
  }

  @Test
  public void test_updateRolePermission() throws Exception {
    TestUserSingleton.setTestUser(MockData.getUser());

    String capability = "abm";
    Role expectedRoleOutput = MockData.getRole();
    expectedRoleOutput.setRoleId("1234");
    expectedRoleOutput.setCapability(capability);

    when(authorizationService.updateRolePermission(anyString(), anyString(), anyString(), anyList())).thenReturn(
        expectedRoleOutput);

    MvcResult mvcResult =
        mockMvc
            .perform(post("/access-control/capabilities/capability/roles/role/assignments/permission")
                .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(Arrays.asList("permission"))))
            .andExpect(status().isOk())
            .andReturn();

    Role actualRoleOutput = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
        Role.class);

    assertEquals(expectedRoleOutput.getRoleId(), actualRoleOutput.getRoleId());
    assertEquals(expectedRoleOutput.getRoleName(), actualRoleOutput.getRoleName());
    assertEquals(expectedRoleOutput.getCapability(), actualRoleOutput.getCapability());
  }

  @Test
  public void test_createPermission() throws Exception {
    TestUserSingleton.setTestUser(MockData.getUser());

    PermissionInfo expectedPermissionOutput = MockData.createPermissionInfoList().get(0);

    when(authorizationService.createPermission(anyString(), anyString(), any())).thenReturn(
        expectedPermissionOutput);

    MvcResult mvcResult =
        mockMvc
            .perform(
                post("/access-control/capabilities/capability/permissions")
                    .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(
                        MockData.createPermissionInfoList().get(0))))
            .andExpect(status().isCreated())
            .andReturn();

    PermissionInfo actualPermissionOutput = objectMapper.readValue(
        mvcResult.getResponse().getContentAsString(),
        PermissionInfo.class);

    assertEquals(expectedPermissionOutput.getPermissionId(),
        actualPermissionOutput.getPermissionId());
    assertEquals(expectedPermissionOutput.getName(),
        actualPermissionOutput.getName());
  }

  @Test
  public void test_createPermission_whenPermissionInvalid() throws Exception {
    TestUserSingleton.setTestUser(MockData.getUser());

    String errorCode = "error.invalid";
    String errorMessage = "error invalid field";
    when(authorizationService.createPermission(anyString(), anyString(), any())).thenThrow(
        new FumValidationException(errorCode, errorMessage));

    MvcResult mvcResult =
        mockMvc
            .perform(post("/access-control/capabilities/capability/permissions")
                .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON)
                .content(
                    objectMapper.writeValueAsString(MockData.createPermissionInfoList().get(0))))
            .andExpect(status().isBadRequest())
            .andReturn();

    ErrorMessage errorOutput = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
        ErrorMessage.class);
    validateErrorMessage(HttpStatus.BAD_REQUEST, errorCode, errorMessage, errorOutput);
  }

  @Test
  public void test_deletePermission() throws Exception {
    TestUserSingleton.setTestUser(MockData.getUser());

    doNothing().when(authorizationService).deletePermission(anyString(), anyString());

    MvcResult mvcResult =
        mockMvc
            .perform(
                delete("/access-control/capabilities/capability/permissions/capability:permission")
                    .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(MockData.getRole())))
            .andExpect(status().isNoContent())
            .andReturn();
  }

  @Test
  public void test_deletePermission_whenPermissionIsInvalid() throws Exception {
    TestUserSingleton.setTestUser(MockData.getUser());

    String errorCode = "error.invalid";
    String errorMessage = "error invalid field";

    doThrow(new FumValidationException(errorCode, errorMessage)).when(authorizationService)
        .deletePermission(anyString(), anyString());

    MvcResult mvcResult =
        mockMvc
            .perform(delete("/access-control/capabilities/capability/permissions/invalid")
                .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(MockData.getRole())))
            .andExpect(status().isBadRequest())
            .andReturn();

    ErrorMessage errorOutput = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
        ErrorMessage.class);
    validateErrorMessage(HttpStatus.BAD_REQUEST, errorCode, errorMessage, errorOutput);
  }

  @Test
  public void test_getPermission() throws Exception {
    PermissionInfo expectedPermission = MockData.createMockPermission().get(0);
    doReturn(expectedPermission).when(authorizationService).getPermission(anyString(), anyString());

    MvcResult mvcResult =
        mockMvc
            .perform(
                get("/access-control/capabilities/capability/permissions/permission")
                    .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();

    PermissionInfo actualPermissionOutput = objectMapper.readValue(
        mvcResult.getResponse().getContentAsString(),
        PermissionInfo.class);

    assertEquals(expectedPermission.getPermissionId(), actualPermissionOutput.getPermissionId());
    assertEquals(expectedPermission.getName(), actualPermissionOutput.getName());
  }

  @Test
  public void test_togglePermission() throws Exception {
    doNothing().when(authorizationService).togglePermission(anyString(), anyString(), anyBoolean());
    TogglePermission togglePermission = new TogglePermission();
    togglePermission.active(true);

    MvcResult mvcResult =
        mockMvc
            .perform(patch("/access-control/capabilities/capability/permissions/permission")
                .header(HttpHeaders.AUTHORIZATION, ACCESS_TOKEN)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(togglePermission)))
            .andExpect(status().isOk())
            .andReturn();

    String actualMessage = mvcResult.getResponse().getContentAsString();
    assertEquals("Permission permission is activated successfully.", actualMessage);
  }

  private void validateErrorMessage(HttpStatus status, String code, String message,
      ErrorMessage errorMessage) {
    assertEquals(status.name(), errorMessage.getTitle());
    assertEquals(status.getReasonPhrase(), errorMessage.getDescription());
    assertEquals(String.valueOf(status.value()), errorMessage.getHttpCode());
    assertTrue(errorMessage.getMessages().getErrors().length > 0);

    Errors error = errorMessage.getMessages().getErrors()[0];
    assertEquals(code, error.getCode());
    assertNull(error.getField());
    assertEquals(message, error.getMessage());
  }
}
