package ca.bnc.wealth.api.authorization.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.service.AuthorizationServiceJpa;
import ca.bnc.wealth.common.authorization.model.Role;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

@ExtendWith(MockitoExtension.class)
class RolePermissionControllerUserGroupsTest {

  private static final String CAPABILITY = "aom";

  @Mock private AuthorizationServiceJpa authorizationServiceJpa;

  @Captor private ArgumentCaptor<List<String>> userGroupCaptor;

  @AfterEach
  void clearContext() {
    SecurityContextHolder.clearContext();
  }

  private RolePermissionController controllerFor(List<String> groups, boolean employeeToken) {
    User user = new User();
    user.setGroups(groups);
    user.setEmployeeToken(employeeToken);
    SecurityContextHolder.getContext()
        .setAuthentication(new UsernamePasswordAuthenticationToken(user, null, List.of()));
    return new RolePermissionController(authorizationServiceJpa);
  }

  @Test
  void getRolesAssignmentsMe_employeeToken_addsBareGroupNameAlias() {
    RolePermissionController controller =
        controllerFor(
            List.of("Wealth.CompassX", "07641-NPR-ACC-Wealth.CompassX.AdminAll", "Wealth"), true);
    when(authorizationServiceJpa.getUserRoles(anyString(), any(), any())).thenReturn(List.of());

    controller.getRolesAssignmentsMe("Bearer token", CAPABILITY);

    verify(authorizationServiceJpa).getUserRoles(anyString(), userGroupCaptor.capture(), any());
    assertEquals(
        List.of(
            "Wealth.CompassX",
            "07641-NPR-ACC-Wealth.CompassX.AdminAll",
            "Wealth.CompassX.AdminAll",
            "Wealth"),
        userGroupCaptor.getValue());
  }

  @Test
  void getRolesAssignmentsMe_externalToken_leavesGroupsUntouched() {
    RolePermissionController controller =
        controllerFor(List.of("Wealth.CompassX", "Wealth.CompassX.Trader"), false);
    when(authorizationServiceJpa.getUserRoles(anyString(), any(), any()))
        .thenReturn(List.of(new Role()));

    controller.getRolesAssignmentsMe("Bearer token", CAPABILITY);

    verify(authorizationServiceJpa).getUserRoles(anyString(), userGroupCaptor.capture(), any());
    assertEquals(
        List.of("Wealth.CompassX", "Wealth.CompassX.Trader"), userGroupCaptor.getValue());
  }

  @Test
  void getRolesAssignmentsMe_employeeTokenWithoutPrefixedGroups_leavesGroupsUntouched() {
    RolePermissionController controller =
        controllerFor(List.of("Wealth.CompassX", "2442_DWH_Firm360_ADM"), true);
    when(authorizationServiceJpa.getUserRoles(anyString(), any(), any())).thenReturn(List.of());

    controller.getRolesAssignmentsMe("Bearer token", CAPABILITY);

    verify(authorizationServiceJpa).getUserRoles(anyString(), userGroupCaptor.capture(), any());
    assertEquals(
        List.of("Wealth.CompassX", "2442_DWH_Firm360_ADM"), userGroupCaptor.getValue());
  }

  @Test
  void getRolesAssignmentsMe_employeeToken_skipsBlankEntriesAndPrefixOnlyGroups() {
    List<String> groups = new ArrayList<>();
    groups.add("07641-NPR-ACC-Wealth.CompassX.AdminAll");
    groups.add(null);
    groups.add("  ");
    groups.add("07641-NPR-ACC-");
    RolePermissionController controller = controllerFor(groups, true);
    when(authorizationServiceJpa.getUserRoles(anyString(), any(), any())).thenReturn(List.of());

    controller.getRolesAssignmentsMe("Bearer token", CAPABILITY);

    verify(authorizationServiceJpa).getUserRoles(anyString(), userGroupCaptor.capture(), any());
    assertEquals(
        List.of(
            "07641-NPR-ACC-Wealth.CompassX.AdminAll",
            "Wealth.CompassX.AdminAll",
            "07641-NPR-ACC-"),
        userGroupCaptor.getValue());
  }

  @Test
  void userHasPermissions_employeeToken_addsBareGroupNameAlias() {
    RolePermissionController controller =
        controllerFor(List.of("07641-PRD-ACC-Wealth.CompassX.AdminAll"), true);
    when(authorizationServiceJpa.getRolePermissions(anyString(), any())).thenReturn(List.of());

    controller.userHasPermissions("Bearer token", CAPABILITY, "aom:view");

    verify(authorizationServiceJpa).getRolePermissions(anyString(), userGroupCaptor.capture());
    assertEquals(
        List.of("07641-PRD-ACC-Wealth.CompassX.AdminAll", "Wealth.CompassX.AdminAll"),
        userGroupCaptor.getValue());
  }

  @Test
  void getRolePermissions_employeeToken_addsBareGroupNameAlias() {
    RolePermissionController controller =
        controllerFor(
            List.of("Wealth.CompassX", "07641-NPR-ACC-Wealth.CompassX.AdminAll"), true);
    when(authorizationServiceJpa.getRolePermissions(anyString(), any())).thenReturn(List.of());

    controller.getRolePermissions("Bearer token", CAPABILITY);

    verify(authorizationServiceJpa).getRolePermissions(anyString(), userGroupCaptor.capture());
    assertEquals(
        List.of(
            "Wealth.CompassX",
            "07641-NPR-ACC-Wealth.CompassX.AdminAll",
            "Wealth.CompassX.AdminAll"),
        userGroupCaptor.getValue());
  }

  @Test
  void getRolePermissions_employeeTokenWithDuplicateGroups_deduplicatesAliases() {
    RolePermissionController controller =
        controllerFor(
            List.of(
                "07641-NPR-ACC-Wealth.CompassX.AdminAll",
                "07641-PRD-ACC-Wealth.CompassX.AdminAll",
                "Wealth.CompassX.AdminAll"),
            true);
    when(authorizationServiceJpa.getRolePermissions(anyString(), any())).thenReturn(List.of());

    controller.getRolePermissions("Bearer token", CAPABILITY);

    verify(authorizationServiceJpa).getRolePermissions(anyString(), userGroupCaptor.capture());
    assertEquals(
        List.of(
            "07641-NPR-ACC-Wealth.CompassX.AdminAll",
            "Wealth.CompassX.AdminAll",
            "07641-PRD-ACC-Wealth.CompassX.AdminAll"),
        userGroupCaptor.getValue());
  }
}
