package ca.bnc.wealth.api.authorization.kafka;

import static org.mockito.Mockito.*;

import ca.bnc.wealth.common.kafka.model.EventMessages;
import ca.bnc.wealth.common.kafka.model.audit.AuditUserConfigPayLoad;
import ca.bnc.wealth.common.messenger.Messenger;
import ca.bnc.wealth.common.messenger.model.KafkaMessage;
import tools.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@ExtendWith(MockitoExtension.class)
public class AuditLogEventPublisherTests {
  @MockitoBean
  private ObjectMapper objectMapper;

  @Mock
  private Messenger messager;

  private AuditLogEventPublisher auditLogEventPublisher;

  @SneakyThrows
  @Before
  public void setUp() {
    MockitoAnnotations.openMocks(this);
    auditLogEventPublisher = new AuditLogEventPublisher();
    FieldUtils.writeField(auditLogEventPublisher, "objectMapper", objectMapper, true);
    FieldUtils.writeField(auditLogEventPublisher, "messager", messager, true);
  }

  @Test
  public void testPublish_successful() throws Exception {

    EventMessages<AuditUserConfigPayLoad> eventMessages = new EventMessages<>();
    KafkaMessage kafkaMessage = KafkaMessage.builder().message("testMessage").key("key").build();
    when(objectMapper.writeValueAsString(eventMessages)).thenReturn("testMessage");


    auditLogEventPublisher.publish(eventMessages);
    verify(objectMapper, times(1)).writeValueAsString(eventMessages);
  }

  @Test
  public void testPublish_exceptionHandling() throws Exception {
    // Arrange
    EventMessages<AuditUserConfigPayLoad> eventMessages = new EventMessages<>();
    when(objectMapper.writeValueAsString(eventMessages)).thenThrow(new RuntimeException("Serialization error"));

    // Act
    auditLogEventPublisher.publish(eventMessages);

    // Assert
    verify(messager, never()).process(any());
  }
}
