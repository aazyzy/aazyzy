package ca.bnc.wealth.api.authorization.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.kafka.AuditLogEventPublisher;
import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class AuditLogServiceTests {

  @MockitoBean private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @MockitoBean private AuditLogEventPublisher auditLogEventPublisher;

  @MockitoBean private AuthorizationServiceJpa authorizationServiceJpa;

  private AuditLogService auditLogService;

  @SneakyThrows
  @Before
  public void setup() {
    auditLogService = new AuditLogService();
    FieldUtils.writeField(
        auditLogService, "namedParameterJdbcTemplate", namedParameterJdbcTemplate, true);
    FieldUtils.writeField(auditLogService, "auditLogEventPublisher", auditLogEventPublisher, true);
    FieldUtils.writeField(auditLogService, "enableUserConfigAudit", true, true);
    FieldUtils.writeField(auditLogService, "auditBatchSize", 1, true);
    FieldUtils.writeField(auditLogService, "authorizationServiceJpa", authorizationServiceJpa, true);
  }

  @Test
  public void publishAuditLog_create() {
    Map<String, Object> map = new HashMap<>();
    List<Map<String, Object>> lst = new ArrayList<>();
    lst.add(map);
    map.put("USER_CONFIGURATION_ID", 123);
    map.put("IDP_SUBJECT", "idpSubject");

    PackageTemplate packageTemplate = new PackageTemplate();
    packageTemplate.setType(PackageType.U);
    when(authorizationServiceJpa.getPackageTemplateEntity(anyString())).thenReturn(packageTemplate);
    when(namedParameterJdbcTemplate.queryForList(any(String.class), any(MapSqlParameterSource.class)))
        .thenReturn(lst);
    when(namedParameterJdbcTemplate.queryForObject(
            any(String.class), any(MapSqlParameterSource.class), any(Class.class)))
        .thenReturn("idpSubject|r2|r2|r3|");
    auditLogService.publishUpdateTemplateResourcesAuditLog(
        "NBIN",
        () -> {});
    verify(namedParameterJdbcTemplate, times(2)).queryForObject(any(String.class), any(MapSqlParameterSource.class), any(Class.class));
  }


}
