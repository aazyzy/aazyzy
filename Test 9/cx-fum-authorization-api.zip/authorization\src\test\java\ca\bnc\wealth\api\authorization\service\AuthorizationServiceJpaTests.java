package ca.bnc.wealth.api.authorization.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.util.AuthorizationConstants;
import ca.bnc.wealth.api.authorization.utility.MockData;
import ca.bnc.wealth.common.authorization.model.ActionType;
import ca.bnc.wealth.common.authorization.model.PackageTemplate;
import ca.bnc.wealth.common.authorization.model.PermissionInfo;
import ca.bnc.wealth.common.authorization.model.ResourceData;
import ca.bnc.wealth.common.authorization.model.ResourceEntitlement;
import ca.bnc.wealth.common.authorization.model.TemplateResourceAssignment;
import ca.bnc.wealth.common.authorization.model.TemplateType;
import ca.bnc.wealth.common.authorization.model.UpdateTemplateResourceAssignment;
import ca.bnc.wealth.common.exception.Entity.FumConflictException;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.service.PackageTemplateServiceHelper;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.entity.iam.Capability;
import ca.bnc.wealth.common.jpa.entity.iam.Permission;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.entity.iam.Role;
import ca.bnc.wealth.common.jpa.entity.iam.UserGroup;
import ca.bnc.wealth.common.jpa.repo.iam.CapabilityRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PermissionRepository;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.RolePermissionAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.RoleRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserGroupRoleAssignmentRepository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class AuthorizationServiceJpaTests {

  private AuthorizationServiceJpa authorizationServiceJpa;

  @MockitoBean
  private UserGroupRepository userGroupRepository;

  @MockitoBean
  private ResourceRepository resourceRepository;

  @MockitoBean
  private PermissionRepository permissionRepository;

  @MockitoBean
  private RoleRepository roleRepository;

  @MockitoBean
  private CapabilityRepository capabilityRepository;

  @MockitoBean
  private AuthorizationValidationService authorizationValidationService;

  @MockitoBean
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @MockitoBean
  private PackageTemplateRepository packageTemplateRepository;

  @MockitoBean
  private RolePermissionAssignmentRepository rolePermissionAssignmentRepository;

  @MockitoBean
  private UserGroupRoleAssignmentRepository userGroupRoleAssignmentRepository;

  @MockitoBean
  private PackageTemplateAssignmentUserGroupRepository packageTemplateAssignmentUserGroupRepository;

  @MockitoBean
  private PackageTemplateAssignmentResourceRepository packageTemplateAssignmentResourceRepository;

  @MockitoBean
  private UserAssignmentUserGroupRepository userAssignmentUserGroupRepository;

  @MockitoBean
  private RedisCacheOperationService redisCacheOperationService;

  @MockitoBean
  private PackageTemplateServiceHelper packageTemplateServiceHelper;

  @SneakyThrows
  @Before
  public void setup() {
    authorizationServiceJpa = new AuthorizationServiceJpa();
    FieldUtils.writeField(authorizationServiceJpa, "userGroupRepository", userGroupRepository,
        true);
    FieldUtils.writeField(authorizationServiceJpa, "resourceRepository", resourceRepository,
        true);
    FieldUtils.writeField(authorizationServiceJpa, "permissionRepository", permissionRepository,
        true);
    FieldUtils.writeField(authorizationServiceJpa, "roleRepository", roleRepository, true);
    FieldUtils.writeField(authorizationServiceJpa, "capabilityRepository", capabilityRepository,
        true);
    FieldUtils.writeField(authorizationServiceJpa, "authorizationValidationService",
        authorizationValidationService, true);
    FieldUtils.writeField(authorizationServiceJpa, "namedParameterJdbcTemplate",
        namedParameterJdbcTemplate, true);
    FieldUtils.writeField(authorizationServiceJpa, "packageTemplateRepository",
        packageTemplateRepository, true);
    FieldUtils.writeField(authorizationServiceJpa, "rolePermissionAssignmentRepository",
        rolePermissionAssignmentRepository, true);
    FieldUtils.writeField(authorizationServiceJpa, "userGroupRoleAssignmentRepository",
        userGroupRoleAssignmentRepository, true);
    FieldUtils.writeField(authorizationServiceJpa, "packageTemplateAssignmentUserGroupRepository",
        packageTemplateAssignmentUserGroupRepository, true);
    FieldUtils.writeField(authorizationServiceJpa, "userAssignmentUserGroupRepository",
        userAssignmentUserGroupRepository, true);
    FieldUtils.writeField(authorizationServiceJpa, "packageTemplateAssignmentResourceRepository",
        packageTemplateAssignmentResourceRepository, true);
    FieldUtils.writeField(authorizationServiceJpa, "redisCacheOperationService",
        redisCacheOperationService, true);
    FieldUtils.writeField(authorizationServiceJpa, "packageTemplateServiceHelper",
        packageTemplateServiceHelper, true);
  }

  @Test
  public void getAllUserGroups() {
    UserGroup userGroup = new UserGroup();
    userGroup.setName("usergroup");
    when(userGroupRepository.findAll()).thenReturn(List.of(userGroup));
    List<ca.bnc.wealth.common.authorization.model.UserGroup> lst = authorizationServiceJpa.getAllUserGroups();

    assertEquals(1, lst.size());
    assertEquals("usergroup", lst.get(0).getName());
    // assert immutable
    ca.bnc.wealth.common.authorization.model.UserGroup newUserGroup = new ca.bnc.wealth.common.authorization.model.UserGroup();
    assertThrows(UnsupportedOperationException.class, () -> lst.add(newUserGroup));
  }


  @Test
  public void getRolesIncludePermissions() {
    Role role = MockData.getRoleEntity();
    Map<String, Object> roleMap = MockData.getRoleMap();
    when(namedParameterJdbcTemplate.queryForList(eq(AuthorizationConstants.GET_ROLES_QUERY),
        any(SqlParameterSource.class))).thenReturn(List.of(roleMap));

    Map<String, Object> permissionMap = Map.of("PERMISSION_ID", 2,
        "CAPABILITY", role.getCapability().getName(),
        "NAME", "permission",
        "ACTIVE", true);
    when(namedParameterJdbcTemplate.queryForList(eq(AuthorizationConstants.GET_PERMISSION_QUERY),
        any(SqlParameterSource.class))).thenReturn(List.of(permissionMap));

    List<ca.bnc.wealth.common.authorization.model.Role> lst = authorizationServiceJpa.getRoles(
        "code", true);
    assertEquals(1, lst.size());
    assertEquals(String.valueOf(role.getRoleId()), lst.get(0).getRoleId());
    assertEquals(role.getName(), lst.get(0).getRoleName());
    assertEquals(role.getCapability().getName(), lst.get(0).getCapability());
    assertEquals(1, lst.get(0).getPermissions().size());
    assertEquals(String.valueOf(permissionMap.get("PERMISSION_ID")),
        lst.get(0).getPermissions().get(0).getPermissionId());
    assertEquals(permissionMap.get("NAME"), lst.get(0).getPermissions().get(0).getName());
    assertEquals(permissionMap.get("CAPABILITY"),
        lst.get(0).getPermissions().get(0).getCapability());
    assertEquals(permissionMap.get("ACTIVE"), lst.get(0).getPermissions().get(0).getIsActive());
  }

  @Test
  public void getRolesWithoutPermissions() {
    Role role = MockData.getRoleEntity();
    Map<String, Object> roleMap = MockData.getRoleMap();
    when(namedParameterJdbcTemplate.queryForList(any(), any(SqlParameterSource.class)))
        .thenReturn(List.of(roleMap));

    List<ca.bnc.wealth.common.authorization.model.Role> lst = authorizationServiceJpa.getRoles(
        "code", false);
    assertEquals(1, lst.size());
    assertEquals(String.valueOf(role.getRoleId()), lst.get(0).getRoleId());
    assertEquals(role.getName(), lst.get(0).getRoleName());
    assertEquals(role.getCapability().getName(), lst.get(0).getCapability());
  }

  @Test
  public void testCreateRole() {
    Role expectedRole = MockData.getRoleEntity();
    expectedRole.setRoleId(1);

    when(capabilityRepository.findFirstByName(anyString())).thenReturn(new Capability());
    when(roleRepository.save(any(Role.class))).thenReturn(expectedRole);

    ca.bnc.wealth.common.authorization.model.Role actualRole =
        authorizationServiceJpa.createRole("idpSubject", "abm", MockData.getRole());

    verify(roleRepository, times(1)).save(any());
    assertEquals(String.valueOf(expectedRole.getRoleId()), actualRole.getRoleId());
    assertEquals(expectedRole.getName(), actualRole.getRoleName());
    assertEquals(expectedRole.getCapability().getName(), actualRole.getCapability());
  }

  @Test(expected = FumNotFoundException.class)
  public void testCreateRole_whenCapabilityNotFound_shouldThrowFumNotFoundException() {
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(null);
    authorizationServiceJpa.createRole("idpSubject", "abm", MockData.getRole());
  }

  @Test(expected = FumConflictException.class)
  public void testCreateRole_whenRoleConstraintExceptionThrown_shouldThrowFumServiceException() {
    Role expectedRole = MockData.getRoleEntity();
    expectedRole.setRoleId(1);

    when(capabilityRepository.findFirstByName(anyString())).thenReturn(new Capability());

    IllegalArgumentException e = new IllegalArgumentException("constraint [uk_role]");
    doThrow(e).when(roleRepository).save(any(Role.class));

    ca.bnc.wealth.common.authorization.model.Role actualRole =
        authorizationServiceJpa.createRole("idpSubject", "abm", MockData.getRole());
  }

  @Test(expected = FumConflictException.class)
  public void testCreateRole_whenRoleCapabilityConstraintExceptionThrown_shouldThrowFumServiceException() {
    Role expectedRole = MockData.getRoleEntity();
    expectedRole.setRoleId(1);

    when(capabilityRepository.findFirstByName(anyString())).thenReturn(new Capability());

    IllegalArgumentException e = new IllegalArgumentException("constraint [uk_role_capability]");
    doThrow(e).when(roleRepository).save(any(Role.class));

    ca.bnc.wealth.common.authorization.model.Role actualRole =
        authorizationServiceJpa.createRole("idpSubject", "abm", MockData.getRole());
  }

  @Test(expected = FumValidationException.class)
  public void testCreateRole_whenInvalidRoleInput_shouldThrowFumValidationException() {
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(new Capability());
    doThrow(FumValidationException.class).when(authorizationValidationService)
        .validateRole(anyString(), any());
    authorizationServiceJpa.createRole("idpSubject", "abm", MockData.getRole());
  }

  @Test(expected = FumServiceException.class)
  public void testCreateRole_whenUnableToSaveRole_shouldThrowFumServiceException() {
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(new Capability());
    doThrow(new RuntimeException("error")).when(roleRepository).save(any(Role.class));
    authorizationServiceJpa.createRole("idpSubject", "abm", MockData.getRole());
  }

  @Test
  public void testDeleteRole_whenRoleExist_shouldDeleteRole() {
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(
        MockData.getCapabilityEntity());
    when(roleRepository.deleteByNameAndCapability(anyString(), any(Capability.class))).thenReturn(
        1);
    try {
      authorizationServiceJpa.deleteRole(MockData.CAPABILITY, MockData.ROLE);
    } catch (Exception e) {
      fail("This test should not fail.");
    }
  }

  @Test(expected = FumNotFoundException.class)
  public void testDeleteRole_whenRoleDoNotExist_shouldThrowFumNotFoundException() {
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(
        MockData.getCapabilityEntity());
    when(roleRepository.deleteByNameAndCapability(anyString(), any(Capability.class))).thenReturn(
        0);
    authorizationServiceJpa.deleteRole(MockData.CAPABILITY, MockData.ROLE);
  }

  @Test(expected = FumNotFoundException.class)
  public void testDeleteRole_whenExceptionThrown_shouldThrowFumNotFoundException() {
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(
        MockData.getCapabilityEntity());
    doThrow(new FumNotFoundException("", "")).when(roleRepository)
        .deleteByNameAndCapability(anyString(), any(Capability.class));
    authorizationServiceJpa.deleteRole(MockData.CAPABILITY, MockData.ROLE);
  }

  @Test(expected = FumServiceException.class)
  public void testDeleteRole_whenUnexpectedError_shouldThrowException() {
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(
        MockData.getCapabilityEntity());
    doThrow(new RuntimeException("error")).when(roleRepository)
        .deleteByNameAndCapability(anyString(), any(Capability.class));
    authorizationServiceJpa.deleteRole(MockData.CAPABILITY, MockData.ROLE);
  }

  @Test
  public void testCreatePermission() {
    Capability capability = new Capability();
    capability.setName(MockData.CAPABILITY);
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(capability);
    Permission permission = new Permission();
    permission.setPermissionId(1234);
    permission.setName(MockData.PERMISSION);
    permission.setCapability(capability);
    when(permissionRepository.save(any())).thenReturn(permission);

    PermissionInfo input = new PermissionInfo();
    input.setName(MockData.PERMISSION);
    input.setDescription("desc");
    PermissionInfo permissionInfo = authorizationServiceJpa.createPermission("idpSubject",
        MockData.CAPABILITY, input);
    assertEquals(permission.getName(), permissionInfo.getName());
    assertEquals(permission.getPermissionId(), Long.parseLong(permissionInfo.getPermissionId()));
  }

  @Test(expected = FumValidationException.class)
  public void testCreatePermission_whenPermissionAlreadyExist_shouldThrowFumValidationException() {
    Capability capability = new Capability();
    capability.setName(MockData.CAPABILITY);
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(capability);
    Permission permission = new Permission();
    permission.setPermissionId(1234);
    permission.setName(MockData.PERMISSION);
    permission.setDescription("description");
    permission.setCapability(capability);
    PermissionInfo input = new PermissionInfo();
    input.setName(MockData.PERMISSION);
    input.setDescription("description");
    doThrow(new DataIntegrityViolationException("uk_permission")).when(permissionRepository)
        .save(any());
    authorizationServiceJpa.createPermission("idpSubject", MockData.CAPABILITY, input);
  }

  @Test(expected = DataIntegrityViolationException.class)
  public void testCreatePermission_whenGenericExceptionThrown_shouldThrowBackTheSameGenericException() {
    Capability capability = new Capability();
    capability.setName(MockData.CAPABILITY);
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(capability);
    Permission permission = new Permission();
    permission.setPermissionId(1234);
    permission.setName(MockData.PERMISSION);
    permission.setDescription("description");
    permission.setCapability(capability);
    PermissionInfo input = new PermissionInfo();
    input.setName(MockData.PERMISSION);
    input.setDescription("description");
    doThrow(new DataIntegrityViolationException("generic exception")).when(permissionRepository)
        .save(any());
    authorizationServiceJpa.createPermission("idpSubject", MockData.CAPABILITY, input);
  }

  @Test(expected = FumNotFoundException.class)
  public void testCreatePermission_whenCapabilityDoNotExist_shouldThrowFumNotFoundException() {
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(null);
    authorizationServiceJpa.createPermission("idpSubject", MockData.CAPABILITY,
        new PermissionInfo());
  }

  @Test
  public void testDeletePermission_whenPermissions_shouldDeletePermissions() {
    doNothing().when(permissionRepository).delete(any(Permission.class));
    Capability capability = new Capability();
    capability.setName(MockData.CAPABILITY);
    List<Permission> permissionList = MockData.createPermissionList();
    permissionList.get(0).setName(MockData.PERMISSION);
    permissionList.get(0).setCapability(capability);
    doReturn(permissionList).when(permissionRepository).findAll();
    authorizationServiceJpa.deletePermission(MockData.CAPABILITY, MockData.PERMISSION);
    verify(permissionRepository, times(1)).delete(any(Permission.class));
  }

  @Test
  public void testDeletePermission_whenPermissionDoNotExist_shouldDoNothing() {
    doReturn(new ArrayList<>()).when(permissionRepository).findAll();
    authorizationServiceJpa.deletePermission(MockData.CAPABILITY, MockData.PERMISSION);
    verify(permissionRepository, never()).delete(any(Permission.class));
  }

  @Test
  public void testGetTemplate_whenTemplateExistWithPackageTypeF_shouldReturnTemplate() {
    ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate actualPackageTemplate =
        MockData.getPackageTemplateEntity();
    actualPackageTemplate.setType(PackageType.F);
    when(packageTemplateRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(actualPackageTemplate));
    List<PackageTemplate> templates = authorizationServiceJpa.getTemplate("firmType",
        TemplateType.F, true);
    assertEquals(actualPackageTemplate.getName(), templates.get(0).getName());
    assertEquals(actualPackageTemplate.getDescription(), templates.get(0).getDescription());
  }

  @Test
  public void testGetTemplate_whenTemplateExistWithPackageTypeU_shouldReturnTemplate() {
    ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate actualPackageTemplate =
        MockData.getPackageTemplateEntity();
    actualPackageTemplate.setType(PackageType.U);
    actualPackageTemplate.getPackageTemplateAssignmentResources().get(0).setAssignmentType(
        PackageAssignmentType.G);
    actualPackageTemplate.getPackageTemplateAssignmentResources().get(0).setAssignmentMode(
        PackageAssignmentMode.M);
    actualPackageTemplate.getPackageTemplateAssignmentUserGroups().get(0)
        .setAssignmentType(PackageAssignmentType.S);
    actualPackageTemplate.getPackageTemplateAssignmentUserGroups().get(0)
        .setAssignmentMode(PackageAssignmentMode.O);
    when(packageTemplateRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(actualPackageTemplate));
    List<PackageTemplate> templates = authorizationServiceJpa.getTemplate("firmType",
        TemplateType.F, true);
    assertEquals(actualPackageTemplate.getName(), templates.get(0).getName());
    assertEquals(actualPackageTemplate.getDescription(), templates.get(0).getDescription());
  }

  @Test
  public void testGetTemplate_whenTemplateExistAndFirmTypeIsNullAndDetailsIsFalse_shouldReturnTemplate() {
    ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate actualPackageTemplate =
        MockData.getPackageTemplateEntity();
    when(packageTemplateRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(actualPackageTemplate));
    List<PackageTemplate> templates = authorizationServiceJpa.getTemplate(null,
        TemplateType.F, false);
    assertEquals(actualPackageTemplate.getName(), templates.get(0).getName());
    assertEquals(actualPackageTemplate.getDescription(), templates.get(0).getDescription());
  }

  @Test
  public void testGetTemplate_whenTemplateDoesNotExist_shouldReturnEmptyList() {
    when(packageTemplateRepository.findAll(any(Specification.class)))
        .thenReturn(new ArrayList());
    List<PackageTemplate> templates = authorizationServiceJpa.getTemplate("firmType",
        TemplateType.F, true);
    assertTrue(templates.isEmpty());
  }

  @Test
  public void testDeleteTemplate_whenTemplateExists_shouldNotThrowException() {
    authorizationServiceJpa.deleteTemplate("myTemplate");
    verify(redisCacheOperationService, times(1)).deleteCacheByCacheName(any());
  }

  @Test(expected = FumValidationException.class)
  public void testDeleteTemplate_whenTemplateDoesNotExists_shouldThrowFumValidationException() {
    doThrow(FumValidationException.class).when(packageTemplateServiceHelper)
        .deletePackageTemplate(any());
    authorizationServiceJpa.deleteTemplate("myTemplate");
  }

  @Test(expected = FumConflictException.class)
  public void testDeleteTemplate_whenTemplateISUsedByFeaturePackage_shouldThrowFumConflictException() {
    doThrow(FumConflictException.class).when(packageTemplateServiceHelper)
        .deletePackageTemplate(any());
    authorizationServiceJpa.deleteTemplate("myTemplate");
  }

  @Test
  public void testGetGroupMe_whenUserGroupListExist_shouldReturnUserGroupList() {
    UserGroup actualUserGroup = MockData.getUserGroupEntity();
    when(userGroupRepository.findAll(any(Specification.class))).thenReturn(
        List.of(actualUserGroup));
    List<ca.bnc.wealth.common.authorization.model.UserGroup> userGroupList =
        authorizationServiceJpa.getGroupsMe(MockData.IDP_SUBJECT);
    assertEquals(actualUserGroup.getName(), userGroupList.get(0).getName());
    assertEquals(actualUserGroup.getDescription(), userGroupList.get(0).getDescription());
    // assert immutable
    ca.bnc.wealth.common.authorization.model.UserGroup newUserGroup = new ca.bnc.wealth.common.authorization.model.UserGroup();
    assertThrows(UnsupportedOperationException.class, () -> userGroupList.add(newUserGroup));
  }

  @Test
  public void testGetResourceEntitlements_whenResourceListExist_shouldReturnResourceEntitlementList() {
    List<Resource> actualResource = MockData.getResourceEntityList();
    when(resourceRepository.findAll(any(Specification.class))).thenReturn(actualResource);
    List<ResourceEntitlement> resourceEntitlements =
        authorizationServiceJpa.getResourceEntitlements("resourceType", MockData.IDP_SUBJECT);
    assertEquals(1, resourceEntitlements.size());
    assertEquals(actualResource.get(1).getName(), resourceEntitlements.get(0).getResourceName());
  }

  @Test
  public void testGetRolePermissions_whenPermissionExist_shouldReturnPermissionInfo() {
    Permission permissionEntity = MockData.getPermissionEntity();
    when(permissionRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(permissionEntity));

    List<PermissionInfo> permissionInfos = authorizationServiceJpa
        .getRolePermissions("capability", new ArrayList<>());

    assertEquals(permissionEntity.getName(), permissionInfos.get(0).getName());
  }

  @Test(expected = FumValidationException.class)
  public void testUpdateRolePermission_whenPermissionsListNull_shouldThrowFumValidationException() {
    authorizationServiceJpa.updateRolePermission(MockData.IDP_SUBJECT, MockData.CAPABILITY,
        MockData.ROLE, null);
  }

  @Test(expected = FumNotFoundException.class)
  public void testUpdateRolePermission_whenCapabilityDoNotExist_shouldThrowFumNotFoundException() {
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(null);
    authorizationServiceJpa.updateRolePermission(MockData.IDP_SUBJECT, MockData.CAPABILITY,
        MockData.ROLE, new ArrayList<>());
  }

  @Test(expected = FumNotFoundException.class)
  public void testUpdateRolePermission_whenRoleDoNotExist_shouldThrowFumNotFoundException() {
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(
        MockData.getCapabilityEntity());
    when(roleRepository.findByNameAndCapability(anyString(), any(Capability.class))).thenReturn(
        null);
    authorizationServiceJpa.updateRolePermission(MockData.IDP_SUBJECT, MockData.CAPABILITY,
        MockData.ROLE, new ArrayList<>());
  }

  @Test(expected = FumValidationException.class)
  public void testUpdateRolePermission_whenPermissionDoNotMatchWithInput_shouldThrowFumValidationException() {
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(
        MockData.getCapabilityEntity());
    when(roleRepository.findByNameAndCapability(anyString(), any(Capability.class))).thenReturn(
        MockData.getRoleEntity());
    when(permissionRepository.findByNameInAndCapability(anyList(),
        any(Capability.class))).thenReturn(new ArrayList<>());
    authorizationServiceJpa.updateRolePermission(MockData.IDP_SUBJECT, MockData.CAPABILITY,
        MockData.ROLE, List.of("permission"));
  }

  @Test
  public void testUpdateRolePermission_whenRolePermissionIsValid_shouldReturnUpdatedRole() {
    Permission actualPermission = MockData.getPermissionEntity();
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(
        MockData.getCapabilityEntity());
    when(roleRepository.findByNameAndCapability(anyString(), any(Capability.class)))
        .thenReturn(MockData.getRoleEntity());
    when(permissionRepository.findByNameInAndCapability(anyList(), any(Capability.class)))
        .thenReturn(List.of(actualPermission));
    doNothing().when(rolePermissionAssignmentRepository).deleteAll(any());
    doNothing().when(rolePermissionAssignmentRepository).flush();
    when(rolePermissionAssignmentRepository.saveAllAndFlush(any()))
        .thenReturn(MockData.getRolePermissionAssignmentList());

    ca.bnc.wealth.common.authorization.model.Role role =
        authorizationServiceJpa.updateRolePermission(MockData.IDP_SUBJECT, MockData.CAPABILITY,
            MockData.ROLE,
            Collections.singletonList(actualPermission.getName()));
    assertEquals(role.getPermissions().get(0).getName(), actualPermission.getName());
  }

  @Test
  public void deleteRolePermission_whenCapabilityDoNotExist_shouldNotDeleteRolePermission() {
    authorizationServiceJpa.deleteRolePermission(MockData.CAPABILITY, MockData.ROLE);
    verify(rolePermissionAssignmentRepository, never()).deleteRolePermissionAssignmentsByRole(any());
  }

  @Test
  public void deleteRolePermission_whenRoleDoNotExist_shouldNotDeleteRolePermission() {
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(
        MockData.getCapabilityEntity());
    authorizationServiceJpa.deleteRolePermission(MockData.CAPABILITY, MockData.ROLE);
    verify(rolePermissionAssignmentRepository, never()).deleteRolePermissionAssignmentsByRole(any());
  }

  @Test
  public void deleteRolePermission_whenCapabilityExist_shouldDeleteRolePermission() {
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(
        MockData.getCapabilityEntity());
    when(roleRepository.findByNameAndCapability(anyString(), any(Capability.class))).thenReturn(
        MockData.getRoleEntity());
    doNothing().when(rolePermissionAssignmentRepository)
        .deleteRolePermissionAssignmentsByRole(any(Role.class));
    authorizationServiceJpa.deleteRolePermission(MockData.CAPABILITY, MockData.ROLE);
    verify(rolePermissionAssignmentRepository, times(1)).deleteRolePermissionAssignmentsByRole(any());
  }

  @Test
  public void testGetUserRoles_whenIncludePermissionFalse_shouldReturnRoles() {
    Map<String, Object> mockRole = MockData.getRoleMap();
    when(namedParameterJdbcTemplate.queryForList(anyString(), any(SqlParameterSource.class)))
        .thenReturn(List.of(mockRole));

    List<ca.bnc.wealth.common.authorization.model.Role> roles =
        authorizationServiceJpa.getUserRoles(MockData.CAPABILITY, new ArrayList<>(), false);

    assertEquals(mockRole.get("NAME"), roles.get(0).getRoleName());
  }

  @Test
  public void testGetUserRoles_whenIncludePermissionTrue_shouldReturnRoles() {
    Map<String, Object> mockRole = MockData.getRoleMap();
    when(namedParameterJdbcTemplate.queryForList(anyString(), any(SqlParameterSource.class)))
        .thenReturn(List.of(mockRole));

    Map<String, Object> permissionMap = MockData.getPermissionMap();
    when(namedParameterJdbcTemplate.queryForList(eq(AuthorizationConstants.GET_PERMISSION_QUERY),
        any(SqlParameterSource.class))).thenReturn(List.of(permissionMap));

    List<ca.bnc.wealth.common.authorization.model.Role> roles =
        authorizationServiceJpa.getUserRoles(MockData.CAPABILITY, new ArrayList<>(), true);

    assertEquals(mockRole.get("NAME"), roles.get(0).getRoleName());
  }

  @Test
  public void testGetUserRoles_whenIncludePermissionISNULL_shouldReturnRoles() {
    Map<String, Object> mockRole = MockData.getRoleMap();
    when(namedParameterJdbcTemplate.queryForList(anyString(), any(SqlParameterSource.class)))
        .thenReturn(List.of(mockRole));

    List<ca.bnc.wealth.common.authorization.model.Role> roles =
        authorizationServiceJpa.getUserRoles(MockData.CAPABILITY, new ArrayList<>(), null);

    assertEquals(mockRole.get("NAME"), roles.get(0).getRoleName());
  }

  @Test
  public void testGetScopes_whenRoleExist_shouldReturnRoleNamesAsScope() {
    Map<String, Object> mockRole = MockData.getRoleMap();
    when(namedParameterJdbcTemplate.queryForList(anyString(), any(SqlParameterSource.class)))
        .thenReturn(List.of(mockRole));

    List<String> scopes = authorizationServiceJpa.getScopes(MockData.CAPABILITY);
    assertEquals(mockRole.get("NAME"), scopes.get(0));
  }

  @Test(expected = FumNotFoundException.class)
  public void testTogglePermission_whenNoPermissionExist_shouldThrowFumNotFoundException() {
    when(permissionRepository.findAll()).thenReturn(new ArrayList<>());
    authorizationServiceJpa.togglePermission(MockData.CAPABILITY, MockData.PERMISSION, true);
  }

  @Test
  public void testTogglePermission_whenPermissionExist_shouldTogglePermission() {
    Permission mockPermission = MockData.getPermissionEntity();
    when(permissionRepository.findAll()).thenReturn(List.of(mockPermission));
    authorizationServiceJpa.togglePermission(MockData.CAPABILITY, MockData.PERMISSION, true);
    verify(permissionRepository, times(1)).save(any());
  }

  @Test(expected = FumValidationException.class)
  public void testCreateUserGroup_whenUserGroupExist_shouldThrowFumValidationException() {
    when(userGroupRepository.findOne(any(Specification.class))).thenReturn(
        Optional.of(new UserGroup()));
    authorizationServiceJpa.createUserGroup(MockData.IDP_SUBJECT, MockData.getUserGroup());
  }

  @Test
  public void testCreateUserGroup_whenUserGroupDoNotExist_shouldCreateUserGroup() {
    when(userGroupRepository.findOne(any(Specification.class))).thenReturn(Optional.empty());
    when(userGroupRepository.save(any(UserGroup.class))).thenReturn(MockData.getUserGroupEntity());
    authorizationServiceJpa.createUserGroup(MockData.IDP_SUBJECT, MockData.getUserGroup());
    verify(userGroupRepository, times(1)).save(any());
  }

  @Test
  public void testDeleteUserGroup_whenUserGroupDoNotExist_shouldDoNothing() {
    try {
      authorizationServiceJpa.deleteUserGroup("123");
    } catch (Exception e) {
      fail("This test should not fail.");
    }
  }

  @Test
  public void testDeleteUserGroup_whenUserGroupDoExist_shouldDeleteUserGroup() {
    try {
      when(userGroupRepository.findOne(any(Specification.class))).thenReturn(
          Optional.of(MockData.getUserGroupEntity()));
      authorizationServiceJpa.deleteUserGroup("123");
    } catch (Exception e) {
      fail("This test should not fail.");
    }
  }

  @Test(expected = FumValidationException.class)
  public void testDeleteUserGroup_whenUserGroupHasRoleAssignments_shouldThrowFumValidationException() {
    when(userGroupRepository.findOne(any(Specification.class))).thenReturn(
        Optional.of(MockData.getUserGroupEntity()));
    when(userGroupRoleAssignmentRepository.exists(any(Specification.class))).thenReturn(true);
    authorizationServiceJpa.deleteUserGroup("123");
  }

  @Test(expected = FumValidationException.class)
  public void testDeleteUserGroup_whenUserGroupHasPackageTemplateAssignments_shouldThrowFumValidationException() {
    when(userGroupRepository.findOne(any(Specification.class))).thenReturn(
        Optional.of(MockData.getUserGroupEntity()));
    when(packageTemplateAssignmentUserGroupRepository.exists(any(Specification.class))).thenReturn(
        true);
    authorizationServiceJpa.deleteUserGroup("123");
  }

  @Test(expected = FumValidationException.class)
  public void testDeleteUserGroup_whenUserGroupHasUserAssignments_shouldThrowFumValidationException() {
    when(userGroupRepository.findOne(any(Specification.class))).thenReturn(
        Optional.of(MockData.getUserGroupEntity()));
    when(userAssignmentUserGroupRepository.exists(any(Specification.class))).thenReturn(true);
    authorizationServiceJpa.deleteUserGroup("123");
  }

  @Test(expected = FumValidationException.class)
  public void testUpdateUserGroup_whenUserGroupDoNotExist_shouldThrow() {
    when(userGroupRepository.findOne(any(Specification.class))).thenReturn(Optional.empty());
    authorizationServiceJpa.updateUserGroup(MockData.IDP_SUBJECT, "123", MockData.getUserGroup());
  }

  @Test
  public void testUpdateUserGroup_whenUserGroupDoExist_shouldUpdateUserGroup() {
    when(userGroupRepository.findOne(any(Specification.class))).thenReturn(
        Optional.of(MockData.getUserGroupEntity()));
    when(userGroupRepository.save(any(UserGroup.class))).thenReturn(MockData.getUserGroupEntity());
    ca.bnc.wealth.common.authorization.model.UserGroup actualUserGroup =
        authorizationServiceJpa.updateUserGroup(MockData.IDP_SUBJECT, "123",
            MockData.getUserGroup());
    assertEquals(MockData.getUserGroup().getUserGroupId(), actualUserGroup.getUserGroupId());
  }

  @Test
  public void testDeleteResource_whenResourceDoNotExist_shouldNotThrowFumValidationException() {
    try {
    when(resourceRepository.findAll(any(Specification.class))).thenReturn(new ArrayList());
    authorizationServiceJpa.deleteResource("type", "resource");
    } catch (Exception e) {
      fail("This test should not fail.");
    }
  }

  @Test
  public void testDeleteResource_whenResourceDoExist_shouldDeleteResource() {
    try {
      when(resourceRepository.findAll(any(Specification.class)))
          .thenReturn(Collections.singletonList(MockData.getResourceEntity()));
      authorizationServiceJpa.deleteResource("type", "resource");
    } catch (Exception e) {
      fail("This test should not fail.");
    }
  }

  @Test(expected = FumValidationException.class)
  public void testPatchResource_whenResourceDoNotExist_shouldThrowFumValidationException() {
    when(resourceRepository.findAll(any(Specification.class))).thenReturn(new ArrayList());
    authorizationServiceJpa.patchResource("type", "resource", MockData.getResourceData());
  }

  @Test
  public void testPatchResource_whenResourceDoExist_shouldPatchResource() {
    try {
      when(resourceRepository.findAll(any(Specification.class)))
          .thenReturn(Collections.singletonList(MockData.getResourceEntity()));
      authorizationServiceJpa.patchResource("type", "resource", MockData.getResourceData());
    } catch (Exception e) {
      fail("This test should not fail.");
    }
  }

  @Test
  public void testCreateResource_whenResourceValid_shouldCreateResource() {
    when(resourceRepository.save(any(Resource.class))).thenReturn(MockData.getResourceEntity());
    ResourceData createdResource = authorizationServiceJpa
        .createResource("type", "resource", MockData.getResourceData());
    assertEquals(MockData.getResourceEntity().getName(), createdResource.getName());
  }
  @Test
  public void testCheckResourceByNameAndRestriction_ResourceExists() {
    ResourceData resourceData = MockData.getResourceData();
    resourceData.setRestriction(true);

    when(resourceRepository.findFirstByNameAndRestriction(anyString(), anyBoolean()))
            .thenReturn(Optional.of(MockData.getResourceEntity()));
    boolean result = authorizationServiceJpa.checkResourceByNameAndRestriction("type", resourceData);
    assertTrue(result);
  }

  @Test
  public void testCheckResourceByNameAndRestriction_ResourceDoesNotExist() {
    when(resourceRepository.findFirstByNameAndRestriction(anyString(), anyBoolean()))
            .thenReturn(Optional.empty());
    boolean result = authorizationServiceJpa.checkResourceByNameAndRestriction("type",MockData.getResourceData());
    assertFalse(result);
  }

  @Test
  public void testGetResourceByResourceType_whenNoResourceExist_shouldReturnEmptyList() {
    when(resourceRepository.findByType(anyString())).thenReturn(new ArrayList<>());
    List<ResourceData> resourceDataList = authorizationServiceJpa.getResourceByResourceType("");
    assertEquals(0, resourceDataList.size());
  }

  @Test
  public void testGetResourceByResourceType_whenResourceExist_shouldReturnResourceList() {
    when(resourceRepository.findByType(anyString())).thenReturn(
        Collections.singletonList(MockData.getResourceEntity()));
    List<ResourceData> resourceDataList = authorizationServiceJpa.getResourceByResourceType("");
    assertFalse(resourceDataList.isEmpty());
  }

  @Test
  public void testGetResourceByTypeAndName_whenResourceExist_shouldReturnResourceList() {
    when(resourceRepository.findFirstByTypeAndName(anyString(), anyString()))
        .thenReturn(Optional.of(MockData.getResourceEntity()));
    ResourceData resourceData = authorizationServiceJpa.getResourceByTypeAndName("type", "name");
    assertEquals(MockData.getResourceEntity().getName(), resourceData.getName());
  }

  @Test(expected = FumNotFoundException.class)
  public void testGetResourceByTypeAndName_whenResourceExist_shouldThrowFumNotFoundException() {
    when(resourceRepository.findFirstByTypeAndName(anyString(), anyString()))
        .thenReturn(Optional.empty());
    authorizationServiceJpa.getResourceByTypeAndName("type", "name");
  }

  @Test
  public void testGetResourceByResourceTypeAndRrCode_whenResourceExist_shouldReturnResourceList() {
    Map<String, Object> b36DecodeMap = Map.of("b36_decode", 2L);
    when(namedParameterJdbcTemplate.queryForMap(eq(AuthorizationConstants.DECODE_RRCODE_QUERY),
        any(SqlParameterSource.class))).thenReturn(b36DecodeMap);

    Map<String, Object> rrCodeMap = Map.of("RR_CODE_RANGE_ID", 1);
    when(namedParameterJdbcTemplate.queryForList(
        eq(AuthorizationConstants.GET_RRCODE_BY_USER_AND_B10_QUERY),
        any(SqlParameterSource.class))).thenReturn(List.of(rrCodeMap));

    Map<String, Object> resourceMap = Map.of("NAME", "name",
        "DESCRIPTION", "description",
        "ACTIVE", true,
        "CONF_URI", "confUri",
        "VERSION", "version",
        "GROUP_NAME", "groupName",
        "LABEL", "label",
        "PURPOSE", "purpose");
    when(namedParameterJdbcTemplate.queryForList(
        eq(AuthorizationConstants.GET_RESOURCES_BY_RRCODE_QUERY),
        any(SqlParameterSource.class))).thenReturn(List.of(resourceMap));

    List<ResourceData> resourceDataList = authorizationServiceJpa.getResourceByResourceTypeAndRrCode(
        "resourceType", "rrCode", MockData.getUser());

    assertFalse(resourceDataList.isEmpty());
    assertEquals(resourceMap.get("NAME"), resourceDataList.get(0).getName());
    assertEquals(resourceMap.get("DESCRIPTION"), resourceDataList.get(0).getDescription());
    assertEquals(resourceMap.get("ACTIVE"), resourceDataList.get(0).getActive());
    assertEquals(resourceMap.get("CONF_URI"), resourceDataList.get(0).getConfUri());
    assertEquals(resourceMap.get("VERSION"), resourceDataList.get(0).getVersion());
    assertEquals(resourceMap.get("GROUP_NAME"), resourceDataList.get(0).getGroupName());
    assertEquals(resourceMap.get("LABEL"), resourceDataList.get(0).getLabel());
    assertEquals(resourceMap.get("PURPOSE"), resourceDataList.get(0).getPurpose());
  }

  @Test
  public void testGetResourceByResourceTypeAndRrCode_whenRrCodeNotAssignedToUser_shouldReturnEmptyList() {
    Map<String, Object> b36DecodeMap = Map.of("b36_decode", 2L);
    when(namedParameterJdbcTemplate.queryForMap(eq(AuthorizationConstants.DECODE_RRCODE_QUERY),
        any(SqlParameterSource.class))).thenReturn(b36DecodeMap);

    when(namedParameterJdbcTemplate.queryForList(
        eq(AuthorizationConstants.GET_RRCODE_BY_USER_AND_B10_QUERY),
        any(SqlParameterSource.class))).thenReturn(Collections.emptyList());

    List<ResourceData> resourceDataList = authorizationServiceJpa.getResourceByResourceTypeAndRrCode(
        "resourceType", "rrCode", MockData.getUser());
    assertTrue(resourceDataList.isEmpty());
  }

  @Test
  public void testGetResourceByResourceTypeAndRrCode_whenRrCodeNotAssignedToFirm_shouldReturnEmptyList() {
    Map<String, Object> b36DecodeMap = Map.of("b36_decode", 2L);
    when(namedParameterJdbcTemplate.queryForMap(eq(AuthorizationConstants.DECODE_RRCODE_QUERY),
        any(SqlParameterSource.class))).thenReturn(b36DecodeMap);

    Map<String, Object> rrCodeMap = Map.of("RR_CODE_RANGE_ID", 1);
    when(namedParameterJdbcTemplate.queryForList(
        eq(AuthorizationConstants.GET_RRCODE_BY_USER_AND_B10_QUERY),
        any(SqlParameterSource.class))).thenReturn(List.of(rrCodeMap));

    when(namedParameterJdbcTemplate.queryForList(
        eq(AuthorizationConstants.GET_RESOURCES_BY_RRCODE_QUERY),
        any(SqlParameterSource.class))).thenReturn(Collections.emptyList());

    List<ResourceData> resourceDataList = authorizationServiceJpa.getResourceByResourceTypeAndRrCode(
        "resourceType", "rrCode", MockData.getUser());
    assertTrue(resourceDataList.isEmpty());
  }

  @Test
  public void testValidateTemplateResourceAssignmentPayload_whenInputPayloadIsValidAndActionTypeIsAdd_shouldPassValidation() {
    try {
      mockRepositoryCallForValidation();
      authorizationServiceJpa.validateAndUpdateTemplateResourceAssignmentPayload(
          MockData.getUpdateTemplateResourceAssignment(ActionType.ADD), MockData.TEMPLATE_NAME);
    } catch (Exception e) {
      fail("Test case should not throw exception");
    }
  }

  @Test(expected = FumNotFoundException.class)
  public void testValidateTemplateResourceAssignmentPayload_whenPackageTemplateDoNotExist_shouldThrowFumNotFoundException() {
    when(packageTemplateRepository.findByName(anyString())).thenReturn(Optional.empty());
    authorizationServiceJpa.validateAndUpdateTemplateResourceAssignmentPayload(
        MockData.getUpdateTemplateResourceAssignment(ActionType.ADD), MockData.TEMPLATE_NAME);
  }

  @Test
  public void testValidateTemplateResourceAssignmentPayload_whenResourcesAreAlreadyAssignedToPackageTemplateForAdd() {
    mockRepositoryCallForValidation();
    when(resourceRepository.findAll(any(Specification.class))).thenReturn(MockData.getResourceEntities());
    authorizationServiceJpa.validateAndUpdateTemplateResourceAssignmentPayload(
        MockData.getUpdateTemplateResourceAssignment(ActionType.ADD), MockData.TEMPLATE_NAME);
  }

  @Test
  public void testValidateTemplateResourceAssignmentPayload_whenResourcesAreNotAssignedToPackageTemplateForDelete() {
    mockRepositoryCallForValidation();
    authorizationServiceJpa.validateAndUpdateTemplateResourceAssignmentPayload(
        MockData.getUpdateTemplateResourceAssignment(ActionType.DELETE), MockData.TEMPLATE_NAME);
  }

  @Test(expected = FumNotFoundException.class)
  public void testValidateTemplateResourceAssignmentPayload_whenResourcesDoNotExist_shouldThrowFumNotFoundException() {
    when(packageTemplateRepository.findByName(anyString()))
        .thenReturn(Optional.of(MockData.getPackageTemplateEntity()));
    when(resourceRepository.findAll()).thenReturn(Arrays.asList());
    when(resourceRepository.findAll(any(Specification.class))).thenReturn(MockData.getResourceEntities());
    authorizationServiceJpa.validateAndUpdateTemplateResourceAssignmentPayload(
        MockData.getUpdateTemplateResourceAssignment(ActionType.ADD), MockData.TEMPLATE_NAME);
  }

  @Test(expected = FumNotFoundException.class)
  public void testValidateTemplateResourceAssignmentPayload_whenResourcesIsInvalidOptional_shouldThrowFumNotFoundException() {
    ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate pt = MockData.getPackageTemplateWithPackageTemplateAssignmentResource();
    pt.getPackageTemplateAssignmentResources().get(0).setAssignmentMode(PackageAssignmentMode.M);
    when(packageTemplateRepository.findByName(anyString())).thenReturn(Optional.of(pt));
    authorizationServiceJpa.validateAndUpdateTemplateResourceAssignmentPayload(MockData.getUpdateTemplateResourceAssignment(ActionType.ADD), MockData.TEMPLATE_NAME);
  }

  @Test
  public void testIsValidOptionalResources_whenTestingAllScenarios_shouldReturnExpectedResult() {

    //When list is provided is valid
    assertTrue(authorizationServiceJpa.isValidOptionalResources(MockData.getTemplateResourceAssignments()));

    //When list is valid in reverse order
    List<TemplateResourceAssignment> traList = MockData.getTemplateResourceAssignments();
    TemplateResourceAssignment temp = traList.get(0);
    traList.set(0, traList.get(1));
    traList.set(1, temp);
    assertTrue(authorizationServiceJpa.isValidOptionalResources(traList));

    //When both resource restrictions are false
    traList = MockData.getTemplateResourceAssignments();
    traList.get(0).setRestriction(false);
    assertFalse(authorizationServiceJpa.isValidOptionalResources(traList));

    //When both resource restrictions are true
    traList = MockData.getTemplateResourceAssignments();
    traList.get(1).setRestriction(true);
    assertFalse(authorizationServiceJpa.isValidOptionalResources(traList));

    //When both resources are mandatory
    traList = MockData.getTemplateResourceAssignments();
    traList.get(0).setAssignmentMode(TemplateResourceAssignment.AssignmentModeEnum.M);
    assertFalse(authorizationServiceJpa.isValidOptionalResources(traList));

    //When both resources are optional
    traList = MockData.getTemplateResourceAssignments();
    traList.get(1).setAssignmentMode(TemplateResourceAssignment.AssignmentModeEnum.O);
    assertFalse(authorizationServiceJpa.isValidOptionalResources(traList));
  }

  @Test
  public void testUpdateTemplateResources_whenActionTypeIsAdd_shouldAddTheResource() {
    try {
      mockRepositoryCallForValidation();
      authorizationServiceJpa.updateTemplateResources(MockData.TEMPLATE_NAME,
          MockData.getUpdateTemplateResourceAssignment(ActionType.ADD), MockData.REQUESTED_BY);
    } catch (Exception e) {
      fail("Test case should not throw exception");
    }
  }

  @Test
  public void testUpdateTemplateResources_whenActionTypeIsAddAndModuleOverrideIsProvided_shouldAddTheResource() {
    try {
      mockRepositoryCallForValidation();
      UpdateTemplateResourceAssignment utra = MockData.getUpdateTemplateResourceAssignment(ActionType.ADD);
      utra.getResources().get(0).setModuleOverride(true);
      authorizationServiceJpa.updateTemplateResources(MockData.TEMPLATE_NAME, utra, MockData.REQUESTED_BY);
    } catch (Exception e) {
      fail("Test case should not throw exception");
    }
  }

  @Test
  public void testUpdateTemplateResources_whenActionTypeIsDelete_shouldDeleteTheResource() {
    try {
      mockRepositoryCallForValidation();
      when(resourceRepository.findAll(any(Specification.class))).thenReturn(MockData.getResourceEntities());
      authorizationServiceJpa.updateTemplateResources(MockData.TEMPLATE_NAME,
          MockData.getUpdateTemplateResourceAssignment(ActionType.DELETE), MockData.REQUESTED_BY);
    } catch (Exception e) {
      fail("Test case should not throw exception");
    }
  }

  @Test
  public void testUpdateTemplateResources_whenActionTypeIsReplace_shouldReplaceTheResource() {
    try {
      mockRepositoryCallForValidation();
      authorizationServiceJpa.updateTemplateResources(MockData.TEMPLATE_NAME,
          MockData.getUpdateTemplateResourceAssignment(ActionType.REPLACE), MockData.REQUESTED_BY);
    } catch (Exception e) {
      fail("Test case should not throw exception");
    }
  }

  @Test
  public void testValidateUpdateTemplateResourceAssignment_whenValidUpdateTemplateResourceAssignment_shouldNotThrowException() {
    try {
      authorizationServiceJpa.validateUpdateTemplateResourceAssignmentDto(
          MockData.getUpdateTemplateResourceAssignment(ActionType.ADD), MockData.getPackageTemplateEntity());
    } catch (Exception e) {
      fail("Test case should not throw exception");
    }
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUpdateTemplateResourceAssignment_whenUpdateTemplateResourceAssignmentIsNull_shouldThrowFumValidationException() {
    authorizationServiceJpa.validateUpdateTemplateResourceAssignmentDto(null, MockData.getPackageTemplateEntity());
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUpdateTemplateResourceAssignment_whenResourcesIsNull_shouldThrowFumValidationException() {
    UpdateTemplateResourceAssignment utra = MockData.getUpdateTemplateResourceAssignment(ActionType.ADD);
    utra.setResources(null);
    authorizationServiceJpa.validateUpdateTemplateResourceAssignmentDto(utra, MockData.getPackageTemplateEntity());
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUpdateTemplateResourceAssignment_whenResourcesIsEmpty_shouldThrowFumValidationException() {
    UpdateTemplateResourceAssignment utra = MockData.getUpdateTemplateResourceAssignment(ActionType.ADD);
    utra.setResources(new ArrayList<>());
    authorizationServiceJpa.validateUpdateTemplateResourceAssignmentDto(utra, MockData.getPackageTemplateEntity());
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUpdateTemplateResourceAssignment_whenResourceNameIsEmpty_shouldThrowFumValidationException() {
    UpdateTemplateResourceAssignment utra = MockData.getUpdateTemplateResourceAssignment(ActionType.ADD);
    utra.getResources().get(0).setName(null);
    authorizationServiceJpa.validateUpdateTemplateResourceAssignmentDto(utra, MockData.getPackageTemplateEntity());
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUpdateTemplateResourceAssignment_whenResourceRestrictionIsNull_shouldThrowFumValidationException() {
    UpdateTemplateResourceAssignment utra = MockData.getUpdateTemplateResourceAssignment(ActionType.ADD);
    utra.getResources().get(0).setRestriction(null);
    authorizationServiceJpa.validateUpdateTemplateResourceAssignmentDto(utra, MockData.getPackageTemplateEntity());
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUpdateTemplateResourceAssignment_whenResourceAssignmentModeIsNull_shouldThrowFumValidationException() {
    UpdateTemplateResourceAssignment utra = MockData.getUpdateTemplateResourceAssignment(ActionType.ADD);
    utra.getResources().get(0).setAssignmentMode(null);
    authorizationServiceJpa.validateUpdateTemplateResourceAssignmentDto(utra, MockData.getPackageTemplateEntity());
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUpdateTemplateResourceAssignment_whenResourceSelectionDefaultIsNull_shouldThrowFumValidationException() {
    UpdateTemplateResourceAssignment utra = MockData.getUpdateTemplateResourceAssignment(ActionType.ADD);
    utra.getResources().get(0).setSelectionDefault(null);
    authorizationServiceJpa.validateUpdateTemplateResourceAssignmentDto(utra, MockData.getPackageTemplateEntity());
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUpdateTemplateResourceAssignment_whenResourceSelectionDefaultIsTrueAndResourceIsOptional_shouldThrowFumValidationException() {
    UpdateTemplateResourceAssignment utra = MockData.getUpdateTemplateResourceAssignment(ActionType.ADD);
    utra.getResources().get(0).setSelectionDefault(true);
    ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate pt = MockData.getPackageTemplateEntity();
    pt.setFirmType(FirmType.NBIN);
    pt.setType(PackageType.U);
    authorizationServiceJpa.validateUpdateTemplateResourceAssignmentDto(utra, pt);
  }


  private void mockRepositoryCallForValidation() {
    when(packageTemplateRepository.findByName(anyString()))
        .thenReturn(Optional.of(MockData.getPackageTemplateEntity()));
    when(resourceRepository.findAll()).thenReturn(MockData.getResourceEntities());
  }

}
