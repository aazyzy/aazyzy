package ca.bnc.wealth.api.authorization.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.fail;

import ca.bnc.wealth.api.authorization.utility.MockData;
import ca.bnc.wealth.common.authorization.model.ActionType;
import ca.bnc.wealth.common.authorization.model.FeaturePackageRequest;
import ca.bnc.wealth.common.authorization.model.PermissionInfo;
import ca.bnc.wealth.common.authorization.model.ResourceData;
import ca.bnc.wealth.common.authorization.model.Role;
import ca.bnc.wealth.common.authorization.model.UpdateTemplateResourceAssignment;
import ca.bnc.wealth.common.authorization.model.UserGroup;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import java.util.ArrayList;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class AuthorizationValidationServiceTests {

  private AuthorizationValidationService validationService;

  @Before
  public void init() {
    validationService = new AuthorizationValidationService();
  }

  @Test
  public void testValidateRole() {
    try {
      validationService.validateRole("cx-user-conf", MockData.getRole());
    } catch (Exception e) {
      fail("Test case should not throw exception");
    }
  }

  @Test(expected = FumValidationException.class)
  public void testValidateRole_whenNullRoleInput_shouldThrowFumValidationException() {
    validationService.validateRole("cx-user-conf", null);
  }

  @Test(expected = FumValidationException.class)
  public void testValidateRole_whenEmptyRoleName_shouldThrowFumValidationException() {
    Role role = MockData.getRole();
    role.setRoleName("");
    validationService.validateRole("cx-user-conf", role);
  }

//  @Test(expected = FumValidationException.class)
//  public void testValidateRole_whenRoleNameInvalid_shouldThrowFumValidationException() {
//    Role role = MockData.getRole();
//    role.setRoleName("invalid");
//    validationService.validateRole("cx-user-conf", role);
//  }

  @Test
  public void testValidatePermission_whenFormatMet_shouldThrowFumValidationException() {
    try {
      PermissionInfo permissionInfo = new PermissionInfo();
      permissionInfo.setName("access-control:cx-user-conf");
      permissionInfo.setDescription("desc");
      validationService.validatePermission(permissionInfo);
    } catch (FumValidationException e) {
      fail("Test case should not throw exception");
    }
  }

  @Test(expected = FumValidationException.class)
  public void testValidatePermission_whenPermissionNull_shouldThrowFumValidationException() {
    validationService.validatePermission(null);
  }

  @Test(expected = FumValidationException.class)
  public void testValidatePermission_whenFormatNotMet_shouldThrowFumValidationException() {
    PermissionInfo permissionInfo = new PermissionInfo();
    permissionInfo.setName("cx-user-conf");
    validationService.validatePermission(permissionInfo);
  }

  @Test
  public void test_validateResourceForCreate_whenGood() {
    assertDoesNotThrow(() -> validationService.validateResourceForCreate("test_type", MockData.getResourceData()));
  }

  @Test(expected = FumValidationException.class)
  public void test_validateResourceForCreate_whenTypeIsNull() {
    validationService.validateResourceForCreate(null, MockData.getResourceData());
  }

  @Test(expected = FumValidationException.class)
  public void test_validateResourceForCreate_whenTypeIsEmpty() {
    validationService.validateResourceForCreate(" ", MockData.getResourceData());
  }

  @Test(expected = FumValidationException.class)
  public void test_validateResourceForCreate_whenNameIsNull() {
    validationService.validateResourceForCreate("test_type", new ResourceData());
  }

  @Test(expected = FumValidationException.class)
  public void test_validateResourceForCreate_whenNameIsEmpty() {
    validationService.validateResourceForCreate("test_type",
        ResourceData.builder()
            .name("   ")
            .build());
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUserGroup_whenUserGroupIsNull_shouldThrowFumValidationException() {
    validationService.validateUserGroup(null);
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUserGroup_whenNameIsEmpty_shouldThrowFumValidationException() {
    UserGroup userGroup = new UserGroup();
    userGroup.setName("");
    validationService.validateUserGroup(userGroup);
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUserGroup_whenIsFirmScopeIsNull_shouldThrowFumValidationException() {
    UserGroup userGroup = new UserGroup();
    userGroup.setName("name");
    userGroup.setIsFirmScope(null);
    validationService.validateUserGroup(userGroup);
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUserGroup_whenIsInternalIsNull_shouldThrowFumValidationException() {
    UserGroup userGroup = new UserGroup();
    userGroup.setName("name");
    userGroup.setIsFirmScope(true);
    userGroup.setIsInternal(null);
    validationService.validateUserGroup(userGroup);
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUserGroup_whenIsActiveIsNull_shouldThrowFumValidationException() {
    UserGroup userGroup = new UserGroup();
    userGroup.setName("name");
    userGroup.setIsFirmScope(true);
    userGroup.setIsInternal(true);
    userGroup.setIsActive(null);
    validationService.validateUserGroup(userGroup);
  }

  @Test
  public void testValidateUserGroup_whenUserGroupIsValid_shouldNotThrowFumValidationException() {
    UserGroup userGroup = new UserGroup();
    userGroup.setName("name");
    userGroup.setIsFirmScope(true);
    userGroup.setIsInternal(true);
    userGroup.setIsActive(true);
    validationService.validateUserGroup(userGroup);
  }

  @Test(expected = FumValidationException.class)
  public void testValidateFeaturePackageMandatoryFields_whenFeaturePackageRequestIsNull_shouldThrowFumValidationException() {
    validationService.validateFeaturePackageMandatoryFields(null);
  }

  @Test(expected = FumValidationException.class)
  public void testValidateFeaturePackageMandatoryFields_whenPackageTemplateIdIsNull_shouldThrowFumValidationException() {
    validationService.validateFeaturePackageMandatoryFields(new FeaturePackageRequest());
  }

  @Test
  public void testValidateFeaturePackageMandatoryFields_whenPackageTemplateIdIsNull_shouldNotThrowFumValidationException() {
    FeaturePackageRequest featurePackageRequest = new FeaturePackageRequest();
    featurePackageRequest.setPackageTemplateId(12);
    validationService.validateFeaturePackageMandatoryFields(featurePackageRequest);
  }

}