package ca.bnc.wealth.api.authorization.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.utility.MockData;
import ca.bnc.wealth.common.authorization.model.Capability;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.repo.iam.CapabilityRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PermissionRepository;
import ca.bnc.wealth.common.jpa.repo.iam.RoleRepository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class CapabilityServiceTest {

  private CapabilityService capabilityService;

  @MockitoBean
  private PermissionRepository permissionRepository;

  @MockitoBean
  private RoleRepository roleRepository;

  @MockitoBean
  private CapabilityRepository capabilityRepository;

  @SneakyThrows
  @Before
  public void setup() {
    capabilityService = new CapabilityService();
    FieldUtils.writeField(capabilityService, "permissionRepository", permissionRepository,
        true);
    FieldUtils.writeField(capabilityService, "roleRepository", roleRepository, true);
    FieldUtils.writeField(capabilityService, "capabilityRepository", capabilityRepository,
        true);
  }

  @Test(expected = FumNotFoundException.class)
  public void testDeleteCapability_whenCapabilityDoNotExist_shouldThrowFumNotFoundException() {
    capabilityService.deleteCapability("123");
  }

  @Test(expected = FumValidationException.class)
  public void testDeleteCapability_whenCapabilityHasPermissionDependency_shouldThrowFumValidationException() {
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(MockData.getCapabilityEntity());
    when(permissionRepository.findAll(any(Specification.class))).thenReturn(
        Arrays.asList(MockData.getPermissionEntity()));
    capabilityService.deleteCapability("123");
  }

  @Test(expected = FumValidationException.class)
  public void testDeleteCapability_whenCapabilityHasRoleDependency_shouldThrowFumValidationException() {
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(MockData.getCapabilityEntity());
    when(permissionRepository.findAll(any(Specification.class))).thenReturn(new ArrayList());
    when(roleRepository.findAll(any(Specification.class))).thenReturn(
        Arrays.asList(MockData.getRoleEntity()));
    capabilityService.deleteCapability("123");
  }

  @Test
  public void testDeleteCapability_whenCapabilityHasNoPermissionAndRoleDependency_shouldDeleteCapability() {
    when(capabilityRepository.findFirstByName(anyString())).thenReturn(MockData.getCapabilityEntity());
    when(permissionRepository.findAll(any(Specification.class))).thenReturn(new ArrayList());
    when(roleRepository.findAll(any(Specification.class))).thenReturn(new ArrayList());
    capabilityService.deleteCapability("123");
    verify(capabilityRepository, times(1)).delete(any(
        ca.bnc.wealth.common.jpa.entity.iam.Capability.class));
  }

  @Test(expected = FumValidationException.class)
  public void testCreateCapability_whenCapabilityAlreadyExists_shouldThrowFumValidationException() {
    when(capabilityRepository.findAll(any(Specification.class)))
        .thenReturn(Arrays.asList(MockData.getCapabilityEntity()));
    capabilityService.createCapability(MockData.IDP_SUBJECT, MockData.getCapabilityData());
  }

  @Test
  public void testCreateCapability_whenCapabilityDoNotExists_shouldCreateCapability() {
    when(capabilityRepository.findAll(any(Specification.class)))
        .thenReturn(new ArrayList());
    when(capabilityRepository.save(any(ca.bnc.wealth.common.jpa.entity.iam.Capability.class)))
        .thenReturn(MockData.getCapabilityEntity());
    Capability savedCapability = capabilityService
        .createCapability(MockData.IDP_SUBJECT, MockData.getCapabilityData());
    assertEquals(MockData.getCapabilityEntity().getCapabilityID(),
        savedCapability.getCapabilityID());
  }

  @Test
  public void getCapabilities_whenCapabilitiesExist_shouldReturnCapabilities() {
    when(capabilityRepository.findAll()).thenReturn(Arrays.asList(MockData.getCapabilityEntity()));
    List<Capability> capabilities = capabilityService.getCapabilities();
    assertEquals(MockData.getCapabilityEntity().getName(), capabilities.get(0).getName());
  }

}
