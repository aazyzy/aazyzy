package ca.bnc.wealth.api.authorization.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.utility.MockData;
import ca.bnc.wealth.common.authorization.model.FeaturePackageCreateResponse;
import ca.bnc.wealth.common.authorization.model.FeaturePackageRequest;
import ca.bnc.wealth.common.authorization.model.GetFeaturePackage;
import ca.bnc.wealth.common.authorization.model.PackageTemplateAssignment;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.fum.service.FeaturePackageServiceHelper;
import ca.bnc.wealth.common.fum.service.PackageTemplateServiceHelper;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackageAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackageAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class FeaturePackageServiceTest {

  private FeaturePackageService featurePackageService;

  @MockitoBean
  private FeaturePackageRepository featurePackageRepository;

  @MockitoBean
  private AuthorizationValidationService authorizationValidationService;

  @MockitoBean
  private PackageTemplateServiceHelper packageTemplateServiceHelper;

  @MockitoBean
  private FeaturePackageServiceHelper featurePackageServiceHelper;

  @SneakyThrows
  @Before
  public void setup() {
    featurePackageService = new FeaturePackageService();
    FieldUtils.writeField(featurePackageService, "authorizationValidationService",
        authorizationValidationService, true);
    FieldUtils.writeField(featurePackageService, "featurePackageRepository",
        featurePackageRepository, true);
    FieldUtils.writeField(featurePackageService, "featurePackageServiceHelper",
        featurePackageServiceHelper, true);
    FieldUtils.writeField(featurePackageService, "packageTemplateServiceHelper",
        packageTemplateServiceHelper, true);
  }

  @Test
  public void createFeaturePackage_whenFeaturePackageRequestIsValid_shouldCreateFeaturePackage() {
    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setFeaturePackageId(1);
    when(featurePackageServiceHelper.createFeaturePackage(anyLong(), anyList(), anyString())).thenReturn(featurePackage);
    FeaturePackageCreateResponse response = featurePackageService.createFeaturePackage(MockData.getFeaturePackageRequest(), MockData.IDP_SUBJECT);
    assertEquals(1, response.getFeaturePackageId());
  }

  @Test
  public void createFeaturePackage_withModuleOverRides_whenFeaturePackageRequestIsValid_shouldCreateFeaturePackage() {
    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setFeaturePackageId(1);
    when(featurePackageServiceHelper.createFeaturePackage(anyString(), anyList(), anyList(), anyString())).thenReturn(featurePackage);
    FeaturePackageRequest featurePackageRequest = new FeaturePackageRequest();
    featurePackageRequest.setPackageName("packageName");
    featurePackageRequest.setModuleOverrides(new ArrayList<>());
    featurePackageRequest.setFeatures(new ArrayList<>());

    FeaturePackageCreateResponse response = featurePackageService.createFeaturePackage(featurePackageRequest, MockData.IDP_SUBJECT);
    assertEquals(1, response.getFeaturePackageId());
  }

  @Test(expected = FumNotFoundException.class)
  public void getFeaturePackage_whenFeaturePackageDoNotExist_shouldThrowFumNotFoundException() {
    featurePackageService.getFeaturePackage(123, false);
  }

  @Test
  public void getFeaturePackage_whenDetailsRequestIsFalse_shouldReturnFeaturePackageWithoutDetails() {
    FeaturePackage mockFeaturePackage = MockData.getFeaturePackage();
    when(featurePackageRepository.findById(anyLong())).thenReturn(Optional.of(mockFeaturePackage));
    GetFeaturePackage actualFeaturePackage = featurePackageService.getFeaturePackage(123, false);
    assertNotNull(actualFeaturePackage);
    assertNull(actualFeaturePackage.getDetails());
  }

  @Test
  public void getFeaturePackage_whenDetailsRequestIsTrue_shouldReturnFeaturePackageWithDetails() {
    FeaturePackage mockFeaturePackage = MockData.getFeaturePackage();
    PackageTemplateAssignmentUserGroup packageTemplateAssignmentUserGroup = MockData.getPackageTemplateAssignmentUserGroup();
    PackageTemplateAssignmentResource packageTemplateAssignmentResource = MockData.getPackageTemplateAssignmentResource();
    FeaturePackageAssignmentResource featurePackageAssignmentResource = MockData.getFeaturePackageAssignmentResource();
    FeaturePackageAssignmentUserGroup featurePackageAssignmentUserGroup = MockData.getFeaturePackageAssignmentUserGroup();

    when(featurePackageRepository.findById(anyLong())).thenReturn(Optional.of(mockFeaturePackage));
    when(featurePackageServiceHelper.getFeaturePackageAssignment(anyInt(), eq(
        PackageAssignmentType.S))).thenReturn(Arrays.asList(featurePackageAssignmentResource));
    when( packageTemplateServiceHelper.getPackageTemplateAssignment(anyLong(),eq(
        PackageAssignmentType.S))).thenReturn(Map.of(345l, packageTemplateAssignmentResource));
    when(featurePackageServiceHelper.getFeaturePackageAssignment(anyInt(), eq(
        PackageAssignmentType.G))).thenReturn(Arrays.asList(featurePackageAssignmentUserGroup));
    when( packageTemplateServiceHelper.getPackageTemplateAssignment(anyLong(),eq(
        PackageAssignmentType.G))).thenReturn(Map.of(123l, packageTemplateAssignmentUserGroup));

    GetFeaturePackage actualFeaturePackage = featurePackageService.getFeaturePackage(123, true);
    assertNotNull(actualFeaturePackage);
    assertNotNull(actualFeaturePackage.getDetails());
  }

  @Test
  public void getFeaturePackage_whenDetailsRequestIsTrueAndWithResource_shouldReturnFeaturePackageWithoutDetails() {
   FeaturePackage mockFeaturePackage = MockData.getFeaturePackage();
    when(featurePackageRepository.findById(anyLong())).thenReturn(Optional.of(mockFeaturePackage));
    GetFeaturePackage actualFeaturePackage = featurePackageService.getFeaturePackage(123, true);
    assertNotNull(actualFeaturePackage);
    assertNotNull(actualFeaturePackage.getDetails());
  }

}
