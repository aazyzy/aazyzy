package ca.bnc.wealth.api.authorization.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.utility.MockData;
import ca.bnc.wealth.common.authorization.model.UpdateFeaturePackageTemplate;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.fum.service.PackageTemplateServiceHelper;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import java.util.Optional;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class FeaturePackageTemplateServiceTest {

  private FeaturePackageTemplateService featurePackageTemplateService;

  @MockitoBean
  private PackageTemplateRepository packageTemplateRepository;
  @MockitoBean
  private PackageTemplateServiceHelper packageTemplateServiceHelper;
  @MockitoBean
  private RedisCacheOperationService redisCacheOperationService;

  @SneakyThrows
  @Before
  public void setup() {
    featurePackageTemplateService = new FeaturePackageTemplateService();

    FieldUtils.writeField(featurePackageTemplateService, "packageTemplateServiceHelper",
        packageTemplateServiceHelper,
        true);
    FieldUtils.writeField(featurePackageTemplateService, "packageTemplateRepository",
        packageTemplateRepository,
        true);
    FieldUtils.writeField(featurePackageTemplateService, "redisCacheOperationService",
        redisCacheOperationService,
        true);
  }

  @Test
  public void createPackageTemplate() {
    when(packageTemplateServiceHelper.createPackageTemplate(any(PackageTemplate.class), anyList(), anyList())).thenReturn(MockData.getPackageTemplateEntity());
    ca.bnc.wealth.common.authorization.model.PackageTemplate response = featurePackageTemplateService.createPackageTemplate(MockData.getPackageTemplate());
    assertEquals(MockData.getPackageTemplateEntity().getPackageTemplateId(), response.getPackageTemplateId());
    verify(redisCacheOperationService, times(1)).deleteCacheByCacheName(any());
  }

  @Test(expected = FumNotFoundException.class)
  public void updateFeaturePackageTemplate_notFound() {
    when(packageTemplateRepository.findByName(anyString())).thenReturn(Optional.empty());
    featurePackageTemplateService.updateFeaturePackageTemplate("idp", "abc", new UpdateFeaturePackageTemplate());
  }

  @Test
  public void updateFeaturePackageTemplate_found() {
    when(packageTemplateRepository.findByName(anyString())).thenReturn(Optional.of(MockData.getPackageTemplateEntity()));
    UpdateFeaturePackageTemplate updateFeaturePackageTemplate = new UpdateFeaturePackageTemplate();
    updateFeaturePackageTemplate.setStatus(true);
    featurePackageTemplateService.updateFeaturePackageTemplate("idp", "abc", updateFeaturePackageTemplate);
    verify(redisCacheOperationService, times(1)).deleteCacheByCacheName(any());
  }
}
