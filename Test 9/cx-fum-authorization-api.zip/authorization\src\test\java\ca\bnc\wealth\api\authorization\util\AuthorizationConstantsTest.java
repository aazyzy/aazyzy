package ca.bnc.wealth.api.authorization.util;

import java.lang.reflect.Constructor;
import org.junit.Test;

public class AuthorizationConstantsTest {

  @Test(expected = IllegalStateException.class)
  public void testConstantsConstructor() throws Exception {
    Constructor<AuthorizationConstants> constructor = AuthorizationConstants.class.getDeclaredConstructor();
    constructor.setAccessible(true);
    try {
      constructor.newInstance();
    } catch (Exception e) {
      throw (IllegalStateException) e.getCause();
    }
  }
}
