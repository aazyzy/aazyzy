package ca.bnc.wealth.api.authorization.util;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.Test;

public class GeneralUtilsTest {

  @Test
  public void testIsNumber_whenStringIsNumber_shouldReturnTrue() {
    assertTrue(GeneralUtils.isNumber("123"));
  }

  @Test
  public void testIsNumber_whenStringIsNotNumber_shouldReturnFalse() {
    assertFalse(GeneralUtils.isNumber("invalid"));
  }

}
