package ca.bnc.wealth.api.authorization.util;

import static org.junit.Assert.assertEquals;

import ca.bnc.wealth.common.authorization.model.PermissionInfo;
import ca.bnc.wealth.common.authorization.model.ResourceData;
import ca.bnc.wealth.common.authorization.model.Role;
import ca.bnc.wealth.common.authorization.model.UserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.Capability;
import ca.bnc.wealth.common.jpa.entity.iam.Permission;
import java.util.Map;
import org.junit.Test;

public class MapperUtilsTests {

  @Test
  public void toDtoPermission() {
    Permission request = new Permission();
    request.setName("permission");
    PermissionInfo response = MapperUtils.toDto(request);
    assertEquals("permission", response.getName());
  }

 /* @Test
  public void toDtoUserGroupRoleAssignmentView() {
    UserGroupRoleAssignmentView request = new UserGroupRoleAssignmentView();
    request.setCapabilityCode("capability");
    request.setRole("role");
    Role response = MapperUtils.toDto(request);
    assertEquals("capability", response.getCapability());
    assertEquals("role", response.getRoleName());
  }

  @Test
  public void toDtoRolePermissionAssignmentView() {
    RolePermissionAssignmentView request = new RolePermissionAssignmentView();
    request.setCapabilityCode("capability");
    request.setPermission("permission");
    PermissionAssignment response = MapperUtils.toDto(request);
    assertEquals("capability", response.getCapability());
    assertEquals("permission", response.getPermissionName());
  }*/

  @Test
  public void toDtoUserGroup() {
    ca.bnc.wealth.common.jpa.entity.iam.UserGroup request = new ca.bnc.wealth.common.jpa.entity.iam.UserGroup();
    request.setName("usergroup");
    request.setDescription("ugd");
    UserGroup response = MapperUtils.toDto(request);
    assertEquals("usergroup", response.getName());
    assertEquals("ugd", response.getDescription());
  }

  @Test
  public void toDtoRole() {
    ca.bnc.wealth.common.jpa.entity.iam.Role request = new ca.bnc.wealth.common.jpa.entity.iam.Role();
    request.setName("role");
    //request.setRemedyAppId("app");
    request.setRoleId(1);
    Capability c = new Capability();
    c.setName("capability");
    request.setCapability(c);
    Role response = MapperUtils.toDto(request);
    assertEquals("role", response.getRoleName());
    assertEquals("capability", response.getCapability());
    assertEquals("1", response.getRoleId());
  }

  @Test
  public void testToResourceDataDto() {
    Map<String, Object> resourceMap = Map.of("NAME", "name",
        "DESCRIPTION", "description",
        "ACTIVE", true,
        "CONF_URI", "confUri",
        "VERSION", "version",
        "GROUP_NAME", "groupName",
        "LABEL", "label",
        "PURPOSE", "purpose");

    ResourceData resourceData = MapperUtils.toResourceDataDto(resourceMap);
    assertEquals(resourceMap.get("NAME"), resourceData.getName());
    assertEquals(resourceMap.get("DESCRIPTION"), resourceData.getDescription());
    assertEquals(resourceMap.get("ACTIVE"), resourceData.getActive());
    assertEquals(resourceMap.get("CONF_URI"), resourceData.getConfUri());
    assertEquals(resourceMap.get("VERSION"), resourceData.getVersion());
    assertEquals(resourceMap.get("GROUP_NAME"), resourceData.getGroupName());
    assertEquals(resourceMap.get("LABEL"), resourceData.getLabel());
    assertEquals(resourceMap.get("PURPOSE"), resourceData.getPurpose());
  }
}
