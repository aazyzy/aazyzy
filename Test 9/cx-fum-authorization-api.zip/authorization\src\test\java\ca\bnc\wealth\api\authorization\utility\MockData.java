package ca.bnc.wealth.api.authorization.utility;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.common.authorization.model.ActionType;
import ca.bnc.wealth.common.authorization.model.Capability;
import ca.bnc.wealth.common.authorization.model.FeaturePackageCreateResponse;
import ca.bnc.wealth.common.authorization.model.FeaturePackageRequest;
import ca.bnc.wealth.common.authorization.model.PackageTemplate.TypeEnum;
import ca.bnc.wealth.common.authorization.model.PackageTemplateAssignment;
import ca.bnc.wealth.common.authorization.model.PackageTemplateDetails;
import ca.bnc.wealth.common.authorization.model.PackageTemplateDetails.AssignmentModeEnum;
import ca.bnc.wealth.common.authorization.model.PackageTemplateDetails.AssignmentTypeEnum;
import ca.bnc.wealth.common.authorization.model.PermissionInfo;
import ca.bnc.wealth.common.authorization.model.ResourceData;
import ca.bnc.wealth.common.authorization.model.Role;
import ca.bnc.wealth.common.authorization.model.TemplateResourceAssignment;
import ca.bnc.wealth.common.authorization.model.UpdateTemplateResourceAssignment;
import ca.bnc.wealth.common.authorization.model.UserGroup;
import ca.bnc.wealth.common.jpa.entity.enums.FirmAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackageAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackageAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.FirmAssignmentFeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.Permission;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.entity.iam.RolePermissionAssignment;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentFeaturePackage;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class MockData {

  public static String ROLE = "PORTFOLIO_MANAGER";
  public static String IDP_SUBJECT = "idpSubject";
  public static String CAPABILITY = "mf-orders";
  public static String PERMISSION = "BOOK_ORDERS";
  public static String REQUESTED_BY = "system";
  public static String TEMPLATE_NAME = "AdminAll";

  public static User getUser() {
    User user = new User();
    user.setIdpSubject("idpSubject");
    return user;
  }

  public static List<PermissionInfo> createMockPermisionList() {
    List<PermissionInfo> permissionList = new ArrayList<>();
    PermissionInfo permission = new PermissionInfo();
    permission.setCapability("mf-orders");
    permission.setName("BOOK_ORDERS");
    permissionList.add(permission);
    return permissionList;
  }

  public static List<Role> createMockRoleList() {
    List<Role> roleList = new ArrayList<>();
    Role role = new Role();
    role.setCapability("mf-orders");
    role.setRoleName("PORTFOLIO_MANAGER");
    roleList.add(role);
    return roleList;
  }

  public static List<PermissionInfo> createMockPermission() {
    List<PermissionInfo> lst = new ArrayList<>();
    PermissionInfo permissionAssignment = new PermissionInfo();
    permissionAssignment.setName("access-control:list_roles");
    permissionAssignment.setCapability("access-control");
    lst.add(permissionAssignment);
    return lst;
  }

  public static List<UserGroup> createUserGroupList() {
    UserGroup userGroup = new UserGroup();
    userGroup.setUserGroupId(1234L);
    userGroup.setName("Wealth.CompassX.Assistant");
    userGroup.setDescription("Wealth.CompassX.Assistant");
    return List.of(userGroup);
  }

  public static UserGroup createUserGroup() {
    return createUserGroupList().get(0);
  }

  public static Role getRole() {
    Role role = new Role();
    role.setRoleName("wealth:cx-user-conf:viewer");
    return role;
  }

  public static List<String> createRoles() {
    List<String> roleList = new ArrayList<>();
    roleList.add("wealth:cx-user-conf:viewer");

    return roleList;
  }

  public static List<PermissionInfo> createPermissionInfoList() {
    List<PermissionInfo> permissionInfoList = new ArrayList<>();
    PermissionInfo permissionInfo = new PermissionInfo();
    permissionInfo.setPermissionId("1234");
    permissionInfo.setName("acm:edit_orders");
    permissionInfoList.add(permissionInfo);
    return permissionInfoList;
  }

  public static List<PermissionInfo> createPermissionAssignments() {
    List<PermissionInfo> permissionInfoList = new ArrayList<>();
    PermissionInfo permissionAssignment = new PermissionInfo();
    permissionAssignment.setName("amend_applications");
    permissionInfoList.add(permissionAssignment);
    return permissionInfoList;
  }

  public static List<Permission> createPermissionList() {
    Permission permission = new Permission();
    permission.setName("capability:permission");
    return Arrays.asList(permission);
  }

  public static ResourceData getResourceData() {
    return ResourceData.builder()
        .name("test_resource")
        .description("test_description")
        .active(true)
        .version("version_1")
        .confUri("conf_uri_1")
        .groupName("groupName")
        .label("label")
        .purpose("purpose")
        .build();
  }

  public static Capability getCapabilityData() {
    return getCapabilityDataList().get(0);
  }

  public static List<Capability> getCapabilityDataList() {
    Capability capability = new Capability();
    capability.capabilityID(1234L);
    capability.setName("Capability");
    capability.setDescription("This is a capability");
    capability.setLob("CapabilityLob");
    List<Capability> capabilities = Arrays.asList(capability);
    return capabilities;
  }

  public static ca.bnc.wealth.common.jpa.entity.iam.Capability getCapabilityEntity() {
    ca.bnc.wealth.common.jpa.entity.iam.Capability capability =
        new ca.bnc.wealth.common.jpa.entity.iam.Capability();
    capability.setCapabilityID(1234L);
    capability.setName(CAPABILITY);
    capability.setDescription("This is a capability");
    capability.setLob("CapabilityLob");

    return capability;
  }

  public static FeaturePackage getFeaturePackage() {
    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setActive(true);
    featurePackage.setPackageTemplate(MockData.getPackageTemplateEntity());
    featurePackage.setFeaturePackageId(132);
    featurePackage.setFeaturePackageAssignmentResources(Arrays.asList(getFeaturePackageAssignmentResource()));
    featurePackage.setFeaturePackageAssignmentUserGroups(Arrays.asList(getFeaturePackageAssignmentUserGroup()));
    return featurePackage;
  }

  public static FeaturePackageAssignmentResource getFeaturePackageAssignmentResource() {
    FeaturePackageAssignmentResource resource = new FeaturePackageAssignmentResource();
    resource.setFeaturePackage(new FeaturePackage());
    resource.setSelected(true);
    resource.setFeaturePackageAssignmentId(1234);
    resource.setPackageTemplateAssignmentResource(getPackageTemplateAssignmentResource());
    return resource;
  }

  public static FeaturePackageAssignmentUserGroup getFeaturePackageAssignmentUserGroup() {
    FeaturePackageAssignmentUserGroup userGroup = new FeaturePackageAssignmentUserGroup();
    userGroup.setFeaturePackage(new FeaturePackage());
    userGroup.setFeaturePackageAssignmentId(1234);
    userGroup.setPackageTemplateAssignmentUserGroup(getPackageTemplateAssignmentUserGroup());
    userGroup.setSelected(true);
    return userGroup;
  }

  public static FeaturePackageRequest getFeaturePackageRequest() {
    FeaturePackageRequest featurePackageRequest = new FeaturePackageRequest();
    featurePackageRequest.setPackageTemplateId(1234);
    featurePackageRequest.setAssignments(Arrays.asList(new PackageTemplateAssignment()));
    return featurePackageRequest;
  }

  public static PackageTemplateAssignment getPackageTemplateAssignmentAsUserGroup() {
    PackageTemplateAssignment packageTemplateAssignment = new PackageTemplateAssignment();
    packageTemplateAssignment.setAssignmentId(Math.toIntExact(getPackageTemplateAssignmentUserGroup()
        .getTemplateAssignmentId()));
    packageTemplateAssignment.setSelected(true);
    return packageTemplateAssignment;
  }

  public static PackageTemplateAssignment getPackageTemplateAssignmentAsResource() {
    PackageTemplateAssignment packageTemplateAssignment = new PackageTemplateAssignment();
    packageTemplateAssignment.setAssignmentId(Math.toIntExact(getPackageTemplateAssignmentResource()
        .getTemplateAssignmentId()));
    packageTemplateAssignment.setSelected(true);
    return packageTemplateAssignment;
  }

  public static FeaturePackageCreateResponse getFeaturePackageCreateResponse() {
    FeaturePackageCreateResponse featurePackageCreateResponse = new FeaturePackageCreateResponse();
    featurePackageCreateResponse.setFeaturePackageId(1234L);
    return featurePackageCreateResponse;
  }

  public static UserAssignmentFeaturePackage getUserAssignmentFeaturePackage() {
    UserAssignmentFeaturePackage userAssignmentFeaturePackage = new UserAssignmentFeaturePackage();
    userAssignmentFeaturePackage.setAssignmentType(UserAssignmentType.S);
    userAssignmentFeaturePackage.setFeaturePackage(getFeaturePackage());
    userAssignmentFeaturePackage.setUserConfiguration(getIamUserConfiguration());
    return userAssignmentFeaturePackage;
  }

  public static IamUserConfiguration getIamUserConfiguration() {
    IamUserConfiguration iamUserConfiguration = new IamUserConfiguration();
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setIdpSubject(IDP_SUBJECT);
    iamUserConfiguration.setIdpUserIdentifier(IDP_SUBJECT);
    iamUserConfiguration.setFirstName("firmName");
    iamUserConfiguration.setLastName("lastName");
    iamUserConfiguration.setEmail("email@email.com");
    return iamUserConfiguration;
  }

  public static FirmAssignmentFeaturePackage getFirmAssignmentFeaturePackage() {
    FirmAssignmentFeaturePackage firmAssignmentFeaturePackage = new FirmAssignmentFeaturePackage();
    firmAssignmentFeaturePackage.setFeaturePackage(getFeaturePackage());
    firmAssignmentFeaturePackage.setAssignmentType(FirmAssignmentType.R);
    firmAssignmentFeaturePackage.setFirm(getFirm());
    return firmAssignmentFeaturePackage;
  }

  public static Firm getFirm() {
    Firm firm = new Firm();
    firm.setFirmId("12342");
    firm.setActive(true);
    firm.setFirmType(FirmType.IB);
    firm.setName("firm");
    return firm;
  }

  public static ca.bnc.wealth.common.authorization.model.PackageTemplate getPackageTemplate() {
    ca.bnc.wealth.common.authorization.model.PackageTemplate packageTemplate =
        new ca.bnc.wealth.common.authorization.model.PackageTemplate();
    packageTemplate.setName("packageTemplate");
    packageTemplate.setDescription("description");
    packageTemplate.setActive(true);
    packageTemplate.setType(TypeEnum.FIRM);
    packageTemplate.setFirmType("IB");
    packageTemplate.setDetails(Arrays.asList(getPackageTemplateDetailWithResource(),
        getPackageTemplateDetailWithUserGroup()));
    return packageTemplate;
  }

  public static PackageTemplateDetails getPackageTemplateDetailWithResource() {
    PackageTemplateDetails details = new PackageTemplateDetails();
    details.setTemplateDetailId(1234L);
    details.setAssignmentMode(AssignmentModeEnum.O);
    details.setAssignmentType(AssignmentTypeEnum.S);
    details.setResource(getResource());
    details.setAssignee(getResource().getName());
    details.setSelectionDefault(false);
    return details;
  }

  public static PackageTemplateDetails getPackageTemplateDetailWithUserGroup() {
    PackageTemplateDetails details = new PackageTemplateDetails();
    details.setTemplateDetailId(1234L);
    details.setAssignmentMode(AssignmentModeEnum.M);
    details.setAssignmentType(AssignmentTypeEnum.G);
    details.setUserGroup(getUserGroup());
    details.setAssignee(getUserGroup().getName());
    details.setSelectionDefault(true);
    return details;
  }

  public static ca.bnc.wealth.common.authorization.model.Resource getResource() {
    ca.bnc.wealth.common.authorization.model.Resource resource =
        new ca.bnc.wealth.common.authorization.model.Resource();
    resource.setResourceId(123L);
    resource.setName(getResourceEntity().getName());
    resource.setType("F");
    resource.setLabel("label");
    resource.setPurpose("purpose");
    return resource;
  }

  public static UserGroup getUserGroup() {
    UserGroup userGroup = new UserGroup();
    userGroup.setUserGroupId(1234L);
    userGroup.setName(getUserGroupEntity().getName());
    userGroup.setDescription("This is userGroup");
    userGroup.setIsInternal(true);
    userGroup.setIsFirmScope(true);
    userGroup.setIsActive(true);
    return userGroup;
  }

  public static PackageTemplate getPackageTemplateEntity() {
    PackageTemplate packageTemplate = new PackageTemplate();
    packageTemplate.setPackageTemplateId(1234L);
    packageTemplate.setName("packageTemplate");
    packageTemplate.setDescription("description");
    packageTemplate.setActive(true);
    packageTemplate.setType(PackageType.F);
    packageTemplate.setFirmType(FirmType.IB);
    packageTemplate.setPackageTemplateAssignmentResources(Arrays.asList(getPackageTemplateAssignmentResource()));
    packageTemplate.setPackageTemplateAssignmentUserGroups(Arrays.asList(getPackageTemplateAssignmentUserGroup()));
    return packageTemplate;
  }

  public static PackageTemplateAssignmentResource getPackageTemplateAssignmentResource() {
    PackageTemplateAssignmentResource resource = new PackageTemplateAssignmentResource();
    resource.setTemplateAssignmentId(345);
    resource.setResource(getResourceEntity());
    resource.setAssignmentType(PackageAssignmentType.S);
    resource.setAssignmentMode(PackageAssignmentMode.O);
    return resource;
  }

  public static PackageTemplateAssignmentUserGroup getPackageTemplateAssignmentUserGroup() {
    PackageTemplateAssignmentUserGroup userGroup = new PackageTemplateAssignmentUserGroup();
    userGroup.setTemplateAssignmentId(123);
    userGroup.setAssignmentMode(PackageAssignmentMode.M);
    userGroup.setAssignmentType(PackageAssignmentType.G);
    userGroup.setUserGroup(getUserGroupEntity());
    return userGroup;
  }

  public static Permission getPermissionEntity() {
    Permission permission = new Permission();
    permission.setName(PERMISSION);
    permission.setDescription("Description");
    permission.setActive(true);
    permission.setCapability(getCapabilityEntity());

    return permission;
  }

  public static Resource getResourceEntity() {
    return getResourceEntityList().get(0);
  }

  public static List<Resource> getResourceEntityList() {
    Resource resource1 = new Resource();
    resource1.setName("resource1");
    resource1.setDescription("res desc");
    resource1.setConfUri("conf");
    resource1.setResourceId(1234L);
    resource1.setActive(true);
    resource1.setGroupName("groupName");
    resource1.setLabel("label2");
    resource1.setPurpose("purpose2");
    resource1.setRestriction(true);

    Resource resource2 = new Resource();
    resource2.setName("resource2");
    resource2.setDescription("res desc");
    resource2.setConfUri("conf");
    resource2.setResourceId(1234L);
    resource2.setActive(true);
    resource2.setGroupName("groupName");
    resource2.setLabel("label2");
    resource2.setPurpose("purpose2");
    resource2.setRestriction(false);

    return Arrays.asList(resource1, resource2);
  }

  public static ca.bnc.wealth.common.jpa.entity.iam.UserGroup getUserGroupEntity() {
    ca.bnc.wealth.common.jpa.entity.iam.UserGroup userGroup = new ca.bnc.wealth.common.jpa.entity.iam.UserGroup();
    userGroup.setIsFirmScope(true);
    userGroup.setUserGroupId(1234L);
    userGroup.setName("usergroup");
    userGroup.setIsInternal(true);
    userGroup.setDescription("usergroup desc");
    return userGroup;
  }

  public static ca.bnc.wealth.common.jpa.entity.iam.Role getRoleEntity() {
    ca.bnc.wealth.common.jpa.entity.iam.Role role = new ca.bnc.wealth.common.jpa.entity.iam.Role();
    role.setRoleId(1234L);
    role.setName("Role name");

    ca.bnc.wealth.common.jpa.entity.iam.Capability capability =
        new ca.bnc.wealth.common.jpa.entity.iam.Capability();
    capability.setCapabilityID(1234L);
    capability.setName(CAPABILITY);
    role.setCapability(capability);
    role.setRolePermissionAssignments(getRolePermissionAssignmentList());
    return role;
  }

  public static Map<String, Object> getRoleMap() {
    return Map.of("ROLE_ID", getRoleEntity().getRoleId(),
        "CAPABILITY", getRoleEntity().getCapability().getName(),
        "NAME", getRoleEntity().getName());
  }

  public static Map<String, Object> getPermissionMap() {
    return Map.of("PERMISSION_ID", 2,
        "CAPABILITY", MockData.CAPABILITY,
        "NAME", "permission",
        "ACTIVE", true);
  }

  public static List<RolePermissionAssignment> getRolePermissionAssignmentList() {
    RolePermissionAssignment assignment = new RolePermissionAssignment();
    assignment.setRole(new ca.bnc.wealth.common.jpa.entity.iam.Role());
    assignment.setPermission(getPermissionEntity());

    return Arrays.asList(assignment);
  }

  public static UpdateTemplateResourceAssignment getUpdateTemplateResourceAssignment(ActionType action) {
    UpdateTemplateResourceAssignment updateTemplateResourceAssignment =
        new UpdateTemplateResourceAssignment();
    updateTemplateResourceAssignment.setAction(action);
    updateTemplateResourceAssignment.resources(getTemplateResourceAssignments());

    return updateTemplateResourceAssignment;
  }

  public static List<TemplateResourceAssignment> getTemplateResourceAssignments() {
    TemplateResourceAssignment templateResourceAssignment1 = new TemplateResourceAssignment();
    templateResourceAssignment1.setName("order");
    templateResourceAssignment1.setRestriction(true);
    templateResourceAssignment1.setSelectionDefault(true);
    templateResourceAssignment1.setAssignmentMode(TemplateResourceAssignment.AssignmentModeEnum.O);
    TemplateResourceAssignment templateResourceAssignment2 = new TemplateResourceAssignment();
    templateResourceAssignment2.setName("order");
    templateResourceAssignment2.setRestriction(false);
    templateResourceAssignment2.setSelectionDefault(true);
    templateResourceAssignment2.setAssignmentMode(TemplateResourceAssignment.AssignmentModeEnum.M);
    TemplateResourceAssignment templateResourceAssignment3 = new TemplateResourceAssignment();
    templateResourceAssignment3.setName("purchase");
    templateResourceAssignment3.setRestriction(false);
    templateResourceAssignment3.setSelectionDefault(false);
    templateResourceAssignment3.setAssignmentMode(TemplateResourceAssignment.AssignmentModeEnum.O);

    return Arrays.asList(templateResourceAssignment1, templateResourceAssignment2);
  }

  public static PackageTemplate getPackageTemplateWithPackageTemplateAssignmentResource() {
    ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(new ArrayList<>());
    MockData.getTemplateResourceAssignments().forEach(r -> {
      PackageTemplateAssignmentResource resourceAssignment = new PackageTemplateAssignmentResource();
      Resource resource = new Resource();
      resource.setName(r.getName());
      resource.setRestriction(r.getRestriction());
      resourceAssignment.setResource(resource);
      packageTemplate.getPackageTemplateAssignmentResources().add(resourceAssignment);
    });

    return packageTemplate;
  }

  public static List<Resource> getResourceEntities() {
    Resource resource1 = new Resource();
    resource1.setName("order");
    resource1.setRestriction(true);

    Resource resource2 = new Resource();
    resource2.setName("order");
    resource2.setRestriction(false);

    Resource resource3 = new Resource();
    resource3.setName("purchase");
    resource3.setRestriction(false);

    Resource resource4 = new Resource();
    resource4.setName("purchase_admin");
    resource4.setRestriction(true);

    Resource resource5 = new Resource();
    resource5.setName("purchase_admin");
    resource5.setRestriction(false);

    return Arrays.asList(resource1, resource2, resource3);
  }
}
