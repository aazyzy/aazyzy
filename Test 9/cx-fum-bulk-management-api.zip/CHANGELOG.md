# Changelog

## [5.0.2](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/compare/v5.0.1...v5.0.2) (2026-11-20)


### Bug Fixes

* rebuild image on base image java-25-1.2.2 ([#71](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/issues/71)) ([376e59c](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/376e59c35dbe513a3abb5d2bcbd471052c7036a5))

## [5.0.1](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/compare/v5.0.0...v5.0.1) (2026-11-02)


### Miscellaneous Chores

* move to parent-pom-core 3.0.1, which fixes the Snyk findings of the 5.0.0 release: Tomcat 11.0.27, Jackson 3.2.4 and 2.22.4, Hibernate Validator 9.1.6.Final and java-jwt 4.6.2

## [5.0.0](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/compare/v4.0.1...v5.0.0) (2026-10-29)


### Miscellaneous Chores

* align develop versions with main after the 4.0.1 release ([#50](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/pull/50)) ([1648cd1](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/1648cd13856e7a66f8965f3d70a0007ed3f8ce19))
* move bulk-management-api to Spring Boot 4.1.1 in develop ([#52](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/pull/52)) ([9a1d154](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/9a1d154dcbe4c8bfe036300a2b3e970cbf46b3bc))
* skip Sonar in the release workflow on Java 25 ([#56](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/pull/56)) ([b703072](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/b70307218933a50a4d0edab5f90b5f63b3565f82))
* skip the SonarQube analysis for now ([#54](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/pull/54)) ([0a6c15d](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/0a6c15d4afc9ec7d0612ce70e279fc57dcc07572))
* sync 6900 dependency versions to develop SNAPSHOTs ([#55](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/pull/55)) ([311af2f](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/311af2fd3efa8196ad4b748168f3de606d69dd25))

## [4.0.1](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/compare/v4.0.0...v4.0.1) (2026-10-14)


### Miscellaneous Chores

* remediate Snyk vulnerabilities on the 4.0 release line ([#47](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/issues/47)) ([abbe9ea](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/abbe9ea4673d4efd8ce38808d5f26a588810a7e9))

## [4.0.0](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/compare/v3.2.0...v4.0.0) (2026-10-14)


### Miscellaneous Chores

* pin released 6900 dependency versions for release 4.0.0: commons-lib 2.1.42 (NWPI-15097), api-schemas-wealth 1.11.58 ([0c7a94f](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/0c7a94f9486f8ce61d81a9ee91032e653735fd45))

## [3.2.0](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/compare/v3.0.1...v3.2.0) (2026-09-16)


### Bug Fixes

* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([ba4e1da](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/ba4e1dad15164d5ffc486daaef3409a8b1a3c57f))
* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([1de3065](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/1de3065d41d2b7626431aba86d4d80e17abe367d))


### Miscellaneous Chores

* pin released 6900 dependency versions for release 3.2.0 ([836c34d](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/836c34da5e5bece7374e28e5d7017af3075c9850))

## [3.0.1](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/compare/v3.0.0...v3.0.1) (2026-08-25)


### Miscellaneous Chores

* release 3.0.1 with the NWPI-14906 RestClient timeout fix ([#30](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/issues/30)) ([b9b2810](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/b9b28106dac9376396b25cdde86587d0ac7eb583))

## [3.0.0](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/compare/v2.2.6...v3.0.0) (2026-08-19)


### Miscellaneous Chores

* release 3.0.0 ([0a15fb4](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/0a15fb452a65dab5d9c897a95c3057bacdf4cc1b))

## [2.2.6](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/compare/v2.2.5...v2.2.6) (2026-08-19)


### Bug Fixes

* **deps:** pin at.yawk.lz4:lz4-java 1.11.1 for CVE-2026-59949 ([#20](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/issues/20)) ([da6ca4f](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/da6ca4fc50e76d6539595f995da38809ff56f4c7))
* **deps:** pin at.yawk.lz4:lz4-java 1.11.1 for CVE-2026-59949 ([#21](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/issues/21)) ([34ca1cf](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/34ca1cf20e6ba7753fc360f5a1f755023536f35c))
* **deps:** pin tomcat-embed 10.1.56 and logback-core 1.5.36 (Snyk HIGH) ([#13](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/issues/13)) ([e7f01cf](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/e7f01cf50a73a2c653d70e0af6dfe3605c23fa31))
* **deps:** pin vulnerable transitive dependencies for Snyk remediation ([#22](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/issues/22)) ([c5d7863](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/c5d786332880ed269ac64b880a3aaa887620bdbf))

## [2.2.5](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/compare/v2.2.4...v2.2.5) (2026-06-29)


### Bug Fixes

* release 2.2.1 ([348c2d0](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/348c2d0f59085a798be28f1005b992d485d19721))

## [2.2.4](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/compare/v2.2.3...v2.2.4) (2026-06-09)


### Bug Fixes

* first release in github ([8f5bc43](https://github.com/NBC-GPMF/cx-fum-bulk-management-api/commit/8f5bc43ace234c4fa606b4f6413ccf0b9d2548fb))
