# Bulk Management API

Spring Boot microservice that manages bulk upload and export workflows for user configuration and migration operations in the FUM domain.

## Overview

- Runtime: Java 17
- Framework: Spring Boot
- Build tool: Maven
- Artifact: ca.bnc.wealth.api:bulk-management-api
- Default port: 8081
- Context path: /bulk-management-api
- Management base path: /manage

## Prerequisites

- Java 17
- Maven 3.8+
- Access to internal Maven repositories (parent and shared libraries)
- Local runtime overrides file (for example application-local.yml)

## Build and Test

```bash
# Compile
mvn compile

# Run tests
mvn test

# Build executable jar
mvn clean package -DskipTests

# Full verification build
mvn clean install
```

Build output:

- target/bulk-management-api-exec.jar

## Run

### Option 1: Run packaged jar

```bash
java -Dspring.config.additional-location="file:/absolute/path/application-local.yml" -jar target/bulk-management-api-exec.jar
```

### Option 2: Run from IDE

Add VM option:

```text
-Dspring.config.additional-location=/absolute/path/application-local.yml
```

The service starts on port 8081 with context path /bulk-management-api.

Health endpoint:

```bash
curl -v http://localhost:8081/bulk-management-api/manage/health
```

Info endpoint:

```bash
curl -v http://localhost:8081/bulk-management-api/manage/info
```

## API Endpoints

Base path: /bulk-management-api

| Method | Path | Description |
|---|---|---|
| GET | /templates/{template-format} | Download template file for a template name/format |
| POST | /files/{template-format}?firmId={firmId} | Upload a bulk input file |
| POST | /batches/trigger/{batch-id}?firmId={firmId} | Trigger processing for a previously uploaded batch |
| POST | /batches/search | Search batches by type, template names, and filters |
| GET | /batches/{batch-id}/status | Get batch status (optionally with details) |
| GET | /batches/{batch-id}/file | Download originally uploaded file |
| GET | /batches/{batch-id}/results | Download result/output file |
| POST | /batches/trigger/export/{template-name} | Trigger export process for a template |
| PUT | /batches/status | Update status for one or more batch records |

Notes:

- Endpoints are defined via contract-first interface implementation in the controller.
- Authentication is enforced by shared security libraries.

## Configuration

Core runtime properties in src/main/resources/application.yml:

- server.port: 8081
- server.servlet.context-path: /bulk-management-api
- management.endpoints.web.base-path: /manage
- spring.application.name: bulk-management-api

Commonly used properties:

- KAFKA_ENV (used to compose consumer group id)
- app.kafka.enable (default true)
- app.scheduling.enable (default true)
- bulk.schedule.duration (default 30 in application.yml)
- bulk.schedule.callback.name (default BULK_MANAGEMENT_API_CALLBACK_SCHEDULE)
- bulk.export.batch.chunkSize (default 50)
- bulk.export.batch.timeBetweenChunkExec (default 60000)
- bulk.export.batch.disableDelay (default true)
- feign.host.url (default http://localhost)
- feign.r2Api.businessViewId
- feign.ciamApi.context

Keep environment-specific and secret values in non-committed override files.

## Docker

Dockerfile expects a prebuilt jar in target:

```bash
mvn clean package -DskipTests
docker build -t bulk-management-api .
docker run -p 8081:8081 bulk-management-api
```

Container details:

- Base image: nbc-docker.artifacts.bnc.ca/nbc-gpmf/cx-nbin-base-docker-image:java-17-1.0.3
- Exposed port: 8081

## CI/CD

- PR and branch CI workflow: .github/workflows/ci.yaml
- Main branch deploy workflow: .github/workflows/build-deploy.yaml
- Release workflows and release-please config are under .github/workflows and .github/release-please

## Project Structure

Key packages:

- src/main/java/ca/bnc/wealth/api/bulk/management/controller
- src/main/java/ca/bnc/wealth/api/bulk/management/service
- src/main/java/ca/bnc/wealth/api/bulk/management/kafka
- src/main/java/ca/bnc/wealth/api/bulk/management/schedule
- src/main/java/ca/bnc/wealth/api/bulk/management/config

Main class:

- src/main/java/ca/bnc/wealth/api/bulk/management/Application.java

Tests:

- src/test/java/ca/bnc/wealth/api/bulk/management