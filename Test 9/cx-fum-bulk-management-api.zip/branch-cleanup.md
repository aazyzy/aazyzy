# Branch Cleanup Report: bulk-management-api

Generated: 2026-06-08 14:42:54
Default Branch: develop
Total Branches: 21

---

## Summary

- Total Branches: 21
- Excluded from Deletion: 0
- Marked for Deletion: 21

---

## All Branches

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `snyk-fix-6b25c7104786abdf3b8d830584e2fd22` | 2025-03-13 19:51:02 -0400 | 2025-03-13 19:51:02 -0400 | MERGED |
| `feature/NWPI-12957-33-get-bulk-batch-status-endpoint-to-bma` | 2025-03-24 18:18:11 -0400 | 2025-03-24 18:18:11 -0400 | MERGED |
| `feature/NWPI-12957-get-bulk-batch-status` | 2025-03-25 14:09:46 -0400 | 2025-03-25 14:09:46 -0400 | MERGED |
| `feature/NWPI-12934` | 2025-03-31 16:49:41 -0400 | 2025-03-31 16:49:41 -0400 | MERGED |
| `NWPI-13271` | 2025-04-22 17:33:46 -0400 | 2025-04-22 17:33:46 -0400 | MERGED |
| `release/1.24.0` | 2025-05-29 17:27:25 -0400 | 2025-05-29 17:27:25 -0400 | MERGED |
| `release/1.24.1` | 2025-06-02 16:33:04 -0400 | 2025-06-02 16:33:04 -0400 | MERGED |
| `release/1.24.2` | 2025-06-06 12:24:48 -0400 | 2025-06-06 12:24:48 -0400 | MERGED |
| `feature/NWPI-13538-api-adopt-bma-status-detailed-for-json` | 2025-06-12 12:19:57 -0400 | 2025-06-12 12:19:57 -0400 | MERGED |
| `release/1.26.0` | 2025-07-18 10:10:26 -0400 | 2025-07-18 10:10:26 -0400 | MERGED |
| `release/1.28.0` | 2025-11-10 15:52:28 -0500 | 2025-11-10 15:52:28 -0500 | MERGED |
| `feature/NWPI-13539-api-make-firm-id-optional-for-upload-file-for-batch-api` | 2025-11-27 23:57:11 -0500 | 2025-11-27 23:57:11 -0500 | MERGED |
| `release/2.1.0` | 2026-01-19 16:36:09 -0500 | 2026-01-19 16:36:09 -0500 | MERGED |
| `feature/NWPI-14278-1-create-attestation-api-performance-fixes` | 2026-01-20 08:12:09 -0500 | 2026-01-20 08:12:09 -0500 | MERGED |
| `feature/NWPI-14340-create-attestation-api-for-all-firms-never-finish` | 2026-02-23 16:30:38 -0500 | 2026-02-23 16:30:38 -0500 | MERGED |
| `release/2.1.1` | 2026-03-06 12:52:21 -0500 | 2026-03-06 12:52:21 -0500 | MERGED |
| `feature/subscription-bulk` | 2026-03-24 10:28:32 -0400 | 2026-03-24 10:28:32 -0400 | MERGED |
| `feature/NWPI-14414-use-subscription-api-7461-for-web-socket-notifications-backend-changes-part-2` | 2026-04-07 17:53:45 -0400 | 2026-04-07 17:53:45 -0400 | MERGED |
| `feature/bulk-status-cleanup` | 2026-05-21 09:57:20 -0400 | 2026-05-21 09:57:20 -0400 | MERGED |
| `release/2.2.0` | 2026-05-22 09:46:20 -0400 | 2026-05-22 09:46:20 -0400 | MERGED |
| `release/2.2.0.0` | 2026-05-29 20:58:28 -0400 | 2026-05-29 20:58:28 -0400 | MERGED |

---

## Excluded from Deletion

Criteria: Unmerged branches with last commit less than 2 months old
Count: 0

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| No branches excluded | | | |

---

## Marked for Deletion

Criteria: All merged branches + unmerged branches with last commit older than 2 months
Count: 21

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `snyk-fix-6b25c7104786abdf3b8d830584e2fd22` | 2025-03-13 19:51:02 -0400 | 2025-03-13 19:51:02 -0400 | MERGED |
| `feature/NWPI-12957-33-get-bulk-batch-status-endpoint-to-bma` | 2025-03-24 18:18:11 -0400 | 2025-03-24 18:18:11 -0400 | MERGED |
| `feature/NWPI-12957-get-bulk-batch-status` | 2025-03-25 14:09:46 -0400 | 2025-03-25 14:09:46 -0400 | MERGED |
| `feature/NWPI-12934` | 2025-03-31 16:49:41 -0400 | 2025-03-31 16:49:41 -0400 | MERGED |
| `NWPI-13271` | 2025-04-22 17:33:46 -0400 | 2025-04-22 17:33:46 -0400 | MERGED |
| `release/1.24.0` | 2025-05-29 17:27:25 -0400 | 2025-05-29 17:27:25 -0400 | MERGED |
| `release/1.24.1` | 2025-06-02 16:33:04 -0400 | 2025-06-02 16:33:04 -0400 | MERGED |
| `release/1.24.2` | 2025-06-06 12:24:48 -0400 | 2025-06-06 12:24:48 -0400 | MERGED |
| `feature/NWPI-13538-api-adopt-bma-status-detailed-for-json` | 2025-06-12 12:19:57 -0400 | 2025-06-12 12:19:57 -0400 | MERGED |
| `release/1.26.0` | 2025-07-18 10:10:26 -0400 | 2025-07-18 10:10:26 -0400 | MERGED |
| `release/1.28.0` | 2025-11-10 15:52:28 -0500 | 2025-11-10 15:52:28 -0500 | MERGED |
| `feature/NWPI-13539-api-make-firm-id-optional-for-upload-file-for-batch-api` | 2025-11-27 23:57:11 -0500 | 2025-11-27 23:57:11 -0500 | MERGED |
| `release/2.1.0` | 2026-01-19 16:36:09 -0500 | 2026-01-19 16:36:09 -0500 | MERGED |
| `feature/NWPI-14278-1-create-attestation-api-performance-fixes` | 2026-01-20 08:12:09 -0500 | 2026-01-20 08:12:09 -0500 | MERGED |
| `feature/NWPI-14340-create-attestation-api-for-all-firms-never-finish` | 2026-02-23 16:30:38 -0500 | 2026-02-23 16:30:38 -0500 | MERGED |
| `release/2.1.1` | 2026-03-06 12:52:21 -0500 | 2026-03-06 12:52:21 -0500 | MERGED |
| `feature/subscription-bulk` | 2026-03-24 10:28:32 -0400 | 2026-03-24 10:28:32 -0400 | MERGED |
| `feature/NWPI-14414-use-subscription-api-7461-for-web-socket-notifications-backend-changes-part-2` | 2026-04-07 17:53:45 -0400 | 2026-04-07 17:53:45 -0400 | MERGED |
| `feature/bulk-status-cleanup` | 2026-05-21 09:57:20 -0400 | 2026-05-21 09:57:20 -0400 | MERGED |
| `release/2.2.0` | 2026-05-22 09:46:20 -0400 | 2026-05-22 09:46:20 -0400 | MERGED |
| `release/2.2.0.0` | 2026-05-29 20:58:28 -0400 | 2026-05-29 20:58:28 -0400 | MERGED |

---

## Deletion Results

Total Attempted: 21
Successfully Deleted: 19
Failed: 2
Skipped (Excluded Safety Gate): 0

### Failed Deletions

| Branch Name | Error |
|-------------|-------|
| `feature/bulk-status-cleanup` | You cannot delete this branch since it has at least one open pull request associated with it |
| `release/2.2.0` | You cannot delete this branch since it has at least one open pull request associated with it |
