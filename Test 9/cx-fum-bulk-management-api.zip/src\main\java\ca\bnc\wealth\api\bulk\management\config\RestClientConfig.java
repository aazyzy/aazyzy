package ca.bnc.wealth.api.bulk.management.config;


import lombok.extern.slf4j.Slf4j;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.util.Timeout;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

@Slf4j
@Configuration
public class RestClientConfig {

  @Value("${restclient.bulkManagementApi.connectTimeoutSeconds:10}")
  private int connectTimeoutSeconds;

  @Value("${restclient.bulkManagementApi.connectionRequestTimeoutSeconds:10}")
  private int connectionRequestTimeoutSeconds;

  // Bulk plugin endpoints process a whole batch synchronously (e.g. PUT /user-conf/upload/update
  // performs several Okta/R2 round-trips per user), so seconds are not enough. Keep this well below
  // the Kafka max.poll.interval.ms (default 300s): the call blocks the consumer poll thread.
  @Value("${restclient.bulkManagementApi.responseTimeoutSeconds:60}")
  private int responseTimeoutSeconds;

  @Bean
  public RestClient getRestClient() {
    log.info("REST_CLIENT_CONFIG: connectTimeout={}s, connectionRequestTimeout={}s, responseTimeout={}s",
        connectTimeoutSeconds, connectionRequestTimeoutSeconds, responseTimeoutSeconds);
    RequestConfig requestConfig = RequestConfig.custom()
        .setConnectTimeout(Timeout.ofSeconds(connectTimeoutSeconds))
        .setConnectionRequestTimeout(Timeout.ofSeconds(connectionRequestTimeoutSeconds))
        .setResponseTimeout(Timeout.ofSeconds(responseTimeoutSeconds))
        .build();

    CloseableHttpClient httpClient = HttpClients.custom()
        .setDefaultRequestConfig(requestConfig)
        .build();

    HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);

    return RestClient
        .builder()
        .requestFactory(clientHttpRequestFactory)
        .build();
  }
}
