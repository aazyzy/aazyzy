package ca.bnc.wealth.api.bulk.management.controller;

import static org.springframework.http.HttpHeaders.CONTENT_DISPOSITION;
import java.util.List;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.bulk.management.service.BulkStatusService;
import ca.bnc.wealth.api.bulk.management.service.BulkTemplateService;
import ca.bnc.wealth.api.bulk.management.service.BulkValidationService;
import ca.bnc.wealth.api.bulk.management.service.TriggerBulkProcessService;
import ca.bnc.wealth.api.bulk.management.service.TriggerExportProcessService;
import ca.bnc.wealth.api.bulk.management.service.UploadService;
import ca.bnc.wealth.api.bulk.management.utils.Constants;
import ca.bnc.wealth.common.bulk_management.api.BulkManagementApi;
import ca.bnc.wealth.common.bulk_management.model.BatchStatus;
import ca.bnc.wealth.common.bulk_management.model.BatchesSearchRequest;
import ca.bnc.wealth.common.bulk_management.model.BatchesSearchResponse;
import ca.bnc.wealth.common.bulk_management.model.ExportRequest;
import ca.bnc.wealth.common.bulk_management.model.UpdateStatusRequest;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
public class BulkManagementController implements BulkManagementApi {

  private final UploadService uploadService;

  private final TriggerBulkProcessService triggerBulkProcessService;

  private final BulkStatusService bulkStatusService;

  private final BulkTemplateService bulkTemplateService;

  private final TriggerExportProcessService triggerExportProcessService;

  private final BulkValidationService bulkValidationService;

  @Override
  public ResponseEntity<Resource> getTemplateByTemplateName(String templateName) {
    Pair<String, ByteArrayResource> pair = bulkTemplateService.getTemplateByTemplateName(templateName);
    String headerValue = "attachment; filename=\"" + pair.getKey() + "\"";
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION, headerValue)
        .body(pair.getValue());
  }

  @Override
  public ResponseEntity<String> uploadFile(String templateName, MultipartFile file, String firmId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("uploadFile # Start: idpSubject: {}", user.getIdpSubject());
    try {
      BulkUpload bulkUpload = uploadService.validateAndUpload(templateName, firmId, file, user.getIdpSubject());
      return ResponseEntity.ok(bulkUpload.getBatchID());
    } catch (FumValidationException fumValidationException) {
      return ResponseEntity.badRequest().body(fumValidationException.getCode());
    } catch (Exception exception) {
      log.error("uploadFile # Error: idpSubject: {}, error: {}", user.getIdpSubject(), exception.getMessage());
      throw exception;
    }
  }

  @Override
  public ResponseEntity<Void> triggerBulkProcess(String batchId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("uploadFile # Start: idpSubject: {}", user.getIdpSubject());
    triggerBulkProcessService.triggerBulkProcess(batchId, user.getIdpSubject());
    return ResponseEntity.ok().build();
  }

  @Override
  public ResponseEntity<BatchStatus> getBatchStatusByBatchId(String batchId, Boolean getDetails) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getProcessStatusByBatchId # Start: idpSubject: {}", user.getIdpSubject());

    return ResponseEntity.ok(bulkStatusService.getBatchStatusByBatchId(batchId, getDetails));
  }

  @Override
  public ResponseEntity<byte[]> getUploadedFileByBatchId(String batchId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getUploadedFileByBatchId # Start: idpSubject: {}, batchId: {}", user.getIdpSubject(), batchId);
    Pair<String, ByteArrayResource> pair = uploadService.getUploadedFile(batchId, user.getFirmId());
    String headerValue = "attachment; filename=\"" + pair.getKey() + "\"";
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION, headerValue)
        .body(getCsvByteArray(pair));
  }

  @Override
  public ResponseEntity<byte[]> getResultsFileByBatchId(String batchId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getResultsFileByBatchId # Start: idpSubject: {}, batchId: {}", user.getIdpSubject(), batchId);
    Pair<String, ByteArrayResource> pair = uploadService.getResultsFileByBatchId(batchId, user.getFirmId());
    String headerValue = "attachment; filename=\"" + pair.getKey() + "\"";
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION, headerValue)
        .body(getCsvByteArray(pair));
  }

  @Override
  public ResponseEntity<BatchesSearchResponse> batchesSearch(
      BatchesSearchRequest batchesSearchRequest) {
    log.info("getBulkUploadRecordsByBatchTypeAndTemplateNames # Start: ");

    bulkValidationService.validateBulkUploadRecordRequest(batchesSearchRequest);

    return ResponseEntity.ok(uploadService
        .getBulkUploadsByTemplateNamesAndBatchType(batchesSearchRequest));
  }

  @Override
  public ResponseEntity<String> triggerExportProcess(String templateName, ExportRequest exportRequest) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("triggerExportProcess # Start: idpSubject: {}", user.getIdpSubject());

    BulkUpload bulkUpload = uploadService.createBulkUploadExport(templateName, user.getIdpSubject());
    triggerExportProcessService.triggerExportProcess(bulkUpload, exportRequest, user.getIdpSubject());
    return ResponseEntity.ok(bulkUpload.getBatchID());
  }

  @Override
  public ResponseEntity<Void> updateStatus(List<UpdateStatusRequest> updateStatusRequest) {
    log.info("updateStatus # Start: ");
    bulkStatusService.updateStatus(updateStatusRequest);
    return ResponseEntity.ok().build();
  }

  private byte[] getCsvByteArray(Pair<String, ByteArrayResource> pair) {
    byte[] result = new byte[Constants.CSV_BOM_HEADER_BYTE.length + pair.getValue().getByteArray().length];
    System.arraycopy(Constants.CSV_BOM_HEADER_BYTE, 0, result, 0, Constants.CSV_BOM_HEADER_BYTE.length);
    System.arraycopy(pair.getValue().getByteArray(), 0, result, Constants.CSV_BOM_HEADER_BYTE.length, pair.getValue().getByteArray().length);
    return result;
  }
}
