package ca.bnc.wealth.api.bulk.management.jpa;

import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.jpa.utils.GenericQuery;
import jakarta.persistence.criteria.JoinType;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum GenericBatchSearchCriteria implements GenericQuery {
  batchID(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "batchID", null, null),
  bulkUploadStatus(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "bulkUploadStatus", null, null);

  private EnumQueryCriteria criteria;
  private String field;
  private Object defaultValue;
  private JoinType[] joinTypes;

  @Override
  public EnumQueryCriteria getCriteria() {
    return this.criteria;
  }

  @Override
  public String getEntityField() {
    return this.field;
  }

  @Override
  public Object getDefaultValue() {
    return this.defaultValue;
  }

  @Override
  public JoinType[] getJoinTypes() {
    return this.joinTypes;
  }
}