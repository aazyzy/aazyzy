package ca.bnc.wealth.api.bulk.management.kafka;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import jakarta.annotation.PostConstruct;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ca.bnc.wealth.common.kafka.core.publisher.Publisher;
import ca.bnc.wealth.common.kafka.messaging.publisher.EventMessagePublisherFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class SingleRequestPublisher {

  protected Publisher<String, String> publisher;

  private final EventMessagePublisherFactory publisherFactory;

  @Value("${bulk.producer.action}")
  private String producerActionName;

  @Value("${app.kafka.enable:true}")
  private boolean kafkaEnable;

  @PostConstruct
  public void init() {
    if(kafkaEnable){
      this.publisher = publisherFactory.createNewPublisher(producerActionName);
    } else {
      log.warn("Kafka is disabled. SingleRequestPublisher will not be initialized.");
    }
  }

  public void publishMessage(List<String> ids) {
    try {
      log.info("Publishing list Request Ids:" + ids);
      publisher.publishSynchronous("BMA:" + StringUtils.join(ids, ","));
    } catch (ExecutionException | TimeoutException e) {
      throw new RuntimeException("Failed to publish message to Kafka", e);
    }
  }

  public void publishMessage(String id) {
    try {
      log.info("Publishing single Request Id:" + id);
      publisher.publishSynchronous("BMA:" + id);
    } catch (ExecutionException | TimeoutException e) {
      throw new RuntimeException("Failed to publish message to Kafka", e);
    }
  }
}
