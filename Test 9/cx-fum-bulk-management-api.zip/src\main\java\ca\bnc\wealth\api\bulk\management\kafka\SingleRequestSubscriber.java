package ca.bnc.wealth.api.bulk.management.kafka;

import java.util.Arrays;
import java.util.List;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ca.bnc.wealth.api.bulk.management.service.SingleRequestCallbackService;
import ca.bnc.wealth.api.bulk.management.service.SingleRequestService;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadTemplateRepository;
import ca.bnc.wealth.common.kafka.core.subscriber.Subscriber;
import ca.bnc.wealth.common.kafka.core.subscriber.SubscriberFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class SingleRequestSubscriber {

  private static final String MESSAGE_PREFIX = "BMA:";
  private static final String ID_DELIMITER = ",";

  private final SubscriberFactory subscriberFactory;
  private final SingleRequestService singleRequestService;
  private final SingleRequestCallbackService singleRequestCallbackService;
  private final BulkUploadTemplateRepository bulkUploadTemplateRepository;

  @Value("${bulk.consumer.group-id}")
  private String consumerGroupId;

  @Value("${bulk.consumer.action}")
  private String consumerName;

  @Value("${app.kafka.enable:true}")
  private boolean kafkaEnable;

  @PostConstruct
  public void init() {
    if (!kafkaEnable) {
      log.warn("Kafka is disabled. SingleRequestSubscriber will not be initialized.");
      return;
    }
    bulkUploadTemplateRepository.findAll().forEach(template -> {
      Subscriber<String, String> subscriber = subscriberFactory.createNewSubscriber(
          consumerName,
          consumerGroupId + "!!" + template.getTemplateName(),
          consumerRecord -> processMessage(consumerRecord.value(), template.getTemplateName()));
      subscriber.subscribe();
    });
  }

  private void processMessage(String singleActionIds, String templateName) {
    try {
      if (!isValidMessage(singleActionIds)) {
        log.warn("Invalid message format: {}", singleActionIds);
        return;
      }

      log.debug("Processing message for Single Request Id: {}", singleActionIds);
      List<Long> ids = parseIds(singleActionIds);

      if (ids.isEmpty()) {
        return;
      }

      if (isTemplateMatch(ids.get(0), templateName)) {
        processSingleRequests(ids);
      }
    } catch (Exception exception) {
      log.error("Failed to process message: {}", exception.getMessage(), exception);
    }
  }

  private boolean isValidMessage(String message) {
    return message != null && message.startsWith(MESSAGE_PREFIX);
  }

  private List<Long> parseIds(String message) {
    String idsString = message.split(MESSAGE_PREFIX)[1];
    return Arrays.stream(idsString.split(ID_DELIMITER))
        .map(Long::parseLong)
        .toList();
  }

  private boolean isTemplateMatch(Long firstId, String templateName) {
    return templateName.equals(
        singleRequestCallbackService.getBulkUploadTemplateBySingleActionId(firstId)
            .getTemplateName());
  }

  private void processSingleRequests(List<Long> ids) {
    if (singleRequestCallbackService.canRunSingleRequestsOrElsePublish(ids)) {
      singleRequestService.singleRequestProcessing(ids);
    }
  }
}
