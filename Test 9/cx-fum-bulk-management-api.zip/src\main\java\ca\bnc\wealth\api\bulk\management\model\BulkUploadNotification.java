package ca.bnc.wealth.api.bulk.management.model;

import java.io.Serializable;
import java.sql.Timestamp;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BulkUploadNotification implements Serializable {

  private String batchId;
  private String status;
  private String templateName;
  private String firmId;
  private int totalRecords;
  private int totalSuccess;
  private int totalFailed;
  private int totalPending;
  private Timestamp updatedDate;
}
