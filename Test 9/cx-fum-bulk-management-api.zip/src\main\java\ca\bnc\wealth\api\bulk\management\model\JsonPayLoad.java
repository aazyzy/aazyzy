package ca.bnc.wealth.api.bulk.management.model;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JsonPayLoad implements Serializable {

  private String targetUrl;
  private String httpMethod;
  private Object payload;
  private boolean requiresCallback;
  private boolean hasResponse;
}
