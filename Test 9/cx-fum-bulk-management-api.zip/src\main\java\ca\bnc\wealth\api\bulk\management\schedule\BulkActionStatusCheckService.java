package ca.bnc.wealth.api.bulk.management.schedule;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ca.bnc.wealth.api.bulk.management.service.BulkStatusService;
import ca.bnc.wealth.api.bulk.management.service.SingleRequestCallbackService;
import ca.bnc.wealth.api.bulk.management.utils.Constants;
import ca.bnc.wealth.common.jpa.entity.enums.BatchType;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import ca.bnc.wealth.common.jpa.service.IamScheduleService;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class BulkActionStatusCheckService {

  private final BulkUploadRepository bulkUploadRepository;

  private final IamScheduleService scheduleService;

  private final BulkStatusService bulkStatusService;

  private final SingleRequestCallbackService singleRequestCallbackService;

  @Value("${bulk.schedule.name}")
  private String scheduleName;

  @Value("${bulk.schedule.callback.name:BULK_MANAGEMENT_API_CALLBACK_SCHEDULE}")
  private String callbackScheduleName;

  @Value("${bulk.schedule.duration:10}")
  private long schedulerDuration;

  @Scheduled(
      fixedDelayString = "${bulk.schedule.duration:30}",
      timeUnit = TimeUnit.SECONDS)
  @Transactional
  public void updateBulkStatus() {
    if (this.scheduleService.canRunSchedule(scheduleName, schedulerDuration, TimeUnit.SECONDS)) {
      List<BulkUpload> lst = getPendingBulkRequest();

      lst.forEach(entity -> bulkStatusService.checkAndUpdateStatus(entity.getBatchID()));

      this.scheduleService.updateStatusToFinish(scheduleName);
    }
  }

  @Scheduled(
      fixedDelayString = "${bulk.schedule.callback.duration:20}",
      timeUnit = TimeUnit.MINUTES)
  @Transactional
  public void updateBulkCallbackStatus() {
    if (this.scheduleService.canRunSchedule(callbackScheduleName, schedulerDuration, TimeUnit.MINUTES)) {
      try {
        singleRequestCallbackService.updateStatusForCallbackTimeOut();
      } finally {
        this.scheduleService.updateStatusToFinish(callbackScheduleName);
      }
    }
  }

  private List<BulkUpload> getPendingBulkRequest() {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(Constants.BULK_UPLOAD_STATUS, Pair.of(EnumQueryCriteria.IN,
        List.of(BulkUploadStatus.SUBMITTED, BulkUploadStatus.PROCESSING)));
    // to ignore BulkUserMigration template
    fieldValueMap.put("bulkUploadTemplate.templateName", Pair.of(EnumQueryCriteria.IGNORE_CASE_NOT_EQUALS, "BulkUserMigration"));
    fieldValueMap.put("bulkUploadTemplate.batchType", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER,
        BatchType.UPLOAD.name()));
    return bulkUploadRepository.findAll(new Specification<>(fieldValueMap));
  }
}
