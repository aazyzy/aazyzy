package ca.bnc.wealth.api.bulk.management.service;

import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class BulkManagementServiceJpa {

  @Autowired
  private PackageTemplateRepository packageTemplateRepository;

  @Autowired
  private PackageTemplateAssignmentResourceRepository packageTemplateAssignmentResourceRepository;

  @Autowired
  private ResourceRepository resourceRepository;

  @Value("${redis.cache.enable:false}")
  private boolean enableCache;

  @Cacheable(value = "BulkManagement-API-GetPackageTemplates-By-PackageType", key = "#packageType.name()", cacheManager = "redisCacheManager", condition = "#root.getTarget().redisCacheEnabled()")
  public List<PackageTemplate> getPackageTemplatesByPackageType(PackageType packageType) {
    return packageTemplateRepository.findByType(packageType);
  }

  @Cacheable(value = "BulkManagement-API-GetResources-By-Restriction", key = "#restriction", cacheManager = "redisCacheManager", condition = "#root.getTarget().redisCacheEnabled()")
  public List<Resource> getResourcesByRestriction(boolean restriction) {
    return resourceRepository.findByRestriction(restriction);
  }

  @Cacheable(value = "BulkManagement-API-GetAssignmentResources-By-AssignmentType-AssignmentMode-SelectionDefault", key = "#packageAssignmentType.name().concat('-').concat(#packageAssignmentMode.name()).concat('-').concat(#selectionDefault)", cacheManager = "redisCacheManager", condition = "#root.getTarget().redisCacheEnabled()")
  public List<PackageTemplateAssignmentResource> getAssignmentResourcesByAssignmentTypeAndAssignmentModeAndSelectionDefault(PackageAssignmentType packageAssignmentType, PackageAssignmentMode packageAssignmentMode, boolean selectionDefault) {
    return packageTemplateAssignmentResourceRepository.findByAssignmentTypeAndAssignmentModeAndSelectionDefault(
        packageAssignmentType, packageAssignmentMode, selectionDefault);
  }

  public boolean redisCacheEnabled() {
    return enableCache;
  }
}
