package ca.bnc.wealth.api.bulk.management.service;

import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tools.jackson.databind.ObjectMapper;
import ca.bnc.wealth.api.bulk.management.utils.Constants;
import ca.bnc.wealth.common.bulk_management.model.BatchStatus;
import ca.bnc.wealth.common.bulk_management.model.Response;
import ca.bnc.wealth.common.bulk_management.model.UpdateStatusRequest;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.Audit;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadDetails;
import ca.bnc.wealth.common.jpa.repo.iam.AuditRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadDetailsRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@Service
public class BulkStatusService {

  private static final long BULK_UPLOAD_TIMEOUT_HOURS = 24;

  @Autowired
  BulkUploadRepository bulkUploadRepository;

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  private BulkUploadDetailsRepository bulkUploadDetailsRepository;

  @Autowired
  private CsvWriteService csvWriteService;

  @Autowired
  private AuditRepository auditRepository;

  @Autowired(required = false)
  private SubscriptionEmitService subscriptionEmitService;

  public BatchStatus getBatchStatusByBatchId(String batchId, Boolean getDetails) {
    log.info("getProcessStatusByBatchId # Start: batchId: {}, getReport: {}", batchId, getDetails);
    BulkUpload bulkUpload = bulkUploadRepository.findByBatchID(batchId)
        .orElseThrow(() -> {
          log.warn("Bulk upload not found for batch id: {}", batchId);
          throw new FumNotFoundException(Constants.BULK_UPLOAD_NOT_FOUND_CODE,
              Constants.BULK_UPLOAD_NOT_FOUND_MESSAGE + batchId);
        });

    BatchStatus batchStatus = new BatchStatus();
    Optional.ofNullable(bulkUpload.getBulkUploadStatus()).ifPresent(
      status -> batchStatus.setStatus(status.name()));
    batchStatus.setTotalRecords(bulkUpload.getTotalRecords());
    batchStatus.setSuccessfullyRecords(bulkUpload.getTotalSuccess());
    batchStatus.setFailedRecords(bulkUpload.getTotalFailed());
    batchStatus.setInProgressRecords(
        bulkUpload.getTotalRecords() - bulkUpload.getTotalSuccess() - bulkUpload.getTotalFailed());
    if (getDetails != null && getDetails)
      batchStatus.detailedReport(getReport(bulkUpload.getBulkUploadDetails()));
    return batchStatus;
  }

  protected List<Response> getReport(List<BulkUploadDetails> bulkUploadDetails) {
    List<Response> responses = new ArrayList<>();
    bulkUploadDetails.forEach(bulkUploadDetail -> {
      try {
        responses.add(objectMapper.readValue(bulkUploadDetail.getResponse(), Response.class));
      } catch (Exception e) {
        Response response = new Response();
        response.setId(String.valueOf(bulkUploadDetail.getBulkUploadDetailID()));
        response.setStatus(bulkUploadDetail.getBulkUploadStatus().name());
        responses.add(response);
      }
    });
    return responses;
  }

  @Async
  @Transactional
  public void checkAndUpdateStatus(String batchId) {
    try {
      BulkUpload bulkUpload = bulkUploadRepository.findByBatchID(batchId).orElseThrow(() -> {
        log.warn("Bulk upload not found for batch id: {}", batchId);
        throw new FumNotFoundException(Constants.BULK_UPLOAD_NOT_FOUND_CODE,
            Constants.BULK_UPLOAD_NOT_FOUND_MESSAGE + batchId);
      });

      BulkUploadStatus previousStatus = bulkUpload.getBulkUploadStatus();

      // If the bulk upload has been pending for more than 24 hours, mark it as failed
      if (bulkUpload.getCreatedDate() != null
          && bulkUpload.getCreatedDate().toLocalDateTime().plusHours(BULK_UPLOAD_TIMEOUT_HOURS).isBefore(LocalDateTime.now())) {
        log.warn("Bulk upload timed out after {} hours for batchId: {}", BULK_UPLOAD_TIMEOUT_HOURS, batchId);
        bulkUpload.setBulkUploadStatus(BulkUploadStatus.FAILED);
        bulkUpload.setUpdatedDate(Timestamp.valueOf(LocalDateTime.now()));
        Audit generatedAudit = uploadAudit(bulkUpload);
        bulkUpload.setGeneratedAudit(generatedAudit);
        bulkUploadRepository.saveAndFlush(bulkUpload);
        Optional.ofNullable(subscriptionEmitService)
            .ifPresent(s -> s.emitBulkUploadEvent(bulkUpload));
        return;
      }

      String bulkUploadPath = "bulkUpload.bulkUploadID";
      Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
      fieldValueMap.put(Constants.BULK_UPLOAD_STATUS, Pair.of(EnumQueryCriteria.EQUALS, BulkUploadStatus.SUCCESS));
      fieldValueMap.put(bulkUploadPath, Pair.of(EnumQueryCriteria.EQUALS, bulkUpload.getBulkUploadID()));
      long successful = bulkUploadDetailsRepository.count(new Specification<>(fieldValueMap));

      Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap1 = new HashMap<>();
      fieldValueMap1.put(Constants.BULK_UPLOAD_STATUS, Pair.of(EnumQueryCriteria.EQUALS, BulkUploadStatus.FAILED));
      fieldValueMap1.put(bulkUploadPath, Pair.of(EnumQueryCriteria.EQUALS, bulkUpload.getBulkUploadID()));
      long failed = bulkUploadDetailsRepository.count(new Specification<>(fieldValueMap1));

      BulkUploadStatus newStatus;
      if(bulkUpload.getTotalRecords() == successful) {
        newStatus = BulkUploadStatus.SUCCESS;
      } else if(successful + failed == bulkUpload.getTotalRecords()) {
        newStatus = successful > 0 ? BulkUploadStatus.PART_SUCCESS : BulkUploadStatus.FAILED;
      } else {
        newStatus = BulkUploadStatus.PROCESSING;
      }

      int newSuccess = (int) successful;
      int newFailed = (int) failed;
      int newPending = bulkUpload.getTotalRecords() - newSuccess - newFailed;

      // Skip save and event emission if nothing changed
      boolean statusChanged = previousStatus != newStatus;
      boolean countsChanged = !Integer.valueOf(newSuccess).equals(bulkUpload.getTotalSuccess())
          || !Integer.valueOf(newFailed).equals(bulkUpload.getTotalFailed())
          || !Integer.valueOf(newPending).equals(bulkUpload.getTotalPending());

      if (!statusChanged && !countsChanged) {
        log.debug("No changes detected for batchId: {}, skipping update", batchId);
        return;
      }

      bulkUpload.setBulkUploadStatus(newStatus);
      bulkUpload.setTotalSuccess(newSuccess);
      bulkUpload.setTotalFailed(newFailed);
      bulkUpload.setTotalPending(newPending);
      bulkUpload.setUpdatedDate(Timestamp.valueOf(LocalDateTime.now()));

      boolean isTerminal = newStatus == BulkUploadStatus.SUCCESS
          || newStatus == BulkUploadStatus.PART_SUCCESS
          || newStatus == BulkUploadStatus.FAILED;
      if (isTerminal && previousStatus != newStatus) {
        Audit generatedAudit = uploadAudit(bulkUpload);
        bulkUpload.setGeneratedAudit(generatedAudit);
      }

      bulkUploadRepository.saveAndFlush(bulkUpload);
      log.info("emit1) # Emitting bulk upload event for batch id: {}", batchId);
      Optional.ofNullable(subscriptionEmitService)
          .ifPresent(s -> s.emitBulkUploadEvent(bulkUpload));
    } catch (Exception e) {
      log.error("Error in updating bulk status for batchId: " + batchId, e);
    }

  }

  private Audit uploadAudit(BulkUpload bulkUpload) {
    String fileFormat = bulkUpload.getBulkUploadTemplate().getConfig().getFileFormat();
    log.info("Generating report for batch Id:" + bulkUpload.getBatchID());
    Audit audit = new Audit();
    if (fileFormat.equalsIgnoreCase("csv")) {
      Pair<String, StringWriter> pair = csvWriteService.downloadStatusCsv(bulkUpload);
      audit.setFileName(pair.getKey());
      audit.setFileContents(pair.getValue().toString().getBytes(StandardCharsets.UTF_8));
      audit.setMetadata("metadata".getBytes());
      audit.setUpdatedBy("");
      audit.setUpdatedDate(new java.sql.Timestamp(System.currentTimeMillis()));
      return auditRepository.save(audit);
    } else if (fileFormat.equalsIgnoreCase("json")) {
      Pair<String, StringWriter> pair = csvWriteService.downloadStatusJson(bulkUpload);
      audit.setFileName(pair.getKey());
      audit.setFileContents(pair.getValue().toString().getBytes());
      audit.setMetadata("metadata".getBytes());
      audit.setUpdatedBy("");
      audit.setUpdatedDate(new java.sql.Timestamp(System.currentTimeMillis()));
      return auditRepository.save(audit);
    } else {
      log.warn("File format not supported:" + fileFormat);
      return null;
    }
  }

  public void updateStatus(List<UpdateStatusRequest> updateStatusRequest) {
    updateStatusRequest.forEach(this::updateStatus);
  }

  @SneakyThrows
  public void updateStatus(UpdateStatusRequest updateStatusRequest) {
    log.info("updateStatus # Start: batchDetailId: {}", updateStatusRequest.getBatchDetailId());
    BulkUploadDetails bulkUploadDetails = bulkUploadDetailsRepository.findById(updateStatusRequest.getBatchDetailId()).orElseThrow(() -> {
      log.warn("Bulk upload detail not found for batch detail id: {}", updateStatusRequest.getBatchDetailId());
      throw new FumNotFoundException(Constants.BULK_UPLOAD_DETAIL_NOT_FOUND_CODE,
          Constants.BULK_UPLOAD_DETAIL_NOT_FOUND_MESSAGE + updateStatusRequest.getBatchDetailId());
    });

    log.info("Status update request: {}, message: {}", updateStatusRequest.getStatus(), updateStatusRequest.getResponce());

    Response response = new Response();
    response.setId(String.valueOf(updateStatusRequest.getBatchDetailId()));
    try {
      if (updateStatusRequest.getStatus().equals(BulkUploadStatus.SUCCESS.name())) {
        response.setStatus(BulkUploadStatus.SUCCESS.name());
        response.setData(updateStatusRequest.getResponce());
        bulkUploadDetails.setResponse(objectMapper.writeValueAsString(response).getBytes(StandardCharsets.UTF_8));
        bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.valueOf(updateStatusRequest.getStatus()));
      } else if (updateStatusRequest.getStatus().equals(BulkUploadStatus.FAILED.name())) {
        response.setStatus(BulkUploadStatus.FAILED.name());
        response.setErrorMessage(updateStatusRequest.getResponce());
        bulkUploadDetails.setResponse(objectMapper.writeValueAsString(response).getBytes(StandardCharsets.UTF_8));
        bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.valueOf(updateStatusRequest.getStatus()));
      } else {
        log.warn("Invalid status update request: {}, message: {}", updateStatusRequest.getStatus(), updateStatusRequest.getResponce());
        bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.FAILED);
        response.setStatus(BulkUploadStatus.FAILED.name());
        response.setErrorMessage("Invalid status update request: " + updateStatusRequest.getStatus());
        bulkUploadDetails.setResponse(objectMapper.writeValueAsString(response).getBytes(StandardCharsets.UTF_8));
        bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.FAILED);
      }
    } catch (Exception e) {
      log.error("Error in updating status for batchDetailId: " + updateStatusRequest.getBatchDetailId(), e);
      bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.FAILED);
      response.setStatus(BulkUploadStatus.FAILED.name());
      response.setErrorMessage("Error in updating status: " + e.getMessage());
      bulkUploadDetails.setResponse(objectMapper.writeValueAsString(response).getBytes(StandardCharsets.UTF_8));
      bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.FAILED);
    }

    bulkUploadDetails.setUpdatedBy(Constants.BMA_SYSTEM);
    bulkUploadDetails.setUpdatedDate(Timestamp.valueOf(LocalDateTime.now()));
    bulkUploadDetailsRepository.save(bulkUploadDetails);
  }
}
