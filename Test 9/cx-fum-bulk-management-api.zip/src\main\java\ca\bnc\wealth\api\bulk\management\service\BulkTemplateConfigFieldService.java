package ca.bnc.wealth.api.bulk.management.service;

import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class BulkTemplateConfigFieldService {

  public static final String DELIMITER = "|";
  public static final String START_REGEX_PATTERN = "^(";
  public static final String END_REGEX_PATTERN = "|$)$";
  public static final List<String> DEFAULT_MODULES = List.of("compass_r2", "firm_client_accounts",
      "users_module");
  public static final String FIRM_LEVEL_ACCESS_RESOURCE = "firm_level_access";

  @Autowired
  private BulkManagementServiceJpa bulkManagementServiceJpa;

  public Pattern getConfigFieldPattern(String fieldValue) {
    if (StringUtils.isBlank(fieldValue)) {
      log.info("Pattern is null or empty");
      return Pattern.compile(StringUtils.EMPTY);
    }

    switch (fieldValue) {
      case "fn:language" -> {
        return Pattern.compile(START_REGEX_PATTERN + String.join(DELIMITER, PreferredLanguageType.EN.name(),
            PreferredLanguageType.FR.name()) + END_REGEX_PATTERN);
      }
      case "fn:defaultModules" -> {
        return Pattern.compile(START_REGEX_PATTERN + String.join(DELIMITER, DEFAULT_MODULES) + END_REGEX_PATTERN);
      }
      case "fn:roles" -> {
        List<PackageTemplate> packageTemplates = bulkManagementServiceJpa.getPackageTemplatesByPackageType(PackageType.U);
        List<String> packageNames = packageTemplates.stream()
            .map(PackageTemplate::getName)
            .toList();
        return Pattern.compile(START_REGEX_PATTERN + String.join(DELIMITER, packageNames) + END_REGEX_PATTERN);
      }
      case "fn:boolean" -> {
        return Pattern.compile(START_REGEX_PATTERN + "true|false" + END_REGEX_PATTERN, Pattern.CASE_INSENSITIVE);
      }
      case "fn:moduleOverrides" -> {
        List<Resource> resources = bulkManagementServiceJpa.getResourcesByRestriction(true);
        List<String> resourceNames = resources.stream()
            .map(Resource::getName)
            .toList();
        return Pattern.compile(START_REGEX_PATTERN + String.join(DELIMITER, resourceNames) + END_REGEX_PATTERN);
      }
      case "fn:features" -> {
        List<PackageTemplateAssignmentResource> assignmentResources = bulkManagementServiceJpa.getAssignmentResourcesByAssignmentTypeAndAssignmentModeAndSelectionDefault(
            PackageAssignmentType.S, PackageAssignmentMode.O, false);
        Set<String> resourceNames = assignmentResources.stream()
            .map(PackageTemplateAssignmentResource::getResource)
            .map(Resource::getName)
            .filter(resourceName -> !FIRM_LEVEL_ACCESS_RESOURCE.equalsIgnoreCase(resourceName))
            .collect(Collectors.toSet());
        return Pattern.compile(START_REGEX_PATTERN + String.join(DELIMITER, resourceNames) + END_REGEX_PATTERN);
      }
      default -> {
        return Pattern.compile(fieldValue);
      }
    }
  }
}

