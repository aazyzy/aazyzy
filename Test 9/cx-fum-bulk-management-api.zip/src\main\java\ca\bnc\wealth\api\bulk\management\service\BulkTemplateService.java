package ca.bnc.wealth.api.bulk.management.service;

import ca.bnc.wealth.api.bulk.management.model.JsonPayLoad;
import ca.bnc.wealth.api.bulk.management.utils.Constants;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.enums.BatchType;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadTemplateRepository;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.SerializationFeature;
import java.util.List;
import java.util.Optional;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class BulkTemplateService {

  @Autowired
  private BulkUploadTemplateRepository bulkUploadTemplateRepository;

  @Autowired
  private ObjectMapper objectMapper;

  private static final String SAMPLE_URL = "https://nbin.wealth-tu.apis.bnc.ca/firm-management/firms";

  public Optional<BulkUploadTemplate> getTemplate(String templateName, BatchType batchType) {
    return bulkUploadTemplateRepository.findByTemplateNameAndBatchType(templateName, batchType);
  }

  public Template getTemplateConfig(String templateName) {
    return bulkUploadTemplateRepository.findByTemplateNameAndBatchType(templateName, BatchType.UPLOAD).orElseThrow(() -> new FumNotFoundException("template.notfound","Template not found")).getConfig();
  }

  @SneakyThrows
  public Pair<String,ByteArrayResource> getTemplateByTemplateName(String templateName) {
    log.info("getTemplateByTemplateName # Start: templateName: {}", templateName);
    BulkUploadTemplate bulkUploadTemplate = bulkUploadTemplateRepository.findByTemplateNameAndBatchType(templateName, BatchType.UPLOAD)
        .orElseThrow(() -> {
          log.warn("Template not found for template name: {}", templateName);
          return new FumNotFoundException(Constants.BULK_UPLOAD_TEMPLATE_NOT_FOUND_CODE,
              Constants.BULK_UPLOAD_TEMPLATE_NOT_FOUND_MESSAGE + templateName);
        });

    Template template = bulkUploadTemplate.getConfig();

    if (template.getFileFormat().equalsIgnoreCase("csv")) {
      String delimiter = template.getDelimiter() != null ? template.getDelimiter(): ",";
      String headers = String.join(delimiter, template.getHeaderNames());
      return Pair.of(templateName + "." + template.getFileFormat(), new ByteArrayResource(headers.getBytes()));
    }

    if (template.getFileFormat().equalsIgnoreCase("json")) {
      JsonPayLoad jsonPayLoad = new JsonPayLoad();
      jsonPayLoad.setTargetUrl(SAMPLE_URL);
      jsonPayLoad.setHttpMethod(HttpMethod.POST.name());
      jsonPayLoad.setPayload(new Object());
      jsonPayLoad.setHasResponse(false);
      String response = objectMapper.writerWithDefaultPrettyPrinter()
          .without(SerializationFeature.FAIL_ON_EMPTY_BEANS)
          .writeValueAsString(List.of(jsonPayLoad));
      return Pair.of(templateName + "." + template.getFileFormat(), new ByteArrayResource(response.getBytes()));
    }

    throw new FumValidationException(Constants.BULK_UPLOAD_TEMPLATE_NOT_SUPPORTED_CODE,
        Constants.BULK_UPLOAD_TEMPLATE_NOT_SUPPORTED_MESSAGE + template.getFileFormat());
  }
}
