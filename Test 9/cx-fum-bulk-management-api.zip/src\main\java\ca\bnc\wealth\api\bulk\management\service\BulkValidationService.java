package ca.bnc.wealth.api.bulk.management.service;

import static ca.bnc.wealth.api.bulk.management.utils.Constants.BULK_UPLOAD_HTTP_METHOD_MISSING;
import static ca.bnc.wealth.api.bulk.management.utils.Constants.BULK_UPLOAD_INVALID_HTTP_METHOD;
import static ca.bnc.wealth.api.bulk.management.utils.Constants.BULK_UPLOAD_INVALID_JSON;
import static ca.bnc.wealth.api.bulk.management.utils.Constants.BULK_UPLOAD_JSON_PAYLOAD_MISSING;
import static ca.bnc.wealth.api.bulk.management.utils.Constants.BULK_UPLOAD_URL_MISSING;

import ca.bnc.wealth.api.bulk.management.model.JsonPayLoad;
import ca.bnc.wealth.api.bulk.management.utils.Constants;
import ca.bnc.wealth.api.bulk.management.utils.MapperUtils;
import ca.bnc.wealth.common.bulk_management.model.BatchesSearchRequest;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import ca.bnc.wealth.common.jpa.entity.jsonb.TemplateField;
import ca.bnc.wealth.common.jpa.entity.jsonb.TemplateFieldConfig;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
@Slf4j
public class BulkValidationService {

  private static final Set<String> HTTP_METHODS = Collections.unmodifiableSet(Stream.of(HttpMethod.values())
      .map(HttpMethod::name)
      .collect(Collectors.toSet()));

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  private BulkTemplateConfigFieldService bulkTemplateConfigFieldService;

  public Optional<String> validateFile(MultipartFile multipartFile, Template template) {
    if (template == null) {
      return Optional.of("Error loading rules");
    }

    long maxFileSize = template.getFileSize();
    if (multipartFile.getSize() > maxFileSize) {
      return Optional.of(String.format("File exceeds limit of %s.",
          FileUtils.byteCountToDisplaySize(maxFileSize)));
    }

    String allowedFileFormat = template.getFileFormat();
    String extension = FilenameUtils.getExtension(multipartFile.getOriginalFilename());
    if (!allowedFileFormat.equalsIgnoreCase(extension)) {
      return Optional.of(String.format("Incorrect File format (%s files only).", allowedFileFormat));
    }
    if (allowedFileFormat.equalsIgnoreCase("csv")) {
      return !validDelimiter(template, multipartFile)? Optional.of("Required Header missing or Invalid delimiter"): Optional.empty();
    } else if (allowedFileFormat.equalsIgnoreCase("json")) {
      Pair<Boolean, String> jsonValidation = validJsonFile(multipartFile);
      return jsonValidation.getLeft() ? Optional.empty() : Optional.of(jsonValidation.getRight());
    } else {
      return Optional.of("Unsupported file format");
    }
  }

  private Pair<Boolean, String> validJsonFile(MultipartFile multipartFile) {
    try {
      BufferedReader fileReader = new BufferedReader(
          new InputStreamReader(multipartFile.getInputStream(), StandardCharsets.UTF_8));
      String result = fileReader.lines().collect(Collectors.joining("\n"));
      List<JsonPayLoad> jsonPayLoadList = objectMapper.readValue(result, new TypeReference<>(){});
      for (JsonPayLoad jsonPayLoad : jsonPayLoadList) {
        String validationError = validateJsonPayload(jsonPayLoad);
        if (validationError != null) {
          return Pair.of(false, validationError);
        }
      }
      return Pair.of(true, null);
    } catch (Exception e) {
      return Pair.of(false, BULK_UPLOAD_INVALID_JSON);
    }
  }

  @SneakyThrows
  private boolean validDelimiter(Template template, MultipartFile multipartFile) {
    BufferedReader fileReader = new BufferedReader(
        new InputStreamReader(multipartFile.getInputStream(), StandardCharsets.UTF_8));
    String line = MapperUtils.removeBom(fileReader.readLine());
    fileReader.close();
    if (line != null) {
      List<String> split = Stream.of(line.split(template.getDelimiter())).map(String::toLowerCase).toList();
      List<String> headers = template.getHeaderNames().stream().map(String::toLowerCase).toList();
      return split.containsAll(headers);
    }
    return false;
  }

  public Map<String, List<Long>> validation(List<Map<String, String>> parsedFileContents,
      Template template) {
    Map<String, List<Long>> errorMessageToRowNumbers = new HashMap<>();
    Map<String, TemplateFieldConfig> fieldConfigMap = template.getFields().stream()
        .collect(Collectors.toMap(TemplateField::getFieldName, TemplateField::getConfig));

    for (int rowIndex = 0; rowIndex < parsedFileContents.size(); rowIndex++) {
      Map<String, String> row = parsedFileContents.get(rowIndex);
      fieldConfigMap.forEach((fieldname, fieldConfig) -> {
        String fieldValue = row.get(fieldConfig.getHeaderName());
        boolean hasError = mandatoryField(fieldConfig, fieldValue, errorMessageToRowNumbers,
            Long.parseLong(row.get(Constants.ROW_NUMBER)));
        if(!hasError) {
          supportedFieldValues(fieldConfig, fieldValue, errorMessageToRowNumbers,
              Long.parseLong(row.get(Constants.ROW_NUMBER)));
        }
      });
    }
    return errorMessageToRowNumbers;
  }

  public void validateBulkUploadRecordRequest(BatchesSearchRequest batchesSearchRequest) {
    if (batchesSearchRequest.getBatchType() == null) {
      throw new IllegalArgumentException("BatchType is required");
    }
    if (batchesSearchRequest.getTemplateNames() == null) {
      throw new IllegalArgumentException("TemplateNames is required");
    }
  }

  private boolean mandatoryField(TemplateFieldConfig fieldConfig, String fieldValue,
      Map<String, List<Long>> errorMessageToRowNumbers, long rowIndex) {

    if (fieldConfig.getMandatory() && StringUtils.isBlank(fieldValue)) {
      errorMessageToRowNumbers.computeIfAbsent("Mandatory_Field " + fieldConfig.getHeaderName(),
          k -> new ArrayList<>()).add(rowIndex);
      return true;
    }
    return false;
  }

  private void supportedFieldValues(TemplateFieldConfig field, String fieldValue,
      Map<String, List<Long>> errorMessageToRowNumbers, long rowIndex) {
    if (field.getPattern() != null) {
      Pattern pattern = bulkTemplateConfigFieldService.getConfigFieldPattern(field.getPattern());
      if(field.getMultiValued()!= null && field.getMultiValued()) {
        String delimiter = field.getMultiValueDelimiter() != null ? field.getMultiValueDelimiter() : ",";
        String[] values = fieldValue.split(delimiter);
        for (String value : values) {
          if (value !=null && !pattern.matcher(value).matches()) {
            errorMessageToRowNumbers.computeIfAbsent("Not_Supported_Value " + field.getHeaderName(),
                k -> new ArrayList<>()).add(rowIndex);
            break;
          }
        }
      } else {
        if (fieldValue != null && !pattern.matcher(fieldValue).matches()) {
            errorMessageToRowNumbers.computeIfAbsent("Not_Supported_Value " + field.getHeaderName(),
                k -> new ArrayList<>()).add(rowIndex);
        }
      }
    }
  }

  String validateJsonPayload(JsonPayLoad jsonPayLoad) {
    if (jsonPayLoad == null) {
      return BULK_UPLOAD_JSON_PAYLOAD_MISSING;
    }

    if (jsonPayLoad.getTargetUrl() == null) {
      return BULK_UPLOAD_URL_MISSING;
    }

    if (jsonPayLoad.getHttpMethod() == null) {
      return BULK_UPLOAD_HTTP_METHOD_MISSING;
    }

    if (!HTTP_METHODS.contains(jsonPayLoad.getHttpMethod().toUpperCase())) {
      return BULK_UPLOAD_INVALID_HTTP_METHOD;
    }

    return null;
  }
}
