package ca.bnc.wealth.api.bulk.management.service;

import ca.bnc.wealth.api.bulk.management.utils.Constants;
import ca.bnc.wealth.common.bulk_management.model.Response;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadDetails;
import tools.jackson.databind.ObjectMapper;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class CsvWriteService {

  @Autowired
  private ObjectMapper objectMapper;

  @SneakyThrows
  public String getCsvString(List<String> headers, List<Map<String,String>> rows, String delimiter) {
    StringWriter sw = new StringWriter();
    CSVFormat csvFormat = CSVFormat.DEFAULT.builder()
        .setHeader(headers.toArray(new String[headers.size()]))
        .setDelimiter(delimiter)
        .build();

    CSVPrinter printer = new CSVPrinter(sw, csvFormat);
    for (Map<String,String> row : rows) {
      printer.printRecord(headers.stream().map(header -> row.get(header) != null ? row.get(header) : "").toList());
    }
    return sw.toString();
  }

  public Pair<String, StringWriter> downloadStatusCsv(BulkUpload bulkUpload) {
    List<BulkUploadDetails> lst = bulkUpload.getBulkUploadDetails().stream()
        .sorted(Comparator.comparingLong(BulkUploadDetails::getBulkUploadDetailID))
        .toList();
    String fileName = bulkUpload.getAudit().getFileName();
    List<String> headers = new ArrayList<>(bulkUpload.getBulkUploadTemplate().getConfig().getHeaderNames());
    headers.add(Constants.STATUS);
    headers.add(Constants.ERROR_MESSAGE);

    String delimiter = bulkUpload.getBulkUploadTemplate().getConfig().getDelimiter();
    StringWriter sw = getCsvStringWriter(headers, lst, delimiter == null? "," : delimiter, bulkUpload.getBulkUploadTemplate().getConfig().getFileFormat());
    String downloadFileName = fileName.split(".csv")[0] + "_Status.csv";
    return Pair.of(downloadFileName, sw);
  }

  public Pair<String, StringWriter> downloadStatusJson(BulkUpload bulkUpload) {
    List<BulkUploadDetails> lst = bulkUpload.getBulkUploadDetails().stream()
        .sorted(Comparator.comparingLong(BulkUploadDetails::getBulkUploadDetailID))
        .toList();
    String fileName = bulkUpload.getAudit().getFileName();
    List<String> headers = new ArrayList<>();
    headers.add(Constants.REQUEST);
    headers.add(Constants.STATUS);
    headers.add(Constants.ERROR_MESSAGE);

    String fileFormat = bulkUpload.getBulkUploadTemplate().getConfig().getFileFormat();
    StringWriter sw = getCsvStringWriter(headers, lst, ",", fileFormat);
    String downloadFileName = fileName.split("." + fileFormat)[0] + "_Status.csv";
    return Pair.of(downloadFileName, sw);
  }

  @SneakyThrows
  private StringWriter getCsvStringWriter(List<String> headers, List<BulkUploadDetails> lst, String delimiter, String fileFormat) {
    StringWriter sw = new StringWriter();
    CSVFormat csvFormat = CSVFormat.DEFAULT.builder()
        .setHeader(headers.toArray(new String[headers.size()]))
        .setDelimiter(delimiter)
        .build();

    CSVPrinter printer = new CSVPrinter(sw, csvFormat);

    for (BulkUploadDetails details : lst) {
      printer.printRecord(addRowData(headers, details, fileFormat));
    }

    return sw;
  }

  @SneakyThrows
  private List<String> addRowData(List<String> headers, BulkUploadDetails details, String fileFormat) {
    Map<String, String> rawDataMap = objectMapper.readValue(new String(details.getRequest(), StandardCharsets.UTF_8), Map.class);
    Response response = getResponse(details);
    rawDataMap.put(Constants.STATUS, response.getStatus());
    rawDataMap.put(Constants.ERROR_MESSAGE, response.getErrorMessage());

    if ("json".equalsIgnoreCase(fileFormat)) {
      rawDataMap.put(Constants.REQUEST, new String(details.getRequest(), StandardCharsets.UTF_8));
    }

    return new ArrayList<>(
        headers.stream().map(header -> rawDataMap.get(header) != null ? rawDataMap.get(header) : "")
            .toList());
  }

  private Response getResponse(BulkUploadDetails bulkUploadDetail) {
    try {
      return objectMapper.readValue(bulkUploadDetail.getResponse(), Response.class);
    } catch (Exception e) {
      Response response = new Response();
      response.setId(String.valueOf(bulkUploadDetail.getBulkUploadDetailID()));
      response.setStatus(bulkUploadDetail.getBulkUploadStatus().name());
      return response;
    }
  }

  public String getCreateUserErrorMessage(String key) {
    switch (key) {
      case Constants.ERROR_OKTA_PROFILE:
        return "User id already exists in Okta";
      case Constants.ERROR_INVALID_FIRM_ID:
        return "Invalid Firm ID";
      case Constants.ERROR_R2_PW:
        return "R2 password encryption is outdated";
      case Constants.ERROR_R2_FOUND:
        return "R2 ID is linked with another CX user";
      case Constants.ERROR_EMAIL_INVALID:
        return "Invalid email address";
      case Constants.ERROR_OKTA_CREATE:
        return "Okta user creation failed";
      case Constants.ERROR_R2_NOT_FOUND:
        return "R2 ID does not exist";
      case Constants.ERROR_RR_CODE_INVALID:
        return "Invalid RR Code";
      case Constants.ERROR_SSO_EXIST:
        return "New Compass User Id exists already";
      default:
        return "Create User Failed";
    }
  }

}
