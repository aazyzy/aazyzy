package ca.bnc.wealth.api.bulk.management.service;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.bulk.management.utils.Constants;
import ca.bnc.wealth.common.ciam.feign.client.GetOktaUserProfileClient;
import ca.bnc.wealth.common.ciam.model.OktaAccessProfile;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.ciam.security.CiamSystemToken;
import ca.bnc.wealth.common.r2.feign.client.CxUserProfileClient;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ExternalClientService {

  @Value("${feign.r2Api.businessViewId}")
  private String businessViewId;

  @Value("${feign.ciamApi.context}")
  private String ciamContext;

  @Autowired
  SystemTokenFactory systemTokenFactory;

  @Autowired
  CxUserProfileClient cxUserProfileClient;

  @Autowired
  CiamSystemToken ciamSystemToken;

  @Autowired
  GetOktaUserProfileClient userOktaProfileClient;

  public String getCompassR2(String idpSubject) {
    return Optional.ofNullable(getCxUserProfile(idpSubject))
        .map(pair -> pair.getValue())
        .orElse("");
  }

  public String getSecureZoneId(String idpUserId) {
    OktaUserProfile oktaUserProfile = getOktaUserProfile(idpUserId);

    return Optional.ofNullable(oktaUserProfile)
        .map(OktaUserProfile::getAccessProfile)
        .map(OktaAccessProfile::getBngfSecureZoneId)
        .map(array -> String.join(",", array))
        .orElse("");
  }


  public OktaUserProfile getOktaUserProfile(String idpUserId) {
    log.info("Getting okta profile of user {}", idpUserId);
    OktaUserProfile oktaUserProfile = null;
    try {
      String bearerToken = ciamSystemToken.getBearerToken();
      oktaUserProfile =
          userOktaProfileClient.getOktaUserProfile(bearerToken, ciamContext, idpUserId);
    } catch (Exception e) {
      log.warn("Error getting {} profile from Okta with error: {}", idpUserId, e.getMessage());
    }
    log.info("Okta profile {} ", oktaUserProfile);
    return oktaUserProfile;
  }

  public Pair<HttpStatusCode, String> getCxUserProfile(String cxUserId) {
    try {
      String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);
      ResponseEntity<String> response =
          cxUserProfileClient.getR2UserProfile(token, businessViewId, cxUserId);
      return Pair.of(response.getStatusCode(), response.getBody());
    } catch (Exception exception) {
      log.error("CRITICAL: Failed to get R2 ID: {}", exception.getMessage());
    }
    return null;
  }


}
