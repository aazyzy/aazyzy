package ca.bnc.wealth.api.bulk.management.service;

import ca.bnc.wealth.api.bulk.management.kafka.SingleRequestPublisher;
import ca.bnc.wealth.api.bulk.management.model.JsonPayLoad;
import ca.bnc.wealth.api.bulk.management.utils.Constants;
import ca.bnc.wealth.common.bulk_management.model.Response;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadDetails;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadDetailsRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import tools.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
public class SingleRequestCallbackService {


  @Autowired
  private BulkUploadDetailsRepository bulkUploadDetailsRepository;

  @Autowired
  private SingleRequestPublisher singleRequestPublisher;

  @Autowired
  private ObjectMapper objectMapper;

  @Value("${bulk.waitTime.beforeRepublish:500}")
  private int waitTime;

  private static final int DEFAULT_MAX_WAIT_TIME_MIN = 300;

  @Transactional
  public boolean canRunSingleRequestsOrElsePublish(List<Long> singleActionIds) {
    boolean canRun = canRunSingleRequests(singleActionIds);
    log.info("Single Request IDs: {} canRun: {}", singleActionIds, canRun);
    if (canRun) {
      return true;
    }
    waitBeforePublish();
    log.info("Re-publishing Single Request IDs: {}", singleActionIds);
    singleRequestPublisher.publishMessage(singleActionIds.stream()
        .map(String::valueOf)
        .toList());
    return false;
  }


  public boolean canRunSingleRequests(List<Long> singleActionIds) {
    try {
      if (!callBackRequired(singleActionIds))
        return true;

      List<BulkUploadDetails> processingList = getPreviousCallRequiredRunning(singleActionIds.get(0)).stream()
          .filter(bud -> !singleActionIds.contains(bud.getBulkUploadDetailID()))
          .toList();

      processingList = updateStatus(processingList);
      if (processingList.isEmpty())
        return true;

      BulkUploadTemplate template = processingList.get(0).getBulkUpload().getBulkUploadTemplate();
      Map<String, String> templatePreferences = template.getTemplatePreferences();
      int runningInstance = templatePreferences != null && templatePreferences.containsKey(Constants.RUNNING_INSTANCES_FOR_CALLBACK) ?
          getInt(templatePreferences.get(Constants.RUNNING_INSTANCES_FOR_CALLBACK)) : 1;

      if(processingList.size() >= runningInstance) {
        log.info("There are {} single requests with callback still processing for template: {}. Max allowed is {}",
            processingList.size(), template.getTemplateName(), runningInstance);
        log.info("Processing Single Request IDs: {}", processingList.stream()
            .map(bud -> String.valueOf(bud.getBulkUploadDetailID()))
            .reduce((a, b) -> a + ", " + b).orElse(""));
        return false;
      }
    } catch (Exception e) {
      log.error("Error validating single request callback requirement: {}", e.getMessage());
    }
    return true;
  }

  @Transactional
  public void updateStatusForCallbackTimeOut() {
    log.info("Starting updateStatusForCallbackTimeOut process");
    List<BulkUploadDetails> processingList = getBulkUploadDetails(null, BulkUploadStatus.PROCESSING).stream()
        .filter(bud -> callBackRequired(bud.getBulkUpload().getBulkUploadTemplate(), bud.getRequest()))
        .toList();
    log.info("Found {} processing single requests with callback requirement", processingList.size());
    updateStatus(processingList);
    log.info("Completed updateStatusForCallbackTimeOut process");
  }


  @SneakyThrows
  private List<BulkUploadDetails> updateStatus(List<BulkUploadDetails> processingList) {
    List<BulkUploadDetails> finalList = new ArrayList<>();
    if(processingList.isEmpty())
      return finalList;

    BulkUploadTemplate template = processingList.get(0).getBulkUpload().getBulkUploadTemplate();
    Map<String, String> templatePreferences = template.getTemplatePreferences();
    int maxWaitTimeMin = templatePreferences != null && templatePreferences.containsKey(Constants.MAX_WAIT_TIME_MIN_FOR_CALLBACK_MIN) ?
        getInt(templatePreferences.get(Constants.MAX_WAIT_TIME_MIN_FOR_CALLBACK_MIN)) : DEFAULT_MAX_WAIT_TIME_MIN;

    for(BulkUploadDetails bud: processingList) {
      LocalDateTime start =
          bud.getUpdatedDate() != null ? bud.getUpdatedDate().toLocalDateTime() : bud.getCreatedDate().toLocalDateTime();

      long minutes = Duration.between(start, LocalDateTime.now()).toMinutes();
      if (minutes > maxWaitTimeMin) {
        log.warn("Marked as FAILED due to exceeding max wait time for callback for BulkUploadDetailID: {}", bud.getBulkUploadDetailID());
        bud.setBulkUploadStatus(BulkUploadStatus.FAILED);
        Response response = errorResponse(String.valueOf(bud.getBulkUploadDetailID()), "Marked as FAILED due to exceeding max wait time for callback");
        bud.setResponse(objectMapper.writeValueAsString(response).getBytes(StandardCharsets.UTF_8));

        bulkUploadDetailsRepository.save(bud);
      } else {
        finalList.add(bud);
      }
    }
    return finalList;
  }

  private boolean callBackRequired(List<Long> singleActionIds) {

    List<BulkUploadDetails> entities = bulkUploadDetailsRepository.findAllById(singleActionIds);
    BulkUploadTemplate template = entities.get(0).getBulkUpload().getBulkUploadTemplate();

    for (BulkUploadDetails entity : entities) {
      if (callBackRequired(template, entity.getRequest()))
        return true;
    }
    return false;
  }

  public BulkUploadDetails getBulkUploadDetailsById(Long singleActionId) {
    return bulkUploadDetailsRepository.findById(singleActionId)
        .orElseThrow(() -> new IllegalArgumentException(
            Constants.BULK_UPLOAD_DETAIL_NOT_FOUND_MESSAGE + singleActionId));
  }

  public BulkUploadTemplate getBulkUploadTemplateBySingleActionId(Long singleActionId) {
    return getBulkUploadDetailsById(singleActionId).getBulkUpload().getBulkUploadTemplate();
  }

  @SneakyThrows
  public List<BulkUploadDetails> getPreviousCallRequiredRunning(Long singleActionId) {
    BulkUploadTemplate template = getBulkUploadDetailsById(singleActionId).getBulkUpload().getBulkUploadTemplate();

    return getBulkUploadDetails(
      getBulkUploadTemplateBySingleActionId(singleActionId).getTemplateName(), 
        BulkUploadStatus.PROCESSING).stream()
          .filter(bud -> callBackRequired(template, bud.getRequest()))
          .toList();
  }

  private List<BulkUploadDetails> getBulkUploadDetails(String templateName, BulkUploadStatus bulkUploadStatus) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(Constants.BULK_UPLOAD_STATUS, Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, bulkUploadStatus.name()));

    if(StringUtils.isNotBlank(templateName))
      fieldValueMap.put("bulkUpload.bulkUploadTemplate.templateName", Pair.of(EnumQueryCriteria.EQUALS, templateName));

    return bulkUploadDetailsRepository.findAll(new Specification<>(fieldValueMap));
  }

  private boolean callBackRequired(BulkUploadTemplate template, byte[] request ) {
    try {
      if (template.getConfig().getFileFormat().equalsIgnoreCase("json")) {
        JsonPayLoad jsonPayLoad = objectMapper.readValue(new String(request, StandardCharsets.UTF_8), JsonPayLoad.class);
        if (jsonPayLoad.isRequiresCallback())
          return true;
      } else {
        Map<String, String> map = objectMapper.readValue(new String(request, StandardCharsets.UTF_8), Map.class);
        if (Boolean.parseBoolean(map.getOrDefault(Constants.REQUEST_CALLBACK, "false")))
          return true;
      }
    } catch (Exception e) {
      log.error("Error parsing request for callback requirement: {}", e.getMessage());
    }
    return false;
  }

  int getInt(String intValue) {
    try {
      return Integer.parseInt(intValue);
    } catch (Exception e) {
      log.warn("Unable to parse int value from string: {}", intValue);
      return 0;
    }
  }

  Response errorResponse(String id, String errorMessage) {
    Response response = new Response();
    response.setId(id);
    response.setErrorMessage(errorMessage);
    response.setStatus(BulkUploadStatus.FAILED.name());
    return response;
  }

  void waitBeforePublish() {
    try {
      Thread.sleep(waitTime);
    } catch (InterruptedException e) {
      log.error("Error during wait: {}", e.getMessage());
    }
  }
}
