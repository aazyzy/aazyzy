package ca.bnc.wealth.api.bulk.management.service;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.bulk.management.model.JsonPayLoad;
import ca.bnc.wealth.api.bulk.management.utils.Constants;
import ca.bnc.wealth.common.bulk_management.model.Response;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadDetails;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadDetailsRepository;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;
import com.nimbusds.jose.util.Pair;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClient.RequestHeadersSpec.ConvertibleClientHttpResponse;

@Slf4j
@Service
public class SingleRequestService {

  @Autowired
  private BulkUploadDetailsRepository bulkUploadDetailsRepository;

  @Autowired
  private SystemTokenFactory systemTokenFactory;

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  private RestClient restClient;

  @Value("${feign.host.url: http://localhost}")
  private String hostnameUrl;

  @SneakyThrows
  public void singleRequestProcessing(List<Long> singleActionIds) {
    List<BulkUploadDetails> entities = bulkUploadDetailsRepository.findAllById(singleActionIds);
    try {
      boolean anyUnsubmittedDetails = entities.stream()
          .anyMatch(entity -> entity.getBulkUploadStatus() != BulkUploadStatus.SUBMITTED);
      if (anyUnsubmittedDetails || entities.isEmpty()) {
        return;
      }

      Map<Long, BulkUploadDetails> bulkUploadDetailsMap = new HashMap<>();

      for (BulkUploadDetails entity : entities) {
        BulkUploadDetails bulkUploadDetails = updateStatus(entity, BulkUploadStatus.PROCESSING);
        bulkUploadDetailsMap.put(bulkUploadDetails.getBulkUploadDetailID(), bulkUploadDetails);
      }
      BulkUploadTemplate template = entities.get(0).getBulkUpload().getBulkUploadTemplate();
      if (template.getConfig().getFileFormat().equalsIgnoreCase("json")) {
        processJsonContent(template, bulkUploadDetailsMap);
      } else {
        processCsvContent(template, bulkUploadDetailsMap);
      }
    } catch (Exception e) {
      log.warn("Error while processing request: {}", e.getMessage());
      entities.forEach(entity -> {
        updateBulkUploadDetails(entity, errorResponse(String.valueOf(entity.getBulkUploadDetailID()), e.getMessage()));
      });
    }
  }

  private void processJsonContent(BulkUploadTemplate template,
      Map<Long, BulkUploadDetails> bulkUploadDetailsMap) {
    for (BulkUploadDetails entity : bulkUploadDetailsMap.values()) {
      try {
        apiCallForJson(template, entity);
      } catch (Exception e) {
        log.warn("Error while processing JSON request for ID: " + entity.getBulkUploadDetailID() + " error:", e);
        updateBulkUploadDetails(entity, errorResponse(String.valueOf(entity.getBulkUploadDetailID()), e.getMessage()));
      }
    }
  }

  @SneakyThrows
  private void apiCallForJson(BulkUploadTemplate template, BulkUploadDetails entity) {
    JsonPayLoad jsonPayLoad = objectMapper.readValue(new String(entity.getRequest(), StandardCharsets.UTF_8), JsonPayLoad.class);
    RequestMethod method = RequestMethod.valueOf(jsonPayLoad.getHttpMethod().toUpperCase());
    boolean absoluteUrl = jsonPayLoad.getTargetUrl().strip().toLowerCase().startsWith("http");
    String url = absoluteUrl ? jsonPayLoad.getTargetUrl() : hostnameUrl + jsonPayLoad.getTargetUrl();
    if (absoluteUrl) {
      validateOutboundUrl(url, entity.getBulkUploadDetailID());
    }
    log.info("Calling API with method: {} for detailId: {}", method, entity.getBulkUploadDetailID());
    String requestBody = jsonPayLoad.getPayload() != null ? objectMapper.writeValueAsString(jsonPayLoad.getPayload()) : null;

    url = updateUrlWithCallback(entity, jsonPayLoad, url);
    Pair<Boolean,String> pair = callAPI(method, url, requestBody);

    log.info("API response: {}", pair);

    if(pair != null && pair.getLeft()) {
      if(jsonPayLoad.isRequiresCallback() && "BulkManagementApiCallBack-Started".equalsIgnoreCase(pair.getRight())) {
        log.info("API requires callback, skipping updating bulk upload details for ID: {}", entity.getBulkUploadDetailID());
        return;
      }
      updateBulkUploadDetails(entity, successResponse(String.valueOf(entity.getBulkUploadDetailID()), pair.getRight()));
    } else {
      updateBulkUploadDetails(entity, errorResponse(String.valueOf(entity.getBulkUploadDetailID()), pair != null ? pair.getRight() : "Unknown error"));
    }
  }

  private Pair<Boolean,String> processResponse(ConvertibleClientHttpResponse response) {
    try {
      return Pair.of(response.getStatusCode().is2xxSuccessful(), new String(response.getBody().readAllBytes(), StandardCharsets.UTF_8));
    } catch (Exception exception) {
      return Pair.of(false, exception.getMessage());
    }
  }


  @SneakyThrows
  private void processCsvContent(BulkUploadTemplate template , Map<Long, BulkUploadDetails> bulkUploadDetailsMap) {
    Map<Long,Map<String, String>> requestMap = new HashMap<>();
    for(BulkUploadDetails entity : bulkUploadDetailsMap.values()) {
      Map<String, String> request = objectMapper.readValue(
          new String(entity.getRequest(), StandardCharsets.UTF_8), Map.class);
      request.put(Constants.REQUEST_ID, String.valueOf(entity.getBulkUploadDetailID()));
      requestMap.put(entity.getBulkUploadDetailID(),request);
    }

    RequestMethod method = RequestMethod.valueOf(template.getPluginUrl().split(":")[0].toUpperCase(Locale.ROOT));
    String url = template.getPluginUrl().split(method.name() + ":")[1];
    List<String> variables = getVariableInUrl(url);
    if(!variables.isEmpty()) {
      for (Map<String, String> map : requestMap.values()) {
        for (String variable : variables) {
          url = url.replace("{" + variable + "}", map.get(variable));
        }
        callAPIAndProcessResponse(bulkUploadDetailsMap, method, url, List.of(map), template);
      }
    } else {
      callAPIAndProcessResponse(bulkUploadDetailsMap, method, url, new ArrayList<>(requestMap.values()), template);
    }
  }

  void callAPIAndProcessResponse(Map<Long, BulkUploadDetails> bulkUploadDetailsMap, RequestMethod method, String url,List<Map<String, String>> requestList,BulkUploadTemplate template) {
    try {
      log.info("Calling API: {} with method: {} for detailIds: {}", url, method, bulkUploadDetailsMap.keySet());
      log.debug("Request payload: {}", requestList);
      url = updateUrlWithCallback(new ArrayList<>(bulkUploadDetailsMap.values()), requestList, url);
      Pair<Boolean, String> response = callAPI(method, url, objectMapper.writeValueAsString(requestList));

      if (response == null) {
        throw new FumServiceException("error.apiResponse.empty", "API response is null");
      }
      log.info("API response for URL {} : success={}", url, response.getLeft());

      if("BulkManagementApiCallBack-Started".equalsIgnoreCase(response.getRight())) {
        log.info("API requires callback, skipping updating bulk upload details for IDs: {}", bulkUploadDetailsMap.keySet());
        return;
      }

      List<Response> lst = objectMapper.readValue(response.getRight(), new TypeReference<List<Response>>(){});
      Map<Long, Response> idResponseMap = lst.stream().collect(Collectors.toMap(v -> Long.valueOf(v.getId()),v->v));
      if(response.getLeft()) {
        for (Entry<Long, BulkUploadDetails> entry : bulkUploadDetailsMap.entrySet()) {
          if(idResponseMap.containsKey(entry.getKey())) {
            Map<String, String> map = objectMapper.readValue(new String(bulkUploadDetailsMap.get(entry.getKey()).getRequest(), StandardCharsets.UTF_8), Map.class);
            updateBulkUploadDetails(bulkUploadDetailsMap.get(entry.getKey()), idResponseMap.get(entry.getKey()));
          } else {
            updateBulkUploadDetails(entry.getValue(), errorResponse(String.valueOf(entry.getKey()), "API response does not contain all IDs"));
          }
        }
      } else {
        requestList.stream()
            .map(req -> req.get(Constants.REQUEST_ID))
            .forEach(id -> updateBulkUploadDetails(bulkUploadDetailsMap.get(Long.valueOf(id)), errorResponse(id, response.getRight().toString())));
      }
    } catch (Exception e) {
      log.warn("Error calling API {} for detailIds {}: {}", url, bulkUploadDetailsMap.keySet(), e.getMessage(), e);
      requestList.stream()
          .map(map -> map.get(Constants.REQUEST_ID))
          .forEach(id -> updateBulkUploadDetails(bulkUploadDetailsMap.get(Long.valueOf(id)),
              errorResponse(id, e.getMessage())));
    }
  }

  @SneakyThrows
  Pair<Boolean,String> callAPI(RequestMethod method,String url, String request) {
    String token = systemTokenFactory.getSystemToken(Constants.SYSTEM_TOKEN_FUM);
    switch (method) {
      case POST:
        if(request != null) {
          return restClient.post()
              .uri(new URI(url))
              .accept(MediaType.APPLICATION_JSON)
              .contentType(MediaType.APPLICATION_JSON)
              .headers(headers -> headers.setBearerAuth(token))
              .body(request)
              .exchange((httpRequest, httpResponse) -> processResponse(httpResponse));
        } else {
          return restClient.post()
              .uri(new URI(url))
              .accept(MediaType.APPLICATION_JSON)
              .contentType(MediaType.APPLICATION_JSON)
              .headers(headers -> headers.setBearerAuth(token))
              .exchange((httpRequest, httpResponse) -> processResponse(httpResponse));
        }
      case PUT:
        if(request != null) {
          return restClient.put()
              .uri(new URI(url))
              .accept(MediaType.APPLICATION_JSON)
              .contentType(MediaType.APPLICATION_JSON)
              .headers(headers -> headers.setBearerAuth(token))
              .body(request)
              .exchange((httpRequest, httpResponse) -> processResponse(httpResponse));
        } else {
          return restClient.put()
              .uri(new URI(url))
              .accept(MediaType.APPLICATION_JSON)
              .contentType(MediaType.APPLICATION_JSON)
              .headers(headers -> headers.setBearerAuth(token))
              .exchange((httpRequest, httpResponse) -> processResponse(httpResponse));
        }
      case GET:
        return restClient.get()
            .uri(new URI(url))
            .accept(MediaType.APPLICATION_JSON)
            .headers(headers -> headers.setBearerAuth(token))
            .exchange((httpRequest, httpResponse) -> processResponse(httpResponse));
      case DELETE:
        return restClient.delete()
            .uri(new URI(url))
            .accept(MediaType.APPLICATION_JSON)
            .headers(headers -> headers.setBearerAuth(token))
            .exchange((httpRequest, httpResponse) -> processResponse(httpResponse));
      default:
        return Pair.of(false, Constants.INVALID_REQUEST_METHOD_MESSAGE);
    }
  }

  private Pair<HttpStatusCode, Object> processResponse(ResponseEntity<List<Response>> response) {
    if (response.getStatusCode().is2xxSuccessful()) {
      return Pair.of(response.getStatusCode(), response.getBody());
    } else {
      return Pair.of(response.getStatusCode(), apiErrorMessage(response.getStatusCode()));
    }
  }

  private Pair<HttpStatusCode, Object> processResponseVoid(ResponseEntity<Void> response) {
    if (response.getStatusCode().is2xxSuccessful()) {
      return Pair.of(response.getStatusCode(), null);
    } else {
      return Pair.of(response.getStatusCode(), apiErrorMessage(response.getStatusCode()));
    }
  }

  private List<String> getVariableInUrl(String url) {
    List<String> result = new ArrayList<>();
    String[] lst = url.split("/\\{");
    for (int i = 1; i < lst.length; i++) {
      String temp = lst[i].split("}/")[0];
      result.add(temp);
    }
    if (result.size() > 0) {
      result.set(result.size() - 1, result.get(result.size() - 1).split("}")[0]);
    }
    return result;
  }

  private BulkUploadDetails updateStatus(BulkUploadDetails bulkUploadDetails,
      BulkUploadStatus bulkUploadStatus) {
    bulkUploadDetails.setBulkUploadStatus(bulkUploadStatus);
    bulkUploadDetails.setUpdatedBy(Constants.BMA_SYSTEM);
    bulkUploadDetails.setUpdatedDate(Timestamp.valueOf(LocalDateTime.now()));
    return bulkUploadDetailsRepository.saveAndFlush(bulkUploadDetails);
  }

  @SneakyThrows
  private BulkUploadDetails updateBulkUploadDetails(BulkUploadDetails bulkUploadDetails, Response response) {
    bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.valueOf(response.getStatus()));
    bulkUploadDetails.setResponse(objectMapper.writeValueAsString(response).getBytes(StandardCharsets.UTF_8));
    bulkUploadDetails.setUpdatedBy(Constants.BMA_SYSTEM);
    bulkUploadDetails.setUpdatedDate(Timestamp.valueOf(LocalDateTime.now()));
    return bulkUploadDetailsRepository.saveAndFlush(bulkUploadDetails);
  }

  @SneakyThrows
  private Response successResponse(String id, Object object) {
    Response response = new Response();
    response.setId(id);
    if(object != null) {
      response.setData(objectMapper.writeValueAsString(object));
    }
    response.setStatus(BulkUploadStatus.SUCCESS.name());
    return response;
  }

  private Response deleteResponse(String id, BulkUploadStatus bulkUploadStatus) {
    Response response = new Response();
    response.setId(id);
    response.setStatus(bulkUploadStatus.name());
    return response;
  }

  private Response errorResponse(String id, String errorMessage) {
    Response response = new Response();
    response.setId(id);
    response.setErrorMessage(errorMessage);
    response.setStatus(BulkUploadStatus.FAILED.name());
    return response;
  }

  private String apiErrorMessage(HttpStatusCode status) {
    return "API call failed with status code: " + status;
  }

  private String updateUrlWithCallback(BulkUploadDetails entity, JsonPayLoad jsonPayLoad, String url) {
    if(jsonPayLoad.isRequiresCallback()) {
      url = url + "?batch-detail-ids=" + entity.getBulkUploadDetailID() + "&bulk-file-format=json";
      log.info("Updated URL with callback parameters: {}", url);
      return url;
    }
    return url;
  }

  private String updateUrlWithCallback(List<BulkUploadDetails> entitys, List<Map<String, String>> requests, String url) {
    boolean requiresCallBack = requests.stream()
        .anyMatch(req -> Boolean.parseBoolean(req.getOrDefault(Constants.REQUEST_CALLBACK, "false")));

    if(requiresCallBack) {
      String bulkUploadIds = entitys.stream()
          .map(BulkUploadDetails::getBulkUploadDetailID)
          .map(String::valueOf)
          .collect(Collectors.joining(","));
      url = url + "?batch-detail-ids=" + bulkUploadIds + "&bulk-file-format=csv";
      log.info("Updated URL with callback parameters: {}", url);
      return url;
    }
    return url;
  }

  private void validateOutboundUrl(String url, Long detailId) {
    URI uri;
    try {
      uri = new URI(url);
    } catch (URISyntaxException e) {
      log.warn("SSRF_BLOCKED: malformed targetUrl for detailId={}", detailId);
      throw new FumServiceException("error.ssrf.blocked", Constants.BULK_UPLOAD_MALFORMED_URL);
    }
    String scheme = uri.getScheme();
    if (scheme == null || (!scheme.equalsIgnoreCase("http") && !scheme.equalsIgnoreCase("https"))) {
      log.warn("SSRF_BLOCKED: unsupported scheme for detailId={}, scheme={}", detailId, scheme);
      throw new FumServiceException("error.ssrf.blocked", Constants.BULK_UPLOAD_MALFORMED_URL);
    }
    String host = uri.getHost();
    if (host == null || isBlockedHost(host)) {
      log.warn("SSRF_BLOCKED: targetUrl host not allowed for detailId={}, host={}", detailId, host);
      throw new FumServiceException("error.ssrf.blocked", Constants.BULK_UPLOAD_MALFORMED_URL);
    }
  }

  private boolean isBlockedHost(String host) {
    String normalizedHost = host.toLowerCase(Locale.ROOT);
    if (normalizedHost.equals("localhost") || normalizedHost.endsWith(".localhost")
        || normalizedHost.equals("metadata.google.internal")) {
      return true;
    }
    try {
      InetAddress address = InetAddress.getByName(host);
      return address.isLoopbackAddress() || address.isAnyLocalAddress()
          || address.isLinkLocalAddress() || address.isSiteLocalAddress();
    } catch (UnknownHostException e) {
      // Unresolvable host — block to be safe.
      return true;
    }
  }

}
