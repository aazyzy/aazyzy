package ca.bnc.wealth.api.bulk.management.service;

import ca.bnc.wealth.api.bulk.management.model.BulkUploadNotification;
import ca.bnc.wealth.common.bma.service.SubscriptionClientService;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnBean(SubscriptionClientService.class)
@RequiredArgsConstructor
@Slf4j
public class SubscriptionEmitService {

  private final SubscriptionClientService subscriptionClientService;

  @Value("${subscription.domain:6900_BMA}")
  private String domain;

  /**
   * Emits a notification event for a BulkUpload record change.
   * This is fire-and-forget: errors are logged but do not propagate.
   */
  public void emitBulkUploadEvent(BulkUpload bulkUpload) {
    try {
      BulkUploadNotification notification = BulkUploadNotification.builder()
          .batchId(bulkUpload.getBatchID())
          .status(Optional.ofNullable(bulkUpload.getBulkUploadStatus())
              .map(Enum::name).orElse(null))
          .templateName(Optional.ofNullable(bulkUpload.getBulkUploadTemplate())
              .map(t -> t.getTemplateName()).orElse(null))
          .firmId(Optional.ofNullable(bulkUpload.getFirmId())
              .filter(id -> !id.isBlank()).orElse("DUMMY_FIRM_ID"))
          .totalRecords(bulkUpload.getTotalRecords())
          .totalSuccess(bulkUpload.getTotalSuccess())
          .totalFailed(bulkUpload.getTotalFailed())
          .totalPending(bulkUpload.getTotalPending())
          .updatedDate(bulkUpload.getUpdatedDate())
          .build();

      subscriptionClientService.emit(domain, List.of(notification));
    } catch (Exception e) {
      log.error("emitBulkUploadEvent # Error: batchId: {}, message: {}",
          bulkUpload.getBatchID(), e.getMessage(), e);
    }
  }
}
