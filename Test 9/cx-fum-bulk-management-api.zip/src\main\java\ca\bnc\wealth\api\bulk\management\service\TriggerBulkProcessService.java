package ca.bnc.wealth.api.bulk.management.service;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;
import ca.bnc.wealth.api.bulk.management.kafka.SingleRequestPublisher;
import ca.bnc.wealth.api.bulk.management.model.JsonPayLoad;
import ca.bnc.wealth.api.bulk.management.utils.Constants;
import ca.bnc.wealth.common.bulk_management.model.Response;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadDetails;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadDetailsRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class TriggerBulkProcessService {

  private final BulkUploadRepository bulkUploadRepository;

  private final CsvFileReadService csvFileReadService;


  private final BulkValidationService bulkValidationService;

  private final BulkUploadDetailsRepository bulkUploadDetailsRepository;

  private final SingleRequestPublisher singleRequestPublisher;

  private final ObjectMapper objectMapper;

  private final Optional<SubscriptionEmitService> subscriptionEmitService;

  @Async
  public void triggerBulkProcess(String batchId, String requestedId) {
    log.info("triggerBulkProcess # Start processing batch: batchId: {}", batchId);
    try {
      BulkUpload bulkUpload = getBulkUploadByBatchId(batchId);
      if (bulkUpload.getBulkUploadStatus() != BulkUploadStatus.UPLOADED) {
        log.warn("triggerBulkProcess # Batch already processed: batchId: {}", batchId);
        return;
      }
      bulkUpload = updateStatus(batchId, BulkUploadStatus.PROCESSING);
      Template template = bulkUpload.getBulkUploadTemplate().getConfig();
      byte[] content = bulkUpload.getAudit().getFileContents();
      if (template.getFileFormat().equalsIgnoreCase("csv")) {
        List<Map<String, String>> records = csvFileReadService.convertCsvFileToMap(new BufferedReader(new InputStreamReader(new ByteArrayInputStream(content), StandardCharsets.UTF_8)), template, true);
        bulkUpload = updateTotalRecords(bulkUpload, records.size());

        addCurrentFirmIdAndRequestedId(records, bulkUpload.getFirmId(), requestedId);

        inputFileErrorValidation(records, template);

        updateDefaultValue(records, template);

        createSingleRequestAndPublish(bulkUpload, records, template, requestedId);

      } else if (template.getFileFormat().equalsIgnoreCase("json")) {
        BufferedReader fileReader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(content)));
        String result = fileReader.lines().collect(Collectors.joining("\n"));
        List<JsonPayLoad> jsonActions = objectMapper.readValue(result, new TypeReference<List<JsonPayLoad>>() {});
        bulkUpload = updateTotalRecords(bulkUpload, jsonActions.size());
        createSingleRequestAndPublish(bulkUpload, jsonActions, requestedId);
      }
    } catch (Exception e) {
      log.warn("triggerBulkProcess # Error: batchId: {}", batchId, e);
      updateStatus(batchId, BulkUploadStatus.FAILED);
    }
  }

  private void updateDefaultValue(List<Map<String, String>> records, Template template) {
    records.forEach(record -> {
      template.getFields().forEach(field -> {
        if (field.getConfig().getDefaultValue() != null && record.get(field.getConfig().getHeaderName()) == null) {
          record.put(field.getConfig().getHeaderName(), field.getConfig().getDefaultValue());
        }
      });
    });
  }

  public void inputFileErrorValidation(List<Map<String, String>> parsedFileContents, Template templateRules) {

    Map<String, List<Long>> validation = this.bulkValidationService.validation(
        parsedFileContents, templateRules);
    if (!validation.isEmpty()) {
      validation.forEach((key, value) -> {
        if (!value.isEmpty()) {
          value.forEach(rowNumber -> {
            String errorMessage = key + ": value is missing or incorrect header";
            parsedFileContents.get(rowNumber.intValue() - 2).computeIfAbsent(Constants.STATUS, k -> BulkUploadStatus.FAILED.name());
            parsedFileContents.get(rowNumber.intValue() - 2).computeIfPresent(Constants.ERROR_MESSAGE, (k, v) -> v + "," + errorMessage);
            parsedFileContents.get(rowNumber.intValue() - 2).computeIfAbsent(Constants.ERROR_MESSAGE, k -> errorMessage);
          });
        }
      });
    }
  }

  @SneakyThrows
  private void createSingleRequestAndPublish(
      BulkUpload bulkUpload, List<JsonPayLoad> jsonPayLoadList, String requestId) {
    for (JsonPayLoad jsonPayLoad : jsonPayLoadList) {
      BulkUploadDetails bulkUploadDetails = new BulkUploadDetails();
      bulkUploadDetails.setBulkUpload(bulkUpload);
      bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
      bulkUploadDetails.setRequest(objectMapper.writeValueAsString(jsonPayLoad).getBytes(
          StandardCharsets.UTF_8));
      bulkUploadDetails.setCreatedBy(requestId);
      bulkUploadDetails.setCreatedDate(Timestamp.valueOf(LocalDateTime.now()));
      BulkUploadDetails response = bulkUploadDetailsRepository.saveAndFlush(bulkUploadDetails);
      singleRequestPublisher.publishMessage(String.valueOf(response.getBulkUploadDetailID()));
    }
  }

  @SneakyThrows
  private void createSingleRequestAndPublish(
      BulkUpload bulkUpload, List<Map<String, String>> parsedFileContents, Template template, String requestId) {

    long batchSize = template.getBatchSize() <= 0 ? 1 : template.getBatchSize();
    List<String> batch = new ArrayList<>();
    int failedCount = 0;
    for (Map<String, String> map : parsedFileContents) {
      // Validation Failed
      if (map.containsKey(Constants.ERROR_MESSAGE)) {
        BulkUploadDetails bulkUploadDetails = new BulkUploadDetails();
        bulkUploadDetails.setBulkUpload(bulkUpload);
        bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.FAILED);
        bulkUploadDetails.setRequest(objectMapper.writeValueAsString(map).getBytes(StandardCharsets.UTF_8));
        bulkUploadDetails.setResponse(objectMapper.writeValueAsString(errorResponse(null, map.get(Constants.ERROR_MESSAGE))).getBytes(StandardCharsets.UTF_8));
        bulkUploadDetails.setCreatedBy(requestId);
        bulkUploadDetails.setCreatedDate(Timestamp.valueOf(LocalDateTime.now()));
        bulkUploadDetailsRepository.saveAndFlush(bulkUploadDetails);
        failedCount++;
        continue;
      }
      BulkUploadDetails bulkUploadDetails = new BulkUploadDetails();
      bulkUploadDetails.setBulkUpload(bulkUpload);
      bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
      bulkUploadDetails.setRequest(objectMapper.writeValueAsString(map).getBytes(
          StandardCharsets.UTF_8));
      bulkUploadDetails.setCreatedBy(requestId);
      bulkUploadDetails.setCreatedDate(Timestamp.valueOf(LocalDateTime.now()));
      BulkUploadDetails response = bulkUploadDetailsRepository.saveAndFlush(bulkUploadDetails);

      batch.add(String.valueOf(response.getBulkUploadDetailID()));
      if (batch.size() == batchSize) {
        singleRequestPublisher.publishMessage(batch);
        batch = new ArrayList<>();
      }
    }
    if (!batch.isEmpty()) {
      singleRequestPublisher.publishMessage(batch);
    }
    if (failedCount > 0) {
      bulkUpload.setTotalFailed(failedCount);
      bulkUpload.setBulkUploadStatus(BulkUploadStatus.PROCESSING);
      bulkUploadRepository.saveAndFlush(bulkUpload);
      log.info("emit2) # Emitting bulk upload event for batch id: {}", bulkUpload.getBatchID());
      subscriptionEmitService.ifPresent(s -> s.emitBulkUploadEvent(bulkUpload));
    }
  }

  public BulkUpload getBulkUploadByBatchId(String batchId) {
    return bulkUploadRepository.findByBatchID(batchId)
        .orElseThrow(() -> {
          log.warn("Bulk upload not found for form id: {}", batchId);
          throw new FumNotFoundException(Constants.BULK_UPLOAD_NOT_FOUND_CODE,
              Constants.BULK_UPLOAD_NOT_FOUND_MESSAGE + batchId);
        });
  }

  public BulkUpload getBulkUploadById(String requestId) {
    return bulkUploadRepository.findById(Long.valueOf(requestId))
        .orElseThrow(() -> {
          log.warn("Bulk upload not found for form id: {}", requestId);
          throw new FumNotFoundException(Constants.BULK_UPLOAD_NOT_FOUND_CODE,
              Constants.BULK_UPLOAD_NOT_FOUND_MESSAGE + requestId);
        });
  }

  private void addCurrentFirmIdAndRequestedId(List<Map<String, String>> records, String firmId, String requestedId) {
    records.forEach(record -> {
      record.put(Constants.CURRENT_FIRM, firmId);
      record.put(Constants.CURRENT_USER, requestedId);
    });
  }

  private BulkUpload updateStatus(String batchId, BulkUploadStatus bulkUploadStatus) {
    BulkUpload bulkUpload = bulkUploadRepository.findByBatchID(batchId).orElseThrow(() -> new FumNotFoundException("batch.notfound", "Batch not found"));
    bulkUpload.setBulkUploadStatus(bulkUploadStatus);
    BulkUpload saved = bulkUploadRepository.saveAndFlush(bulkUpload);
    log.info("emit3) # Emitting bulk upload event for batch id: {}", batchId);
    subscriptionEmitService.ifPresent(s -> s.emitBulkUploadEvent(saved));
    return saved;
  }

  private BulkUpload updateTotalRecords(BulkUpload bulkUpload, int totalRecords) {
    bulkUpload.setTotalRecords(totalRecords);
    return bulkUploadRepository.saveAndFlush(bulkUpload);
  }

  private Response errorResponse(String id, String errorMessage) {
    Response response = new Response();
    response.setId(id);
    response.setErrorMessage(errorMessage);
    response.setStatus(BulkUploadStatus.FAILED.name());
    return response;
  }

  public void firmIdMatchBulkUploadFirmId(String batchId, String firmId) {
    BulkUpload bulkUpload = getBulkUploadByBatchId(batchId);
    if (!bulkUpload.getFirmId().equals(firmId)) {
      log.warn("firmIdMatchBulkUploadFirmId # FirmId does not match: batchId: {}, firmId: {}", batchId, firmId);
      throw new FumValidationException(Constants.BULK_UPLOAD_FIRM_ID_NOT_MATCH_CODE,
          Constants.BULK_UPLOAD_FIRM_ID_NOT_MATCH_MESSAGE + batchId);
    }
  }
}
