package ca.bnc.wealth.api.bulk.management.service;

import ca.bnc.wealth.api.bulk.management.utils.Constants;
import ca.bnc.wealth.api.bulk.management.utils.MapperUtils;
import ca.bnc.wealth.common.bulk_management.model.ExportRequest;
import ca.bnc.wealth.common.bulk_management.model.Filter;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.fum.model.FirmPreferencesEnum;
import ca.bnc.wealth.common.fum.model.UserPreferencesEnum;
import ca.bnc.wealth.common.fum.service.CustomThreadPoolExecutor;
import ca.bnc.wealth.common.fum.service.FirmServiceHelper;
import ca.bnc.wealth.common.jpa.entity.enums.BatchType;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.Audit;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import ca.bnc.wealth.common.jpa.repo.iam.AuditRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class TriggerExportProcessService {

  public static final String GET_USER_FROM_MV_BY_CONF_ID_QUERY = """
  select *
  from
    "IAM_V2"."USER_CONFIGURATION_LIVE"
  """;

  public static final String GET_MODULE_OVERRIDES_QUERY = """
      select * from "IAM_V2".fn_getFirmLevelAccess_moduleOverride_features(CAST(STRING_TO_ARRAY((:idpSubjects),',') AS VARCHAR[]))
  """;

  public static final String ORDER_BY = "  order by \"FIRM_ID\", \"FIRST_NAME\" , \"LAST_NAME\"";

  public static final String GET_FIRM_WITH_IDENTITY_SOURCE_QUERY = """
     select * from "IAM_V2"."FIRM" where "IDENTITY_SOURCE" is not null
  """;

  @Autowired
  private BulkUploadRepository bulkUploadRepository;

  @Qualifier("readJdbcTemplate")
  @Autowired
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @Autowired
  private CsvWriteService csvWriteService;

  @Autowired
  private BulkTemplateService bulkTemplateService;

  @Autowired
  private AuditRepository auditRepository;

  @Value("${bulk.export.batch.chunkSize:50}")
  private int chunkSize;

  @Value("${bulk.export.batch.timeBetweenChunkExec:60000}")
  private int timeBetweenChunkExec;

  @Value("${bulk.export.batch.disableDelay:true}")
  private boolean disableDelay;

  @Autowired
  private ExternalClientService externalClientService;

  @Autowired
  private FirmServiceHelper firmServiceHelper;

  @Autowired
  private FirmRepository firmRepository;

  @CustomThreadPoolExecutor(isBlockingQueue = false, corePoolSize = "${bulk.export.uploadCorePoolSize:2}", maxPoolSize = "${bulk.export.uploadMaxPoolSize:2}")
  public void triggerExportProcess(BulkUpload bulkUpload,  ExportRequest exportRequest, String requestedBy) {

    bulkUpload.setBulkUploadStatus(BulkUploadStatus.PROCESSING);
    bulkUploadRepository.saveAndFlush(bulkUpload);
    try {

      List<Map<String, Object>> userList = getUserData(exportRequest, requestedBy);
      List<String> userOrder = userList.stream()
          .map(map -> getStringValue(map.get("IDP_SUBJECT")))
          .toList();

      Map<String, Map<String, String>> idpSubjectRowMap = getCsvList(userList, bulkUpload.getBulkUploadTemplate().getTemplateName());

      updateExternalIdAndOverrides(idpSubjectRowMap);

      Audit audit = createAuditCsv(bulkUpload.getBulkUploadTemplate().getTemplateName(), idpSubjectRowMap, userOrder);

      bulkUpload.setTotalRecords(userList.size());
      bulkUpload.setBulkUploadStatus(BulkUploadStatus.SUCCESS);
      bulkUpload.setGeneratedAudit(audit);
      bulkUploadRepository.saveAndFlush(bulkUpload);
    } catch (Exception exception) {
      log.warn("triggerExportProcess #{} Exception: {}", bulkUpload.getBatchID(), exception.getMessage());
      bulkUpload.setBulkUploadStatus(BulkUploadStatus.FAILED);
      bulkUploadRepository.saveAndFlush(bulkUpload);
    }
  }

  Audit createAuditCsv(String templateName, Map<String, Map<String, String>> idpSubjectRowMap, List<String> userOrder) {
    List<Map<String, String>> csvList = userOrder.stream().map(idpSubjectRowMap::get).toList();
    Optional<BulkUploadTemplate> optionalTemplate = bulkTemplateService.getTemplate(templateName, BatchType.UPLOAD);
    if (optionalTemplate.isEmpty()) {
      throw new FumServiceException("error.template.notFound", "Template not found: " + templateName);
    }
    BulkUploadTemplate template = optionalTemplate.get();
    List<String> headers = template.getConfig().getHeaderNames();
    String csvString = csvWriteService.getCsvString(headers, csvList, template.getConfig().getDelimiter());
    Audit audit = new Audit();
    audit.setFileName("users-upload-" + getFormattedDate() + ".csv");
    audit.setFileContents(csvString.getBytes(StandardCharsets.UTF_8));
    audit.setMetadata("metadata".getBytes());
    audit.setUpdatedBy("");
    audit.setUpdatedDate(new java.sql.Timestamp(System.currentTimeMillis()));
    return auditRepository.save(audit);
  }

  private void updateExternalIdAndOverrides(Map<String, Map<String, String>> idpSubjectRowMap) {

    ListUtils.partition(new ArrayList<>(idpSubjectRowMap.values()), chunkSize).stream()
        .peek(list -> this.waitForNextExec())
        .forEach(csvListChunk -> {
          List<String> idpSubjects = csvListChunk.stream().map(map -> map.get(Constants.IDP_SUBJECT)).toList();
          String idpSubjectString = String.join(",", idpSubjects);
          log.info("idpSubjectString: {}", idpSubjectString);

          MapSqlParameterSource parameters = new MapSqlParameterSource();
          parameters.addValue("idpSubjects", idpSubjectString);
          String idpFlaMoFs = namedParameterJdbcTemplate.queryForObject(GET_MODULE_OVERRIDES_QUERY,parameters, String.class);
          log.info("idpFlaMoFs: {}", idpFlaMoFs);

          if(StringUtils.isNotBlank(idpFlaMoFs)) {
            Arrays.stream(idpFlaMoFs.split("#")).forEach(idpFlaMoF -> {
              String[] idpFlaMoFArray = idpFlaMoF.split("\\|");
              if(idpFlaMoFArray.length == 4) {
                String idpSubject = idpFlaMoFArray[0];
                idpSubjectRowMap.get(idpSubject).put(Constants.FIRM_LEVEL_ACCESS, idpFlaMoFArray[1].trim());
                idpSubjectRowMap.get(idpSubject).put(Constants.MODULE_OVERRIDES, idpFlaMoFArray[2].trim());
                idpSubjectRowMap.get(idpSubject).put(Constants.FEATURES, idpFlaMoFArray[3].trim());
              }
            });
          }

          csvListChunk.forEach(map -> {
            map.put(Constants.SECURE_ZONE_ID, externalClientService.getSecureZoneId(map.get(Constants.IDP_USER_ID)));
            map.put(Constants.COMPASS_R2_ID, externalClientService.getCompassR2(map.get(Constants.IDP_SUBJECT)));
          });

    });
  }

  Map<String, Map<String, String>> getCsvList(List<Map<String, Object>> userList, String templateName) {
    Map<String, String> firmIdAndIdentitySource = getFirmIdAndIdentitySource();

    Optional<BulkUploadTemplate> optionalTemplate = bulkTemplateService.getTemplate(templateName, BatchType.UPLOAD);
    if (optionalTemplate.isEmpty()) {
      throw new FumServiceException("error.template.notFound", "Template not found: " + templateName);
    }
    Template templateConfig = optionalTemplate.get().getConfig();

    Map<String,Map<String, String>> idpSubjectRowMap = new HashMap<>();
    userList.forEach(map -> {
      Map<String, String> csvMap = new HashMap<>();
      csvMap.put(Constants.IDP_SUBJECT, getStringValue(map.get("IDP_SUBJECT")));
      csvMap.put(Constants.IDP_USER_ID, getStringValue(map.get("IDP_USER_ID")));
      csvMap.put(Constants.FIRM_ID, getStringValue(map.get("FIRM_ID")));
      csvMap.put(Constants.FIRST_NAME, getStringValue(map.get("FIRST_NAME")));
      csvMap.put(Constants.LAST_NAME, getStringValue(map.get("LAST_NAME")));
      csvMap.put(Constants.EMAIL_ADDRESS, getStringValue(map.get("EMAIL")));
      csvMap.put(Constants.PREFERRED_LANGUAGE, getStringValue(map.get("PREFERRED_LANGUAGE")));

      Map<String, String> userPreferences = Optional.ofNullable(map.get("USER_PREFERENCES"))
          .map(String::valueOf)
          .map(MapperUtils::getMap)
          .orElse(new HashMap<>());

      Map<String, String> firmPreferences = Optional.ofNullable(map.get("FIRM_PREFERENCES"))
          .map(String::valueOf)
          .map(MapperUtils::getMap)
          .orElse(new HashMap<>());

      csvMap.put(Constants.DEFAULT_MODULE, getUserPreferences(userPreferences, firmPreferences, templateConfig));
      csvMap.put(Constants.USER_NAME, getStringValue(map.get("USERNAME")));

      csvMap.put(Constants.OSS_USER_ID, getStringValue(map.get("OSS_USER_ID")));

      String bngfReferenceId = getStringValue(map.get("BNGF_REFERENCE_ID"));
      String firmId = getStringValue(map.get("FIRM_ID"));
      if(bngfReferenceId!= null && firmIdAndIdentitySource.containsKey(firmId) && bngfReferenceId.startsWith(firmIdAndIdentitySource.get(firmId))) {
        String externalClientId = bngfReferenceId.replace( firmIdAndIdentitySource.get(firmId) + "_", "");
        csvMap.put(Constants.EXTERNAL_CLIENT_ID, externalClientId);
      }else {
        csvMap.put(Constants.EXTERNAL_CLIENT_ID, "");
      }

      csvMap.put(Constants.PACKAGE_TEMPLATE_NAME, getStringValue(map.get("USER_ROLE")));

      String rrCode = getStringValue(map.get("RR_RANGES"));
      csvMap.put(Constants.RR_CODES, rrCode!= null && rrCode.equals("-") ? "" : rrCode);


      idpSubjectRowMap.put(csvMap.get(Constants.IDP_SUBJECT),csvMap);
    });
    return idpSubjectRowMap;
  }

  private List<Map<String, Object>> getUserData(ExportRequest exportRequest, String idpSubject) {
    StringBuilder query = new StringBuilder(GET_USER_FROM_MV_BY_CONF_ID_QUERY);
    MapSqlParameterSource userParameters = new MapSqlParameterSource();

    query.append(" where \"STATE_DESCRIPTION\" not in ('Deleted', 'Suspended') ");
    List<String> firmIds = getFirmIdForSearch(exportRequest, idpSubject);
    if (!firmIds.isEmpty()) {
      query.append(" and \"FIRM_ID\" in (:firmId) ");
      userParameters.addValue("firmId", firmIds);
    }

    if( exportRequest.getFilter()!= null && !exportRequest.getFilter().isEmpty()) {
      int filterIndex = 0;
      for(Filter filter: exportRequest.getFilter()) {
        String paramName = "filterValue" + filterIndex++;
        log.info("SQL_FILTER_APPLIED: fieldName={}, condition={}", filter.getFieldName(), filter.getFilterCondition());
        query.append(" and ").append(getWhereClause(filter, paramName, userParameters)).append(" ");
      }
    }
    query.append(ORDER_BY);
    log.info("getUserData # query: {}", query);
    log.info("getUserData # userParameters: {}", userParameters);
    return namedParameterJdbcTemplate.queryForList(query.toString(), userParameters);
  }

  private List<String> getFirmIdForSearch(ExportRequest exportRequest, String idpSubject) {
    String primaryFirmId = firmServiceHelper.getPrimaryFirm(idpSubject, null)
        .map(Firm::getFirmId)
        .orElseThrow(() -> new FumNotFoundException(Constants.BULK_EXPORT_PRIMARY_FIRM_NOT_FOUND_CODE, Constants.BULK_EXPORT_PRIMARY_FIRM__NOT_FOUND_MESSAGE));
    List<String> firmIds = new ArrayList<>();
    if (primaryFirmId.equalsIgnoreCase("NBIN")) {
      if(exportRequest.getFirmId() != null && !exportRequest.getFirmId().isEmpty()) {
        firmIds.addAll(exportRequest.getFirmId());
      }
    } else {
      if(exportRequest.getFirmId() != null && !exportRequest.getFirmId().isEmpty()) {
        List<Long> ids = firmRepository.getAllFirmsByIdpSubject(idpSubject);
        List<String> userFirmsIds = ids.stream()
            .map(firmRepository::findById)
            .map(Optional::get)
            .map(Firm::getFirmId)
            .toList();
        exportRequest.getFirmId()
            .stream()
            .filter(userFirmsIds::contains)
            .forEach(firmIds::add);
      } else {
        firmIds.add(primaryFirmId);
      }
    }

    return firmIds;
  }

  private static final java.util.regex.Pattern COLUMN_NAME_PATTERN = java.util.regex.Pattern.compile("^[A-Za-z0-9_]{1,64}$");

  private String validateColumnName(String fieldName) {
    if (fieldName == null || !COLUMN_NAME_PATTERN.matcher(fieldName).matches()) {
      log.error("SQL_INJECTION_ATTEMPT: rejected filter fieldName={}", fieldName);
      throw new FumServiceException("error.filter.invalidField", "Invalid filter field name");
    }
    return fieldName;
  }

  private String getWhereClause(Filter filter, String paramName, MapSqlParameterSource params) {
    String column = "\"" + validateColumnName(filter.getFieldName()) + "\"";
    String placeholder = ":" + paramName;
    String value = filter.getFieldValue();
    String whereClause = "";
    switch (filter.getFilterCondition()) {
      case IN -> {
        params.addValue(paramName, Arrays.stream(value.split(",")).map(String::trim).toList());
        whereClause = column + " in (" + placeholder + ")";
      }
      case EQUALS -> {
        params.addValue(paramName, value);
        whereClause = column + " = " + placeholder;
      }
      case NOT_EQUALS -> {
        params.addValue(paramName, value);
        whereClause = column + " <> " + placeholder;
      }
      case CONTAINS -> {
        params.addValue(paramName, "%" + value + "%");
        whereClause = column + " like " + placeholder;
      }
      case STARTS_WITH -> {
        params.addValue(paramName, value + "%");
        whereClause = column + " like " + placeholder;
      }
      case ENDS_WITH -> {
        params.addValue(paramName, "%" + value);
        whereClause = column + " like " + placeholder;
      }
      case GREATER_THAN -> {
        params.addValue(paramName, value);
        whereClause = column + " > " + placeholder;
      }
      case GREATER_THEN_OR_EQUAL -> {
        params.addValue(paramName, value);
        whereClause = column + " >= " + placeholder;
      }
      case LESS_THAN -> {
        params.addValue(paramName, value);
        whereClause = column + " < " + placeholder;
      }
      case LESS_THAN_OR_EQUAL -> {
        params.addValue(paramName, value);
        whereClause = column + " <= " + placeholder;
      }
      case IS_NULL -> whereClause = column + " is null";
      case IGNORE_CASE_EQUALS -> {
        params.addValue(paramName, value);
        whereClause = "lower(" + column + ") = lower(" + placeholder + ")";
      }
      case IGNORE_CASE_NOT_EQUALS -> {
        params.addValue(paramName, value);
        whereClause = "lower(" + column + ") <> lower(" + placeholder + ")";
      }
      case IGNORE_CASE_CONTAINS -> {
        params.addValue(paramName, "%" + value + "%");
        whereClause = "lower(" + column + ") like lower(" + placeholder + ")";
      }
      case IGNORE_CASE_STARTS_WITH -> {
        params.addValue(paramName, value + "%");
        whereClause = "lower(" + column + ") like lower(" + placeholder + ")";
      }
      case IGNORE_CASE_ENDS_WITH -> {
        params.addValue(paramName, "%" + value);
        whereClause = "lower(" + column + ") like lower(" + placeholder + ")";
      }
    }
    return whereClause;
  }

  private String getStringValue(Object object) {
    return object != null ? object.toString() : null;
  }

  private static String getUserPreferences(Map<String, String> userPreferences, Map<String, String> firmPreferences, Template templateConfig) {
    if(userPreferences != null && userPreferences.containsKey(UserPreferencesEnum.defaultModule.name()) && StringUtils.isNotBlank(userPreferences.get(UserPreferencesEnum.defaultModule.name()))) {
      return userPreferences.get(UserPreferencesEnum.defaultModule.name());
    } else if(firmPreferences != null && firmPreferences.containsKey(FirmPreferencesEnum.defaultModule.name()) && StringUtils.isNotBlank(firmPreferences.get(FirmPreferencesEnum.defaultModule.name()))) {
      return firmPreferences.get(FirmPreferencesEnum.defaultModule.name());
    }
    return templateConfig.getFields().stream()
        .filter(field -> field.getConfig().getHeaderName().equalsIgnoreCase(Constants.DEFAULT_MODULE))
        .findFirst()
        .map(field -> field.getConfig().getDefaultValue())
        .orElse("firm_client_accounts");
  }

  private Map<String, String> getFirmIdAndIdentitySource() {
    Map<String, String> firmIdAndName = new HashMap<>();
    namedParameterJdbcTemplate.queryForList(GET_FIRM_WITH_IDENTITY_SOURCE_QUERY, new MapSqlParameterSource())
        .forEach(map -> {
          String firmId = getStringValue(map.get("FIRM_ID"));
          String identitySource = getStringValue(map.get("IDENTITY_SOURCE"));
          if (StringUtils.isNotBlank(firmId) && StringUtils.isNotBlank(identitySource)) {
            firmIdAndName.put(firmId, identitySource);
          }
        });
    return firmIdAndName;
  }

  @SneakyThrows
  private void waitForNextExec() {
    if( disableDelay ) {
      return;
    }
    log.info("Waiting for " + timeBetweenChunkExec + " millsecond before starting next chunk");
    Thread.sleep(timeBetweenChunkExec);
    log.info("will start the next chunk of records");
  }

  private String getFormattedDate() {
    LocalDateTime today = LocalDateTime.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd-HH-mm");
    return today.format(formatter);
  }
}
