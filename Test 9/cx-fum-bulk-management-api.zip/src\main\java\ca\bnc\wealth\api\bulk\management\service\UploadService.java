package ca.bnc.wealth.api.bulk.management.service;

import ca.bnc.wealth.api.bulk.management.jpa.GenericBatchSearchCriteria;
import ca.bnc.wealth.api.bulk.management.utils.Constants;
import ca.bnc.wealth.api.bulk.management.utils.MapperUtils;
import ca.bnc.wealth.common.bulk_management.model.BatchesSearchRequest;
import ca.bnc.wealth.common.bulk_management.model.BatchesSearchResponse;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.enums.BatchType;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.Audit;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import ca.bnc.wealth.common.jpa.repo.iam.AuditRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserConfigSearchMaterializedViewRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.jpa.utils.RepositoryUtils;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@Service
public class UploadService {

    @Autowired
    private BulkTemplateService bulkTemplateService;

    @Autowired
    private BulkValidationService bulkValidationService;

    @Autowired
    private BulkUploadRepository bulkUploadRepository;

    @Autowired
    private AuditRepository auditRepository;

    @Autowired
    private BulkUploadTemplateRepository bulkUploadTemplateRepository;

    @Autowired
    private UserConfigSearchMaterializedViewRepository userConfigSearchMaterializedViewRepository;

    @Autowired(required = false)
    private SubscriptionEmitService subscriptionEmitService;

    public Pair<String,ByteArrayResource> getUploadedFile(String batchId, String firmId) {
        BulkUpload upload = getBulkUploadByBatchId(batchId);
        validateFirmAccess(upload, batchId, firmId);
        Audit audit = upload.getAudit();
        return Pair.of(audit.getFileName(), new ByteArrayResource(audit.getFileContents()));
    }

    public Pair<String,ByteArrayResource> getResultsFileByBatchId(String batchId, String firmId) {
        BulkUpload upload = getBulkUploadByBatchId(batchId);
        validateFirmAccess(upload, batchId, firmId);
        Audit audit = upload.getGeneratedAudit();
        if(audit == null) {
            log.warn("Bulk upload results not found for form id: {}", batchId);
            throw new FumNotFoundException(Constants.BULK_UPLOAD_RESULTS_NOT_FOUND_CODE,
                Constants.BULK_UPLOAD_RESULTS_NOT_FOUND_MESSAGE + batchId);
        }
        return Pair.of(audit.getFileName(), new ByteArrayResource(audit.getFileContents()));
    }

    private void validateFirmAccess(BulkUpload upload, String batchId, String firmId) {
        String batchFirmId = upload.getFirmId();
        log.info("BULK_FILE_ACCESS: batchId={}, userFirm={}, batchFirm={}", batchId, firmId, batchFirmId);
        // Export batches carry no firmId; NBIN is the cross-firm administrative firm.
        if (batchFirmId == null || "NBIN".equalsIgnoreCase(firmId)) {
            return;
        }
        if (!batchFirmId.equals(firmId)) {
            log.warn("BULK_FILE_ACCESS_DENIED: batchId={}, userFirm={}, batchFirm={}", batchId, firmId, batchFirmId);
            throw new FumValidationException(Constants.BULK_UPLOAD_FIRM_ID_NOT_MATCH_CODE,
                Constants.BULK_UPLOAD_FIRM_ID_NOT_MATCH_MESSAGE + batchId);
        }
    }

    public BatchesSearchResponse getBulkUploadsByTemplateNamesAndBatchType(
        BatchesSearchRequest bulkUploadRecordRequest) {
        Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
        if(!bulkUploadRecordRequest.getTemplateNames().isEmpty()) {
            fieldValueMap.put("bulkUploadTemplate.templateName", Pair.of(EnumQueryCriteria.IN,
                bulkUploadRecordRequest.getTemplateNames()));
        }
        fieldValueMap.put("bulkUploadTemplate.batchType", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER,
            bulkUploadRecordRequest.getBatchType()));
        fieldValueMap.put("bulkUploadStatus", Pair.of(EnumQueryCriteria.IGNORE_CASE_NOT_EQUALS,
            BulkUploadStatus.UPLOADED.name()));

        Specification<BulkUpload> spec = new Specification<>(fieldValueMap);

        List<String> fields =
            CollectionUtils.isEmpty(bulkUploadRecordRequest.getSortBy())
                ? List.of(GenericBatchSearchCriteria.batchID.getEntityField())
                : bulkUploadRecordRequest.getSortBy().stream()
                    .map(field -> GenericBatchSearchCriteria.valueOf(field).getEntityField())
                    .toList();

        String direction = bulkUploadRecordRequest.getSortOrder() != null ? bulkUploadRecordRequest.getSortOrder().name() : null;

        PageRequest page =
            RepositoryUtils.getPageRequest(
                bulkUploadRecordRequest.getPageNumber(), bulkUploadRecordRequest.getPageSize(), fields, direction, false);

        Page<BulkUpload> bulkUploads = bulkUploadRepository.findAll(spec, page);

        List<String> idpSubjects = bulkUploads.stream()
            .map(BulkUpload::getCreatedBy)
            .filter(Objects::nonNull)
            .distinct().toList();

        Map<String, Pair<EnumQueryCriteria, Object>> userFieldValueMap = new HashMap<>();
        userFieldValueMap.put("idpSubject", Pair.of(EnumQueryCriteria.IN, idpSubjects));
        Specification<UserConfigSearchMaterializedView> userSpec = new Specification<>(userFieldValueMap);
        Map<String, UserConfigSearchMaterializedView> usersMap = userConfigSearchMaterializedViewRepository.findAll(userSpec)
            .stream().collect(Collectors.toMap(UserConfigSearchMaterializedView::getIdpSubject, user -> user));

        BatchesSearchResponse batchesSearchResponse = MapperUtils.toDto(bulkUploads.toList(), usersMap);
        batchesSearchResponse.setTotalCount((int) bulkUploads.getTotalElements());
        if (bulkUploadRecordRequest.getPageSize() != null && bulkUploadRecordRequest.getPageSize() > 0) {
            batchesSearchResponse.setNumberOfPages(
                batchesSearchResponse.getTotalCount() / bulkUploadRecordRequest.getPageSize()
                    + (batchesSearchResponse.getTotalCount() % bulkUploadRecordRequest.getPageSize() == 0 ? 0 : 1));
        }

        return batchesSearchResponse;
    }

    @SneakyThrows
    public BulkUpload validateAndUpload(String templateName, String firmId,
        MultipartFile fileToUpload, String requestId) {
        BulkUploadTemplate bulkUploadTemplate = bulkTemplateService.getTemplate(
                        templateName, BatchType.UPLOAD)
                .orElseThrow(() -> {
                    log.warn("Template name not found for template name: {}", templateName);
                    return new FumValidationException(Constants.BULK_UPLOAD_TEMPLATE_NOT_FOUND_CODE,
                            Constants.BULK_UPLOAD_TEMPLATE_NOT_FOUND_MESSAGE + templateName);
                });
        Template templateRules = bulkUploadTemplate.getConfig();

        bulkValidationService.validateFile(fileToUpload, templateRules)
                .ifPresent(error -> {
                    log.warn("Error validating file: {}", error);
                    throw new FumValidationException(Constants.BULK_UPLOAD_FILE_VALIDATION_ERROR_CODE,
                            error);
                });

        Audit auditEntity = createAuditLog(requestId, fileToUpload, "metadata");

        return createBulkUpload(bulkUploadTemplate, auditEntity, firmId, requestId);
    }

    private BulkUpload createBulkUpload(BulkUploadTemplate bulkUploadTemplate, Audit audit,
        String firmId, String requestId) {
        return createBulkUpload(bulkUploadTemplate, BulkUploadStatus.UPLOADED, audit, firmId, requestId);
    }

    private BulkUpload createBulkUpload(BulkUploadTemplate bulkUploadTemplate,BulkUploadStatus status, Audit audit,
        String firmId, String requestId) {
        BulkUpload entity = new BulkUpload();
        long sequence = bulkUploadRepository
            .generateID("\"IAM_V2\".\"bulk_user_migration_request_sequence\"");
        entity.setBatchID(formatId(getPrefix(bulkUploadTemplate), "", "%010d", sequence));
        entity.setBulkUploadTemplate(bulkUploadTemplate);
        entity.setAudit(audit);
        entity.setFirmId(firmId);
        entity.setUserRequestedBy(requestId);
        entity.setBulkUploadStatus(status);
        entity.setTotalRecords(0);
        entity.setTotalSuccess(0);
        entity.setTotalFailed(0);
        entity.setTotalPending(0);
        entity.setCreatedBy(requestId);
        entity.setCreatedDate(Timestamp.valueOf(LocalDateTime.now()));
        BulkUpload saved = bulkUploadRepository.saveAndFlush(entity);
        log.info("emit4) # Emitting bulk upload event for batch id: {}", saved.getBatchID());
        Optional.ofNullable(subscriptionEmitService)
            .ifPresent(s -> s.emitBulkUploadEvent(saved));
        return saved;
    }

    @SneakyThrows
    public Audit createAuditLog(String idpSubject, MultipartFile file, String metadata) {
        log.info("uploadAudit # Start: idpUserSubject: {}", idpSubject);
        byte[] fileContents = MapperUtils.removeBom(file.getBytes());
        Audit audit = new Audit();
        audit.setFileName(file.getOriginalFilename());
        audit.setFileContents(fileContents);
        audit.setMetadata(metadata.getBytes());
        audit.setUpdatedBy(idpSubject);
        audit.setUpdatedDate(new java.sql.Timestamp(System.currentTimeMillis()));
        return auditRepository.save(audit);
    }

    private String getPrefix(BulkUploadTemplate bulkUploadTemplate) {
        return StringUtils.isNotBlank(bulkUploadTemplate.getPrefix()) ? bulkUploadTemplate.getPrefix() : bulkUploadTemplate.getBatchType() == BatchType.EXPORT ? "CUE" : "CUU";
    }
    private String formatId(@Nullable String prefix, @Nullable String suffix, @NonNull String format,
                            @NonNull Long id) {
        format = StringUtils.isBlank(prefix) ? format : prefix + format;
        format = StringUtils.isBlank(suffix) ? format : format + suffix;
        return String.format(format, id);
    }

    public BulkUpload getBulkUploadByBatchId(String batchId) {
        return bulkUploadRepository.findByBatchID(batchId)
            .orElseThrow(() -> {
                log.warn("Bulk upload not found for form id: {}", batchId);
                throw new FumNotFoundException(Constants.BULK_UPLOAD_NOT_FOUND_CODE,
                    Constants.BULK_UPLOAD_NOT_FOUND_MESSAGE + batchId);
            });
    }

    public BulkUpload createBulkUploadExport(String templateName, String requestId) {
        BulkUploadTemplate bulkUploadTemplate = bulkTemplateService.getTemplate(
                templateName, BatchType.EXPORT)
            .orElseThrow(() -> {
                log.warn("Template name not found for template name: {}", templateName);
                return new FumValidationException(Constants.BULK_UPLOAD_TEMPLATE_NOT_FOUND_CODE,
                    Constants.BULK_UPLOAD_TEMPLATE_NOT_FOUND_MESSAGE + templateName);
            });

        return createBulkUpload(bulkUploadTemplate, BulkUploadStatus.SUBMITTED, null, null, requestId);
    }

}

