package ca.bnc.wealth.api.bulk.management.utils;

public class Constants {
  public static final String ROW_NUMBER = "row-number";
  public static final String CURRENT_FIRM = "current-firm";
  public static final String CURRENT_USER = "current-user";
  public static final String REQUEST_CALLBACK = "requiresCallback";
  public static final String REQUEST_ID = "requestedId";
  public static final String RUNNING_INSTANCES_FOR_CALLBACK = "running_instances_for_callback";
  public static final String MAX_WAIT_TIME_MIN_FOR_CALLBACK_MIN = "max_wait_before_fail_for_callback_min";
  public static final String BMA_SYSTEM = "BMA_SYSTEM";
  public static final String IDP_SUBJECT = "idp-subject";
  public static final String IDP_USER_ID = "idp-user-id";
  public static final String FIRM_ID = "Firm*";
  public static final String FIRST_NAME = "First Name*";
  public static final String LAST_NAME = "Last Name*";
  public static final String EMAIL_ADDRESS = "Email Address*";
  public static final String PREFERRED_LANGUAGE = "Preferred Language*";
  public static final String DEFAULT_MODULE =  "Default Module";
  public static final String USER_NAME = "User ID*";
  public static final String SECURE_ZONE_ID ="SecureZone ID";
  public static final String OSS_USER_ID = "OSS User ID";
  public static final String COMPASS_R2_ID ="CR2 User ID";
  public static final String EXTERNAL_CLIENT_ID ="SSO User ID";
  public static final String PACKAGE_TEMPLATE_NAME = "Role*";
  public static final String FIRM_LEVEL_ACCESS = "Firm Level Access*";
  public static final String RR_CODES = "RR Code Assignment";
  public static final String MODULE_OVERRIDES = "Module Overrides";
  public static final String FEATURES = "Features";
  public static final String BULK_UPLOAD_STATUS = "bulkUploadStatus";
  public static final String STATUS = "Status";
  public static final String REQUEST = "Request";
  public static final String ERROR_MESSAGE = "Error Message";
  public static final String ERROR_OKTA_PROFILE = "error.okta.profile.found";
  public static final String ERROR_INVALID_FIRM_ID = "error.firmId.invalid";
  public static final String ERROR_R2_PW = "error.hashedPassword.invalid";
  public static final String ERROR_R2_FOUND = "error.r2.withcpxsub";
  public static final String ERROR_EMAIL_INVALID = "error.email.invalid.format";
  public static final String ERROR_OKTA_CREATE = "error.okta.profile.creation";
  public static final String ERROR_R2_NOT_FOUND = "error.r2.notfound";
  public static final String ERROR_RR_CODE_INVALID = "error.rrcode.invalid";
  public static final String ERROR_SSO_EXIST = "error.bngfReferenceId.exist";

  public static final String ERROR_R2_NOT_FOUND_MESSAGE = "R2 ID does not exist";

  public static final String BULK_UPLOAD_TEMPLATE_NOT_FOUND_CODE = "bulk.user.upload.template.notFound";
  public static final String BULK_UPLOAD_TEMPLATE_NOT_FOUND_MESSAGE = "Template rules not found for template name: ";
  public static final String BULK_UPLOAD_TEMPLATE_NOT_SUPPORTED_CODE = "bulk.user.upload.template.notSupported";
  public static final String BULK_UPLOAD_TEMPLATE_NOT_SUPPORTED_MESSAGE = "Template format not supported: ";
  public static final String BULK_UPLOAD_FILE_VALIDATION_ERROR_CODE = "bulk.user.upload.file.validation.error";
  public static final String INVALID_REQUEST_METHOD_CODE = "http.method.invalid";
  public static final String INVALID_REQUEST_METHOD_MESSAGE = "HTTP Method is not supported";
  public static final String BULK_UPLOAD_FILE_READ_ERROR_CODE = "bulk.user.upload.file.read.error";
  public static final String BULK_UPLOAD_TEMPLATE_FORM_CODE = "bulk.user.upload.template.form.validation.error";
  public static final String BULK_UPLOAD_TEMPLATE_FORM_MESSAGE = "Supported template formatat USER-MIGRATE-TEMPLATE and USER-PASSWORD-TEMPLATE";
  public static final String BULK_UPLOAD_NOT_FOUND_CODE = "bulk.user.upload.notFound";
  public static final String BULK_UPLOAD_NOT_FOUND_MESSAGE = "Bulk upload not found for id: ";
  public static final String BULK_UPLOAD_DETAIL_NOT_FOUND_CODE = "bulk.user.upload.detail.notFound";
  public static final String BULK_UPLOAD_DETAIL_NOT_FOUND_MESSAGE = "Bulk upload detail not found for action id: ";
  public static final String BULK_UPLOAD_PASSWORD_FILE_VALIDATION_ERROR_CODE = "bulk.user.upload.password.file.validation.error";
  public static final String BULK_UPLOAD_PASSWORD_FILE_VALIDATION_ERROR_MESSAGE = "Password file does not contain password for user: ";
  public static final String BULK_UPLOAD_STATUS_ERROR_CODE = "bulk.user.upload.status.error";
  public static final String BULK_UPLOAD_STATUS_ERROR_MESSAGE = "Bulk upload status is not UPLOADED, current status: ";
  public static final String BULK_UPLOAD_HASH_ERROR_CODE = "bulk.user.upload.hashPassword.error";
  public static final String BULK_UPLOAD_HASH_ERROR_MESSAGE = "Password is required";
  public static final String BULK_UPLOAD_GENERATED_AUDIT_NOT_FOUND_CODE = "bulk.user.upload.generated.audit.notFound";
  public static final String BULK_UPLOAD_GENERATED_AUDIT_NOT_FOUND_MESSAGE = "Generated audit not found for migration id: ";
  public static final String BULK_USER_MIGRATE_TEMPLATE = "User_Template.csv";
  public static final String BULK_USER_PASSWORD_TEMPLATE = "Password_Template.csv";
  public static final String BULK_UPLOAD_INVALID_JSON = "Invalid JSON format";
  public static final String BULK_UPLOAD_JSON_PAYLOAD_MISSING = "Payload is missing or empty";
  public static final String BULK_UPLOAD_URL_MISSING = "Target Url is missing";
  public static final String BULK_UPLOAD_MALFORMED_URL = "Malformed Target Url";
  public static final String BULK_UPLOAD_HTTP_METHOD_MISSING = "Http Method is missing";
  public static final String BULK_UPLOAD_REQUIRES_CALLBACK = "RequiresCallback is missing";
  public static final String BULK_UPLOAD_INVALID_HTTP_METHOD = "Invalid Http Method";
  public static final String BULK_UPLOAD_FIRM_ID_NOT_MATCH_CODE = "bulk.user.upload.firmId.notMatch";
  public static final String BULK_UPLOAD_FIRM_ID_NOT_MATCH_MESSAGE = "Firm ID does not match firm Id of upload";
  public static final String BULK_UPLOAD_RESULTS_NOT_FOUND_CODE = "bulk.user.upload.results.notFound";
  public static final String BULK_UPLOAD_RESULTS_NOT_FOUND_MESSAGE = "Bulk upload results not found for bulk id: ";
  public static final String BULK_EXPORT_PRIMARY_FIRM_NOT_FOUND_CODE = "bulk.user.export.primaryfirm.notFound";
  public static final String BULK_EXPORT_PRIMARY_FIRM__NOT_FOUND_MESSAGE = "Bulk upload result not found for action id: ";
  public static final byte[] CSV_BOM_HEADER_BYTE = new byte[] {(byte) 0xEF, (byte) 0xBB, (byte) 0xBF};
  public static final String SYSTEM_TOKEN_FUM = "fum";

  private Constants() {
    throw new IllegalStateException("Utility class");
  }
}
