package ca.bnc.wealth.api.bulk.management.utils;

import ca.bnc.wealth.common.bulk_management.model.BatchStatus;
import ca.bnc.wealth.common.bulk_management.model.BatchesSearchResponse;
import ca.bnc.wealth.common.jpa.entity.enums.BatchType;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import tools.jackson.core.JacksonException;

@Slf4j
public class MapperUtils {

  private MapperUtils() {
    throw new IllegalStateException("Utility class");
  }

  public static BatchesSearchResponse toDto(List<BulkUpload> bulkUploads, Map<String, UserConfigSearchMaterializedView> usersMap) {
    List<ca.bnc.wealth.common.bulk_management.model.BatchesSearchResponseRecord> searchResponseRecords = bulkUploads.stream()
        .map(bulkUpload -> {
          ca.bnc.wealth.common.bulk_management.model.BatchesSearchResponseRecord responseRecord =
              new ca.bnc.wealth.common.bulk_management.model.BatchesSearchResponseRecord();
          responseRecord.setBatchId(bulkUpload.getBatchID());
          responseRecord.setFileName(bulkUpload.getAudit() != null ?
              bulkUpload.getAudit().getFileName() : null);
          responseRecord.setCreatedDate(bulkUpload.getCreatedDate() != null ?
              bulkUpload.getCreatedDate().toString() : null);

          if (bulkUpload.getBulkUploadTemplate() != null) {
            responseRecord.setBatchType(bulkUpload.getBulkUploadTemplate().getBatchType() != null ?
                bulkUpload.getBulkUploadTemplate().getBatchType().name() : null);
            responseRecord.setTemplateName(bulkUpload.getBulkUploadTemplate().getTemplateName());
          }

          if (bulkUpload.getCreatedBy() != null) {
            UserConfigSearchMaterializedView materializedView = usersMap.get(bulkUpload.getCreatedBy());
            String name = materializedView != null ?
                String.format("%s %s", materializedView.getFirstName(), materializedView.getLastName()) : null;
            responseRecord.setCreatedBy(name);
          }

          if (bulkUpload.getBulkUploadTemplate() != null &&
              bulkUpload.getBulkUploadTemplate().getBatchType() == BatchType.EXPORT) {
            responseRecord.setFileName(bulkUpload.getGeneratedAudit() != null ?
                bulkUpload.getGeneratedAudit().getFileName() : null);
          }

          BatchStatus batchStatus = new BatchStatus();
          batchStatus.setTotalRecords(bulkUpload.getTotalRecords());
          batchStatus.setSuccessfullyRecords(bulkUpload.getTotalSuccess());
          batchStatus.setFailedRecords(bulkUpload.getTotalFailed());
          batchStatus.setInProgressRecords(bulkUpload.getTotalPending());
          batchStatus.setStatus(bulkUpload.getBulkUploadStatus() != null ?
              bulkUpload.getBulkUploadStatus().name() : null);

          responseRecord.setStatus(batchStatus);
          return responseRecord;
        }).toList();

    BatchesSearchResponse bulkUploadRecordResponse = new BatchesSearchResponse();
    bulkUploadRecordResponse.setBatches(searchResponseRecords);

    return bulkUploadRecordResponse;
  }

  public static Map<String,String> getMap(String mapString) {
    try {
      ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().build();
      return objectMapper.readValue(mapString, Map.class);
    } catch (JacksonException e) {
      return null;
    }
  }

  public static String removeBom(String bomString) {
    if(StringUtils.isBlank(bomString) || bomString.length() < 3) {
      return bomString;
    }
    byte[] first3byte = Arrays.copyOfRange(bomString.getBytes(StandardCharsets.UTF_8),0,3);
    if( Arrays.equals(Constants.CSV_BOM_HEADER_BYTE, first3byte)) {
      return new String(bomString.getBytes(StandardCharsets.UTF_8), 3, bomString.length() - 1, StandardCharsets.UTF_8);
    }
    return bomString;
  }

  public static byte[] removeBom(byte[] bomBytes) {
    if (bomBytes == null || bomBytes.length < 3) {
      return bomBytes;
    }
    byte[] first3byte = Arrays.copyOfRange(bomBytes, 0, 3);
    if (Arrays.equals(Constants.CSV_BOM_HEADER_BYTE, first3byte)) {
      return Arrays.copyOfRange(bomBytes, 3, bomBytes.length);
    }
    return bomBytes;
  }
}
