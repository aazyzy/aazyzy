package ca.bnc.wealth.api.bulk.management.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ca.bnc.wealth.api.authorization.security.SecurityConfigAdapter;
import ca.bnc.wealth.api.authorization.security.test.TestAuthConfiguration;
import ca.bnc.wealth.api.bulk.management.service.BulkStatusService;
import ca.bnc.wealth.api.bulk.management.service.BulkTemplateService;
import ca.bnc.wealth.api.bulk.management.service.BulkValidationService;
import ca.bnc.wealth.api.bulk.management.service.TriggerBulkProcessService;
import ca.bnc.wealth.api.bulk.management.service.TriggerExportProcessService;
import ca.bnc.wealth.api.bulk.management.service.UploadService;
import ca.bnc.wealth.common.bulk_management.model.BatchStatus;
import ca.bnc.wealth.common.bulk_management.model.BatchesSearchRequest;
import ca.bnc.wealth.common.bulk_management.model.ExportRequest;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import tools.jackson.databind.ObjectMapper;
import java.util.Arrays;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMultipartHttpServletRequestBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@WebMvcTest(properties = {"spring.profiles.active=test"})
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@ContextConfiguration(
    classes = {
        SecurityConfigAdapter.class,
        TestAuthConfiguration.class,
        BulkManagementController.class,
        ca.bnc.wealth.common.exception.handler.ServiceExceptionHandler.class,
        ca.bnc.wealth.common.spring.microservice.starter.core.exception.GlobalDefaultExceptionHandler
            .class
    })
public class BulkManagementControllerTest {
  @Autowired
  private WebApplicationContext webApplicationContext;

  @Autowired
  private MockMvc mockMvc;

  @MockitoBean
  private UploadService uploadService;

  @MockitoBean
  private TriggerBulkProcessService triggerBulkProcessService;

  @MockitoBean
  private BulkStatusService bulkStatusService;

  @MockitoBean
  private BulkTemplateService bulkTemplateService;

  @MockitoBean
  private TriggerExportProcessService triggerExportProcessService;

  @MockitoBean
  private BulkValidationService bulkValidationService;

  @Autowired
  ObjectMapper objectMapper;

  @Before
  public void setup() {
    mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext)
        .apply(springSecurity()).build();
  }

  @Test
  public void getTemplateTest() throws Exception {
    Pair<String, ByteArrayResource> pair = Pair.of("1", new ByteArrayResource(new byte[]{}));
    doReturn(pair).when(bulkTemplateService).getTemplateByTemplateName(any());
    MvcResult mvcResult = mockMvc
        .perform(get("/templates/{template-format}", "template")
            .header(HttpHeaders.AUTHORIZATION, ""))
        .andExpect(status().isOk())
        .andReturn();

    assertEquals("text/csv", mvcResult.getResponse().getContentType());
  }

  @Test
  public void uploadFile() throws Exception {
    BulkUpload bulkUpload = new BulkUpload();
    bulkUpload.setBatchID("id");
    doReturn(bulkUpload).when(uploadService).validateAndUpload(any(), any(),any(), any());
    MockMultipartHttpServletRequestBuilder multipart =
        (MockMultipartHttpServletRequestBuilder)
            multipart("/files/{template-format}?firmId={firmId}", "USER-TEMPLATE", "NBIN")
                .with(
                    request -> {
                      request.setMethod(HttpMethod.POST.name());
                      return request;
                    });

    MockMultipartFile file =
        new MockMultipartFile(
            "file",
            "audit-input.json",
            MediaType.APPLICATION_JSON_VALUE,
            "{ \"key\": \"value\" }".getBytes());
    MvcResult mvcResult =
        mockMvc
            .perform(multipart.file(file).header(HttpHeaders.AUTHORIZATION, "").with(csrf()))
            .andExpect(status().isOk())
            .andReturn();



    assertEquals(bulkUpload.getBatchID(), mvcResult.getResponse().getContentAsString());
  }

  @Test
  public void uploadFile_whenFumValidationError_shouldReturn400() throws Exception {
    BulkUpload bulkUpload = new BulkUpload();
    bulkUpload.setBatchID("id");
    doThrow(new FumValidationException("", "")).when(uploadService).validateAndUpload(any(), any(),any(), any());
    MockMultipartHttpServletRequestBuilder multipart =
        (MockMultipartHttpServletRequestBuilder)
            multipart("/files/{template-format}?firmId={firmId}", "USER-TEMPLATE", "NBIN")
                .with(
                    request -> {
                      request.setMethod(HttpMethod.POST.name());
                      return request;
                    });

    MockMultipartFile file =
        new MockMultipartFile(
            "file",
            "audit-input.json",
            MediaType.APPLICATION_JSON_VALUE,
            "{ \"key\": \"value\" }".getBytes());
    MvcResult mvcResult =
        mockMvc
            .perform(multipart.file(file).header(HttpHeaders.AUTHORIZATION, "").with(csrf()))
            .andExpect(status().is4xxClientError())
            .andReturn();
  }

  @Test
  public void triggerBulkProcessTest() throws Exception {
    MvcResult mvcResult = mockMvc
        .perform(post("/batches/trigger/{batch-id}?firmId={firmId}", "id", "NBIN")
            .header(HttpHeaders.AUTHORIZATION, "").with(csrf())
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andReturn();
  }

  @Test
  public void testBatchesSearch() throws Exception {
    BatchesSearchRequest bulkUploadRecordRequest = new BatchesSearchRequest();
    bulkUploadRecordRequest.setBatchType("UPLOAD");
    bulkUploadRecordRequest.setTemplateNames(Arrays.asList("template1", "template2"));

    mockMvc
        .perform(post("/batches/search")
            .header(HttpHeaders.AUTHORIZATION, "").with(csrf())
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(bulkUploadRecordRequest)))
        .andExpect(status().isOk());
  }

  @Test
  public void getBatchStatusByBatchIdTest() throws Exception {
    doReturn(new BatchStatus()).when(bulkStatusService).getBatchStatusByBatchId(any(), anyBoolean());
    MvcResult mvcResult = mockMvc
        .perform(get("/batches/{batch-id}/status", "123")
            .header(HttpHeaders.AUTHORIZATION, ""))
        .andExpect(status().isOk())
        .andReturn();
  }

  @Test
  public void getUploadedFileByBatchIdTest() throws Exception {
    Pair<String, ByteArrayResource> pair = Pair.of("1", new ByteArrayResource(new byte[]{}));
    doReturn(pair).when(uploadService).getUploadedFile(any(), any());
    MvcResult mvcResult = mockMvc
        .perform(get("/batches/{batch-id}/file", "123")
            .header(HttpHeaders.AUTHORIZATION, ""))
        .andExpect(status().isOk())
        .andReturn();
  }

  @Test
  public void getResultsFileByBatchIdTest() throws Exception {
    Pair<String, ByteArrayResource> pair = Pair.of("1", new ByteArrayResource(new byte[]{}));
    doReturn(pair).when(uploadService).getResultsFileByBatchId(any(), any());
    MvcResult mvcResult = mockMvc
        .perform(get("/batches/{batch-id}/results", "123")
            .header(HttpHeaders.AUTHORIZATION, ""))
        .andExpect(status().isOk())
        .andReturn();
  }

  @Test
  public void triggerExportProcessTest() throws Exception {
    doReturn(new BulkUpload()).when(uploadService).createBulkUploadExport(any(), any());

    mockMvc
        .perform(post("/batches/trigger/export/{template-name}", "template")
            .header(HttpHeaders.AUTHORIZATION, "").with(csrf())
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(new ExportRequest())))
        .andExpect(status().isOk());
  }

}
