package ca.bnc.wealth.api.bulk.management.schedule;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.List;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import ca.bnc.wealth.api.bulk.management.service.BulkStatusService;
import ca.bnc.wealth.api.bulk.management.utils.MockData;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import ca.bnc.wealth.common.jpa.service.IamScheduleService;
import lombok.SneakyThrows;

@RunWith(SpringRunner.class)
public class BulkActionStatusCheckServiceTest {

  @MockitoBean
  private BulkUploadRepository bulkUploadRepository;

  @MockitoBean
  private IamScheduleService scheduleService;
  
  @MockitoBean
  private BulkStatusService bulkStatusService;

  private BulkActionStatusCheckService bulkActionStatusCheckService;

  @SneakyThrows
  @Before
  public void setup() {
    bulkActionStatusCheckService = new BulkActionStatusCheckService(
        bulkUploadRepository,
        scheduleService,
        bulkStatusService,
        null);
  }

  @Test
  public void testUpdateBulkStatus_whenCannotRunSchedule_shouldNotUpdateBulkStatus() {
    when(scheduleService.canRunSchedule(any(), anyLong(), any())).thenReturn(false);
    bulkActionStatusCheckService.updateBulkStatus();
    verify(scheduleService, never()).updateStatusToFinish(any());
  }

  @Test
  public void testUpdateBulkStatus_whenCanRunSchedule_shouldUpdateBulkStatus() {
    when(scheduleService.canRunSchedule(any(), anyLong(), any())).thenReturn(true);
    when(bulkUploadRepository.findAll(any(Specification.class))).thenReturn(List.of(MockData.getBulkUpload()));
    bulkActionStatusCheckService.updateBulkStatus();
    verify(scheduleService, times(1)).updateStatusToFinish(any());
  }
}
