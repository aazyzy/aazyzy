package ca.bnc.wealth.api.bulk.management.service;

import static org.junit.Assert.assertFalse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class BulkManagementServiceJpaTest {

  @Mock
  private PackageTemplateRepository packageTemplateRepository;

  @Mock
  private PackageTemplateAssignmentResourceRepository packageTemplateAssignmentResourceRepository;

  @Mock
  private ResourceRepository resourceRepository;

  @InjectMocks
  private BulkManagementServiceJpa bulkManagementServiceJpa;

  @Test
  public void testGetPackageTemplatesByPackageType() {
    bulkManagementServiceJpa.getPackageTemplatesByPackageType(PackageType.U);
    verify(packageTemplateRepository, times(1)).findByType(any());
  }

  @Test
  public void testGetResourcesByRestriction() {
    bulkManagementServiceJpa.getResourcesByRestriction(true);
    verify(resourceRepository, times(1)).findByRestriction(any());

  }

  @Test
  public void testGetAssignmentResourcesByAssignmentTypeAndAssignmentModeAndSelectionDefault() {
    bulkManagementServiceJpa.getAssignmentResourcesByAssignmentTypeAndAssignmentModeAndSelectionDefault(
        PackageAssignmentType.S, PackageAssignmentMode.O, false);
    verify(packageTemplateAssignmentResourceRepository, times(1)).findByAssignmentTypeAndAssignmentModeAndSelectionDefault(any(), any(), anyBoolean());
  }

  @Test
  public void testRedisEnabled() {
    assertFalse(bulkManagementServiceJpa.redisCacheEnabled());
  }
}
