package ca.bnc.wealth.api.bulk.management.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.bulk.management.utils.Constants;
import ca.bnc.wealth.api.bulk.management.utils.MockData;
import ca.bnc.wealth.common.bulk_management.model.BatchStatus;
import ca.bnc.wealth.common.bulk_management.model.Response;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadDetails;
import ca.bnc.wealth.common.jpa.repo.iam.AuditRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadDetailsRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import tools.jackson.databind.ObjectMapper;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.jpa.domain.Specification;

@RunWith(MockitoJUnitRunner.Silent.class)
public class BulkStatusServiceTest {

  @Mock
  private BulkUploadRepository bulkUploadRepository;

  @Mock
  private ObjectMapper objectMapper;

  @Mock
  private BulkUploadDetailsRepository bulkUploadDetailsRepository;

  @Mock
  private AuditRepository auditRepository;

  @Mock
  private CsvWriteService csvWriteService;

  @Mock
  private SubscriptionEmitService subscriptionEmitService;

  @InjectMocks
  private BulkStatusService bulkStatusService;

  private BulkUpload bulkUpload;
  private List<BulkUploadDetails> bulkUploadDetailsList;

  @Before
  public void setUp() {
    bulkUpload = new BulkUpload();
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.SUCCESS);
    bulkUpload.setTotalRecords(10);
    bulkUpload.setTotalSuccess(7);
    bulkUpload.setTotalFailed(2);

    bulkUploadDetailsList = new ArrayList<>();
    BulkUploadDetails detail1 = new BulkUploadDetails();
    detail1.setBulkUploadDetailID(1L);
    detail1.setBulkUploadStatus(BulkUploadStatus.SUCCESS);
    detail1.setResponse("{\"id\":\"1\",\"status\":\"SUCCESS\"}".getBytes());
    bulkUploadDetailsList.add(detail1);

    BulkUploadDetails detail2 = new BulkUploadDetails();
    detail2.setBulkUploadDetailID(2L);
    detail2.setBulkUploadStatus(BulkUploadStatus.FAILED);
    detail2.setResponse("{\"id\":\"2\",\"status\":\"FAILED\"}".getBytes());
    bulkUploadDetailsList.add(detail2);

    bulkUpload.setBulkUploadDetails(bulkUploadDetailsList);
  }

  @Test
  public void testGetProcessStatusByBatchId_Success() {
    when(bulkUploadRepository.findByBatchID("batch1")).thenReturn(Optional.of(bulkUpload));

    BatchStatus batchStatus = bulkStatusService.getBatchStatusByBatchId("batch1", true);

    assertEquals(10, batchStatus.getTotalRecords());
    assertEquals(7, batchStatus.getSuccessfullyRecords());
    assertEquals(2, batchStatus.getFailedRecords());
    assertEquals(1, batchStatus.getInProgressRecords());
    assertEquals(2, batchStatus.getDetailedReport().size());
    assertEquals(BulkUploadStatus.SUCCESS.name(), batchStatus.getStatus());
  }

  @Test
  public void testGetProcessStatusByBatchId_NotFound() {
    when(bulkUploadRepository.findByBatchID("batch1")).thenReturn(Optional.empty());

    FumNotFoundException exception = assertThrows(FumNotFoundException.class, () -> {
      bulkStatusService.getBatchStatusByBatchId("batch1", true);
    });

    assertEquals(Constants.BULK_UPLOAD_NOT_FOUND_MESSAGE + "batch1", exception.getMessage());
  }

  @Test
  public void testGetReport() throws Exception {
    Response response1 = new Response();
    response1.setId("1");
    response1.setStatus("SUCCESS");

    Response response2 = new Response();
    response2.setId("2");
    response2.setStatus("FAILED");

    when(objectMapper.readValue(bulkUploadDetailsList.get(0).getResponse(), Response.class)).thenReturn(response1);
    when(objectMapper.readValue(bulkUploadDetailsList.get(1).getResponse(), Response.class)).thenReturn(response2);

    List<Response> responses = bulkStatusService.getReport(bulkUploadDetailsList);

    assertEquals(2, responses.size());
    assertEquals("1", responses.get(0).getId());
    assertEquals("SUCCESS", responses.get(0).getStatus());
    assertEquals("2", responses.get(1).getId());
    assertEquals("FAILED", responses.get(1).getStatus());
  }

  @Test
  public void testCheckAndUpdateStatus_whenBulkUploadProvided_shouldUpdateBulkUploadStatus() {
    when(bulkUploadDetailsRepository.count(any(Specification.class))).thenReturn(1L);
    when(csvWriteService.downloadStatusCsv(any())).thenReturn(Pair.of("filename", new StringWriter()));

    // Bulk upload details success
    BulkUpload bulkUpload = MockData.getBulkUpload();
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
    bulkUpload.setTotalRecords(1);
    when(bulkUploadRepository.findByBatchID(anyString())).thenReturn(Optional.of(bulkUpload));
    bulkStatusService.checkAndUpdateStatus(bulkUpload.getBatchID());
    verify(bulkUploadRepository, times(1)).saveAndFlush(any());

    // Bulk upload details failed
    clearInvocations(bulkUploadRepository);
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
    bulkUpload.setTotalSuccess(null);
    bulkUpload.setTotalFailed(null);
    bulkUpload.setTotalPending(null);
    bulkUpload.setTotalRecords(2);
    when(bulkUploadRepository.findByBatchID(anyString())).thenReturn(Optional.of(bulkUpload));
    bulkStatusService.checkAndUpdateStatus(bulkUpload.getBatchID());
    verify(bulkUploadRepository, times(1)).saveAndFlush(any());

    // Bulk upload details still processing
    clearInvocations(bulkUploadRepository);
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
    bulkUpload.setTotalSuccess(null);
    bulkUpload.setTotalFailed(null);
    bulkUpload.setTotalPending(null);
    bulkUpload.setTotalRecords(3);
    bulkStatusService.checkAndUpdateStatus(bulkUpload.getBatchID());
    verify(bulkUploadRepository, times(1)).saveAndFlush(any());
  }

  @Test
  public void testCheckAndUpdateStatus_whenJsonBulkUploadProvided_shouldUpdateBulkUploadStatus() {
    when(bulkUploadDetailsRepository.count(any(Specification.class))).thenReturn(1L);
    when(csvWriteService.downloadStatusJson(any())).thenReturn(Pair.of("filename", new StringWriter()));

    BulkUpload bulkUpload = MockData.getBulkUpload();
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
    bulkUpload.getBulkUploadTemplate().getConfig().setFileFormat("json");

    // Bulk upload details success
    bulkUpload.setTotalRecords(1);
    when(bulkUploadRepository.findByBatchID(anyString())).thenReturn(Optional.of(bulkUpload));
    bulkStatusService.checkAndUpdateStatus(bulkUpload.getBatchID());
    verify(bulkUploadRepository, times(1)).saveAndFlush(any());
    verify(auditRepository, times(1)).save(any());

    // Bulk upload details failed
    clearInvocations(bulkUploadRepository);
    clearInvocations(auditRepository);
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
    bulkUpload.setTotalSuccess(null);
    bulkUpload.setTotalFailed(null);
    bulkUpload.setTotalPending(null);
    bulkUpload.setTotalRecords(2);
    when(bulkUploadRepository.findByBatchID(anyString())).thenReturn(Optional.of(bulkUpload));
    bulkStatusService.checkAndUpdateStatus(bulkUpload.getBatchID());
    verify(bulkUploadRepository, times(1)).saveAndFlush(any());
    verify(auditRepository, times(1)).save(any());

    // Bulk upload details still processing
    clearInvocations(bulkUploadRepository);
    clearInvocations(auditRepository);
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
    bulkUpload.setTotalSuccess(null);
    bulkUpload.setTotalFailed(null);
    bulkUpload.setTotalPending(null);
    bulkUpload.setTotalRecords(3);
    bulkStatusService.checkAndUpdateStatus(bulkUpload.getBatchID());
    verify(bulkUploadRepository, times(1)).saveAndFlush(any());
    verify(auditRepository, times(0)).save(any());
  }

  @Test
  public void testCheckAndUpdateStatus_whenTextBulkUploadProvided_shouldUpdateBulkUploadStatus() {
    when(bulkUploadDetailsRepository.count(any(Specification.class))).thenReturn(1L);
    when(csvWriteService.downloadStatusJson(any())).thenReturn(Pair.of("filename", new StringWriter()));

    BulkUpload bulkUpload = MockData.getBulkUpload();
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
    bulkUpload.getBulkUploadTemplate().getConfig().setFileFormat("text");

    bulkUpload.setTotalRecords(1);
    when(bulkUploadRepository.findByBatchID(anyString())).thenReturn(Optional.of(bulkUpload));
    bulkStatusService.checkAndUpdateStatus(bulkUpload.getBatchID());
    verify(bulkUploadRepository, times(1)).saveAndFlush(any());
    verify(auditRepository, times(0)).save(any());
  }

  @Test
  public void testCheckAndUpdateStatus_whenNothingChanged_shouldSkipSaveAndEmit() {
    BulkUpload bulkUpload = MockData.getBulkUpload();
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.PROCESSING);
    bulkUpload.setTotalRecords(3);
    bulkUpload.setTotalSuccess(1);
    bulkUpload.setTotalFailed(1);
    bulkUpload.setTotalPending(1);
    bulkUpload.setCreatedDate(Timestamp.valueOf(LocalDateTime.now()));

    when(bulkUploadRepository.findByBatchID(anyString())).thenReturn(Optional.of(bulkUpload));
    // successful=1, failed=1 → still processing, same counts as before
    when(bulkUploadDetailsRepository.count(any(Specification.class))).thenReturn(1L);

    bulkStatusService.checkAndUpdateStatus(bulkUpload.getBatchID());

    verify(bulkUploadRepository, times(0)).saveAndFlush(any());
    verify(subscriptionEmitService, times(0)).emitBulkUploadEvent(any());
  }

  @Test
  public void testCheckAndUpdateStatus_whenTimedOut_shouldMarkAsFailed() {
    BulkUpload bulkUpload = MockData.getBulkUpload();
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.PROCESSING);
    bulkUpload.setTotalRecords(3);
    bulkUpload.setTotalSuccess(0);
    bulkUpload.setTotalFailed(0);
    bulkUpload.setTotalPending(3);
    // Created 25 hours ago — exceeds the 24-hour timeout
    bulkUpload.setCreatedDate(Timestamp.valueOf(LocalDateTime.now().minusHours(25)));

    when(bulkUploadRepository.findByBatchID(anyString())).thenReturn(Optional.of(bulkUpload));
    when(csvWriteService.downloadStatusCsv(any())).thenReturn(Pair.of("filename", new StringWriter()));

    bulkStatusService.checkAndUpdateStatus(bulkUpload.getBatchID());

    assertEquals(BulkUploadStatus.FAILED, bulkUpload.getBulkUploadStatus());
    verify(bulkUploadRepository, times(1)).saveAndFlush(any());
    verify(subscriptionEmitService, times(1)).emitBulkUploadEvent(any());
    // Should NOT query detail counts for timed-out uploads
    verify(bulkUploadDetailsRepository, times(0)).count(any(Specification.class));
  }
}