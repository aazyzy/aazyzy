package ca.bnc.wealth.api.bulk.management.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import java.util.List;
import java.util.regex.Pattern;
import org.apache.logging.log4j.util.Strings;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class BulkTemplateConfigFieldServiceTest {

  @Mock
  private BulkManagementServiceJpa bulkManagementServiceJpa;

  @InjectMocks
  private BulkTemplateConfigFieldService bulkTemplateConfigFieldService;

  @Test
  public void testGetConfigFieldPattern() {
    // When field is null
    Pattern result = bulkTemplateConfigFieldService.getConfigFieldPattern(null);
    assertEquals(Strings.EMPTY, result.pattern());

    // When field is fn:language
    result = bulkTemplateConfigFieldService.getConfigFieldPattern("fn:language");
    assertEquals("^(EN|FR|$)$", result.pattern());

    // When field is fn:defaultModules
    result = bulkTemplateConfigFieldService.getConfigFieldPattern("fn:defaultModules");
    assertEquals("^(compass_r2|firm_client_accounts|users_module|$)$", result.pattern());

    // When field is fn:roles
    PackageTemplate packageTemplate = new PackageTemplate();
    packageTemplate.setName("myPackage");
    when(bulkManagementServiceJpa.getPackageTemplatesByPackageType(any())).thenReturn(List.of(packageTemplate));
    result = bulkTemplateConfigFieldService.getConfigFieldPattern("fn:roles");
    assertEquals("^(myPackage|$)$", result.pattern());

    // When field is fn:boolean
    result = bulkTemplateConfigFieldService.getConfigFieldPattern("fn:boolean");
    assertEquals("^(true|false|$)$", result.pattern());

    // When field is fn:moduleOverrides
    Resource resource = new Resource();
    resource.setName("myResource");
    when(bulkManagementServiceJpa.getResourcesByRestriction(anyBoolean())).thenReturn(List.of(resource));
    result = bulkTemplateConfigFieldService.getConfigFieldPattern("fn:moduleOverrides");
    assertEquals("^(myResource|$)$", result.pattern());

    // When field is fn:features
    PackageTemplateAssignmentResource packageTemplateAssignmentResource = new PackageTemplateAssignmentResource();
    packageTemplateAssignmentResource.setResource(resource);
    when(bulkManagementServiceJpa.getAssignmentResourcesByAssignmentTypeAndAssignmentModeAndSelectionDefault(
        any(), any(), anyBoolean())).thenReturn(List.of(packageTemplateAssignmentResource));
    result = bulkTemplateConfigFieldService.getConfigFieldPattern("fn:features");
    assertEquals("^(myResource|$)$", result.pattern());

    // When field is a pattern
    String pattern = ".*";
    result = bulkTemplateConfigFieldService.getConfigFieldPattern(pattern);
    assertEquals(pattern, result.pattern());
  }
}