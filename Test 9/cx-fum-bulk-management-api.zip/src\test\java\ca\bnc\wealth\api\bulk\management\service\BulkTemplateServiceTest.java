package ca.bnc.wealth.api.bulk.management.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.enums.BatchType;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadTemplateRepository;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.ObjectWriter;
import tools.jackson.databind.SerializationFeature;
import java.util.List;
import java.util.Optional;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.io.ByteArrayResource;

@RunWith(MockitoJUnitRunner.Silent.class)
public class BulkTemplateServiceTest {

  private static final String TEST_TEMPLATE = "testTemplate";

  @Mock
  private BulkUploadTemplateRepository bulkUploadTemplateRepository;

  @Mock
  private ObjectMapper objectMapper;

  @Mock
  private ObjectWriter objectWriter;

  @InjectMocks
  private BulkTemplateService bulkTemplateService;

  private BulkUploadTemplate bulkUploadTemplate;
  private Template template;

  @Before
  public void setUp() {
    template = new Template();
    template.setFileFormat("csv");
    template.setDelimiter(",");
    template.setHeaderNames(List.of("header1", "header2"));

    bulkUploadTemplate = new BulkUploadTemplate();
    bulkUploadTemplate.setTemplateName(TEST_TEMPLATE);
    bulkUploadTemplate.setConfig(template);
  }

  @Test
  public void testGetTemplate_Success() {
    when(bulkUploadTemplateRepository.findByTemplateNameAndBatchType(TEST_TEMPLATE, BatchType.UPLOAD)).thenReturn(Optional.of(bulkUploadTemplate));

    Optional<BulkUploadTemplate> result = bulkTemplateService.getTemplate(TEST_TEMPLATE, BatchType.UPLOAD);

    assertEquals(bulkUploadTemplate, result.get());
  }

  @Test
  public void testGetTemplate_NotFound() {
    when(bulkUploadTemplateRepository.findByTemplateName(TEST_TEMPLATE)).thenReturn(Optional.empty());

    Optional<BulkUploadTemplate> result = bulkTemplateService.getTemplate(TEST_TEMPLATE, BatchType.UPLOAD);

    assertEquals(Optional.empty(), result);
  }

  @Test
  public void testGetTemplateConfig_Success() {
    when(bulkUploadTemplateRepository.findByTemplateNameAndBatchType(TEST_TEMPLATE, BatchType.UPLOAD)).thenReturn(Optional.of(bulkUploadTemplate));

    Template result = bulkTemplateService.getTemplateConfig(TEST_TEMPLATE);

    assertEquals(template, result);
  }

  @Test
  public void testGetTemplateConfig_NotFound() {
    when(bulkUploadTemplateRepository.findByTemplateName(TEST_TEMPLATE)).thenReturn(Optional.empty());

    FumNotFoundException exception = assertThrows(FumNotFoundException.class, () -> {
      bulkTemplateService.getTemplateConfig(TEST_TEMPLATE);
    });

    assertEquals("Template not found", exception.getMessage());
  }

  @Test
  public void testGetTemplateByTemplateName_CsvFormat() {
    when(bulkUploadTemplateRepository.findByTemplateNameAndBatchType(TEST_TEMPLATE, BatchType.UPLOAD)).thenReturn(Optional.of(bulkUploadTemplate));

    Pair<String, ByteArrayResource> result = bulkTemplateService.getTemplateByTemplateName(
        TEST_TEMPLATE);

    assertEquals("testTemplate.csv", result.getLeft());
    assertEquals("header1,header2", new String(result.getRight().getByteArray()));
  }

  @Test
  public void testGetTemplateByTemplateName_JsonFormat() throws Exception {
    template.setFileFormat("json");
    when(bulkUploadTemplateRepository.findByTemplateNameAndBatchType(TEST_TEMPLATE, BatchType.UPLOAD)).thenReturn(Optional.of(bulkUploadTemplate));

    String jsonResponse = "[{\"targetUrl\":\"http://localhost:8080\",\"httpMethod\":\"POST\",\"payload\":\"<json payload>\",\"hasResponse\":false}]";

    when(objectMapper.writerWithDefaultPrettyPrinter()).thenReturn(objectWriter);
    when(objectWriter.without(SerializationFeature.FAIL_ON_EMPTY_BEANS)).thenReturn(objectWriter);
    when(objectWriter.writeValueAsString(any())).thenReturn(jsonResponse);
    Pair<String, ByteArrayResource> result = bulkTemplateService.getTemplateByTemplateName(
        TEST_TEMPLATE);

    assertEquals("testTemplate.json", result.getLeft());
    assertEquals(jsonResponse, new String(result.getRight().getByteArray()));
  }

  @Test
  public void testGetTemplateByTemplateName_TemplateNotFound() {
    when(bulkUploadTemplateRepository.findByTemplateName(TEST_TEMPLATE)).thenReturn(Optional.empty());

    FumNotFoundException exception = assertThrows(FumNotFoundException.class, () -> {
      bulkTemplateService.getTemplateByTemplateName(TEST_TEMPLATE);
    });

    assertEquals("Template rules not found for template name: " + TEST_TEMPLATE, exception.getMessage());
  }

  @Test
  public void testGetTemplateByTemplateName_FormatNotFound() {
    String fileFormat = "xml";
    template.setFileFormat(fileFormat);
    when(bulkUploadTemplateRepository.findByTemplateNameAndBatchType(TEST_TEMPLATE, BatchType.UPLOAD)).thenReturn(Optional.of(bulkUploadTemplate));

    FumValidationException exception = assertThrows(FumValidationException.class, () -> {
      bulkTemplateService.getTemplateByTemplateName(TEST_TEMPLATE);
    });

    assertEquals(String.format("Template format not supported: %s", fileFormat), exception.getMessage());
  }
}