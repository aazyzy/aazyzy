package ca.bnc.wealth.api.bulk.management.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.bulk.management.model.JsonPayLoad;
import ca.bnc.wealth.api.bulk.management.utils.Constants;
import ca.bnc.wealth.common.bulk_management.model.BatchesSearchRequest;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import ca.bnc.wealth.common.jpa.entity.jsonb.TemplateField;
import ca.bnc.wealth.common.jpa.entity.jsonb.TemplateFieldConfig;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

@RunWith(MockitoJUnitRunner.class)
public class BulkValidationServiceTest {

  @Spy
  private ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().build();

  @Mock
  private BulkTemplateConfigFieldService bulkTemplateConfigFieldService;

  @InjectMocks
  private BulkValidationService bulkValidationService;

  private Template template;

  @Before
  public void setUp() {
    template = new Template();
    template.setFileFormat("csv");
    template.setDelimiter(",");
    template.setHeaderNames(List.of("header1", "header2"));
    template.setFileSize(1024L); // 1 KB

    List<TemplateField> fields = new ArrayList<>();

    TemplateFieldConfig fieldConfig1 = new TemplateFieldConfig();
    fieldConfig1.setHeaderName("header1");
    fieldConfig1.setMandatory(true);
    fieldConfig1.setPattern("^[a-zA-Z0-9]+$");

    TemplateField field1 = new TemplateField();
    field1.setFieldName("field1");
    field1.setConfig(fieldConfig1);
    fields.add(field1);

    TemplateFieldConfig fieldConfig2 = new TemplateFieldConfig();
    fieldConfig2.setHeaderName("header2");
    fieldConfig2.setMandatory(false);
    fieldConfig2.setPattern(".*");

    TemplateField field2 = new TemplateField();
    field2.setFieldName("field2");
    field2.setConfig(fieldConfig2);
    fields.add(field2);

    template.setFields(fields);
  }

  @Test
  public void testValidateFile_Success() throws Exception {
    String content = "header1,header2\nvalue1,value2";
    InputStream inputStream = IOUtils.toInputStream(content, StandardCharsets.UTF_8);
    MultipartFile multipartFile = new MockMultipartFile("file", "test.csv", "text/csv", inputStream);

    Optional<String> result = bulkValidationService.validateFile(multipartFile, template);

    assertTrue(result.isEmpty());
  }

  @Test
  public void testValidateFile_ExceedsFileSize() throws Exception {
    template.setFileSize(10L); // 10 bytes
    String content = "header1,header2\nvalue1,value2";
    InputStream inputStream = IOUtils.toInputStream(content, StandardCharsets.UTF_8);
    MultipartFile multipartFile = new MockMultipartFile("file", "test.csv", "text/csv", inputStream);

    Optional<String> result = bulkValidationService.validateFile(multipartFile, template);

    assertEquals("File exceeds limit of 10 bytes.", result.get());
  }

  @Test
  public void testValidateFile_IncorrectFileFormat() throws Exception {
    String content = "header1,header2\nvalue1,value2";
    InputStream inputStream = IOUtils.toInputStream(content, StandardCharsets.UTF_8);
    MultipartFile multipartFile = new MockMultipartFile("file", "test.txt", "text/plain", inputStream);

    Optional<String> result = bulkValidationService.validateFile(multipartFile, template);

    assertEquals("Incorrect File format (csv files only).", result.get());
  }

  @Test
  public void testValidateFile_InvalidDelimiter() throws Exception {
    String content = "header1;header2\nvalue1;value2";
    InputStream inputStream = IOUtils.toInputStream(content, StandardCharsets.UTF_8);
    MultipartFile multipartFile = new MockMultipartFile("file", "test.csv", "text/csv", inputStream);

    Optional<String> result = bulkValidationService.validateFile(multipartFile, template);

    assertEquals("Required Header missing or Invalid delimiter", result.get());
  }

  @Test
  public void testValidateFile_UnsupportedFileFormat() throws Exception {
    template.setFileFormat("xml");
    String content = "<root><header1>value1</header1><header2>value2</header2></root>";
    InputStream inputStream = IOUtils.toInputStream(content, StandardCharsets.UTF_8);
    MultipartFile multipartFile = new MockMultipartFile("file", "test.xml", "application/xml", inputStream);

    Optional<String> result = bulkValidationService.validateFile(multipartFile, template);

    assertEquals("Unsupported file format", result.get());
  }

  @Test
  public void testValidateFile_NullTemplate() {
    String content = "header1,header2\nvalue1,value2";
    MultipartFile multipartFile = new MockMultipartFile("file", "test.csv", "text/csv", content.getBytes());

    Optional<String> result = bulkValidationService.validateFile(multipartFile, null);

    assertEquals("Error loading rules", result.get());
  }

  @Test
  public void testValidateFileJson_Success() {
    template.setFileFormat("json");
    String content = """
       [{
       "targetUrl" : "http://localhost:8082/user-conf/testJsonPost",
       "httpMethod" : "POST",
       "requiresCallback": true
       }]
       """;
    MultipartFile multipartFile = new MockMultipartFile("file", "test.json", "application/json", content.getBytes());

    Optional<String> result = bulkValidationService.validateFile(multipartFile, template);

    assertTrue(result.isEmpty());
  }

  @Test
  public void testValidateFileJson_InvalidJson() {
    template.setFileFormat("json");
    String content = """
       [{ "invalid" }]
       """;
    MultipartFile multipartFile = new MockMultipartFile("file", "test.json", "application/json", content.getBytes());

    Optional<String> result = bulkValidationService.validateFile(multipartFile, template);

    assertEquals("Invalid JSON format", result.get());
  }

  @Test
  public void testValidateFileJson_InvalidHttpMethod() {
    template.setFileFormat("json");
    String content = """
       [{
       "targetUrl" : "http://localhost:8082/user-conf/testJsonPost",
       "httpMethod" : "POST11111",
       "requiresCallback": true
       }]
       """;
    MultipartFile multipartFile = new MockMultipartFile("file", "test.json", "application/json", content.getBytes());

    Optional<String> result = bulkValidationService.validateFile(multipartFile, template);

    assertEquals("Invalid Http Method", result.get());
  }

  @Test
  public void testValidation_Success() {
    List<Map<String, String>> parsedFileContents = new ArrayList<>();
    Map<String, String> row1 = new HashMap<>();
    row1.put("header1", "value1");
    row1.put("header2", "value2");
    row1.put(Constants.ROW_NUMBER, "1");
    parsedFileContents.add(row1);

    when(bulkTemplateConfigFieldService.getConfigFieldPattern(any())).thenReturn(Pattern.compile(".*"));
    Map<String, List<Long>> result = bulkValidationService.validation(parsedFileContents, template);

    assertEquals(0, result.size());
  }

  @Test
  public void testValidation_MandatoryFieldMissing() {
    List<Map<String, String>> parsedFileContents = new ArrayList<>();
    Map<String, String> row1 = new HashMap<>();
    row1.put("header2", "value2");
    row1.put(Constants.ROW_NUMBER, "1");
    parsedFileContents.add(row1);

    when(bulkTemplateConfigFieldService.getConfigFieldPattern(any())).thenReturn(Pattern.compile(".*"));
    Map<String, List<Long>> result = bulkValidationService.validation(parsedFileContents, template);

    assertEquals(1, result.size());
    assertEquals(List.of(1L), result.get("Mandatory_Field header1"));
  }

  @Test
  public void testValidation_InvalidPattern() {
    List<Map<String, String>> parsedFileContents = new ArrayList<>();
    Map<String, String> row1 = new HashMap<>();
    row1.put("header1", null);
    row1.put("header2", "123");
    row1.put(Constants.ROW_NUMBER, "1");
    parsedFileContents.add(row1);

    when(bulkTemplateConfigFieldService.getConfigFieldPattern(any())).thenReturn(Pattern.compile(".*"));
    Map<String, List<Long>> result = bulkValidationService.validation(parsedFileContents, template);

    assertEquals(1, result.size());
  }

  @Test
  public void testValidateJsonPayload() {
    assertEquals("Payload is missing or empty", bulkValidationService.validateJsonPayload(null));

    JsonPayLoad jsonPayLoad = new JsonPayLoad();
    jsonPayLoad.setRequiresCallback(true);
    assertEquals("Target Url is missing", bulkValidationService.validateJsonPayload(jsonPayLoad));

    jsonPayLoad.setTargetUrl("http://localhost:8082/user-conf/testJsonPost");
    assertEquals("Http Method is missing", bulkValidationService.validateJsonPayload(jsonPayLoad));

    jsonPayLoad.setHttpMethod("invalid");
    assertEquals("Invalid Http Method", bulkValidationService.validateJsonPayload(jsonPayLoad));

    jsonPayLoad.setHttpMethod("POST");
    assertNull(bulkValidationService.validateJsonPayload(jsonPayLoad));
  }

  @Test
  public void testValidateBulkUploadRecordRequest_whenValidRequest_shouldNotThrowException() {
    BatchesSearchRequest request = new BatchesSearchRequest();
    request.setBatchType("UPLOAD");
    request.setTemplateNames(new ArrayList<>());
    try {
      bulkValidationService.validateBulkUploadRecordRequest(request);
    } catch (Exception e) {
      fail("Exception should not be thrown for valid request");
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateBulkUploadRecordRequest_whenMissingBatchTypeRequest_shouldThrowException() {
    BatchesSearchRequest request = new BatchesSearchRequest();
    request.setBatchType(null);
    request.setTemplateNames(new ArrayList<>());
    bulkValidationService.validateBulkUploadRecordRequest(request);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateBulkUploadRecordRequest_whenMissingTemplateNamesRequest_shouldThrowException() {
    BatchesSearchRequest request = new BatchesSearchRequest();
    request.setBatchType("UPLOAD");
    request.setTemplateNames(null);
    bulkValidationService.validateBulkUploadRecordRequest(request);
  }
}