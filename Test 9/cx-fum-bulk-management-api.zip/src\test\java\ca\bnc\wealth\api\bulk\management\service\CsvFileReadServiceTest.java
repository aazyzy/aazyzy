package ca.bnc.wealth.api.bulk.management.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import ca.bnc.wealth.common.jpa.entity.jsonb.TemplateField;
import ca.bnc.wealth.common.jpa.entity.jsonb.TemplateFieldConfig;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

@ExtendWith(MockitoExtension.class)
class CsvFileReadServiceTest {

  @InjectMocks
  private CsvFileReadService csvFileReadService;

  private Template template;
  private MultipartFile csvFile;

  @BeforeEach
  public void setUp() {
    template = new Template();
    template.setDelimiter(",");

    TemplateFieldConfig fieldConfig1 = new TemplateFieldConfig();
    fieldConfig1.setHeaderName("header1");

    TemplateField field1 = new TemplateField();
    field1.setFieldName("field1");
    field1.setConfig(fieldConfig1);

    TemplateFieldConfig fieldConfig2 = new TemplateFieldConfig();
    fieldConfig2.setHeaderName("header2");

    TemplateField field2 = new TemplateField();
    field2.setFieldName("field2");
    field2.setConfig(fieldConfig2);

    template.setFields(List.of(field1, field2));

    String csvContent = "header1,header2\nvalue1,value2";
    csvFile = new MockMultipartFile("file", "test.csv", "text/csv", csvContent.getBytes(StandardCharsets.UTF_8));
  }

  @Test
  void testConvertCsvFileToMap_Success() throws Exception {
    List<Map<String, String>> result = csvFileReadService.convertCsvFileToMap(csvFile, template);

    assertEquals(1, result.size());
    assertEquals("value1", result.get(0).get("header1"));
    assertEquals("value2", result.get(0).get("header2"));
  }


  @Test
  void testConvertCsvFileToMap_InvalidTemplate() {
    IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
      csvFileReadService.convertCsvFileToMap(csvFile, null);
    });

    assertEquals("Template is not found.", exception.getMessage());
  }
}