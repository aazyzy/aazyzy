package ca.bnc.wealth.api.bulk.management.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import ca.bnc.wealth.api.bulk.management.utils.Constants;
import ca.bnc.wealth.api.bulk.management.utils.MockData;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import java.io.StringWriter;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class CsvWriteServiceTest {

  private CsvWriteService csvWriteService;
  @Spy
  private ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().build();

  @Before
  public void init() throws IllegalAccessException {
    csvWriteService = new CsvWriteService();
    FieldUtils.writeField(csvWriteService, "objectMapper",
        objectMapper, true);

  }

  @Test
  public void getCreateUserErrorMessage() {
    String response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_OKTA_PROFILE);
    assertEquals("User id already exists in Okta", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_INVALID_FIRM_ID);
    assertEquals("Invalid Firm ID", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_R2_PW);
    assertEquals("R2 password encryption is outdated", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_R2_FOUND);
    assertEquals("R2 ID is linked with another CX user", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_EMAIL_INVALID);
    assertEquals("Invalid email address", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_OKTA_CREATE);
    assertEquals("Okta user creation failed", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_R2_NOT_FOUND);
    assertEquals("R2 ID does not exist", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_RR_CODE_INVALID);
    assertEquals("Invalid RR Code", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_SSO_EXIST);
    assertEquals("New Compass User Id exists already", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.PACKAGE_TEMPLATE_NAME);
    assertEquals("Create User Failed", response);

  }


  @Test
  public void testDownloadStatusCsv_whenBulkStatusSuccess_shouldUseBulkUploadDetailsResponse() {
    BulkUpload bulkUpload = MockData.getBulkUpload();
    Pair<String, StringWriter> pair = csvWriteService.downloadStatusCsv(bulkUpload);
    assertEquals(bulkUpload.getAudit().getFileName() + "_Status.csv", pair.getKey());
    assertTrue(pair.getValue().toString().contains("SUCCESS"));
  }

  @Test
  public void testDownloadStatusCsv_whenBulkStatusFailed_shouldUseBulkUploadDetailsRequest() {
    BulkUpload bulkUpload = MockData.getBulkUpload();
    bulkUpload.getBulkUploadDetails().get(0).setBulkUploadStatus(BulkUploadStatus.FAILED);
    Pair<String, StringWriter> pair  = csvWriteService.downloadStatusCsv(bulkUpload);
    assertEquals(bulkUpload.getAudit().getFileName() + "_Status.csv",  pair.getKey());
    assertTrue( pair.getValue().toString().contains("FAILED"));
  }

  @Test
  public void testDownloadStatusJson_whenBulkStatusSuccess_shouldUseBulkUploadDetailsResponse() {
    BulkUpload bulkUpload = MockData.getBulkUpload();
    bulkUpload.getBulkUploadTemplate().getConfig().setFileFormat("json");
    Pair<String, StringWriter> pair = csvWriteService.downloadStatusJson(bulkUpload);
    assertEquals(bulkUpload.getAudit().getFileName() + "_Status.csv", pair.getKey());
    assertTrue(pair.getValue().toString().contains("SUCCESS"));
  }

  @Test
  public void testDownloadStatusJson_whenBulkStatusFailed_shouldUseBulkUploadDetailsRequest() {
    BulkUpload bulkUpload = MockData.getBulkUpload();
    bulkUpload.getBulkUploadTemplate().getConfig().setFileFormat("json");
    bulkUpload.getBulkUploadDetails().get(0).setBulkUploadStatus(BulkUploadStatus.FAILED);
    Pair<String, StringWriter> pair  = csvWriteService.downloadStatusJson(bulkUpload);
    assertEquals(bulkUpload.getAudit().getFileName() + "_Status.csv",  pair.getKey());
    assertTrue( pair.getValue().toString().contains("FAILED"));
  }
}
