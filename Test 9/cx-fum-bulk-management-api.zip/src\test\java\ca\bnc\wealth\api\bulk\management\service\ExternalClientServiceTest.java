package ca.bnc.wealth.api.bulk.management.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.*;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.common.ciam.feign.client.GetOktaUserProfileClient;
import ca.bnc.wealth.common.ciam.model.OktaAccessProfile;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.ciam.security.CiamSystemToken;
import ca.bnc.wealth.common.r2.feign.client.CxUserProfileClient;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;


public class ExternalClientServiceTest {

  @Mock
  private SystemTokenFactory systemTokenFactory;

  @Mock
  private CxUserProfileClient cxUserProfileClient;

  @Mock
  private CiamSystemToken ciamSystemToken;

  @Mock
  private GetOktaUserProfileClient userOktaProfileClient;

  @InjectMocks
  private ExternalClientService externalClientService;

  @BeforeEach
  public void setUp() {
    org.mockito.MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testGetCompassR2_Success() {
    String idpSubject = "testIdpSubject";
    String token = "testToken";
    String businessViewId = "testBusinessViewId";
    String responseBody = "testResponse";

    when(systemTokenFactory.getBearerToken("r2")).thenReturn(token);
    when(cxUserProfileClient.getR2UserProfile(any(), any(), any()))
        .thenReturn(ResponseEntity.ok(responseBody));

    Pair<HttpStatusCode, String> result = externalClientService.getCxUserProfile(idpSubject);

    assertEquals(HttpStatusCode.valueOf(200), result.getKey());
    assertEquals(responseBody, result.getValue());
  }

  @Test
  public void testGetCompassR2_Failure() {
    String idpSubject = "testIdpSubject";

    when(systemTokenFactory.getBearerToken("r2")).thenThrow(new RuntimeException("Error"));

    Pair<HttpStatusCode, String> result = externalClientService.getCxUserProfile(idpSubject);

    assertNull(result);
  }

  @Test
  public void testGetSecureZoneId_Success() {
    String idpUserId = "testUserId";
    OktaUserProfile oktaUserProfile = new OktaUserProfile();
    OktaAccessProfile accessProfile = new OktaAccessProfile();
    accessProfile.setBngfSecureZoneId(new String[]{"zone1", "zone2"});
    oktaUserProfile.setAccessProfile(accessProfile);

    when(ciamSystemToken.getBearerToken()).thenReturn("testToken");
    when(userOktaProfileClient.getOktaUserProfile(any(), any(), any()))
        .thenReturn(oktaUserProfile);

    String result = externalClientService.getSecureZoneId(idpUserId);

    assertEquals("zone1,zone2", result);
  }

  @Test
  public void testGetSecureZoneId_NoAccessProfile() {
    String idpUserId = "testUserId";
    OktaUserProfile oktaUserProfile = new OktaUserProfile();

    when(ciamSystemToken.getBearerToken()).thenReturn("testToken");
    when(userOktaProfileClient.getOktaUserProfile("testToken", "testContext", idpUserId))
        .thenReturn(oktaUserProfile);

    String result = externalClientService.getSecureZoneId(idpUserId);

    assertEquals("", result);
  }

  @Test
  public void testGetOktaUserProfile_Success() {
    String idpUserId = "testUserId";
    OktaUserProfile oktaUserProfile = new OktaUserProfile();

    when(ciamSystemToken.getBearerToken()).thenReturn("testToken");
    when(userOktaProfileClient.getOktaUserProfile(any(), any(), any()))
        .thenReturn(oktaUserProfile);

    OktaUserProfile result = externalClientService.getOktaUserProfile(idpUserId);

    assertEquals(oktaUserProfile, result);
  }

  @Test
  public void testGetOktaUserProfile_Failure() {
    String idpUserId = "testUserId";

    when(ciamSystemToken.getBearerToken()).thenReturn("testToken");
    when(userOktaProfileClient.getOktaUserProfile(any(), any(), any()))
        .thenThrow(new RuntimeException("Error"));

    OktaUserProfile result = externalClientService.getOktaUserProfile(idpUserId);

    assertNull(result);
  }
}