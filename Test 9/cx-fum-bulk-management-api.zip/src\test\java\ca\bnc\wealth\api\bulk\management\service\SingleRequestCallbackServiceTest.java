package ca.bnc.wealth.api.bulk.management.service;


import ca.bnc.wealth.api.bulk.management.kafka.SingleRequestPublisher;
import ca.bnc.wealth.common.bulk_management.model.Response;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadDetailsRepository;
import tools.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SingleRequestCallbackServiceTest {

  @InjectMocks
  SingleRequestCallbackService service;

  @Mock
  BulkUploadDetailsRepository bulkUploadDetailsRepository;

  @Mock
  SingleRequestPublisher singleRequestPublisher;

  @Mock
  ObjectMapper objectMapper;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    ReflectionTestUtils.setField(service, "waitTime", 1); // speed up tests
  }

  @Test
  void testCanRunSingleRequestsOrElsePublish_CanRunTrue() {
    List<Long> ids = List.of(1L);
    SingleRequestCallbackService spyService = spy(service);
    doReturn(true).when(spyService).canRunSingleRequests(ids);

    boolean result = spyService.canRunSingleRequestsOrElsePublish(ids);
    assertTrue(result);
    verify(spyService, never()).waitBeforePublish();
    verify(singleRequestPublisher, never()).publishMessage(anyList());
  }

  @Test
  void testCanRunSingleRequestsOrElsePublish_CanRunFalse() {
    List<Long> ids = List.of(1L);
    SingleRequestCallbackService spyService = spy(service);
    doReturn(false).when(spyService).canRunSingleRequests(ids);

    boolean result = spyService.canRunSingleRequestsOrElsePublish(ids);
    assertFalse(result);
    verify(spyService, times(1)).waitBeforePublish();
    verify(singleRequestPublisher, times(1)).publishMessage(anyList());
  }

  @Test
  void testGetInt_ValidAndInvalid() {
    assertEquals(5, service.getInt("5"));
    assertEquals(0, service.getInt("notanint"));
  }

  @Test
  void testErrorResponse() {
    Response response = service.errorResponse("123", "error");
    assertEquals("123", response.getId());
    assertEquals("error", response.getErrorMessage());
    assertEquals(BulkUploadStatus.FAILED.name(), response.getStatus());
  }
}