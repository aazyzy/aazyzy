package ca.bnc.wealth.api.bulk.management.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadDetails;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadDetailsRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestClient;

@ExtendWith(MockitoExtension.class)
class SingleRequestServiceTest {

  @Mock
  private BulkUploadDetailsRepository bulkUploadDetailsRepository;

  @Mock
  private BulkUploadRepository bulkUploadRepository;

  @Mock
  private SystemTokenFactory systemTokenFactory;

  @Spy
  private ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().build();

  @Mock
  private RestClient restClient;

  @Spy
  @InjectMocks
  private SingleRequestService singleRequestService;

  private BulkUploadDetails bulkUploadDetails;
  private BulkUploadTemplate bulkUploadTemplate;
  private List<BulkUploadDetails> bulkUploadDetailsList;

  @BeforeEach
  public void setUp() {
    bulkUploadTemplate = new BulkUploadTemplate();
    bulkUploadTemplate.setTemplateName("testTemplate");
    bulkUploadTemplate.setConfig(new Template());
    bulkUploadTemplate.getConfig().setFileFormat("json");

    bulkUploadDetails = new BulkUploadDetails();
    bulkUploadDetails.setBulkUploadDetailID(1L);
    bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
    bulkUploadDetails.setRequest("{\"httpMethod\":\"POST\",\"targetUrl\":\"http://localhost:8080\",\"payload\":\"<json payload>\",\"hasResponse\":false}".getBytes(StandardCharsets.UTF_8));
    bulkUploadDetails.setBulkUpload(new BulkUpload());
    bulkUploadDetails.getBulkUpload().setBulkUploadTemplate(bulkUploadTemplate);

    bulkUploadDetailsList = new ArrayList<>();
    bulkUploadDetailsList.add(bulkUploadDetails);
  }

  @SneakyThrows
  @Test
  void testCallAPIAndProcessResponse_success() {
    Map<Long, BulkUploadDetails> detailsMap = Map.of(1L, bulkUploadDetails);
    List<Map<String, String>> requestList = List.of(Map.of("id", "1", "requestedId", "1"));

    doReturn(null).when(singleRequestService).callAPI(any(RequestMethod.class), anyString(), any());

    singleRequestService.callAPIAndProcessResponse(detailsMap, RequestMethod.POST, "http://test", requestList, new BulkUploadTemplate());
    verify(bulkUploadDetailsRepository, times(1)).saveAndFlush(any());
  }
}