package ca.bnc.wealth.api.bulk.management.service;

import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import ca.bnc.wealth.common.bma.service.SubscriptionClientService;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;

@ExtendWith(MockitoExtension.class)
class SubscriptionEmitServiceTest {

  @Mock
  private SubscriptionClientService subscriptionClientService;

  @InjectMocks
  private SubscriptionEmitService subscriptionEmitService;

  private BulkUpload bulkUpload;

  @BeforeEach
  void setUp() {
    ReflectionTestUtils.setField(subscriptionEmitService, "domain", "bulk-upload");

    BulkUploadTemplate template = new BulkUploadTemplate();
    template.setTemplateName("test-template");

    bulkUpload = new BulkUpload();
    bulkUpload.setBatchID("CUU0000000001");
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.UPLOADED);
    bulkUpload.setBulkUploadTemplate(template);
    bulkUpload.setFirmId("FIRM001");
    bulkUpload.setTotalRecords(10);
    bulkUpload.setTotalSuccess(5);
    bulkUpload.setTotalFailed(2);
    bulkUpload.setTotalPending(3);
  }

  @Test
  void emitBulkUploadEvent_shouldCallSubscriptionClientService() {
    subscriptionEmitService.emitBulkUploadEvent(bulkUpload);

    verify(subscriptionClientService).emit(eq("bulk-upload"), anyList());
  }

  @Test
  void emitBulkUploadEvent_shouldNotPropagateException() {
    doThrow(new RuntimeException("Subscription API error"))
        .when(subscriptionClientService).emit(anyString(), anyList());

    // Should not throw
    subscriptionEmitService.emitBulkUploadEvent(bulkUpload);

    verify(subscriptionClientService).emit(eq("bulk-upload"), anyList());
  }

  @Test
  void emitBulkUploadEvent_shouldHandleNullTemplate() {
    bulkUpload.setBulkUploadTemplate(null);

    subscriptionEmitService.emitBulkUploadEvent(bulkUpload);

    verify(subscriptionClientService).emit(eq("bulk-upload"), anyList());
  }

  @Test
  void emitBulkUploadEvent_shouldHandleNullStatus() {
    bulkUpload.setBulkUploadStatus(null);

    subscriptionEmitService.emitBulkUploadEvent(bulkUpload);

    verify(subscriptionClientService).emit(eq("bulk-upload"), anyList());
  }
}
