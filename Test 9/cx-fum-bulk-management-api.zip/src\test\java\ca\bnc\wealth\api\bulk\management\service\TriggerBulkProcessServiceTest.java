package ca.bnc.wealth.api.bulk.management.service;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import ca.bnc.wealth.api.bulk.management.kafka.SingleRequestPublisher;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.Audit;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadDetailsRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import tools.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TriggerBulkProcessServiceTest {

  @Mock
  private BulkUploadRepository bulkUploadRepository;

  @Mock
  private CsvFileReadService csvFileReadService;

  @Mock
  private BulkValidationService bulkValidationService;

  @Mock
  private BulkUploadDetailsRepository bulkUploadDetailsRepository;

  @Mock
  private SingleRequestPublisher singleRequestPublisher;

  @Mock
  private ObjectMapper objectMapper;

  @InjectMocks
  private TriggerBulkProcessService triggerBulkProcessService;

  private BulkUpload bulkUpload;
  private Template template;

  @BeforeEach
  public void setUp() {
    template = new Template();
    template.setFileFormat("csv");
    template.setBatchSize(1);
    template.setFields(new ArrayList<>());

    bulkUpload = new BulkUpload();
    bulkUpload.setBatchID("batch1");
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.UPLOADED);
    bulkUpload.setBulkUploadTemplate(new BulkUploadTemplate());
    bulkUpload.getBulkUploadTemplate().setConfig(template);
    bulkUpload.setAudit(new Audit());
    bulkUpload.getAudit().setFileContents("header1,header2\nvalue1,value2".getBytes(StandardCharsets.UTF_8));
  }


  @Test
  void testTriggerBulkProcess_BulkUploadNotFound() {
    when(bulkUploadRepository.findByBatchID("batch1")).thenReturn(Optional.empty());

    assertThrows(FumNotFoundException.class, () -> {
      triggerBulkProcessService.triggerBulkProcess("batch1", "user1");
    });
  }

}