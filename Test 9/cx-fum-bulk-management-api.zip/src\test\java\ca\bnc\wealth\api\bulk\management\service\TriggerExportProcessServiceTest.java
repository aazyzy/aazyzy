package ca.bnc.wealth.api.bulk.management.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyList;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.anyMap;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.bulk_management.model.ExportRequest;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.fum.service.FirmServiceHelper;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.Audit;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import ca.bnc.wealth.common.jpa.repo.iam.AuditRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class TriggerExportProcessServiceTest {

  @Mock
  private BulkUploadRepository bulkUploadRepository;

  @Mock
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @Mock
  private CsvWriteService csvWriteService;

  @Mock
  private BulkTemplateService bulkTemplateService;

  @Mock
  private AuditRepository auditRepository;

  @Mock
  private ExternalClientService externalClientService;

  @Mock
  private FirmRepository firmRepository;

  @Mock
  private FirmServiceHelper firmServiceHelper;

  @InjectMocks
  private TriggerExportProcessService triggerExportProcessService;

  private BulkUpload bulkUpload;
  private ExportRequest exportRequest;

  @BeforeEach
  public void setUp() {
    org.mockito.MockitoAnnotations.openMocks(this);

    bulkUpload = new BulkUpload();
    bulkUpload.setBatchID("batch1");
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.PROCESSING);
    BulkUploadTemplate template = new BulkUploadTemplate();
    template.setTemplateName("test");
    Template config = new Template();
    config.setFields(new ArrayList<>());
    config.setHeaderNames(new ArrayList<>());
    template.setConfig(config);
    bulkUpload.setBulkUploadTemplate(template);

    exportRequest = new ExportRequest();
    exportRequest.setFirmId(Collections.singletonList("firm1"));
  }

  @Test
  @SneakyThrows
  void testTriggerExportProcess_Success() {
    when(bulkUploadRepository.saveAndFlush(bulkUpload)).thenReturn(bulkUpload);
    Firm firm = new Firm();
    firm.setFirmId("NBIN");
    when(firmServiceHelper.getPrimaryFirm(any(), any())).thenReturn(Optional.of(firm));

    when(namedParameterJdbcTemplate.queryForList(anyString(), any(MapSqlParameterSource.class))).thenReturn(getMockUserList());
    when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), any(Class.class))).thenReturn("subject1|true|abcd|abc|#subject2|false|abc|asdf|");
    when(csvWriteService.getCsvString(anyList(), anyList(), any())).thenReturn("csvContent");
    when(auditRepository.save(any(Audit.class))).thenReturn(new Audit());
    when(bulkTemplateService.getTemplate(any(), any())).thenReturn(Optional.of(bulkUpload.getBulkUploadTemplate()));

    FieldUtils.writeField(triggerExportProcessService, "chunkSize",
        10, true);

    triggerExportProcessService.triggerExportProcess(bulkUpload, exportRequest, "user1");

    assertEquals(BulkUploadStatus.SUCCESS, bulkUpload.getBulkUploadStatus());
    verify(bulkUploadRepository, times(2)).saveAndFlush(bulkUpload);
  }

  @Test
  @SneakyThrows
  void testTriggerExportProcessNonNBIN_Success() {
    when(bulkUploadRepository.saveAndFlush(bulkUpload)).thenReturn(bulkUpload);
    Firm firm = new Firm();
    firm.setFirmId("NBIN-N");
    when(firmServiceHelper.getPrimaryFirm(any(), any())).thenReturn(Optional.of(firm));

    when(namedParameterJdbcTemplate.queryForList(anyString(), any(MapSqlParameterSource.class))).thenReturn(getMockUserList());
    when(namedParameterJdbcTemplate.queryForObject(anyString(), any(MapSqlParameterSource.class), any(Class.class))).thenReturn("subject1|true|abcd|abc|#subject2|false|abc|asdf|");
    when(csvWriteService.getCsvString(anyList(), anyList(), any())).thenReturn("csvContent");
    when(auditRepository.save(any(Audit.class))).thenReturn(new Audit());
    when(bulkTemplateService.getTemplate(any(), any())).thenReturn(Optional.of(bulkUpload.getBulkUploadTemplate()));
    when(firmRepository.getAllFirmsByIdpSubject(anyString())).thenReturn(Collections.singletonList(1l));
    when(firmRepository.findById(anyLong())).thenReturn(Optional.of(firm));

    FieldUtils.writeField(triggerExportProcessService, "chunkSize",
        10, true);

    triggerExportProcessService.triggerExportProcess(bulkUpload, exportRequest, "user1");

    assertEquals(BulkUploadStatus.SUCCESS, bulkUpload.getBulkUploadStatus());
    verify(bulkUploadRepository, times(2)).saveAndFlush(bulkUpload);
  }

  @Test
  void testTriggerExportProcess_Failure() {
    when(bulkUploadRepository.saveAndFlush(bulkUpload)).thenReturn(bulkUpload);
    when(namedParameterJdbcTemplate.queryForList(anyString(), anyMap())).thenThrow(new RuntimeException("Error"));

    triggerExportProcessService.triggerExportProcess(bulkUpload, exportRequest, "user1");

    assertEquals(BulkUploadStatus.FAILED, bulkUpload.getBulkUploadStatus());
    verify(bulkUploadRepository, times(2)).saveAndFlush(bulkUpload);
  }

  @Test
  void testCreateAuditCsv_whenValidPackageTemplate_shouldCreateAudit() {
    Map<String, Map<String, String>> idpSubjectRowMap = new HashMap<>();
    Map<String, String> row = Map.of("header1", "value1");
    idpSubjectRowMap.put("user1", row);

    BulkUploadTemplate template = new BulkUploadTemplate();
    Template config = new Template();
    config.setHeaderNames(List.of("header1"));
    config.setDelimiter(",");
    template.setConfig(config);

    when(bulkTemplateService.getTemplate(any(), any())).thenReturn(Optional.of(template));
    when(csvWriteService.getCsvString(anyList(), anyList(), any())).thenReturn("header1\nvalue1");

    triggerExportProcessService.createAuditCsv("testTemplate", idpSubjectRowMap, new ArrayList<>());
    verify(auditRepository).save(any(Audit.class));
  }

  @Test
  void testCreateAuditCsv_whenPackageTemplateNotFound_shouldThrowFumException() {
    Map<String, Map<String, String>> idpSubjectRowMap = new HashMap<>();
    Map<String, String> row = Map.of("header1", "value1");
    idpSubjectRowMap.put("user1", row);

    List<String> userOrder = new ArrayList<>();

    when(bulkTemplateService.getTemplate(any(), any())).thenReturn(Optional.empty());
    when(csvWriteService.getCsvString(anyList(), anyList(), any())).thenReturn("header1\nvalue1");

    assertThrows(FumServiceException.class, () -> triggerExportProcessService.createAuditCsv("testTemplate", idpSubjectRowMap, userOrder));
  }

  @Test
  void testGetCsvList_whenPackageTemplateNotFound_shouldThrowFumException() {
    List<Map<String, Object>> userList = List.of(new HashMap<>());
    when(bulkTemplateService.getTemplate(any(), any())).thenReturn(Optional.empty());
    assertThrows(FumServiceException.class, () -> triggerExportProcessService.getCsvList(userList, "testTemplate"));
  }

  private List<Map<String, Object>> getMockUserList() {
    Map<String, Object> user1 = new HashMap<>();
    user1.put("IDP_SUBJECT", "subject1");
    user1.put("IDP_USER_ID", "user1");
    user1.put("FIRM_ID", "firm1");
    user1.put("FIRST_NAME", "John");
    user1.put("LAST_NAME", "Doe");
    user1.put("EMAIL", "john.doe@example.com");

    Map<String, Object> user2 = new HashMap<>();
    user2.put("IDP_SUBJECT", "subject2");
    user2.put("IDP_USER_ID", "user2");
    user2.put("FIRM_ID", "firm2");
    user2.put("FIRST_NAME", "Jane");
    user2.put("LAST_NAME", "Smith");
    user2.put("EMAIL", "jane.smith@example.com");

    return Arrays.asList(user1, user2);
  }
}