package ca.bnc.wealth.api.bulk.management.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.bulk.management.utils.Constants;
import ca.bnc.wealth.api.bulk.management.utils.MockData;
import ca.bnc.wealth.common.bulk_management.model.BatchesSearchRequest;
import ca.bnc.wealth.common.bulk_management.model.BatchesSearchRequest.SortOrderEnum;
import ca.bnc.wealth.common.bulk_management.model.BatchesSearchResponse;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.enums.BatchType;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.Audit;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import ca.bnc.wealth.common.jpa.repo.iam.AuditRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserConfigSearchMaterializedViewRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

@ExtendWith(MockitoExtension.class)
class UploadServiceTest {

  @Mock
  private BulkTemplateService bulkTemplateService;

  @Mock
  private BulkValidationService bulkValidationService;

  @Mock
  private BulkUploadRepository bulkUploadRepository;

  @Mock
  private AuditRepository auditRepository;

  @Mock
  private BulkUploadTemplateRepository bulkUploadTemplateRepository;

  @Mock
  private UserConfigSearchMaterializedViewRepository userConfigSearchMaterializedViewRepository;

  @InjectMocks
  private UploadService uploadService;

  private BulkUploadTemplate bulkUploadTemplate;
  private Template templateRules;
  private MultipartFile fileToUpload;

  @BeforeEach
  public void setUp() {
    templateRules = new Template();
    bulkUploadTemplate = new BulkUploadTemplate();
    bulkUploadTemplate.setConfig(templateRules);

    fileToUpload = new MockMultipartFile("file", "test.csv", "text/csv", "header1,header2\nvalue1,value2".getBytes());
  }

  @Test
  void testValidateAndUpload_Success() throws Exception {
    when(bulkTemplateService.getTemplate("templateName", BatchType.UPLOAD)).thenReturn(Optional.of(bulkUploadTemplate));
    when(bulkValidationService.validateFile(fileToUpload, templateRules)).thenReturn(Optional.empty());
    when(auditRepository.save(any(Audit.class))).thenAnswer(invocation -> invocation.getArgument(0));
    when(bulkUploadRepository.saveAndFlush(any(BulkUpload.class))).thenAnswer(invocation -> invocation.getArgument(0));

    BulkUpload result = uploadService.validateAndUpload("templateName", "NBIN",fileToUpload,"requestId");

    assertEquals(BulkUploadStatus.UPLOADED, result.getBulkUploadStatus());
    assertEquals("requestId", result.getCreatedBy());
  }

  @Test
  void testValidateAndUpload_TemplateNotFound() {
    when(bulkTemplateService.getTemplate("templateName", BatchType.UPLOAD)).thenReturn(Optional.empty());

    FumValidationException exception = assertThrows(FumValidationException.class, () -> {
      uploadService.validateAndUpload("templateName", "NBIN", fileToUpload, "requestId");
    });

    assertEquals(Constants.BULK_UPLOAD_TEMPLATE_NOT_FOUND_MESSAGE + "templateName", exception.getMessage());
  }

  @Test
  void testValidateAndUpload_FileValidationError() {
    when(bulkTemplateService.getTemplate("templateName", BatchType.UPLOAD)).thenReturn(Optional.of(bulkUploadTemplate));
    when(bulkValidationService.validateFile(fileToUpload, templateRules)).thenReturn(Optional.of("Validation error"));

    FumValidationException exception = assertThrows(FumValidationException.class, () -> {
      uploadService.validateAndUpload("templateName","NBIN", fileToUpload, "requestId");
    });

    assertEquals("Validation error", exception.getMessage());
  }

  @Test
  void getBulkUploadsByTemplateNamesAndBatchType_ReturnsExpectedResponse() {
    BatchesSearchRequest request = new BatchesSearchRequest();
    request.setTemplateNames(Arrays.asList("template1", "template2"));
    request.setBatchType(BatchType.UPLOAD.name());

    when(bulkUploadRepository.findAll(any(Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl(MockData.getBulkUploadList()));

    BatchesSearchResponse response = uploadService.getBulkUploadsByTemplateNamesAndBatchType(request);

    assertEquals(2, response.getBatches().size());
  }

  @Test
  void getBulkUploadsByTemplateNamesAndBatchType_whenNoTemplateNames_ReturnsExpectedResponse() {
    BatchesSearchRequest request = new BatchesSearchRequest();
    request.setTemplateNames(new ArrayList<>());
    request.setBatchType(BatchType.UPLOAD.name());

    when(bulkUploadRepository.findAll(any(Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl(MockData.getBulkUploadList()));

    BatchesSearchResponse response = uploadService.getBulkUploadsByTemplateNamesAndBatchType(request);

    assertEquals(2, response.getBatches().size());
  }

  @Test
  void getBulkUploadsByTemplateNamesAndBatchType_whenNoTemplatesAndAudit_ReturnsExpectedResponse() {
    BatchesSearchRequest request = new BatchesSearchRequest();
    request.setTemplateNames(new ArrayList<>());
    request.setBatchType(BatchType.UPLOAD.name());
    BulkUpload bulkUpload = MockData.getBulkUploadList().get(0);
    bulkUpload.setAudit(null);
    bulkUpload.setBulkUploadTemplate(null);

    when(bulkUploadRepository.findAll(any(Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl(List.of(bulkUpload)));

    BatchesSearchResponse response = uploadService.getBulkUploadsByTemplateNamesAndBatchType(request);

    assertEquals(1, response.getBatches().size());
  }

  @Test
  void getBulkUploadsByTemplateNamesAndBatchType_EmptyRequest_ReturnsEmptyResponse() {
    BatchesSearchRequest request = new BatchesSearchRequest();
    request.setTemplateNames(Collections.emptyList());
    request.setBatchType(BatchType.UPLOAD.name());

    when(bulkUploadRepository.findAll(any(Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl(Collections.emptyList()));

    BatchesSearchResponse response = uploadService.getBulkUploadsByTemplateNamesAndBatchType(request);

    assertTrue(response.getBatches().isEmpty());
  }

  @Test
  void getBulkUploadsByTemplateNamesAndBatchType_NullRequest_ThrowsException() {
    assertThrows(NullPointerException.class, () -> {
      uploadService.getBulkUploadsByTemplateNamesAndBatchType(null);
    });
  }

  @Test
  void getBulkUploadsByTemplateNamesAndBatchType_searchParamsProvided_shouldReturnPagination() {
    BatchesSearchRequest request = new BatchesSearchRequest();
    request.setTemplateNames(new ArrayList<>());
    request.setBatchType(BatchType.UPLOAD.name());

    request.setPageNumber(1);
    request.setPageSize(10);
    request.setSortBy(List.of("batchID"));
    request.setSortOrder(SortOrderEnum.DESC);

    when(bulkUploadRepository.findAll(any(Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl(MockData.getBulkUploadList()));

    BatchesSearchResponse response = uploadService.getBulkUploadsByTemplateNamesAndBatchType(request);
    assertEquals(2, response.getBatches().size());
    assertEquals(request.getPageNumber(), response.getNumberOfPages());
  }
}