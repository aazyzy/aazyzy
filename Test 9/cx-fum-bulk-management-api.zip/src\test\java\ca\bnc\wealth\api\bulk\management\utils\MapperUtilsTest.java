package ca.bnc.wealth.api.bulk.management.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import ca.bnc.wealth.common.bulk_management.model.BatchesSearchResponse;
import ca.bnc.wealth.common.jpa.entity.enums.BatchType;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Test;

public class MapperUtilsTest {

  @Test(expected = IllegalStateException.class)
  public void testMapperUtilsConstructor() throws Exception {
    Constructor<MapperUtils> constructor = MapperUtils.class.getDeclaredConstructor();
    constructor.setAccessible(true);
    try {
      constructor.newInstance();
    } catch (Exception e) {
      throw (IllegalStateException) e.getCause();
    }
  }

  @Test
  public void testToDto() {
    BulkUpload bulkUpload = MockData.getBulkUpload();
    bulkUpload.getBulkUploadTemplate().setBatchType(BatchType.UPLOAD);

    BatchesSearchResponse response = MapperUtils.toDto(List.of(bulkUpload), new HashMap<>());
    assertFalse(response.getBatches().isEmpty());
    assertEquals(bulkUpload.getBatchID(), response.getBatches().get(0).getBatchId());
    assertEquals(bulkUpload.getBulkUploadTemplate().getBatchType().name(), response.getBatches().get(0).getBatchType());
    assertEquals(bulkUpload.getBulkUploadTemplate().getTemplateName(), response.getBatches().get(0).getTemplateName());
    assertEquals(bulkUpload.getAudit().getFileName(), response.getBatches().get(0).getFileName());
    assertEquals(bulkUpload.getCreatedDate().toString(), response.getBatches().get(0).getCreatedDate());
    assertNull(response.getBatches().get(0).getCreatedBy());
    assertEquals(bulkUpload.getBulkUploadStatus().name(), response.getBatches().get(0).getStatus().getStatus());

    // created date is null
    bulkUpload.setCreatedDate(null);
    response = MapperUtils.toDto(List.of(bulkUpload), new HashMap<>());
    assertNull(response.getBatches().get(0).getCreatedDate());

    // created by is not null and materialized view is empty
    bulkUpload.setCreatedBy("12345");
    response = MapperUtils.toDto(List.of(bulkUpload), new HashMap<>());
    assertNull(response.getBatches().get(0).getCreatedBy());

    // materialized view is not empty
    UserConfigSearchMaterializedView view = new UserConfigSearchMaterializedView();
    view.setFirstName("John");
    view.setLastName("Doe");
    HashMap<String, UserConfigSearchMaterializedView> usersMap = new HashMap<>();
    usersMap.put(bulkUpload.getCreatedBy(), view);
    response = MapperUtils.toDto(List.of(bulkUpload), usersMap);
    assertEquals("John Doe", response.getBatches().get(0).getCreatedBy());

    // batch type is null
    bulkUpload.getBulkUploadTemplate().setBatchType(null);
    response = MapperUtils.toDto(List.of(bulkUpload), usersMap);
    assertNull(response.getBatches().get(0).getBatchType());

    // batch type is EXPORT and generated audit is not null
    bulkUpload.getBulkUploadTemplate().setBatchType(BatchType.EXPORT);
    response = MapperUtils.toDto(List.of(bulkUpload), usersMap);
    assertEquals(bulkUpload.getGeneratedAudit().getFileName(), response.getBatches().get(0).getFileName());

    // batch type is EXPORT and generated audit is null
    bulkUpload.setGeneratedAudit(null);
    response = MapperUtils.toDto(List.of(bulkUpload), usersMap);
    assertNull(response.getBatches().get(0).getFileName());

    // bulk upload status is null
    bulkUpload.setBulkUploadStatus(null);
    response = MapperUtils.toDto(List.of(bulkUpload), usersMap);
    assertNull(response.getBatches().get(0).getStatus().getStatus());
  }

  @Test
  public void testToMap() {
    Map<String, String> response = MapperUtils.getMap("invalid");
    assertNull(response);

    response = MapperUtils.getMap("{\"key1\":\"value1\",\"key2\":\"value2\"}");
    assertNotNull(response);
  }
}
