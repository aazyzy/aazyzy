package ca.bnc.wealth.api.bulk.management.utils;

import ca.bnc.wealth.common.jpa.entity.enums.BatchType;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.Audit;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadDetails;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import ca.bnc.wealth.common.jpa.entity.jsonb.TemplateField;
import ca.bnc.wealth.common.jpa.entity.jsonb.TemplateFieldConfig;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

public class MockData {

  public static BulkUploadTemplate getBulkUploadTemplateEntity() {
    BulkUploadTemplate bulkUploadTemplate = new BulkUploadTemplate();
    bulkUploadTemplate.setBulkUploadTemplateID(123);
    bulkUploadTemplate.setTemplateName("bulkTemplateName");
    bulkUploadTemplate.setConfig(getTemplateEntity());

    return bulkUploadTemplate;
  }

  public static Template getTemplateEntity() {
    TemplateFieldConfig fieldConfig = new TemplateFieldConfig();
    fieldConfig.setHeaderName("header1");
    fieldConfig.setMandatory(true);
    fieldConfig.setPattern(".*");

    TemplateField templateField = new TemplateField();
    templateField.setFieldName("field1");
    templateField.setConfig(fieldConfig);

    Template template = new Template();
    template.setFileFormat("csv");
    template.setFileSize(123);
    template.setFields(List.of(templateField));
    template.setHeaderNames(List.of("header1"));

    return template;
  }


  public static BulkUpload getBulkUpload() {
    BulkUpload bulkUpload = new BulkUpload();
    bulkUpload.setBulkUploadID(123);
    bulkUpload.setBatchID("123");
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.SUCCESS);
    bulkUpload.setCreatedDate(new Timestamp(System.currentTimeMillis()));
    bulkUpload.setAudit(getAuditEntity());
    bulkUpload.setBulkUploadTemplate(getBulkUploadTemplateEntity());
    bulkUpload.setGeneratedAudit(getAuditEntity());

    String request = """
        {"firmId":"NBIN","username":"sso1","secureZoneIds":["SZ1"],"ossProxyId":"oss1","ossUserId":"oss1","ossGroupId":"oss1","firstName":"firstName1","lastName":"Last1","email":"test20230207@gmail.com","preferredLanguage":"EN","compassR2Id":"bulk.user1","rrCodeRanges":[{"fromRRCode":"AAAA","toRRCode":"AAAA"},{"fromRRCode":"BBBB","toRRCode":"BBBB"}],"featurePackage":{"packageName":"ManageFirmAndUser","moduleOverrides":["firm_level_access","orders_module"]},"hashedPassword":"$2a$12$JPGZpiSlwgZMtgHA8Wmgtul6BIVqoQPn9WIjiRgqIh/NvgZo.y.qW","activationDate":"2024-12-20T00:00:00"}
        """;
    String response = """
        {"userConfigurationId":22536,"firmId":"NBIN","idpUserId":"00u22fcb0ipEaG2650h8","idpSubject":"cpx_22536","idp":"nbin","username":"sso1.qa","secureZoneIds":["SZ1"],"ossProxyId":"oss1","ossUserId":"oss1","ossGroupId":"oss1","firstName":"firstName1","lastName":"Last1","email":"test20230207@gmail.com","preferredLanguage":"EN","compassR2Id":"bulk.user1","rrCodeRanges":[{"fromRRCode":"AAAA","toRRCode":"AAAA"},{"fromRRCode":"BBBB","toRRCode":"BBBB"}],"featurePackage":{"packageName":"ManageFirmAndUser","moduleOverrides":["firm_level_access","orders_module"]},"active":"true","password":"MmgU16_Ue}j?","hashedPassword":"$2a$12$JPGZpiSlwgZMtgHA8Wmgtul6BIVqoQPn9WIjiRgqIh/NvgZo.y.qW","activationDate":"2024-12-20T00:00:00"}
        """;
    BulkUploadDetails bulkUploadDetails = new BulkUploadDetails();
    bulkUploadDetails.setBulkUploadDetailID(1);
    bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.SUCCESS);
    bulkUploadDetails.setRequest(request.getBytes());
    bulkUploadDetails.setResponse(response.getBytes());
    bulkUpload.setBulkUploadDetails(List.of(bulkUploadDetails));
    return bulkUpload;
  }

  public static Audit getAuditEntity() {
    Audit audit = new Audit();
    audit.setAuditId(1L);
    audit.setFileName("Sample Audit");
    audit.setFileContents("Sample File".getBytes());

    return audit;
  }

  public static List<BulkUpload> getBulkUploadList() {
    BulkUpload bulkUpload1 = new BulkUpload();
    bulkUpload1.setBatchID("batch1");
    bulkUpload1.setBulkUploadStatus(BulkUploadStatus.UPLOADED);
    BulkUploadTemplate template1 = new BulkUploadTemplate();
    template1.setTemplateName("template1");
    template1.setBatchType(BatchType.UPLOAD);
    bulkUpload1.setBulkUploadTemplate(template1);
    bulkUpload1.setAudit(new Audit());
    bulkUpload1.setCreatedDate(Timestamp.valueOf("2023-10-01 10:00:00"));
    BulkUpload bulkUpload2 = new BulkUpload();
    bulkUpload2.setBatchID("batch2");
    bulkUpload2.setBulkUploadStatus(BulkUploadStatus.FAILED);
    BulkUploadTemplate template2 = new BulkUploadTemplate();
    template2.setTemplateName("template2");
    template2.setBatchType(BatchType.EXPORT);
    bulkUpload2.setBulkUploadTemplate(template2);
    bulkUpload2.setAudit(new Audit());
    bulkUpload2.setCreatedDate(Timestamp.valueOf("2023-10-01 10:00:00"));
    return List.of(bulkUpload1, bulkUpload2);
  }


}
