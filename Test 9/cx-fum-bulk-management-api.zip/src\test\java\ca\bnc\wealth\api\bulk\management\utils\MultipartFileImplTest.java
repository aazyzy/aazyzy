package ca.bnc.wealth.api.bulk.management.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import org.junit.Test;
import org.springframework.web.multipart.MultipartFile;

public class MultipartFileImplTest {

  private static final String FILENAME = "test.txt";
  private static final String FILE_CONTENT = "content";
  private static final String CONTENT_TYPE = "csv";

  @Test
  public void testMultipartFileImpl() throws IOException {
    MultipartFile file = new MultipartFileImpl(FILE_CONTENT.getBytes(), FILENAME, CONTENT_TYPE);
    assertEquals(FILENAME, file.getName());
    assertEquals(FILENAME, file.getOriginalFilename());
    assertEquals(CONTENT_TYPE, file.getContentType());
    assertFalse(file.isEmpty());
    assertNotNull(file.getInputStream());

    File tempFile = File.createTempFile("test", ".txt");
    tempFile.deleteOnExit();
    file.transferTo(tempFile);
    assertTrue(tempFile.exists());
  }
}
