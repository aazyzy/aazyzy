# Changelog

## [5.0.2](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/compare/v5.0.1...v5.0.2) (2026-11-20)


### Bug Fixes

* rebuild image on base image java-25-1.2.2 ([#70](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/issues/70)) ([060a84c](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/060a84c2316169cfe8deb42f7dde67d256c5ac66))

## [5.0.1](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/compare/v5.0.0...v5.0.1) (2026-11-02)


### Miscellaneous Chores

* move to parent-pom-core 3.0.1, which fixes the Snyk findings of the 5.0.0 release: Tomcat 11.0.27, Jackson 3.2.4 and 2.22.4, Hibernate Validator 9.1.6.Final and java-jwt 4.6.2

## [5.0.0](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/compare/v4.0.2...v5.0.0) (2026-10-29)


### Miscellaneous Chores

* align develop versions with main after the 4.0.1 release ([#45](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/pull/45)) ([54ee7fc](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/54ee7fcf5d4caf7259a9e2ff08c57edbd5f9cd52))
* move bulk-user-migration-api to Spring Boot 4.1.1 in develop ([#48](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/pull/48)) ([d61a533](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/d61a533f765682f5184468ef1e4b4a7038701d2a))
* skip Sonar in the release workflow on Java 25 ([#55](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/pull/55)) ([3827c8b](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/3827c8b1bb8e22cb6c904ba8dd4cc931a8fe1302))
* skip the SonarQube analysis for now ([#53](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/pull/53)) ([a6a84fc](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/a6a84fc16675ece1f7cd8aee8c40c9d6116f13bb))
* stop storing migration passwords in BULK_UPLOAD_DETAIL ([#46](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/pull/46)) ([f1c56af](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/f1c56afd6b979673bc6e63b69ba7308fc6b9d0a0))
* sync 6900 dependency versions to develop SNAPSHOTs ([#54](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/pull/54)) ([a4d36af](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/a4d36afe576071e7cccfecf55805b091c747d05c))

## [4.0.2](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/compare/v4.0.1...v4.0.2) (2026-10-19)


### Miscellaneous Chores

* stop storing migration passwords in BULK_UPLOAD_DETAIL ([#49](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/issues/49)) ([c3deb64](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/c3deb64972b7a43ae17e4eed3ac05cb251d4ea22))

## [4.0.1](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/compare/v4.0.0...v4.0.1) (2026-10-14)


### Miscellaneous Chores

* remediate Snyk vulnerabilities on the 4.0 release line ([#41](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/issues/41)) ([c930185](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/c930185c8804d722221bfa132d618c51c4663f34))

## [4.0.0](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/compare/v3.2.0...v4.0.0) (2026-10-14)


### Miscellaneous Chores

* pin released 6900 dependency versions for release 4.0.0: commons-lib 2.1.42 (NWPI-15097), api-schemas-wealth 1.11.58 ([b5967c4](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/b5967c4cb72c7e2881f8eac667b1e5bfc1652cbe))

## [3.2.0](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/compare/v3.0.0...v3.2.0) (2026-09-16)


### Bug Fixes

* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([54a3388](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/54a33887de7f3103f24f4129c01ad8d8c5600a7f))
* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([1166b90](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/1166b902e6d01622947eced15e04fb39727a2d35))


### Miscellaneous Chores

* pin released 6900 dependency versions for release 3.2.0 ([0d2799c](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/0d2799c6cb2b85f3bbfe048ce59c19e719edd5cd))

## [3.0.0](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/compare/v2.2.3...v3.0.0) (2026-08-19)


### Miscellaneous Chores

* release 3.0.0 ([8a0ca73](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/8a0ca736576fefae44c5c6033ade9a0390144306))

## [2.2.3](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/compare/v2.2.2...v2.2.3) (2026-08-19)


### Bug Fixes

* **deps:** pin at.yawk.lz4:lz4-java 1.11.1 for CVE-2026-59949 ([#19](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/issues/19)) ([3ccfed5](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/3ccfed5618e81f213f0a15646162adf40b642a41))
* **deps:** pin at.yawk.lz4:lz4-java 1.11.1 for CVE-2026-59949 ([#20](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/issues/20)) ([675f9a1](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/675f9a18b767780e2fc53794d99b144e09220f94))
* **deps:** pin tomcat-embed 10.1.56 and logback-core 1.5.36 (Snyk HIGH) ([#13](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/issues/13)) ([b717c6e](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/b717c6ec57bc8c315a8b97d378646bcfa6439737))
* **deps:** pin vulnerable transitive dependencies for Snyk remediation ([#21](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/issues/21)) ([508447c](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/508447c425ae320fc1378585dce76374d212eb33))

## [2.2.2](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/compare/v2.2.1...v2.2.2) (2026-06-29)


### Bug Fixes

* release 2.2.1 ([0fbbd5f](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/0fbbd5fddf0d5fef61128687f31fa4b70693c06b))

## [2.2.1](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/compare/v2.2.0...v2.2.1) (2026-06-09)


### Bug Fixes

* first release in github ([15deabd](https://github.com/NBC-GPMF/cx-fum-bulk-user-migration-api/commit/15deabd10207a02014c1c6607747a45764a81eb3))
