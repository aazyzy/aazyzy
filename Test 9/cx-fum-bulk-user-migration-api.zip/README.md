# Bulk User Migration API

Spring Boot service used to upload, validate, submit, and track bulk user migration requests.

## What this service does

- Provides templates for migration and password uploads.
- Validates uploaded migration files against template rules.
- Creates bulk migration batches and publishes per-user requests to Kafka.
- Consumes per-user processing messages and calls downstream user-configuration APIs.
- Tracks batch progress and generates final CSV status reports.
- Exposes endpoints to query status, metadata, and generated reports.
- Generates user reports asynchronously and uploads them to S3.

## Runtime basics

- Java: 17
- Framework: Spring Boot
- Context path: /bulk-user-uploads
- Default port: 8081
- Management base path: /manage
- Exposed management endpoints: health, info

Base URL (local): http://localhost:8081/bulk-user-uploads

## Main process flow

1. Client downloads template CSVs.
2. Client uploads migration file using USER-MIGRATE-TEMPLATE.
3. Service validates input, stores audit artifact, and creates a bulk form record.
4. Client submits migration with password file and form id.
5. Service creates per-user actions and publishes them to Kafka.
6. Kafka consumer processes each action and calls user-configuration API.
7. Scheduler aggregates action status, updates batch status, and uploads generated report CSV.
8. Client downloads report/status/metadata by migration id.

## API endpoints

All paths below are relative to /bulk-user-uploads.

- GET /templates/{template-format}: Download template CSV.
- POST /templates/{template-format}: Upload migration file and create form id.
- GET /forms/{form-id}: Download original uploaded audit file.
- POST /migrations (multipart + x-nbin-cx-form-id): Submit migration using password file.
- GET /migrations/{migration-id}: Get batch status.
- GET /reports: List all migration reports.
- GET /reports/{migration-id}: Download generated migration status CSV.
- GET /reports/{migration-id}/metadata: Get migration metadata summary.
- GET /user/report: Trigger default async user report generation.
- POST /user/report/query: Trigger async user report generation with filters/options.

## Batch statuses

- UPLOADED: File accepted and validated.
- SUBMITTED: Migration submitted for processing.
- PROCESSING: In-flight processing.
- SUCCESS: All records succeeded.
- PART_SUCCESS: Mix of success and failure.
- FAILED: All records failed or terminal failure.

## Key integrations

- Kafka publisher/subscriber for single-request processing.
- Audit management API for storing/retrieving uploaded and generated files.
- User configuration API for individual user creation.
- PostgreSQL repositories/entities for bulk and detail tracking.
- S3 for generated user-report CSV output.

## Local development

1. Create a local override file, for example application-local.yml.
2. Add required local properties (database, kafka, downstream URLs, auth, S3).
3. Run Application main class with VM option:

```bash
-Dspring.config.additional-location="<absolute-path-to-application-local.yml>"
```

4. Start the service and call endpoints using base URL:

```text
http://localhost:8081/bulk-user-uploads
```

## Build and test

Use the Maven wrapper included in the repository.

```bash
./mvnw clean test
./mvnw clean verify
```

## CI/CD at a glance

- Pull requests and non-main pushes run Maven CI workflow.
- Pushes to main run build and ArgoCD deployment workflow.
- Release automation is handled via release-please configuration under .github.

## Notes

- Template format USER-MIGRATE-TEMPLATE is enforced for migration upload.
- Password file is required when submitting migration.
- Scheduler frequency is controlled by bulk.schedule.duration.