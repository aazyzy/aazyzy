package ca.bnc.wealth.api.bulk.migration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication(scanBasePackages = {"ca.bnc.wealth.api.*",
        "ca.bnc.wealth.common.kafka.*",
        "ca.bnc.wealth.common.exception.*",
        "ca.bnc.wealth.common.core.cors",
        "ca.bnc.wealth.common.spring.microservice.starter.core",
        "ca.bnc.wealth.common.jpa.*",
        "ca.bnc.wealth.common.s3",
        "ca.bnc.wealth.common.fum.*"})
@EnableJpaRepositories({"ca.bnc.wealth.common.jpa.repo"})
@EntityScan(basePackages = {"ca.bnc.wealth.common.jpa.entity"})
@EnableScheduling
@EnableAsync
public class Application {

  public static void main(String[] args) {
    SpringApplication.run(Application.class, args);
  }

}
