package ca.bnc.wealth.api.bulk.migration.controller;

import static org.springframework.http.HttpHeaders.CONTENT_DISPOSITION;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.bulk.migration.service.SingleRequestService;
import ca.bnc.wealth.api.bulk.migration.service.TemplateService;
import ca.bnc.wealth.api.bulk.migration.service.UploadService;
import ca.bnc.wealth.api.bulk.migration.service.UserReportService;
import ca.bnc.wealth.common.bulk_user_migration.api.BulkUserMigrationApi;
import ca.bnc.wealth.common.bulk_user_migration.model.DownloadUserReportRequest;
import ca.bnc.wealth.common.bulk_user_migration.model.MigrationReportMetadataResponse;
import ca.bnc.wealth.common.bulk_user_migration.model.MigrationReportResponse;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.Audit;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@RestController
public class BulkUserMigrationController implements BulkUserMigrationApi {

  @Autowired
  private TemplateService templateService;
  @Autowired
  private UploadService uploadService;
  @Autowired
  private SingleRequestService singleRequestService;
  @Autowired
  private UserReportService userReportService;

  @Override
  public ResponseEntity<Resource> getTemplateByTemplateFormat(String templateFormat) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getTemplateByTemplateFormat # Start: idpUserSubject: {} templateFormat {}", user.getIdpSubject(), templateFormat);

    Pair<String, ByteArrayResource> pair = templateService.getAuditById(templateFormat);
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION, pair.getKey())
        .body(pair.getValue());
  }

  @Override
  public ResponseEntity<String> uploadBulkUserDetails(String templateFormat, MultipartFile file) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("uploadBulkUserDetails # Start: idpUserSubject: {} templateFormat {}", user.getIdpSubject(), templateFormat);

    if(!templateFormat.equalsIgnoreCase("USER-MIGRATE-TEMPLATE"))
      throw new FumValidationException("NOT_SUPPORTED", "Supported format is USER-MIGRATE-TEMPLATE");
    BulkUpload bulkUpload = uploadService.uploadAndValidate(file, user.getIdpSubject());
    return ResponseEntity.ok(String.valueOf(bulkUpload.getBulkUploadID()));
  }

  @Override
  public ResponseEntity<String> migrateBulkUser(MultipartFile file, String formId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("migrateBulkUser # Start: idpUserSubject: {} formId {}", user.getIdpSubject(), formId);

    String migrationId = uploadService.migrateBulkUser(formId, file, user.getIdpSubject());
    return ResponseEntity.ok(migrationId);
  }


  @Override
  public ResponseEntity<Resource> getBulkUploadAuditByFormId(String formId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getBulkUploadAuditByFormId # Start: idpUserSubject: {} formId {}", user.getIdpSubject(), formId);

    BulkUpload bulkUpload  = uploadService.getBulkUploadByFormId(formId);
    Pair<String,ByteArrayResource> pair = templateService.getAuditById(bulkUpload.getAudit().getAuditId());
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION, pair.getKey())
        .body(pair.getValue());
  }

  @Override
  public ResponseEntity<List<MigrationReportResponse>> downloadAllBulkUserMigrationReports() {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("downloadAllBulkUserMigrationReports # Start: idpUserSubject: {}", user.getIdpSubject());
    return ResponseEntity.ok(uploadService.getAllBulkUserMigrations());
  }

  @Override
  public ResponseEntity<Resource> downloadBulkUserMigrationReport(String migrationId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("downloadBulkUserMigrationReport # Start: idpUserSubject: {} migrationId {}", user.getIdpSubject(), migrationId);

    Audit generatedAudit = singleRequestService.downloadStatusCsv(migrationId);

    String headerValue = "attachment; filename=\"" + generatedAudit.getFileName() + "\"";
    return ResponseEntity.ok()
        .header(CONTENT_DISPOSITION, headerValue)
        .body(new ByteArrayResource(generatedAudit.getFileContents()));
  }

  @Override
  public ResponseEntity<String> getBulkUserMigrationStatus(String migrationId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getBulkUserMigrationStatus # Start: idpUserSubject: {} migrationId {}", user.getIdpSubject(), migrationId);
    return ResponseEntity.ok(uploadService.getBulkUserMigrationStatus(migrationId).name());
  }

  @Override
  public ResponseEntity<MigrationReportMetadataResponse> downloadBulkUserMigrationReportMetadata(String migrationId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("downloadBulkUserMigrationReportMetadata # Start: idpUserSubject: {} migrationId {}", user.getIdpSubject(), migrationId);
    return ResponseEntity.ok(uploadService.getMigrationReportMetadata(migrationId));
  }

  @Override
  public ResponseEntity<Void> downloadUserReport() {
    userReportService.generateUserReportAsync();
    return ResponseEntity.ok().build();
  }

  @Override
  public ResponseEntity<Void> downloadUserReportQuery(DownloadUserReportRequest downloadUserReportRequest) {
    userReportService.generateUserReportAsync(downloadUserReportRequest);
    return ResponseEntity.ok().build();
  }
}
