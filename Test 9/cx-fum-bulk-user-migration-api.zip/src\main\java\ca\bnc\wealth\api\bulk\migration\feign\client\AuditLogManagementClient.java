package ca.bnc.wealth.api.bulk.migration.feign.client;

import ca.bnc.wealth.common.audit_management.model.Audit;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

@FeignClient(url = "${feign.auditLogManagementApi.url}")
public interface AuditLogManagementClient {

  @PostMapping(path = "/audits", consumes = "multipart/form-data", produces = "application/json")
  ResponseEntity<Audit> uploadAudit( @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestPart(value = "file", required = true) MultipartFile file,
      @RequestParam(value = "metadata", required = false) String metadata);

  @GetMapping(path = "/audits/{audit-id}", produces =  { "multipart/form-data", "application/json" })
  ResponseEntity<ByteArrayResource> getAuditById(@RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @PathVariable("audit-id") Long auditId);
}
