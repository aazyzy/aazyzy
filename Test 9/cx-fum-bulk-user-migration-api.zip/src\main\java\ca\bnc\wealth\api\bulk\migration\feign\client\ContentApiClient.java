package ca.bnc.wealth.api.bulk.migration.feign.client;

import java.util.Map;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(url = "${feign.contentApi.url}")
public interface ContentApiClient {

  @PostMapping(path = "/experience/content/modules")
  ResponseEntity<Map<String,String>> getTransulation( @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,@RequestHeader(name = HttpHeaders.ACCEPT_LANGUAGE) String lang, @RequestBody String request);
}
