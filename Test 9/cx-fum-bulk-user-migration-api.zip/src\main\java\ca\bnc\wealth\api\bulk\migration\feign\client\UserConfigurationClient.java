package ca.bnc.wealth.api.bulk.migration.feign.client;

import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(url = "${feign.userConfigApi.url}")
public interface UserConfigurationClient {

  @PostMapping(path = "/users")
  ResponseEntity<Object> createUserConfiguration( @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,@RequestBody UserConfiguration userConfiguration);
}
