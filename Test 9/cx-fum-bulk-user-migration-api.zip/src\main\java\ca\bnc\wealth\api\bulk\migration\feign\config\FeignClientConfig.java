package ca.bnc.wealth.api.bulk.migration.feign.config;

import ca.bnc.wealth.api.authorization.feign.config.FeignCodecs;
import ca.bnc.wealth.api.bulk.migration.feign.client.AuditLogManagementClient;
import ca.bnc.wealth.api.bulk.migration.feign.client.ContentApiClient;
import ca.bnc.wealth.api.bulk.migration.feign.client.UserConfigurationClient;
import feign.Feign;
import feign.Logger;
import feign.Util;
import feign.codec.Decoder;
import feign.form.spring.SpringFormEncoder;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.util.StreamUtils;
import tools.jackson.databind.JavaType;
import tools.jackson.databind.cfg.DateTimeFeature;
import tools.jackson.databind.json.JsonMapper;

@Configuration
@EnableFeignClients
@Slf4j
public class FeignClientConfig {

  // Jackson 2 defaults with ISO dates: what the Spring Boot 3 line's per-call decoder mapper read
  private static final JsonMapper DECODER_MAPPER =
      JsonMapper.builderWithJackson2Defaults()
          .disable(DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS)
          .build();

  @Value("${feign.userConfigApi.url}")
  private String userConfigApi;

  @Value("${feign.auditLogManagementApi.url}")
  private String auditLogManagementApi;

  @Value("${feign.contentApi.url}")
  private String contentApi;

  @Bean
  public UserConfigurationClient getUserConfigurationClient(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .decoder(new ResponseEntityDecoder(getResponseEntityDecoder()))
        .logger(new Slf4jLogger(UserConfigurationClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(UserConfigurationClient.class, userConfigApi);
  }

  @Bean
  public AuditLogManagementClient getAuditManagementClient() {

    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(new SpringFormEncoder())
        .decoder(new ResponseEntityDecoder(getResourceOrJsonDecoder()))
        .logger(new Slf4jLogger(AuditLogManagementClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(AuditLogManagementClient.class, auditLogManagementApi);
  }

  @Bean
  public ContentApiClient getContentApiClient() {

    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(new SpringFormEncoder())
        .decoder(new ResponseEntityDecoder(getResourceOrJsonDecoder()))
        .logger(new Slf4jLogger(ContentApiClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(ContentApiClient.class, contentApi);
  }

  public Decoder getResourceOrJsonDecoder() {
    return (response, type) -> {

      if (type instanceof Class && ByteArrayResource.class.isAssignableFrom((Class) type)) {
        return new ByteArrayResource(StreamUtils.copyToByteArray(response.body().asInputStream()));
      }
      String bodyStr = Util.toString(response.body().asReader(Util.UTF_8));
      JavaType javaType = DECODER_MAPPER.getTypeFactory().constructType(type);
      return DECODER_MAPPER.readValue(bodyStr, javaType);
    };
  }

  public Decoder getResponseEntityDecoder() {
    return (response, type) -> {
      String bodyStr = Util.toString(response.body().asReader(Util.UTF_8));
      JavaType javaType = DECODER_MAPPER.getTypeFactory().constructType(type);
      return DECODER_MAPPER.readValue(bodyStr, javaType);
    };
  }
}
