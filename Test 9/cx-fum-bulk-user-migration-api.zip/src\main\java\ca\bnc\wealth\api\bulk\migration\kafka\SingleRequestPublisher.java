package ca.bnc.wealth.api.bulk.migration.kafka;

import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadDetails;
import ca.bnc.wealth.common.kafka.core.publisher.Publisher;
import ca.bnc.wealth.common.kafka.messaging.publisher.EventMessagePublisherFactory;
import jakarta.annotation.PostConstruct;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class SingleRequestPublisher {

  protected Publisher<String, String> publisher;
  @Autowired
  private EventMessagePublisherFactory publisherFactory;

  @Value("${bulk.producer.action}")
  private String producerActionName;

  @PostConstruct
  public void init() {
    this.publisher = publisherFactory.createNewPublisher(producerActionName);
  }

  public void publishMessage(BulkUploadDetails bulkUploadDetails) {
    try {
      log.info("Publishing single Request Id:" + bulkUploadDetails.getBulkUploadDetailID());
      publisher.publishSynchronous(String.valueOf(bulkUploadDetails.getBulkUploadDetailID()));
    } catch (ExecutionException | TimeoutException e) {
      throw new RuntimeException("Failed to publish message to Kafka", e);
    }
  }
}
