package ca.bnc.wealth.api.bulk.migration.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.core.io.ByteArrayResource;

@Getter
@Setter
public class BulkDownloadResource extends ByteArrayResource {

  private final String fileName;

  public BulkDownloadResource(String fileName, byte[] byteArray, String description) {
    super(byteArray, description);
    this.fileName = fileName;
  }
}
