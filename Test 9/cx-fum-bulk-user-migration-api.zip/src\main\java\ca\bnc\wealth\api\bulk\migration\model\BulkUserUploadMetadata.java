package ca.bnc.wealth.api.bulk.migration.model;

import java.time.LocalDateTime;
import lombok.Data;

@Data
public class BulkUserUploadMetadata {

  private String filename;
  private String status;
  private Integer totalRecords;
  private Integer successfulRecords;
  private Integer failedRecords;
  private Integer pendingRecords;
  private LocalDateTime uploadedDate;
}
