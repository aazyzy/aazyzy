package ca.bnc.wealth.api.bulk.migration.schedule;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.bulk.migration.feign.client.AuditLogManagementClient;
import ca.bnc.wealth.api.bulk.migration.model.BulkDownloadResource;
import ca.bnc.wealth.api.bulk.migration.service.CsvWriteService;
import ca.bnc.wealth.api.bulk.migration.utils.Constants;
import ca.bnc.wealth.api.bulk.migration.utils.MultipartFileImpl;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.Audit;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadDetailsRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AuditRepository;
import ca.bnc.wealth.common.jpa.service.ScheduleService;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Service
@Slf4j
public class BulkActionStatusCheckService {

  @Autowired
  private BulkUploadRepository bulkUploadRepository;

  @Autowired
  private BulkUploadDetailsRepository bulkUploadDetailsRepository;

  @Autowired
  private AuditRepository auditRepository;

  @Autowired
  private ScheduleService scheduleService;

  @Autowired
  private CsvWriteService csvWriteService;

  @Autowired
  private AuditLogManagementClient auditLogManagementClient;

  @Autowired
  private SystemTokenFactory systemTokenFactory;

  @Value("${bulk.schedule.name}")
  private String scheduleName;

  @Value("${bulk.schedule.duration:10}")
  private long schedulerDuration;

  @Scheduled(
      fixedDelayString = "${bulk.schedule.duration:10}",
      timeUnit = TimeUnit.SECONDS)
  @Transactional
  public void updateBulkStatus() {
    if (this.scheduleService.canRunSchedule(scheduleName, schedulerDuration, TimeUnit.SECONDS)) {
      List<BulkUpload> lst = getPendingBulkRequest();

      ExecutorService executorService = Executors.newFixedThreadPool(10);
      lst.forEach(entity -> executorService.submit(() -> this.checkAndUpdateStatus(entity)));
      shutdownAndAwait(executorService);
      this.scheduleService.updateStatusToFinish(scheduleName);
    }
  }

  void checkAndUpdateStatus(BulkUpload bulkUpload) {
    String bulkUploadPath = "bulkUpload.bulkUploadID";
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(Constants.BULK_UPLOAD_STATUS, Pair.of(EnumQueryCriteria.EQUALS, BulkUploadStatus.SUCCESS));
    fieldValueMap.put(bulkUploadPath, Pair.of(EnumQueryCriteria.EQUALS, bulkUpload.getBulkUploadID()));
    long successful = bulkUploadDetailsRepository.count(new Specification<>(fieldValueMap));

    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap1 = new HashMap<>();
    fieldValueMap1.put(Constants.BULK_UPLOAD_STATUS, Pair.of(EnumQueryCriteria.EQUALS, BulkUploadStatus.FAILED));
    fieldValueMap1.put(bulkUploadPath, Pair.of(EnumQueryCriteria.EQUALS, bulkUpload.getBulkUploadID()));
    long failed = bulkUploadDetailsRepository.count(new Specification<>(fieldValueMap1));

    if(bulkUpload.getTotalRecords() == successful) {
      bulkUpload.setBulkUploadStatus(BulkUploadStatus.SUCCESS);
      Audit generatedAudit = uploadAudit(bulkUpload);
      bulkUpload.setGeneratedAudit(generatedAudit);
    } else if(successful + failed == bulkUpload.getTotalRecords()) {
      if(successful > 0) {
        bulkUpload.setBulkUploadStatus(BulkUploadStatus.PART_SUCCESS);
      } else {
        bulkUpload.setBulkUploadStatus(BulkUploadStatus.FAILED);
      }
      Audit generatedAudit = uploadAudit(bulkUpload);
      bulkUpload.setGeneratedAudit(generatedAudit);
    } else {
      bulkUpload.setBulkUploadStatus(BulkUploadStatus.PROCESSING);
    }
    bulkUpload.setTotalSuccess((int)successful);
    bulkUpload.setTotalFailed((int)failed);
    bulkUpload.setTotalPending(bulkUpload.getTotalRecords() - (int)successful - (int)failed);
    bulkUpload.setUpdatedDate(Timestamp.valueOf(LocalDateTime.now()));
    bulkUploadRepository.saveAndFlush(bulkUpload);
  }

  private List<BulkUpload> getPendingBulkRequest() {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(Constants.BULK_UPLOAD_STATUS, Pair.of(EnumQueryCriteria.IN,
        List.of(BulkUploadStatus.SUBMITTED, BulkUploadStatus.PROCESSING)));
    // include BulkUserMigration template
    fieldValueMap.put("bulkUploadTemplate.templateName", Pair.of(EnumQueryCriteria.IGNORE_CASE_EQUALS, "BulkUserMigration"));
    List<BulkUpload> pendingRequests = bulkUploadRepository.findAll(new Specification<>(fieldValueMap));
    if (pendingRequests.size() > 10000) {
      log.warn("QUERY_RESULT_SIZE: method=getPendingBulkRequest, resultCount={} - exceeds threshold", pendingRequests.size());
    } else {
      log.info("QUERY_RESULT_SIZE: method=getPendingBulkRequest, resultCount={}", pendingRequests.size());
    }
    return pendingRequests;
  }

  private ca.bnc.wealth.common.jpa.entity.iam.Audit uploadAudit(BulkUpload bulkUpload) {
    log.info("Generating report for batch Id:" + bulkUpload.getBatchID());
    BulkDownloadResource bulkDownloadResource = csvWriteService.downloadStatusCsv(bulkUpload);
    MultipartFile multipartFile = new MultipartFileImpl(bulkDownloadResource.getByteArray(),
        bulkDownloadResource.getFileName(), "csv");

    String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);
    ResponseEntity<ca.bnc.wealth.common.audit_management.model.Audit> auditResponseEntity
        = auditLogManagementClient.uploadAudit(token, multipartFile, "");

    return auditRepository.getReferenceById(
        Objects.requireNonNull(auditResponseEntity.getBody()).getAuditId()); // Calling DB directly to get entity reference
  }

  @SneakyThrows
  private void shutdownAndAwait(ExecutorService executorService) {
    executorService.shutdown();
    try {
      executorService.awaitTermination(100000, TimeUnit.MILLISECONDS);
    } catch (InterruptedException e) {
      executorService.shutdownNow();
      log.error("Error in executor service: {}", e.getMessage());
      throw e;
    }
  }
}
