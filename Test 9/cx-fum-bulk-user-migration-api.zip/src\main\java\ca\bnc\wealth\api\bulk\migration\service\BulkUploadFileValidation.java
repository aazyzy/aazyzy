package ca.bnc.wealth.api.bulk.migration.service;

import ca.bnc.wealth.api.bulk.migration.utils.Constants;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import ca.bnc.wealth.common.jpa.entity.jsonb.TemplateField;
import ca.bnc.wealth.common.jpa.entity.jsonb.TemplateFieldConfig;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BulkUploadFileValidation {

  public Map<String, List<Long>> validation(List<Map<String, String>> parsedFileContents,
      Template template) {
    Map<String, List<Long>> errorMessageToRowNumbers = new HashMap<>();
    Map<String, TemplateFieldConfig> fieldConfigMap = template.getFields().stream()
        .collect(Collectors.toMap(TemplateField::getFieldName, TemplateField::getConfig));

    for (int rowIndex = 0; rowIndex < parsedFileContents.size(); rowIndex++) {
      Map<String, String> row = parsedFileContents.get(rowIndex);
      fieldConfigMap.forEach((fieldname, fieldConfig) -> {
        String fieldValue = row.get(fieldConfig.getHeaderName());
        boolean hasError = mandatoryField(fieldConfig, fieldValue, errorMessageToRowNumbers,
            Long.parseLong(row.get(Constants.ROW_NUMBER)));
        if(!hasError) {
          supportedFieldValues(fieldConfig, fieldValue, errorMessageToRowNumbers,
              Long.parseLong(row.get(Constants.ROW_NUMBER)));
        }
      });
    }
    return errorMessageToRowNumbers;
  }

  private boolean mandatoryField(TemplateFieldConfig fieldConfig, String fieldValue,
      Map<String, List<Long>> errorMessageToRowNumbers, long rowIndex) {

    if (fieldConfig.getMandatory() && StringUtils.isBlank(fieldValue)) {
      errorMessageToRowNumbers.computeIfAbsent("Mandatory_Field " + fieldConfig.getHeaderName(),
          k -> new ArrayList<>()).add(rowIndex);
      return true;
    }
    return false;
  }

  private void supportedFieldValues(TemplateFieldConfig field, String fieldValue,
      Map<String, List<Long>> errorMessageToRowNumbers, long rowIndex) {
    if (field.getPattern() != null) {
      Pattern pattern = Pattern.compile(field.getPattern());
      if (!pattern.matcher(fieldValue).matches()) {
        errorMessageToRowNumbers.computeIfAbsent("Not_Supported_Value " + field.getHeaderName(),
            k -> new ArrayList<>()).add(rowIndex);
      }
    }
  }

}
