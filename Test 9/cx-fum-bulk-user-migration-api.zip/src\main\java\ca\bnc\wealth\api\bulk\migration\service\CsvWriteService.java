package ca.bnc.wealth.api.bulk.migration.service;

import ca.bnc.wealth.api.bulk.migration.model.BulkDownloadResource;
import ca.bnc.wealth.api.bulk.migration.utils.Constants;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadDetails;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import tools.jackson.databind.ObjectMapper;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class CsvWriteService {

  private static final String JSON_ERROR_MESSAGES = "messages";
  private static final String JSON_ERRORS = "errors";
  private static final String JSON_ERROR_CODE = "code";
  private static final String JSON_ERROR_MESSAGE = "message";
  @Autowired
  private ObjectMapper objectMapper;

  public BulkDownloadResource downloadStatusCsv(BulkUpload bulkUpload) {
    List<BulkUploadDetails> lst = bulkUpload.getBulkUploadDetails();
    String fileName = bulkUpload.getAudit().getFileName();
    List<String> headers = new ArrayList<>(bulkUpload.getBulkUploadTemplate().getConfig().getHeaderNames());
    headers.add(Constants.STATUS);
    headers.add(Constants.ERROR_MESSAGE);

    StringWriter sw = getCsvStringWriter(headers, lst);
    String downloadFileName = fileName.split(".csv")[0] + "_Status.csv";
    log.info("CSV_REPORT_GENERATED: fileName={}, recordCount={}", downloadFileName, lst.size());
    return new BulkDownloadResource(downloadFileName, sw.toString().getBytes(), "");
  }

  @SneakyThrows
  private StringWriter getCsvStringWriter(List<String> headers, List<BulkUploadDetails> lst) {
    StringWriter sw = new StringWriter();
    CSVFormat csvFormat = CSVFormat.DEFAULT.builder()
        .setHeader(headers.toArray(new String[headers.size()]))
        .setDelimiter("|")
        .build();

    CSVPrinter printer = new CSVPrinter(sw, csvFormat);

    for (BulkUploadDetails details : lst) {
      printer.printRecord(addRowData(headers, details));
    }

    return sw;
  }

  @SneakyThrows
  private List<String> addRowData(List<String> headers, BulkUploadDetails details) {
    List<String> row = new ArrayList<>();
    UserConfiguration userConfiguration;
    Map<String, String> rawDataMap = new HashMap<>();

    if( details.getBulkUploadStatus() == BulkUploadStatus.SUCCESS) {
      userConfiguration = objectMapper.readValue(new String(details.getResponse(), StandardCharsets.UTF_8), UserConfiguration.class);
      rawDataMap.putAll(convert(userConfiguration, details));
    } else {
      try {
        userConfiguration = objectMapper.readValue(new String(details.getRequest(), StandardCharsets.UTF_8), UserConfiguration.class);
        rawDataMap.putAll(convert(userConfiguration, details));
      } catch (Exception e) {
        rawDataMap.putAll(objectMapper.readValue(new String(details.getRequest(), StandardCharsets.UTF_8), HashMap.class));
      }
    }
    row.addAll(headers.stream().map(header -> sanitizeCsvCell(rawDataMap.get(header) != null ? rawDataMap.get(header) : "")).toList());

    return row;
  }

  private String sanitizeCsvCell(String value) {
    if (value != null && !value.isEmpty() && "=+@-".indexOf(value.charAt(0)) >= 0) {
      return "'" + value;
    }
    return value;
  }

  private Map<String, String> convert(UserConfiguration userConfiguration, BulkUploadDetails details) {
    Map<String, String> rawDataMap = new HashMap<>();
    rawDataMap.put(Constants.FIRM_ID,userConfiguration.getFirmId());
    rawDataMap.put(Constants.FIRST_NAME,userConfiguration.getFirstName());
    rawDataMap.put(Constants.LAST_NAME,userConfiguration.getLastName());
    rawDataMap.put(Constants.EMAIL,userConfiguration.getEmail());
    rawDataMap.put(Constants.PREFERRED_LANGUAGE,userConfiguration.getPreferredLanguage());
    if(userConfiguration.getSecureZoneIds() != null && !userConfiguration.getSecureZoneIds().isEmpty()) {
      rawDataMap.put(Constants.SECURITY_ZONE_ID,userConfiguration.getSecureZoneIds().stream().collect(Collectors.joining(",")));
    }
    if(userConfiguration.getOssUserId() != null || userConfiguration.getOssProxyId() != null || userConfiguration.getOssGroupId() != null) {
      rawDataMap.put(Constants.OSS_USER_ID,userConfiguration.getOssUserId());
    }
    rawDataMap.put(Constants.COMPASS_R2_ID,userConfiguration.getCompassR2Id());
    if(StringUtils.isNotBlank(userConfiguration.getExternalClientId())) {
      rawDataMap.put(Constants.SSO_USER_ID,userConfiguration.getUsername());
    }
    rawDataMap.put(Constants.PACKAGE_TEMPLATE_NAME,userConfiguration.getFeaturePackage().getPackageName());
    if(userConfiguration.getFeaturePackage().getModuleOverrides() != null && !userConfiguration.getFeaturePackage().getModuleOverrides().isEmpty()) {
      rawDataMap.put(Constants.MODULE_OVERRIDES,userConfiguration.getFeaturePackage().getModuleOverrides().stream()
          .filter(mo -> !mo.equalsIgnoreCase("firm_level_access"))
          .collect(Collectors.joining(",")));
      if(userConfiguration.getFeaturePackage().getModuleOverrides().contains("firm_level_access")) {
        rawDataMap.put(Constants.FIRM_LEVEL_ACCESS,"false");
      } else {
        rawDataMap.put(Constants.FIRM_LEVEL_ACCESS,"true");
      }
    } else {
      rawDataMap.put(Constants.FIRM_LEVEL_ACCESS,"false");
    }
    convertRrCodeRange(rawDataMap, userConfiguration);

    rawDataMap.put(Constants.ACTIVATION_DATE,userConfiguration.getActivationDate().format(DateTimeFormatter.ofPattern("MM-dd-yyyy")));

    rawDataMap.put(Constants.STATUS,details.getBulkUploadStatus().name());
    if(details.getBulkUploadStatus() == BulkUploadStatus.FAILED) {
      rawDataMap.put(Constants.ERROR_MESSAGE, details.getResponse() != null ? getErrorMessage(new String(details.getResponse(), StandardCharsets.UTF_8)) : "");
    }
    return rawDataMap;
  }

  private void convertRrCodeRange(Map<String, String> rawDataMap, UserConfiguration userConfiguration) {
    if(userConfiguration.getRrCodeRanges() != null && !userConfiguration.getRrCodeRanges().isEmpty()) {
      rawDataMap.put(Constants.RR_CODES,userConfiguration.getRrCodeRanges().stream().map(rr -> rr.getFromRRCode() + "-" + rr.getToRRCode()).collect(Collectors.joining(",")));
    }
  }

  public String getErrorMessage(String createUserResponse) {
    try {
      JSONObject jsonObject = new JSONObject(createUserResponse);
      if(jsonObject.has(JSON_ERROR_MESSAGES) && jsonObject.getJSONObject(JSON_ERROR_MESSAGES).has(JSON_ERRORS)) {
        JSONArray jsonArray = jsonObject.getJSONObject(JSON_ERROR_MESSAGES).getJSONArray(JSON_ERRORS);
        return getJsonErrorMessage(jsonArray);
      }
    } catch (Exception ignored) {
      if(createUserResponse.equals(Constants.ERROR_R2_NOT_FOUND_MESSAGE))
        return createUserResponse;
    }
    return "Unable to create user";
  }

  private String getJsonErrorMessage(JSONArray jsonArray ) {
    StringBuilder stringBuilder = new StringBuilder();
    for (int i = 0; i < jsonArray.length(); i++) {
      JSONObject message = jsonArray.getJSONObject(i);
      if(message.has(JSON_ERROR_CODE)) {
        if(message.getString(JSON_ERROR_CODE).contains("."))
          stringBuilder.append(getCreateUserErrorMessage(message.getString(JSON_ERROR_CODE)));
        else
          stringBuilder.append(getCreateUserErrorMessage(message.getString(JSON_ERROR_MESSAGE)));
        if(i != jsonArray.length() - 1)
          stringBuilder.append(",");
      }
    }
    return stringBuilder.toString();
  }

  public String getCreateUserErrorMessage(String key) {
    switch (key) {
      case Constants.ERROR_OKTA_PROFILE:
        return "User id already exists in Okta";
      case Constants.ERROR_INVALID_FIRM_ID:
        return "Invalid Firm ID";
      case Constants.ERROR_R2_PW:
        return "R2 password encryption is outdated";
      case Constants.ERROR_R2_FOUND:
        return "R2 ID is linked with another CX user";
      case Constants.ERROR_EMAIL_INVALID:
        return "Invalid email address";
      case Constants.ERROR_OKTA_CREATE:
        return "Okta user creation failed";
      case Constants.ERROR_R2_NOT_FOUND:
        return "R2 ID does not exist";
      case Constants.ERROR_RR_CODE_INVALID:
        return "Invalid RR Code";
      case Constants.ERROR_SSO_EXIST:
        return "New Compass User Id exists already";
      default:
        return "Create User Failed";
    }
  }

}
