package ca.bnc.wealth.api.bulk.migration.service;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.bulk.migration.feign.client.UserConfigurationClient;
import ca.bnc.wealth.api.bulk.migration.kafka.SingleRequestPublisher;
import ca.bnc.wealth.api.bulk.migration.utils.Constants;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadDetails;
import ca.bnc.wealth.common.jpa.entity.iam.Audit;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadDetailsRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import ca.bnc.wealth.common.userconfiguration.model.FeaturePackage;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ObjectNode;
import feign.FeignException;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import tools.jackson.core.JacksonException;

@Slf4j
@Service
public class SingleRequestService {

  private static final List<String> PASSWORD_FIELDS = List.of("password", "hashedPassword", Constants.PASS_LABEL);

  @Autowired
  private BulkUploadDetailsRepository bulkUploadDetailsRepository;

  @Autowired
  private BulkUploadRepository bulkUploadRepository;

  @Autowired
  private UserConfigurationClient userConfigurationClient;

  @Autowired
  private SystemTokenFactory systemTokenFactory;

  @Autowired
  private SingleRequestPublisher singleRequestPublisher;

  @Autowired
  private ObjectMapper objectMapper;

  @SneakyThrows
  public void singleRequestProcessing(long singleActionId) {
    BulkUploadDetails entity = bulkUploadDetailsRepository.findById(singleActionId)
        .orElseThrow(() -> {
          log.error("Bulk upload detail not found for action id: {}", singleActionId);
          throw new FumNotFoundException(Constants.BULK_UPLOAD_DETAIL_NOT_FOUND_CODE,
              Constants.BULK_UPLOAD_DETAIL_NOT_FOUND_MESSAGE + singleActionId);
        });

    if (entity.getBulkUploadStatus() != BulkUploadStatus.SUBMITTED) {
      return;
    }

    try {
      UserConfiguration userConfiguration = objectMapper.readValue(new String(entity.getRequest(), StandardCharsets.UTF_8), UserConfiguration.class);
      validateUserConfiguration(userConfiguration);
      String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);

      ResponseEntity<Object> response = userConfigurationClient.createUserConfiguration(token, userConfiguration);
      Object body = response.getBody();
      if (body != null) {
        entity.setResponse(withoutPasswords(objectMapper.writeValueAsString(body).getBytes(StandardCharsets.UTF_8)));
      }
      if (response.getStatusCode() == HttpStatus.OK) {
        entity.setBulkUploadStatus(BulkUploadStatus.SUCCESS);
      } else {
        entity.setBulkUploadStatus(BulkUploadStatus.FAILED);
      }
    } catch (FeignException exception) {
      log.error("UPSTREAM_ERROR: actionId={}, statusCode={}, errorType={}", singleActionId, exception.status(), exception.getClass().getSimpleName());
      entity.setBulkUploadStatus(BulkUploadStatus.FAILED);
      entity.setResponse(withoutPasswords(exception.contentUTF8().getBytes(StandardCharsets.UTF_8)));
    } catch (Exception e) {
      log.error("Error while processing single request: {}", e.getMessage());
      if (e instanceof FumValidationException) {
        entity.setResponse(e.getMessage().getBytes(StandardCharsets.UTF_8));
      } else {
        log.error("unable to call the user create endpoint ");
        entity.setResponse("unable to call the user create endpoint".getBytes(StandardCharsets.UTF_8));
      }
      entity.setBulkUploadStatus(BulkUploadStatus.FAILED);
    }
    // The hash is only needed for the call above.
    entity.setRequest(withoutPasswords(entity.getRequest()));
    bulkUploadDetailsRepository.saveAndFlush(entity);
  }

  @SneakyThrows
  public void createSingleRequestAndPublish(
      BulkUpload bulkUpload, List<Map<String, String>> parsedFileContents, String requestId) {
    for (Map<String, String> map : parsedFileContents) {
      // Validation Failed
      if(map.containsKey(Constants.ERROR_MESSAGE)) {
        BulkUploadDetails bulkUploadDetails = new BulkUploadDetails();
        bulkUploadDetails.setBulkUpload(bulkUpload);
        bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.FAILED);
        bulkUploadDetails.setRequest(withoutPasswords(objectMapper.writeValueAsString(map).getBytes(StandardCharsets.UTF_8)));
        bulkUploadDetails.setResponse(map.get(Constants.ERROR_MESSAGE).getBytes(StandardCharsets.UTF_8));
        bulkUploadDetails.setCreatedBy(requestId);
        bulkUploadDetails.setCreatedDate(Timestamp.valueOf(LocalDateTime.now()));
        bulkUploadDetailsRepository.saveAndFlush(bulkUploadDetails);
        continue;
      }
      UserConfiguration userConfiguration = createUser(map);
      BulkUploadDetails bulkUploadDetails = new BulkUploadDetails();
      bulkUploadDetails.setBulkUpload(bulkUpload);
      if(StringUtils.isBlank(userConfiguration.getHashedPassword()) && StringUtils.isNotBlank(userConfiguration.getUsername())) {
        bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.FAILED);
        bulkUploadDetails.setResponse(Constants.ERROR_R2_NOT_FOUND_MESSAGE.getBytes(StandardCharsets.UTF_8));
      } else {
        bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
      }
      bulkUploadDetails.setRequest(objectMapper.writeValueAsString(userConfiguration).getBytes(
          StandardCharsets.UTF_8));
      bulkUploadDetails.setCreatedBy(requestId);
      bulkUploadDetails.setCreatedDate(Timestamp.valueOf(LocalDateTime.now()));
      BulkUploadDetails response = bulkUploadDetailsRepository.saveAndFlush(bulkUploadDetails);
      singleRequestPublisher.publishMessage(response);
    }
  }

  public Audit downloadStatusCsv(String batchId) {
    BulkUpload bulkUpload = bulkUploadRepository.findByBatchID(batchId).orElseThrow(() -> {
      log.error("Bulk upload not found for batch id: {}", batchId);
      return new FumNotFoundException(Constants.BULK_UPLOAD_NOT_FOUND_CODE,
          Constants.BULK_UPLOAD_NOT_FOUND_MESSAGE + batchId);
    });

    return Optional.ofNullable(bulkUpload.getGeneratedAudit())
        .orElseThrow(() -> new FumValidationException(Constants.BULK_UPLOAD_GENERATED_AUDIT_NOT_FOUND_CODE,
            Constants.BULK_UPLOAD_GENERATED_AUDIT_NOT_FOUND_MESSAGE + batchId));
  }

  @SneakyThrows
  private UserConfiguration createUser(Map<String, String> rawDataMap) {
    rawDataMap.keySet().forEach(key -> {
      if(StringUtils.isNotBlank(rawDataMap.get(key))) {
        rawDataMap.put(key, rawDataMap.get(key).trim());
      }
    });
    UserConfiguration user = new UserConfiguration();
    user.setFirmId(rawDataMap.get(Constants.FIRM_ID));
    user.setFirstName(rawDataMap.get(Constants.FIRST_NAME));
    user.setLastName(rawDataMap.get(Constants.LAST_NAME));
    user.setEmail(rawDataMap.get(Constants.EMAIL));
    user.setPreferredLanguage(rawDataMap.get(Constants.PREFERRED_LANGUAGE));
    user.setHashedPassword(rawDataMap.get(Constants.PASS_LABEL));
    if(StringUtils.isNotBlank(rawDataMap.get(Constants.SECURITY_ZONE_ID))) {
      user.setSecureZoneIds(
          Arrays.stream(rawDataMap.get(Constants.SECURITY_ZONE_ID).split(",")).map(String::trim).toList());

    }
    user.setOssUserId(rawDataMap.get(Constants.OSS_USER_ID));
    user.setOssProxyId(rawDataMap.get(Constants.OSS_USER_ID));
    user.setOssGroupId(rawDataMap.get(Constants.OSS_USER_ID));
    if(StringUtils.isNotBlank(rawDataMap.get(Constants.COMPASS_R2_ID))) {
      user.compassR2Id(rawDataMap.get(Constants.COMPASS_R2_ID));
      user.setUsername(rawDataMap.get(Constants.COMPASS_R2_ID));
    }

    if (StringUtils.isNotBlank(rawDataMap.get(Constants.EXTERNAL_CLIENT_ID))) {
      user.setExternalClientId(rawDataMap.get(Constants.EXTERNAL_CLIENT_ID));
      user.setUsername("");
    }

    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setPackageName(rawDataMap.get(Constants.PACKAGE_TEMPLATE_NAME));
    List<String> moduleOverrides = new ArrayList<>();
    if(StringUtils.isNotBlank(rawDataMap.get(Constants.FIRM_LEVEL_ACCESS)) && rawDataMap.get(Constants.FIRM_LEVEL_ACCESS).equalsIgnoreCase("false")){
      moduleOverrides.add("firm_level_access");
    }

    if(StringUtils.isNotBlank(rawDataMap.get(Constants.FIRM_LEVEL_ACCESS)) && rawDataMap.get(Constants.FIRM_LEVEL_ACCESS).equalsIgnoreCase("true")){
      featurePackage.setFeatures(Arrays.asList("firm_level_access"));
    }

    if(StringUtils.isNotBlank(rawDataMap.get(Constants.MODULE_OVERRIDES))){
      Arrays.stream(rawDataMap.get(Constants.MODULE_OVERRIDES).split(","))
          .map(String::trim)
          .filter(mo -> !mo.equalsIgnoreCase("firm_level_access"))
          .forEach(moduleOverrides::add);
    }
    featurePackage.setModuleOverrides(moduleOverrides);
    user.setFeaturePackage(featurePackage);

    if(StringUtils.isNotBlank(rawDataMap.get(Constants.RR_CODES))) {
      List<RRCodeRange> lst = Arrays.stream(rawDataMap.get(Constants.RR_CODES).split(","))
          .map(String::trim)
          .map(rr -> {
            String[] array = rr.split("-");
            return array.length == 2 ? new RRCodeRange().fromRRCode(array[0].trim()).toRRCode(array[1].trim())
                : new RRCodeRange().fromRRCode(array[0].trim()).toRRCode(array[0].trim());
          })
          .collect(Collectors.toList());
      user.setRrCodeRanges(lst);
    }

    user.setActivationDate(LocalDate.parse(rawDataMap.get(Constants.ACTIVATION_DATE), DateTimeFormatter.ofPattern("MM-dd-yyyy"))
            .atStartOfDay());
    return user;
  }

  private void validateUserConfiguration(UserConfiguration userConfiguration) {
    if(StringUtils.isBlank(userConfiguration.getHashedPassword()) && StringUtils.isNotBlank(userConfiguration.getUsername())) {
      throw new FumValidationException(Constants.BULK_UPLOAD_HASH_ERROR_CODE, Constants.BULK_UPLOAD_HASH_ERROR_MESSAGE);
    }
  }

  private byte[] withoutPasswords(byte[] json) {
    if (json == null || json.length == 0) {
      return json;
    }
    try {
      if (objectMapper.readTree(json) instanceof ObjectNode node) {
        node.remove(PASSWORD_FIELDS);
        return objectMapper.writeValueAsBytes(node);
      }
    } catch (JacksonException e) {
      // Not JSON (e.g. a plain error message): nothing to strip.
    }
    return json;
  }
}
