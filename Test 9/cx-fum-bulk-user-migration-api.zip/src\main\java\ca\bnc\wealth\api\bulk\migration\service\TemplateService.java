package ca.bnc.wealth.api.bulk.migration.service;

import static org.springframework.http.HttpHeaders.CONTENT_DISPOSITION;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.bulk.migration.feign.client.AuditLogManagementClient;
import ca.bnc.wealth.api.bulk.migration.utils.Constants;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadTemplateRepository;
import java.util.Objects;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class TemplateService {

  @Value("${bulk.template.name:BulkUserMigration}")
  private String templateName;

  @Autowired
  private BulkUploadTemplateRepository bulkUploadTemplateRepository;

  @Autowired
  private AuditLogManagementClient auditLogManagementClient;

  @Autowired
  private SystemTokenFactory systemTokenFactory;

  @SneakyThrows
  public Pair<String, ByteArrayResource> getAuditById(String templateFormat) {
    log.info("Getting audit by id");
    BulkUploadTemplate bulkUploadTemplate = bulkUploadTemplateRepository.findByTemplateName(templateName)
        .orElseThrow(() -> new FumValidationException(Constants.BULK_UPLOAD_TEMPLATE_NOT_FOUND_CODE,
            Constants.BULK_UPLOAD_TEMPLATE_NOT_FOUND_MESSAGE + templateName));

    Pair<String, ByteArrayResource> template = null;
    switch (templateFormat) {
      case "USER-MIGRATE-TEMPLATE":
        template = Pair.of(Constants.BULK_USER_MIGRATE_TEMPLATE, new ByteArrayResource(bulkUploadTemplate.getLayoutUser()));
        break;
      case "USER-PASSWORD-TEMPLATE":
        template = Pair.of(Constants.BULK_USER_PASSWORD_TEMPLATE, new ByteArrayResource(bulkUploadTemplate.getLayoutPassword()));
        break;
      default:
        throw new FumValidationException(Constants.BULK_UPLOAD_TEMPLATE_FORM_CODE, Constants.BULK_UPLOAD_TEMPLATE_FORM_MESSAGE);
    }

    return template;
  }

  public Pair<String, ByteArrayResource> getAuditById(long auditId) {
    String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);
    ResponseEntity<ByteArrayResource> response = auditLogManagementClient.getAuditById(token, auditId);

    return Pair.of(Objects.requireNonNull(response.getHeaders().get(CONTENT_DISPOSITION)).toString(), response.getBody());
  }
}
