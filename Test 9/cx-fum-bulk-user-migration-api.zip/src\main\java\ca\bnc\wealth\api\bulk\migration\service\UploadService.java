package ca.bnc.wealth.api.bulk.migration.service;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.bulk.migration.feign.client.AuditLogManagementClient;
import ca.bnc.wealth.api.bulk.migration.model.BulkUserUploadMetadata;
import ca.bnc.wealth.api.bulk.migration.utils.Constants;
import ca.bnc.wealth.common.bulk_user_migration.model.MigrationReportMetadataResponse;
import ca.bnc.wealth.common.bulk_user_migration.model.MigrationReportResponse;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.Audit;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AuditRepository;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@Service
public class UploadService {

    @Value("${bulk.template.name:BulkUserMigration}")
    private String templateName;

    @Autowired
    private BulkUploadTemplateRepository bulkUploadTemplateRepository;

    @Autowired
    private BulkUploadRepository bulkUploadRepository;

    @Autowired
    private AuditRepository auditRepository;

    @Autowired
    private CsvFileReadService csvFileReadService;

    @Autowired
    private BulkUploadFileValidation bulkUploadFileValidation;

    @Autowired
    private SingleRequestService singleRequestService;

    @Autowired
    private AuditLogManagementClient auditLogManagementClient;

    @Autowired
    private SystemTokenFactory systemTokenFactory;

    @Autowired
    private ObjectMapper objectMapper;

    public BulkUpload getBulkUploadByFormId(String formId) {
        return bulkUploadRepository.findById(Long.valueOf(formId))
            .orElseThrow(() -> {
                log.error("Bulk upload not found for form id: {}", formId);
                throw new FumNotFoundException(Constants.BULK_UPLOAD_NOT_FOUND_CODE,
                    Constants.BULK_UPLOAD_NOT_FOUND_MESSAGE + formId);
            });
    }

    public List<MigrationReportResponse> getAllBulkUserMigrations() {
        return bulkUploadRepository.findAll().stream()
                .map(this::toDto)
                .toList();
    }

    @SneakyThrows
    public BulkUpload uploadAndValidate(MultipartFile fileToUpload, String requestId) {
        BulkUploadTemplate bulkUploadTemplate = bulkUploadTemplateRepository.findByTemplateName(
                        templateName)
                .orElseThrow(() -> {
                    log.error("Template name not found for template name: {}", templateName);
                    return new FumValidationException(Constants.BULK_UPLOAD_TEMPLATE_NOT_FOUND_CODE,
                            Constants.BULK_UPLOAD_TEMPLATE_NOT_FOUND_MESSAGE + templateName);
                });
        Template templateRules = bulkUploadTemplate.getConfig();

        csvFileReadService.validateFile(fileToUpload, templateRules)
                .ifPresent(error -> {
                    log.error("Error validating file: {}", error);
                    throw new FumValidationException(Constants.BULK_UPLOAD_FILE_VALIDATION_ERROR_CODE,
                            error);
                });

        //Reading data from csv
        List<Map<String, String>> parsedFileContents = this.csvFileReadService.convertCsvFileToMap(fileToUpload, templateRules);

        String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);
        ResponseEntity<ca.bnc.wealth.common.audit_management.model.Audit> auditResponseEntity
            = auditLogManagementClient.uploadAudit(token, fileToUpload, "");
        Audit auditEntity = auditRepository.getReferenceById(
            Objects.requireNonNull(auditResponseEntity.getBody()).getAuditId());

        return createBulkUpload(bulkUploadTemplate, parsedFileContents, auditEntity, requestId);
    }

    @SneakyThrows
    public String migrateBulkUser(String formId, MultipartFile passwordFile, String requestId) {
        BulkUpload bulkUpload = getBulkUploadByFormId(formId);
        if (bulkUpload.getBulkUploadStatus() != BulkUploadStatus.UPLOADED) {
            throw new FumValidationException(Constants.BULK_UPLOAD_STATUS_ERROR_CODE,
                    Constants.BULK_UPLOAD_STATUS_ERROR_MESSAGE + bulkUpload.getBulkUploadStatus());
        }

        bulkUpload.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
        bulkUploadRepository.saveAndFlush(bulkUpload);

        String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);
        ResponseEntity<ByteArrayResource> response = auditLogManagementClient.getAuditById(token, bulkUpload.getAudit().getAuditId());
        ByteArrayResource doc = Objects.requireNonNullElse(response.getBody(), new ByteArrayResource(new byte[0]));
        BufferedReader fileReader = new BufferedReader(
                new InputStreamReader(doc.getInputStream(), StandardCharsets.UTF_8));

        List<Map<String, String>> parsedFileContents = this.csvFileReadService.convertCsvFileToMap(fileReader, bulkUpload.getBulkUploadTemplate().getConfig());

        inputFileErrorValidation(parsedFileContents);

        List<Map<String, String>> psList = this.csvFileReadService.convertCsvFileToMap(passwordFile, bulkUpload.getBulkUploadTemplate().getPasswordConfig(), false);

        Map<String, String> useNamePassword = psList.stream()
                .map(map -> Pair.of(map.get(Constants.COMPASS_R2_ID).toLowerCase(), map.get(Constants.PASS_LABEL)))
                // Without a merge function a duplicate R2 ID throws an exception whose message holds both hashes.
                .collect(Collectors.toMap(Pair::getLeft, Pair::getRight, (first, second) -> first));

        parsedFileContents.forEach(map -> map.put(Constants.PASS_LABEL, useNamePassword.get(map.get(Constants.COMPASS_R2_ID).toLowerCase())));

        singleRequestService.createSingleRequestAndPublish(bulkUpload, parsedFileContents, requestId);
        return bulkUpload.getBatchID();
    }

    public void inputFileErrorValidation(List<Map<String, String>> parsedFileContents) {

        BulkUploadTemplate bulkUploadTemplate = bulkUploadTemplateRepository.findByTemplateName(
                templateName)
            .orElseThrow(() -> {
                log.error("Template name not found for template name: {}", templateName);
                return new FumValidationException(Constants.BULK_UPLOAD_TEMPLATE_NOT_FOUND_CODE,
                    Constants.BULK_UPLOAD_TEMPLATE_NOT_FOUND_MESSAGE + templateName);
            });
        Template templateRules = bulkUploadTemplate.getConfig();

        Map<String, List<Long>> validation = this.bulkUploadFileValidation.validation(
            parsedFileContents, templateRules);
        if (!validation.isEmpty()) {
            validation.forEach((key, value) -> {
                if (!value.isEmpty()) {
                    value.forEach(rowNumber -> {
                        String errorMessage = getValidationErrorMessage(key);
                        parsedFileContents.get(rowNumber.intValue() - 2).computeIfAbsent(Constants.STATUS, k -> BulkUploadStatus.FAILED.name());
                        parsedFileContents.get(rowNumber.intValue() - 2).computeIfPresent(Constants.ERROR_MESSAGE, (k, v) -> v + "," + errorMessage);
                        parsedFileContents.get(rowNumber.intValue() - 2).computeIfAbsent(Constants.ERROR_MESSAGE, k -> errorMessage);
                    });
                }
            });
        }
    }

    public String getValidationErrorMessage(String key) {
        try {
            String header = key.contains("Mandatory_Field") ? key.split("Mandatory_Field ")[1] : key.split("Not_Supported_Value ")[1];
            switch (header) {
                case Constants.PACKAGE_TEMPLATE_NAME:
                    return "New Compass - Role value is missing or incorrect header";
                case Constants.PREFERRED_LANGUAGE:
                    return "Missing Preferred Language or incorrect header";
                case Constants.ACTIVATION_DATE:
                    if(key.contains("Mandatory_Field"))
                        return "Missing Migration Date or incorrect header";
                    else
                        return "Invalid Migration Date";
                case Constants.FIRM_ID:
                    return "Missing Firm ID or incorrect header";
                case Constants.FIRST_NAME:
                    return "Missing user's first name on incorrect header";
                case Constants.LAST_NAME:
                    return "Missing user's last name or incorrect header";
                case Constants.EMAIL:
                    return "Missing user's email address or incorrect header";
                case Constants.SECURITY_ZONE_ID:
                    return "Missing Secured Zone User ID or incorrect header";
            }
        } catch (Exception exception) {
            log.info("Validation error for Mandatory field {}", key);
        }
        return "Invalid Data";
    }

    public BulkUploadStatus getBulkUserMigrationStatus(String migrationId) {
        BulkUpload bulkUpload = bulkUploadRepository.findByBatchID(migrationId)
                .orElseThrow(() -> {
                    log.error("Bulk upload not found for migration id: {}", migrationId);
                    throw new FumNotFoundException(Constants.BULK_UPLOAD_NOT_FOUND_CODE,
                            Constants.BULK_UPLOAD_NOT_FOUND_MESSAGE + migrationId);
                });

        return bulkUpload.getBulkUploadStatus();
    }

    public MigrationReportMetadataResponse getMigrationReportMetadata(String migrationId) {
        BulkUpload bulkUpload = bulkUploadRepository.findByBatchID(migrationId).orElseThrow(() -> {
            log.error(Constants.BULK_UPLOAD_NOT_FOUND_MESSAGE + migrationId);
            return new FumNotFoundException(Constants.BULK_UPLOAD_NOT_FOUND_CODE,
                Constants.BULK_UPLOAD_NOT_FOUND_MESSAGE + migrationId);
        });
        MigrationReportMetadataResponse migrationReportMetadataResponse = new MigrationReportMetadataResponse();
        migrationReportMetadataResponse.setMetadata(toList(bulkUpload));
        return migrationReportMetadataResponse;
    }

    private BulkUpload createBulkUpload(BulkUploadTemplate bulkUploadTemplate,
        List<Map<String, String>> parsedFileContents, Audit audit, String requestId) {
        BulkUpload entity = new BulkUpload();
        long sequence = bulkUploadRepository.generateID("\"IAM_V2\".\"bulk_user_migration_request_sequence\"");
        entity.setBatchID(formatId("B", "", "%010d", sequence));
        entity.setBulkUploadTemplate(bulkUploadTemplate);
        entity.setAudit(audit);
        entity.setBulkUploadStatus(BulkUploadStatus.UPLOADED);
        entity.setTotalRecords(parsedFileContents.size());
        entity.setTotalSuccess(0);
        entity.setTotalFailed(0);
        entity.setTotalPending(parsedFileContents.size());
        entity.setCreatedBy(requestId);
        entity.setCreatedDate(Timestamp.valueOf(LocalDateTime.now()));
        return bulkUploadRepository.saveAndFlush(entity);
    }

    private String formatId(@Nullable String prefix, @Nullable String suffix, @NonNull String format,
                            @NonNull Long id) {
        format = StringUtils.isBlank(prefix) ? format : prefix + format;
        format = StringUtils.isBlank(suffix) ? format : format + suffix;
        return String.format(format, id);
    }

    private MigrationReportResponse toDto(BulkUpload bulkUpload) {
        MigrationReportResponse migrationReportResponse = new MigrationReportResponse();
        migrationReportResponse.setMigrationId(bulkUpload.getBatchID());
        migrationReportResponse.setMetadata(toList(bulkUpload));
        return migrationReportResponse;
    }

    protected List<Object> toList(BulkUpload bulkUpload) {
        BulkUserUploadMetadata bulkUserUploadMetadata = new BulkUserUploadMetadata();
        if(bulkUpload.getAudit() != null)
          bulkUserUploadMetadata.setFilename(bulkUpload.getAudit().getFileName());
        bulkUserUploadMetadata.setStatus(bulkUpload.getBulkUploadStatus().name());
        bulkUserUploadMetadata.setTotalRecords(bulkUpload.getTotalRecords());
        bulkUserUploadMetadata.setSuccessfulRecords(bulkUpload.getTotalSuccess());
        bulkUserUploadMetadata.setFailedRecords(bulkUpload.getTotalFailed());
        bulkUserUploadMetadata.setPendingRecords(bulkUpload.getTotalPending());
        bulkUserUploadMetadata.setUploadedDate(bulkUpload.getCreatedDate().toLocalDateTime());

        Map<String, String> map = objectMapper.convertValue(bulkUserUploadMetadata, new TypeReference<>(){});
        return new ArrayList<>(map.entrySet());
    }
}

