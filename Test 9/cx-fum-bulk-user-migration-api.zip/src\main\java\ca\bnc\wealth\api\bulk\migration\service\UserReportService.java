package ca.bnc.wealth.api.bulk.migration.service;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.bulk.migration.feign.client.ContentApiClient;
import ca.bnc.wealth.api.bulk.migration.utils.Constants;
import ca.bnc.wealth.api.bulk.migration.utils.UserHeaderEnum;
import ca.bnc.wealth.common.bulk_user_migration.model.DownloadUserReportRequest;
import ca.bnc.wealth.common.fum.model.UserStateDescriptionEnum;
import ca.bnc.wealth.common.fum.service.MftService;
import ca.bnc.wealth.common.fum.service.UserStatusService;
import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignment;
import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserConfigSearchMaterializedViewRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.s3.S3PropertyInterface;
import ca.bnc.wealth.common.s3.S3Service;
import tools.jackson.databind.json.JsonMapper;
import java.io.StringWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.s3.model.S3Object;

@Slf4j
@Service
public class UserReportService {

  List<UserHeaderEnum> headers = List.of(UserHeaderEnum.Firm_ID, UserHeaderEnum.Firm_Name, UserHeaderEnum.IDP_Subject, UserHeaderEnum.CX_User_ID,
      UserHeaderEnum.First_Name, UserHeaderEnum.Last_Name, UserHeaderEnum.Email_Address, UserHeaderEnum.Preferred_Language, UserHeaderEnum.User_Status, UserHeaderEnum.User_Role, UserHeaderEnum.CX_Login_Date);

  Map<String, String> packageTranslations = Map.ofEntries(
    Map.entry("AdminAccountsAndProfiles_V1.17", "Admin Accounts and Profiles"),
    Map.entry("AdminAllButNotTrade_V1.17" , "Admin All but not trade"),
    Map.entry("ManageAll_V1.17" , "Manage All"),
    Map.entry("ManageAllButNotTrade_V1.16" , "Manage All but not trade"),
    Map.entry("AdminAll_V1.17" , "Admin All"),
    Map.entry("AdminOrders_V1.17" , "Admin Orders"),
    Map.entry("AdminServiceRequests_V1.17" , "Admin Service Requests"),
    Map.entry("ManageAccountAssets_V1.17" , "Manage Account Assets"),
    Map.entry("ManageAccountsAndProfiles_V1.17" , "Manage Accounts and Profiles"),
    Map.entry("ManageFirmAndUser_V1.17" , "Manage Firm and User"),
    Map.entry("ManageOrders_V1.17" , "Manage Orders"),
    Map.entry("ManagePostTrade_V1.17" , "Manage Post Trade"),
    Map.entry("ManageServiceRequests_V1.17" , "Manage Service Requests"),
    Map.entry("ManageTransactions_V1.17" , "Manage Transactions"),
    Map.entry("ProcessAccounts_V1.17" , "Process Accounts and Profiles"),
    Map.entry("ViewOnlyConfidentialProfile_V1.17" , "View Only, Confidential Profile")
  );

  @Autowired
  private IamUserConfigurationRepository iamUserConfigurationRepository;

  @Autowired
  private UserConfigSearchMaterializedViewRepository userConfigSearchMaterializedViewRepository;

  @Autowired
  private UserAssignmentRepository userAssignmentRepository;

  @Autowired
  private FirmRepository firmRepository;

  @Autowired
  private PackageTemplateRepository packageTemplateRepository;

  @Autowired
  private FeaturePackageRepository featurePackageRepository;

  @Autowired
  private ContentApiClient contentApiClient;

  @Autowired
  private SystemTokenFactory systemTokenFactory;

  @Autowired
  private UserStatusService userStatusService;

  @Autowired
  private MftService mftService;

  @Autowired
  private S3Service s3Service;

  @Autowired
  private S3PropertyInterface s3PropertyInterface;

  @Value("${s3.userReport.bucket:#{null}}")
  private String bucket;

  @Value("${s3.userReport.keyPrefix:#{null}}")
  private String keyPrefix;

  @Value("${s3.userReport.storeLatestRecordCount:10}")
  private int storeLatestRecordCount;

  @Async
  public void generateUserReportAsync(DownloadUserReportRequest downloadUserReportRequest) {
    generateUserReport(downloadUserReportRequest.getFirmId(), downloadUserReportRequest.getCsvHeaderMapping(), downloadUserReportRequest.getCsvHeaderOrder(), downloadUserReportRequest.getFileNameStartsWith(),
        downloadUserReportRequest.getActiveUsers());
  }

  @Async
  public void generateUserReportAsync() {
    generateUserReport(null, null, null, null, null);
  }

  public Pair<String,String> generateUserReport(String firmId, Map<String, String> csvHeaderMapping, List<String> csvHeaderOrder, String fileNameStartsWith, Boolean activeUsers) {
    List<Map<UserHeaderEnum, Object>> users = getUsers(firmId, activeUsers);
    log.info("User report generated with {} users", users.size());
    StringWriter sw = csvHeaderMapping != null && !csvHeaderMapping.isEmpty() ? getCsvStringWriter(csvHeaderMapping, csvHeaderOrder, users) : getCsvStringWriter(headers, users);

    String filePrefix = StringUtils.isNotBlank(fileNameStartsWith) ? fileNameStartsWith : "User_Report";
    String fileName = filePrefix + "_" + getDateString() + ".csv";
    String fileContent = sw.toString();

    //log.info("Uploading user report to MFT");
    //mftService.sendFile(fileName, fileContent, "/Inbox");

    log.info("User report uploaded to S3");
    s3Service.uploadWithCsvBom(s3PropertyInterface.getS3AccessFor(), bucket, keyPrefix, fileName, fileContent);

    //log.info("deleting old records from S3");
    //deleteOldS3Records();

    return Pair.of(fileName, fileContent);
  }

  @SneakyThrows
  private StringWriter getCsvStringWriter(List<UserHeaderEnum> headers, List<Map<UserHeaderEnum, Object>> lst) {
    StringWriter sw = new StringWriter();
    CSVFormat csvFormat = CSVFormat.DEFAULT.builder()
        .setHeader(headers.stream().map(UserHeaderEnum::name).toArray(String[]::new))
        .setDelimiter(",")
        .build();

    CSVPrinter printer = new CSVPrinter(sw, csvFormat);

    for (Map<UserHeaderEnum, Object> details : lst) {
      printer.printRecord(headers.stream().map(details::get).collect(Collectors.toList()));
    }
    return sw;
  }

  @SneakyThrows
  private StringWriter getCsvStringWriter(Map<String, String> csvHeaderMapping, List<String> csvHeaderOrder,List<Map<UserHeaderEnum, Object>> lst) {
    List<UserHeaderEnum> orderedHeaders = Optional.ofNullable(csvHeaderOrder).map(header -> header.stream()
          .map(csvHeaderMapping::get)
          .map(this::getUserHeaderEnum)
          .filter(Objects::nonNull)
          .toList()).orElse(headers);
    StringWriter sw = new StringWriter();
    CSVFormat csvFormat = CSVFormat.DEFAULT.builder()
        .setHeader(orderedHeaders.stream().map(UserHeaderEnum::name).toArray(String[]::new))
        .setDelimiter(",")
        .build();

    CSVPrinter printer = new CSVPrinter(sw, csvFormat);

    for (Map<UserHeaderEnum, Object> details : lst) {
      printer.printRecord(orderedHeaders.stream().map(details::get).collect(Collectors.toList()));
    }
    return sw;
  }

  private List<Map<UserHeaderEnum, Object>> getUsers(String firmId, Boolean activeUsers) {
    List<Map<UserHeaderEnum, Object>> users = new ArrayList<>();

    Map<String, Firm> idpFirmMap = getUserFirmMap();
    Map<String, String> idpUserRoleMap = getUserRoleMap();
    Map<String, Object>idpLastLogin = new HashMap<>();
    iamUserConfigurationRepository.findAll().forEach(user -> idpLastLogin.put(user.getIdpSubject(), user.getLastLoginDate()));
    Map<String,String> contentMap = packageTranslations;

    getUserFromView(firmId, activeUsers).forEach(user -> {
      Map<UserHeaderEnum, Object> userMap = new HashMap<>();
      userMap.put(UserHeaderEnum.Firm_ID, user.getFirmId());
      userMap.put(UserHeaderEnum.Firm_Name, Optional.ofNullable(idpFirmMap.get(user.getIdpSubject())).map(Firm::getName).orElse(""));
      userMap.put(UserHeaderEnum.IDP_Subject, user.getIdpSubject());
      userMap.put(UserHeaderEnum.CX_User_ID, user.getUsername());
      userMap.put(UserHeaderEnum.First_Name, user.getFirstName());
      userMap.put(UserHeaderEnum.Last_Name, user.getLastName());
      userMap.put(UserHeaderEnum.Email_Address, user.getEmail());
      userMap.put(UserHeaderEnum.Preferred_Language, Optional.ofNullable(user.getPreferredLanguageType()).map(PreferredLanguageType::name).orElse(""));
      userMap.put(UserHeaderEnum.User_Status, userStatusService.getUiUserStatus(user));
      if (Boolean.TRUE.equals(activeUsers)) {
        userMap.put(UserHeaderEnum.User_State, "Active");
      } else {
        userMap.put(UserHeaderEnum.User_State, user.getActive() ? "Active" : "Inactive");
      }
      userMap.put(UserHeaderEnum.User_Role, getContentValue(idpUserRoleMap.get(user.getIdpSubject()), contentMap));
      userMap.put(UserHeaderEnum.CX_Login_Date,idpLastLogin.get(user.getIdpSubject()));
      userMap.put(UserHeaderEnum.RR_Code,user.getRrRanges());
      users.add(userMap);
    });

    if (users.size() > 10000) {
      log.warn("QUERY_RESULT_SIZE: method=getUsers, resultCount={} - exceeds threshold", users.size());
    } else {
      log.info("QUERY_RESULT_SIZE: method=getUsers, resultCount={}", users.size());
    }

    return users;
  }

  private List<UserConfigSearchMaterializedView> getUserFromView(String firmId, Boolean activeUsers) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    if (Boolean.TRUE.equals(activeUsers)) {
      fieldValueMap.put("stateDescription", Pair.of(EnumQueryCriteria.IN,
          List.of(UserStateDescriptionEnum.STAGED.dbValue, UserStateDescriptionEnum.PENDING_USER_ACTION.dbValue,
              UserStateDescriptionEnum.ACTIVE.dbValue, UserStateDescriptionEnum.PASSWORD_RESET.dbValue,
              UserStateDescriptionEnum.PASSWORD_EXPIRED.dbValue, UserStateDescriptionEnum.LOCKED.dbValue)));
    }

    if( firmId == null || firmId.isEmpty()) {
      List<UserConfigSearchMaterializedView> allFirmsUsers = userConfigSearchMaterializedViewRepository.findAll(Sort.by(Direction.ASC, "firmId","firstName", "lastName"));
      log.warn("USER_REPORT_EXPORT: firmId=null, scope=ALL_FIRMS, recordCount={} - cross-firm export, no firm-level isolation applied", allFirmsUsers.size());
      return allFirmsUsers;
    }
    fieldValueMap.put("firmId", Pair.of(EnumQueryCriteria.EQUALS, firmId));
    Specification<UserConfigSearchMaterializedView> specification = new Specification<>(fieldValueMap);
    List<UserConfigSearchMaterializedView> firmUsers = userConfigSearchMaterializedViewRepository.findAll(specification, Sort.by(Direction.ASC, "firmId","firstName", "lastName"));
    log.info("USER_REPORT_EXPORT: firmId={}, recordCount={}", firmId, firmUsers.size());
    return firmUsers;
  }

  private Map<String, String>  getUserRoleMap() {
    Map<String, List<UserAssignment>> userRoleAssignments = userAssignmentRepository.findAllByAssignmentType(UserAssignmentType.P).stream()
        .collect(Collectors.groupingBy(UserAssignment::getIdpSubject));

    List<PackageTemplate> pts = packageTemplateRepository.findByType(PackageType.U);
    Map<Long, String> fpPtNameMap = new HashMap<>();

    pts.forEach(pt -> featurePackageRepository.findAllByPackageTemplate(pt).forEach(fp -> fpPtNameMap.put(fp.getFeaturePackageId(), pt.getName())));

    Map<String, String> idpUserRoleMap = new HashMap<>();
    userRoleAssignments.forEach((idpSubject, userAssignments) -> {
      idpUserRoleMap.put(idpSubject, fpPtNameMap.get(userAssignments.get(0).getAssigneeId().longValue()));
    });
    return idpUserRoleMap;
  }

  private Map<String, Firm> getUserFirmMap() {
    Map<String, List<UserAssignment>> firmAssignmentsMap = userAssignmentRepository.findAllByAssignmentType(UserAssignmentType.F).stream()
        .collect(Collectors.groupingBy(UserAssignment::getIdpSubject));
    Set<Long> firmIds = firmAssignmentsMap.values().stream().flatMap(List::stream)
        .map(UserAssignment::getAssigneeId)
        .map(Long::valueOf)
        .collect(Collectors.toSet());

    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("firmEntityId", Pair.of(EnumQueryCriteria.IN, firmIds.stream().toList()));
    Specification<Firm> spec = new Specification<>(fieldValueMap);
    Map<Long, Firm> firms = firmRepository.findAll(spec).stream().collect(Collectors.toMap(Firm::getFirmEntityId, firm -> firm));

    Map<String, Firm> idpFirmMap = new HashMap<>();
    firmAssignmentsMap.forEach((idpSubject, firmAssignments) -> {
      Firm firm = firms.get(firmAssignments.get(0).getAssigneeId().longValue());
      idpFirmMap.put(idpSubject, firm);
    });
    return idpFirmMap;
  }

  private void deleteOldS3Records() {
    List<S3Object> s3Objects = s3Service.getListOfS3Objects(s3PropertyInterface.getS3AccessFor(), bucket, keyPrefix).stream()
        .sorted(Comparator.comparing(S3Object::lastModified))
        .toList();

    int toDeleteCount = s3Objects.size() - storeLatestRecordCount;
    if (toDeleteCount > 0) {
      List<String> keys = s3Objects.stream()
          .limit(toDeleteCount)
          .map(S3Object::key)
          .toList();
      s3Service.deleteS3Object(s3PropertyInterface.getS3AccessFor(), bucket, keys);
    }
  }

  private Map<String,String> getContentMap() {
    try {
      String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);
      ResponseEntity<Map<String,String>> response = contentApiClient.getTransulation(token, "en", JsonMapper.builderWithJackson2Defaults().build().writeValueAsString(List.of("platform")));
      return Optional.ofNullable(response).map(ResponseEntity::getBody).orElse(new HashMap<>());
    } catch (Exception e) {
      log.warn("Error while getting content map", e);
      return new HashMap<>();
    }
  }

  String getContentValue(String role, Map<String,String> contentMap) {
    // Null check for immutable map
    if (role == null) {
      return null;
    }
    return contentMap.getOrDefault(role, role);
  }

  private String getDateString() {
    LocalDate today = LocalDate.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
    return today.format(formatter);
  }

  private UserHeaderEnum getUserHeaderEnum(String header) {
    try {
      return UserHeaderEnum.valueOf(header);
    } catch (IllegalArgumentException e) {
      log.warn("Invalid header: {}", header);
      return null;
    }
  }

}
