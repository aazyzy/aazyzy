package ca.bnc.wealth.api.bulk.migration.utils;

public class Constants {
  public static final String ROW_NUMBER = "row-number";
  public static final String FIRM_ID = "Firm ID*";
  public static final String FIRST_NAME = "First Name*";
  public static final String LAST_NAME = "Last Name*";
  public static final String EMAIL = "Email Address*";
  public static final String PREFERRED_LANGUAGE = "Preferred Language*";
  public static final String PASS_LABEL = "Password*";
  public static final String SECURITY_ZONE_ID = "SecureZone ID*";
  public static final String OSS_USER_ID = "OSS User ID";
  public static final String COMPASS_R2_ID = "CR2 User ID";
  public static final String SSO_USER_ID = "SSO User ID";
  public static final String PACKAGE_TEMPLATE_NAME = "Role*";
  public static final String FIRM_LEVEL_ACCESS = "Firm Level Access*";
  public static final String RR_CODES = "RR Code Assignment";
  public static final String MODULE_OVERRIDES = "Module Overrides";
  public static final String ACTIVATION_DATE = "Activation Date*";
  public static final String EXTERNAL_CLIENT_ID = "External Client Id";
  public static final String BULK_UPLOAD_STATUS = "bulkUploadStatus";
  public static final String STATUS = "Status";
  public static final String ERROR_MESSAGE = "Error Message";
  public static final String ERROR_OKTA_PROFILE = "error.okta.profile.found";
  public static final String ERROR_INVALID_FIRM_ID = "error.firmId.invalid";
  public static final String ERROR_R2_PW = "error.hashedPassword.invalid";
  public static final String ERROR_R2_FOUND = "error.r2.withcpxsub";
  public static final String ERROR_EMAIL_INVALID = "error.email.invalid.format";
  public static final String ERROR_OKTA_CREATE = "error.okta.profile.creation";
  public static final String ERROR_R2_NOT_FOUND = "error.r2.notfound";
  public static final String ERROR_RR_CODE_INVALID = "error.rrcode.invalid";
  public static final String ERROR_SSO_EXIST = "error.bngfReferenceId.exist";

  public static final String ERROR_R2_NOT_FOUND_MESSAGE = "R2 ID does not exist";

  public static final String BULK_UPLOAD_TEMPLATE_NOT_FOUND_CODE = "bulk.user.upload.template.notFound";
  public static final String BULK_UPLOAD_TEMPLATE_NOT_FOUND_MESSAGE = "Template rules not found for template name: ";
  public static final String BULK_UPLOAD_FILE_VALIDATION_ERROR_CODE = "bulk.user.upload.file.validation.error";
  public static final String BULK_UPLOAD_FILE_READ_ERROR_CODE = "bulk.user.upload.file.read.error";
  public static final String BULK_UPLOAD_TEMPLATE_FORM_CODE = "bulk.user.upload.template.form.validation.error";
  public static final String BULK_UPLOAD_TEMPLATE_FORM_MESSAGE = "Supported template formatat USER-MIGRATE-TEMPLATE and USER-PASSWORD-TEMPLATE";
  public static final String BULK_UPLOAD_NOT_FOUND_CODE = "bulk.user.upload.notFound";
  public static final String BULK_UPLOAD_NOT_FOUND_MESSAGE = "Bulk upload not found for migration id: ";
  public static final String BULK_UPLOAD_DETAIL_NOT_FOUND_CODE = "bulk.user.upload.detail.notFound";
  public static final String BULK_UPLOAD_DETAIL_NOT_FOUND_MESSAGE = "Bulk upload detail not found for action id: ";
  public static final String BULK_UPLOAD_PASSWORD_FILE_VALIDATION_ERROR_CODE = "bulk.user.upload.password.file.validation.error";
  public static final String BULK_UPLOAD_PASSWORD_FILE_VALIDATION_ERROR_MESSAGE = "Password file does not contain password for user: ";
  public static final String BULK_UPLOAD_STATUS_ERROR_CODE = "bulk.user.upload.status.error";
  public static final String BULK_UPLOAD_STATUS_ERROR_MESSAGE = "Bulk upload status is not UPLOADED, current status: ";
  public static final String BULK_UPLOAD_HASH_ERROR_CODE = "bulk.user.upload.hashPassword.error";
  public static final String BULK_UPLOAD_HASH_ERROR_MESSAGE = "Password is required";
  public static final String BULK_UPLOAD_GENERATED_AUDIT_NOT_FOUND_CODE = "bulk.user.upload.generated.audit.notFound";
  public static final String BULK_UPLOAD_GENERATED_AUDIT_NOT_FOUND_MESSAGE = "Generated audit not found for migration id: ";
  public static final String BULK_USER_MIGRATE_TEMPLATE = "User_Template.csv";
  public static final String BULK_USER_PASSWORD_TEMPLATE = "Password_Template.csv";
  public static final String SYSTEM_TOKEN_FUM = "fum";
  private Constants() {
    throw new IllegalStateException("Utility class");
  }
}
