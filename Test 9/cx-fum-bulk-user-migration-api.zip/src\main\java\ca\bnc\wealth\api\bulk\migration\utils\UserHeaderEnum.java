package ca.bnc.wealth.api.bulk.migration.utils;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum UserHeaderEnum {
  Firm_ID("Firm ID"),
  Firm_Name("Firm Name"),
  IDP_Subject("IDP Subject"),
  CX_User_ID("CX User ID"),
  First_Name("First Name"),
  Last_Name("Last Name"),
  Email_Address("Email Address"),
  Preferred_Language("Preferred Language"),
  User_Status("User Status"),
  User_State("User State"),
  User_Role("User Role"),
  CX_Login_Date("CX Login Date"),
  RR_Code("RR Code");

  private final String header;

  public String getHeader() {
    return header;
  }
}
