package ca.bnc.wealth.api.bulk.migration.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ca.bnc.wealth.api.authorization.security.SecurityConfigAdapter;
import ca.bnc.wealth.api.authorization.security.test.TestAuthConfiguration;
import ca.bnc.wealth.api.bulk.migration.service.SingleRequestService;
import ca.bnc.wealth.api.bulk.migration.service.TemplateService;
import ca.bnc.wealth.api.bulk.migration.service.UploadService;
import ca.bnc.wealth.api.bulk.migration.service.UserReportService;
import ca.bnc.wealth.api.bulk.migration.utils.MockData;
import ca.bnc.wealth.common.bulk_user_migration.model.DownloadUserReportRequest;
import ca.bnc.wealth.common.bulk_user_migration.model.MigrationReportMetadataResponse;
import ca.bnc.wealth.common.bulk_user_migration.model.MigrationReportResponse;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;
import java.util.List;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMultipartHttpServletRequestBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@WebMvcTest(properties = {"spring.profiles.active=test"})
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@ContextConfiguration(
    classes = {
        SecurityConfigAdapter.class,
        TestAuthConfiguration.class,
        BulkUserMigrationController.class,
        ca.bnc.wealth.common.exception.handler.ServiceExceptionHandler.class,
        ca.bnc.wealth.common.spring.microservice.starter.core.exception.GlobalDefaultExceptionHandler
            .class
    })
public class BulkUserMigrationControllerTest {

  @Autowired
  private WebApplicationContext webApplicationContext;

  @Autowired
  private MockMvc mockMvc;

  @Autowired
  private ObjectMapper objectMapper;

  @MockitoBean
  private TemplateService templateService;

  @MockitoBean
  private UploadService uploadService;

  @MockitoBean
  private SingleRequestService singleRequestService;

  @MockitoBean
  private UserReportService userReportService;

  @Before
  public void setup() {
    mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext)
        .apply(springSecurity()).build();
  }

  @Test
  public void testGetTemplateByTemplateFormat_whenTemplateExists_shouldReturn200() throws Exception {
    Pair<String, ByteArrayResource> pair = Pair.of("1", new ByteArrayResource(new byte[]{}));
    doReturn(pair).when(templateService).getAuditById(any());
    MvcResult mvcResult = mockMvc
        .perform(get("/templates/{template-format}", "template", "csv")
            .header(HttpHeaders.AUTHORIZATION, ""))
        .andExpect(status().isOk())
        .andReturn();

    assertEquals("text/csv", mvcResult.getResponse().getContentType());
  }

  @Test
  public void testUploadBulkUserDetails_whenUploadAndValidationSuccessful_shouldReturn200() throws Exception {
    when(uploadService.uploadAndValidate(any(), any())).thenReturn(MockData.getBulkUpload());

    MockMultipartHttpServletRequestBuilder multipart =
        (MockMultipartHttpServletRequestBuilder)
            multipart("/templates/{template-format}", "USER-MIGRATE-TEMPLATE")
                .with(
                    request -> {
                      request.setMethod(HttpMethod.POST.name());
                      return request;
                    });

    MockMultipartFile file =
        new MockMultipartFile(
            "file",
            "audit-input.json",
            MediaType.APPLICATION_JSON_VALUE,
            "{ \"key\": \"value\" }".getBytes());
    MvcResult mvcResult =
        mockMvc
            .perform(multipart.file(file).header(HttpHeaders.AUTHORIZATION, "").with(csrf()))
            .andExpect(status().isOk())
            .andReturn();

    String response = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
        String.class);
    assertEquals(String.valueOf(MockData.getBulkUpload().getBulkUploadID()), response);
  }

  @Test
  public void testUploadBulkUserDetails_whenTemplateFormatInvalid_shouldThrow400() throws Exception {
    when(uploadService.uploadAndValidate(any(), any())).thenReturn(MockData.getBulkUpload());

    MockMultipartHttpServletRequestBuilder multipart =
        (MockMultipartHttpServletRequestBuilder)
            multipart("/templates/{template-format}", "INVALID")
                .with(
                    request -> {
                      request.setMethod(HttpMethod.POST.name());
                      return request;
                    });

    MockMultipartFile file =
        new MockMultipartFile(
            "file",
            "audit-input.json",
            MediaType.APPLICATION_JSON_VALUE,
            "{ \"key\": \"value\" }".getBytes());

    mockMvc
        .perform(multipart.file(file).header(HttpHeaders.AUTHORIZATION, "").with(csrf()))
        .andExpect(status().isBadRequest());
  }

  @Test
  public void testMigrateBulkUser_whenMigrationSuccessful_shouldReturn200() throws Exception {
    when(uploadService.migrateBulkUser(any(), any(), any())).thenReturn(MockData.getBulkUpload().getBatchID());

    MockMultipartHttpServletRequestBuilder multipart =
        (MockMultipartHttpServletRequestBuilder)
            multipart("/migrations")
                .with(
                    request -> {
                      request.setMethod(HttpMethod.POST.name());
                      return request;
                    });

    MockMultipartFile file =
        new MockMultipartFile(
            "file",
            "audit-input.json",
            MediaType.APPLICATION_JSON_VALUE,
            "{ \"key\": \"value\" }".getBytes());
    MvcResult mvcResult =
        mockMvc
            .perform(multipart
                .file(file)
                .header(HttpHeaders.AUTHORIZATION, "")
                .param("x-nbin-cx-form-id", "1")
                .with(csrf()))
            .andExpect(status().isOk())
            .andReturn();

    String response = objectMapper.readValue(mvcResult.getResponse().getContentAsString(),
        String.class);
    assertEquals(String.valueOf(MockData.getBulkUpload().getBatchID()), response);
  }

  @Test
  public void testGetBulkUploadAuditByFormId_whenAuditExists_shouldReturn200() throws Exception {
    Pair<String, ByteArrayResource> pair = Pair.of("1", new ByteArrayResource(new byte[]{}));
    when(uploadService.getBulkUploadByFormId(any())).thenReturn(MockData.getBulkUpload());
    doReturn(pair).when(templateService).getAuditById(anyLong());
    MvcResult mvcResult = mockMvc
        .perform(get("/forms/{form-id}", "123")
            .header(HttpHeaders.AUTHORIZATION, ""))
        .andExpect(status().isOk())
        .andReturn();

    assertEquals("text/csv", mvcResult.getResponse().getContentType());
  }

  @Test
  public void testGetBulkUploadAuditByFormId_whenAuditNotFound_shouldReturn404() throws Exception {
    when(uploadService.getBulkUploadByFormId(any())).thenThrow(FumNotFoundException.class);
    mockMvc
        .perform(get("/forms/{form-id}", "123")
            .header(HttpHeaders.AUTHORIZATION, ""))
        .andExpect(status().isNotFound());
  }

  @Test
  public void testDownloadAllBulkUserMigrationReports_whenReportsExists_shouldReturn200() throws Exception {
    when(uploadService.getAllBulkUserMigrations()).thenReturn(List.of(MockData.getMigrationReportResponse()));
    MvcResult mvcResult = mockMvc
        .perform(get("/reports")
            .header(HttpHeaders.AUTHORIZATION, ""))
        .andExpect(status().isOk())
        .andReturn();

    List<MigrationReportResponse> response = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), new TypeReference<>() {});
    assertEquals(MockData.getMigrationReportResponse().getMigrationId(), response.get(0).getMigrationId());
    assertEquals(MockData.getMigrationReportResponse().getMetadata().size(), response.get(0).getMetadata().size());
  }

  @Test
  public void testDownloadBulkUserMigrationReport_whenUploadExists_shouldReturn200() throws Exception {
    when(singleRequestService.downloadStatusCsv(any())).thenReturn(MockData.getAuditEntity());
    MvcResult mvcResult = mockMvc
        .perform(get("/reports/{migration-id}", "123")
            .header(HttpHeaders.AUTHORIZATION, ""))
        .andExpect(status().isOk())
        .andReturn();

    assertEquals("text/csv", mvcResult.getResponse().getContentType());
  }

  @Test
  public void testGetBulkUserMigrationStatus_whenUploadExists_shouldReturn200() throws Exception {
    when(uploadService.getBulkUserMigrationStatus(any())).thenReturn(BulkUploadStatus.SUCCESS);
    MvcResult mvcResult = mockMvc
        .perform(get("/migrations/{migration-id}", "B0000001")
            .header(HttpHeaders.AUTHORIZATION, ""))
        .andExpect(status().isOk())
        .andReturn();

    assertEquals(BulkUploadStatus.SUCCESS.name(), mvcResult.getResponse().getContentAsString());
  }

  @Test
  public void testGetBulkUserMigrationStatus_whenUploadIsNotFound_shouldReturn404() throws Exception {
    when(uploadService.getBulkUserMigrationStatus(any())).thenThrow(FumNotFoundException.class);
    mockMvc
        .perform(get("/migrations/{migration-id}", "B0000001").header(HttpHeaders.AUTHORIZATION, ""))
        .andExpect(status().isNotFound());
  }

  @Test
  public void testDownloadBulkUserMigrationReportMetadata_whenUploadIsNotFound_shouldReturn404() throws Exception {
    when(uploadService.getMigrationReportMetadata(any())).thenReturn(MockData.getMigrationReportMetadataResponse());
    MvcResult mvcResult = mockMvc
        .perform(get("/reports/{migration-id}/metadata", "B0000001").header(HttpHeaders.AUTHORIZATION, ""))
        .andExpect(status().isOk())
        .andReturn();

    MigrationReportMetadataResponse response = objectMapper.readValue(mvcResult.getResponse().getContentAsString(), MigrationReportMetadataResponse.class);
    assertEquals(MockData.getMigrationReportMetadataResponse().getMetadata().size(), response.getMetadata().size());
  }

  @Test
  public void testDownloadUserReport_whenReportGenerated_shouldReturn200() throws Exception {
    MvcResult mvcResult = mockMvc
        .perform(get("/user/report")
            .header(HttpHeaders.AUTHORIZATION, ""))
        .andExpect(status().isOk())
        .andReturn();

    assertEquals(200, mvcResult.getResponse().getStatus());
  }

}