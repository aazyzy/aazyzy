package ca.bnc.wealth.api.bulk.migration.schedule;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.bulk.migration.feign.client.AuditLogManagementClient;
import ca.bnc.wealth.api.bulk.migration.model.BulkDownloadResource;
import ca.bnc.wealth.api.bulk.migration.service.CsvWriteService;
import ca.bnc.wealth.api.bulk.migration.utils.MockData;
import ca.bnc.wealth.common.audit_management.model.Audit;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.repo.iam.AuditRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadDetailsRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import ca.bnc.wealth.common.jpa.service.ScheduleService;
import java.util.List;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class BulkActionStatusCheckServiceTest {

  @MockitoBean
  private BulkUploadRepository bulkUploadRepository;

  @MockitoBean
  private BulkUploadDetailsRepository bulkUploadDetailsRepository;

  @MockitoBean
  private AuditRepository auditRepository;

  @MockitoBean
  private ScheduleService scheduleService;

  @MockitoBean
  private CsvWriteService csvWriteService;

  @MockitoBean
  private AuditLogManagementClient auditLogManagementClient;

  @MockitoBean
  private SystemTokenFactory systemTokenFactory;

  private BulkActionStatusCheckService bulkActionStatusCheckService;

  @SneakyThrows
  @Before
  public void setup() {
    bulkActionStatusCheckService = new BulkActionStatusCheckService();
    FieldUtils.writeField(bulkActionStatusCheckService, "bulkUploadRepository",
        bulkUploadRepository, true);
    FieldUtils.writeField(bulkActionStatusCheckService, "bulkUploadDetailsRepository",
        bulkUploadDetailsRepository, true);
    FieldUtils.writeField(bulkActionStatusCheckService, "auditRepository",
        auditRepository, true);
    FieldUtils.writeField(bulkActionStatusCheckService, "scheduleService",
        scheduleService, true);
    FieldUtils.writeField(bulkActionStatusCheckService, "csvWriteService",
        csvWriteService, true);
    FieldUtils.writeField(bulkActionStatusCheckService, "auditLogManagementClient",
        auditLogManagementClient, true);
    FieldUtils.writeField(bulkActionStatusCheckService, "systemTokenFactory",
        systemTokenFactory, true);
  }

  @Test
  public void testUpdateBulkStatus_whenCannotRunSchedule_shouldNotUpdateBulkStatus() {
    when(scheduleService.canRunSchedule(any(), anyLong(), any())).thenReturn(false);
    bulkActionStatusCheckService.updateBulkStatus();
    verify(scheduleService, never()).updateStatusToFinish(any());
  }

  @Test
  public void testUpdateBulkStatus_whenCanRunSchedule_shouldUpdateBulkStatus() {
    when(scheduleService.canRunSchedule(any(), anyLong(), any())).thenReturn(true);
    when(bulkUploadRepository.findAll(any(Specification.class))).thenReturn(List.of(MockData.getBulkUpload()));
    bulkActionStatusCheckService.updateBulkStatus();
    verify(scheduleService, times(1)).updateStatusToFinish(any());
  }

  @Test
  public void testCheckAndUpdateStatus_whenBulkUploadProvided_shouldUpdateBulkUploadStatus() {
    when(bulkUploadDetailsRepository.count(any(Specification.class))).thenReturn(1L);
    when(csvWriteService.downloadStatusCsv(any())).thenReturn(new BulkDownloadResource("filename", "content".getBytes(), "description"));
    Audit audit = new Audit();
    audit.setAuditId(1L);
    when(auditLogManagementClient.uploadAudit(any(), any(), any())).thenReturn(ResponseEntity.ok(audit));

    // Bulk upload details success
    BulkUpload bulkUpload = MockData.getBulkUpload();
    bulkUpload.setTotalRecords(1);
    bulkActionStatusCheckService.checkAndUpdateStatus(bulkUpload);
    verify(bulkUploadRepository, times(1)).saveAndFlush(any());

    // Bulk upload details failed
    clearInvocations(bulkUploadRepository);
    bulkUpload.setTotalRecords(2);
    bulkActionStatusCheckService.checkAndUpdateStatus(bulkUpload);
    verify(bulkUploadRepository, times(1)).saveAndFlush(any());

    // Bulk upload details still processing
    clearInvocations(bulkUploadRepository);
    bulkUpload.setTotalRecords(3);
    bulkActionStatusCheckService.checkAndUpdateStatus(bulkUpload);
    verify(bulkUploadRepository, times(1)).saveAndFlush(any());
  }
}
