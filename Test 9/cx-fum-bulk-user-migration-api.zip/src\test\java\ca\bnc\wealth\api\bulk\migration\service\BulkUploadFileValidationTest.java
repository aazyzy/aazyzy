package ca.bnc.wealth.api.bulk.migration.service;

import static org.junit.Assert.assertEquals;

import ca.bnc.wealth.api.bulk.migration.utils.MockData;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.Test;

public class BulkUploadFileValidationTest {

  private final BulkUploadFileValidation bulkUploadFileValidation = new BulkUploadFileValidation();

  @Test
  public void testBulkUploadFileValidation() {
    List<Map<String, String>> parsedFileContent = new ArrayList<>();
    parsedFileContent.add(Map.of("header1", "value1", "row-number", "2"));
    parsedFileContent.add(Map.of("header2", "value2", "row-number", "2"));

    Map<String, List<Long>> errorMessage = bulkUploadFileValidation.validation(parsedFileContent, MockData.getTemplateEntity());
    assertEquals(1, errorMessage.size());
    assertEquals(1, errorMessage.get("Mandatory_Field header1").size());
    assertEquals(2, (long) errorMessage.get("Mandatory_Field header1").get(0));
  }
}
