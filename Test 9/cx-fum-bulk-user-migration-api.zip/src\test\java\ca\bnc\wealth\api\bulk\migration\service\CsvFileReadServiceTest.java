package ca.bnc.wealth.api.bulk.migration.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import ca.bnc.wealth.api.bulk.migration.utils.MockData;
import ca.bnc.wealth.api.bulk.migration.utils.MultipartFileImpl;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class CsvFileReadServiceTest {

  private final CsvFileReadService csvFileReadService = new CsvFileReadService();
  private static final String FILENAME = "filename.csv";
  private static final String CONTENT_TYPE = "csv";
  private static final String FILE_CONTENT = """
      header1
      value1
      """;

  @Test
  public void testValidateFile_whenValidFile_shouldNotReturnErrorMessage() {
    Template template = MockData.getTemplateEntity();
    String message = csvFileReadService.validateFile(new MultipartFileImpl(FILE_CONTENT.getBytes(), FILENAME, CONTENT_TYPE), template).orElse("");
    assertEquals("", message);
  }

  @Test
  public void testValidateFile_whenInvalidFileExtension_shouldReturnErrorMessage() {
    Template template = MockData.getTemplateEntity();
    String message = csvFileReadService.validateFile(new MultipartFileImpl(FILE_CONTENT.getBytes(), "file.txt", CONTENT_TYPE), template).orElse("");
    assertTrue(message.contains("Incorrect File format"));
  }

  @Test
  public void testValidateFile_whenTemplateIsNull_shouldReturnErrorMessage() {
    String message = csvFileReadService.validateFile(new MultipartFileImpl(FILE_CONTENT.getBytes(), FILENAME, CONTENT_TYPE), null).orElse("");
    assertEquals("Error loading rules", message);
  }

  @Test
  public void testValidateFile_whenFileExceedsMaxSize_shouldReturnErrorMessage() {
    Template template = MockData.getTemplateEntity();
    String message = csvFileReadService.validateFile(new MultipartFileImpl(StringUtils.repeat("x", (int) template.getFileSize() + 1).getBytes(), FILENAME, CONTENT_TYPE), template).orElse("");
    assertTrue(message.contains("File exceeds limit of"));
  }

  @Test
  public void testConvertCsvFileToMap_whenValidCsvFile_shouldReturnMap() throws Exception {
    List<Map<String, String>> map = csvFileReadService.convertCsvFileToMap(new MultipartFileImpl(FILE_CONTENT.getBytes(), FILENAME, CONTENT_TYPE), MockData.getTemplateEntity());
    assertEquals(1, map.size());
    assertEquals("2", map.get(0).get("row-number"));
    assertEquals("value1", map.get(0).get("header1"));

    // when file shouldn't have records
    map = csvFileReadService.convertCsvFileToMap(new MultipartFileImpl(FILE_CONTENT.getBytes(), FILENAME, CONTENT_TYPE), MockData.getTemplateEntity(), false);
    assertEquals(1, map.size());
    assertEquals("2", map.get(0).get("row-number"));
    assertEquals("value1", map.get(0).get("header1"));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConvertCsvFileToMap_whenInvalidCsvFileFormat_shouldThrowIllegalArgumentException() throws Exception {
    csvFileReadService.convertCsvFileToMap(new MultipartFileImpl("x,y,z".getBytes(), FILENAME, CONTENT_TYPE), MockData.getTemplateEntity());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConvertCsvFileToMap_whenTemplateNotFound_shouldThrowIllegalArgumentException()
      throws Exception {
    csvFileReadService.convertCsvFileToMap(new MultipartFileImpl(FILE_CONTENT.getBytes(), FILENAME, CONTENT_TYPE), null);
  }
}
