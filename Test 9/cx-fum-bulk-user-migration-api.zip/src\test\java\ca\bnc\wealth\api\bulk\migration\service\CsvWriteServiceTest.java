package ca.bnc.wealth.api.bulk.migration.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import ca.bnc.wealth.api.bulk.migration.model.BulkDownloadResource;
import ca.bnc.wealth.api.bulk.migration.utils.Constants;
import ca.bnc.wealth.api.bulk.migration.utils.MockData;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class CsvWriteServiceTest {

  private CsvWriteService csvWriteService;
  private final ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().build();

  @Before
  public void init() throws IllegalAccessException {
    csvWriteService = new CsvWriteService();
    FieldUtils.writeField(csvWriteService, "objectMapper",
        objectMapper, true);

  }

  @Test
  public void getCreateUserErrorMessage() {
    String response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_OKTA_PROFILE);
    assertEquals("User id already exists in Okta", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_INVALID_FIRM_ID);
    assertEquals("Invalid Firm ID", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_R2_PW);
    assertEquals("R2 password encryption is outdated", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_R2_FOUND);
    assertEquals("R2 ID is linked with another CX user", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_EMAIL_INVALID);
    assertEquals("Invalid email address", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_OKTA_CREATE);
    assertEquals("Okta user creation failed", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_R2_NOT_FOUND);
    assertEquals("R2 ID does not exist", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_RR_CODE_INVALID);
    assertEquals("Invalid RR Code", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.ERROR_SSO_EXIST);
    assertEquals("New Compass User Id exists already", response);

    response = csvWriteService.getCreateUserErrorMessage(Constants.PACKAGE_TEMPLATE_NAME);
    assertEquals("Create User Failed", response);

  }

  @Test
  public void getErrorMessageCode() throws JSONException {
    JSONObject jsonObject1 = new JSONObject();
    JSONObject jsonObject2 = new JSONObject();
    JSONArray jsonArray = new JSONArray();
    JSONObject message = new JSONObject();
    jsonObject1.put("messages",jsonObject2);
    jsonObject2.put("errors", jsonArray);
    jsonArray.put(message);
    message.put("code", Constants.ERROR_OKTA_PROFILE);

    String response = csvWriteService.getErrorMessage(jsonObject1.toString());
    assertEquals("User id already exists in Okta", response);
  }

  @Test
  public void getErrorMessage() throws JSONException {
    JSONObject jsonObject1 = new JSONObject();
    JSONObject jsonObject2 = new JSONObject();
    JSONArray jsonArray = new JSONArray();
    JSONObject message = new JSONObject();
    jsonObject1.put("messages",jsonObject2);
    jsonObject2.put("errors", jsonArray);
    jsonArray.put(message);
    message.put("code", "error");
    message.put("message", Constants.ERROR_OKTA_PROFILE);

    String response = csvWriteService.getErrorMessage(jsonObject1.toString());
    assertEquals("User id already exists in Okta", response);
  }

  @Test
  public void getErrorMessageCode_exception() {
    String response = csvWriteService.getErrorMessage(Constants.ERROR_R2_NOT_FOUND_MESSAGE);
    assertEquals(Constants.ERROR_R2_NOT_FOUND_MESSAGE, response);
  }

  @Test
  public void testDownloadStatusCsv_whenBulkStatusSuccess_shouldUseBulkUploadDetailsResponse() {
    BulkUpload bulkUpload = MockData.getBulkUpload();
    BulkDownloadResource bulkDownloadResource = csvWriteService.downloadStatusCsv(bulkUpload);
    assertEquals(bulkUpload.getAudit().getFileName() + "_Status.csv", bulkDownloadResource.getFileName());
    assertTrue((new String(bulkDownloadResource.getByteArray())).contains("SUCCESS"));
  }

  @Test
  public void testDownloadStatusCsv_whenBulkStatusFailed_shouldUseBulkUploadDetailsRequest() {
    BulkUpload bulkUpload = MockData.getBulkUpload();
    bulkUpload.getBulkUploadDetails().get(0).setBulkUploadStatus(BulkUploadStatus.FAILED);
    BulkDownloadResource bulkDownloadResource = csvWriteService.downloadStatusCsv(bulkUpload);
    assertEquals(bulkUpload.getAudit().getFileName() + "_Status.csv", bulkDownloadResource.getFileName());
    assertTrue((new String(bulkDownloadResource.getByteArray())).contains("FAILED"));
  }
}
