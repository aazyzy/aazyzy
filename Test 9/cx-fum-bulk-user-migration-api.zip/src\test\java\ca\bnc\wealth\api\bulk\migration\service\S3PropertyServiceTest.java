package ca.bnc.wealth.api.bulk.migration.service;

import static org.junit.Assert.assertEquals;

import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;
import software.amazon.awssdk.regions.Region;

@RunWith(SpringRunner.class)
public class S3PropertyServiceTest {

  private S3PropertyService s3PropertyService;

  @SneakyThrows
  @Before
  public void init() {
    s3PropertyService = new S3PropertyService();
    FieldUtils.writeField(s3PropertyService, "s3AccessKeyId",
        "s3AccessKeyId", true);
    FieldUtils.writeField(s3PropertyService, "s3SecretAccessKey",
        "s3SecretAccessKey", true);
    FieldUtils.writeField(s3PropertyService, "region",
        "ca-central-1", true);
  }

  @Test
  public void testGetS3AccessFor() {
    assertEquals("USER_REPORTS", s3PropertyService.getS3AccessFor());
    assertEquals("s3AccessKeyId", s3PropertyService.getS3AccessKeyId());
    assertEquals("s3SecretAccessKey", s3PropertyService.getS3SecretAccessKey());
    assertEquals(Region.of("ca-central-1"), s3PropertyService.getS3Region());
  }
}
