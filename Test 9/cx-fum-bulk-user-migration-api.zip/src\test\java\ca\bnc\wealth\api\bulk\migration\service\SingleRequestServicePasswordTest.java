package ca.bnc.wealth.api.bulk.migration.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.bulk.migration.feign.client.UserConfigurationClient;
import ca.bnc.wealth.api.bulk.migration.kafka.SingleRequestPublisher;
import ca.bnc.wealth.api.bulk.migration.utils.Constants;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadDetails;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadDetailsRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import feign.FeignException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class SingleRequestServicePasswordTest {

  private static final String HASH = "$2a$12$oXag6QzQfCFxF13b7xv3mONFqtWJSqb7IYmQgizjOGG71leQFN6B2";

  private final ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().findAndAddModules().build();

  @Mock
  private BulkUploadDetailsRepository bulkUploadDetailsRepository;

  @Mock
  private BulkUploadRepository bulkUploadRepository;

  @Mock
  private UserConfigurationClient userConfigurationClient;

  @Mock
  private SystemTokenFactory systemTokenFactory;

  @Mock
  private SingleRequestPublisher singleRequestPublisher;

  @InjectMocks
  private SingleRequestService singleRequestService;

  @BeforeEach
  void setUp() {
    ReflectionTestUtils.setField(singleRequestService, "objectMapper", objectMapper);
  }

  @Test
  void shouldDropPasswordsFromStoredRequestAndResponse_whenUserIsCreated() throws Exception {
    BulkUploadDetails entity = submittedDetail();
    when(bulkUploadDetailsRepository.findById(1L)).thenReturn(Optional.of(entity));
    when(systemTokenFactory.getBearerToken(anyString())).thenReturn("Bearer token");
    Map<String, Object> body = Map.of("username", "r2user", "password", "Tmp#Pass1234", "hashedPassword", HASH);
    when(userConfigurationClient.createUserConfiguration(any(), any())).thenReturn(ResponseEntity.ok().body(body));

    singleRequestService.singleRequestProcessing(1L);

    ArgumentCaptor<UserConfiguration> sent = ArgumentCaptor.forClass(UserConfiguration.class);
    verify(userConfigurationClient).createUserConfiguration(any(), sent.capture());
    assertEquals(HASH, sent.getValue().getHashedPassword());

    BulkUploadDetails saved = savedDetail();
    assertEquals(BulkUploadStatus.SUCCESS, saved.getBulkUploadStatus());
    JsonNode request = objectMapper.readTree(saved.getRequest());
    assertFalse(request.has("hashedPassword"));
    assertEquals("r2user", request.get("username").asString());
    JsonNode response = objectMapper.readTree(saved.getResponse());
    assertFalse(response.has("password"));
    assertFalse(response.has("hashedPassword"));
    assertEquals("r2user", response.get("username").asString());
  }

  @Test
  void shouldDropHashFromStoredRequest_whenUserCreationFails() throws Exception {
    BulkUploadDetails entity = submittedDetail();
    when(bulkUploadDetailsRepository.findById(1L)).thenReturn(Optional.of(entity));
    when(systemTokenFactory.getBearerToken(anyString())).thenReturn("Bearer token");
    when(userConfigurationClient.createUserConfiguration(any(), any())).thenThrow(new UpstreamException());

    singleRequestService.singleRequestProcessing(1L);

    BulkUploadDetails saved = savedDetail();
    assertEquals(BulkUploadStatus.FAILED, saved.getBulkUploadStatus());
    JsonNode request = objectMapper.readTree(saved.getRequest());
    assertFalse(request.has("hashedPassword"));
    assertEquals("r2user", request.get("username").asString());
  }

  @Test
  void shouldKeepNonJsonContentUnchanged() throws Exception {
    BulkUploadDetails entity = submittedDetail();
    entity.setRequest("not json".getBytes(StandardCharsets.UTF_8));
    when(bulkUploadDetailsRepository.findById(1L)).thenReturn(Optional.of(entity));

    singleRequestService.singleRequestProcessing(1L);

    BulkUploadDetails saved = savedDetail();
    assertEquals(BulkUploadStatus.FAILED, saved.getBulkUploadStatus());
    assertEquals("not json", new String(saved.getRequest(), StandardCharsets.UTF_8));
    assertEquals("unable to call the user create endpoint", new String(saved.getResponse(), StandardCharsets.UTF_8));
  }

  @Test
  void shouldDropPasswordColumn_whenRowFailedFileValidation() throws Exception {
    Map<String, String> row = new HashMap<>();
    row.put(Constants.FIRST_NAME, "firstName");
    row.put(Constants.PASS_LABEL, HASH);
    row.put(Constants.ERROR_MESSAGE, "Invalid Data");

    singleRequestService.createSingleRequestAndPublish(new BulkUpload(), List.of(row), "requestId");

    BulkUploadDetails saved = savedDetail();
    assertEquals(BulkUploadStatus.FAILED, saved.getBulkUploadStatus());
    JsonNode request = objectMapper.readTree(saved.getRequest());
    assertFalse(request.has(Constants.PASS_LABEL));
    assertTrue(request.has(Constants.FIRST_NAME));
  }

  private BulkUploadDetails submittedDetail() throws Exception {
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setUsername("r2user");
    userConfiguration.setHashedPassword(HASH);
    BulkUploadDetails entity = new BulkUploadDetails();
    entity.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
    entity.setRequest(objectMapper.writeValueAsBytes(userConfiguration));
    return entity;
  }

  private BulkUploadDetails savedDetail() {
    ArgumentCaptor<BulkUploadDetails> saved = ArgumentCaptor.forClass(BulkUploadDetails.class);
    verify(bulkUploadDetailsRepository).saveAndFlush(saved.capture());
    return saved.getValue();
  }

  static class UpstreamException extends FeignException {
    UpstreamException() {
      super(500, "upstream error");
    }
  }
}
