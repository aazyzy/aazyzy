package ca.bnc.wealth.api.bulk.migration.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.bulk.migration.feign.client.UserConfigurationClient;
import ca.bnc.wealth.api.bulk.migration.kafka.SingleRequestPublisher;
import ca.bnc.wealth.api.bulk.migration.utils.Constants;
import ca.bnc.wealth.api.bulk.migration.utils.MockData;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.Audit;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadDetails;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadDetailsRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import tools.jackson.databind.ObjectMapper;
import feign.FeignException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class SingleRequestServiceTest {

  private SingleRequestService singleRequestService;

  @MockitoBean
  private BulkUploadDetailsRepository bulkUploadDetailsRepository;

  @MockitoBean
  private BulkUploadRepository bulkUploadRepository;

  @MockitoBean
  private UserConfigurationClient userConfigurationClient;

  @MockitoBean
  private SystemTokenFactory systemTokenFactory;

  @MockitoBean
  private SingleRequestPublisher singleRequestPublisher;

  @MockitoBean
  private ObjectMapper objectMapper;

  @SneakyThrows
  @Before
  public void init() {
    singleRequestService = new SingleRequestService();
    FieldUtils.writeField(singleRequestService, "userConfigurationClient",
        userConfigurationClient, true);
    FieldUtils.writeField(singleRequestService, "bulkUploadRepository",
        bulkUploadRepository, true);
    FieldUtils.writeField(singleRequestService, "bulkUploadDetailsRepository",
        bulkUploadDetailsRepository, true);
    FieldUtils.writeField(singleRequestService, "singleRequestPublisher",
        singleRequestPublisher, true);
    FieldUtils.writeField(singleRequestService, "objectMapper",
        objectMapper, true);
    FieldUtils.writeField(singleRequestService, "systemTokenFactory",
        systemTokenFactory, true);
  }

  @Test
  public void testSingleRequestProcessing_whenBulkUploadStatusNotSubmitted_shouldDoNothing() {
    BulkUploadDetails bulkUploadDetails = new BulkUploadDetails();
    bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.FAILED);
    when(bulkUploadDetailsRepository.findById(anyLong())).thenReturn(Optional.of(bulkUploadDetails));
    singleRequestService.singleRequestProcessing(123);
    verify(bulkUploadDetailsRepository, times(0)).saveAndFlush(any());
  }

  @Test(expected = FumNotFoundException.class)
  public void testSingleRequestProcessing_whenBulkUploadDetailsNotFound_shouldThrowFumNotFoundException() {
    when(bulkUploadDetailsRepository.findById(anyLong())).thenReturn(Optional.empty());
    singleRequestService.singleRequestProcessing(123);
  }

  @Test
  public void testSingleRequestProcessing_whenGeneralExceptionIsThrown_shouldSaveBulkUploadStatusFailed() {
    BulkUploadDetails bulkUploadDetails = new BulkUploadDetails();
    bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
    when(bulkUploadDetailsRepository.findById(anyLong())).thenReturn(Optional.of(bulkUploadDetails));
    singleRequestService.singleRequestProcessing(123);
    verify(bulkUploadDetailsRepository, times(1)).saveAndFlush(any());
  }

  @Test
  public void testSingleRequestProcessing_whenFeignExceptionIsThrown_shouldSaveBulkUploadStatusFailed() {
    BulkUploadDetails bulkUploadDetails = new BulkUploadDetails();
    bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
    bulkUploadDetails.setRequest("hello".getBytes());
    when(bulkUploadDetailsRepository.findById(anyLong())).thenReturn(Optional.of(bulkUploadDetails));
    when(objectMapper.readValue(anyString(), eq(UserConfiguration.class))).thenReturn(new UserConfiguration());
    when(userConfigurationClient.createUserConfiguration(any(), any())).thenThrow(new DummyException(1, ""));
    singleRequestService.singleRequestProcessing(123);
    verify(bulkUploadDetailsRepository, times(1)).saveAndFlush(any());
  }

  @Test
  public void testSingleRequestProcessing_whenUserCreationFailed_shouldSaveBulkUploadStatusFailed() {
    BulkUploadDetails bulkUploadDetails = new BulkUploadDetails();
    bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
    bulkUploadDetails.setRequest("hello".getBytes());
    when(bulkUploadDetailsRepository.findById(anyLong())).thenReturn(Optional.of(bulkUploadDetails));
    when(objectMapper.readValue(anyString(), eq(UserConfiguration.class))).thenReturn(new UserConfiguration());
    when(userConfigurationClient.createUserConfiguration(any(), any())).thenReturn(
        ResponseEntity.badRequest().body(null));
    singleRequestService.singleRequestProcessing(123);
    verify(bulkUploadDetailsRepository, times(1)).saveAndFlush(any());
  }

  @Test
  public void testSingleRequestProcessing_whenUserCreationFailed_shouldSaveBulkUploadStatusSuccess() {
    BulkUploadDetails bulkUploadDetails = new BulkUploadDetails();
    bulkUploadDetails.setBulkUploadStatus(BulkUploadStatus.SUBMITTED);
    bulkUploadDetails.setRequest("hello".getBytes());
    when(bulkUploadDetailsRepository.findById(anyLong())).thenReturn(Optional.of(bulkUploadDetails));
    when(objectMapper.readValue(anyString(), eq(UserConfiguration.class))).thenReturn(new UserConfiguration());
    when(objectMapper.writeValueAsString(any())).thenReturn("value");
    when(userConfigurationClient.createUserConfiguration(any(), any())).thenReturn(
        ResponseEntity.ok().body("body"));
    singleRequestService.singleRequestProcessing(123);
    verify(bulkUploadDetailsRepository, times(1)).saveAndFlush(any());
  }

  @Test
  public void testCreateSingleRequestAndPublish_whenNonSsoUser_shouldPublishToKafka() {
    Map<String, String> userInfo = new HashMap<>();
    userInfo.put(Constants.FIRM_ID, "NBIN");
    userInfo.put(Constants.FIRST_NAME, "firstName");
    userInfo.put(Constants.LAST_NAME, "lastName");
    userInfo.put(Constants.EMAIL, "name@email.com");
    userInfo.put(Constants.SECURITY_ZONE_ID, "abc:def");
    userInfo.put(Constants.SSO_USER_ID, "ssoId");
    userInfo.put(Constants.COMPASS_R2_ID, "abcd");
    userInfo.put(Constants.ACTIVATION_DATE, "11-25-2023");
    List<Map<String, String>> parsedFileContents = List.of(userInfo);
    when(objectMapper.writeValueAsString(any())).thenReturn("hello");
    singleRequestService.createSingleRequestAndPublish(MockData.getBulkUpload(), parsedFileContents, "requestId");
    verify(singleRequestPublisher, times(1)).publishMessage(any());
  }

  @Test
  public void testCreateSingleRequestAndPublish_failedValidation() {
    Map<String, String> userInfo = new HashMap<>();
    userInfo.put(Constants.FIRM_ID, "NBIN");
    userInfo.put(Constants.FIRST_NAME, "firstName");
    userInfo.put(Constants.LAST_NAME, "lastName");
    userInfo.put(Constants.EMAIL, "name@email.com");
    userInfo.put(Constants.SECURITY_ZONE_ID, "abc:def");
    userInfo.put(Constants.SSO_USER_ID, "ssoId");
    userInfo.put(Constants.COMPASS_R2_ID, "abcd");
    userInfo.put(Constants.ACTIVATION_DATE, "11-25-2023");
    userInfo.put(Constants.ERROR_MESSAGE, "error");
    List<Map<String, String>> parsedFileContents = List.of(userInfo);
    when(objectMapper.writeValueAsString(any())).thenReturn("hello");
    singleRequestService.createSingleRequestAndPublish(MockData.getBulkUpload(), parsedFileContents, "requestId");
    verify(bulkUploadDetailsRepository, times(1)).saveAndFlush(any());
    verify(singleRequestPublisher, times(0)).publishMessage(any());
  }

  @Test
  public void testCreateSingleRequestAndPublish_whenIaSsoUser_shouldPublishToKafka() {
    Map<String, String> userInfo = new HashMap<>();
    userInfo.put(Constants.FIRM_ID, "NBIN");
    userInfo.put(Constants.FIRST_NAME, "firstName");
    userInfo.put(Constants.LAST_NAME, "lastName");
    userInfo.put(Constants.EMAIL, "name@email.com");
    userInfo.put(Constants.SECURITY_ZONE_ID, "abc:def");
    userInfo.put(Constants.SSO_USER_ID, "indall_ssoId");
    userInfo.put(Constants.COMPASS_R2_ID, "abcd");
    userInfo.put(Constants.ACTIVATION_DATE, "11-25-2023");
    userInfo.put(Constants.EXTERNAL_CLIENT_ID, "iaSsoId");
    List<Map<String, String>> parsedFileContents = List.of(userInfo);
    when(objectMapper.writeValueAsString(any())).thenReturn("hello");
    singleRequestService.createSingleRequestAndPublish(MockData.getBulkUpload(), parsedFileContents, "requestId");
    verify(singleRequestPublisher, times(1)).publishMessage(any());
  }

  @Test(expected = FumNotFoundException.class)
  public void testDownloadStatusCsv_whenBulkUploadDoesNotExist_shouldThrowFumValidationException() {
    when(bulkUploadRepository.findByBatchID(anyString())).thenReturn(Optional.empty());
    singleRequestService.downloadStatusCsv("123");
  }

  @Test
  public void testDownloadStatusCsv_whenBulkUploadExists_shouldReturnReportAudit() {
    when(bulkUploadRepository.findByBatchID(anyString())).thenReturn(Optional.of(MockData.getBulkUpload()));
    Audit generatedAudit = singleRequestService.downloadStatusCsv("123");
    assertEquals(MockData.getBulkUpload().getGeneratedAudit().getFileName(), generatedAudit.getFileName());
  }

  @Test(expected = FumNotFoundException.class)
  public void testDownloadStatusCsv_whenBulkUploadDoesNotExist_shouldThrowFumNotFoundException() {
    when(bulkUploadRepository.findByBatchID(anyString())).thenReturn(Optional.empty());
    singleRequestService.downloadStatusCsv("123");
  }

  @Test(expected = FumValidationException.class)
  public void testDownloadStatusCsv_whenGeneratedReportNotReady_shouldThrowFumValidationException() {
    BulkUpload bulkUpload = MockData.getBulkUpload();
    bulkUpload.setGeneratedAudit(null);
    when(bulkUploadRepository.findByBatchID(anyString())).thenReturn(Optional.of(bulkUpload));
    singleRequestService.downloadStatusCsv("123");
  }

  class DummyException extends FeignException {
    DummyException(int i, String n){
      super(i, n);
    }
  }

}
