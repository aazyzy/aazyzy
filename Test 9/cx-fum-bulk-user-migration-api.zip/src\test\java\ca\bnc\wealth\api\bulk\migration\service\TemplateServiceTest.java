package ca.bnc.wealth.api.bulk.migration.service;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.bulk.migration.feign.client.AuditLogManagementClient;
import ca.bnc.wealth.api.bulk.migration.utils.MockData;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadTemplateRepository;
import java.util.Optional;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.junit.Assert.assertEquals;

import static org.springframework.http.HttpHeaders.CONTENT_DISPOSITION;

@RunWith(SpringRunner.class)
public class TemplateServiceTest {

  private TemplateService templateService;

  @MockitoBean
  private BulkUploadTemplateRepository bulkUploadTemplateRepository;

  @MockitoBean
  private AuditLogManagementClient auditLogManagementClient;

  @MockitoBean
  private SystemTokenFactory systemTokenFactory;

  @SneakyThrows
  @Before
  public void init() {
    templateService = new TemplateService();
    FieldUtils.writeField(templateService, "bulkUploadTemplateRepository",
        bulkUploadTemplateRepository, true);
    FieldUtils.writeField(templateService, "auditLogManagementClient",
        auditLogManagementClient, true);
    FieldUtils.writeField(templateService, "systemTokenFactory",
        systemTokenFactory, true);
    FieldUtils.writeField(templateService, "templateName",
        "BulkUserMigration", true);
  }

  @Test
  public void testGetAuditById_whenTemplateFormatIsUserMigrationTemplate_shouldReturnTemplateAudit() {
    String byteValue = "template";
    BulkUploadTemplate bulkUploadTemplate = MockData.getBulkUploadTemplateEntity();
    bulkUploadTemplate.setLayoutUser(byteValue.getBytes());
    when(bulkUploadTemplateRepository.findByTemplateName(anyString()))
        .thenReturn(Optional.of(bulkUploadTemplate));
    HttpHeaders headers = new HttpHeaders();
    headers.set(CONTENT_DISPOSITION, "ContentHeader");
    ResponseEntity<ByteArrayResource> response =
        new ResponseEntity<>(new ByteArrayResource(byteValue.getBytes()), headers,
        HttpStatus.OK);
    when(auditLogManagementClient.getAuditById(any(), anyLong())).thenReturn(response);
    Pair<String, ByteArrayResource> pair = templateService
        .getAuditById("USER-MIGRATE-TEMPLATE");
    assertEquals(byteValue, new String(pair.getValue().getByteArray()));
  }

  @Test
  public void testGetAuditById_whenTemplateFormatIsUserPasswordTemplate_shouldReturnPasswordAudit() {
    String byteValue = "password";
    BulkUploadTemplate bulkUploadTemplate = MockData.getBulkUploadTemplateEntity();
    bulkUploadTemplate.setLayoutPassword(byteValue.getBytes());
    when(bulkUploadTemplateRepository.findByTemplateName(anyString()))
        .thenReturn(Optional.of(bulkUploadTemplate));
    HttpHeaders headers = new HttpHeaders();
    headers.set(CONTENT_DISPOSITION, "ContentHeader");
    ResponseEntity<ByteArrayResource> response =
        new ResponseEntity<>(new ByteArrayResource(byteValue.getBytes()), headers,
            HttpStatus.OK);
    when(auditLogManagementClient.getAuditById(any(), anyLong())).thenReturn(response);
    Pair<String, ByteArrayResource> pair = templateService
        .getAuditById("USER-PASSWORD-TEMPLATE");
    assertEquals(byteValue, new String(pair.getValue().getByteArray()));
  }

  @Test(expected = FumValidationException.class)
  public void testGetAuditById_whenTemplateFormatIsInvalid_shouldThrowFumValidationException() {
    BulkUploadTemplate bulkUploadTemplate = MockData.getBulkUploadTemplateEntity();
    when(bulkUploadTemplateRepository.findByTemplateName(anyString()))
        .thenReturn(Optional.of(bulkUploadTemplate));
    templateService.getAuditById("invalid");
  }
}
