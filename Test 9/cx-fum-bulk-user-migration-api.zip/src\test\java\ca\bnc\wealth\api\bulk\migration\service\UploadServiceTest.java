package ca.bnc.wealth.api.bulk.migration.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.bulk.migration.feign.client.AuditLogManagementClient;
import ca.bnc.wealth.api.bulk.migration.utils.Constants;
import ca.bnc.wealth.api.bulk.migration.utils.MockData;
import ca.bnc.wealth.common.bulk_user_migration.model.MigrationReportResponse;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AuditRepository;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.cfg.DateTimeFeature;
import tools.jackson.databind.json.JsonMapper;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.multipart.MultipartFile;

@RunWith(SpringRunner.class)
public class UploadServiceTest {

  private UploadService uploadService;

  @MockitoBean
  private BulkUploadTemplateRepository bulkUploadTemplateRepository;

  @MockitoBean
  private BulkUploadRepository bulkUploadRepository;

  @MockitoBean
  private AuditRepository auditRepository;

  @MockitoBean
  private CsvFileReadService csvFileReadService;

  @MockitoBean
  private BulkUploadFileValidation bulkUploadFileValidation;

  @MockitoBean
  private SingleRequestService singleRequestService;

  @MockitoBean
  private AuditLogManagementClient auditLogManagementClient;

  @MockitoBean
  private SystemTokenFactory systemTokenFactory;

  private final ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults()
      .disable(DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS)
      .build();

  @SneakyThrows
  @Before
  public void init() {
    uploadService = new UploadService();
    FieldUtils.writeField(uploadService, "bulkUploadTemplateRepository",
        bulkUploadTemplateRepository, true);
    FieldUtils.writeField(uploadService, "bulkUploadRepository",
        bulkUploadRepository, true);
    FieldUtils.writeField(uploadService, "auditRepository",
        auditRepository, true);
    FieldUtils.writeField(uploadService, "csvFileReadService",
        csvFileReadService, true);
    FieldUtils.writeField(uploadService, "bulkUploadFileValidation",
        bulkUploadFileValidation, true);
    FieldUtils.writeField(uploadService, "singleRequestService",
        singleRequestService, true);
    FieldUtils.writeField(uploadService, "auditLogManagementClient",
        auditLogManagementClient, true);
    FieldUtils.writeField(uploadService, "systemTokenFactory",
        systemTokenFactory, true);
    FieldUtils.writeField(uploadService, "templateName",
        "BulkUserMigration", true);
    FieldUtils.writeField(uploadService, "objectMapper",
        objectMapper, true);
  }

  @Test(expected = FumValidationException.class)
  public void testUploadAndValidate_whenTemplateNameDoNotExist_shouldThrowFumValidationException() {
    uploadService.uploadAndValidate(
        new MockMultipartFile("file", new byte[]{}), "requestId");
  }

  @Test(expected = FumValidationException.class)
  public void testUploadAndValidate_whenValidationFailed_shouldThrowFumValidationException() {
    BulkUploadTemplate mockBulkUploadTemplate = MockData.getBulkUploadTemplateEntity();
    when(bulkUploadTemplateRepository.findByTemplateName(anyString())).thenReturn(Optional.of(
        mockBulkUploadTemplate));
    when(csvFileReadService.validateFile(any(), any())).thenReturn(Optional.of("error"));
    uploadService.uploadAndValidate(
        new MockMultipartFile("file", new byte[]{}), "requestId");
  }

  @Test
  public void testUploadAndValidate_whenAllValidationPassed_shouldUploadFile() {
    BulkUploadTemplate mockBulkUploadTemplate = MockData.getBulkUploadTemplateEntity();
    when(bulkUploadTemplateRepository.findByTemplateName(anyString())).thenReturn(Optional.of(
        mockBulkUploadTemplate));
    when(auditLogManagementClient.uploadAudit(any(), any(), any()))
        .thenReturn(MockData.getAuditResponseEntity());
    when(bulkUploadRepository.saveAndFlush(any())).thenReturn(MockData.getBulkUpload());
    BulkUpload bulkUpload = uploadService.uploadAndValidate(
        new MockMultipartFile("file", new byte[]{}), "requestId");
    assertEquals(MockData.getBulkUpload().getBatchID(), bulkUpload.getBatchID());
  }

  @Test(expected = FumValidationException.class)
  public void testUploadAndValidate_whenValidateFileFailed_shouldThrowFumValidationException() {
    BulkUploadTemplate mockBulkUploadTemplate = MockData.getBulkUploadTemplateEntity();
    when(bulkUploadTemplateRepository.findByTemplateName(anyString())).thenReturn(Optional.of(
        mockBulkUploadTemplate));
    Map<String, List<Long>> validation = new HashMap<>();
    validation.put("fail1", new ArrayList<>());
    validation.put("fail2", new ArrayList<>());
    when(csvFileReadService.validateFile(any(), any())).thenReturn(Optional.of("invalid"));
    uploadService.uploadAndValidate(
        new MockMultipartFile("file", new byte[]{}), "requestId");
  }

  @Test
  public void testGetBulkUserMigrationStatus_whenUploadExists_shouldReturnBulkUserUploadStatus() {
    BulkUpload bulkUpload = MockData.getBulkUpload();
    when(bulkUploadRepository.findByBatchID(any())).thenReturn(Optional.of(bulkUpload));

    BulkUploadStatus actualStatus = uploadService.getBulkUserMigrationStatus("B0000001");
    assertEquals(bulkUpload.getBulkUploadStatus().name(), actualStatus.name());
  }

  @Test(expected = FumNotFoundException.class)
  public void testGetBulkUserMigrationStatus_whenUploadNotFound_shouldThrowException() {
    when(bulkUploadRepository.findByBatchID(any())).thenReturn(Optional.empty());
    uploadService.getBulkUserMigrationStatus("B0000001");
  }

  @Test
  public void testGetBulkUpload_whenUploadExists_shouldReturnBulkUpload() {
    when(bulkUploadRepository.findById(any())).thenReturn(Optional.of(MockData.getBulkUpload()));
    BulkUpload bulkUpload = uploadService.getBulkUploadByFormId("123");
    assertEquals(MockData.getBulkUpload().getBulkUploadID(), bulkUpload.getBulkUploadID());
  }

  @Test(expected = FumNotFoundException.class)
  public void testGetBulkUpload_whenUploadExists_shouldThrowFumNotFoundException() {
    when(bulkUploadRepository.findById(any())).thenReturn(Optional.empty());
    uploadService.getBulkUploadByFormId("123");
  }

  @Test
  public void testGetAllBulkUserMigrationStatus_whenUploadExists_shouldReturnListOfBulkUserUploadStatus() {
    when(bulkUploadRepository.findAll()).thenReturn(List.of(MockData.getBulkUpload()));
    List<MigrationReportResponse> migrationReportResponses = uploadService.getAllBulkUserMigrations();
    assertEquals(MockData.getBulkUpload().getBatchID(), migrationReportResponses.get(0).getMigrationId());
  }

  @Test(expected = FumNotFoundException.class)
  public void testMigrateBulkUser_whenBatchDoesNotExist_shouldThrowFumNotFoundException() {
    when(bulkUploadRepository.findById(any())).thenReturn(Optional.empty());
    uploadService.migrateBulkUser("123", new MockMultipartFile("file", new byte[]{}),
        "requestId");
  }

  @Test(expected = FumValidationException.class)
  public void testMigrateBulkUser_whenBulkUploadStatusIsNotUploaded_shouldThrowFumValidationException() {
    BulkUpload bulkUpload = MockData.getBulkUpload();
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.FAILED);
    when(bulkUploadRepository.findById(any())).thenReturn(Optional.of(bulkUpload));
    uploadService.migrateBulkUser("123", new MockMultipartFile("file", new byte[]{}),
        "requestId");
  }

  @Test
  public void testMigrateBulkUser_whenBulkUploadStatusIsUploaded_shouldSuccessfullyMigrateBulkUser() {
    BulkUpload bulkUpload = MockData.getBulkUpload();
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.UPLOADED);
    when(bulkUploadRepository.findById(any())).thenReturn(Optional.of(bulkUpload));
    when(systemTokenFactory.getBearerToken(anyString())).thenReturn("valid-token");
    ByteArrayResource byteArrayResource = new ByteArrayResource(new byte[]{});
    when(auditLogManagementClient.getAuditById(anyString(), any()))
        .thenReturn(ResponseEntity.ok(byteArrayResource));
    when(bulkUploadTemplateRepository.findByTemplateName(any())).thenReturn(Optional.of(MockData.getBulkUploadTemplateEntity()));
    String batchID = uploadService.migrateBulkUser(bulkUpload.getBatchID(),
        new MockMultipartFile("file", new byte[]{}), "requestId");
    assertEquals(bulkUpload.getBatchID(), batchID);
  }

  @Test
  public void testMigrateBulkUser_whenPasswordFileRepeatsAnR2Id_shouldKeepTheFirstHash() throws Exception {
    BulkUpload bulkUpload = MockData.getBulkUpload();
    bulkUpload.setBulkUploadStatus(BulkUploadStatus.UPLOADED);
    when(bulkUploadRepository.findById(any())).thenReturn(Optional.of(bulkUpload));
    when(systemTokenFactory.getBearerToken(anyString())).thenReturn("valid-token");
    when(auditLogManagementClient.getAuditById(anyString(), any()))
        .thenReturn(ResponseEntity.ok(new ByteArrayResource(new byte[]{})));
    when(bulkUploadTemplateRepository.findByTemplateName(any())).thenReturn(Optional.of(MockData.getBulkUploadTemplateEntity()));
    Map<String, String> user = new HashMap<>(Map.of(Constants.COMPASS_R2_ID, "R2USER"));
    when(csvFileReadService.convertCsvFileToMap(any(BufferedReader.class), any())).thenReturn(List.of(user));
    when(csvFileReadService.convertCsvFileToMap(any(MultipartFile.class), any(), eq(false))).thenReturn(List.of(
        Map.of(Constants.COMPASS_R2_ID, "r2user", Constants.PASS_LABEL, "hash-1"),
        Map.of(Constants.COMPASS_R2_ID, "R2USER", Constants.PASS_LABEL, "hash-2")));

    uploadService.migrateBulkUser(bulkUpload.getBatchID(), new MockMultipartFile("file", new byte[]{}), "requestId");

    assertEquals("hash-1", user.get(Constants.PASS_LABEL));
    verify(singleRequestService).createSingleRequestAndPublish(eq(bulkUpload), anyList(), eq("requestId"));
  }

  @Test
  public void testGetMigrationReportMetadata_whenMigrationReportExists_shouldReturnMetadata() {
    when(bulkUploadRepository.findByBatchID(any())).thenReturn(Optional.of(MockData.getBulkUpload()));
    assertFalse(uploadService.getMigrationReportMetadata("B0000000005").getMetadata().isEmpty());
  }

  @Test(expected = FumNotFoundException.class)
  public void testGetMigrationReportMetadata_whenMigrationReportDoesNotExists_shouldThrowException() {
    when(bulkUploadRepository.findByBatchID(any())).thenReturn(Optional.empty());
    uploadService.getMigrationReportMetadata("B0000000005");
  }

  @Test
  public void getValidationErrorMessage() {
    String mandatoryFields = "Mandatory_Field ";
    String response = uploadService.getValidationErrorMessage(mandatoryFields + Constants.PACKAGE_TEMPLATE_NAME);
    assertEquals("New Compass - Role value is missing or incorrect header", response);

    response = uploadService.getValidationErrorMessage(mandatoryFields + Constants.PREFERRED_LANGUAGE);
    assertEquals("Missing Preferred Language or incorrect header", response);

    response = uploadService.getValidationErrorMessage(mandatoryFields + Constants.ACTIVATION_DATE);
    assertEquals("Missing Migration Date or incorrect header", response);

    response = uploadService.getValidationErrorMessage("Not_Supported_Value " + Constants.ACTIVATION_DATE);
    assertEquals("Invalid Migration Date", response);

    response = uploadService.getValidationErrorMessage(mandatoryFields + Constants.FIRM_ID);
    assertEquals("Missing Firm ID or incorrect header", response);

    response = uploadService.getValidationErrorMessage(mandatoryFields + Constants.FIRST_NAME);
    assertEquals("Missing user's first name on incorrect header", response);

    response = uploadService.getValidationErrorMessage(mandatoryFields + Constants.LAST_NAME);
    assertEquals("Missing user's last name or incorrect header", response);

    response = uploadService.getValidationErrorMessage(mandatoryFields + Constants.EMAIL);
    assertEquals("Missing user's email address or incorrect header", response);

    response = uploadService.getValidationErrorMessage(mandatoryFields + Constants.SECURITY_ZONE_ID);
    assertEquals("Missing Secured Zone User ID or incorrect header", response);

    response = uploadService.getValidationErrorMessage(mandatoryFields + "error");
    assertEquals("Invalid Data", response);
  }

  @Test(expected = FumValidationException.class)
  public void inputFileErrorValidation_TemplateNotFound() {
    List<Map<String, String>> lst = new ArrayList<>();
    when(bulkUploadTemplateRepository.findByTemplateName(anyString())).thenThrow(new FumValidationException("code", "message"));
    uploadService.inputFileErrorValidation(lst);
  }

  @Test
  public void inputFileErrorValidation() {
    List<Map<String, String>> lst = new ArrayList<>();
    Map<String, String> map1 = new HashMap<>();
    map1.put("key", "value");
    Map<String, String> map2 = new HashMap<>();
    map2.put("key", "value");
    lst.add(map1);
    lst.add(map2);
    when(bulkUploadTemplateRepository.findByTemplateName(anyString())).thenReturn(Optional.of(MockData.getBulkUploadTemplateEntity()));
    Map<String, List<Long>> validation = new HashMap<>();
    validation.put("fail1", Arrays.asList(2l,3l));
    validation.put("fail2", Arrays.asList(2l,3l));
    when(bulkUploadFileValidation.validation(any(), any())).thenReturn(validation);
    uploadService.inputFileErrorValidation(lst);
    assertEquals(3,map2.size());
  }
}
