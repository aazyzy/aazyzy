package ca.bnc.wealth.api.bulk.migration.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.bulk.migration.feign.client.ContentApiClient;
import ca.bnc.wealth.api.bulk.migration.utils.UserHeaderEnum;
import ca.bnc.wealth.common.fum.service.UserStatusService;
import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserConfigSearchMaterializedViewRepository;
import ca.bnc.wealth.common.s3.S3PropertyInterface;
import ca.bnc.wealth.common.s3.S3Service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class UserReportServiceTest {

  @InjectMocks
  private UserReportService userReportService;

  @Mock
  private IamUserConfigurationRepository iamUserConfigurationRepository;

  @Mock
  private UserConfigSearchMaterializedViewRepository userConfigSearchMaterializedViewRepository;

  @Mock
  private UserStatusService userStatusService;

  @Mock
  private UserAssignmentRepository userAssignmentRepository;

  @Mock
  private PackageTemplateRepository packageTemplateRepository;

  @Mock
  private FeaturePackageRepository featurePackageRepository;

  @Mock
  private FirmRepository firmRepository;

  @Mock
  private S3Service s3Service;

  @Mock
  private SystemTokenFactory systemTokenFactory;

  @Mock
  private ContentApiClient contentApiClient;

  @Mock
  private S3PropertyInterface s3PropertyInterface;

  @Before
  public void init() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void testGenerateUserReport() {
    when(userConfigSearchMaterializedViewRepository.findAll(any(Sort.class))).thenReturn(List.of(new UserConfigSearchMaterializedView()));
    Pair<String,String> pair = userReportService.generateUserReport("IAVM", new HashMap<>(), new ArrayList<>(), "User_Report", true);
    assertNotNull(pair);
    assertTrue(pair.getLeft().startsWith("User_Report_"));
    assertTrue(pair.getRight().startsWith(UserHeaderEnum.Firm_ID.name()));

    pair = userReportService.generateUserReport("NBIN", new HashMap<>(), new ArrayList<>(), "CX_Active_User_Report", false);
    assertNotNull(pair);
    assertTrue(pair.getLeft().startsWith("CX_Active_User_Report_"));
    assertTrue(pair.getRight().startsWith(UserHeaderEnum.Firm_ID.name()));
  }

  @Test
  public void testGetContentValue() {
    assertNull(userReportService.getContentValue(null, Map.of("", "")));
    assertEquals("role", userReportService.getContentValue("role", Map.of("", "")));
    assertEquals("value", userReportService.getContentValue("role", Map.of("role", "value")));
  }


}
