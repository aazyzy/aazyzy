package ca.bnc.wealth.api.bulk.migration.utils;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class UserHeaderEnumTest {

  @Test
  public void testUserHeaderEnumValues() {
    assertEquals("Firm ID", UserHeaderEnum.Firm_ID.getHeader());
    assertEquals("Firm Name", UserHeaderEnum.Firm_Name.getHeader());
    assertEquals("IDP Subject", UserHeaderEnum.IDP_Subject.getHeader());
    assertEquals("CX User ID", UserHeaderEnum.CX_User_ID.getHeader());
    assertEquals("First Name", UserHeaderEnum.First_Name.getHeader());
    assertEquals("Last Name", UserHeaderEnum.Last_Name.getHeader());
    assertEquals("Email Address", UserHeaderEnum.Email_Address.getHeader());
    assertEquals("Preferred Language", UserHeaderEnum.Preferred_Language.getHeader());
    assertEquals("User Status", UserHeaderEnum.User_Status.getHeader());
    assertEquals("User Role", UserHeaderEnum.User_Role.getHeader());
    assertEquals("CX Login Date", UserHeaderEnum.CX_Login_Date.getHeader());
  }

  @Test
  public void testUserHeaderEnumToString() {
    assertEquals("Firm_ID", UserHeaderEnum.Firm_ID.toString());
    assertEquals("Firm_Name", UserHeaderEnum.Firm_Name.toString());
    assertEquals("IDP_Subject", UserHeaderEnum.IDP_Subject.toString());
    assertEquals("CX_User_ID", UserHeaderEnum.CX_User_ID.toString());
    assertEquals("First_Name", UserHeaderEnum.First_Name.toString());
    assertEquals("Last_Name", UserHeaderEnum.Last_Name.toString());
    assertEquals("Email_Address", UserHeaderEnum.Email_Address.toString());
    assertEquals("Preferred_Language", UserHeaderEnum.Preferred_Language.toString());
    assertEquals("User_Status", UserHeaderEnum.User_Status.toString());
    assertEquals("User_Role", UserHeaderEnum.User_Role.toString());
    assertEquals("CX_Login_Date", UserHeaderEnum.CX_Login_Date.toString());
  }
}
