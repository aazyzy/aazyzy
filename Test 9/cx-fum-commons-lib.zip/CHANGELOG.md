# Changelog

## [2.0.1](https://github.com/NBC-GPMF/cx-fum-commons-lib/compare/v2.0.0...v2.0.1) (2026-11-02)


### Miscellaneous Chores

* move to parent-pom-core 3.0.1, which fixes the Snyk findings of the 5.0.0 release: Tomcat 11.0.27, Jackson 3.2.4 and 2.22.4, Hibernate Validator 9.1.6.Final and java-jwt 4.6.2

## [2.0.0](https://github.com/NBC-GPMF/cx-fum-commons-lib/compare/v1.0.80...v2.0.0) (2026-10-29)


### Miscellaneous Chores

* log Feign calls at BASIC so the system token stays out of logs ([#44](https://github.com/NBC-GPMF/cx-fum-commons-lib/pull/44)) ([0d281ef](https://github.com/NBC-GPMF/cx-fum-commons-lib/commit/0d281efaad69541c3bdee4a8397a8a25467622c6))
* move the Spring Boot 4 line into develop as 2.0.0-SNAPSHOT ([#46](https://github.com/NBC-GPMF/cx-fum-commons-lib/pull/46)) ([47c887b](https://github.com/NBC-GPMF/cx-fum-commons-lib/commit/47c887b4dc5b114ba9d057de57626e7a31e3f927))
* skip the SonarQube analysis for now ([#53](https://github.com/NBC-GPMF/cx-fum-commons-lib/pull/53)) ([865eefd](https://github.com/NBC-GPMF/cx-fum-commons-lib/commit/865eefda2b41e3a2ba5e7ea238d050a42d45f9d8))
* sync 6900 dependency versions to develop SNAPSHOTs ([11885c2](https://github.com/NBC-GPMF/cx-fum-commons-lib/commit/11885c2a79d44c6685bbf584219a533eaadb7090))

## [1.0.80](https://github.com/NBC-GPMF/cx-fum-commons-lib/compare/v1.0.79...v1.0.80) (2026-09-15)


### Bug Fixes

* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([516de9a](https://github.com/NBC-GPMF/cx-fum-commons-lib/commit/516de9a7ec35b56c58930a4fee02e824a0b4eac0))
* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([a240aa4](https://github.com/NBC-GPMF/cx-fum-commons-lib/commit/a240aa4b383fb549d7f34e2f4cd64cdeb1e814dc))

## [1.0.79](https://github.com/NBC-GPMF/cx-fum-commons-lib/compare/v1.0.78...v1.0.79) (2026-08-19)


### Bug Fixes

* **deps:** pin at.yawk.lz4:lz4-java 1.11.1 for CVE-2026-59949 ([#23](https://github.com/NBC-GPMF/cx-fum-commons-lib/issues/23)) ([4ce0e9d](https://github.com/NBC-GPMF/cx-fum-commons-lib/commit/4ce0e9dd6a4e673fd1e370fa6a4701bb684be4d5))
* **deps:** pin at.yawk.lz4:lz4-java 1.11.1 for CVE-2026-59949 ([#24](https://github.com/NBC-GPMF/cx-fum-commons-lib/issues/24)) ([4a88753](https://github.com/NBC-GPMF/cx-fum-commons-lib/commit/4a88753ee53602b15da4bd98ff2afaecc1432f16))
* **deps:** pin tomcat-embed 10.1.56 and logback-core 1.5.36 (Snyk HIGH) ([#17](https://github.com/NBC-GPMF/cx-fum-commons-lib/issues/17)) ([0bc9308](https://github.com/NBC-GPMF/cx-fum-commons-lib/commit/0bc9308cbaca456bd6b03512b1c43434ff31d372))
* **deps:** pin vulnerable transitive dependencies for Snyk remediation ([#27](https://github.com/NBC-GPMF/cx-fum-commons-lib/issues/27)) ([a0ce67f](https://github.com/NBC-GPMF/cx-fum-commons-lib/commit/a0ce67fcb5e880e057e386ed835c671adff04428))

## [1.0.78](https://github.com/NBC-GPMF/cx-fum-commons-lib/compare/v1.0.77...v1.0.78) (2026-06-29)


### Bug Fixes

* release 2.2.1 ([6e01dce](https://github.com/NBC-GPMF/cx-fum-commons-lib/commit/6e01dceb71d09e3c3a72703f496788e080dd3e1a))

## [1.0.77](https://github.com/NBC-GPMF/cx-fum-commons-lib/compare/v1.0.76...v1.0.77) (2026-06-11)


### Bug Fixes

* first release in github ([c7a39d5](https://github.com/NBC-GPMF/cx-fum-commons-lib/commit/c7a39d5eb65574feaa30771862fefe5c9ea4a270))
