# fum-commons-lib

## Introduction

**FUM Commons Library** is the shared Java library for the FUM (Firm User Management) microservice ecosystem. It centralises reusable infrastructure — data access, identity management, messaging, bulk operations, storage, and more — so individual microservices stay focused on domain logic.

- Contains shared code consumed by **all** FUM microservices
- Must **not** contain domain-specific business logic

| | |
|---|---|
| **Group ID** | `ca.nbc.gpmf.cx-fum-commons-lib` |
| **Version** | `2.0.0-SNAPSHOT` (the Spring Boot 3 line continues on `legacy/sb3`) |
| **Java** | 25 |
| **Framework** | Spring Boot 4.1 / Spring Cloud 2025.1 |
| **Build** | Maven multi-module POM (14 modules) |
| **Parent POM** | `ca.nbc.gpmf.cx-fum-parent-pom-core:parent-pom-core`, which holds every version |
| **CI/CD** | GitHub Actions · Snyk Code scanning |

## Modules

### Core

| Module | Artifact ID | Description |
|--------|------------|-------------|
| **JPA** | `commons-jpa` | 67 JPA entities (49 IAM + 18 Platform), 67 Spring Data repositories, specification-based query framework (20 query operations), PostgreSQL with AWS RDS IAM auth via HikariCP |
| **Exception** | `commons-exception` | Exception hierarchy — `FumServiceException` (500), `FumValidationException` (400), `FumMultipleValidationException` (400), `FumNotFoundException` (404), `FumConflictException` (409) — with global `@ControllerAdvice` handler and `ErrorMessage` DTO (errors, info, warnings) |
| **Kafka Model** | `commons-kafka-model` | Kafka message schemas — `EventMessages<T>`, `DataMessages<T>` envelopes with domain payloads for user config, firm ETL, firm management, and audit events |

### Integration

| Module | Artifact ID | External System | Description |
|--------|------------|-----------------|-------------|
| **CIAM** | `commons-ciam` | Okta | 17 Feign clients for user lifecycle, groups, MFA, profile sync, hashed password creation |
| **R2** | `commons-r2` | Compass R2 / CX | `R2UserProfileClient` + `CxUserProfileClient` (3 endpoints) for user profile retrieval |
| **SecureZone** | `commons-sz` | SecureZone UAMA | `SzClientUAMA` — PATCH endpoint to assign IDP subject to SecureZone user ID |
| **S3** | `commons-s3` | AWS S3 | Multi-credential S3 operations via `S3PropertyInterface` — upload (file/string/CSV-BOM), `getVersionAfterUpload`, download, `copyS3Object`, `getListOfS3Objects`, `deleteS3Object` |
| **Report** | `commons-report` | Report API | `ReportApiClient` — POST `/v2/reports` for metadata (`List<S3Details>`) and download (`ByteArrayResource`) |
| **Health Check** | `commons-health-check` | Okta, R2, CIAM | 4 Spring Actuator `HealthIndicator` beans — `OktaJwkHealthIndicator`, `CompassR2ApiHealthIndicator`, `CiamApiHealthIndicator`, `OktaSystemTenantHealthIndicator` |

### Business Utilities

| Module | Artifact ID | Description |
|--------|------------|-------------|
| **FUM Utils** | `commons-fum-utils` | 15 services — user/firm state management (`UserStatusService`, `FirmStateService`), Redis caching (`RedisCacheOperationService`), custom AOP (`@CustomSynchronized`, `@CustomThreadPoolExecutor`), MFT/SFTP (`MftService` via JSch) |
| **Extract** | `commons-extract` | Async extract generation framework — `ExtractInterface` SPI, 2-thread `ExecutorService`, `@Scheduled` timeout detection (default 30 min), status tracking via `IamUserExtractDownload` entity |
| **BMA** | `commons-bma` | Bulk Management API client — `BulkManagementClient` (upload, trigger, status, update) + `BulkManagementApiCallBackAop` for async callback processing (10-thread pool, SecurityContext preservation) |

### Bulk Operations

| Module | Artifact ID | Description |
|--------|------------|-------------|
| **Bulk JPA** | `commons-bulk-jpa` | 4 `@MappedSuperclass` entities (`BulkAction`, `BulkUpload`, `BulkTemplate`, `SingleAction`), 4 repository interfaces, 8 JSONB column models — consumers extend with domain-specific `@Entity` subclasses |
| **Bulk Action** | `commons-bulk-action` | Full bulk processing framework — CSV upload/validation, 3-stage pipeline (CONVERSION → VALIDATION → ACTION), 7 hook points via `HookInterface` SPI, Kafka pub/sub (`SingleRequestPublisher`/`Subscriber`), scheduled status checks and retention cleanup |

## Module Dependency Graph

```
commons-bulk-action ─→ commons-bulk-jpa ─→ commons-jpa
                   └─→ commons-jpa
                   └─→ kafka-core / messaging

commons-fum-utils ──→ commons-jpa
                  └─→ commons-exception

commons-extract ───→ commons-jpa
               └──→ commons-exception

commons-bma ──────→ commons-jpa

commons-health-check → commons-auth (external)

commons-ciam, commons-r2, commons-sz, commons-report, commons-s3,
commons-kafka-model → standalone (no internal module deps)
```

## How to Use

### Add POM Dependency

Add module dependencies in your project `pom.xml`. Versions are managed centrally in the parent POM — do **not** set versions in individual microservices.

```xml
<dependency>
    <groupId>ca.bnc.wealth.common</groupId>
    <artifactId>commons-jpa</artifactId>
</dependency>

<dependency>
    <groupId>ca.bnc.wealth.common</groupId>
    <artifactId>commons-ciam</artifactId>
</dependency>

<dependency>
    <groupId>ca.bnc.wealth.common</groupId>
    <artifactId>commons-s3</artifactId>
</dependency>
```

### Key Extension Points

Several modules provide plugin interfaces for consumer customisation:

| Interface | Module | Purpose |
|-----------|--------|---------|
| `ExtractInterface` | commons-extract | Register custom extract types (`getExtractType()`, `getExtract(long entityId)`) |
| `S3PropertyInterface` | commons-s3 | Provide named S3 credential sets (`getS3AccessFor()`, `getS3Region()` → `Region`) |
| `HookInterface` | commons-bulk-action | Inject custom logic at 7 hook points across the CONVERSION/VALIDATION/ACTION pipeline |
| `CiamSystemToken` | commons-ciam | Provide Okta authentication tokens (`getSystemToken()`, `getBearerToken()`) |
| `EntityInterface` | commons-jpa | Base contract for JPA entities (`Long getId()`, `getUniqueFieldMapping()`) |

### Key Configuration Properties

| Property Prefix | Module | Purpose |
|----------------|--------|---------|
| `postgres.datasource.*` | commons-jpa | JDBC URL, credentials, HikariCP pool settings |
| `postgres.iam.*` | commons-jpa | AWS RDS IAM auth (region, serverName, database) |
| `postgres.read.datasource.*` | commons-jpa | Read replica configuration |
| `feign.ciamApi.url` | commons-ciam | CIAM API base URL |
| `feign.oktaProxy.url` | commons-ciam | Okta proxy base URL |
| `feign.reportApi.url` | commons-report | Report API base URL |
| `mft.6900.*` | commons-fum-utils | SFTP connection (hostname, username, password, port) |
| `extract.wait.time.min` | commons-extract | Extract timeout in minutes (default: 30) |

## Technology Stack

| Layer | Technology | Version |
|-------|-----------|---------|
| Language | Java | 17 |
| Framework | Spring Boot / Spring Cloud | 3.x |
| ORM | Spring Data JPA / Hibernate | — |
| Database | PostgreSQL (HikariCP, AWS JDBC Wrapper for IAM auth) | — |
| Caching | Redis (Spring Data Redis), Caffeine | — |
| Messaging | Apache Kafka | — |
| Storage | AWS S3 (SDK v2 Transfer Manager + CRT) | 2.40.17 / 0.30.4 |
| Identity | Okta CIAM (OAuth 2.0 / OIDC) | — |
| HTTP Clients | Spring Cloud OpenFeign + OkHttp | — |
| Networking | Netty | 4.1.132.Final |
| SSH/SFTP | JSch | 0.2.23 |
| Utilities | Apache Commons Lang3 | 3.20.0 |
| Build | Maven | 3.8.4 |

## Documentation

Detailed Software Design Documents are maintained in [`.github/sdd/`](.github/sdd/README.md) — validated against actual source code, covering:

- **Architecture** — component diagrams, dependency graph, design principles
- **14 module design docs** — package structure, classes, interfaces, configuration properties
- **Data model** — 67 JPA entities, 12 enums, 8 JSONB models, specification framework
- **Integrations** — Okta, R2, SecureZone, S3, Kafka, Report API, Redis, SFTP
- **Cross-cutting** — exception handling, caching, AOP, security, async processing
- **Deployment** — CI/CD pipeline, versioning, dependency management

