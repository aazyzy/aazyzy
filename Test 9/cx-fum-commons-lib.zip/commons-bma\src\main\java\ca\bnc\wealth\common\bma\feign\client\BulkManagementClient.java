package ca.bnc.wealth.common.bma.feign.client;

import ca.bnc.wealth.common.bulk_management.model.BatchStatus;
import ca.bnc.wealth.common.bulk_management.model.UpdateStatusRequest;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

@FeignClient(url = "${feign.bulkManagementApi.url}")
public interface BulkManagementClient {

  @PostMapping(path = "/files/{template-name}", consumes = "multipart/form-data", produces = "application/json")
  ResponseEntity<String> uploadFile(@RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization, @PathVariable("template-name") String templateName,
      @RequestPart(value = "file") MultipartFile file, @RequestParam(value = "firmId") String firmId);

  @PostMapping(path = "/batches/trigger/{batch-id}")
  ResponseEntity<Void> triggerBulkProcess(@RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization, @PathVariable("batch-id") String batchId);

  @GetMapping(path = "/batches/{batch-id}/status", produces = {"application/json"})
  ResponseEntity<BatchStatus> getBatchStatusByBatchId(@RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization, @PathVariable("batch-id") String batchId, @RequestParam(value = "getDetails") Boolean getDetails);


  @PostMapping(path = "/update/status")
  ResponseEntity<Void> updateStatus(@RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization, @RequestBody List<UpdateStatusRequest> list);
}
