package ca.bnc.wealth.common.bma.feign.client;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import java.util.Map;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(url = "${feign.subscriptionApi.url}")
public interface SubscriptionClient {

  @PostMapping("/emit")
  void emit(@RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestHeader @NotNull String domain, @RequestBody @Valid List<Object> events);

  @PostMapping("/subscribe")
  Map<String, Object> subscribe(@RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestBody @Valid Map<String, Object> criteria);
}
