package ca.bnc.wealth.common.bma.feign.config;

import ca.bnc.wealth.api.authorization.feign.config.FeignCodecs;
import ca.bnc.wealth.common.bma.feign.client.SubscriptionClient;
import feign.Feign;
import feign.Logger;
import feign.Retryer;
import feign.Util;
import feign.codec.Decoder;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tools.jackson.databind.JavaType;
import tools.jackson.databind.cfg.DateTimeFeature;
import tools.jackson.databind.json.JsonMapper;

@Configuration
@ConditionalOnProperty(name = "feign.subscriptionApi.url")
public class SubscriptionClientConfig {

  // Jackson 2 defaults: what the Spring Boot 3 line's new ObjectMapper() with JavaTimeModule read
  private static final JsonMapper DECODER_MAPPER =
      JsonMapper.builderWithJackson2Defaults()
          .disable(DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS)
          .build();

  @Value("${feign.subscriptionApi.url}")
  private String subscriptionApiUrl;

  @Bean
  public SubscriptionClient subscriptionClient(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .decoder(new ResponseEntityDecoder(getResponseEntityDecoder()))
        .retryer(new Retryer.Default(100, 1000, 3))
        .logger(new Slf4jLogger(SubscriptionClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(SubscriptionClient.class, subscriptionApiUrl);
  }

  private Decoder getResponseEntityDecoder() {
    return (response, type) -> {
      if (type == void.class || type == Void.class) {
        return null;
      }
      String bodyStr = Util.toString(response.body().asReader(Util.UTF_8));
      JavaType javaType = DECODER_MAPPER.getTypeFactory().constructType(type);
      if (javaType.hasRawClass(String.class)) {
        return bodyStr;
      }
      return DECODER_MAPPER.readValue(bodyStr, javaType);
    };
  }
}
