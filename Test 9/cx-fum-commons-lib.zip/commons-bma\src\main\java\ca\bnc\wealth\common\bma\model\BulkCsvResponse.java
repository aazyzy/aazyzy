package ca.bnc.wealth.common.bma.model;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BulkCsvResponse implements Serializable {

  private String id;
  private String status;
  private String data;
  private String errorMessage;
  private String errorCode;
}
