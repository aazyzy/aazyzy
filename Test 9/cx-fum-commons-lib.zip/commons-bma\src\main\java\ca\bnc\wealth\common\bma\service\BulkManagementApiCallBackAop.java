package ca.bnc.wealth.common.bma.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import tools.jackson.databind.json.JsonMapper;
import ca.bnc.wealth.common.bma.model.BulkCsvResponse;
import ca.bnc.wealth.common.bulk_management.model.UpdateStatusRequest;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
@RequiredArgsConstructor
public class BulkManagementApiCallBackAop {

  private final BulkManagementClientService bulkManagementService;

  private final JsonMapper objectMapper;

  private ExecutorService executorService = Executors.newFixedThreadPool(10);

  @Around("@annotation(ca.bnc.wealth.common.bma.service.BulkManagementApiCallBack)")
  public ResponseEntity<Object> customSynchronized(ProceedingJoinPoint point) {
    String uuid = java.util.UUID.randomUUID().toString();
    log.info("{{}} BulkManagementApiCallBackAop: Entered the AOP for BulkManagementApiCallBack.", uuid);
    String batchDetails = getBatchDetails(uuid);
    String batchFileFormat = getBatchFileFormat(uuid);
    log.info("{{}} BulkManagementApiCallBackAop: batchDetails: {}, batchFileFormat: {} ", uuid, batchDetails, batchFileFormat);
    if (StringUtils.isNotEmpty(batchDetails) && StringUtils.isNotEmpty(batchFileFormat)) {
      // securityContext is lost once we go async, so capturing it here
      SecurityContext context = SecurityContextHolder.getContext();
      log.info("{{}} BulkManagementApiCallBackAop: requires_callback header is present. running the endpoint Async.", uuid);
      executorService.submit(() -> this.asyncTask(context, point, batchDetails, batchFileFormat, uuid));

      log.info("{{}} BulkManagementApiCallBackAop: Returning response for the API call as callback is triggered. ", uuid);
      return ResponseEntity.ok("BulkManagementApiCallBack-Started");
    }
    try {
      log.info("{{}} BulkManagementApiCallBackAop: batchDetails or batchFileFormat is empty. proceeding with the API call without triggering callback. ", uuid);
      return (ResponseEntity<Object>) point.proceed();
    } catch (Throwable e) {
      log.warn("{{}} BulkManagementApiCallBackAop: Error executing API call without callback", uuid, e);
      return ResponseEntity.status(500).body("Error executing API call");
    }
  }

  private void asyncTask(SecurityContext context, ProceedingJoinPoint point, String batchDetails, String batchFileFormat, String uuid) {
    log.info("{{}} BulkManagementApiCallBackAop: Async call started for batch details: {}, batchFileFormat is: {} ", uuid, batchDetails, batchFileFormat);

    List<Long> ids = new ArrayList<>();
    SecurityContextHolder.setContext(context);
    try {
      Arrays.stream(batchDetails.split(","))
          .filter(StringUtils::isNotBlank)
          .map(Long::parseLong)
          .forEach(ids::add);
      Object responseObject = point.proceed();

      log.info("{{}} BulkManagementApiCallBackAop: Async call completed for batch details Ids: {}, response is: {} ", uuid, ids, responseObject);
      if (responseObject instanceof ResponseEntity<?>) {
        processResponseEntity((ResponseEntity) responseObject, ids, batchFileFormat, uuid);
      } else {
        log.warn("{{}} BulkManagementApiCallBackAop: Can't parse the response for callback.", uuid);
      }
    } catch (Throwable e) {
      log.warn("{{}} BulkManagementApiCallBackAop: Error executing async bulk management callback", uuid, e);
      processFailedResponse(e.getMessage(), ids, uuid);
    }
  }

  private void processResponseEntity(ResponseEntity responseEntity, List<Long> ids, String batchFileFormat, String uuid) {
    log.info("{{}} BulkManagementApiCallBackAop: Async call completed with status code: " + responseEntity.getStatusCode(), uuid);
    if (responseEntity.getStatusCode().is2xxSuccessful()) {
      processSuccessfulResponseBody(responseEntity, ids, batchFileFormat, uuid);
    } else {
      log.warn("{{}} BulkManagementApiCallBackAop: Async call failed for batch details Ids: {}. ", uuid, ids);
      processFailedResponse(responseEntity, ids, uuid);
    }
  }

  @SneakyThrows
  private void processFailedResponse(ResponseEntity responseEntity, List<Long> ids, String uuid) {
    String responseStr = "";
    Object responseBody = responseEntity.getBody();
    responseStr = objectMapper.writeValueAsString(responseBody);
    processFailedResponse(responseStr, ids, uuid);
  }


  @SneakyThrows
  void processFailedResponse(String responseStr, List<Long> ids, String uuid) {
    log.info("{{}} BulkManagementApiCallBackAop: Processing failed response for batch details Ids: {}. ", uuid, ids);

    List<UpdateStatusRequest> updateStatusRequests = new ArrayList<>();
    for (Long id : ids) {
      UpdateStatusRequest updateStatusRequest = getUpdateStatusRequest(String.valueOf(id), BulkUploadStatus.FAILED.name(), responseStr);
      updateStatusRequests.add(updateStatusRequest);
    }

    bulkManagementService.updateStatus(updateStatusRequests);
    log.info("{{}} BulkManagementApiCallBackAop: Called Bulk Management Service to update status for failed response.", uuid);
  }

  private void processSuccessfulResponseBody(ResponseEntity responseEntity, List<Long> ids, String batchFileFormat, String uuid) {
    log.info("{{}} BulkManagementApiCallBackAop: Async call successful for batch details Ids: {}. ", uuid, ids);
    Object responseBody = responseEntity.getBody();
    if ("csv".equalsIgnoreCase(batchFileFormat))
      processCsvResponseBody(responseBody, uuid);
    else if ("json".equalsIgnoreCase(batchFileFormat)) {
      processJsonResponseBody(responseBody, ids.get(0), uuid);
    } else
      log.warn("{{}} BulkManagementApiCallBackAop: Unsupported bulk file format: {} ", uuid, batchFileFormat);
  }

  @SneakyThrows
  void processJsonResponseBody(Object responseBody, Long id, String uuid) {
    String responseStr = objectMapper.writeValueAsString(responseBody);
    UpdateStatusRequest updateStatusRequest = getUpdateStatusRequest(String.valueOf(id), BulkUploadStatus.SUCCESS.name(), responseStr);

    bulkManagementService.updateStatus(List.of(updateStatusRequest));
    log.info("{{}} BulkManagementApiCallBackAop: Called Bulk Management Service to update status for JSON file record.", uuid);

  }

  @SneakyThrows
  void processCsvResponseBody(Object responseBody, String uuid) {
    if (responseBody instanceof List<?> responseList) {
      List<UpdateStatusRequest> updateStatusRequests = new ArrayList<>();
      for (Object respObj : responseList) {
        String respStr = objectMapper.writeValueAsString(respObj);
        BulkCsvResponse bulkCsvResponse = getBulkCsvResponse(respStr);
        if (bulkCsvResponse != null)
          updateStatusRequests.add(getUpdateStatusRequest(bulkCsvResponse.getId(), bulkCsvResponse.getStatus(), respStr));
        else
          log.warn("{{}} BulkManagementApiCallBackAop: Unexpected response body type for CSV bulk file Format: {} ", uuid, respObj);
      }
      log.info("{{}} BulkManagementApiCallBackAop: Processed update status requests: {} ", uuid, updateStatusRequests);
      if (!updateStatusRequests.isEmpty()) {

        bulkManagementService.updateStatus(updateStatusRequests);
        log.info("{{}} BulkManagementApiCallBackAop: Called Bulk Management Service to update status for CSV file records.", uuid);
      }
    } else {
      log.warn("{{}} BulkManagementApiCallBackAop: Unexpected response body type for CSV bulk file Format: {} ", uuid, responseBody);
    }
  }

  private UpdateStatusRequest getUpdateStatusRequest(String bulkDetailsId, String status, String responseStr) {
    UpdateStatusRequest updateStatusRequest = new UpdateStatusRequest();
    updateStatusRequest.setBatchDetailId(getLong(bulkDetailsId));
    updateStatusRequest.setStatus(status);
    updateStatusRequest.setResponce(responseStr);
    return updateStatusRequest;
  }

  private Long getLong(String id) {
    try {
      return Long.valueOf(id);
    } catch (Exception e) {
      return null;
    }
  }

  private String getBatchDetails(String uuid) {
    try {
      HttpServletRequest request =
          ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
      return request.getParameter("batch-detail-ids");
    } catch (Exception e) {
      log.warn("{{}} BulkManagementApiCallBackAop: Error getting batch-detail-ids from request parameters.", uuid, e);
      return null;
    }
  }

  private String getBatchFileFormat(String uuid) {
    try {
      HttpServletRequest request =
          ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
      return request.getParameter("bulk-file-format");
    } catch (Exception e) {
      log.warn("{{}} BulkManagementApiCallBackAop: Error getting bulk-file-format from request parameters.", uuid, e);
      return null;
    }
  }

  private BulkCsvResponse getBulkCsvResponse(String jsonString) {
    try {
      return objectMapper.readValue(jsonString, BulkCsvResponse.class);
    } catch (Exception e) {
      log.error("Error parsing response object to BulkCsvResponse", e);
      return null;
    }
  }
}
