package ca.bnc.wealth.common.bma.service;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.common.bma.feign.client.BulkManagementClient;
import ca.bnc.wealth.common.bma.model.JsonPayLoad;
import ca.bnc.wealth.common.bulk_management.model.BatchStatus;
import ca.bnc.wealth.common.bulk_management.model.UpdateStatusRequest;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.List;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.web.multipart.MultipartFile;
import tools.jackson.databind.json.JsonMapper;

@Service
@Slf4j
public class BulkManagementClientService {

  private static final String USER_CONF_SYSTEM_TOKEN = "fum";
  @Autowired
  private BulkManagementClient bulkManagementClient;

  @Autowired
  private SystemTokenFactory systemTokenFactory;

  @Autowired
  private JsonMapper objectMapper;

  public String upload(String templateName, String firmId, List<JsonPayLoad> jsonPayLoads, String fileName) {
    log.info("Uploading file for template: {}, firmId: {}", templateName, firmId);

    MultipartFile file = createMultipartFile(jsonPayLoads, fileName);

    String token = systemTokenFactory.getBearerToken(USER_CONF_SYSTEM_TOKEN);
    return bulkManagementClient.uploadFile( token, templateName, file, firmId).getBody();
  }

  public void triggerBulkProcess(String batchId) {
    log.info("Triggering bulk process for batchId: {}", batchId);
    String token = systemTokenFactory.getBearerToken(USER_CONF_SYSTEM_TOKEN);
    bulkManagementClient.triggerBulkProcess(token, batchId);
  }

  public BatchStatus getBatchStatusByBatchId(String batchId, Boolean getDetails) {
    log.info("Getting batch status for batchId: {}", batchId);
    String token = systemTokenFactory.getBearerToken(USER_CONF_SYSTEM_TOKEN);
    return bulkManagementClient.getBatchStatusByBatchId(token, batchId, getDetails).getBody();
  }

  public void updateStatus(List<UpdateStatusRequest> list) {
    log.info("Updating status for {} requests", list.size());
    String token = systemTokenFactory.getBearerToken(USER_CONF_SYSTEM_TOKEN);
    bulkManagementClient.updateStatus(token, list);
  }

  @SneakyThrows
  private MultipartFile createMultipartFile(List<JsonPayLoad> jsonPayLoads, String fileName) {
    String jsonString = objectMapper.writeValueAsString(jsonPayLoads);

    return new JsonFilePart(fileName, jsonString.getBytes(StandardCharsets.UTF_8));
  }

  // Spring's MockMultipartFile lives in spring-test, which is not a production dependency.
  private record JsonFilePart(String fileName, byte[] content) implements MultipartFile {

    JsonFilePart {
      Assert.hasLength(fileName, "Name must not be empty");
    }

    @Override
    public String getName() {
      return fileName;
    }

    @Override
    public String getOriginalFilename() {
      return fileName;
    }

    @Override
    public String getContentType() {
      return MediaType.TEXT_PLAIN_VALUE;
    }

    @Override
    public boolean isEmpty() {
      return content.length == 0;
    }

    @Override
    public long getSize() {
      return content.length;
    }

    @Override
    public byte[] getBytes() {
      return content;
    }

    @Override
    public InputStream getInputStream() {
      return new ByteArrayInputStream(content);
    }

    @Override
    public void transferTo(File dest) throws IOException {
      Files.write(dest.toPath(), content);
    }
  }
}
