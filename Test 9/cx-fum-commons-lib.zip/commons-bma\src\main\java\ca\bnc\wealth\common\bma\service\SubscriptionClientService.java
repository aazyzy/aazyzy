package ca.bnc.wealth.common.bma.service;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.common.bma.feign.client.SubscriptionClient;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnBean(SubscriptionClient.class)
@Slf4j
public class SubscriptionClientService {

  private static final String SYSTEM_TOKEN_NAME = "fum";

  @Autowired
  private SubscriptionClient subscriptionClient;

  @Autowired
  private SystemTokenFactory systemTokenFactory;

  /**
   * Emits events to subscribers of the given domain via the subscription API.
   * Errors are logged but not propagated to avoid disrupting the calling operation.
   */
  public void emit(String domain, List<Object> events) {
    try {
      log.info("emit # Start: domain: {}, eventCount: {}", domain, events.size());
      String token = systemTokenFactory.getBearerToken(SYSTEM_TOKEN_NAME);
      subscriptionClient.emit(token, domain, events);
      log.info("emit # Success: domain: {}", domain);
    } catch (Exception e) {
      log.error("emit # Error: domain: {}, message: {}", domain, e.getMessage(), e);
    }
  }

  /**
   * Subscribes to events matching the given criteria via the subscription API.
   * Unlike {@link #emit}, errors are propagated to the caller.
   *
   * @param criteria subscription criteria (domain, id, target, parameters)
   * @return subscription response containing the subscription ID
   */
  public Map<String, Object> subscribe(Map<String, Object> criteria) {
    log.debug("subscribe # Start: domain: {}", criteria.get("domain"));
    String token = systemTokenFactory.getBearerToken(SYSTEM_TOKEN_NAME);
    Map<String, Object> response = subscriptionClient.subscribe(token, criteria);
    log.debug("subscribe # Success: subscriptionId: {}", response != null ? response.get("id") : null);
    return response;
  }
}
