package ca.bnc.wealth.common.bma.service;

import ca.bnc.wealth.common.bma.model.BulkCsvResponse;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import tools.jackson.databind.json.JsonMapper;

import java.util.List;

import static org.mockito.Mockito.*;

class BulkManagementApiCallBackAopTest {

  @InjectMocks
  BulkManagementApiCallBackAop aop;

  @Mock
  BulkManagementClientService bulkManagementService;

  @Mock
  JsonMapper objectMapper;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void testProcessFailedResponseWithString() throws Exception {
    List<Long> ids = List.of(1L, 2L);
    String responseStr = "error";
    aop.processFailedResponse(responseStr, ids, "");
    verify(bulkManagementService, times(1)).updateStatus(anyList());
  }

  @Test
  void testProcessJsonResponseBody() throws Exception {
    Object responseBody = new Object();
    when(objectMapper.writeValueAsString(responseBody)).thenReturn("{\"result\":\"ok\"}");
    doNothing().when(bulkManagementService).updateStatus(anyList());
    aop.processJsonResponseBody(responseBody, 1L, "");
    verify(bulkManagementService, times(1)).updateStatus(anyList());
  }

  @Test
  void testProcessCsvResponseBody() throws Exception {
    BulkCsvResponse csvResponse = new BulkCsvResponse();
    csvResponse.setId("1");
    csvResponse.setStatus(BulkUploadStatus.SUCCESS.name());
    List<Object> responseList = List.of(csvResponse);
    when(objectMapper.writeValueAsString(csvResponse)).thenReturn("{\"id\":\"1\",\"status\":\"SUCCESS\"}");
    when(objectMapper.readValue(anyString(), eq(BulkCsvResponse.class))).thenReturn(csvResponse);
    doNothing().when(bulkManagementService).updateStatus(anyList());
    aop.processCsvResponseBody(responseList, "");
    verify(bulkManagementService, times(1)).updateStatus(anyList());
  }
}