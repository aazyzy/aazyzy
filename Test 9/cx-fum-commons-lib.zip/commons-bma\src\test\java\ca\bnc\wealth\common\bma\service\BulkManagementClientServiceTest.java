package ca.bnc.wealth.common.bma.service;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.common.bma.feign.client.BulkManagementClient;
import ca.bnc.wealth.common.bma.model.JsonPayLoad;
import ca.bnc.wealth.common.bulk_management.model.BatchStatus;
import ca.bnc.wealth.common.bulk_management.model.UpdateStatusRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;
import tools.jackson.databind.json.JsonMapper;

import java.nio.charset.StandardCharsets;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BulkManagementClientServiceTest {

  @InjectMocks
  BulkManagementClientService service;

  @Mock
  BulkManagementClient bulkManagementClient;

  @Mock
  SystemTokenFactory systemTokenFactory;

  @Mock
  JsonMapper objectMapper;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void testUpload() throws Exception {
    String token = "token";
    String templateName = "template";
    String firmId = "firm";
    String fileName = "file.json";
    List<JsonPayLoad> payloads = List.of(new JsonPayLoad());
    String json = "[{}]";
    when(systemTokenFactory.getBearerToken(anyString())).thenReturn(token);
    when(objectMapper.writeValueAsString(payloads)).thenReturn(json);
    when(bulkManagementClient.uploadFile(eq(token), eq(templateName), any(MultipartFile.class), eq(firmId)))
        .thenReturn(ResponseEntity.ok("success"));

    String result = service.upload(templateName, firmId, payloads, fileName);
    assertEquals("success", result);
  }

  @Test
  void uploadSendsThePayloadAsATextPartNamedAfterTheFile() throws Exception {
    String json = "[{\"firmId\":\"F1\"}]";
    byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
    List<JsonPayLoad> payloads = List.of(new JsonPayLoad());
    when(systemTokenFactory.getBearerToken(anyString())).thenReturn("token");
    when(objectMapper.writeValueAsString(payloads)).thenReturn(json);
    ArgumentCaptor<MultipartFile> sent = ArgumentCaptor.forClass(MultipartFile.class);
    when(bulkManagementClient.uploadFile(eq("token"), eq("template"), sent.capture(), eq("firm")))
        .thenReturn(ResponseEntity.ok("success"));

    service.upload("template", "firm", payloads, "file.json");

    MultipartFile file = sent.getValue();
    assertEquals("file.json", file.getName());
    assertEquals("file.json", file.getOriginalFilename());
    assertEquals("text/plain", file.getContentType());
    assertEquals(bytes.length, file.getSize());
    assertFalse(file.isEmpty());
    assertArrayEquals(bytes, file.getBytes());
    assertArrayEquals(bytes, file.getInputStream().readAllBytes());
  }

  @Test
  void uploadRejectsAnEmptyFileNameBeforeCallingTheClient() {
    List<JsonPayLoad> payloads = List.of(new JsonPayLoad());
    when(objectMapper.writeValueAsString(payloads)).thenReturn("[]");

    assertThrows(IllegalArgumentException.class, () -> service.upload("template", "firm", payloads, ""));
    verifyNoInteractions(bulkManagementClient);
  }

  @Test
  void testTriggerBulkProcess() {
    String token = "token";
    String batchId = "batch";
    when(systemTokenFactory.getBearerToken(anyString())).thenReturn(token);

    service.triggerBulkProcess(batchId);
  }

  @Test
  void testGetBatchStatusByBatchId() {
    String token = "token";
    String batchId = "batch";
    BatchStatus status = new BatchStatus();
    when(systemTokenFactory.getBearerToken(anyString())).thenReturn(token);
    when(bulkManagementClient.getBatchStatusByBatchId(token, batchId, true))
        .thenReturn(ResponseEntity.ok(status));

    BatchStatus result = service.getBatchStatusByBatchId(batchId, true);
    assertEquals(status, result);
  }

  @Test
  void testUpdateStatus() {
    String token = "token";
    List<UpdateStatusRequest> list = List.of(new UpdateStatusRequest());
    when(systemTokenFactory.getBearerToken(anyString())).thenReturn(token);

    service.updateStatus(list);
    verify(bulkManagementClient, times(1)).updateStatus(token, list);
  }
}
