package ca.bnc.wealth.common.bulk.action.client;

import ca.bnc.wealth.common.bulk.jsonb.ActionResponse;
import java.net.URI;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "SingleRequestFeignClient", url = "localhost:1234")
public interface SingleRequestFeignClient {

  @PostMapping(path = "/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  ResponseEntity<ActionResponse> action(URI url,
      @RequestHeader("Authorization") String authorization, @RequestBody String requestJSON);

}
