package ca.bnc.wealth.common.bulk.action.enums;

public enum EntityEnum {
  TEMPLATE, BULK_UPLOAD, BULK_ACTION, SINGLE_ACTION;
}
