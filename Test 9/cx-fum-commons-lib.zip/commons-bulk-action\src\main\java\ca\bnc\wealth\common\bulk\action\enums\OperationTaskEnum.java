package ca.bnc.wealth.common.bulk.action.enums;

public enum OperationTaskEnum {
  CONVERSION, VALIDATION, ACTION;
}
