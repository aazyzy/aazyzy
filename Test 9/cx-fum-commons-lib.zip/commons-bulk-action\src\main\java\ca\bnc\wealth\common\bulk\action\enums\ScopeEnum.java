package ca.bnc.wealth.common.bulk.action.enums;

public enum ScopeEnum {
  GLOBAL, USER, FIRM, FIRM_CHILDFIRM;
}
