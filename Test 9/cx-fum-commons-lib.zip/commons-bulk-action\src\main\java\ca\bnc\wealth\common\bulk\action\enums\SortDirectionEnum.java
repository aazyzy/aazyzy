package ca.bnc.wealth.common.bulk.action.enums;

public enum SortDirectionEnum {
  ASC, DESC;
}
