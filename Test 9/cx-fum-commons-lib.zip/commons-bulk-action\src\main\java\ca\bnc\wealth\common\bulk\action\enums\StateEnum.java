package ca.bnc.wealth.common.bulk.action.enums;

public enum StateEnum {
  SUBMITTED, PENDING, PROCESSING, SUCCESS, FAILED;
}
