package ca.bnc.wealth.common.bulk.action.hook;

import java.util.List;
import java.util.Map;

public interface BulkPostUploadValidationHookInterface extends HookInterface {

  Map<String, List<Long>> validation(List<Map<String, String>> parsedFileContents);
}
