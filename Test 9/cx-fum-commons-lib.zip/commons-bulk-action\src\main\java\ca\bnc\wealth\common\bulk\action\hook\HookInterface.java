package ca.bnc.wealth.common.bulk.action.hook;

import ca.bnc.wealth.common.bulk.action.enums.HookEnum;

public interface HookInterface {

  String getTemplateName();

  HookEnum getHookEnum();
}
