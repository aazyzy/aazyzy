package ca.bnc.wealth.common.bulk.action.hook;

import ca.bnc.wealth.common.bulk.jsonb.ActionResponse;

public interface SinglePostActionHookInterface extends HookInterface {

  ActionResponse updateSingleResponse(ActionResponse response);
}
