package ca.bnc.wealth.common.bulk.action.hook;

public interface SinglePreActionHookInterface extends HookInterface {

  String updateSingleRequest(String String);
}
