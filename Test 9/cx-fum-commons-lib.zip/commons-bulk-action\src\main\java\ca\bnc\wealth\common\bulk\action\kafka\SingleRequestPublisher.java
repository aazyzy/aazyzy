package ca.bnc.wealth.common.bulk.action.kafka;

import ca.bnc.wealth.common.bulk.entity.SingleActionMappedSuperClass;
import ca.bnc.wealth.common.kafka.core.publisher.Publisher;
import ca.bnc.wealth.common.kafka.messaging.publisher.EventMessagePublisherFactory;
import jakarta.annotation.PostConstruct;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import tools.jackson.databind.json.JsonMapper;

@Service
@Slf4j
public class SingleRequestPublisher {

  protected Publisher<String, String> publisher;
  @Autowired
  private EventMessagePublisherFactory publisherFactory;
  @Autowired
  private JsonMapper objectMapper;
  @Value("${bulk.producer.action}")
  private String producerActionName;

  @PostConstruct
  public void init() {
    this.publisher = publisherFactory.createNewPublisher(producerActionName);
  }

  public void publishMessage(String templateName,
      SingleActionMappedSuperClass singleActionMappedSuperClass) {
    try {
      log.info("Publishing template:" + templateName + ", single Request Id:"
          + singleActionMappedSuperClass.getSingleActionId());
      publisher.publishSynchronous(
          templateName + "|" + singleActionMappedSuperClass.getSingleActionId());
    } catch (ExecutionException | TimeoutException e) {
      throw new RuntimeException("Failed to publish message to Kafka", e);
    }
  }
}
