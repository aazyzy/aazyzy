package ca.bnc.wealth.common.bulk.action.kafka;

import ca.bnc.wealth.common.bulk.action.service.SingleRequestService;
import ca.bnc.wealth.common.kafka.core.subscriber.Subscriber;
import ca.bnc.wealth.common.kafka.core.subscriber.SubscriberFactory;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class SingleRequestSubscriber {

  @Autowired
  private SubscriberFactory subscriberFactory;

  @Autowired
  private SingleRequestService singleRequestService;

  @Value("${bulk.consumer.group-id}")
  private String consumerGroupId;

  @Value("${bulk.consumer.action}")
  private String consumerName;

  @PostConstruct
  public void init() {
    Subscriber<String, String> subscriber = subscriberFactory.createNewSubscriber(consumerName,
        consumerGroupId, consumerRecord -> processMessage(consumerRecord.value()));
    subscriber.subscribe();
  }

  public void processMessage(String singleActionIdAndTemplateName) {

    try {
      if (singleActionIdAndTemplateName != null) {
        String[] temp = singleActionIdAndTemplateName.split("\\|");
        log.info("processing message template:" + temp[0] + ", single Request Id:" + temp[1]);
        singleRequestService.singleRequestProcessing(temp[0], Long.parseLong(temp[1]));
      } else {
        log.error("Unable to convert to Single Action");
      }
    } catch (Exception exception) {
      log.error("unable to process the message, error message: {}", exception.getMessage());
    }

  }

}
