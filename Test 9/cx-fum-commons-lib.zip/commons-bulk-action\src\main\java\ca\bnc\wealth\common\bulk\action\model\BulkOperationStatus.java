package ca.bnc.wealth.common.bulk.action.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BulkOperationStatus {

  private long bulkActionId;

  private String requestId;

  private String state;

  private String operation;

  private long singleActionCount;

  private long singleActionSuccessCount;

  private long singleActionFailCount;

}
