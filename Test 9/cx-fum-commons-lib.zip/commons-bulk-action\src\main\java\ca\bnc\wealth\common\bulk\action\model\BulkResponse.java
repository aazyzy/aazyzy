package ca.bnc.wealth.common.bulk.action.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BulkResponse {

  private long bulkActionId;

  private String bulkRequestId;

  private String status;

  private String errorMessage;
}
