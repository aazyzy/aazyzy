package ca.bnc.wealth.common.bulk.action.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BulkUploadStatus {

  private long bulkUploadId;
  private String state;

  private BulkUploadStatusMessages messages;
}
