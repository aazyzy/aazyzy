package ca.bnc.wealth.common.bulk.action.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BulkUploadStatusMessages {

  private Map<String, List<String>> info = new HashMap<>();
  private Map<String, List<String>> warnings = new HashMap<>();

  private Map<String, List<String>> errors = new HashMap<>();
}
