package ca.bnc.wealth.common.bulk.action.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PageResponse<T> {

  long totalRecords;

  int pageNumber;

  int pageSize;

  List<T> lst;
}
