package ca.bnc.wealth.common.bulk.action.schedule;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.common.bulk.action.enums.EntityEnum;
import ca.bnc.wealth.common.bulk.action.enums.OperationTaskEnum;
import ca.bnc.wealth.common.bulk.action.enums.StateEnum;
import ca.bnc.wealth.common.bulk.action.service.BulkOperationJpa;
import ca.bnc.wealth.common.bulk.action.service.BulkOperationService;
import ca.bnc.wealth.common.bulk.entity.BulkActionMappedSuperClass;
import ca.bnc.wealth.common.bulk.entity.BulkUploadMappedSuperClass;
import ca.bnc.wealth.common.bulk.entity.SingleActionMappedSuperClass;
import ca.bnc.wealth.common.bulk.repo.SingleActionRepositoryInterface;
import ca.bnc.wealth.common.jpa.service.ScheduleService;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BulkActionStatusCheckService {

  @Autowired
  private BulkOperationJpa bulkOperationJpa;

  @Autowired
  private ScheduleService scheduleService;

  @Autowired
  private BulkOperationService bulkOperationService;

  @Value("${bulk.schedule.name}")
  private String scheduleName;

  @Value("${bulk.schedule.duration:10}")
  private long schedulerDuration;

  @Scheduled(
      fixedDelayString = "${bulk.schedule.duration:10}",
      timeUnit = TimeUnit.SECONDS)
  public void updateBulkStatus() {
    if (this.scheduleService.canRunSchedule(scheduleName, schedulerDuration, TimeUnit.SECONDS)) {
      List<? extends BulkActionMappedSuperClass> lst = getPendingBulkRequest();

      ExecutorService executorService = Executors.newFixedThreadPool(10);
      lst.forEach(entity -> executorService.submit(() -> this.checkAndUpdateStatus(entity)));
      shutdownAndAwait(executorService);
      this.scheduleService.updateStatusToFinish(scheduleName);
    }
  }

  private void checkAndUpdateStatus(BulkActionMappedSuperClass bulkActionMappedSuperClass) {
    long bulkUploadId = bulkActionMappedSuperClass.getBulkUploadId();
    long bulkActionId = bulkActionMappedSuperClass.getBulkActionId();
    OperationTaskEnum operationTaskEnum = OperationTaskEnum.valueOf(
        bulkActionMappedSuperClass.getActionType());
    long totalSingleRequest = bulkActionMappedSuperClass.getSingleActionCount();

    SingleActionRepositoryInterface singleActionRepositoryInterface = bulkOperationJpa.getRepositoryObject(
        EntityEnum.SINGLE_ACTION);
    long singleActionSuccessfull = singleActionRepositoryInterface.countByBulkRequestIDAndState(
        bulkActionId, StateEnum.SUCCESS.name());
    long singleActionFailed = singleActionRepositoryInterface.countByBulkRequestIDAndState(
        bulkActionId, StateEnum.FAILED.name());

    if (totalSingleRequest == singleActionSuccessfull) {
      if (operationTaskEnum == OperationTaskEnum.CONVERSION) {
        updateConvertResponse(bulkUploadId, bulkActionId);
      }

      bulkActionMappedSuperClass.setState(StateEnum.SUCCESS.name());
      bulkOperationJpa.saveAndFlush(bulkActionMappedSuperClass);
      bulkOperationJpa.updateBulkUpload(bulkUploadId, bulkActionId, operationTaskEnum,
          StateEnum.SUCCESS);
      log.info("Bulk Action id " + bulkActionId + " is successfully");

      startNextAction(bulkActionMappedSuperClass);
    } else if (singleActionSuccessfull + singleActionFailed == totalSingleRequest) {
      bulkActionMappedSuperClass.setState(StateEnum.FAILED.name());
      bulkOperationJpa.saveAndFlush(bulkActionMappedSuperClass);
      bulkOperationJpa.updateBulkUpload(bulkUploadId, bulkActionId, operationTaskEnum,
          StateEnum.FAILED);
      log.info("Bulk Action id " + bulkActionId + " is failed");
    }
  }

  private void startNextAction(BulkActionMappedSuperClass bulkActionMappedSuperClass) {
    String nextActions = bulkActionMappedSuperClass.getNextAction();
    if (StringUtils.isNotBlank(nextActions)) {
      User user = new User();
      user.setIdpSubject(bulkActionMappedSuperClass.getCreatedBy());
      bulkOperationService.bulkTask(user, bulkActionMappedSuperClass.getBulkUploadId(),
          Arrays.asList(nextActions.split(",")));
    }
  }

  private void updateConvertResponse(long bulkUploadId, long bulkActionId) {
    JpaRepository bulkUploadJpaRepo = bulkOperationJpa.getJpaRepository(EntityEnum.BULK_UPLOAD);

    BulkUploadMappedSuperClass bulkUploadMappedSuperClass = (BulkUploadMappedSuperClass) bulkUploadJpaRepo.findById(
        bulkUploadId).get();

    SingleActionRepositoryInterface singleActionRepositoryInterface = bulkOperationJpa.getRepositoryObject(
        EntityEnum.SINGLE_ACTION);
    List<? extends SingleActionMappedSuperClass> lst = singleActionRepositoryInterface.findByBulkRequestID(
        bulkActionId);

    Map<String, String> rowResponseMap = lst.stream()
        .map(entity -> Pair.of(entity.getUploadRowNumber(), entity.getActionResponse().getData()))
        .collect(Collectors.toMap(Pair::getLeft, Pair::getRight));

    bulkUploadMappedSuperClass.getUploadResponse().getSingleRequests()
        .forEach(singleRequest -> singleRequest.setConvertedData(
            rowResponseMap.get(singleRequest.getUploadRowNumber())));

    bulkOperationJpa.saveAndFlush(bulkUploadMappedSuperClass);
  }

  private List<? extends BulkActionMappedSuperClass> getPendingBulkRequest() {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("state", Pair.of(EnumQueryCriteria.EQUALS, StateEnum.PENDING.name()));

    Specification<? extends BulkActionMappedSuperClass> specification = new Specification<>(
        fieldValueMap);

    JpaSpecificationExecutor jpaSpecificationExecutor = bulkOperationJpa.getJpaSpecificationExecutor(
        EntityEnum.BULK_ACTION);

    return jpaSpecificationExecutor.findAll(specification);
  }

  @SneakyThrows
  private void shutdownAndAwait(ExecutorService executorService) {
    executorService.shutdown();
    try {
      executorService.awaitTermination(100000, TimeUnit.MILLISECONDS);
    } catch (InterruptedException e) {
      executorService.shutdownNow();
      log.error("Error in executor service with error: {}", e.getMessage());
      throw e;
    }
  }
}
