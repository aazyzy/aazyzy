package ca.bnc.wealth.common.bulk.action.schedule;

import ca.bnc.wealth.common.bulk.action.enums.EntityEnum;
import ca.bnc.wealth.common.bulk.action.service.BulkOperationJpa;
import ca.bnc.wealth.common.bulk.repo.BulkActionRepositoryInterface;
import ca.bnc.wealth.common.bulk.repo.BulkUploadRepositoryInterface;
import ca.bnc.wealth.common.bulk.repo.SingleActionRepositoryInterface;
import ca.bnc.wealth.common.jpa.service.ScheduleService;
import jakarta.annotation.PostConstruct;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BulkRetentionService {

  @Autowired
  private BulkOperationJpa bulkOperationJpa;

  @Autowired
  private ScheduleService scheduleService;


  @Value("${bulk.schedule.name}")
  private String scheduleName;


  private String retentionScheduleName;

  @PostConstruct
  public void init() {
    retentionScheduleName = scheduleName + "_RETENTION";
  }

  //@Scheduled(cron = "0 0 21 ? * SUN")
  @Scheduled(cron = "0 0 0 * * *")
  public void deleteOldRecords() {
    try {
      if (this.scheduleService.canRunSchedule(retentionScheduleName, 10, TimeUnit.MINUTES)) {
        Timestamp timestamp = Timestamp.valueOf(LocalDateTime.now());

        BulkUploadRepositoryInterface bulkUploadRepositoryInterface = bulkOperationJpa.getRepositoryObject(
            EntityEnum.BULK_UPLOAD);
        bulkUploadRepositoryInterface.deleteByRetentionBefore(timestamp);

        BulkActionRepositoryInterface bulkActionRepositoryInterface = bulkOperationJpa.getRepositoryObject(
            EntityEnum.BULK_ACTION);
        bulkActionRepositoryInterface.deleteByRetentionBefore(timestamp);

        SingleActionRepositoryInterface singleActionRepositoryInterface = bulkOperationJpa.getRepositoryObject(
            EntityEnum.SINGLE_ACTION);
        singleActionRepositoryInterface.deleteByRetentionBefore(timestamp);

        this.scheduleService.updateStatusToFinish(retentionScheduleName);
      }
    } catch (Exception e) {
      this.scheduleService.updateStatusToFinish(retentionScheduleName);
    }
  }
}
