package ca.bnc.wealth.common.bulk.action.service;

import ca.bnc.wealth.common.bulk.action.enums.HookEnum;
import ca.bnc.wealth.common.bulk.action.enums.OperationTaskEnum;
import ca.bnc.wealth.common.bulk.action.hook.BulkPostUploadValidationHookInterface;
import ca.bnc.wealth.common.bulk.action.hook.HookInterface;
import ca.bnc.wealth.common.bulk.action.hook.SinglePostActionHookInterface;
import ca.bnc.wealth.common.bulk.action.hook.SinglePreActionHookInterface;
import ca.bnc.wealth.common.bulk.entity.BulkTemplateMappedSuperClass;
import ca.bnc.wealth.common.bulk.jsonb.ActionResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class BulkHookService {

  @Autowired
  private TemplateService templateService;

  @Autowired
  private ConfigurableListableBeanFactory beanFactory;

  private Map<String, Map<HookEnum, Object>> templateHootServiceMap = new HashMap<>();

  @Order(11)
  @EventListener(ApplicationReadyEvent.class)
  public void runAfterReady() {
    List<BulkTemplateMappedSuperClass> templates = templateService.getAllTemplate();

    beanFactory.getBeansOfType(BulkPostUploadValidationHookInterface.class)
        .forEach((k, v) -> updateMap(v.getHookEnum(), v));
    beanFactory.getBeansOfType(SinglePreActionHookInterface.class)
        .forEach((k, v) -> updateMap(v.getHookEnum(), v));
    beanFactory.getBeansOfType(SinglePostActionHookInterface.class)
        .forEach((k, v) -> updateMap(v.getHookEnum(), v));
  }

  public Map<String, List<Long>> uploadValidation(String templateName,
      List<Map<String, String>> parsedFileContents) {
    BulkPostUploadValidationHookInterface service = (BulkPostUploadValidationHookInterface) getService(
        templateName, HookEnum.POST_UPLOAD_VALIDATION);
    return Optional.ofNullable(service)
        .map(s -> s.validation(parsedFileContents))
        .orElse(null);
  }

  public String updateSingleRequest(String templateName, String requestId, String initialRequest) {
    SinglePreActionHookInterface service = (SinglePreActionHookInterface) getService(templateName,
        getSingleRequestHookEnum(requestId));
    return Optional.ofNullable(service)
        .map(s -> s.updateSingleRequest(initialRequest))
        .orElse(initialRequest);
  }

  public ActionResponse updateSingleResponse(String templateName, String requestId,
      ActionResponse initialResponse) {
    SinglePostActionHookInterface service = (SinglePostActionHookInterface) getService(templateName,
        getSingleResponseHookEnum(requestId));
    return Optional.ofNullable(service)
        .map(s -> s.updateSingleResponse(initialResponse))
        .orElse(initialResponse);
  }

  private Object getService(String templateName, HookEnum hookEnum) {
    Map<HookEnum, Object> map = templateHootServiceMap.get(templateName);
    if (map != null) {
      BulkPostUploadValidationHookInterface service = (BulkPostUploadValidationHookInterface) map.get(
          hookEnum);
      return service;
    }
    return null;
  }

  private void updateMap(HookEnum hookEnum, HookInterface service) {
    String templateName = service.getTemplateName();
    if (!templateHootServiceMap.containsKey(templateName)) {
      templateHootServiceMap.put(templateName, new HashMap<>());
    }
    templateHootServiceMap.get(templateName).put(hookEnum, service);
  }

  private HookEnum getSingleRequestHookEnum(String requestId) {
    return HookEnum.valueOf("PRE_SINGLE_" + getOperation(requestId).name());
  }

  private HookEnum getSingleResponseHookEnum(String requestId) {
    return HookEnum.valueOf("POST_SINGLE_" + getOperation(requestId).name());
  }

  private OperationTaskEnum getOperation(String requestId) {
    if (requestId.endsWith("C")) {
      return OperationTaskEnum.CONVERSION;
    }
    if (requestId.endsWith("V")) {
      return OperationTaskEnum.VALIDATION;
    } else {
      return OperationTaskEnum.ACTION;
    }
  }
}
