package ca.bnc.wealth.common.bulk.action.service;

import ca.bnc.wealth.common.bulk.action.enums.EntityEnum;
import ca.bnc.wealth.common.bulk.action.enums.OperationTaskEnum;
import ca.bnc.wealth.common.bulk.action.enums.StateEnum;
import ca.bnc.wealth.common.bulk.entity.BulkActionMappedSuperClass;
import ca.bnc.wealth.common.bulk.entity.BulkTemplateMappedSuperClass;
import ca.bnc.wealth.common.bulk.entity.BulkUploadMappedSuperClass;
import ca.bnc.wealth.common.bulk.entity.SingleActionMappedSuperClass;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class BulkOperationJpa {

  @Autowired
  private EntityRepositoryFactory entityRepositoryFactory;


  public <T> T getEntityInstance(EntityEnum entityEnum) {
    return (T) entityRepositoryFactory.getEntityInstance(entityEnum);
  }

  public <T> T getJpaRepository(EntityEnum entityEnum) {
    return (T) entityRepositoryFactory.getJpaRepository(entityEnum);
  }

  public <T> T getJpaSpecificationExecutor(EntityEnum entityEnum) {
    return (T) entityRepositoryFactory.getJpaSpecificationExecutor(entityEnum);
  }

  public <T> T getRepositoryObject(EntityEnum entityEnum) {
    return (T) entityRepositoryFactory.getRepositoryObject(entityEnum);
  }

  public BulkTemplateMappedSuperClass saveAndFlush(
      BulkTemplateMappedSuperClass bulkTemplateMappedSuperClass) {
    JpaRepository repository = getJpaRepository(EntityEnum.TEMPLATE);
    return (BulkTemplateMappedSuperClass) repository.saveAndFlush(bulkTemplateMappedSuperClass);
  }

  public BulkUploadMappedSuperClass saveAndFlush(
      BulkUploadMappedSuperClass bulkUploadMappedSuperClass) {
    JpaRepository repository = getJpaRepository(EntityEnum.BULK_UPLOAD);
    return (BulkUploadMappedSuperClass) repository.saveAndFlush(bulkUploadMappedSuperClass);
  }

  public BulkActionMappedSuperClass saveAndFlush(
      BulkActionMappedSuperClass bulkActionMappedSuperClass) {
    JpaRepository repository = getJpaRepository(EntityEnum.BULK_ACTION);
    return (BulkActionMappedSuperClass) repository.saveAndFlush(bulkActionMappedSuperClass);
  }

  public SingleActionMappedSuperClass saveAndFlush(
      SingleActionMappedSuperClass singleActionMappedSuperClass) {
    JpaRepository repository = getJpaRepository(EntityEnum.SINGLE_ACTION);
    return (SingleActionMappedSuperClass) repository.saveAndFlush(singleActionMappedSuperClass);
  }

  public SingleActionMappedSuperClass getSingleActionById(long singeActionId) {
    JpaRepository repository = getJpaRepository(EntityEnum.SINGLE_ACTION);
    return (SingleActionMappedSuperClass) repository.findById(singeActionId).get();
  }

  public BulkActionMappedSuperClass getBulkActionById(long bulkId) {
    JpaRepository repository = getJpaRepository(EntityEnum.BULK_ACTION);
    return (BulkActionMappedSuperClass) repository.findById(bulkId).get();
  }

  public BulkUploadMappedSuperClass getBulkUploadById(long bulkUploadId) {
    JpaRepository repository = getJpaRepository(EntityEnum.BULK_UPLOAD);
    return (BulkUploadMappedSuperClass) repository.findById(bulkUploadId).get();
  }

  public void updateBulkUpload(long bulkUploadId, long bulkActionId,
      OperationTaskEnum operationTaskEnum, StateEnum status) {
    BulkUploadMappedSuperClass bulkUploadMappedSuperClass = getBulkUploadById(bulkUploadId);
    switch (operationTaskEnum) {
      case CONVERSION:
        bulkUploadMappedSuperClass.setBulkConvertRequestId(bulkActionId);
        bulkUploadMappedSuperClass.setBulkConvertStatus(status.name());
        break;
      case VALIDATION:
        bulkUploadMappedSuperClass.setBulkValidateRequestId(bulkActionId);
        bulkUploadMappedSuperClass.setBulkValidateStatus(status.name());
        break;
      case ACTION:
        bulkUploadMappedSuperClass.setBulkActionRequestId(bulkActionId);
        bulkUploadMappedSuperClass.setBulkActionStatus(status.name());
        break;
    }
    JpaRepository jpaRepository = getJpaRepository(EntityEnum.BULK_UPLOAD);
    jpaRepository.saveAndFlush(bulkUploadMappedSuperClass);
  }
}
