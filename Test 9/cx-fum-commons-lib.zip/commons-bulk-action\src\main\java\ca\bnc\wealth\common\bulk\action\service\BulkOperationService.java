package ca.bnc.wealth.common.bulk.action.service;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.common.bulk.action.enums.SortDirectionEnum;
import ca.bnc.wealth.common.bulk.action.model.BulkDownloadResource;
import ca.bnc.wealth.common.bulk.action.model.BulkOperationStatus;
import ca.bnc.wealth.common.bulk.action.model.BulkResponse;
import ca.bnc.wealth.common.bulk.action.model.BulkUploadStatus;
import ca.bnc.wealth.common.bulk.action.model.PageResponse;
import ca.bnc.wealth.common.bulk.entity.BulkUploadMappedSuperClass;
import java.util.List;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@Service
public class BulkOperationService {

  @Autowired
  private BulkUploadService bulkUploadService;

  @Autowired
  private BulkTaskService bulkTaskService;

  @Autowired
  private BulkStatusService bulkStatusService;

  @Autowired
  private BulkScopeService bulkScopeService;

  public BulkUploadStatus uploadCsv(User user, String templateName, MultipartFile fileToUpload) {
    return bulkUploadService.convertFileToUploadResponse(user, null, templateName, fileToUpload);
  }

  public BulkUploadStatus uploadCsv(User user, String firmId, String templateName,
      MultipartFile fileToUpload) {
    return bulkUploadService.convertFileToUploadResponse(user, firmId, templateName, fileToUpload);
  }

  @SneakyThrows
  public BulkResponse bulkTask(User user, long uploadId, List<String> task) {
    bulkScopeService.validate(user.getIdpSubject(), uploadId);
    return bulkTaskService.bulkTask(user, uploadId, task);
  }

  public PageResponse<? extends BulkUploadMappedSuperClass> getBulkUploadHistory(
      String templateName, boolean uploadWithAction, int pageNumber, int pageSize,
      List<String> sortBy, SortDirectionEnum sortDirection) {
    return bulkUploadService.getBulkUploadHistory(templateName, uploadWithAction, pageNumber,
        pageSize, sortBy, sortDirection);
  }

  @SneakyThrows
  public BulkOperationStatus getBulkStatus(String requestId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    bulkScopeService.validateBulkRequest(user.getIdpSubject(), requestId);
    return bulkStatusService.getBulkStatus(requestId);
  }

  @SneakyThrows
  public List<BulkOperationStatus> getBulkUploadStatus(String bulkUploadId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    bulkScopeService.validate(user.getIdpSubject(), Long.parseLong(bulkUploadId));
    return bulkStatusService.getBulkUploadStatus(bulkUploadId);
  }

  @SneakyThrows
  public BulkDownloadResource downloadStatusCsv(String bulkUploadId,
      List<String> fieldFromResponse) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    bulkScopeService.validate(user.getIdpSubject(), Long.parseLong(bulkUploadId));
    return bulkStatusService.downloadStatusCsv(bulkUploadId, fieldFromResponse);
  }
}
