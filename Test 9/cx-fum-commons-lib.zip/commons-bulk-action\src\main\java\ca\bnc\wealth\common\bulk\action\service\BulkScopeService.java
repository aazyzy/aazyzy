package ca.bnc.wealth.common.bulk.action.service;

import ca.bnc.wealth.common.bulk.action.enums.EntityEnum;
import ca.bnc.wealth.common.bulk.action.enums.ScopeEnum;
import ca.bnc.wealth.common.bulk.action.utils.BulkUtils;
import ca.bnc.wealth.common.bulk.entity.BulkActionMappedSuperClass;
import ca.bnc.wealth.common.bulk.entity.BulkTemplateMappedSuperClass;
import ca.bnc.wealth.common.bulk.entity.BulkUploadMappedSuperClass;
import ca.bnc.wealth.common.jpa.entity.platform.FirmConfiguration;
import ca.bnc.wealth.common.jpa.repo.platform.FirmConfigurationRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class BulkScopeService {

  @Autowired
  private BulkOperationJpa bulkOperationJpa;

  @Autowired
  private TemplateService templateService;

  @Autowired
  private FirmConfigurationRepository firmConfigurationRepository;

  public void validateBulkRequest(String idpSubject, String requestId) throws Throwable {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    if (BulkUtils.isNumeric(requestId)) {
      fieldValueMap.put("bulkActionId", Pair.of(EnumQueryCriteria.EQUALS, requestId));
    } else {
      fieldValueMap.put("requestID", Pair.of(EnumQueryCriteria.EQUALS, requestId));
    }
    Specification<? extends BulkActionMappedSuperClass> specification = new Specification<>(
        fieldValueMap);

    JpaSpecificationExecutor jpaSpecificationExecutor = bulkOperationJpa.getJpaSpecificationExecutor(
        EntityEnum.BULK_ACTION);

    BulkActionMappedSuperClass bulkActionMappedSuperClass = (BulkActionMappedSuperClass) jpaSpecificationExecutor.findOne(
            specification)
        .orElseThrow(() -> new Exception("Not found"));
    validate(idpSubject, bulkActionMappedSuperClass.getBulkUploadId());
  }

  public void validate(String idpSubject, long bulkUploadId) throws Exception {

    JpaRepository jpaRepository = bulkOperationJpa.getJpaRepository(EntityEnum.BULK_UPLOAD);
    Optional<BulkUploadMappedSuperClass> optional = jpaRepository.findById(bulkUploadId);

    BulkUploadMappedSuperClass bulkUploadMappedSuperClass = optional
        .orElseThrow(() -> new IllegalArgumentException(
            "Unable to find bulk upload with bulkUploadId: " + bulkUploadId));

    BulkTemplateMappedSuperClass bulkTemplateMappedSuperClass = templateService.getTemplate(
        bulkUploadMappedSuperClass.getTemplateId());

    ScopeEnum scopeEnum = ScopeEnum.valueOf(bulkTemplateMappedSuperClass.getTemplateScope());
    switch (scopeEnum) {
      case GLOBAL:
        return;
      case USER:
        if (bulkUploadMappedSuperClass.getScopeValue().equalsIgnoreCase(idpSubject)) {
          return;
        }
        break;
      case FIRM:
        List<FirmConfiguration> firmLst = firmConfigurationRepository.findFirmConfiguratoin(
            idpSubject, "RESOURCE_ENTITY_TYPE", "F");
        if (!firmLst.isEmpty() && firmLst.get(0).getFirmId()
            .equalsIgnoreCase(bulkUploadMappedSuperClass.getScopeValue())) {
          return;
        }
        break;
      case FIRM_CHILDFIRM:
        if (isChildFirm(idpSubject, bulkUploadMappedSuperClass.getScopeValue())) {
          return;
        }
        break;
    }
    throw new Exception("Login user don't have access to bulkuploadId:" + bulkUploadId);
  }

  public String getScopeValue(BulkTemplateMappedSuperClass bulkTemplateMappedSuperClass,
      String idpSubject, String firmId) throws Exception {

    switch (ScopeEnum.valueOf(bulkTemplateMappedSuperClass.getTemplateScope())) {
      case GLOBAL:
        return null;
      case USER:
        return idpSubject;
      case FIRM:
        List<FirmConfiguration> firmLst = firmConfigurationRepository.findFirmConfiguratoin(
            idpSubject, "RESOURCE_ENTITY_TYPE", "F");
        if (firmLst.isEmpty()) {
          throw new Exception(String.format("No firms associated to user %s", idpSubject));
        } else if (!firmLst.get(0).getFirmId().equalsIgnoreCase(firmId)) {
          throw new Exception(
              String.format("firm id %s is not primary firm to user %s", firmId, idpSubject));
        }
        return firmLst.get(0).getFirmId();
      case FIRM_CHILDFIRM:
        if (isChildFirm(idpSubject, firmId)) {
          return firmId;
        }
    }
    return null;
  }

  private boolean isChildFirm(String idpSubject, String firmId) {
    List<FirmConfiguration> firmLst = firmConfigurationRepository.findFirmConfiguratoin(idpSubject,
        "RESOURCE_ENTITY_TYPE", "F");
    if (firmLst.get(0).getFirmId().equalsIgnoreCase("NBIN")) {
      return true;
    }

    List<Long> firmIdLst = firmConfigurationRepository.getAllFirmsByIdpSubject(idpSubject);
    return firmConfigurationRepository.findByFirmConfigurationIdIn(firmIdLst).stream()
        .map(FirmConfiguration::getFirmId)
        .anyMatch(id -> id.equalsIgnoreCase(firmId));
  }
}
