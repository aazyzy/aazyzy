package ca.bnc.wealth.common.bulk.action.service;

import ca.bnc.wealth.common.bulk.action.enums.EntityEnum;
import ca.bnc.wealth.common.bulk.action.enums.OperationTaskEnum;
import ca.bnc.wealth.common.bulk.action.enums.StateEnum;
import ca.bnc.wealth.common.bulk.action.model.BulkDownloadResource;
import ca.bnc.wealth.common.bulk.action.model.BulkOperationStatus;
import ca.bnc.wealth.common.bulk.action.utils.BulkUtils;
import ca.bnc.wealth.common.bulk.action.utils.Constants;
import ca.bnc.wealth.common.bulk.entity.BulkActionMappedSuperClass;
import ca.bnc.wealth.common.bulk.entity.BulkUploadMappedSuperClass;
import ca.bnc.wealth.common.bulk.entity.SingleActionMappedSuperClass;
import ca.bnc.wealth.common.bulk.jsonb.ActionResponse;
import ca.bnc.wealth.common.bulk.repo.SingleActionRepositoryInterface;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Service;
import tools.jackson.databind.json.JsonMapper;

@Slf4j
@Service
public class BulkStatusService {

  @Autowired
  private BulkOperationJpa bulkOperationJpa;

  @Autowired
  private CsvWriteService csvWriteService;

  @Autowired
  private JsonMapper objectMapper;

  @SneakyThrows
  public BulkOperationStatus getBulkStatus(String requestId) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    if (BulkUtils.isNumeric(requestId)) {
      fieldValueMap.put("bulkActionId", Pair.of(EnumQueryCriteria.EQUALS, requestId));
    } else {
      fieldValueMap.put("requestID", Pair.of(EnumQueryCriteria.EQUALS, requestId));
    }
    Specification<? extends BulkActionMappedSuperClass> specification = new Specification<>(
        fieldValueMap);

    JpaSpecificationExecutor jpaSpecificationExecutor = bulkOperationJpa.getJpaSpecificationExecutor(
        EntityEnum.BULK_ACTION);

    BulkActionMappedSuperClass bulkActionMappedSuperClass = (BulkActionMappedSuperClass) jpaSpecificationExecutor.findOne(
            specification)
        .orElseThrow(() -> new Exception("Not found"));

    return getBulkOperationStatus(bulkActionMappedSuperClass);
  }

  @SneakyThrows
  public List<BulkOperationStatus> getBulkUploadStatus(String requestId) {

    BulkUploadMappedSuperClass bulkUploadMappedSuperClass = getBulkUpload(requestId)
        .orElseThrow(() -> new Exception("Not found"));

    List<Long> bulkId = new ArrayList<>();
    if (bulkUploadMappedSuperClass.getBulkConvertRequestId() != 0) {
      bulkId.add(bulkUploadMappedSuperClass.getBulkConvertRequestId());
    }
    if (bulkUploadMappedSuperClass.getBulkValidateRequestId() != 0) {
      bulkId.add(bulkUploadMappedSuperClass.getBulkValidateRequestId());
    }
    if (bulkUploadMappedSuperClass.getBulkActionRequestId() != 0) {
      bulkId.add(bulkUploadMappedSuperClass.getBulkActionRequestId());
    }

    return getBulkOperationStatus(bulkId);
  }

  @SneakyThrows
  public BulkDownloadResource downloadStatusCsv(String bulkUploadId,
      List<String> fieldFromResponse) {
    Long bulkId = null;
    OperationTaskEnum operationTaskEnum = null;

    BulkUploadMappedSuperClass bulkUploadMappedSuperClass = getBulkUpload(bulkUploadId)
        .orElseThrow(() -> new Exception("Not found"));

    if (bulkUploadMappedSuperClass.getBulkActionRequestId() != 0) {
      bulkId = bulkUploadMappedSuperClass.getBulkActionRequestId();
      operationTaskEnum = OperationTaskEnum.ACTION;
    } else if (bulkUploadMappedSuperClass.getBulkValidateRequestId() != 0) {
      bulkId = bulkUploadMappedSuperClass.getBulkValidateRequestId();
      operationTaskEnum = OperationTaskEnum.VALIDATION;
    } else if (bulkUploadMappedSuperClass.getBulkConvertRequestId() != 0) {
      bulkId = bulkUploadMappedSuperClass.getBulkConvertRequestId();
      operationTaskEnum = OperationTaskEnum.CONVERSION;
    }
    if (operationTaskEnum == null) {
      new Exception("Not found");
    }

    JpaRepository jpaRepository = bulkOperationJpa.getJpaRepository(EntityEnum.BULK_ACTION);
    BulkActionMappedSuperClass bulkActionMappedSuperClass = (BulkActionMappedSuperClass) jpaRepository.findById(
            bulkId)
        .orElseThrow(() -> new Exception("Not found"));

    SingleActionRepositoryInterface singleActionRepositoryInterface = bulkOperationJpa.getRepositoryObject(
        EntityEnum.SINGLE_ACTION);
    List<? extends SingleActionMappedSuperClass> lst = singleActionRepositoryInterface.findByBulkRequestID(
        bulkId);

    Map<String, Map<String, String>> rowResponseMap = lst.parallelStream()
        .map(single -> requiredFieldMap(single, fieldFromResponse))
        .collect(Collectors.toMap(map -> map.get(Constants.ROW_NUMBER), map -> map));

    return csvWriteService.downloadStatusCsv(bulkUploadMappedSuperClass.getFileName(),
        bulkUploadMappedSuperClass.getOriginalBinary(), operationTaskEnum, fieldFromResponse,
        rowResponseMap);
  }

  @SneakyThrows
  private Map<String, String> requiredFieldMap(
      SingleActionMappedSuperClass singleActionMappedSuperClass, List<String> fieldFromResponse) {
    Map<String, String> response = new HashMap<>();
    response.put(Constants.ROW_NUMBER, singleActionMappedSuperClass.getUploadRowNumber());
    response.put(Constants.SINGLE_REQUEST_STATUS, singleActionMappedSuperClass.getState());

    ActionResponse actionResponse = singleActionMappedSuperClass.getActionResponse();
    if (actionResponse == null) {
      response.put(Constants.ERROR_MESSAGE, "Unable to get response");
      return response;
    }

    if (actionResponse.getErrorMessages() != null && actionResponse.getErrorMessages().size() > 0) {
      String error = actionResponse.getErrorMessages().stream()
          .map(e -> e.getErrorMessage() != null ? e.getErrorMessage() : e.getErrorMessageKey())
          .collect(Collectors.joining("|"));
      response.put(Constants.ERROR_MESSAGE, error);
    } else if (actionResponse.getData() != null) {
      String data = BulkUtils.decode(actionResponse.getData());
      Map<String, String> rawDataMap = objectMapper.readValue(data, Map.class);
      fieldFromResponse.forEach(field -> {
        if (rawDataMap.containsKey(field)) {
          response.put(field, rawDataMap.get(field));
        }
      });
    }
    return response;
  }

  private Optional<BulkUploadMappedSuperClass> getBulkUpload(String bulkUploadId) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("bulkUploadId",
        Pair.of(EnumQueryCriteria.EQUALS, Long.parseLong(bulkUploadId)));
    Specification<? extends BulkActionMappedSuperClass> specification = new Specification<>(
        fieldValueMap);

    JpaSpecificationExecutor bulkUploadJpa = bulkOperationJpa.getJpaSpecificationExecutor(
        EntityEnum.BULK_UPLOAD);

    return bulkUploadJpa.findOne(specification);
  }

  @SneakyThrows
  private List<BulkOperationStatus> getBulkOperationStatus(List<Long> bulkId) {
    List<BulkOperationStatus> response = new ArrayList<>();

    JpaRepository jpaRepository = bulkOperationJpa.getJpaRepository(EntityEnum.BULK_ACTION);
    bulkId.forEach(id -> {
      BulkActionMappedSuperClass bulkActionMappedSuperClass = (BulkActionMappedSuperClass) jpaRepository.findById(
          id).get();
      BulkOperationStatus bulkOperationStatus = new BulkOperationStatus();

      bulkOperationStatus.setBulkActionId(bulkActionMappedSuperClass.getBulkActionId());
      bulkOperationStatus.setRequestId(bulkActionMappedSuperClass.getRequestID());
      bulkOperationStatus.setState(bulkActionMappedSuperClass.getState());
      bulkOperationStatus.setOperation(bulkActionMappedSuperClass.getActionType());
      bulkOperationStatus.setSingleActionCount(bulkActionMappedSuperClass.getSingleActionCount());

      SingleActionRepositoryInterface singleActionRepositoryInterface = bulkOperationJpa.getRepositoryObject(
          EntityEnum.SINGLE_ACTION);
      long successfull = singleActionRepositoryInterface.countByBulkRequestIDAndState(
          bulkActionMappedSuperClass.getBulkActionId(), StateEnum.SUCCESS.name());
      long failed = singleActionRepositoryInterface.countByBulkRequestIDAndState(
          bulkActionMappedSuperClass.getBulkActionId(), StateEnum.FAILED.name());

      bulkOperationStatus.setSingleActionSuccessCount(successfull);
      bulkOperationStatus.setSingleActionFailCount(failed);
      response.add(bulkOperationStatus);
    });
    return response;
  }

  private BulkOperationStatus getBulkOperationStatus(
      BulkActionMappedSuperClass bulkActionMappedSuperClass) {
    BulkOperationStatus bulkOperationStatus = new BulkOperationStatus();

    bulkOperationStatus.setBulkActionId(bulkActionMappedSuperClass.getBulkActionId());
    bulkOperationStatus.setRequestId(bulkActionMappedSuperClass.getRequestID());
    bulkOperationStatus.setState(bulkActionMappedSuperClass.getState());
    bulkOperationStatus.setOperation(bulkActionMappedSuperClass.getActionType());
    bulkOperationStatus.setSingleActionCount(bulkActionMappedSuperClass.getSingleActionCount());

    SingleActionRepositoryInterface singleActionRepositoryInterface = bulkOperationJpa.getRepositoryObject(
        EntityEnum.SINGLE_ACTION);
    long successfull = singleActionRepositoryInterface.countByBulkRequestIDAndState(
        bulkActionMappedSuperClass.getBulkActionId(), StateEnum.SUCCESS.name());
    long failed = singleActionRepositoryInterface.countByBulkRequestIDAndState(
        bulkActionMappedSuperClass.getBulkActionId(), StateEnum.FAILED.name());

    bulkOperationStatus.setSingleActionSuccessCount(successfull);
    bulkOperationStatus.setSingleActionFailCount(failed);
    return bulkOperationStatus;
  }
}
