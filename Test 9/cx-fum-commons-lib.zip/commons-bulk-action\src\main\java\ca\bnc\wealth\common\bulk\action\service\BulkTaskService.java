package ca.bnc.wealth.common.bulk.action.service;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.common.bulk.action.enums.EntityEnum;
import ca.bnc.wealth.common.bulk.action.enums.OperationTaskEnum;
import ca.bnc.wealth.common.bulk.action.enums.StateEnum;
import ca.bnc.wealth.common.bulk.action.model.BulkResponse;
import ca.bnc.wealth.common.bulk.entity.BulkActionMappedSuperClass;
import ca.bnc.wealth.common.bulk.entity.BulkUploadMappedSuperClass;
import ca.bnc.wealth.common.bulk.repo.BulkActionRepositoryInterface;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class BulkTaskService {

  @Autowired
  private BulkOperationJpa bulkOperationJpa;

  @Autowired
  private BulkUploadService bulkUploadService;

  @Autowired
  private SingleRequestService singleRequestService;

  @Value("${bulk.postgres.schema}")
  private String postgressSchema;
  @Value("${bulk.sequence.name.bulk}")
  private String bulkRequestSequenceName;

  public BulkResponse bulkTask(User user, long bulkUploadId, List<String> tasks) {
    BulkResponse bulkResponse = new BulkResponse();

    List<OperationTaskEnum> lst = getTaskOrder(tasks);
    BulkUploadMappedSuperClass bulkUploadMappedSuperClass = bulkUploadService.getBulkUpload(
            bulkUploadId)
        .orElseThrow(() -> new IllegalArgumentException(
            "Unable to find bulk upload with bulkUploadId: " + bulkUploadId));

    String errorMessage = checkPrerequisiteAction(bulkUploadMappedSuperClass, lst);
    if (errorMessage != null) {
      bulkResponse.setErrorMessage(errorMessage);
      bulkResponse.setStatus(StateEnum.FAILED.name());
      return bulkResponse;
    }

    BulkActionMappedSuperClass bulkActionMappedSuperClass = createBulkAction(user,
        bulkUploadMappedSuperClass, lst);

    bulkOperationJpa.updateBulkUpload(bulkUploadId, bulkActionMappedSuperClass.getBulkActionId(),
        lst.get(0), StateEnum.PENDING);

    singleRequestService.createSingleRequestAndPublish(user,
        bulkUploadMappedSuperClass.getTemplateId(), bulkActionMappedSuperClass, lst.get(0),
        bulkUploadMappedSuperClass.getUploadResponse());

    bulkResponse.setStatus(StateEnum.PENDING.name());
    bulkResponse.setBulkRequestId(bulkActionMappedSuperClass.getRequestID());
    bulkResponse.setBulkActionId(bulkActionMappedSuperClass.getBulkActionId());
    return bulkResponse;
  }

  private BulkActionMappedSuperClass createBulkAction(User user,
      BulkUploadMappedSuperClass bulkUploadMappedSuperClass, List<OperationTaskEnum> lst) {
    BulkActionMappedSuperClass bulkActionMappedSuperClass = bulkOperationJpa.getEntityInstance(
        EntityEnum.BULK_ACTION);
    bulkActionMappedSuperClass.setRequestID(getbulkRequestId(lst.get(0)));
    bulkActionMappedSuperClass.setBulkUploadId(bulkUploadMappedSuperClass.getBulkUploadId());
    bulkActionMappedSuperClass.setState(StateEnum.PENDING.name());
    bulkActionMappedSuperClass.setActionType(lst.get(0).name());
    if (lst.size() >= 2) {
      bulkActionMappedSuperClass.setNextAction(
          lst.size() == 2 ? lst.get(1).name() : lst.get(1).name() + "," + lst.get(2).name());
    }
    bulkActionMappedSuperClass.setSingleActionCount(
        bulkUploadMappedSuperClass.getUploadResponse().getSingleRequests().size());
    bulkActionMappedSuperClass.setRetention(bulkUploadMappedSuperClass.getRetention());
    bulkActionMappedSuperClass.setCreatedBy(user.getIdpSubject());
    bulkActionMappedSuperClass.setCreationDate(Timestamp.valueOf(LocalDateTime.now()));

    return bulkOperationJpa.saveAndFlush(bulkActionMappedSuperClass);

  }

  private String checkPrerequisiteAction(BulkUploadMappedSuperClass bulkUploadMappedSuperClass,
      List<OperationTaskEnum> lst) {
    switch (lst.get(0)) {
      case CONVERSION:
        if (StateEnum.SUCCESS.name().equals(bulkUploadMappedSuperClass.getBulkConvertStatus())
            || StateEnum.PENDING.name().equals(bulkUploadMappedSuperClass.getBulkConvertStatus())) {
          return "Can't run Bulk Action if the convert state is in "
              + bulkUploadMappedSuperClass.getBulkConvertStatus();
        }
        break;
      case VALIDATION:
        if (!StateEnum.SUCCESS.name().equals(bulkUploadMappedSuperClass.getBulkConvertStatus())) {
          return "Can't run Bulk Validation without completion of Bulk Convert";
        }
        if (StateEnum.SUCCESS.name().equals(bulkUploadMappedSuperClass.getBulkValidateStatus())
            || StateEnum.PENDING.name()
            .equals(bulkUploadMappedSuperClass.getBulkValidateStatus())) {
          return "Can't run Bulk Action if the validation state is in "
              + bulkUploadMappedSuperClass.getBulkValidateStatus();
        }
        break;
      case ACTION:
        if (!StateEnum.SUCCESS.name().equals(bulkUploadMappedSuperClass.getBulkConvertStatus())
            || !StateEnum.SUCCESS.name()
            .equals(bulkUploadMappedSuperClass.getBulkValidateStatus())) {
          return "Can't run Bulk Action without completion of Bulk Convert and Bulk Validate";
        }
        if (StateEnum.SUCCESS.name().equals(bulkUploadMappedSuperClass.getBulkActionStatus())
            || StateEnum.PENDING.name().equals(bulkUploadMappedSuperClass.getBulkActionStatus())) {
          return "Can't run Bulk Action if the state action is in "
              + bulkUploadMappedSuperClass.getBulkActionStatus();
        }
        break;
    }
    return null;
  }

  private String getbulkRequestId(OperationTaskEnum operationTaskEnum) {
    String sufix = "";
    switch (operationTaskEnum) {
      case CONVERSION:
        sufix = "C";
        break;
      case ACTION:
        sufix = "A";
        break;
      case VALIDATION:
        sufix = "V";
    }
    BulkActionRepositoryInterface repositoryInterface = bulkOperationJpa.getJpaRepository(
        EntityEnum.BULK_ACTION);
    long sequence = repositoryInterface.generateID(
        "\"" + postgressSchema + "\"." + "\"" + bulkRequestSequenceName + "\"");
    return formatId("B", sufix, "%010d", sequence);
  }

  private String formatId(@Nullable String prefix, @Nullable String suffix, @NonNull String format,
      @NonNull Long id) {
    format = StringUtils.isBlank(prefix) ? format : prefix + format;
    format = StringUtils.isBlank(suffix) ? format : format + suffix;
    return String.format(format, id);
  }

  private List<OperationTaskEnum> getTaskOrder(List<String> tasks) {
    List<OperationTaskEnum> taskOrder = new ArrayList<>();
    if (tasks.contains(OperationTaskEnum.CONVERSION.name())) {
      taskOrder.add(OperationTaskEnum.CONVERSION);
    }
    if (tasks.contains(OperationTaskEnum.VALIDATION.name())) {
      taskOrder.add(OperationTaskEnum.VALIDATION);
    }
    if (tasks.contains(OperationTaskEnum.ACTION.name())) {
      taskOrder.add(OperationTaskEnum.ACTION);
    }
    return taskOrder;
  }
}
