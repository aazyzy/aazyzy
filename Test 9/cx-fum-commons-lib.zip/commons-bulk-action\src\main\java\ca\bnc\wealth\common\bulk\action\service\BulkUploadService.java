package ca.bnc.wealth.common.bulk.action.service;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.common.bulk.action.enums.EntityEnum;
import ca.bnc.wealth.common.bulk.action.enums.ScopeEnum;
import ca.bnc.wealth.common.bulk.action.enums.SortDirectionEnum;
import ca.bnc.wealth.common.bulk.action.enums.StateEnum;
import ca.bnc.wealth.common.bulk.action.model.BulkUploadStatus;
import ca.bnc.wealth.common.bulk.action.model.BulkUploadStatusMessages;
import ca.bnc.wealth.common.bulk.action.model.PageResponse;
import ca.bnc.wealth.common.bulk.action.utils.Constants;
import ca.bnc.wealth.common.bulk.entity.BulkTemplateMappedSuperClass;
import ca.bnc.wealth.common.bulk.entity.BulkUploadMappedSuperClass;
import ca.bnc.wealth.common.bulk.jsonb.SingleRequest;
import ca.bnc.wealth.common.bulk.jsonb.Template;
import ca.bnc.wealth.common.bulk.jsonb.UploadResponse;
import ca.bnc.wealth.common.jpa.entity.platform.FirmConfiguration;
import ca.bnc.wealth.common.jpa.repo.platform.FirmConfigurationRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.jpa.utils.RepositoryUtils;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import tools.jackson.databind.json.JsonMapper;

@Service
@Slf4j
public class BulkUploadService {

  @Autowired
  private BulkOperationJpa bulkOperationJpa;

  @Autowired
  private TemplateService templateService;

  @Autowired
  private CsvFileReadService csvFileReadService;

  @Autowired
  private BulkUploadFileValidation bulkUploadFileValidation;

  @Autowired
  private BulkHookService bulkHookService;

  @Autowired
  private BulkScopeService bulkScopeService;

  @Autowired
  private FirmConfigurationRepository firmConfigurationRepository;

  @Autowired
  private JsonMapper objectMapper;

  public Optional<BulkUploadMappedSuperClass> getBulkUpload(long bulkuploadId) {
    JpaRepository jpaRepository = bulkOperationJpa.getJpaRepository(EntityEnum.BULK_UPLOAD);
    return jpaRepository.findById(bulkuploadId);
  }

  public BulkUploadStatus convertFileToUploadResponse(User user, String firmId, String templateName,
      MultipartFile fileToUpload) {

    BulkUploadStatus bulkUploadStatus = new BulkUploadStatus();
    BulkTemplateMappedSuperClass bulkTemplateMappedSuperClass = templateService.getTemplate(
        templateName);
    Template templateRules = bulkTemplateMappedSuperClass.getConfig();

    if (templateRules == null) {
      updateBulkUploadStatus(bulkUploadStatus, StateEnum.FAILED.name(), "Template",
          Arrays.asList("Unable to find the template"));
      return bulkUploadStatus;
    }

    Optional<String> validationMessage = csvFileReadService.validateFile(fileToUpload,
        templateRules);
    if (validationMessage.isPresent()) {
      updateBulkUploadStatus(bulkUploadStatus, StateEnum.FAILED.name(), "",
          Arrays.asList(validationMessage.get()));
      return bulkUploadStatus;
    }

    //Reading data from csv
    List<Map<String, String>> parsedFileContents;
    try {
      parsedFileContents = this.csvFileReadService.convertCsvFileToMap(fileToUpload, templateRules);
    } catch (Exception e) {
      updateBulkUploadStatus(bulkUploadStatus, StateEnum.FAILED.name(), "csvConvert",
          Arrays.asList(e.getMessage()));
      return bulkUploadStatus;
    }

    Map<String, List<Long>> validation = this.bulkUploadFileValidation.validation(
        parsedFileContents, templateRules);
    if (validation.size() > 0) {
      populateValidationMessageToBulkRequest(bulkUploadStatus,
          formatValidationMessages(validation));
      return bulkUploadStatus;
    }

    validation = bulkHookService.uploadValidation(templateName, parsedFileContents);
    if (validation != null && validation.size() > 0) {
      populateValidationMessageToBulkRequest(bulkUploadStatus,
          formatValidationMessages(validation));
      return bulkUploadStatus;
    }

    try {
      BulkUploadMappedSuperClass entity = createBulkUpload(user, firmId,
          bulkTemplateMappedSuperClass, fileToUpload, parsedFileContents);
      bulkUploadStatus.setBulkUploadId(entity.getBulkUploadId());
    } catch (Exception e) {
      updateBulkUploadStatus(bulkUploadStatus, StateEnum.FAILED.name(), "",
          Arrays.asList(e.getMessage()));
    }

    bulkUploadStatus.setState(StateEnum.SUCCESS.name());
    return bulkUploadStatus;
  }

  @SneakyThrows
  public PageResponse<? extends BulkUploadMappedSuperClass> getBulkUploadHistory(
      String templateName, boolean uploadWithAction, int pageNumber, int pageSize,
      List<String> sortBy, SortDirectionEnum sortDirectionEnum) {
    BulkTemplateMappedSuperClass bulkTemplateMappedSuperClass = templateService.getTemplate(
        templateName);

    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("templateId",
        Pair.of(EnumQueryCriteria.EQUALS, bulkTemplateMappedSuperClass.getTemplateId()));

    if (uploadWithAction) {
      fieldValueMap.put("bulkActionRequestId", Pair.of(EnumQueryCriteria.NOT_EQUALS, 0));
    }

    updateFieldValueMapWithScope(bulkTemplateMappedSuperClass, fieldValueMap);

    Specification<? extends BulkUploadMappedSuperClass> specification = new Specification<>(
        fieldValueMap);
    PageRequest pageRequest = RepositoryUtils.getPageRequest(pageNumber, pageSize, sortBy,
        sortDirectionEnum.name(), false);

    JpaSpecificationExecutor jpaSpecificationExecutor = bulkOperationJpa.getJpaSpecificationExecutor(
        EntityEnum.BULK_UPLOAD);

    Page page = jpaSpecificationExecutor.findAll(specification, pageRequest);

    PageResponse<? extends BulkUploadMappedSuperClass> pageResponse = new PageResponse<>();
    pageResponse.setLst(page.toList());
    pageResponse.setTotalRecords(page.getTotalElements());
    pageResponse.setPageNumber(pageNumber);
    pageResponse.setPageSize(pageSize);

    return pageResponse;
  }

  private void updateFieldValueMapWithScope(
      BulkTemplateMappedSuperClass bulkTemplateMappedSuperClass,
      Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap) throws Exception {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    List<FirmConfiguration> firmLst = firmConfigurationRepository.findFirmConfiguratoin(
        user.getIdpSubject(), "RESOURCE_ENTITY_TYPE", "F");
    if (firmLst.isEmpty()) {
      throw new Exception(String.format("No firms associated to user %s", user.getIdpSubject()));
    }
    switch (ScopeEnum.valueOf(bulkTemplateMappedSuperClass.getTemplateScope())) {
      case GLOBAL:
        break;
      case USER:
        fieldValueMap.put("scopeValue", Pair.of(EnumQueryCriteria.EQUALS, user.getIdpSubject()));
        break;
      case FIRM:
        fieldValueMap.put("scopeValue",
            Pair.of(EnumQueryCriteria.EQUALS, firmLst.get(0).getFirmId()));
        break;
      case FIRM_CHILDFIRM:
        List<Long> firmIdLst = firmConfigurationRepository.getAllFirmsByIdpSubject(
            user.getIdpSubject());
        if (!firmLst.get(0).getFirmId().equalsIgnoreCase("NBIN")) {
          List<String> firmIds = firmConfigurationRepository.findByFirmConfigurationIdIn(firmIdLst)
              .stream()
              .map(FirmConfiguration::getFirmId)
              .collect(Collectors.toList());
          fieldValueMap.put("scopeValue", Pair.of(EnumQueryCriteria.IN, firmIds));
        }
        break;
    }
  }

  @SneakyThrows
  private BulkUploadMappedSuperClass createBulkUpload(User user, String firmId,
      BulkTemplateMappedSuperClass bulkTemplateMappedSuperClass, MultipartFile fileToUpload,
      List<Map<String, String>> parsedFileContents) {
    BulkUploadMappedSuperClass entity = this.bulkOperationJpa.getEntityInstance(
        EntityEnum.BULK_UPLOAD);
    entity.setTemplateId(bulkTemplateMappedSuperClass.getTemplateId());
    entity.setOriginalBinary(fileToUpload.getBytes());
    entity.setFileName(fileToUpload.getOriginalFilename());
    entity.setUploadResponse(getUploadResponse(bulkTemplateMappedSuperClass, parsedFileContents));
    entity.setCreatedBy(user.getIdpSubject());
    entity.setCreationDate(Timestamp.valueOf(LocalDateTime.now()));
    if (bulkTemplateMappedSuperClass.getConfig().getRetention() != 0) {
      entity.setRetention(Timestamp.valueOf(LocalDateTime.now()
          .plus(bulkTemplateMappedSuperClass.getConfig().getRetention(), ChronoUnit.DAYS)));
    } else {
      entity.setRetention(Timestamp.valueOf(LocalDateTime.now().plus(180, ChronoUnit.DAYS)));
    }

    entity.setScopeValue(
        bulkScopeService.getScopeValue(bulkTemplateMappedSuperClass, user.getIdpSubject(), firmId));

    return bulkOperationJpa.saveAndFlush(entity);
  }

  private UploadResponse getUploadResponse(
      BulkTemplateMappedSuperClass bulkTemplateMappedSuperClass,
      List<Map<String, String>> parsedFileContents) {
    UploadResponse uploadResponse = new UploadResponse();
    uploadResponse.setRetention(bulkTemplateMappedSuperClass.getConfig().getRetention());
    uploadResponse.setUploadTemplateName(bulkTemplateMappedSuperClass.getTemplateName());

    uploadResponse.setSingleRequests(
        parsedFileContents.stream().map(this::getSingleRequest).collect(Collectors.toList()));

    return uploadResponse;
  }

  @SneakyThrows
  SingleRequest getSingleRequest(Map<String, String> record) {
    SingleRequest singleRequest = new SingleRequest();
    singleRequest.setRawJson(objectMapper.writeValueAsString(record));
    singleRequest.setUploadRowNumber(record.get(Constants.ROW_NUMBER));
    return singleRequest;
  }

  private void updateBulkUploadStatus(BulkUploadStatus bulkUploadStatus, String state, String key,
      List<String> value) {
    bulkUploadStatus.setState(state);
    if (bulkUploadStatus.getMessages() == null) {
      bulkUploadStatus.setMessages(new BulkUploadStatusMessages());
    }

    bulkUploadStatus.getMessages().getErrors().computeIfAbsent(key, k -> new ArrayList<>())
        .addAll(value);
  }

  private void populateValidationMessageToBulkRequest(BulkUploadStatus bulkUploadStatus,
      List<String> messageDetails) {
    bulkUploadStatus.setState(StateEnum.FAILED.name());

    Map<String, List<String>> errors = new HashMap<>();
    int key = 1;
    for (String messageDetail : messageDetails) {
      errors.put(String.valueOf(key++), Arrays.asList(messageDetail));
    }
    if (bulkUploadStatus.getMessages() == null) {
      bulkUploadStatus.setMessages(new BulkUploadStatusMessages());
    }

    bulkUploadStatus.getMessages().setErrors(errors);
  }

  private List<String> formatValidationMessages(Map<String, List<Long>> rowMessages) {

    List<String> messageDetails = new ArrayList<>();
    rowMessages.forEach((key, rowNumbers) -> {
      if (!rowNumbers.isEmpty()) {
        String errorMessage = rowNumbers.size() == 1
            ? "Row " + rowNumbers.get(0) + " - " + key
            : "Rows " + rowNumbers.stream().map(Objects::toString).collect(Collectors.joining(", "))
                + " - " + key;
        messageDetails.add(errorMessage);
      }
    });

    return messageDetails;
  }
}
