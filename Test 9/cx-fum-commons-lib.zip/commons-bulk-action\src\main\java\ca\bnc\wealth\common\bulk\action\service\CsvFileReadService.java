package ca.bnc.wealth.common.bulk.action.service;

import ca.bnc.wealth.common.bulk.action.utils.Constants;
import ca.bnc.wealth.common.bulk.jsonb.Template;
import ca.bnc.wealth.common.bulk.jsonb.TemplateFieldConfig;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
@Slf4j
public class CsvFileReadService {

  public Optional<String> validateFile(MultipartFile multipartFile, Template template) {
    if (template != null) {
      long maxFileSize = template.getFileSize();
      if (multipartFile.getSize() > maxFileSize) {
        return Optional.of(String.format("File exceeds limit of %s.",
            FileUtils.byteCountToDisplaySize(maxFileSize)));
      } else {
        String allowedFileFormat = template.getFileFormat();
        log.info("The allowed file format is: " + allowedFileFormat);
        log.info("The original file name is: " + multipartFile.getOriginalFilename());
        String extension = FilenameUtils.getExtension(multipartFile.getOriginalFilename());
        log.info("The extension of the file name is: " + extension);
        log.info("Do extensions match: " + allowedFileFormat.equalsIgnoreCase(extension));
        return !allowedFileFormat.equalsIgnoreCase(extension) ? Optional.of(
            String.format("Incorrect File format (%s files only).", allowedFileFormat))
            : Optional.empty();
      }
    } else {
      return Optional.of("Error loading rules");
    }
  }

  public List<Map<String, String>> convertCsvFileToMap(MultipartFile csvFile, Template template)
      throws Exception {
    List<Map<String, String>> results = new ArrayList<>();
    if (Objects.isNull(template)) {
      throw new IllegalArgumentException("Template is not found.");
    }

    try {
      BufferedReader fileReader = new BufferedReader(
          new InputStreamReader(csvFile.getInputStream(), StandardCharsets.UTF_8));

      try {
        CSVParser csvParser = new CSVParser(fileReader,
            CSVFormat.RFC4180.builder().setIgnoreEmptyLines(true).setHeader(new String[0])
                .setIgnoreHeaderCase(true).setSkipHeaderRecord(true).setTrim(true).build());

        try {
          Iterator var8 = csvParser.iterator();

          while (var8.hasNext()) {
            CSVRecord record = (CSVRecord) var8.next();
            long lineNum = csvParser.getCurrentLineNumber();
            Map<String, String> rowMap = new HashMap();
            rowMap.put(Constants.ROW_NUMBER, String.valueOf(lineNum));
            template.getFields().forEach((field) -> {
              TemplateFieldConfig fieldConfig = field.getConfig();
              if (record.isSet(fieldConfig.getHeaderName())) {
                rowMap.put(fieldConfig.getHeaderName(),
                    record.get(fieldConfig.getHeaderName()).trim());
              }
            });
            results.add(rowMap);
          }

          if (CollectionUtils.isEmpty(results)) {
            log.error("The file has no rows");
            throw new IllegalArgumentException("file has not data");
          }
        } catch (Throwable var15) {
          try {
            csvParser.close();
          } catch (Throwable var14) {
            var15.addSuppressed(var14);
          }

          throw var15;
        }

        csvParser.close();
      } catch (Throwable var16) {
        try {
          fileReader.close();
        } catch (Throwable var13) {
          var16.addSuppressed(var13);
        }

        throw var16;
      }

      fileReader.close();
      return results;
    } catch (IOException var17) {
      log.error("Error while parsing csv data: {}", var17.getMessage());
      throw var17;
    } catch (IllegalArgumentException var18) {
      throw new IllegalArgumentException("Unable to process the csv data");
    }
  }
}
