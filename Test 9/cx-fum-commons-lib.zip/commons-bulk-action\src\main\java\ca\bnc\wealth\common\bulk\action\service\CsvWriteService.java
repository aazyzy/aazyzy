package ca.bnc.wealth.common.bulk.action.service;

import ca.bnc.wealth.common.bulk.action.enums.OperationTaskEnum;
import ca.bnc.wealth.common.bulk.action.enums.StateEnum;
import ca.bnc.wealth.common.bulk.action.model.BulkDownloadResource;
import ca.bnc.wealth.common.bulk.action.utils.Constants;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class CsvWriteService {

  public BulkDownloadResource downloadStatusCsv(String fileName, byte[] originalBinary,
      OperationTaskEnum operationTaskEnum, List<String> fieldFromResponse,
      Map<String, Map<String, String>> rowResponseMap) {
    List<List<String>> csvList = getuploadedData(originalBinary);

    List<String> headers = csvList.get(0);
    headers.remove(headers.size() - 1);
    if (fieldFromResponse != null && fieldFromResponse.size() > 0) {
      headers.addAll(fieldFromResponse);
    }
    headers.add("Status");
    headers.add("Error Message");

    StringWriter sw = getCsvStringWriter(headers, fieldFromResponse, csvList, rowResponseMap,
        getStatusPrefix(operationTaskEnum));
    String downloadFileName = fileName.split(".csv")[0] + "_Status.csv";
    return new BulkDownloadResource(downloadFileName, sw.toString().getBytes(), "");
  }

  @SneakyThrows
  private StringWriter getCsvStringWriter(List<String> headers, List<String> fieldFromResponse,
      List<List<String>> csvList, Map<String, Map<String, String>> rowResponseMap,
      String statusPrefix) {
    StringWriter sw = new StringWriter();
    CSVFormat csvFormat = CSVFormat.DEFAULT.builder()
        .setHeader(headers.toArray(new String[headers.size()]))
        .build();

    CSVPrinter printer = new CSVPrinter(sw, csvFormat);

    for (int i = 1; i < csvList.size(); i++) {
      List<String> row = csvList.get(i);
      String rowNumber = row.get(row.size() - 1);
      row.remove(row.size() - 1);
      printer.printRecord(
          addRowData(row, fieldFromResponse, rowResponseMap.get(rowNumber), statusPrefix));
    }
    return sw;
  }

  private List<String> addRowData(List<String> orginal, List<String> fieldFromResponse,
      Map<String, String> responseMap, String statuesPrefix) {
    if (responseMap == null) {
      if (fieldFromResponse != null) {
        fieldFromResponse.forEach(field -> orginal.add(""));
      }
      orginal.add(statuesPrefix + StateEnum.FAILED.name());
      orginal.add("");
      return orginal;
    }

    if (fieldFromResponse != null) {
      fieldFromResponse.forEach(
          field -> orginal.add(responseMap.get(field) != null ? responseMap.get(field) : ""));
    }

    if (StateEnum.FAILED.name().equals(responseMap.get(Constants.SINGLE_REQUEST_STATUS))) {
      orginal.add(statuesPrefix + StateEnum.FAILED.name());
      orginal.add(responseMap.get(Constants.ERROR_MESSAGE));
    } else if (StateEnum.SUCCESS.name().equals(responseMap.get(Constants.SINGLE_REQUEST_STATUS))) {
      if ("Conversion:SUCCESS|Validation:SUCCESS|Action:".equals(statuesPrefix)) {
        orginal.add(StateEnum.SUCCESS.name());
        orginal.add("");
      } else {
        orginal.add(statuesPrefix + StateEnum.SUCCESS.name());
        orginal.add("");
      }
    }
    return orginal;
  }

  private String getStatusPrefix(OperationTaskEnum operationTaskEnum) {
    switch (operationTaskEnum) {
      case CONVERSION:
        return "Conversion:";
      case VALIDATION:
        return "Conversion:SUCCESS|Validation:";
      case ACTION:
        return "Conversion:SUCCESS|Validation:SUCCESS|Action:";
    }
    return null;
  }

  @SneakyThrows
  private List<List<String>> getuploadedData(byte[] originalBinary) {
    List<List<String>> csvList = new ArrayList<>();

    Reader reader = new InputStreamReader(new ByteArrayInputStream(originalBinary));
    CSVParser csvParser = new CSVParser(reader,
        CSVFormat.RFC4180.builder().setIgnoreEmptyLines(true).setIgnoreHeaderCase(true)
            .setTrim(true).build());

    Iterator iterator = csvParser.iterator();
    while (iterator.hasNext()) {
      CSVRecord record = (CSVRecord) iterator.next();
      long lineNum = csvParser.getCurrentLineNumber();
      List<String> row = new ArrayList<>();
      row.addAll(record.toList());
      row.add(String.valueOf(lineNum));
      csvList.add(row);
    }
    return csvList;
  }
}
