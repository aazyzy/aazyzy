package ca.bnc.wealth.common.bulk.action.service;

import ca.bnc.wealth.common.bulk.action.enums.EntityEnum;
import ca.bnc.wealth.common.bulk.repo.BulkActionRepositoryInterface;
import ca.bnc.wealth.common.bulk.repo.BulkTemplateRepositoryInterface;
import ca.bnc.wealth.common.bulk.repo.BulkUploadRepositoryInterface;
import ca.bnc.wealth.common.bulk.repo.SingleActionRepositoryInterface;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class EntityRepositoryFactory {

  @Autowired
  private ConfigurableListableBeanFactory beanFactory;

  private Map<EntityEnum, Object> entityRepoMap = new HashMap<>();

  private Map<EntityEnum, Class> entityClassMap = new HashMap<>();

  @Order(10)
  @EventListener(ApplicationReadyEvent.class)
  public void runAfterReady() {

    beanFactory.getBeansOfType(BulkTemplateRepositoryInterface.class)
        .forEach((k, v) -> entityRepoMap.put(EntityEnum.TEMPLATE, v));
    beanFactory.getBeansOfType(BulkUploadRepositoryInterface.class)
        .forEach((k, v) -> entityRepoMap.put(EntityEnum.BULK_UPLOAD, v));
    beanFactory.getBeansOfType(BulkActionRepositoryInterface.class)
        .forEach((k, v) -> entityRepoMap.put(EntityEnum.BULK_ACTION, v));
    beanFactory.getBeansOfType(SingleActionRepositoryInterface.class)
        .forEach((k, v) -> entityRepoMap.put(EntityEnum.SINGLE_ACTION, v));

    Arrays.asList(EntityEnum.TEMPLATE, EntityEnum.BULK_UPLOAD, EntityEnum.BULK_ACTION,
            EntityEnum.SINGLE_ACTION).stream()
        .map(entity -> Pair.of(entity, entityRepoMap.get(entity).getClass()))
        .map(pair -> Pair.of(pair.getLeft(), this.getClass(pair.getRight())))
        .forEach(pair -> entityClassMap.put(pair.getKey(), pair.getValue()));
  }

  public JpaRepository getJpaRepository(EntityEnum entityEnum) {
    return (JpaRepository) entityRepoMap.get(entityEnum);
  }

  public JpaSpecificationExecutor getJpaSpecificationExecutor(EntityEnum entityEnum) {
    return (JpaSpecificationExecutor) entityRepoMap.get(entityEnum);
  }

  public Object getRepositoryObject(EntityEnum entityEnum) {
    return entityRepoMap.get(entityEnum);
  }

  @SneakyThrows
  public Object getEntityInstance(EntityEnum entityEnum) {
    return entityClassMap.get(entityEnum).getDeclaredConstructor().newInstance();
  }

  private Class getClass(Class proxyRepo) {
    Type[] proxyRepoInterfaces = proxyRepo.getGenericInterfaces();
    if (proxyRepoInterfaces == null) {
      return null;
    }
    Class repoInterface = (Class) Arrays.stream(proxyRepoInterfaces)
        .filter(type -> type instanceof Class)
        .filter(type -> !type.getTypeName().startsWith("org.springframework"))
        .findFirst().orElse(null);

    Type[] repoImplementedInterfaces = repoInterface.getGenericInterfaces();

    return (Class) Arrays.stream(repoImplementedInterfaces)
        .filter(type -> type.getTypeName()
            .contains("org.springframework.data.jpa.repository.JpaRepository"))
        .map(type -> ((ParameterizedType) type).getActualTypeArguments())
        .filter(types -> types.length > 0)
        .map(types -> types[0])
        .findFirst().orElse(null);
  }
}
