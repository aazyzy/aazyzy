package ca.bnc.wealth.common.bulk.action.service;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.common.bulk.action.client.SingleRequestFeignClient;
import ca.bnc.wealth.common.bulk.action.enums.EntityEnum;
import ca.bnc.wealth.common.bulk.action.enums.OperationTaskEnum;
import ca.bnc.wealth.common.bulk.action.enums.StateEnum;
import ca.bnc.wealth.common.bulk.action.kafka.SingleRequestPublisher;
import ca.bnc.wealth.common.bulk.action.utils.BulkUtils;
import ca.bnc.wealth.common.bulk.entity.BulkActionMappedSuperClass;
import ca.bnc.wealth.common.bulk.entity.SingleActionMappedSuperClass;
import ca.bnc.wealth.common.bulk.jsonb.ActionResponse;
import ca.bnc.wealth.common.bulk.jsonb.ErrorMessage;
import ca.bnc.wealth.common.bulk.jsonb.SingleRequest;
import ca.bnc.wealth.common.bulk.jsonb.UploadResponse;
import ca.bnc.wealth.common.bulk.repo.SingleActionRepositoryInterface;
import java.net.URI;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Arrays;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class SingleRequestService {

  @Autowired
  BulkOperationJpa bulkOperationJpa;
  @Autowired
  SystemTokenFactory systemTokenFactory;
  @Autowired
  BulkHookService bulkHookService;
  @Autowired
  private SingleRequestPublisher singleRequestPublisher;
  @Autowired
  private TemplateService templateService;
  @Autowired
  private SingleRequestFeignClient client;
  @Value("${bulk.postgres.schema}")
  private String postgressSchema;
  @Value("${bulk.sequence.name.single}")
  private String singleRequestSequenceName;

  @Value("${bulk.systemToken.bulkAction}")
  private String tokenService;

  @Async
  public void createSingleRequestAndPublish(User user, long templateId,
      BulkActionMappedSuperClass bulkAction, OperationTaskEnum operationTaskEnum,
      UploadResponse uploadResponse) {
    final String url = templateService.getUrl(templateId, operationTaskEnum);
    final String templateName = templateService.getTemplateName(templateId);
    try {
      uploadResponse.getSingleRequests().stream()
          .map(singleRequest -> this.createSingleRequest(user, bulkAction, operationTaskEnum, url,
              singleRequest))
          .forEach(sr -> singleRequestPublisher.publishMessage(templateName, sr));
    } catch (Exception e) {
      log.error("single request create and publish fiale for bulkActionId",
          bulkAction.getBulkActionId());
      UpdateFailedStatus(bulkAction.getBulkActionId());
    }
  }

  public void singleRequestProcessing(String templateName, long singleActionId) {
    SingleActionMappedSuperClass entity = bulkOperationJpa.getSingleActionById(singleActionId);
    try {
      String request = bulkHookService.updateSingleRequest(templateName, entity.getRequestID(),
          entity.getActionRequest());

      String token = systemTokenFactory.getBearerToken(tokenService);
      log.info("SingleActionId: {}", singleActionId);
      ResponseEntity<ActionResponse> response = client.action(new URI(entity.getActionUrl()), token,
          request);

      ActionResponse actionResponse = bulkHookService.updateSingleResponse(templateName,
          entity.getRequestID(), response.getBody());

      entity.setActionResponse(actionResponse);
      if (response.getBody().getErrorMessages() != null
          && response.getBody().getErrorMessages().size() > 0) {
        entity.setState(StateEnum.FAILED.name());
      } else {
        entity.setState(StateEnum.SUCCESS.name());
      }
    } catch (Exception e) {
      log.error("unable to call the action endpoint ", entity.getActionUrl());
      log.error("exception message: {}", e.getMessage());
      entity.setState(StateEnum.FAILED.name());

      ActionResponse errorResponse = new ActionResponse();
      ErrorMessage errorMessage = new ErrorMessage();
      errorMessage.setErrorMessage("unable to call the action endpoint");
      errorResponse.setErrorMessages(Arrays.asList(errorMessage));
      entity.setActionResponse(errorResponse);
    }
    bulkOperationJpa.saveAndFlush(entity);
  }

  private SingleActionMappedSuperClass createSingleRequest(User user,
      BulkActionMappedSuperClass bulkAction, OperationTaskEnum operationTaskEnum, String url,
      SingleRequest singleRequest) {
    SingleActionMappedSuperClass singleActionMappedSuperClass = bulkOperationJpa.getEntityInstance(
        EntityEnum.SINGLE_ACTION);
    singleActionMappedSuperClass.setRequestID(getSingleRequestId(operationTaskEnum));
    singleActionMappedSuperClass.setBulkRequestID(bulkAction.getBulkActionId());
    singleActionMappedSuperClass.setRetention(bulkAction.getRetention());
    singleActionMappedSuperClass.setState(StateEnum.PENDING.name());
    singleActionMappedSuperClass.setUploadRowNumber(singleRequest.getUploadRowNumber());
    singleActionMappedSuperClass.setActionUrl(url);
    if (OperationTaskEnum.CONVERSION == operationTaskEnum) {
      singleActionMappedSuperClass.setActionRequest(singleRequest.getRawJson());
    } else {
      singleActionMappedSuperClass.setActionRequest(
          BulkUtils.decode(singleRequest.getConvertedData()));
    }

    singleActionMappedSuperClass.setCreatedBy(user.getIdpSubject());
    singleActionMappedSuperClass.setCreationDate(Timestamp.valueOf(LocalDateTime.now()));

    SingleActionMappedSuperClass dbValue = bulkOperationJpa.saveAndFlush(
        singleActionMappedSuperClass);

    singleActionMappedSuperClass.setSingleActionId(dbValue.getSingleActionId());
    return singleActionMappedSuperClass;
  }

  private String getSingleRequestId(OperationTaskEnum operationTaskEnum) {
    String sufix = "";
    switch (operationTaskEnum) {
      case CONVERSION:
        sufix = "C";
        break;
      case ACTION:
        sufix = "A";
        break;
      case VALIDATION:
        sufix = "V";
    }
    SingleActionRepositoryInterface repositoryInterface = bulkOperationJpa.getJpaRepository(
        EntityEnum.SINGLE_ACTION);
    long sequence = repositoryInterface.generateID(
        "\"" + postgressSchema + "\"." + "\"" + singleRequestSequenceName + "\"");
    return formatId("S", sufix, "%010d", sequence);
  }

  private String formatId(@Nullable String prefix, @Nullable String suffix, @NonNull String format,
      @NonNull Long id) {
    format = StringUtils.isBlank(prefix) ? format : prefix + format;
    format = StringUtils.isBlank(suffix) ? format : format + suffix;
    return String.format(format, id);
  }

  private void UpdateFailedStatus(long bulkActionId) {
    BulkActionMappedSuperClass bulkActionMappedSuperClass = bulkOperationJpa.getBulkActionById(
        bulkActionId);
    bulkActionMappedSuperClass.setState(StateEnum.FAILED.name());
    bulkOperationJpa.saveAndFlush(bulkActionMappedSuperClass);

    bulkOperationJpa.updateBulkUpload(bulkActionMappedSuperClass.getBulkUploadId(), bulkActionId,
        OperationTaskEnum.valueOf(bulkActionMappedSuperClass.getActionType()), StateEnum.FAILED);
  }
}
