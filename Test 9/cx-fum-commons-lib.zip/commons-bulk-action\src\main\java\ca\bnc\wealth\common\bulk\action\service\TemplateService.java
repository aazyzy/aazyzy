package ca.bnc.wealth.common.bulk.action.service;

import ca.bnc.wealth.common.bulk.action.enums.EntityEnum;
import ca.bnc.wealth.common.bulk.action.enums.OperationTaskEnum;
import ca.bnc.wealth.common.bulk.entity.BulkTemplateMappedSuperClass;
import ca.bnc.wealth.common.bulk.repo.BulkTemplateRepositoryInterface;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class TemplateService {

  @Autowired
  BulkOperationJpa bulkOperationJpa;

  Map<String, BulkTemplateMappedSuperClass> templateMap = new HashMap<>();


  public synchronized void initLoad() {
    JpaRepository jpaRepository = bulkOperationJpa.getJpaRepository(EntityEnum.TEMPLATE);
    List<BulkTemplateMappedSuperClass> lst = jpaRepository.findAll();
    lst.forEach(template -> templateMap.put(template.getTemplateName(), template));
  }

  public BulkTemplateMappedSuperClass getTemplate(String templateName) {
    if (templateMap.isEmpty()) {
      initLoad();
    }
    return Optional.ofNullable(templateMap.get(templateName))
        .orElseGet(() -> {
          BulkTemplateMappedSuperClass entity = ((BulkTemplateRepositoryInterface) bulkOperationJpa
              .getJpaRepository(EntityEnum.TEMPLATE)).findByTemplateName(templateName);
          templateMap.put(entity.getTemplateName(), entity);
          return entity;
        });

  }

  public BulkTemplateMappedSuperClass getTemplate(long templateId) {
    if (templateMap.isEmpty()) {
      initLoad();
    }
    return templateMap.values().stream()
        .filter(template -> template.getTemplateId() == templateId)
        .findFirst()
        .orElseGet(() -> {
          BulkTemplateMappedSuperClass entity = (BulkTemplateMappedSuperClass) ((JpaRepository) bulkOperationJpa.getJpaRepository(
              EntityEnum.TEMPLATE))
              .findById(templateId)
              .get();
          templateMap.put(entity.getTemplateName(), entity);
          return entity;
        });

  }

  public List<BulkTemplateMappedSuperClass> getAllTemplate() {
    if (templateMap.isEmpty()) {
      initLoad();
    }
    return new ArrayList<>(templateMap.values());
  }


  public String getUrl(long templateId, OperationTaskEnum operationTaskEnum) {
    String splitKey = "\\s+";

    BulkTemplateMappedSuperClass bulkTemplateMappedSuperClass = templateMap.values().stream()
        .filter(template -> template.getTemplateId() == templateId)
        .findFirst().orElseGet(() -> {
          BulkTemplateMappedSuperClass entity = (BulkTemplateMappedSuperClass) ((JpaRepository) bulkOperationJpa.getJpaRepository(
              EntityEnum.TEMPLATE))
              .findById(templateId)
              .get();
          templateMap.put(entity.getTemplateName(), entity);
          return entity;
        });
    switch (operationTaskEnum) {
      case CONVERSION:
        return bulkTemplateMappedSuperClass.getConversionApi().split(splitKey)[1];
      case VALIDATION:
        return bulkTemplateMappedSuperClass.getValidationApi().split(splitKey)[1];
      case ACTION:
        return bulkTemplateMappedSuperClass.getActionApi().split(splitKey)[1];
    }
    return null;
  }

  public String getTemplateName(long templateId) {
    return templateMap.values().stream()
        .filter(template -> template.getTemplateId() == templateId)
        .findFirst()
        .map(BulkTemplateMappedSuperClass::getTemplateName)
        .get();
  }
}
