package ca.bnc.wealth.common.bulk.action.utils;

public class BulkUtils {

  public static String decode(String payload) {
    byte[] decode = java.util.Base64.getDecoder().decode(payload);
    return new String(decode);
  }

  public static boolean isNumeric(String str) {
    try {
      Long.parseLong(str);
      return true;
    } catch (NumberFormatException e) {
      return false;
    }
  }
}
