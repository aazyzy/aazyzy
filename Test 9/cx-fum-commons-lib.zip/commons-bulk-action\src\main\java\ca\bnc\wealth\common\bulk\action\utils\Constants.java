package ca.bnc.wealth.common.bulk.action.utils;

public class Constants {

  public static final String ROW_NUMBER = "row-number";

  public static final String ERROR_MESSAGE = "error-message";

  public static final String SINGLE_REQUEST_STATUS = "singel-request-status";
}
