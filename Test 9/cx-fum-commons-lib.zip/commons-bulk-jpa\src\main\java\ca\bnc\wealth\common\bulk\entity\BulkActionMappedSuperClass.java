package ca.bnc.wealth.common.bulk.entity;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import java.sql.Timestamp;
import lombok.Data;

@Data
@MappedSuperclass
public class BulkActionMappedSuperClass {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`BULK_ACTIONS_ID`")
  private long bulkActionId;

  @Column(name = "`REQUEST_ID`")
  private String requestID;

  @Column(name = "`BULK_UPLOAD_ID`")
  private long bulkUploadId;

  @Column(name = "`STATE`")
  private String state;

  @Column(name = "`ACTION_TYPE`")
  private String actionType;

  @Column(name = "`NEXT_ACTION`")
  private String nextAction;

  @Column(name = "`SINGLE_ACTION_COUNT`")
  private long singleActionCount;

  @Column(name = "`RETAINED_UNTIL`")
  private Timestamp retention;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATION_DATE`")
  private Timestamp creationDate;

  @Column(name = "`LAST_UPDATED_BY`")
  private String lastUpdatedBy;

  @Column(name = "`LAST_UPDATE_DATE`")
  private Timestamp lastUpdateDate;
}
