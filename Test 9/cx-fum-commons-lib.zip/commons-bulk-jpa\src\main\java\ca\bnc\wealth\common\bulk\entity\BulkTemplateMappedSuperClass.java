package ca.bnc.wealth.common.bulk.entity;

import ca.bnc.wealth.common.bulk.jsonb.Template;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import java.sql.Timestamp;
import lombok.Data;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Data
@MappedSuperclass
public class BulkTemplateMappedSuperClass {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`ID`")
  private long templateId;

  @Column(name = "`TEMPLATE_NAME`")
  private String templateName;

  @Column(name = "`TEMPLATE_SCOPE`")
  private String templateScope;

  @Column(name = "`CAPABILITY`")
  private String capability;

  @Column(name = "`DISPLAY_NAME`")
  private String displayName;

  @Column(name = "`VERSION`")
  private String version;

  @Column(name = "`CONVERSION_API`")
  private String conversionApi;

  @Column(name = "`VALIDATION_API`")
  private String validationApi;

  @Column(name = "`ACTION_API`")
  private String actionApi;

  @Column(name = "`ACTION_RESPONSE_REF_PATH`")
  private String actionResponseRefPath;

  @Column(name = "`DESCRIPTION`")
  private String description;

  @Column(name = "`ENABLED`")
  private Boolean enabled;

  @Column(name = "`CONFIG`")
  @JdbcTypeCode(SqlTypes.JSON)
  private Template config;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATION_DATE`")
  private Timestamp creationDate;

  @Column(name = "`LAST_UPDATED_BY`")
  private String lastUpdatedBy;

  @Column(name = "`LAST_UPDATE_DATE`")
  private Timestamp lastUpdateDate;

}
