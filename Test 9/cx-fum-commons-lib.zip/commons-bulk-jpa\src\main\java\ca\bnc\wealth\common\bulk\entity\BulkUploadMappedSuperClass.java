package ca.bnc.wealth.common.bulk.entity;

import ca.bnc.wealth.common.bulk.jsonb.UploadResponse;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.MappedSuperclass;
import java.sql.Timestamp;
import java.sql.Types;
import lombok.Data;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Data
@MappedSuperclass
public class BulkUploadMappedSuperClass {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`BULK_UPLOADS_ID`")
  private long bulkUploadId;

  @Column(name = "`TEMPLATE_ID`")
  private long templateId;

  @Lob
  @Column(name = "`ORIGINAL_BINARY`")
  @JdbcTypeCode(Types.VARBINARY)
  private byte[] originalBinary;

  @Lob
  @Column(name = "`DOWNLOAD_BINARY`")
  @JdbcTypeCode(Types.VARBINARY)
  private byte[] downloadBinary;

  @Column(name = "`FILE_NAME`")
  private String fileName;

  @Column(name = "`UPLOAD_RESPONSE`")
  @JdbcTypeCode(SqlTypes.JSON)
  private UploadResponse uploadResponse;

  @Column(name = "`SCOPE_VALUE`")
  private String scopeValue;

  @Column(name = "`BULK_CONVERT_REQUEST_ID`")
  private long bulkConvertRequestId;

  @Column(name = "`BULK_CONVERT_STATUS`")
  private String bulkConvertStatus;

  @Column(name = "`BULK_VALIDATE_REQUEST_ID`")
  private long bulkValidateRequestId;

  @Column(name = "`BULK_VALIDATE_STATUS`")
  private String bulkValidateStatus;

  @Column(name = "`BULK_ACTION_REQUEST_ID`")
  private long bulkActionRequestId;

  @Column(name = "`BULK_ACTION_STATUS`")
  private String bulkActionStatus;

  @Column(name = "`RETAINED_UNTIL`")
  private Timestamp retention;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATION_DATE`")
  private Timestamp creationDate;

  @Column(name = "`LAST_UPDATED_BY`")
  private String lastUpdatedBy;

  @Column(name = "`LAST_UPDATE_DATE`")
  private Timestamp lastUpdateDate;
}
