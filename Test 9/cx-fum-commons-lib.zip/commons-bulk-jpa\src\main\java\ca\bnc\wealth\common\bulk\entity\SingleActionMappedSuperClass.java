package ca.bnc.wealth.common.bulk.entity;

import ca.bnc.wealth.common.bulk.jsonb.ActionResponse;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import java.sql.Timestamp;
import lombok.Data;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Data
@MappedSuperclass
public class SingleActionMappedSuperClass {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`SINGLE_ACTIONS_ID`")
  private long singleActionId;

  @Column(name = "`REQUEST_ID`")
  private String requestID;

  @Column(name = "`BULK_REQUEST_ID`")
  private long bulkRequestID;

  @Column(name = "`STATE`")
  private String state;

  @Column(name = "`UPLOAD_ROW_NUMBER`")
  private String uploadRowNumber;

  @Column(name = "`ACTION_URL`")
  private String actionUrl;

  @Column(name = "`ACTION_REQUEST`")
  private String actionRequest;

  @Column(name = "`ACTION_RESPONSE`")
  @JdbcTypeCode(SqlTypes.JSON)
  private ActionResponse actionResponse;

  @Column(name = "`RETAINED_UNTIL`")
  private Timestamp retention;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATION_DATE`")
  private Timestamp creationDate;

  @Column(name = "`LAST_UPDATED_BY`")
  private String lastUpdatedBy;

  @Column(name = "`LAST_UPDATE_DATE`")
  private Timestamp lastUpdateDate;
}
