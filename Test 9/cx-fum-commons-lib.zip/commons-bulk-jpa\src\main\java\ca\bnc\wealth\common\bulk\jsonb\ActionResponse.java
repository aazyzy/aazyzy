package ca.bnc.wealth.common.bulk.jsonb;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ActionResponse {

  private String data;

  private List<ErrorMessage> errorMessages;
}
