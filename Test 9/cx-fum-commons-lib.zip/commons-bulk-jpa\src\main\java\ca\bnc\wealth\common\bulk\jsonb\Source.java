package ca.bnc.wealth.common.bulk.jsonb;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Source {

  private String userId;

  private String system;

  private String apiName;

  private String nbcId;
}
