package ca.bnc.wealth.common.bulk.jsonb;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TemplateField {

  private TemplateFieldConfig config;
  private String fieldName;
}
