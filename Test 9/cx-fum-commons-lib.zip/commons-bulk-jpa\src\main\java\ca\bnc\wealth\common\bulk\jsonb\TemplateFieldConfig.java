package ca.bnc.wealth.common.bulk.jsonb;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TemplateFieldConfig {

  private String pattern;
  private String errorMsg;
  private String jsonCDMPath;
  private String jsonContentValidationPath;
  private Boolean mandatory;
  private String headerName;
}
