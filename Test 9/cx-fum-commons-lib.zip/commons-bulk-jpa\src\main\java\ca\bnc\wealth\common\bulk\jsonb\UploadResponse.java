package ca.bnc.wealth.common.bulk.jsonb;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class UploadResponse {

  private String requestDescription;

  private String version;

  private String uploadTemplateName;

  private long retention;

  private Source source;

  private List<SingleRequest> singleRequests;


}
