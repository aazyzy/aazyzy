package ca.bnc.wealth.common.bulk.repo;

import ca.bnc.wealth.common.bulk.entity.BulkTemplateMappedSuperClass;

public interface BulkTemplateRepositoryInterface {

  BulkTemplateMappedSuperClass findByTemplateName(String sourceNbcId);
}
