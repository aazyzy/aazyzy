package ca.bnc.wealth.common.bulk.repo;

import java.sql.Timestamp;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

public interface BulkUploadRepositoryInterface {

  @Transactional
  @Modifying
  public void deleteByRetentionBefore(Timestamp timestamp);
}
