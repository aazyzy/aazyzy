package ca.bnc.wealth.common.bulk.repo;

import ca.bnc.wealth.common.bulk.entity.SingleActionMappedSuperClass;
import java.sql.Timestamp;
import java.util.List;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface SingleActionRepositoryInterface {

  @Query(value = "select * from nextval(:sequenceName);", countQuery = "SELECT count(*) from nextval(:sequenceName);", nativeQuery = true)
  long generateID(String sequenceName);

  @Query(value = "SELECT nextval(:sequenceName) from generate_series(0, :size) ;", countQuery = "SELECT count(*) from generate_series(0, :size) ;", nativeQuery = true)
  List<Long> generateIDsForTheBatch(String sequenceName, int size);

  long countByBulkRequestIDAndState(long bulkRequestID, String state);

  List<? extends SingleActionMappedSuperClass> findByBulkRequestID(long bulkRequestID);

  @Transactional
  @Modifying
  public void deleteByRetentionBefore(Timestamp timestamp);
}
