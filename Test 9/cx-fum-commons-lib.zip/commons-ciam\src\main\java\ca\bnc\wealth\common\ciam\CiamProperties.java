package ca.bnc.wealth.common.ciam;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Data
public class CiamProperties {

  @Value("${feign.ciamApi.url:#{null}}")
  private String ciamApiUrl;

  @Value("${feign.oktaProxy.url:#{null}}")
  private String oktaProxyUrl;
}
