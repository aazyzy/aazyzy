package ca.bnc.wealth.common.ciam.feign.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(url = "${feign.ciamApi.url}")
public interface AddOktaUserGroupClient {

  @RequestMapping(path = "/groups/{group}/users/{userId}", method = RequestMethod.PUT)
  ResponseEntity<Void> addUserGroup(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestHeader(name = "context") String context,
      @PathVariable(value = "group") String userGroupName,
      @PathVariable(value = "userId") String idpUserIdentifier);
}
