package ca.bnc.wealth.common.ciam.feign.client;

import ca.bnc.wealth.common.ciam.model.OktaUserRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(url = "${feign.ciamApi.url}")
public interface CreateActiveOktaUserClient {

  @RequestMapping(
      path = "profiles?expirePassword=false",
      method = RequestMethod.POST,
      consumes = MediaType.APPLICATION_JSON_VALUE)
  ResponseEntity<Void> createOktaUser(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestHeader(name = "context") String context,
      @RequestBody OktaUserRequest oktaUserRequest);
}
