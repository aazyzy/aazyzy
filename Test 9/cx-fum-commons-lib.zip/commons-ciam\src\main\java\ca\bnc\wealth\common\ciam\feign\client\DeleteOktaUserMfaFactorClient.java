package ca.bnc.wealth.common.ciam.feign.client;

import ca.bnc.wealth.common.ciam.model.OktaDeleteMfaFactor;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(url = "${feign.ciamApi.url}")
public interface DeleteOktaUserMfaFactorClient {

  @RequestMapping(
      path = "profiles/{userId}/mfa/factors",
      method = RequestMethod.DELETE,
      consumes = MediaType.APPLICATION_JSON_VALUE)
  ResponseEntity<Void> deleteOktaUserMfaFactor(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestHeader(name = "context") String context,
      @PathVariable(value = "userId") String idpUserIdentifier,
      @RequestBody OktaDeleteMfaFactor oktaDeleteMfaFactor);
}
