package ca.bnc.wealth.common.ciam.feign.client;

import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(url = "${feign.oktaProxy.url}")
public interface GetOktaUserProfileClient {

  @RequestMapping(path = "profiles/{userId}", method = RequestMethod.GET)
  OktaUserProfile getOktaUserProfile(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestHeader(name = "context") String context,
      @PathVariable String userId);
}
