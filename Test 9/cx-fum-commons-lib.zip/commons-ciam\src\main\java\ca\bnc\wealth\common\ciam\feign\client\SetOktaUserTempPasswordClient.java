package ca.bnc.wealth.common.ciam.feign.client;

import ca.bnc.wealth.common.ciam.model.OktaNewPassword;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(url = "${feign.ciamApi.url}")
public interface SetOktaUserTempPasswordClient {

  @RequestMapping(path = "profiles/{userId}/credentials/temp_password", method = RequestMethod.PUT)
  ResponseEntity<Void> setOktaUserTempPassword(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestHeader(name = "context") String context,
      @PathVariable(name = "userId") String userId,
      @RequestBody OktaNewPassword tempPassword);
}
