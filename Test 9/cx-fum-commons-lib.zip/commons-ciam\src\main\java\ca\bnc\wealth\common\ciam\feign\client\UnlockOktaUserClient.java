package ca.bnc.wealth.common.ciam.feign.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(url = "${feign.ciamApi.url}")
public interface UnlockOktaUserClient {

  @RequestMapping(path = "profiles/{userId}/lifecycle/unlock", method = RequestMethod.PUT)
  ResponseEntity<Void> unlockOktaUser(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestHeader(name = "context") String context,
      @RequestBody String emptyRequestBody);
}
