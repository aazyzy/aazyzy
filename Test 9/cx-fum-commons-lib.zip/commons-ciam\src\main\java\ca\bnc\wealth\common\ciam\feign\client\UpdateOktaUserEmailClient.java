package ca.bnc.wealth.common.ciam.feign.client;

import ca.bnc.wealth.common.ciam.model.OktaUserEmail;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(url = "${feign.ciamApi.url}")
public interface UpdateOktaUserEmailClient {

  @RequestMapping(
      path = "profiles/{userId}/email",
      method = RequestMethod.PUT,
      consumes = MediaType.APPLICATION_JSON_VALUE)
  ResponseEntity<Void> updateOktaUserEmail(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestHeader(name = "context") String context,
      @PathVariable String userId,
      @RequestBody OktaUserEmail oktaUserEmail,
      @RequestParam boolean enroll);
}
