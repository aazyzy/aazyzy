package ca.bnc.wealth.common.ciam.feign.config;

import ca.bnc.wealth.api.authorization.feign.config.FeignCodecs;
import ca.bnc.wealth.common.ciam.CiamProperties;
import ca.bnc.wealth.common.ciam.feign.client.*;
import feign.Feign;
import feign.Logger;
import feign.Util;
import feign.codec.Decoder;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tools.jackson.databind.JavaType;
import tools.jackson.databind.cfg.DateTimeFeature;
import tools.jackson.databind.json.JsonMapper;

@Configuration
@EnableFeignClients
@Slf4j
public class FeignClientConfig {

  // Jackson 2 defaults: what the Spring Boot 3 line's new ObjectMapper() with JavaTimeModule read
  private static final JsonMapper DECODER_MAPPER =
      JsonMapper.builderWithJackson2Defaults()
          .disable(DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS)
          .build();

  @Autowired CiamProperties ciamProperties;

  @Bean
  public Decoder getResponseEntityDecoder() {
    return (response, type) -> {
      String bodyStr = Util.toString(response.body().asReader(Util.UTF_8));
      JavaType javaType = DECODER_MAPPER.getTypeFactory().constructType(type);
      return DECODER_MAPPER.readValue(bodyStr, javaType);
    };
  }

  @Bean
  public GetOktaUserGroupsClient getOktaUserGroups(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .decoder(new ResponseEntityDecoder(getResponseEntityDecoder()))
        .logger(new Slf4jLogger(GetOktaUserGroupsClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(GetOktaUserGroupsClient.class, ciamProperties.getOktaProxyUrl());
  }

  @Bean
  public AddOktaUserGroupClient addOktaUserGroup(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .logger(new Slf4jLogger(AddOktaUserGroupClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(AddOktaUserGroupClient.class, ciamProperties.getCiamApiUrl());
  }

  @Bean
  public DeleteOktaUserGroupClient deleteOktaUserGroup(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .logger(new Slf4jLogger(DeleteOktaUserGroupClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(DeleteOktaUserGroupClient.class, ciamProperties.getCiamApiUrl());
  }

  @Bean
  public CreateOktaUserClient createOktaUser(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .logger(new Slf4jLogger(CreateOktaUserClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(CreateOktaUserClient.class, ciamProperties.getCiamApiUrl());
  }

  @Bean
  public CreateActiveOktaUserClient createActiveOktaUser(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .logger(new Slf4jLogger(CreateActiveOktaUserClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(CreateActiveOktaUserClient.class, ciamProperties.getCiamApiUrl());
  }

  @Bean
  public CreateOktaUserWithHashedPasswordClient createOktaUserWithHashedPasswordClient(
      JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .logger(new Slf4jLogger(CreateOktaUserWithHashedPasswordClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(CreateOktaUserWithHashedPasswordClient.class, ciamProperties.getCiamApiUrl());
  }

  @Bean
  public CreateActiveOktaUserWithHashedPasswordClient createActiveOktaUserWithHashedPasswordClient(
      JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .logger(new Slf4jLogger(CreateActiveOktaUserWithHashedPasswordClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(CreateActiveOktaUserWithHashedPasswordClient.class, ciamProperties.getCiamApiUrl());
  }

  @Bean
  public DeleteOktaUserClient deleteOktaUser(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .logger(new Slf4jLogger(DeleteOktaUserClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(DeleteOktaUserClient.class, ciamProperties.getCiamApiUrl());
  }

  @Bean
  public DeleteOktaUserMfaFactorClient deleteOktaUserSms2fa(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .logger(new Slf4jLogger(DeleteOktaUserMfaFactorClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(DeleteOktaUserMfaFactorClient.class, ciamProperties.getCiamApiUrl());
  }

  @Bean
  public UnlockOktaUserClient unlockOktaUser(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .logger(new Slf4jLogger(UnlockOktaUserClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(UnlockOktaUserClient.class, ciamProperties.getCiamApiUrl());
  }

  @Bean
  public SetOktaUserTempPasswordClient setOktaUserTempPassword(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .logger(new Slf4jLogger(SetOktaUserTempPasswordClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(SetOktaUserTempPasswordClient.class, ciamProperties.getCiamApiUrl());
  }

  @Bean
  public GetOktaUserProfileClient getOktaUserProfile(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .decoder(new ResponseEntityDecoder(getResponseEntityDecoder()))
        .logger(new Slf4jLogger(GetOktaUserProfileClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(GetOktaUserProfileClient.class, ciamProperties.getOktaProxyUrl());
  }

  @Bean
  public SuspendOktaUserProfileClient suspendOktaUserProfileClient(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .logger(new Slf4jLogger(SuspendOktaUserProfileClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(SuspendOktaUserProfileClient.class, ciamProperties.getCiamApiUrl());
  }

  @Bean
  public UnsuspendOktaUserProfileClient unsuspendOktaUserProfileClient(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .logger(new Slf4jLogger(UnsuspendOktaUserProfileClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(UnsuspendOktaUserProfileClient.class, ciamProperties.getCiamApiUrl());
  }

  @Bean
  public UpdateOktaSecureZoneIdClient updateOktaSecureZoneId(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .logger(new Slf4jLogger(UpdateOktaSecureZoneIdClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(UpdateOktaSecureZoneIdClient.class, ciamProperties.getCiamApiUrl());
  }

  @Bean
  public SyncOktaUserProfileClient syncOktaUserProfileClient(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .logger(new Slf4jLogger(SyncOktaUserProfileClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(SyncOktaUserProfileClient.class, ciamProperties.getCiamApiUrl());
  }

  @Bean
  public UpdateOktaUserEmailClient updateOktaUserEmailClient(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .logger(new Slf4jLogger(UpdateOktaUserEmailClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(UpdateOktaUserEmailClient.class, ciamProperties.getCiamApiUrl());
  }
}
