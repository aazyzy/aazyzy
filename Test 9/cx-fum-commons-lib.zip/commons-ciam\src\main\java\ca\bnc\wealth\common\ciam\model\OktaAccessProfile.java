package ca.bnc.wealth.common.ciam.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString
public class OktaAccessProfile {

  String lastName;
  String firstName;
  String username;
  String email;
  String login;
  String preferredLanguage;
  String locale;
  String bngfReferenceId;
  String[] bngfSecureZoneId;
  String bngfIdentitySource;
}
