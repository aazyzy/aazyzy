package ca.bnc.wealth.common.ciam.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString
public class OktaCredentials {

  String password;
  String newPassword;
  @JsonProperty("recoveryQuestion")
  RecoveryQuestion recoveryQuestion;

  @Getter
  @Setter
  @JsonIgnoreProperties(ignoreUnknown = true)
  @ToString
  static class RecoveryQuestion {

    String question;
  }
}
