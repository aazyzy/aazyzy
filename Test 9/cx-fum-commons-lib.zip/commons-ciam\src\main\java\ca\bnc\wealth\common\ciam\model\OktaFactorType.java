package ca.bnc.wealth.common.ciam.model;

public enum OktaFactorType {

  CALL("call"),
  EMAIL("email"),
  PUSH("push"),
  QUESTION("question"),
  SMS("sms"),
  TOKEN("token"),
  TOKEN_HARDWARE("token:hardware"),
  TOKEN_HOTP("token:hotp"),
  TOKEN_SOFTWARE_HOTP("token:software:hotp"),
  U2F("u2f"),
  WEB("web"),
  WEBAUTHN("webauthn");

  private final String factorType;

  OktaFactorType(final String factorType) {
    this.factorType = factorType;
  }

  public String getFactorType() {
    return factorType;
  }

  @Override
  public String toString() {
    return getFactorType();
  }

}
