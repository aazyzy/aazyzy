package ca.bnc.wealth.common.ciam.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class OktaHash implements Serializable {

  private static final long serialVersionUID = 1L;

  @JsonProperty("algorithm")
  private String algorithm;

  @JsonProperty("value")
  private String value;

  @JsonProperty("salt")
  private String salt;

  @JsonProperty("workFactor")
  private Integer workFactor;

  @JsonProperty("saltOrder")
  private String saltOrder;
}