package ca.bnc.wealth.common.ciam.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class OktaUserEmail implements Serializable {

  private static final long serialVersionUID = 1L;

  @JsonProperty("newEmail")
  private String newEmail;

  @JsonProperty("credentials")
  private OktaCredentials credentials;
}
