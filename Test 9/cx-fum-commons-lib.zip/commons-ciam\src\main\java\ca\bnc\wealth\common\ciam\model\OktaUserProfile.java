package ca.bnc.wealth.common.ciam.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class OktaUserProfile {

  String id;
  String status;
  String created;
  String activated;
  String statusChanged;
  String lastLogin;
  String lastUpdated;
  String passwordChanged;
  OktaCredentials credentials;
  OktaFactor factors[];
  OktaAccessProfile accessProfile;
}
