package ca.bnc.wealth.common.ciam.security;

public interface CiamSystemToken {

  public String getSystemToken();

  public String getBearerToken();
}
