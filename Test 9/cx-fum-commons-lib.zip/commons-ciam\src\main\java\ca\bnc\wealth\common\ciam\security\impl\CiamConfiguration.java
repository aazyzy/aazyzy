package ca.bnc.wealth.common.ciam.security.impl;

import ca.bnc.wealth.common.ciam.CiamProperties;
import ca.bnc.wealth.common.ciam.security.CiamSystemToken;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Slf4j
@Configuration
@Profile("!test")
public class CiamConfiguration {

  @Bean
  public CiamProperties getCiamProperties() {
    return new CiamProperties();
  }

  @Bean
  public CiamSystemToken getCiamSystemToken() {
    log.info("Initializing CIAM system token");
    return new CiamSystemTokenImpl();
  }
}
