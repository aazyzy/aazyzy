package ca.bnc.wealth.common.ciam.security.impl;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.common.ciam.security.CiamSystemToken;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

@Slf4j
public class CiamSystemTokenImpl implements CiamSystemToken {

  @Autowired SystemTokenFactory systemTokenFactory;

  @Override
  public String getSystemToken() {
    log.info("Getting ciam system token");
    return systemTokenFactory.getSystemToken("fum");
  }

  @Override
  public String getBearerToken() {
    return systemTokenFactory.getBearerToken("fum");
  }
}
