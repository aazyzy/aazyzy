package ca.bnc.wealth.common.ciam.security.test;

import ca.bnc.wealth.common.ciam.CiamProperties;
import ca.bnc.wealth.common.ciam.security.CiamSystemToken;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("test")
@Slf4j
public class TestCiamConfiguration {

  @Bean
  public CiamSystemToken getCiamSystemToken() {
    return new TestCiamSystemToken();
  }

  @Bean
  public CiamProperties getCiamProperties() {
    return new CiamProperties();
  }

}
