package ca.bnc.wealth.common.ciam.security.test;

import ca.bnc.wealth.common.ciam.security.CiamSystemToken;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

@Slf4j
public class TestCiamSystemToken implements CiamSystemToken {

  final String sampleToken =
      "eyJraWQiOiJYSVNic2tIT3IxSFBZamtBYnVSQ2pqYk43RlUxVnZEcG9HZVY3cVBwanRrIiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULk45T2EwTWNaYjZxVGdzRHB5Si1fLWtWM01JX1NvWFJ2LUdYcTIzNDlfMEkiLCJpc3MiOiJodHRwczovL3N5cy1wcC5ibmMuY2Evb2F1dGgyL2F1c29yNDh2ZzdLVmluek1NMGg3IiwiYXVkIjoiZGVmYXVsdCIsImlhdCI6MTY1Mjk4Mjc0MSwiZXhwIjoxNjUyOTg2MzQxLCJjaWQiOiIwb2ExM2J0bjR1N0Nyc0pDSzBoOCIsInNjcCI6WyJjaWFtOnByb2ZpbGVzOndyaXRlIiwiY2lhbTpncm91cHM6ZGVsZXRlIiwiY2lhbTpwcm9maWxlczphZG1pbiIsImNpYW06Z3JvdXBzOndyaXRlIiwiY2lhbTpwcm9maWxlczpyZWFkIl0sInN1YiI6IjBvYTEzYnRuNHU3Q3JzSkNLMGg4IiwiZ3JvdXBzIjpbIlJvYm90Il19.MHLKeMuhdhL7IQASNvWi4Wcoqsfv_jHQfE2Ztm_Q0oTf6bbAI3m9TByMbp0R6p7xHFXhmDQscyTDwfspldXJGYSGE0qQY2hOZrEMUle7L-84KIkIJQ9XGZvTH00K3aCR9cw342yrXpJmrKons7aT5hyesPNXqyrTg1kub-JPFPulxAEjpCExA4zbgDelvopb-AEX4t6rubWMG35PT0GhDIImU0Ig75ky5TONr3V4hX78V1YOyy5i7Vn9KCQIMxW8Zsqw2yVEviw-FZxmB516BxN2hvlE8gMf-R1grlRnhmCfy9DC3PbRMB11_akl-CNCD2jSQwX3cUROzH8ROYvjww";

  @Value("${oauth2.ciam.testToken:#{null}}")
  private String systemToken;

  @Override
  public String getSystemToken() {
    log.warn("!!!!!!!!!!!!TEST MODE. Dummy CIAM System Token !!!!!!!!!");
    return systemToken == null || systemToken.isEmpty() || systemToken.equals("null")
        ? sampleToken
        : systemToken;
  }

  @Override
  public String getBearerToken() {
    return "Bearer " + this.getSystemToken();
  }
}
