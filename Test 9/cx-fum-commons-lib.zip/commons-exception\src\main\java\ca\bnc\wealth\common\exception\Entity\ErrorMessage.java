package ca.bnc.wealth.common.exception.Entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

@Data
@NoArgsConstructor
public class ErrorMessage {

  @JsonProperty("title")
  String title = "INTERNAL_SERVER_ERROR";
  @JsonProperty("description")
  String description = "Internal Server Error";
  @JsonProperty("httpCode")
  String httpCode = "500";
  @JsonProperty("timestamp")
  LocalDateTime timestamp;
  @JsonProperty("messages")
  Messages messages;

  public ErrorMessage(String code, String defaultMessage) {
    timestamp = LocalDateTime.now();
    messages = new Messages();
    Errors error = new Errors();
    error.setCode(code);
    error.setMessage(defaultMessage);
    Errors[] errors = {error};

    messages.setErrors(errors);
  }

  public ErrorMessage(String code, String defaultMessage, HttpStatus httpStatus) {
    this(code, defaultMessage);
    title = httpStatus.name();
    description = httpStatus.getReasonPhrase();
    httpCode = String.valueOf(httpStatus.value());
  }

  public ErrorMessage(List<Errors> errors, HttpStatus httpStatus) {
    timestamp = LocalDateTime.now();
    title = httpStatus.name();
    description = httpStatus.getReasonPhrase();
    httpCode = String.valueOf(httpStatus.value());
    messages = new Messages();
    messages.setErrors(errors.toArray(new Errors[0]));
  }
}
