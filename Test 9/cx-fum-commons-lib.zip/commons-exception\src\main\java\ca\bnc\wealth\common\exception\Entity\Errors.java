package ca.bnc.wealth.common.exception.Entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Errors {

  @JsonProperty("code")
  String code;

  @JsonProperty("field")
  String field;

  @JsonProperty("message")
  String message;
}
