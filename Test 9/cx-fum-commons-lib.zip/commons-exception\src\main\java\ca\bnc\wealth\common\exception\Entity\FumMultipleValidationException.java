package ca.bnc.wealth.common.exception.Entity;

import java.util.List;
import lombok.Data;

@Data
public class FumMultipleValidationException extends RuntimeException {

  private List<Errors> errors;

  public FumMultipleValidationException(List<Errors> errors) {
    this.errors = errors;
  }
}