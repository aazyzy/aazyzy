package ca.bnc.wealth.common.exception.Entity;

import lombok.Data;

@Data
public class FumValidationException extends RuntimeException {

  private String message;
  private String code;

  public FumValidationException(String code, String message) {
    super(message);
    this.code = code;
    this.message = message;
  }
}
