package ca.bnc.wealth.common.exception.Entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Messages {

  @JsonProperty("errors")
  Errors[] errors;

  @JsonProperty("info")
  String info;

  @JsonProperty("warnings")
  String warnings;
}
