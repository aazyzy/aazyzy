package ca.bnc.wealth.common.exception.handler;

import ca.bnc.wealth.common.exception.Entity.ErrorMessage;
import ca.bnc.wealth.common.exception.Entity.FumConflictException;
import ca.bnc.wealth.common.exception.Entity.FumMultipleValidationException;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class ServiceExceptionHandler extends ResponseEntityExceptionHandler {

  @ExceptionHandler(value = {FumServiceException.class})
  protected ResponseEntity<Object> handleFumException(FumServiceException ex, WebRequest request) {
    ErrorMessage errorMessage = new ErrorMessage(ex.getCode(), ex.getMessage());
    return handleExceptionInternal(ex, errorMessage,
        new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
  }

  @ExceptionHandler(value = {FumValidationException.class})
  protected ResponseEntity<Object> handleFumException(FumValidationException ex,
      WebRequest request) {
    ErrorMessage errorMessage = new ErrorMessage(ex.getCode(), ex.getMessage(),
        HttpStatus.BAD_REQUEST);
    return createResponseEntity(errorMessage, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
  }

  @ExceptionHandler(value = {FumMultipleValidationException.class})
  protected ResponseEntity<Object> handleFumException(FumMultipleValidationException ex,
      WebRequest request) {
    ErrorMessage errorMessage = new ErrorMessage(ex.getErrors(), HttpStatus.BAD_REQUEST);
    return createResponseEntity(errorMessage, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
  }

  @ExceptionHandler(value = {FumNotFoundException.class})
  protected ResponseEntity<Object> handleFumException(FumNotFoundException ex,
      WebRequest request) {
    ErrorMessage errorMessage = new ErrorMessage(ex.getCode(), ex.getMessage(),
        HttpStatus.NOT_FOUND);
    return createResponseEntity(errorMessage, new HttpHeaders(), HttpStatus.NOT_FOUND, request);
  }

  @ExceptionHandler(value = {FumConflictException.class})
  protected ResponseEntity<Object> handleFumException(FumConflictException ex,
      WebRequest request) {
    ErrorMessage errorMessage = new ErrorMessage(ex.getCode(), ex.getMessage(),
        HttpStatus.CONFLICT);
    return createResponseEntity(errorMessage, new HttpHeaders(), HttpStatus.CONFLICT, request);
  }
}
