package ca.bnc.wealth.common.extract.api;

public enum ExtractStatus {

  IN_PROGRESS,
  GENERATED,
  COMPLETED,
  FAILED;

}