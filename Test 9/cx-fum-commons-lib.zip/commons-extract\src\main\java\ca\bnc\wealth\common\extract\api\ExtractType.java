package ca.bnc.wealth.common.extract.api;

public enum ExtractType {

  USER,
  BULK_UPLOAD;

}