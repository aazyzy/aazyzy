package ca.bnc.wealth.common.extract.service;

public interface ExtractInterface {

  String getExtractType();

  byte[] getExtract(long entityId);

}