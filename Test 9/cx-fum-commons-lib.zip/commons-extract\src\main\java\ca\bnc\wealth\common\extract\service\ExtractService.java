package ca.bnc.wealth.common.extract.service;

import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.extract.api.ExtractStatus;
import ca.bnc.wealth.common.extract.api.ExtractType;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserExtractDownload;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserExtractDownloadRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ExtractService {

    public static final String EXTRACT_DATA_FAILED_TO_GENERATE_ERROR_CODE = "extract.data.failed";
    public static final String EXTRACT_DATA_FAILED_TO_GENERATE_ERROR_MESSAGE = "Failed to generate extract data";
    ExecutorService executorService = Executors.newFixedThreadPool(2);
    @Value("${extract.wait.time.min:30}")
    private int EXTRACT_WAITING_TIME_IN_MIN;
    @Autowired
    private ConfigurableListableBeanFactory beanFactory;
    @Autowired
    private IamUserExtractDownloadRepository userExtractDownloadRepository;
    @Autowired
    private IamUserConfigurationRepository userConfigurationRepository;
    private Map<String, ExtractInterface> extractServiceMap = new HashMap<>();

    @EventListener(ApplicationReadyEvent.class)
    public void runAfterReady() {
        beanFactory.getBeansOfType(ExtractInterface.class)
                .forEach((k, v) -> extractServiceMap.put(v.getExtractType(), v));
    }

    public byte[] getExtract(long userConfigurationId, ExtractType extractType)
            throws FumServiceException {
        List<String> lst = Arrays.asList(ExtractStatus.GENERATED.name(),
                ExtractStatus.IN_PROGRESS.name(), ExtractStatus.FAILED.name());
        Optional<IamUserExtractDownload> optional = getUserExtractDownload(userConfigurationId, lst);
        if (optional.isPresent()) {
            IamUserExtractDownload userExtractDownload = optional.get();
            switch (ExtractStatus.valueOf(userExtractDownload.getStatus())) {
                case GENERATED:
                    userExtractDownload.setStatus(ExtractStatus.COMPLETED.name());
                    userExtractDownloadRepository.saveAndFlush(userExtractDownload);
                    return userExtractDownload.getExtractData();
                case IN_PROGRESS:
                    return null;
                case FAILED:
                    userExtractDownload.setStatus(ExtractStatus.COMPLETED.name());
                    userExtractDownload.setExtractData(
                            EXTRACT_DATA_FAILED_TO_GENERATE_ERROR_MESSAGE.getBytes());
                    userExtractDownloadRepository.saveAndFlush(userExtractDownload);
                    throw new FumServiceException(EXTRACT_DATA_FAILED_TO_GENERATE_ERROR_CODE,
                        EXTRACT_DATA_FAILED_TO_GENERATE_ERROR_MESSAGE);
            }
        }
        IamUserExtractDownload userExtractDownload = userExtractDownloadRepository.saveAndFlush(
                createUserExtractDownload(userConfigurationId, extractType));
        executorService.submit(() -> callExtract(userExtractDownload));
        return null;
    }

    private void callExtract(IamUserExtractDownload userExtractDownload) {
        ExtractInterface extractInterface = extractServiceMap.get(
                userExtractDownload.getExtractType());
        try {
            byte[] extract = extractInterface.getExtract(userExtractDownload.getRequestedBy().getUserConfigurationId());

            IamUserExtractDownload currentUserExtractDownload = userExtractDownloadRepository.findById(userExtractDownload.getExtractId()).get();
            if (currentUserExtractDownload.getStatus().equalsIgnoreCase(ExtractStatus.IN_PROGRESS.name())) {
                currentUserExtractDownload.setStatus(ExtractStatus.GENERATED.name());
                currentUserExtractDownload.setExtractData(extract);
                userExtractDownloadRepository.saveAndFlush(currentUserExtractDownload);
            }
        } catch (Exception exception) {
            IamUserExtractDownload currentUserExtractDownload = userExtractDownloadRepository.findById(userExtractDownload.getExtractId()).get();
            currentUserExtractDownload.setStatus(ExtractStatus.FAILED.name());
            userExtractDownloadRepository.saveAndFlush(currentUserExtractDownload);
        }

    }

    private IamUserExtractDownload createUserExtractDownload(long userConfigurationId,
                                                          ExtractType extractType) {
        IamUserExtractDownload userExtractDownload = new IamUserExtractDownload();
        IamUserConfiguration userConfiguration = userConfigurationRepository.getReferenceById(userConfigurationId);
        userExtractDownload.setRequestedBy(userConfiguration);
        userExtractDownload.setExtractType(extractType.name());
        userExtractDownload.setStatus(ExtractStatus.IN_PROGRESS.name());
        userExtractDownload.setRequestedOn(Timestamp.valueOf(LocalDateTime.now()));
        return userExtractDownload;
    }

    private Optional<IamUserExtractDownload> getUserExtractDownload(long userConigurationId,
                                                                 List<String> extractStatus) {
        Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
        fieldValueMap.put("status", Pair.of(EnumQueryCriteria.IN, extractStatus));
        fieldValueMap.put("requestedBy.userConfigurationId",
                Pair.of(EnumQueryCriteria.EQUALS, userConigurationId));
        return userExtractDownloadRepository.findOne(new Specification<>(fieldValueMap));
    }

    @Scheduled(fixedDelayString = "${extract.delay.scheduler.time.min:10}", timeUnit = TimeUnit.MINUTES)
    public void scheduleToCheckCompletion() {
        Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
        fieldValueMap.put("status",
                Pair.of(EnumQueryCriteria.EQUALS, ExtractStatus.IN_PROGRESS.name()));
        userExtractDownloadRepository.findAll(new Specification<>(fieldValueMap))
                .forEach(userExtractDownload -> {
                    if (userExtractDownload.getRequestedOn().getTime()
                            + EXTRACT_WAITING_TIME_IN_MIN * 60 * 1000 < System.currentTimeMillis()) {
                        userExtractDownload.setStatus(ExtractStatus.FAILED.name());
                        userExtractDownloadRepository.saveAndFlush(userExtractDownload);
                    }
                });
    }
}