package ca.bnc.wealth.common.fum.config;

import java.util.concurrent.Executor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
@EnableAsync
public class CommonConfig {

  @Value("${fum.async.executor.corePoolSize:2}")
  private int corePoolSize;


  @Bean(name = "fumAsyncExecutor")
  public Executor fumAsyncExecutor()  {

    ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
    executor.setCorePoolSize(corePoolSize);
    executor.setMaxPoolSize(Integer.MAX_VALUE);
    executor.setQueueCapacity(Integer.MAX_VALUE);
    executor.setThreadNamePrefix("Fum-AsynchThread-");
    executor.initialize();
    return executor;
  }
}
