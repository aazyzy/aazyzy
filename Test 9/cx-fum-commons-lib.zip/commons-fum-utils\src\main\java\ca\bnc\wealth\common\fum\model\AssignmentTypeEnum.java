package ca.bnc.wealth.common.fum.model;

import java.util.List;

public enum AssignmentTypeEnum {
  FEATURE_PACKAGE("P", "feature-package", "p"),

  FIRM("F", "firm", "f"),

  PERMISSION("PE", "permission", "pe"),

  RESOURCE("S", "resource", "s"),

  ROLE("RO", "role", "ro"),

  RR_RANGE("R", "rr-range", "r"),

  USER_GROUP("G", "user-group", "g");

  private final String dbCode;
  private final List<String> codes;

  AssignmentTypeEnum(String dbCode, String... codes) {
    this.dbCode = dbCode;
    this.codes = List.of(codes);
  }

  public static AssignmentTypeEnum findByCode(String code) {
    if (code == null) {
      return null;
    }
    return List.of(AssignmentTypeEnum.values()).stream()
        .filter(assignmentType -> assignmentType.codes.contains(code.toLowerCase()))
        .findFirst()
        .orElse(null);
  }

  public String getDbCode() {
    return dbCode;
  }
}
