package ca.bnc.wealth.common.fum.model;

public enum FirmPreferencesEnum {
  defaultModule;
}
