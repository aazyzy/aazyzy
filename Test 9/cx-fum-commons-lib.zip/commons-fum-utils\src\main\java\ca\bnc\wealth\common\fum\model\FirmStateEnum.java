package ca.bnc.wealth.common.fum.model;

public enum FirmStateEnum {
  ACTIVE("active"),
  INACTIVE("inactive"),
  ONBOARDED("onboarded"),
  DECOMMISSIONED("decommissioned");

  public final String label;

  FirmStateEnum(String label) {
    this.label = label;
  }

  public boolean labelEquals(String label) {
    return this.label.equalsIgnoreCase(label);
  }
}
