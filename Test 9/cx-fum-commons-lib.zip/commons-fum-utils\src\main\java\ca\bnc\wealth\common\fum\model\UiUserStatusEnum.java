package ca.bnc.wealth.common.fum.model;

public enum UiUserStatusEnum {
  Invited("Invited"), First_Sign_In("First Sign In"), Active("Active"), Password_Reset("Password Reset"), Locked("Locked"), Inactive("Inactive"), No_Account("No Account");

  public final String status;

  UiUserStatusEnum(String status) {
    this.status = status;
  }
}
