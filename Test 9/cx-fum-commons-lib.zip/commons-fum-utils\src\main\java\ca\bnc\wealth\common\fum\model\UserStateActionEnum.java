package ca.bnc.wealth.common.fum.model;

public enum UserStateActionEnum {
  ONBOARDING("Onboarding"),
  SET_2FA("Set 2FA"),
  SET_PASSWORD("Set Password"),
  SET_RECOVERY_QUESTION("Set Recovery Question"),
  BLANK(""),
  PASSWORD_RESET("Password Reset"),
  PASSWORD_EXPIRED("Password Expired"),
  LOCKED("Locked Out"),
  ACTIVE("Active"),
  SUSPENDED("Suspended"),
  DELETED("Deleted");

  public final String dbValue;

  UserStateActionEnum(String dbValue) {
    this.dbValue = dbValue;
  }

  public static UserStateActionEnum getEnum(String dbValue) {
    for (UserStateActionEnum state : UserStateActionEnum.values()) {
      if (state.dbValue.equalsIgnoreCase(dbValue)) {
        return state;
      }
    }
    return null;
  }
}
