package ca.bnc.wealth.common.fum.model;

public enum UserStateDescriptionEnum {
  STAGED("Staged"),
  PENDING_USER_ACTION("Pending User Action"),
  ACTIVE("Active"),
  PASSWORD_RESET("Password Reset"),
  PASSWORD_EXPIRED("Password Expired"),
  LOCKED("Locked"),
  SUSPENDED("Suspended"),
  DELETED("Deleted");

  public final String dbValue;

  UserStateDescriptionEnum(String dbValue) {
    this.dbValue = dbValue;
  }

  public static UserStateDescriptionEnum getEnum(String dbValue) {
    for (UserStateDescriptionEnum stateDescriptionEnum : UserStateDescriptionEnum.values()) {
      if (stateDescriptionEnum.dbValue.equalsIgnoreCase(dbValue)) {
        return stateDescriptionEnum;
      }
    }
    return null;
  }
}
