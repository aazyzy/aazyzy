package ca.bnc.wealth.common.fum.model;

public enum UserStateEnum {
  ONBOARDING("onboarding"),
  PROVISIONED("provisioned"),
  ACTIVE("active"),
  RECOVERY("recovery"),
  INACTIVE("inactive"),
  DECOMMISSIONED("decommissioned");

  public final String dbValue;

  UserStateEnum(String dbValue) {
    this.dbValue = dbValue;
  }

  public static UserStateEnum getEnum(String dbValue) {
    for (UserStateEnum state : UserStateEnum.values()) {
      if (state.dbValue.equalsIgnoreCase(dbValue)) {
        return state;
      }
    }
    return null;
  }
}
