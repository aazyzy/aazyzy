package ca.bnc.wealth.common.fum.model;

public enum UserStatusEnum {
  ACTIVE("active"),
  INACTIVE("inactive");

  public final String dbValue;

  UserStatusEnum(String dbValue) {
    this.dbValue = dbValue;
  }

  public static UserStatusEnum getEnum(String dbValue) {
    for (UserStatusEnum status : UserStatusEnum.values()) {
      if (status.dbValue.equalsIgnoreCase(dbValue)) {
        return status;
      }
    }
    return null;
  }
}
