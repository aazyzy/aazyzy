package ca.bnc.wealth.common.fum.service;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.concurrent.TimeUnit;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface CustomSynchronized {

  boolean waitForever() default false;

  int waitTime() default 0;

  TimeUnit timeUnit() default TimeUnit.MINUTES;

  boolean runAfterTimeout() default false;

  boolean resetAfterTimeout() default true;


}
