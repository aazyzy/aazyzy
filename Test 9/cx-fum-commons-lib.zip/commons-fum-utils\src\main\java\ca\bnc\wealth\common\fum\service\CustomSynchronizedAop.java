package ca.bnc.wealth.common.fum.service;

import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.jpa.service.IamScheduleService;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Slf4j
public class CustomSynchronizedAop {
  private static final String PT_UPDATE_SCHEDULE = "PT_UPDATE_SCHEDULE";

  @Autowired
  private IamScheduleService iamScheduleService;

  @SneakyThrows
  @Around("@annotation(ca.bnc.wealth.common.fum.service.CustomSynchronized)")
  public void customSynchronized(ProceedingJoinPoint point)  {
    try {
      if(canRun(point))
        point.proceed();
    }  finally {
      iamScheduleService.updateStatusToFinish(PT_UPDATE_SCHEDULE);
    }
  }

  @SneakyThrows
  private boolean canRun(ProceedingJoinPoint point) {
    CustomSynchronized customSynchronized = ((MethodSignature) point.getSignature()).getMethod().getAnnotation(CustomSynchronized.class);
    boolean waitForever = customSynchronized.waitForever();
    int waitTime = customSynchronized.waitTime();
    long waitTimeMillSec = customSynchronized.timeUnit().toMillis(waitTime);
    boolean runAfterTimeout = customSynchronized.runAfterTimeout();
    boolean resetAfterTimeout = customSynchronized.resetAfterTimeout();


    boolean canRun = false;
    while(waitForever || waitTimeMillSec > 0) {
      canRun = CompletableFuture.supplyAsync(() -> iamScheduleService.canRunSchedule(PT_UPDATE_SCHEDULE)).get();
      if (canRun) {
        break;
      }
      log.info("Waiting for the Other Thread to finish");
      Thread.sleep(30 * 1000);//30 seconds
      if (!waitForever) {
        waitTimeMillSec -= 30 * 1000;
      }
    }
    if(canRun) {
      return canRun;
    }
    if(runAfterTimeout) {
      log.info("*****Running the method after timeout*****");
      CompletableFuture.runAsync(() -> iamScheduleService.resetSchedulerStatus(PT_UPDATE_SCHEDULE, true)).get();
      return true;
    } else if(resetAfterTimeout) {
      log.info("*****Resetting the Scheduler Status after timeout*****");
      CompletableFuture.runAsync(() -> iamScheduleService.resetSchedulerStatus(PT_UPDATE_SCHEDULE, false)).get();
    }

    throw new FumServiceException("concurrent.job.error", "Another Thread is running the same method");
  }
}
