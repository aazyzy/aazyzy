package ca.bnc.wealth.common.fum.service;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface CustomThreadPoolExecutor {

  public boolean isBlockingQueue() default true;
  public int blockingQueueSize() default 1;
  public String corePoolSize() default "1";
  public String maxPoolSize() default "1";

}
