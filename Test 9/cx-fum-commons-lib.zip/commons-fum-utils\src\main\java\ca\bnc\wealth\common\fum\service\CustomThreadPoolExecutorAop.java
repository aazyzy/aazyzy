package ca.bnc.wealth.common.fum.service;

import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Slf4j
public class CustomThreadPoolExecutorAop {

  @Autowired
  private ValueResolverService valueResolverService;

  private static final Map<String, ThreadPoolExecutor> threadPoolExecutorMap = new ConcurrentHashMap<>();
  @Around("@annotation(ca.bnc.wealth.common.fum.service.CustomThreadPoolExecutor)")
  public void executionTime(ProceedingJoinPoint point)  {

    CustomThreadPoolExecutor customThreadPoolExecutor = ((MethodSignature) point.getSignature()).getMethod().getAnnotation(CustomThreadPoolExecutor.class);

    log.info("blockingQueueSize: " + customThreadPoolExecutor.blockingQueueSize());

    ThreadPoolExecutor threadPoolExecutor = threadPoolExecutorMap.computeIfAbsent(point.getSignature().toString(), k -> {
      CustomThreadPoolExecutor ctpe = ((MethodSignature) point.getSignature()).getMethod().getAnnotation(CustomThreadPoolExecutor.class);

      if(ctpe.isBlockingQueue()) {
        return new ThreadPoolExecutor(valueResolverService.getIntValue(ctpe.corePoolSize()), valueResolverService.getIntValue(ctpe.maxPoolSize()), 0, TimeUnit.MILLISECONDS,
            new ArrayBlockingQueue<>(ctpe.blockingQueueSize()) ,
            new ThreadPoolExecutor.DiscardOldestPolicy());
      }
      return new ThreadPoolExecutor(valueResolverService.getIntValue(ctpe.corePoolSize()), valueResolverService.getIntValue(ctpe.maxPoolSize()),
          0L, TimeUnit.MILLISECONDS,
          new LinkedBlockingQueue<Runnable>());
    });

    threadPoolExecutor.submit(() -> {
      try {
        return point.proceed();
      } catch (Throwable e) {
        throw new RuntimeException(e);
      }
    });
  }

}
