package ca.bnc.wealth.common.fum.service;

import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.util.Constants;
import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.enums.FirmAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackageAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackageAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.userconfiguration.model.PackageTemplateAssignment;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
@RequiredArgsConstructor
public class FeaturePackageServiceHelper {

  @Autowired
  private PackageTemplateRepository packageTemplateRepository;
  @Autowired
  private PackageTemplateServiceHelper packageTemplateServiceHelper;
  @Autowired
  private FeaturePackageRepository featurePackageRepository;
  @Autowired
  private FeaturePackageAssignmentUserGroupRepository featurePackageAssignmentUserGroupRepository;
  @Autowired
  private FeaturePackageAssignmentResourceRepository featurePackageAssignmentResourceRepository;
  @Autowired
  private FeaturePackageTemplateServiceHelper featurePackageTemplateServiceHelper;
  @Autowired
  private UserAssignmentService userAssignmentService;
  @Autowired
  private FirmAssignmentService firmAssignmentService;
  @Qualifier("postgresJdbcTemplate")
  @Autowired
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  public Map<String, Object> getFeaturePackageByFirmEntityId(Integer firmEntityId) {
    SqlParameterSource firmFeaturePackageParameters = new MapSqlParameterSource()
        .addValue(Constants.FIRM_ENTITY_ID, firmEntityId);
    List<Map<String, Object>> featurePackageList =
        namedParameterJdbcTemplate.queryForList(Constants.FIRM_FEATURE_PACKAGE_QUERY,
            firmFeaturePackageParameters);

    if (featurePackageList.isEmpty()) {
      return new HashMap<>();
    }

    return featurePackageList.get(0);
  }

  public <T extends EntityInterface> List<T> getFeaturePackageAssignment(Integer featurePackageId, PackageAssignmentType packageAssignmentType) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("featurePackage.featurePackageId",
        Pair.of(EnumQueryCriteria.EQUALS, featurePackageId));
    switch (packageAssignmentType) {
      case G:
        fieldValueMap.put("packageTemplateAssignmentUserGroup.assignmentType",
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, packageAssignmentType.name()));
        break;
        case S:
          fieldValueMap.put("packageTemplateAssignmentResource.assignmentType",
              Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, packageAssignmentType.name()));
        break;
    }

    Specification<T> spec = new Specification<>(fieldValueMap);
    JpaSpecificationExecutor jpaSpecificationExecutor = featurePackageTemplateServiceHelper.getJpaSpecificationExecutorForFpAssignment(packageAssignmentType);
    return jpaSpecificationExecutor.findAll(spec);
  }

  @Transactional
  public void updateFeaturePackageStatus(String idpSubject, Integer featurePackageId, boolean active) {
    FeaturePackage featurePackage = featurePackageRepository.getReferenceById(featurePackageId.longValue());
   if(featurePackage == null) {
     log.error("No feature package found for {} ", featurePackageId);
     throw new FumNotFoundException(
         Constants.FEATURE_PACKAGE_NOT_FOUND_CODE,
         String.format(Constants.FEATURE_PACKAGE_NOT_FOUND_MESSAGE, featurePackageId));
   }
    featurePackage.setActive(active);
    featurePackage.setUpdateDate(new Timestamp(System.currentTimeMillis()));
    featurePackage.setUpdatedBy(idpSubject);
    log.info("updateFeaturePackage: updated feature package id{} ", featurePackageId);
    featurePackageRepository.save(featurePackage);
  }

  @Transactional
  public void deleteFeaturePackage(Integer featurePackageId) {
    FeaturePackage featurePackage = featurePackageRepository.findById(featurePackageId.longValue())
        .orElseThrow(
            () -> new FumNotFoundException(Constants.FEATURE_PACKAGE_NOT_FOUND_CODE,
                String.format(Constants.FEATURE_PACKAGE_NOT_FOUND_MESSAGE,
                    featurePackageId)));

    boolean hasUserAssignment = userAssignmentService.hasUserAssignment(featurePackageId, UserAssignmentType.P);
    if (hasUserAssignment) {
      throw new FumValidationException(
          Constants.FEATURE_PACKAGE_HAS_ASSIGNMENT_CODE,
          String.format(
              Constants.FEATURE_PACKAGE_HAS_ASSIGNMENT_MESSAGE,
              featurePackageId));
    }

    boolean hasFirmAssignment = firmAssignmentService.hasFirmAssignment(featurePackageId, FirmAssignmentType.P);
    if (hasFirmAssignment) {
      throw new FumValidationException(
          Constants.FEATURE_PACKAGE_HAS_ASSIGNMENT_CODE,
          String.format(
              Constants.FEATURE_PACKAGE_HAS_ASSIGNMENT_MESSAGE,
              featurePackageId));
    }

    featurePackageTemplateServiceHelper.getJpaRepositoryForFpAssignment(PackageAssignmentType.G)
        .deleteAll(getFeaturePackageAssignment(featurePackageId, PackageAssignmentType.G));

    featurePackageTemplateServiceHelper.getJpaRepositoryForFpAssignment(PackageAssignmentType.S)
        .deleteAll(getFeaturePackageAssignment(featurePackageId, PackageAssignmentType.S));
    featurePackageRepository.delete(featurePackage);
  }

  @Transactional
  public FeaturePackage createFeaturePackage(String packageTemplateName, List<String> moduleOverrides, List<String> features, String requestedBy) {
    PackageTemplate packageTemplate = packageTemplateRepository.findByName(packageTemplateName)
        .orElseThrow(() -> new FumValidationException(Constants.FEATURE_PACKAGE_NAME_NOTFOUND_CODE, Constants.FEATURE_PACKAGE_NAME_NOTFOUND_MESSAGE));

    FeaturePackage featurePackage = createFeaturePackage(packageTemplate, requestedBy);
    updateFeaturePackageAssignments(packageTemplate, featurePackage, moduleOverrides, features, requestedBy);

    return featurePackage;
  }

  @Transactional
  public FeaturePackage createFeaturePackage(long packageTemplateId, List<Pair<Integer, Boolean>> assignmentSelectionPairList, String requestedBy) {
    PackageTemplate packageTemplate = packageTemplateServiceHelper.getPackageTemplate(packageTemplateId);

    validatePackageTemplateAssignments(packageTemplateId, assignmentSelectionPairList);

    FeaturePackage featurePackage = createFeaturePackage(packageTemplate, requestedBy);

    updateFeaturePackageAssignments(packageTemplateId, featurePackage, assignmentSelectionPairList, requestedBy);

    return featurePackage;
  }

  public FeaturePackage createFeaturePackage(PackageTemplate packageTemplate, String requestedBy) {
    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setPackageTemplate(packageTemplate);
    featurePackage.setVersion("1");
    featurePackage.setActive(true);
    featurePackage.setCreatedBy(requestedBy);
    featurePackage.setCreationDate(new Timestamp(System.currentTimeMillis()));
    return featurePackageRepository.save(featurePackage);
  }

  @Transactional
  public FeaturePackage updateFeaturePackage(long featurePackageId, long packageTemplateId, List<Pair<Integer, Boolean>> assignmentSelectionPairList, String requestedBy) {
    FeaturePackage featurePackage = featurePackageRepository.findById(featurePackageId)
        .orElseThrow(
            () -> new FumNotFoundException(Constants.FEATURE_PACKAGE_NOT_FOUND_CODE,
                String.format(Constants.FEATURE_PACKAGE_NOT_FOUND_MESSAGE,
                    packageTemplateId)));

    PackageTemplate packageTemplate = packageTemplateServiceHelper.getPackageTemplate(packageTemplateId);

    validatePackageTemplateAssignments(packageTemplateId, assignmentSelectionPairList);

    FeaturePackage updatedFeaturepackage = updateFeaturePackage(featurePackage, packageTemplate, requestedBy);

    featurePackageAssignmentUserGroupRepository.deleteAll(getFeaturePackageAssignment((int)featurePackageId, PackageAssignmentType.G));
    featurePackageAssignmentUserGroupRepository.flush();
    featurePackageAssignmentResourceRepository.deleteAll(getFeaturePackageAssignment((int)featurePackageId, PackageAssignmentType.S));
    featurePackageAssignmentResourceRepository.flush();

    updateFeaturePackageAssignments(packageTemplateId, updatedFeaturepackage, assignmentSelectionPairList, requestedBy);
    return updatedFeaturepackage;
  }

  public FeaturePackage updateFeaturePackage(FeaturePackage featurePackage, PackageTemplate packageTemplate, String requestedBy) {
    featurePackage.setPackageTemplate(packageTemplate);
    featurePackage.setActive(true);
    featurePackage.setUpdatedBy(requestedBy);
    featurePackage.setUpdateDate(new Timestamp(System.currentTimeMillis()));
    return featurePackageRepository.save(featurePackage);
  }

  private void updateFeaturePackageAssignments(long packageTemplateId,FeaturePackage savedFeaturePackage, List<Pair<Integer, Boolean>> assignmentSelectionPairList, String requestedBy) {
    Map<Long, PackageTemplateAssignmentUserGroup> ptaugs = packageTemplateServiceHelper.getPackageTemplateAssignment(
        packageTemplateId, PackageAssignmentType.G);

    Map<Long, PackageTemplateAssignmentResource> ptars = packageTemplateServiceHelper.getPackageTemplateAssignment(
        packageTemplateId, PackageAssignmentType.S);

    for (Pair<Integer, Boolean> assignmentPair : assignmentSelectionPairList) {
      if (ptaugs.containsKey(assignmentPair.getLeft().longValue())) {
        FeaturePackageAssignmentUserGroup featurePackageAssignmentUserGroup = new FeaturePackageAssignmentUserGroup();

        featurePackageAssignmentUserGroup.setFeaturePackage(savedFeaturePackage);
        featurePackageAssignmentUserGroup.setPackageTemplateAssignmentUserGroup(
            ptaugs.get(assignmentPair.getLeft().longValue()));
        featurePackageAssignmentUserGroup.setSelected(assignmentPair.getRight());
        featurePackageAssignmentUserGroup.setCreatedBy(requestedBy);
        featurePackageAssignmentUserGroup.setCreationDate(
            new Timestamp(System.currentTimeMillis()));

        featurePackageAssignmentUserGroupRepository.save(featurePackageAssignmentUserGroup);
      } else if (ptars.containsKey(
          assignmentPair.getLeft().longValue())) {
        FeaturePackageAssignmentResource featurePackageAssignmentResource = new FeaturePackageAssignmentResource();

        featurePackageAssignmentResource.setFeaturePackage(savedFeaturePackage);
        featurePackageAssignmentResource.setPackageTemplateAssignmentResource(
            ptars.get(assignmentPair.getLeft().longValue()));
        featurePackageAssignmentResource.setSelected(assignmentPair.getRight());
        featurePackageAssignmentResource.setCreatedBy(requestedBy);
        featurePackageAssignmentResource.setCreationDate(new Timestamp(System.currentTimeMillis()));

        featurePackageAssignmentResourceRepository.save(featurePackageAssignmentResource);
      }
    }
  }

  private void updateFeaturePackageAssignments(PackageTemplate packageTemplate,FeaturePackage featurePackage, List<String> moduleOverrides, List<String> features, String requestedBy) {
    Map<Long, PackageTemplateAssignmentUserGroup> ptaugs = packageTemplateServiceHelper.getPackageTemplateAssignment(
        packageTemplate.getPackageTemplateId(), PackageAssignmentType.G);
    ptaugs.forEach((id, ptaug) -> {
      FeaturePackageAssignmentUserGroup featurePackageAssignmentUserGroup = new FeaturePackageAssignmentUserGroup();

      featurePackageAssignmentUserGroup.setFeaturePackage(featurePackage);
      featurePackageAssignmentUserGroup.setPackageTemplateAssignmentUserGroup(ptaug);
      featurePackageAssignmentUserGroup.setSelected(true);
      featurePackageAssignmentUserGroup.setCreatedBy(requestedBy);
      featurePackageAssignmentUserGroup.setCreationDate(new Timestamp(System.currentTimeMillis()));

      featurePackageAssignmentUserGroupRepository.save(featurePackageAssignmentUserGroup);
    });

    Map<Long, PackageTemplateAssignmentResource> ptars = packageTemplateServiceHelper.getPackageTemplateAssignment(
        packageTemplate.getPackageTemplateId(), PackageAssignmentType.S);

    ptars.forEach((id, ptar) -> {
      FeaturePackageAssignmentResource featurePackageAssignmentResource = new FeaturePackageAssignmentResource();

      featurePackageAssignmentResource.setFeaturePackage(featurePackage);
      featurePackageAssignmentResource.setPackageTemplateAssignmentResource(ptar);
      if(ptar.isSelectionDefault()) {
        featurePackageAssignmentResource.setSelected(true);
      } else {
        Resource resource = ptar.getResource();
        if(resource.getRestriction()) {
          Optional.ofNullable(moduleOverrides)
              .flatMap(lst -> lst.stream().filter(mo -> mo.equalsIgnoreCase(resource.getName())).findFirst())
              .ifPresentOrElse((resourceName) -> {
                featurePackageAssignmentResource.setSelected(resource.getRestriction());
              }, () ->{
                featurePackageAssignmentResource.setSelected(!resource.getRestriction());
              });
        } else {
          Optional.ofNullable(features)
              .flatMap(lst -> lst.stream().filter(mo -> mo.equalsIgnoreCase(resource.getName())).findFirst())
              .ifPresentOrElse((resourceName) -> {
                featurePackageAssignmentResource.setSelected(true);
              }, () ->{
                featurePackageAssignmentResource.setSelected(false);
              });
        }
      }
      featurePackageAssignmentResource.setCreatedBy(requestedBy);
      featurePackageAssignmentResource.setCreationDate(new Timestamp(System.currentTimeMillis()));

      featurePackageAssignmentResourceRepository.save(featurePackageAssignmentResource);
    });
  }

  private void validatePackageTemplateAssignments(long packageTemplateId, List<Pair<Integer, Boolean>> assignmentSelectionPairList ) {
    Map<Long, PackageTemplateAssignmentUserGroup> ptaugs = packageTemplateServiceHelper.getPackageTemplateAssignment(
        packageTemplateId, PackageAssignmentType.G);

    Map<Long, PackageTemplateAssignmentResource> ptars = packageTemplateServiceHelper.getPackageTemplateAssignment(
        packageTemplateId, PackageAssignmentType.S);

    validatePackageTemplateAssignments(assignmentSelectionPairList, ptaugs, ptars);
  }
  private void validatePackageTemplateAssignments(List<Pair<Integer, Boolean>> assignmentSelectionPairList,
      Map<Long, PackageTemplateAssignmentUserGroup> ptaugs,
      Map<Long, PackageTemplateAssignmentResource> ptars) {
    if (assignmentSelectionPairList != null &&
        assignmentSelectionPairList.size() != (ptaugs.size() + ptars.size())) {
      throw new FumValidationException(
          Constants.FEATURE_PACKAGE_UNWANTED_DATA_CODE,
          Constants.FEATURE_PACKAGE_UNWANTED_DATA_MESSAGE);
    }

    if (!isIdMatchBetweenInputAndDB(ptaugs.keySet(), ptars.keySet(),
        assignmentSelectionPairList)) {
      throw new FumValidationException(
          Constants.PACKAGE_TEMPLATE_ASSIGNMENT_NOT_MATCH_CODE,
          Constants.PACKAGE_TEMPLATE_ASSIGNMENT_NOT_MATCH_MESSAGE);
    }

    if (!isIncludeAssignmentModeIsActiveInInput(ptaugs, ptars,
        assignmentSelectionPairList)) {
      throw new FumValidationException(
          Constants.PACKAGE_TEMPLATE_ASSIGNMENT_INCLUDE_NOT_ACTIVE_CODE,
          Constants.PACKAGE_TEMPLATE_ASSIGNMENT_INCLUDE_NOT_ACTIVE_MESSAGE);
    }
  }

  private boolean isIdMatchBetweenInputAndDB(Set<Long> ptaugsKeys, Set<Long> ptarsKeys,
      List<Pair<Integer, Boolean>> assignmentSelectionPairList) {
    Set<Integer> input = assignmentSelectionPairList.stream().map(Pair::getKey).collect(
        Collectors.toSet());

    return Stream.of(ptaugsKeys, ptarsKeys).flatMap(Collection::stream)
        .allMatch(id -> input.contains(id.intValue()));

  }

  private boolean isIncludeAssignmentModeIsActiveInInput(
      Map<Long, PackageTemplateAssignmentUserGroup> ptaugs,
      Map<Long, PackageTemplateAssignmentResource> ptars,
      List<Pair<Integer, Boolean>> assignmentSelectionPairList) {

    Map<Integer, Boolean> inputMap = assignmentSelectionPairList.stream()
        .collect(Collectors.toMap(Pair::getKey,Pair::getValue));

    List<Long> includeId1 = ptaugs.values()
        .stream()
        .filter(pta -> pta.getAssignmentMode() == PackageAssignmentMode.M)
        .map(PackageTemplateAssignmentUserGroup::getTemplateAssignmentId)
        .collect(Collectors.toList());

    List<Long> includeId2 = ptars.values()
        .stream()
        .filter(pta -> pta.getAssignmentMode() == PackageAssignmentMode.M)
        .map(PackageTemplateAssignmentResource::getTemplateAssignmentId)
        .collect(Collectors.toList());

    includeId1.addAll(includeId2);

    return includeId1.stream().allMatch(id -> inputMap.get(id.intValue()));
  }

  public List<FeaturePackageAssignmentResource> getFeaturePackageAssignmentResources(Integer featurePackageId, String resourceName) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("featurePackage.featurePackageId", Pair.of(EnumQueryCriteria.EQUALS, featurePackageId));
    fieldValueMap.put("packageTemplateAssignmentResource.assignmentType", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, PackageAssignmentType.S.name()));
    fieldValueMap.put("packageTemplateAssignmentResource.resource.name", Pair.of(EnumQueryCriteria.EQUALS, resourceName));
    Specification<FeaturePackageAssignmentResource> spec = new Specification<>(fieldValueMap);
    return featurePackageAssignmentResourceRepository.findAll(spec);
  }

  public List<FeaturePackageAssignmentResource> getFeaturePackageAssignmentResourceType(Integer featurePackageId, String resourceType) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("featurePackage.featurePackageId", Pair.of(EnumQueryCriteria.EQUALS, featurePackageId));
    fieldValueMap.put("packageTemplateAssignmentResource.assignmentType", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, PackageAssignmentType.S.name()));
    fieldValueMap.put("packageTemplateAssignmentResource.resource.type", Pair.of(EnumQueryCriteria.EQUALS, resourceType));
    Specification<FeaturePackageAssignmentResource> spec = new Specification<>(fieldValueMap);
    return featurePackageAssignmentResourceRepository.findAll(spec);
  }

  public boolean featurePackageHasResourceType(
      ca.bnc.wealth.common.userconfiguration.model.FeaturePackage featurePackage, String resourceType) {
    List<PackageTemplateAssignmentResource> ptars = new ArrayList<>();
    if(StringUtils.isNotBlank(featurePackage.getPackageName())) {
      ptars = packageTemplateServiceHelper.getPackageTemplateAssignmentResourceType(featurePackage.getPackageName(), resourceType);
    } else {
      ptars = packageTemplateServiceHelper.getPackageTemplateAssignmentResourceType(featurePackage.getPackageTemplateId(), resourceType);
    }

    Map<String, List<PackageTemplateAssignmentResource>> map = ptars.stream().collect(Collectors.groupingBy(ptar -> ptar.getResource().getName(), Collectors.toList()));

    return map.entrySet().stream().anyMatch(entry -> featurePackageHasResource(featurePackage, entry.getKey(), entry.getValue()));
  }

  public boolean featurePackageHasResource(
      ca.bnc.wealth.common.userconfiguration.model.FeaturePackage featurePackage, String resourceName, List<PackageTemplateAssignmentResource> ptars) {
    if(StringUtils.isNotBlank(featurePackage.getPackageName())) {
      if(ptars.size() == 1) {
        if(ptars.get(0).getAssignmentMode() == PackageAssignmentMode.M)
          return true;
        else
          return featurePackage.getFeatures() != null && featurePackage.getFeatures().contains(resourceName);
      } else if(ptars.size() == 2) {
        return featurePackage.getModuleOverrides() == null || !featurePackage.getModuleOverrides().contains(resourceName);
      }
    } else {
      if(ptars.size() == 1) {
        if(ptars.get(0).getAssignmentMode() == PackageAssignmentMode.M) {
          return true;
        } else
          return featurePackage.getAssignments() != null && featurePackage.getAssignments()
              .stream()
              .filter(a -> a.getAssignmentId() == ptars.get(0).getTemplateAssignmentId())
              .map(PackageTemplateAssignment::getSelected)
              .findFirst()
              .orElse(false);
      } else if(ptars.size() == 2) {
        List<Integer> ptarIds = ptars.stream()
            .map(PackageTemplateAssignmentResource::getTemplateAssignmentId)
            .mapToInt(Math::toIntExact)
            .boxed().toList();
        return Optional.ofNullable(featurePackage.getAssignments())
            .orElse(new ArrayList<>())
            .stream()
            .filter(a -> ptarIds.contains(a.getAssignmentId()))
            .filter(a -> !a.getSelected())
            .map(a -> !a.getSelected())
            .findFirst()
            .orElse(false);
      }
    }
    return false;
  }
}
