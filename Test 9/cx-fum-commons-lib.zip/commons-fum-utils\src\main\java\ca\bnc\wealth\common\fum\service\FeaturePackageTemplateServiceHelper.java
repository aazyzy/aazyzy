package ca.bnc.wealth.common.fum.service;

import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.fum.util.Constants;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentUserGroupRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class FeaturePackageTemplateServiceHelper {

  @Autowired
  private PackageTemplateAssignmentUserGroupRepository packageTemplateAssignmentUserGroupRepository;
  @Autowired
  private PackageTemplateAssignmentResourceRepository packageTemplateAssignmentResourceRepository;
  @Autowired
  private FeaturePackageAssignmentUserGroupRepository featurePackageAssignmentUserGroupRepository;
  @Autowired
  private FeaturePackageAssignmentResourceRepository featurePackageAssignmentResourceRepository;

  public JpaRepository getJpaRepositoryForPtAssignment(
      PackageAssignmentType assignmentType) {
    switch (assignmentType) {
      case G:
        return packageTemplateAssignmentUserGroupRepository;
      case S:
        return packageTemplateAssignmentResourceRepository;
    }
    throw new FumNotFoundException(Constants.NOT_FOUND_ERROR, "Unable to find the jpa repository");
  }

  public JpaSpecificationExecutor getJpaSpecificationExecutorForPtAssignment(
      PackageAssignmentType assignmentType) {
    switch (assignmentType) {
      case G:
        return packageTemplateAssignmentUserGroupRepository;
      case S:
        return packageTemplateAssignmentResourceRepository;
    }
    throw new FumNotFoundException(Constants.NOT_FOUND_ERROR, "Unable to find the jpa specification");
  }

  public JpaRepository getJpaRepositoryForFpAssignment(
      PackageAssignmentType assignmentType) {
    switch (assignmentType) {
      case G:
        return featurePackageAssignmentUserGroupRepository;
      case S:
        return featurePackageAssignmentResourceRepository;
    }
    throw new FumNotFoundException(Constants.NOT_FOUND_ERROR, "Unable to find the jpa repository");
  }

  public JpaSpecificationExecutor getJpaSpecificationExecutorForFpAssignment(
      PackageAssignmentType assignmentType) {
    switch (assignmentType) {
      case G:
        return featurePackageAssignmentUserGroupRepository;
      case S:
        return featurePackageAssignmentResourceRepository;
    }
    throw new FumNotFoundException(Constants.NOT_FOUND_ERROR, "Unable to find the jpa specification");
  }


}
