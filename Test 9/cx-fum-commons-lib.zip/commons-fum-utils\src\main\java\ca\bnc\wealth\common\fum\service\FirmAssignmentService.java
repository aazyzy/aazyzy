package ca.bnc.wealth.common.fum.service;

import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.fum.util.Constants;
import ca.bnc.wealth.common.jpa.entity.enums.FirmAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FirmAssignment;
import ca.bnc.wealth.common.jpa.entity.iam.FirmAssignmentFeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.FirmAssignmentRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignment;
import ca.bnc.wealth.common.jpa.repo.iam.FirmAssignmentFeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmAssignmentRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.DeleteSpecification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class FirmAssignmentService {

  @Autowired private FirmAssignmentServiceHelper firmAssignmentServiceHelper;

  @Autowired private FirmAssignmentRepository firmAssignmentRepository;

  @Autowired private FirmAssignmentRrCodeRangeRepository firmAssignmentRrCodeRangeRepository;

  @Autowired private FirmAssignmentFeaturePackageRepository firmAssignmentFeaturePackageRepository;

  @Autowired private UserServiceHelper userServiceHelper;

  @Autowired private RedisCacheOperationService redisCacheOperationService;

  @Transactional
  public FirmAssignment createFirmAssignment(
      int firmEntityId, int assignmentId, FirmAssignmentType firmAssignmentType) {
    FirmAssignment firmAssignment = new FirmAssignment();

    firmAssignment.setFirmEntityId(firmEntityId);
    firmAssignment.setAssigneeId(assignmentId);
    firmAssignment.setAssignmentType(firmAssignmentType);
    firmAssignment.setEffectiveDate(new Timestamp(System.currentTimeMillis()));
    firmAssignment.setExpiryDate(Timestamp.valueOf(Constants.EXPIRY_DATE));
    return firmAssignmentRepository.save(firmAssignment);
  }

  public void createFirmFeaturePackageAssignment(
      String firmId, Integer featurePackageId, String requestedBy) {
    firmAssignmentFeaturePackageRepository.setFirmFeaturePackageAssignment(
        firmId, featurePackageId, requestedBy);
    evictFirmUsersCache(firmId);
  }

  public void createFirmFeaturePackageAssignment(
      String firmId, Integer featurePackageId, String requestedBy, String systemClientId) {
    firmAssignmentFeaturePackageRepository.setFirmFeaturePackageAssignment(
        firmId, featurePackageId, requestedBy, systemClientId);
    evictFirmUsersCache(firmId);
  }

  private void evictFirmUsersCache(String firmId) {
    userServiceHelper
        .getFirmUsers(firmId, true)
        .forEach(
            uc -> {
              log.info(
                  "Deleting {} cache for nbin idp user: {}",
                  Constants.GET_RERSOURCE_CACHE_NAME,
                  uc.getIdpSubject());
              redisCacheOperationService.deleteCacheByCacheNameAndPattern(
                  Constants.GET_RERSOURCE_CACHE_NAME, uc.getIdpSubject());
            });
    userServiceHelper
        .getFirmUsers(firmId, false)
        .forEach(
            uc -> {
              log.info(
                  "Deleting {} cache for non nbin idp user: {}",
                  Constants.GET_RERSOURCE_CACHE_NAME,
                  uc.getIdpSubject());
              redisCacheOperationService.deleteCacheByCacheNameAndPattern(
                  Constants.GET_RERSOURCE_CACHE_NAME, uc.getIdpSubject());
            });
    redisCacheOperationService.deleteCacheByCacheNameAndPattern(Constants.GET_FIRM_CACHE, firmId);
  }

  @Transactional
  public void deleteFirmAssignment(int firmEntityId, FirmAssignmentType firmAssignmentType) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap1 = new HashMap<>();
    fieldValueMap1.put("firmEntityId", Pair.of(EnumQueryCriteria.EQUALS, firmEntityId));
    fieldValueMap1.put(
        Constants.ASSIGNMENT_TYPE,
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, firmAssignmentType.name()));

    Specification<FirmAssignment> spec1 = new Specification<>(fieldValueMap1);
    firmAssignmentRepository.delete(forDelete(spec1));
  }

  @Transactional
  public void deleteFirmAssignment(int firmEntityId) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap1 = new HashMap<>();
    fieldValueMap1.put("firmEntityId", Pair.of(EnumQueryCriteria.EQUALS, firmEntityId));

    Specification<FirmAssignment> spec1 = new Specification<>(fieldValueMap1);
    firmAssignmentRepository.delete(forDelete(spec1));
  }

  // Spring Data JPA 4 deletes by DeleteSpecification; Spring Data JPA 3 passed a null query here
  private static DeleteSpecification<FirmAssignment> forDelete(
      Specification<FirmAssignment> spec) {
    return (root, delete, criteriaBuilder) -> spec.toPredicate(root, null, criteriaBuilder);
  }

  @Transactional
  public void deleteFirmAssignment(
      String firmId, String firmAssignmentType, Integer assigneeId, String requestedBy) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("firm.firmId", Pair.of(EnumQueryCriteria.EQUALS, firmId));
    switch (firmAssignmentType) {
      case "R":
        fieldValueMap.put(
            "assignmentType",
            Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, FirmAssignmentType.R.name()));
        fieldValueMap.put(
            "iamRrCodeRange.rrCodeRangeId", Pair.of(EnumQueryCriteria.EQUALS, assigneeId));
        Specification<FirmAssignmentRrCodeRange> spec1 = new Specification<>(fieldValueMap);
        List<FirmAssignmentRrCodeRange> firmAssignmentRrCodeRanges =
            firmAssignmentRrCodeRangeRepository.findAll(spec1);
        firmAssignmentRrCodeRangeRepository.deleteAll(firmAssignmentRrCodeRanges);
        break;
      case "P":
        fieldValueMap.put(
            "assignmentType",
            Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, FirmAssignmentType.P.name()));
        fieldValueMap.put(
            "featurePackage.featurePackageId", Pair.of(EnumQueryCriteria.EQUALS, assigneeId));
        Specification<FirmAssignmentFeaturePackage> spec2 = new Specification<>(fieldValueMap);
        List<FirmAssignmentFeaturePackage> firmAssignmentFeaturePackages =
            firmAssignmentFeaturePackageRepository.findAll(spec2);
        firmAssignmentFeaturePackageRepository.deleteAll(firmAssignmentFeaturePackages);
        break;
      default:
        throw new FumNotFoundException(
            Constants.NOT_FOUND_ERROR, "Not supported assignment type: " + firmAssignmentType);
    }
    redisCacheOperationService.deleteCacheByCacheNameAndPattern(Constants.GET_FIRM_CACHE, firmId);
  }

  public boolean hasFirmAssignment(Integer assigneeId, FirmAssignmentType firmAssignmentType) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(
        "assignmentType", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, firmAssignmentType.name()));
    fieldValueMap.put("assigneeId", Pair.of(EnumQueryCriteria.EQUALS, assigneeId));
    Specification<UserAssignment> spec = new Specification<>(fieldValueMap);
    return firmAssignmentRepository.count(new Specification<>(fieldValueMap)) > 0;
  }
}