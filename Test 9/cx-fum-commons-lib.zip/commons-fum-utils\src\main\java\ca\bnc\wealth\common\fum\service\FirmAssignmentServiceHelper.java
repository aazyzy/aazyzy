package ca.bnc.wealth.common.fum.service;

import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.fum.util.Constants;
import ca.bnc.wealth.common.jpa.entity.enums.FirmAssignmentType;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmAssignmentFeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmAssignmentRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class FirmAssignmentServiceHelper {

  @Autowired
  private FirmAssignmentRrCodeRangeRepository firmAssignmentRrCodeRangeRepository;
  @Autowired
  private FirmAssignmentFeaturePackageRepository firmAssignmentFeaturePackageRepository;
  @Autowired
  private IamRrCodeRangeRepository rrCodeRangeRepository;
  @Autowired
  private FeaturePackageRepository featurePackageRepository;


  public JpaRepository getJpaRepository(
      FirmAssignmentType assignmentType) {
    switch (assignmentType) {
      case R:
        return firmAssignmentRrCodeRangeRepository;
      case P:
        return firmAssignmentFeaturePackageRepository;
    }
    throw new FumNotFoundException(Constants.NOT_FOUND_ERROR, "Unable to find the jpa specification");
  }

  public JpaSpecificationExecutor getJpaSpecificationRepository(
      FirmAssignmentType assignmentType) {
    switch (assignmentType) {
      case R:
        return firmAssignmentRrCodeRangeRepository;
      case P:
        return firmAssignmentFeaturePackageRepository;
    }
    throw new FumNotFoundException(Constants.NOT_FOUND_ERROR, "Unable to find the jpa specification");
  }

  public JpaSpecificationExecutor getFirmAssignmentTypeJpaSpecificationRepository(
      FirmAssignmentType assignmentType) {
    switch (assignmentType) {
      case R:
        return rrCodeRangeRepository;
      case P:
        return featurePackageRepository;
    }
    throw new FumNotFoundException(Constants.NOT_FOUND_ERROR, "Unable to find the firm assignment jpa specification");
  }
}
