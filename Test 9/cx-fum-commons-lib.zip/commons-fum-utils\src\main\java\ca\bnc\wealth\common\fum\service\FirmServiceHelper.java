package ca.bnc.wealth.common.fum.service;

import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.model.FirmPreferencesEnum;
import ca.bnc.wealth.common.fum.model.FirmStateEnum;
import ca.bnc.wealth.common.fum.util.Constants;
import ca.bnc.wealth.common.jpa.entity.enums.FirmAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.FinancialEntity;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.repo.iam.FinancialEntityRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class FirmServiceHelper {

  @Autowired
  FirmRepository firmRepository;

  @Autowired
  private RrCodeServiceHelper rrCodeServiceHelper;
  @Autowired
  private FirmStateService firmStateService;
  @Autowired
  private FinancialEntityRepository financialEntityRepository;
  @Autowired
  private FirmAssignmentService firmAssignmentService;
  @Autowired
  private FeaturePackageServiceHelper featurePackageServiceHelper;
  @Autowired
  private UserAssignmentService userAssignmentService;
  @Autowired
  private UserServiceHelper userServiceHelper;
  @Qualifier("postgresJdbcTemplate")
  @Autowired
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
  @Autowired
  private RedisCacheOperationService redisCacheOperationService;


  public List<Map<String, Object>> getPrimaryFirmByIdpSubjectUsingJdbc(
      String idpUserSubject, boolean active) {
    SqlParameterSource parameters = new MapSqlParameterSource()
        .addValue("idpSubject", idpUserSubject)
        .addValue("assignmentType", UserAssignmentType.F.name())
        .addValue("active", true);
    return namedParameterJdbcTemplate.queryForList(Constants.GET_FIRMS_BY_IDP_SUBJECT_QUERY,
                parameters);
  }

  public Optional<Firm> getPrimaryFirm(String idpUserSubject, Boolean activeFirm) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(
        "userAssignmentFirms.userConfiguration.idpSubject",
        Pair.of(EnumQueryCriteria.EQUALS, idpUserSubject));
    fieldValueMap.put(
        "userAssignmentFirms.assignmentType",
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.F.name()));
    if(activeFirm != null) {
      fieldValueMap.put("active", Pair.of(EnumQueryCriteria.EQUALS, activeFirm));
    }
    Specification<Firm> spec = new Specification<>(fieldValueMap);

    return this.firmRepository.findOne(spec);
  }

  public Map<String, Object> getFirmByFirmId(String idpUserSubject, String firmId, Boolean isHierarchy) {
    SqlParameterSource firmParameters = new MapSqlParameterSource()
        .addValue(Constants.IDP_SUBJECT, idpUserSubject)
        .addValue(Constants.FIRM_ID, firmId);
    Map<String,Object> map;
    try {
      return namedParameterJdbcTemplate.queryForMap(getFirmQuery(isHierarchy),
          firmParameters);
    } catch(EmptyResultDataAccessException e) {
      throw new FumNotFoundException(Constants.FIRM_NOT_ASSIGNED_TO_USER_CODE,
          String.format(Constants.FIRM_NOT_ASSIGNED_TO_USER_MESSAGE, firmId));
    }
  }

  public void updateFirmStatusPreferences(String firmId, String status, Map<String, String> firmPreferences, String requestedBy) {
    Firm firm = firmRepository.findByFirmId(firmId);
    validateIfFirmNotExistOrDecommissioned(firm, firmId);
    if (Constants.FIRM_STATUS_ACTIVE.equalsIgnoreCase(status)) {
      rrCodeServiceHelper.setRRCodeRangeStatus(firm.getFirmId(), true);
      firmStateService.setActive(firm, requestedBy);
    } else if (Constants.FIRM_STATUS_INACTIVE.equalsIgnoreCase(status)) {
      rrCodeServiceHelper.setRRCodeRangeStatus(firm.getFirmId(), false);
      firmStateService.setInactive(firm, requestedBy);
    }

    setFirmPreferences(firm, firmPreferences);

    firmRepository.save(firm);
    redisCacheOperationService.deleteCacheByCacheNameAndPattern(Constants.GET_FIRM_CACHE, firmId);
    userServiceHelper.refreshUserSearchMaterializedView(false);
    clearUserCache(firmId);
  }

  public Firm createFirm(Firm firm, FinancialEntity financialEntity, String parentFirmId, List<Pair<String, String>> rrCodes, Integer packageTemplateId,  List<Pair<Integer, Boolean>> assignmentSelectionPairList, String requestedBy) {
    firmStateService.setStateOnCreate(firm);

    createFinancialEntityIfNotExist(financialEntity).ifPresent(firm::setFinancialEntity);

    Optional.ofNullable(parentFirmId).ifPresent(p -> setParentFirm(p, firm));

    Firm createdFirm = firmRepository.save(firm);

    setRRCodeRangeToFirm(createdFirm, rrCodes);

    setFeaturePackageToFirm(createdFirm, packageTemplateId, assignmentSelectionPairList, requestedBy);

    return createdFirm;
  }

  public Firm updateFirm(Firm firm, FinancialEntity financialEntity, List<Pair<String, String>> rrCodes, Integer packageTemplateId,  List<Pair<Integer, Boolean>> assignmentSelectionPairList, String requestedBy) {
    firmStateService.saveStateOnUpdate(firm.getFirmId());

    createFinancialEntityIfNotExist(financialEntity).ifPresent(firm::setFinancialEntity);

    Firm updatedFirm = firmRepository.save(firm);

    boolean hasRrCodeChange = hasRrCodeChange(firm.getFirmId(),rrCodes);
    if(hasRrCodeChange) {
      firmAssignmentService.deleteFirmAssignment(updatedFirm.getFirmEntityId().intValue(), FirmAssignmentType.R);
      setRRCodeRangeToFirm(updatedFirm, rrCodes);
      // Flush to ensure new FIRM_ASSIGNMENT rows are visible to subsequent
      // queries that read through a different entity type (FirmAssignmentRrCodeRange)
      // mapped to the same table. Without this, Hibernate's auto-flush may not
      // detect the overlap and refreshUserRrCode would see zero firm ranges.
      firmRepository.flush();
    }

    boolean currentFirmLevelAccess = userAssignmentService.hasFirmLevelAccessResourceToFirm(firm.getFirmId());
    setFeaturePackageToFirm(updatedFirm, packageTemplateId, assignmentSelectionPairList, requestedBy);
    boolean updatedFirmLevelAccess = userAssignmentService.hasFirmLevelAccessResourceToFirm(firm.getFirmId());

    if(hasRrCodeChange || currentFirmLevelAccess ^ updatedFirmLevelAccess) {
      userAssignmentService.refreshUserRrCode(updatedFirm.getFirmId(), requestedBy);
    }

    redisCacheOperationService.deleteCacheByCacheNameAndPattern(Constants.GET_FIRM_CACHE, firm.getFirmId());
    return updatedFirm;
  }

  public Optional<FinancialEntity> createFinancialEntityIfNotExist(FinancialEntity financialEntity) {
    if (!isFinancialEntityInfoExist(financialEntity)) {
      return Optional.empty();
    }

    FinancialEntity existingFinancialEntity =
        financialEntityRepository.findByBrokerCodeAndBranchNumberAndDealerCode(
            financialEntity.getBrokerCode(), financialEntity.getBranchNumber(), financialEntity.getDealerCode());

    if (existingFinancialEntity != null) {
      return Optional.of(existingFinancialEntity);
    } else {
      return Optional.of(financialEntityRepository.save(financialEntity));
    }
  }

  boolean isFinancialEntityInfoExist(FinancialEntity financialEntity) {
    return financialEntity.getBrokerCode() != null || financialEntity.getBranchNumber() != null ||
        financialEntity.getDealerCode() != null || financialEntity.getLegalEntityIdentifier() != null;
  }

  @Transactional
  public void decommissionFirm(String firmId) {
    Firm firm = firmRepository.findByFirmId(firmId);
    validateIfFirmNotExistOrDecommissioned(firm, firmId);
    validateIfFirmActive(firm);
    firmAssignmentService.deleteFirmAssignment(firm.getFirmEntityId().intValue());
    firmStateService.setDecommission(firm);
    firmRepository.save(firm);
    redisCacheOperationService.deleteCacheByCacheNameAndPattern(Constants.GET_FIRM_CACHE, firmId);
  }

  protected void setRRCodeRangeToFirm(Firm firm, List<Pair<String, String>> rrCodes) {
    if(rrCodes == null || rrCodes.size() == 0)
      return;

    Set<String> lst = rrCodes.stream().map(pair -> pair.getLeft() + "-" + pair.getRight()).collect(Collectors.toSet());
    lst.forEach(rr -> {
      String[] range = rr.split("-");
      String fromRrCode = range[0];
      String toRrCode = range[1];
      IamRrCodeRange iamRrCodeRange = rrCodeServiceHelper.createRrCodeEntityIfNotExist(fromRrCode, toRrCode);
      log.info("Updateing Firm {} assignment with RR Code Id {}, Range {} to {}", firm.getFirmId(),iamRrCodeRange.getRrCodeRangeId(), fromRrCode, toRrCode);
      firmAssignmentService.createFirmAssignment(firm.getFirmEntityId().intValue(),(int) iamRrCodeRange.getRrCodeRangeId(), FirmAssignmentType.R);
    });
  }

  private void setFeaturePackageToFirm(Firm firm, Integer packageTemplateId, List<Pair<Integer, Boolean>> assignmentSelectionPairList, String requestedBy) {
    if( packageTemplateId != null) {
      FeaturePackage featurePackage = featurePackageServiceHelper.createFeaturePackage(packageTemplateId, assignmentSelectionPairList, requestedBy);
      firmAssignmentService.deleteFirmAssignment(firm.getFirmEntityId().intValue(), FirmAssignmentType.P);
      firmAssignmentService.createFirmAssignment(firm.getFirmEntityId().intValue(), (int)featurePackage.getFeaturePackageId(), FirmAssignmentType.P);
    }
  }

  private Firm setParentFirm(String parentFirmId, Firm firm) {
    Firm parentFirm = firmRepository.findByFirmId(parentFirmId);
    validateIfFirmNotExistOrDecommissioned(parentFirm, parentFirmId);
    firm.setParentFirm(parentFirm);
    return parentFirm;
  }

  public void validateIfFirmNotExistOrDecommissioned(Firm firm, String firmId) {
    if (firm == null || FirmStateEnum.DECOMMISSIONED.labelEquals(firm.getState())) {
      throw new FumNotFoundException(Constants.FIRM_NOT_FOUND_CODE,
          String.format(Constants.FIRM_NOT_FOUND_MESSAGE, firmId));
    }
  }

  public void validateIfFirmActive(Firm firm) {
    if (firm.getActive() || !Constants.FIRM_STATUS_INACTIVE.equalsIgnoreCase(firm.getState())) {
      throw new FumValidationException(Constants.FIRM_NOT_INACTIVE_CODE, Constants.FIRM_NOT_INACTIVE_MESSAGE);
    }
  }

  private String getFirmQuery(Boolean isWithHierarchy) {
    if(isWithHierarchy) {
      return String.format(Constants.FIRM_QUERY, Constants.FIRM_QUERY_CHILD_FIRM, Constants.FIRM_QUERY_JOIN, Constants.FIRM_QUERY_GROUP_BY);
    }
    return String.format(Constants.FIRM_QUERY, "", "", "");
  }

  public void setFirmPreferences(Firm firmEntity, Map<String,String> firmPreferences) {
    Optional.ofNullable(firmPreferences)
        .ifPresentOrElse((map) -> {
          map.forEach((key, value) -> {
            if (!EnumUtils.isValidEnum(FirmPreferencesEnum.class, key)) {
              throw new FumValidationException("error.firmPreference.invalid", "Not a valid firm preference key");
            }
          });
          firmEntity.setFirmPreferences(map);
        },() -> firmEntity.setFirmPreferences(null));
  }

  public boolean hasRrCodeChange(String firmId, List<Pair<String, String>> rrCodes) {
    Set<String> newRrCodes = rrCodes.stream().map(r -> r.getLeft() + "-" + r.getRight()).collect(Collectors.toSet());
    return hasRrCodeChange(firmId, newRrCodes);
  }

  public boolean hasRrCodeChange(String firmId, Set<String> newRrCodes) {
    Set<String> currentRrCodes = rrCodeServiceHelper.getFirmRrCodeRange(firmId)
        .stream()
        .map(r -> r.getFromRrCode() + "-" + r.getToRrCode())
        .collect(Collectors.toSet());


    log.info("Current RRCodes: {}, New RRCodes: {}", currentRrCodes, newRrCodes);

    if(currentRrCodes.size() != newRrCodes.size()) {
      return true;
    } else {
      return !currentRrCodes.containsAll(newRrCodes);
    }
  }

  private void clearUserCache(String firmId) {
    userServiceHelper.getFirmUsers(firmId,null).forEach(user -> {
      redisCacheOperationService.deleteUserConfigurationCache(user.getIdpSubject(), user.getUserConfigurationId().intValue(), user.getIdpUserIdentifier());
    });
  }
}
