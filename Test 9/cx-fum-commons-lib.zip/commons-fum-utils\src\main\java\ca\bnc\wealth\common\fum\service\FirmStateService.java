package ca.bnc.wealth.common.fum.service;

import ca.bnc.wealth.common.fum.model.FirmStateEnum;
import ca.bnc.wealth.common.jpa.entity.enums.FirmAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.FirmAssignment;
import ca.bnc.wealth.common.jpa.repo.iam.FirmAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class FirmStateService {

  @Autowired
  private FirmRepository firmRepository;

  @Autowired
  private FirmAssignmentRepository firmAssignmentRepository;

  public void setStateOnCreate(Firm firm) {
    firm.setActive(false);
    firm.setState(FirmStateEnum.ONBOARDED.label);
  }

  public void saveStateOnUpdate(String firmId) {
    Optional.ofNullable(firmRepository.findByFirmId(firmId))
        .ifPresent(firm -> {
          if (FirmStateEnum.ONBOARDED.labelEquals(firm.getState()) && hasFeaturePackage(firm)) {
            firm.setActive(true);
            firm.setState(FirmStateEnum.ACTIVE.label);
            firm.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
            firmRepository.save(firm);
          }
        });
  }

  public void setActive(Firm firm, String requestedBy) {
    if (!firm.getActive()) {
      firm.setActive(true);
      firm.setState(FirmStateEnum.ACTIVE.label);
      firm.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
      firm.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
      firm.setLastUpdatedBy(requestedBy);
    }
  }

  public void setInactive(Firm firm, String requestedBy) {
    if (firm.getActive()) {
      firm.setActive(false);
      firm.setState(FirmStateEnum.INACTIVE.label);
      firm.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
      firm.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
      firm.setLastUpdatedBy(requestedBy);
    }
  }

  public void setDecommission(Firm firm) {
    firm.setActive(false);
    firm.setState(FirmStateEnum.DECOMMISSIONED.label);
    firm.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  private boolean hasFeaturePackage(Firm firm) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();

    fieldValueMap.put("firmEntityId", Pair.of(EnumQueryCriteria.EQUALS, firm.getFirmEntityId()));
    fieldValueMap.put("assignmentType", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, FirmAssignmentType.P.name()));
    Specification<FirmAssignment> spec = new Specification<>(fieldValueMap);
    return firmAssignmentRepository.count(spec) > 0;
  }
}
