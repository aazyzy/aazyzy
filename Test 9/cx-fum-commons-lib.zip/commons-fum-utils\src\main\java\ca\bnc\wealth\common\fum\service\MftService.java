package ca.bnc.wealth.common.fum.service;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;
import java.util.Vector;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class MftService {

    @Value("${mft.6900.hostname}")
    private String mftHostname;
    @Value("${mft.6900.username}")
    private String mftUserName;
    @Value("${mft.6900.password}")
    private String mftPassword;
    @Value("${mft.6900.port:22}")
    private int mftPort;


    public void sendFile(String fileName, String fileContent, String destinationDir) {
        sendFile(fileName, new ByteArrayInputStream(fileContent.getBytes(StandardCharsets.UTF_8)), destinationDir);
    }

    @SneakyThrows
    public void sendFile(String fileName, ByteArrayInputStream byteArrayInputStream, String destinationDir) {
        log.info("Sending file {} to {}", fileName, destinationDir);
        Session session = getJschSession();
        ChannelSftp sftp = null;
        try {
            session.connect();
            sftp = (ChannelSftp) session.openChannel("sftp");
            sftp.connect();
            sftp.put(byteArrayInputStream ,  destinationDir + "/" + fileName);
        } finally {
            Optional.ofNullable(sftp).ifPresent(ChannelSftp::disconnect);
            Optional.ofNullable(session).ifPresent(Session::disconnect);
        }
    }

    @SneakyThrows
    public InputStream getFile(String fileName, String destinationDir) {
        log.info("Getting file {} from {}", fileName, destinationDir);
        Session session = getJschSession();
        ChannelSftp sftp = null;
        try {
            session.connect();
            sftp = (ChannelSftp) session.openChannel("sftp");
            sftp.connect();
            return sftp.get(destinationDir + "/" + fileName);
        } finally {
            Optional.ofNullable(sftp).ifPresent(ChannelSftp::disconnect);
            Optional.ofNullable(session).ifPresent(Session::disconnect);
        }
    }

    @SneakyThrows
    public List<String> getFiles(String destinationDir) {
        log.info("Getting files from {}", destinationDir);
        Session session = getJschSession();
        ChannelSftp sftp = null;
        try {
            session.connect();
            sftp = (ChannelSftp) session.openChannel("sftp");
            sftp.connect();
            Vector<LsEntry> v =  sftp.ls(destinationDir);
            return v.stream().map(LsEntry::getFilename).collect(Collectors.toList());
        } finally {
            Optional.ofNullable(sftp).ifPresent(ChannelSftp::disconnect);
            Optional.ofNullable(session).ifPresent(Session::disconnect);
        }
    }
    @SneakyThrows
    private Session getJschSession() {
        log.info("Creating JSch session with {}@{}", mftUserName, mftHostname);
        JSch jsch = new JSch();
        Session session = jsch.getSession(mftUserName, mftHostname, mftPort);
        session.setPassword(mftPassword);
        session.setConfig("StrictHostKeyChecking", "no");
        return session;
    }

}
