package ca.bnc.wealth.common.fum.service;

import ca.bnc.wealth.common.exception.Entity.FumConflictException;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.util.Constants;
import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserGroupRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.lang3.tuple.Triple;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
@RequiredArgsConstructor
public class PackageTemplateServiceHelper {

  @Autowired
  private FeaturePackageTemplateServiceHelper featurePackageTemplateServiceHelper;

  @Autowired
  private PackageTemplateRepository packageTemplateRepository;

  @Autowired
  private UserGroupRepository userGroupRepository;

  @Autowired
  private ResourceRepository resourceRepository;

  @Autowired
  private PackageTemplateAssignmentUserGroupRepository packageTemplateAssignmentUserGroupRepository;

  @Autowired
  private PackageTemplateAssignmentResourceRepository packageTemplateAssignmentResourceRepository;

  @Autowired
  private FeaturePackageRepository featurePackageRepository;

  public PackageTemplate getPackageTemplate(long  packageTemplateId) {
    return packageTemplateRepository.findById(packageTemplateId)
        .orElseThrow(
            () -> new FumNotFoundException(Constants.PACKAGE_TEMPLATE_NOT_FOUND_CODE,
                String.format(Constants.PACKAGE_TEMPLATE_NOT_FOUND_MESSAGE,
                    packageTemplateId)));
  }

  public <T extends EntityInterface> Map<Long, T > getPackageTemplateAssignment(
      Long packageTemplateId, PackageAssignmentType packageAssignmentType) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("packageTemplate.packageTemplateId",
        Pair.of(EnumQueryCriteria.EQUALS, packageTemplateId));
    fieldValueMap.put("assignmentType",
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, packageAssignmentType.name()));
    Specification<T> spec = new Specification<>(fieldValueMap);
    JpaSpecificationExecutor jpaSpecificationExecutor = featurePackageTemplateServiceHelper.getJpaSpecificationExecutorForPtAssignment(packageAssignmentType);
    List<T> lst = jpaSpecificationExecutor.findAll(spec);
    return  lst.stream()
        .collect(
            Collectors.toMap(EntityInterface::getId, x -> x));
  }

  @Transactional
  public void deletePackageTemplate(String templateName) {
    PackageTemplate packageTemplate = packageTemplateRepository.findByName(templateName)
        .orElseThrow(() -> new FumValidationException(
            Constants.TEMPLATE_DOES_NOT_EXIST_CODE,
            String.format(Constants.TEMPLATE_DOES_NOT_EXIST_MESSAGE, templateName)));

    if(hasFeaturePackages(packageTemplate.getPackageTemplateId())) {
      throw new FumConflictException(Constants.CAN_NOT_DELETE_TEMPLATE_CODE, String.format(Constants.CAN_NOT_DELETE_TEMPLATE_MESSAGE, templateName));
    }

    JpaRepository repository = featurePackageTemplateServiceHelper.getJpaRepositoryForPtAssignment(PackageAssignmentType.G);
    repository.deleteAll(getPackageTemplateAssignment(packageTemplate.getPackageTemplateId(), PackageAssignmentType.G).values());

    repository = featurePackageTemplateServiceHelper.getJpaRepositoryForPtAssignment(PackageAssignmentType.S);
    repository.deleteAll(getPackageTemplateAssignment(packageTemplate.getPackageTemplateId(), PackageAssignmentType.S).values());

    packageTemplateRepository.delete(packageTemplate);
  }

  @Transactional
  public PackageTemplate createPackageTemplate(PackageTemplate packageTemplate, List<String> userGroup,  List<Pair<Pair<String, Boolean>, Pair<PackageAssignmentMode, Boolean>>> resources) {
    PackageTemplate createdPackageTemplate = packageTemplateRepository.save(packageTemplate);
    assigneUserGroup(createdPackageTemplate, userGroup);
    assigneResources(createdPackageTemplate, resources);
    return createdPackageTemplate;
  }

  private void assigneUserGroup(PackageTemplate packageTemplate, List<String> userGroups) {
    userGroups.stream()
        .map(ug -> Pair.of(ug,userGroupRepository.findFirstByName(ug)))
        .map(p -> p.getValue().orElseThrow(() ->new FumValidationException(Constants.USER_GROUP_NOT_EXIST_CODE, String.format(Constants.USER_GROUP_NOT_EXIST_MESSAGE, p.getKey()))))
        .forEach(ug -> {
          PackageTemplateAssignmentUserGroup templateDetails = new PackageTemplateAssignmentUserGroup();
          templateDetails.setUserGroup(ug);
          templateDetails.setPackageTemplate(packageTemplate);
          templateDetails.setAssignmentType(PackageAssignmentType.G);
          templateDetails.setAssignmentMode(PackageAssignmentMode.M);
          templateDetails.setSelectionDefault(true);
          packageTemplateAssignmentUserGroupRepository.save(templateDetails);
        });
  }

  private void assigneResources(PackageTemplate packageTemplate,  List<Pair<Pair<String, Boolean>, Pair<PackageAssignmentMode, Boolean>>> resources) {
    resources.stream()
        .map(pair -> {
          Resource resource = resourceRepository.findFirstByNameAndRestriction(pair.getLeft().getLeft(), pair.getLeft().getRight())
              .orElseThrow(() -> new FumValidationException(Constants.RESOURCE_TYPE_NOT_EXIST_CODE, String.format(Constants.RESOURCE_TYPE_NOT_EXIST_MESSAGE, pair.getLeft())));
          return Triple.of(resource, pair.getRight().getLeft(), pair.getRight().getRight());
        })
        .forEach(triple -> {
          PackageTemplateAssignmentResource templateDetails = new PackageTemplateAssignmentResource();
          templateDetails.setResource(triple.getLeft());
          templateDetails.setPackageTemplate(packageTemplate);
          templateDetails.setAssignmentType(PackageAssignmentType.S);
          templateDetails.setAssignmentMode(triple.getMiddle());
          templateDetails.setSelectionDefault(triple.getRight());
          packageTemplateAssignmentResourceRepository.save(templateDetails);
        });
  }

  private boolean hasFeaturePackages(long packageTemplateId) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("packageTemplate.packageTemplateId",
        Pair.of(EnumQueryCriteria.EQUALS, packageTemplateId));
    Specification<FeaturePackage> spec = new Specification<>(fieldValueMap);
    return featurePackageRepository.count(spec) > 0;
  }

  public List<PackageTemplateAssignmentResource> getPackageTemplateAssignmentResource(String packageTemplateName, String resourceName) {
    PackageTemplate packageTemplate = packageTemplateRepository.findByName(packageTemplateName)
        .orElseThrow(() -> new FumValidationException(
            Constants.TEMPLATE_DOES_NOT_EXIST_CODE,
            String.format(Constants.TEMPLATE_DOES_NOT_EXIST_MESSAGE, packageTemplateName)));
    return getPackageTemplateAssignmentResource(packageTemplate.getPackageTemplateId(), resourceName);
  }

  public List<PackageTemplateAssignmentResource> getPackageTemplateAssignmentResource(long packageTemplateId, String resourceName) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("packageTemplate.packageTemplateId", Pair.of(EnumQueryCriteria.EQUALS, packageTemplateId));
    fieldValueMap.put("assignmentType", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, PackageAssignmentType.S.name()));
    fieldValueMap.put("resource.name", Pair.of(EnumQueryCriteria.EQUALS, resourceName));
    Specification<PackageTemplateAssignmentResource> spec = new Specification<>(fieldValueMap);
    return packageTemplateAssignmentResourceRepository.findAll(spec);
  }

  public List<PackageTemplateAssignmentResource> getPackageTemplateAssignmentResourceType(String packageTemplateName, String resourceType) {
    PackageTemplate packageTemplate = packageTemplateRepository.findByName(packageTemplateName)
        .orElseThrow(() -> new FumValidationException(
            Constants.TEMPLATE_DOES_NOT_EXIST_CODE,
            String.format(Constants.TEMPLATE_DOES_NOT_EXIST_MESSAGE, packageTemplateName)));
    return getPackageTemplateAssignmentResourceType(packageTemplate.getPackageTemplateId(), resourceType);
  }

  public List<PackageTemplateAssignmentResource> getPackageTemplateAssignmentResourceType(long packageTemplateId, String resourceType) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("packageTemplate.packageTemplateId", Pair.of(EnumQueryCriteria.EQUALS, packageTemplateId));
    fieldValueMap.put("assignmentType", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, PackageAssignmentType.S.name()));
    fieldValueMap.put("resource.type", Pair.of(EnumQueryCriteria.EQUALS, resourceType));
    Specification<PackageTemplateAssignmentResource> spec = new Specification<>(fieldValueMap);
    return packageTemplateAssignmentResourceRepository.findAll(spec);
  }
}
