package ca.bnc.wealth.common.fum.service;

import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class RedisCacheOperationService {

  @Autowired
  @Qualifier("redisCacheManager")
  private CacheManager cacheManager;

  @Value("${redis.cache.enable:false}")
  private boolean enableCache;

  @Autowired RedisTemplate redisTemplate;

  private static final List<String> userConfigCache =
      Arrays.asList(
          "UserConfiguration-Enrich",
          "UserConfiguration-UsersMe",
          "UserConfiguration-UsersId",
          "UserConfiguration-CompassR2Id",
          "UserConfiguration-SecurityZoneId",
          "UserConfiguration-IdpSubject");

  @Caching(
      evict = {
        @CacheEvict(
            value = "UserConfiguration-Enrich",
            key = "#userConfiguration.idpSubject",
            cacheManager = "redisCacheManager",
            condition = "#root.getTarget().redisCacheEnabled()"),
        @CacheEvict(
            value = "UserConfiguration-UsersMe",
            key = "#userConfiguration.idpSubject",
            cacheManager = "redisCacheManager",
            condition = "#root.getTarget().redisCacheEnabled()"),
        @CacheEvict(
            value = "UserConfiguration-UsersId",
            key = "#userConfiguration.userConfigurationId",
            cacheManager = "redisCacheManager",
            condition = "#root.getTarget().redisCacheEnabled()"),
        @CacheEvict(
            value = "UserConfiguration-IdpSubject",
            key = "#userConfiguration.idpSubject",
            cacheManager = "redisCacheManager",
            condition = "#root.getTarget().redisCacheEnabled()"),
        @CacheEvict(
            value = "UserConfiguration-CompassR2Id",
            key = "#userConfiguration.idpSubject",
            cacheManager = "redisCacheManager",
            condition = "#root.getTarget().redisCacheEnabled()"),
        @CacheEvict(
            value = "UserConfiguration-SecurityZoneId",
            key = "#userConfiguration.idpUserId",
            cacheManager = "redisCacheManager",
            condition = "#userConfiguration.idpUserId != null && #root.getTarget().redisCacheEnabled()")
      })
  public void deleteUserConfigurationCache(UserConfiguration userConfiguration) {}

  @Caching(
      evict = {
        @CacheEvict(
            value = "UserConfiguration-Enrich",
            key = "#idpSubject",
            cacheManager = "redisCacheManager",
            condition = "#root.getTarget().redisCacheEnabled()"),
        @CacheEvict(
            value = "UserConfiguration-UsersMe",
            key = "#idpSubject",
            cacheManager = "redisCacheManager",
            condition = "#root.getTarget().redisCacheEnabled()"),
        @CacheEvict(
            value = "UserConfiguration-UsersId",
            key = "#userConfigurationId",
            cacheManager = "redisCacheManager",
            condition = "#root.getTarget().redisCacheEnabled()"),
        @CacheEvict(
            value = "UserConfiguration-IdpSubject",
            key = "#idpSubject",
            cacheManager = "redisCacheManager",
            condition = "#root.getTarget().redisCacheEnabled()"),
        @CacheEvict(
            value = "UserConfiguration-CompassR2Id",
            key = "#idpSubject",
            cacheManager = "redisCacheManager",
            condition = "#root.getTarget().redisCacheEnabled()"),
        @CacheEvict(
            value = "UserConfiguration-SecurityZoneId",
            key = "#idpUserId",
            cacheManager = "redisCacheManager",
            condition = "#idpUserId != null && #root.getTarget().redisCacheEnabled()")
      })
  public void deleteUserConfigurationCache(
      String idpSubject, Integer userConfigurationId, String idpUserId) {}

  @Caching(
      evict = {
        @CacheEvict(
            value = "UserConfiguration-Enrich",
            key = "#idpSubject",
            cacheManager = "redisCacheManager",
            condition = "#root.getTarget().redisCacheEnabled()"),
        @CacheEvict(
            value = "UserConfiguration-UsersMe",
            key = "#idpSubject",
            cacheManager = "redisCacheManager",
            condition = "#root.getTarget().redisCacheEnabled()"),
        @CacheEvict(
            value = "UserConfiguration-UsersId",
            key = "#userConfigurationId",
            cacheManager = "redisCacheManager",
            condition = "#root.getTarget().redisCacheEnabled()"),
        @CacheEvict(
            value = "UserConfiguration-IdpSubject",
            key = "#idpSubject",
            cacheManager = "redisCacheManager",
            condition = "#root.getTarget().redisCacheEnabled()")
      })
  public void deleteUserConfigurationCacheEnrichUserMeUsersId(
      String idpSubject, Integer userConfigurationId) {}

  @Caching(
      evict = {
        @CacheEvict(
            value = "UserConfiguration-UsersId",
            key = "#userConfigurationId",
            cacheManager = "redisCacheManager",
            condition = "#root.getTarget().redisCacheEnabled()"),
        @CacheEvict(
            value = "UserConfiguration-IdpSubject",
            key = "#idpSubject",
            cacheManager = "redisCacheManager",
            condition = "#root.getTarget().redisCacheEnabled()")
      })
  public void deleteUserConfigurationWithRrCodeCache(
      String idpSubject, Integer userConfigurationId) {}

  public void deleteAllUserCache() {
    if (redisCacheEnabled()) {
      userConfigCache.stream()
          .filter(cacheName -> cacheManager.getCache(cacheName) != null)
          .forEach(name -> cacheManager.getCache(name).clear());
    }
  }

  public void deleteCacheByCacheName(String cacheName) {
    if (redisCacheEnabled()) {
      Cache cache = cacheManager.getCache(cacheName);
      if (cache != null) {
        cache.clear();
      }
    }
  }

  public void deleteCacheByCacheNameAndKey(String cacheName, Object key) {
    if (redisCacheEnabled()) {
      Cache cache = cacheManager.getCache(cacheName);
      if (cache != null) {
        if (cache.get(key) != null) {
          cache.evict(key);
        }
      }
    }
  }

  public void deleteCacheByCacheNameAndPattern(String cacheName, String keyPattern) {
    if (redisCacheEnabled()) {
      Cache cache = cacheManager.getCache(cacheName);
      if (cache != null) {
        Optional.ofNullable(redisTemplate.keys(cacheName + "*" + keyPattern + "*"))
            .ifPresent(redisTemplate::delete);
      }
    }
  }

  public void deleteCacheByPattern(String keyPattern) {
    if (redisCacheEnabled()) {
      Optional.ofNullable(redisTemplate.keys("*" + keyPattern + "*"))
          .ifPresent(redisTemplate::delete);
    }
  }

  public void addCache(String cacheName, Object key, Object value) {
    if (redisCacheEnabled()) {
      Cache cache = cacheManager.getCache(cacheName);
      if (cache != null) {
        cache.put(key, value);
      }
    }
  }

  public <T> Optional<T> getCacheByCacheNameAndKey(String cacheName, Object key, Class<T> t) {
    if (redisCacheEnabled()) {
      Cache cache = cacheManager.getCache(cacheName);
      if (cache != null) {
        return Optional.ofNullable(cache.get(key, t));
      }
    }
    return Optional.empty();
  }

  public boolean redisCacheEnabled() {
    return enableCache;
  }

  public void deleteUserConfigurationCacheNoException(UserConfiguration userConfiguration) {
    try {
      deleteUserConfigurationCache(userConfiguration);
    } catch (Exception e) {
      log.warn(
          "User not cached on redis yet. Unable to clear cache: {}",
          userConfiguration.getUsername());
    }
  }
}
