package ca.bnc.wealth.common.fum.service;

import ca.bnc.wealth.common.jpa.entity.enums.FirmAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ResourceServiceHelper {

  @Autowired
  private ResourceRepository resourceRepository;

  public List<Resource> getFirmResources(String firmId, boolean selected) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(
        "packageTemplateAssignmentResources.assignmentType",
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, PackageAssignmentType.S.name()));
    fieldValueMap.put(
        "packageTemplateAssignmentResources.featurePackageAssignmentResources.featurePackage.firmAssignmentFeaturePackages.assignmentType",
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, FirmAssignmentType.P.name()));
    fieldValueMap.put(
        "packageTemplateAssignmentResources.featurePackageAssignmentResources.featurePackage.firmAssignmentFeaturePackages.firm.firmId",
        Pair.of(EnumQueryCriteria.EQUALS, firmId));
    fieldValueMap.put(
        "packageTemplateAssignmentResources.featurePackageAssignmentResources.isSelected",
        Pair.of(EnumQueryCriteria.EQUALS, selected));

    Specification<Resource> spec = new Specification<>(fieldValueMap);
    return resourceRepository.findAll(spec);
  }

  public List<Resource> getUserResources(String idpSubject) {
    return getUserResources(idpSubject, true);
  }

  public List<Resource> getUserResources(String idpSubject, Boolean selected) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(
        "packageTemplateAssignmentResources.assignmentType",
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, PackageAssignmentType.S.name()));
    fieldValueMap.put(
        "packageTemplateAssignmentResources.featurePackageAssignmentResources.featurePackage.userAssignmentFeaturePackages.assignmentType",
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, FirmAssignmentType.P.name()));
    fieldValueMap.put(
        "packageTemplateAssignmentResources.featurePackageAssignmentResources.featurePackage.userAssignmentFeaturePackages.userConfiguration.idpSubject",
        Pair.of(EnumQueryCriteria.EQUALS, idpSubject));
    if (selected != null) {
      fieldValueMap.put(
          "packageTemplateAssignmentResources.featurePackageAssignmentResources.isSelected",
          Pair.of(EnumQueryCriteria.EQUALS, selected));
    }

    Specification<Resource> spec = new Specification<>(fieldValueMap);
    return resourceRepository.findAll(spec);
  }
}
