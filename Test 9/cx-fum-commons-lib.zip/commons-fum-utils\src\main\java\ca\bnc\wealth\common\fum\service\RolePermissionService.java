package ca.bnc.wealth.common.fum.service;

import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class RolePermissionService {
  @Qualifier("postgresJdbcTemplate")
  @Autowired
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  private static final String IDP_SUBJECT = "idpSubject";

  private static final String ROLE_QUERY = "select distinct \"ROLE\" as role from \"IAM_V2\".vw_user_group_role_permission_assignment vugrpa \n"
      + "where \"IDP_SUBJECT\" = :idpSubject and \"ROLE\" notnull; \n";

  private static final String PERMISSION_QUERY = "select distinct \"PERMISSION\" as permission from \"IAM_V2\".vw_user_group_role_permission_assignment vugrpa \n"
      + "where \"IDP_SUBJECT\" = :idpSubject and \"PERMISSION\" notnull;";

  public Optional<List<String>> getRoles(String idpSubject) {
    SqlParameterSource parameters = new MapSqlParameterSource().addValue(IDP_SUBJECT, idpSubject);
    List<String> roles = namedParameterJdbcTemplate.queryForList(ROLE_QUERY, parameters, String.class);

    return Optional.of(roles);
  }

  public Optional<List<String>> getPermissions(String idpSubject) {
    SqlParameterSource parameters = new MapSqlParameterSource().addValue(IDP_SUBJECT, idpSubject);
    List<String> permissions = namedParameterJdbcTemplate.queryForList(PERMISSION_QUERY, parameters, String.class);

    return Optional.of(permissions);
  }
}
