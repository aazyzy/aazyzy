package ca.bnc.wealth.common.fum.service;

import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.fum.util.Constants;
import ca.bnc.wealth.common.jpa.entity.enums.FirmAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
@Slf4j
public class RrCodeServiceHelper {

  @Autowired
  private IamRrCodeRangeRepository iamRrCodeRangeRepository;;

  @Qualifier("postgresJdbcTemplate")
  @Autowired
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  public List<IamRrCodeRange> getFirmRrCodeRange(String firmId) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(
        "firmAssignmentRrCodeRanges.assignmentType",
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.R.name()));
    fieldValueMap.put(
        "firmAssignmentRrCodeRanges.firm.firmId", Pair.of(EnumQueryCriteria.EQUALS, firmId));
    Specification<IamRrCodeRange> spec = new Specification<>(fieldValueMap);
    return iamRrCodeRangeRepository.findAll(spec);
  }

  public List<Map<String, Object>> getRRCodeListByFirmIdUsingJdbc(String firmId) {
    log.info("getRRCodeListByFirmId: firmId: {} ", firmId);

    SqlParameterSource parameters = new MapSqlParameterSource()
        .addValue("firmId", firmId)
        .addValue("assignmentType", FirmAssignmentType.R.name());

    List<Map<String, Object>> rrCodeRangeList = namedParameterJdbcTemplate.queryForList(
        Constants.GET_RR_CODES_BY_FIRM, parameters);
    log.info("RR Range list size {} for firmId: {}", rrCodeRangeList.size(), firmId);
    return rrCodeRangeList;
  }

  @Async("fumAsyncExecutor")
  public CompletableFuture<IamRrCodeRange> getRrRangeEntityAsync(String fromRrCode, String toRrCode, Boolean active) {
    return CompletableFuture.completedFuture(getRrRangeEntity(fromRrCode,toRrCode, active));
  }

  public IamRrCodeRange getRrRangeEntity(String fromRrCode, String toRrCode, Boolean active ) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(
        "fromRrCode", Pair.of(EnumQueryCriteria.EQUALS, fromRrCode));
    fieldValueMap.put(
        "toRrCode", Pair.of(EnumQueryCriteria.EQUALS, toRrCode));
    if(active != null)  {
      fieldValueMap.put("active", Pair.of(EnumQueryCriteria.EQUALS, active));
    }

    Specification<IamRrCodeRange> spec = new Specification<>(fieldValueMap);
    List<IamRrCodeRange> result = iamRrCodeRangeRepository.findAll(spec);
    if (!CollectionUtils.isEmpty(result) && result.size() == 1) {
      return result.get(0);
    }
    throw new FumNotFoundException(Constants.NOT_FOUND_ERROR, "Unable to find the unique rrCode");
  }

  public void setRRCodeRangeStatus(String firmId, boolean status) {
    List<IamRrCodeRange> rrCode = getFirmRrCodeRange(firmId);
    rrCode.forEach(rr -> rr.setActive(status));
    iamRrCodeRangeRepository.saveAll(rrCode);
  }

  public IamRrCodeRange createRrCodeEntityIfNotExist(String fromRrCode, String toRrCode) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("fromRrCode",
        Pair.of(EnumQueryCriteria.EQUALS, fromRrCode));
    fieldValueMap.put("toRrCode",
        Pair.of(EnumQueryCriteria.EQUALS, toRrCode));
    Specification<IamRrCodeRange> spec = new Specification<>(fieldValueMap);
    List<IamRrCodeRange> lst = iamRrCodeRangeRepository.findAll(spec);
    if(!CollectionUtils.isEmpty(lst)) {
      return lst.get(0);
    }
    IamRrCodeRange rrCodeRange = new IamRrCodeRange();
    rrCodeRange.setFromRrCode(fromRrCode);
    rrCodeRange.setToRrCode(toRrCode);
    rrCodeRange.setActive(true);
    return iamRrCodeRangeRepository.save(rrCodeRange);
  }
}
