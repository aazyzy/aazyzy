package ca.bnc.wealth.common.fum.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import ca.bnc.wealth.common.exception.Entity.FumConflictException;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.fum.model.AssignmentTypeEnum;
import ca.bnc.wealth.common.fum.util.Constants;
import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignment;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.UserGroup;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserGroupRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.jpa.utils.RepositoryUtils;
import ca.bnc.wealth.common.userconfiguration.model.PageInfo;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserAssignmentService {
  @Autowired
  private UserAssignmentRrCodeRangeRepository userAssignmentRrCodeRangeRepository;
  @Autowired
  private ResourceRepository resourceRepository;
  @Autowired
  private UserGroupRepository userGroupRepository;
  @Autowired
  private IamUserConfigurationRepository iamUserConfigurationRepository;
  @Autowired
  private ResourceServiceHelper resourceServiceHelper;
  @Qualifier("postgresJdbcTemplate")
  @Autowired
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
  @Autowired
  private UserServiceHelper userServiceHelper;
  @Autowired
  private RedisCacheOperationService redisCacheOperationService;
  @Autowired
  private UserAssignmentRepository userAssignmentRepository;
  @Autowired
  private UserAssignmentServiceHelper userAssignmentServiceHelper;
  @Autowired
  private RrCodeServiceHelper rrCodeServiceHelper;

  public List<ca.bnc.wealth.common.userconfiguration.model.UserAssignment> getUserAssignmentsSp(String idpSubject, List<String> assignmentTypes, Boolean active) {
    return Optional.ofNullable(assignmentTypes)
        .map(types -> types.stream()
            .map(assignmentType -> getUserAssignmentsSpOne(idpSubject, AssignmentTypeEnum.findByCode(assignmentType), active))
            .flatMap(List::stream)
            .collect(Collectors.toList()))
        .orElse(Collections.emptyList());
  }

  private List<ca.bnc.wealth.common.userconfiguration.model.UserAssignment> getUserAssignmentsSpOne(String idpSubject, AssignmentTypeEnum assignmentType, Boolean active) {

    List<Map<String, Object>> listMap = userAssignmentRepository.getUserAssignment(idpSubject, assignmentType.getDbCode(), active);
    List<ca.bnc.wealth.common.userconfiguration.model.UserAssignment> response = new ArrayList<>();

    listMap.forEach(map -> {
      ca.bnc.wealth.common.userconfiguration.model.UserAssignment userAssignment = ca.bnc.wealth.common.userconfiguration.model.UserAssignment.builder()
          .assignmentType(assignmentType.getDbCode())
          .assigneeId((Integer) map.get(Constants.ASSIGNEE_ID))
          .build();
      response.add(userAssignment);

      switch (assignmentType) {
        case RR_RANGE:
          userAssignment
              .fromRrCode((String) map.get(Constants.FROM_RR_CODE))
              .toRrCode((String) map.get(Constants.TO_RR_CODE));
          break;
        case ROLE:
          userAssignment
              .role((String) map.get(Constants.ASSIGNEE_VALUE));
          break;
        case PERMISSION:
          userAssignment
              .permission((String) map.get(Constants.ASSIGNEE_VALUE));
          break;
        case FEATURE_PACKAGE:
          userAssignment
              .templateName((String) map.get(Constants.ASSIGNEE_VALUE));
          break;
        case FIRM:
          userAssignment
              .firmId((String) map.get(Constants.ASSIGNEE_VALUE));
          break;
        case RESOURCE:
          userAssignment
              .resourceName((String) map.get(Constants.ASSIGNEE_VALUE));
          break;
        case USER_GROUP:
          userAssignment
              .usergroupName((String) map.get(Constants.ASSIGNEE_VALUE));
          break;
      }
    });
    return response;
  }

  public <T extends EntityInterface> Map<String, List<T>> getUserAssignmentType(List<String> idpSubjects, UserAssignmentType assignmentType) {
    List<UserAssignment> userAssignments = getUserAssignmentEntity(idpSubjects, assignmentType);
    Map<String, List<Integer>> idpSubjectAssignMap = userAssignments.stream()
        .collect(Collectors.groupingBy(v -> v.getIdpSubject(),
            Collectors.mapping(v -> v.getAssigneeId(), Collectors.toList())));

    List<Integer> assignmentIds = userAssignments.stream()
        .map(v -> v.getAssigneeId())
        .distinct()
        .collect(Collectors.toList());
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();

    switch (assignmentType) {
      case R:
        fieldValueMap.put("rrCodeRangeId", Pair.of(EnumQueryCriteria.IN, assignmentIds));
        break;
      case P:
        fieldValueMap.put("featurePackageId", Pair.of(EnumQueryCriteria.IN, assignmentIds));
        break;
      case F:
        fieldValueMap.put("firmEntityId", Pair.of(EnumQueryCriteria.IN, assignmentIds));
        break;
      case S:
        fieldValueMap.put("resourceId", Pair.of(EnumQueryCriteria.IN, assignmentIds));
        break;
      case G:
        fieldValueMap.put("userGroupId", Pair.of(EnumQueryCriteria.IN, assignmentIds));
        break;
    }
    Specification<T> spec = new Specification<>(fieldValueMap);
    if (userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(assignmentType) != null) {
      List<T> t = userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(assignmentType).findAll(spec);
      Map<Integer, T> idTMap = t.stream().collect(Collectors.toMap(v -> v.getId().intValue(), v -> v));

      Map<String, List<T>> responseMap = idpSubjectAssignMap.entrySet().stream()
          .map(entity -> {
            List<T> tList = new ArrayList<>();
            entity.getValue().stream()
                .filter(idTMap::containsKey)
                .map(idTMap::get)
                .forEach(tList::add);
            return Pair.of(entity.getKey(), tList);
          }).collect(Collectors.toMap(Pair::getKey, Pair::getValue));
      return responseMap;
    }
    return Collections.emptyMap();
  }

  public List<ca.bnc.wealth.common.userconfiguration.model.UserAssignment> getUserAssignments(String idpSubject, List<String> assignmentTypes, Boolean active) {
    return getUserAssignmentsSp(idpSubject, assignmentTypes, active);
  }

  public List<UserAssignment> getUserAssignmentEntity(List<String> idpSubjects, UserAssignmentType assignmentType) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(
        Constants.ASSIGNMENT_TYPE,
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, assignmentType.name()));
    fieldValueMap.put(
        "idpSubject",
        Pair.of(EnumQueryCriteria.IN, idpSubjects));
    Specification<UserAssignment> spec = new Specification<>(fieldValueMap);
    return userAssignmentRepository.findAll(spec);
  }

  public <T> List<T> getUserAssignment(String idpSubject, UserAssignmentType assignmentType) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(Constants.ASSIGNMENT_TYPE,
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, assignmentType.name()));
    fieldValueMap.put("userConfiguration.idpSubject",
        Pair.of(EnumQueryCriteria.EQUALS, idpSubject));
    Specification<T> spec = new Specification<>(fieldValueMap);
    return userAssignmentServiceHelper.getJpaSpecificationRepository(assignmentType).findAll(spec);
  }

  public boolean hasUserAssignment(String idpSubject, Integer assignmentId, UserAssignmentType assignmentType) {

    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(Constants.ASSIGNMENT_TYPE, Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, assignmentType.name()));
    fieldValueMap.put("idpSubject", Pair.of(EnumQueryCriteria.EQUALS, idpSubject));
    fieldValueMap.put("assigneeId", Pair.of(EnumQueryCriteria.EQUALS, assignmentId));
    Specification<UserAssignment> spec = new Specification<>(fieldValueMap);
    return userAssignmentRepository.count(spec) > 0;
  }

  @SneakyThrows
  public <T> boolean hasUserAssignment(String idpSubject, String assignmentName, UserAssignmentType assignmentType) {

    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(Constants.ASSIGNMENT_TYPE, Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, assignmentType.name()));
    fieldValueMap.put("userConfiguration.idpSubject", Pair.of(EnumQueryCriteria.EQUALS, idpSubject));
    switch (assignmentType) {
      case R:
        throw new FumConflictException("unsupported", "unsupported for rr code");
      case P:
        fieldValueMap.put("featurePackage.packageTemplate.name", Pair.of(EnumQueryCriteria.EQUALS, assignmentName));
        break;
      case F:
        fieldValueMap.put("firm.firmId", Pair.of(EnumQueryCriteria.EQUALS, assignmentName));
        break;
      case S:
        fieldValueMap.put("resource.name", Pair.of(EnumQueryCriteria.EQUALS, assignmentName));
        break;
      case G:
        fieldValueMap.put("userGroup.name", Pair.of(EnumQueryCriteria.EQUALS, assignmentName));
        break;
    }
    Specification<T> spec = new Specification<>(fieldValueMap);
    JpaSpecificationExecutor jpaSpecificationExecutor = userAssignmentServiceHelper.getJpaSpecificationRepository(assignmentType);
    if (jpaSpecificationExecutor == null) {
      throw new FumNotFoundException(Constants.NOT_FOUND_ERROR, "unable to find jpa specification");
    }
    return jpaSpecificationExecutor.count(spec) > 0;
  }

  public Page<IamUserConfiguration> getUserConfigByAssignment(UserAssignmentType assignmentType, String assignmentValue, PageInfo page) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    switch (assignmentType) {
      case F:
        fieldValueMap.put("userAssignmentFirms.assignmentType",
            Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.F.name()));
        fieldValueMap.put("userAssignmentFirms.firm.firmId",
            Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, assignmentValue));
        break;
      case G:
        fieldValueMap.put("userAssignmentUserGroups.assignmentType",
            Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.G.name()));
        fieldValueMap.put("userAssignmentUserGroups.userGroup.name",
            Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, assignmentValue));
        break;
      case P:
      case R:
      case S:
        throw new FumNotFoundException(Constants.NOT_FOUND_ERROR, "Not supported");
      default:
        throw new FumNotFoundException(Constants.NOT_FOUND_ERROR, "Unable to find the jpa specification");
    }

    Specification<IamUserConfiguration> spec = new Specification<>(fieldValueMap);

    PageRequest pageRequest = null;
    if (page != null) {
      List<String> field =
          CollectionUtils.isEmpty(page.getSortBy()) ? List.of("firstName") : page.getSortBy();
      String direction = page.getSortOrder() != null ? page.getSortOrder().name() : null;
      pageRequest = RepositoryUtils.getPageRequest(page.getPageNumber(), page.getPageSize(), field,
          direction, false);
    } else {
      pageRequest = RepositoryUtils.getPageRequest(null, null, List.of("firstName"), null, false);
    }

    return iamUserConfigurationRepository.findAll(spec, pageRequest);
  }

  @Transactional
  public void refreshUserAssignment(String assignmentType, String firmId, String requestedBy) {
    if (assignmentType.equalsIgnoreCase("resource")) {
      refreshUserResourcesByFirmId(firmId, requestedBy);
    } else if (assignmentType.equalsIgnoreCase("rr-range")) {
      refreshUserRrCode(firmId, requestedBy);
    } else {
      throw new FumNotFoundException(Constants.NOT_FOUND_ERROR, "Not supported");
    }
  }

  @Transactional
  public void refreshUserAssignment(UserAssignmentType userAssignmentType, String firmId, String requestedBy) {
    switch (userAssignmentType) {
      case S:
        refreshUserResourcesByFirmId(firmId, requestedBy);
        break;
      case R:
        refreshUserRrCode(firmId, requestedBy);
        break;
      default:
        throw new FumNotFoundException(Constants.NOT_FOUND_ERROR, "Not supported");
    }
  }

  @Transactional
  public void refreshUserResourcesByFirmId(String firmId, String requestedBy) {
    SqlParameterSource parameters =
        new MapSqlParameterSource().addValue("firmId", firmId).addValue("requestedBy", requestedBy);
    namedParameterJdbcTemplate.queryForMap(Constants.REFRESH_ASSIGNMENT_BY_FIRM_ID_QUERY, parameters);

    userServiceHelper.getFirmUsers(firmId, true)
        .forEach(uc -> {
          redisCacheOperationService.deleteUserConfigurationCacheEnrichUserMeUsersId(uc.getIdpSubject(), uc.getUserConfigurationId().intValue());
          redisCacheOperationService.deleteCacheByCacheNameAndPattern(Constants.GET_RERSOURCE_CACHE_NAME, uc.getIdpSubject());
        });
  }

  public void refreshUserRrCode(String firmId, String requestedBy) {
    deleteUnusedRrCodeAssignment(firmId);

    if (!hasFirmLevelAccessResourceToFirm(firmId)) {
      return;
    }
    List<IamUserConfiguration> userConfigurations = userServiceHelper.getFirmUsersWithFirmLevelAccess(firmId, true);

    List<IamRrCodeRange> rrCodeRanges = rrCodeServiceHelper.getFirmRrCodeRange(firmId);

    userConfigurations.forEach(uc -> addUserAssignmentRrCode(uc, rrCodeRanges, requestedBy));

  }

  public boolean hasFirmLevelAccessResourceToFirm(String firmId) {
    List<Resource> firmResources = resourceServiceHelper.getFirmResources(firmId, true);
    return firmResources.stream()
        .anyMatch(resource -> "firm_level_access".equalsIgnoreCase(resource.getName()) && "data_access".equalsIgnoreCase(resource.getType()));
  }

  public void addUserAssignmentRrCode(IamUserConfiguration uc, List<IamRrCodeRange> rrCodeRanges, String requestedBy) {
    getUserAssignment(uc.getIdpSubject(), UserAssignmentType.R)
        .forEach(userAssignmentServiceHelper.getJpaRepository(UserAssignmentType.R)::delete);

    rrCodeRanges.forEach(
        rr -> {
          UserAssignmentRrCodeRange userAssignmentRrCodeRange =
              new UserAssignmentRrCodeRange();
          userAssignmentRrCodeRange.setAssignmentType(UserAssignmentType.R);
          userAssignmentRrCodeRange.setUserConfiguration(uc);
          userAssignmentRrCodeRange.setIamRrCodeRange(rr);
          userAssignmentRrCodeRange.setCreatedBy(requestedBy);
          userAssignmentRrCodeRange.setCreationDate(
              new Timestamp(System.currentTimeMillis()));
          userAssignmentRrCodeRangeRepository.save(userAssignmentRrCodeRange);
        });
    redisCacheOperationService.deleteUserConfigurationCacheEnrichUserMeUsersId(uc.getIdpSubject(), uc.getUserConfigurationId().intValue());
  }

  public void assignUserGroupToUser(long userConfigurationId, String idpSubject, long assigneeId, String requestedBy) {
    userAssignmentUsingSp(userConfigurationId, idpSubject, assigneeId, UserAssignmentType.G.name(), requestedBy);
    redisCacheOperationService.deleteUserConfigurationCacheEnrichUserMeUsersId(idpSubject, (int) userConfigurationId);
  }

  public void assignResourceToUser(long userConfigurationId, String idpSubject, long assigneeId, String requestedBy) {
    userAssignmentUsingSp(userConfigurationId, idpSubject, assigneeId, UserAssignmentType.S.name(), requestedBy);
    redisCacheOperationService.deleteUserConfigurationCacheEnrichUserMeUsersId(idpSubject, (int) userConfigurationId);
  }

  public void assignFirmToUser(long userConfigurationId, String idpSubject, long assigneeId, String requestedBy) {
    userAssignmentUsingSp(userConfigurationId, idpSubject, assigneeId, UserAssignmentType.F.name(), requestedBy);
    redisCacheOperationService.deleteUserConfigurationCacheEnrichUserMeUsersId(idpSubject, (int) userConfigurationId);
  }

  public void assignFeaturePackageToUser(long userConfigurationId, String idpSubject, long assigneeId, String requestedBy) {
    userAssignmentUsingSp(userConfigurationId, idpSubject, assigneeId, UserAssignmentType.P.name(), requestedBy);
    redisCacheOperationService.deleteUserConfigurationCacheEnrichUserMeUsersId(idpSubject, (int) userConfigurationId);
    redisCacheOperationService.deleteCacheByCacheNameAndPattern(Constants.GET_RERSOURCE_CACHE_NAME, idpSubject);
  }

  public void assignRrRangesSp(final Integer userConfigurationId, final String idpSubject, final List<RRCodeRange> targetRrRanges, final String requestedBy) {
    String rrcode = StringUtils.join(targetRrRanges.stream().map(rr -> rr.getFromRRCode() + "-" + rr.getToRRCode()).collect(
        Collectors.toList()), ":");
    userAssignmentRepository.setUserRrCodeAssignment(userConfigurationId, rrcode, requestedBy);
    redisCacheOperationService.deleteUserConfigurationCacheEnrichUserMeUsersId(idpSubject, (int) userConfigurationId);
  }


  public void userAssignmentUsingSp(long userConfigurationId, String idpSubject, long assignmentId, String assignmentType, String requestedBy) {
    try {
      userAssignmentRepository.setUserAssignment(userConfigurationId, assignmentId, assignmentType, requestedBy);
      redisCacheOperationService.deleteUserConfigurationCacheEnrichUserMeUsersId(idpSubject, Integer.valueOf((int) userConfigurationId));
    } catch (Exception e) {
      handlePostgresDbException(e, userConfigurationId, assignmentId);
    }
  }

  public void applyFirmAccessLevelCheckSp(long idpSubject, String requestBy) {
    try {
      userAssignmentRepository.applyFirmAccessLevelCheck(idpSubject, requestBy);
    } catch (Exception e) {
      handlePostgresDbException(e, idpSubject, null);
    }
  }

  @Transactional
  public void deleteUserAssignment(String idpSubject,
      String assignmentType, Integer assigneeId) {
    userAssignmentRepository.findFirstByIdpSubjectAndAssignmentTypeAndAssigneeId(
        idpSubject, UserAssignmentType.valueOf(assignmentType), assigneeId)
        .ifPresent(userAssignmentRepository::delete);
  }

  public boolean hasUserAssignment(Integer assigneeId, UserAssignmentType userAssignmentType) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("assignmentType", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, userAssignmentType.name()));
    fieldValueMap.put("assigneeId", Pair.of(EnumQueryCriteria.EQUALS, assigneeId));
    Specification<UserAssignment> spec = new Specification<>(fieldValueMap);
    return userAssignmentRepository.count(new Specification<>(fieldValueMap)) > 0;
  }

  public void assignUserGroupNameToUser(Integer userConfigurationId, String idpSubject, String userGroupName, String requestedBy) {
    Optional<UserGroup> optionalUserGroup = userGroupRepository.findFirstByName(userGroupName);
    optionalUserGroup.ifPresentOrElse(userGroupVal -> {
      assignUserGroupToUser(userConfigurationId, idpSubject, userGroupVal.getUserGroupId(), requestedBy);
    }, () -> {
      throw new FumNotFoundException(Constants.ERROR_USER_GROUP_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_GROUP_NOT_FOUND_MESSAGE, userGroupName));
    });
  }

  public void assignResourceNameToUser(Integer userConfigurationId, String idpSubject, String resourceName, String requestedBy) {

    Optional<Resource> optionalResource = resourceRepository.findFirstByName(resourceName);
    optionalResource.ifPresentOrElse(resource -> {
      assignResourceToUser(userConfigurationId, idpSubject, resource.getResourceId(), requestedBy);
    }, () -> {
      {
        throw new FumNotFoundException(Constants.ERROR_RESOURCE_NOT_FOUND_CODE,
            String.format(Constants.ERROR_RESOURCE_NOT_FOUND_MESSAGE, resourceName));
      }
    });

  }

  @Transactional
  public void deleteUserAssignments(IamUserConfiguration userConfiguration) {
    userAssignmentRepository.deleteUserAssignmentsByIdpSubject(userConfiguration.getIdpSubject());
  }

  protected void deleteUnusedRrCodeAssignment(String firmId) {
    List<IamUserConfiguration> userconfigs = userServiceHelper.getFirmUsers(firmId, true);
    List<String> idpSubjects = userconfigs.stream()
        .peek(user -> redisCacheOperationService.deleteUserConfigurationWithRrCodeCache(user.getIdpSubject(), Integer.valueOf(user.getUserConfigurationId().intValue())))
        .map(IamUserConfiguration::getIdpSubject)
        .collect(Collectors.toList());

    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap2 = new HashMap<>();

    fieldValueMap2.put("userAssignmentRrCodeRanges.assignmentType",
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.R.name()));
    fieldValueMap2.put("userAssignmentRrCodeRanges.userConfiguration.idpSubject",
        Pair.of(EnumQueryCriteria.IN, idpSubjects));
    Specification<IamRrCodeRange> spec = new Specification<>(fieldValueMap2);
    List<IamRrCodeRange> userRrCodes = userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(UserAssignmentType.R).findAll(spec);


    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap3 = new HashMap<>();
    fieldValueMap3.put(Constants.IDP_SUBJECT, Pair.of(EnumQueryCriteria.IN, idpSubjects));
    fieldValueMap3.put(Constants.ASSIGNMENT_TYPE, Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.R.name()));
    Specification<UserAssignment> spec3 = new Specification<>(fieldValueMap3);
    Map<Integer, List<UserAssignment>> assignmentIdMap = userAssignmentRepository.findAll(spec3)
        .stream()
        .collect(Collectors.groupingBy(UserAssignment::getAssigneeId));

    List<IamRrCodeRange> firmRrCodeList = rrCodeServiceHelper.getFirmRrCodeRange(firmId);

    List<Long> deleteIdList = userRrCodes.stream()
        .filter(ur -> firmRrCodeList.stream().noneMatch(fr -> ur.getFromRrCodeB10() >= fr.getFromRrCodeB10() && ur.getToRrCodeB10() <= fr.getToRrCodeB10()))
        .flatMap(ur -> assignmentIdMap.get(Integer.valueOf((int) ur.getRrCodeRangeId())).stream())
        .map(UserAssignment::getId)
        .collect(Collectors.toList());

    userAssignmentRepository.deleteAllById(deleteIdList);
  }

  @SneakyThrows
  public static void shutdownAndAwait(ExecutorService executorService) {
    executorService.shutdown();
    try {
      executorService.awaitTermination(100000, TimeUnit.MILLISECONDS);
    } catch (InterruptedException e) {
      executorService.shutdownNow();
      log.error("Error in executor service: {}", e.getMessage());
      throw e;
    }
  }

  @SneakyThrows
  private void handlePostgresDbException(Exception e, Long idpSubject, Long assignment) {
    if (e.getMessage().contains(String.format(Constants.USER_NOT_FOUND_ERROR, idpSubject))) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, idpSubject));
    }
    if (e.getMessage().contains(String.format(Constants.FIRM_NOT_FOUND_ERROR, assignment))) {
      throw new FumNotFoundException(Constants.ERROR_FIRM_NOT_FOUND_CODE,
          String.format(Constants.ERROR_FIRM_NOT_FOUND_MESSAGE, assignment));
    }
    if (e.getMessage().contains(String.format(Constants.USER_GROUP_NOT_FOUND_ERROR, assignment))) {
      throw new FumNotFoundException(Constants.ERROR_USER_GROUP_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_GROUP_NOT_FOUND_MESSAGE, assignment));
    }
    if (e.getMessage().contains(String.format(Constants.RESOURCE_NOT_FOUND_ERROR, assignment))) {
      throw new FumNotFoundException(Constants.ERROR_RESOURCE_NOT_FOUND_CODE,
          String.format(Constants.ERROR_RESOURCE_NOT_FOUND_MESSAGE, assignment));
    }
    throw e;
  }
}
