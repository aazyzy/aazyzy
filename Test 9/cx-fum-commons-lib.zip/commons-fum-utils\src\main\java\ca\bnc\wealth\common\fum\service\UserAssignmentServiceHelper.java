package ca.bnc.wealth.common.fum.service;

import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.fum.util.Constants;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentFeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentFirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserGroupRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class UserAssignmentServiceHelper {

  @Autowired
  private UserAssignmentFeaturePackageRepository userAssignmentFeaturePackageRepository;
  @Autowired
  private UserAssignmentFirmRepository userAssignmentFirmRepository;
  @Autowired
  private UserAssignmentResourceRepository userAssignmentResourceRepository;
  @Autowired
  private UserAssignmentRrCodeRangeRepository userAssignmentRrCodeRangeRepository;
  @Autowired
  private UserAssignmentUserGroupRepository userAssignmentUserGroupRepository;
  @Autowired
  private ResourceRepository resourceRepository;
  @Autowired
  private UserGroupRepository userGroupRepository;
  @Autowired
  private IamRrCodeRangeRepository rrCodeRangeRepository;
  @Autowired
  private FeaturePackageRepository featurePackageRepository;
  @Autowired
  private FirmRepository firmRepository;


  public JpaRepository getJpaRepository(
      UserAssignmentType assignmentType) {
    switch (assignmentType) {
      case R:
        return userAssignmentRrCodeRangeRepository;
      case P:
        return userAssignmentFeaturePackageRepository;
      case F:
        return userAssignmentFirmRepository;
      case S:
        return userAssignmentResourceRepository;
      case G:
        return userAssignmentUserGroupRepository;
    }
    throw new FumNotFoundException(Constants.NOT_FOUND_ERROR, "Unable to find the jpa specification");
  }

  public JpaSpecificationExecutor getJpaSpecificationRepository(
      UserAssignmentType assignmentType) {
    switch (assignmentType) {
      case R:
        return userAssignmentRrCodeRangeRepository;
      case P:
        return userAssignmentFeaturePackageRepository;
      case F:
        return userAssignmentFirmRepository;
      case S:
        return userAssignmentResourceRepository;
      case G:
        return userAssignmentUserGroupRepository;
    }
    throw new FumNotFoundException(Constants.NOT_FOUND_ERROR, "Unable to find the jpa specification");
  }

  public JpaSpecificationExecutor getUserAssignmentTypeJpaSpecificationRepository(
      UserAssignmentType assignmentType) {
    switch (assignmentType) {
      case R:
        return rrCodeRangeRepository;
      case P:
        return featurePackageRepository;
      case F:
        return firmRepository;
      case S:
        return resourceRepository;
      case G:
        return userGroupRepository;
    }
    throw new FumNotFoundException(Constants.NOT_FOUND_ERROR, "Unable to find the user assignment jpa specification");
  }

}
