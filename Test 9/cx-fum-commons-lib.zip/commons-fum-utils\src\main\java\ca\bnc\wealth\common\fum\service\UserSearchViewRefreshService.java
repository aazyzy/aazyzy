package ca.bnc.wealth.common.fum.service;

import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.repo.iam.UserConfigSearchMaterializedViewRepository;
import jakarta.annotation.PreDestroy;
import java.util.Objects;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Centralized refresh service for the {@code IAM_V2.USER_CONFIGURATION_MATERIALIZED} view.
 *
 * <p>Every write path across the FUM platform triggers the refresh through this single service so
 * that the expensive {@code REFRESH MATERIALIZED VIEW CONCURRENTLY} is coalesced into <b>at most one
 * running plus one waiting</b> job per instance, instead of firing once per mutation.
 *
 * <p>The refresh work runs on a bounded, coalescing executor: a single worker thread with a
 * one-slot queue and a {@link ThreadPoolExecutor.DiscardOldestPolicy}. Because every refresh
 * recomputes the whole view, a newly submitted refresh supersedes an older not-yet-started one, so
 * discarding the queued task is safe and guarantees that a refresh which starts <i>after</i> the
 * most recent change always runs.
 *
 * <p>Callers that must read the view immediately after their own write (for example, to build an
 * audit after-image) use {@link #refreshNow(boolean)} to refresh synchronously and preserve
 * read-your-writes consistency. High-volume fire-and-forget mutation paths use
 * {@link #refreshAsync(boolean)} to benefit from coalescing.
 *
 * <p>Regardless of the entry point, every physical refresh runs under a single lock, so the
 * database never executes two {@code REFRESH MATERIALIZED VIEW CONCURRENTLY} statements at the same
 * time.
 */
@Service
@Slf4j
public class UserSearchViewRefreshService {

  private static final int CALLBACK_QUEUE_CAPACITY = 100;
  private static final long SHUTDOWN_AWAIT_SECONDS = 10L;

  private final UserConfigSearchMaterializedViewRepository userConfigSearchMaterializedViewRepository;

  /** Bounded, coalescing executor: at most 1 running + 1 waiting refresh. */
  private final ThreadPoolExecutor refreshExecutor = new ThreadPoolExecutor(
      1, 1, 0L, TimeUnit.MILLISECONDS,
      new ArrayBlockingQueue<>(1),
      daemonThreadFactory("user-search-view-refresh"),
      new ThreadPoolExecutor.DiscardOldestPolicy());

  /**
   * Bounded executor for refresh-then-callback work. Uses {@link ThreadPoolExecutor.CallerRunsPolicy}
   * so callbacks (which are distinct per user) are never dropped and the caller is throttled by
   * backpressure instead of the queue growing without bound.
   */
  private final ThreadPoolExecutor callbackExecutor = new ThreadPoolExecutor(
      1, 1, 0L, TimeUnit.MILLISECONDS,
      new ArrayBlockingQueue<>(CALLBACK_QUEUE_CAPACITY),
      daemonThreadFactory("user-search-view-refresh-callback"),
      new ThreadPoolExecutor.CallerRunsPolicy());

  /** Serializes every physical refresh so the database never runs two refreshes at once. */
  private final ReentrantLock refreshLock = new ReentrantLock();

  public UserSearchViewRefreshService(
      UserConfigSearchMaterializedViewRepository userConfigSearchMaterializedViewRepository) {
    this.userConfigSearchMaterializedViewRepository = userConfigSearchMaterializedViewRepository;
  }

  /**
   * Enqueue a coalescing asynchronous refresh (at most 1 running + 1 waiting per instance).
   *
   * @param throwException when {@code true}, a refresh failure is rethrown on the worker thread
   *     after logging; when {@code false}, it is only logged. Because the refresh runs
   *     asynchronously, the exception cannot reach the calling thread — use {@link #refreshNow} when
   *     the caller needs to observe failures.
   */
  public void refreshAsync(boolean throwException) {
    refreshExecutor.submit(() -> doRefresh(throwException));
  }

  /**
   * Asynchronously refresh the view and then run {@code afterRefresh}. The refresh and the callback
   * run sequentially — the callback strictly after the refresh — on a dedicated bounded executor, so
   * the callback never observes a pre-refresh view and is never dropped by refresh coalescing.
   *
   * @param afterRefresh work to run once the refresh has completed
   * @param throwException when {@code true}, a failure is rethrown on the worker thread after
   *     logging; when {@code false}, it is only logged.
   */
  public void refreshAsync(Runnable afterRefresh, boolean throwException) {
    callbackExecutor.submit(() -> refreshThenCallback(afterRefresh, throwException));
  }

  /**
   * Refresh the view synchronously on the calling thread. Use this when the caller must read the
   * refreshed view within the same request (for example, to build an audit after-image). The
   * refresh waits for any in-flight refresh to finish, then runs its own, so the caller always
   * observes a view that reflects its own write.
   *
   * @param throwException when {@code true}, a failure is rethrown to the caller after logging.
   */
  public void refreshNow(boolean throwException) {
    doRefresh(throwException);
  }

  /**
   * Enqueue a coalescing asynchronous refresh only when a <b>search-relevant</b> field of the user
   * configuration actually changed between {@code before} and {@code after}. Changes limited to
   * columns that are no longer part of the search materialized view (for example user preferences)
   * or to the audit-only timestamp columns ({@code LAST_UPDATE_DATE}, {@code LAST_UPDATED_BY},
   * {@code PROFILE_LAST_UPDATED}, {@code STATUS_LAST_UPDATED}) do not trigger a refresh, leaving the
   * search view eventually-consistent for those. A {@code null} before/after image is treated as a
   * change so creates, deletes and unknown cases stay safe.
   *
   * <p><b>Only for write paths that mutate the user's own columns and do NOT change firm /
   * user-group / RR-code assignments.</b> The assignment-derived columns ({@code FIRM_ID},
   * {@code USER_GROUP_NAME}, {@code RR_RANGES}) are not visible on the entity and cannot be compared
   * here, so any path that also changes assignments must refresh unconditionally.
   */
  public void refreshAsyncIfSearchFieldChanged(
      IamUserConfiguration before, IamUserConfiguration after, boolean throwException) {
    if (searchRelevantFieldChanged(before, after)) {
      refreshAsync(throwException);
    } else {
      log.debug(
          "Skipping user-search materialized view refresh: no search-relevant field changed for user configuration {}",
          after.getUserConfigurationId());
    }
  }

  private void doRefresh(boolean throwException) {
    try {
      refreshUnderLock();
    } catch (Exception exception) {
      log.error("Unable to refresh userSearchMaterializedView: {}", exception.getMessage(), exception);
      if (throwException) {
        throw exception;
      }
    }
  }

  private void refreshThenCallback(Runnable afterRefresh, boolean throwException) {
    try {
      refreshUnderLock();
      afterRefresh.run();
    } catch (Exception exception) {
      log.error(
          "Unable to refresh userSearchMaterializedView or run post-refresh callback: {}",
          exception.getMessage(), exception);
      if (throwException) {
        throw exception;
      }
    }
  }

  /**
   * Run the physical refresh under {@link #refreshLock} so that no two refreshes -- whether
   * triggered by {@link #refreshAsync}, the callback path, or {@link #refreshNow} -- ever execute
   * concurrently against the database. The callback in {@link #refreshThenCallback} runs only after
   * a successful refresh, because a failure propagates out of this method.
   */
  private void refreshUnderLock() {
    refreshLock.lock();
    try {
      userConfigSearchMaterializedViewRepository.refreshMeterializedView();
    } finally {
      refreshLock.unlock();
    }
  }

  /**
   * Whether any trimmed-search-view column derived from the user's own record changed. The compared
   * set is the searchable user columns that remain in the view. Two groups are intentionally
   * excluded: (1) audit-only timestamp/actor columns ({@code LAST_UPDATE_DATE},
   * {@code LAST_UPDATED_BY}, {@code PROFILE_LAST_UPDATED}, {@code STATUS_LAST_UPDATED},
   * {@code CREATED_BY}, {@code CREATION_DATE}) and (2) columns no longer in the trimmed view
   * ({@code userPreferences}, {@code activationDate}, {@code identityLastUpdated},
   * {@code sourceIdpSubject}, {@code bngfReferenceId}, {@code lastLoginDate}). Assignment-derived
   * columns ({@code FIRM_ID}, {@code USER_GROUP_NAME}, {@code RR_RANGES}) come from join tables, not
   * this entity, so paths that change assignments must refresh unconditionally.
   */
  private static boolean searchRelevantFieldChanged(
      IamUserConfiguration before, IamUserConfiguration after) {
    if (before == null || after == null) {
      return true;
    }
    return !Objects.equals(before.getFirstName(), after.getFirstName())
        || !Objects.equals(before.getLastName(), after.getLastName())
        || !Objects.equals(before.getEmail(), after.getEmail())
        || !Objects.equals(before.getUsername(), after.getUsername())
        || !Objects.equals(before.getIdp(), after.getIdp())
        || !Objects.equals(before.getIdpSubject(), after.getIdpSubject())
        || !Objects.equals(before.getIdpUserIdentifier(), after.getIdpUserIdentifier())
        || !Objects.equals(before.getOssGroupId(), after.getOssGroupId())
        || !Objects.equals(before.getOssUserId(), after.getOssUserId())
        || !Objects.equals(before.getPreferredLanguageType(), after.getPreferredLanguageType())
        || !Objects.equals(before.getPreferredCxUtModule(), after.getPreferredCxUtModule())
        || !Objects.equals(before.getState(), after.getState())
        || !Objects.equals(before.getStateAction(), after.getStateAction())
        || !Objects.equals(before.getStateDescription(), after.getStateDescription())
        || !Objects.equals(before.getActive(), after.getActive())
        || !Objects.equals(before.getAccessProfileSet(), after.getAccessProfileSet())
        || !Objects.equals(before.getSource(), after.getSource());
  }

  private static ThreadFactory daemonThreadFactory(String name) {
    return runnable -> {
      Thread thread = new Thread(runnable, name);
      thread.setDaemon(true);
      return thread;
    };
  }

  @PreDestroy
  void shutdown() {
    shutdownExecutor(refreshExecutor);
    shutdownExecutor(callbackExecutor);
  }

  private void shutdownExecutor(ThreadPoolExecutor executor) {
    executor.shutdown();
    try {
      if (!executor.awaitTermination(SHUTDOWN_AWAIT_SECONDS, TimeUnit.SECONDS)) {
        executor.shutdownNow();
      }
    } catch (InterruptedException exception) {
      executor.shutdownNow();
      Thread.currentThread().interrupt();
    }
  }
}
