package ca.bnc.wealth.common.fum.service;


import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class UserServiceHelper {

  @Autowired
  private IamUserConfigurationRepository iamUserConfigurationRepository;
  @Autowired
  private IamRrCodeRangeRepository iamRrCodeRangeRepository;
  @Autowired
  private UserSearchViewRefreshService userSearchViewRefreshService;

  public List<IamUserConfiguration> getFirmUsers(String firmId, Boolean nbinUsersOnly) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldMap = new HashMap<>();
    fieldMap.put(
        "userAssignmentFirms.assignmentType",
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.F.name()));
    fieldMap.put("userAssignmentFirms.firm.firmId", Pair.of(EnumQueryCriteria.EQUALS, firmId));
    if(nbinUsersOnly != null) {
      if(nbinUsersOnly) {
        fieldMap.put("idp", Pair.of(EnumQueryCriteria.IGNORE_CASE_EQUALS, "nbin"));
      } else {
        fieldMap.put("idp", Pair.of(EnumQueryCriteria.IGNORE_CASE_NOT_EQUALS, "nbin"));
      }
    }
    Specification<IamUserConfiguration> spec = new Specification<>(fieldMap);
    return iamUserConfigurationRepository.findAll(spec);
  }

  public List<IamUserConfiguration> getFirmUsersWithFirmLevelAccess(String firmId, Boolean nbinUsersOnly) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(
        "userAssignmentFirms.assignmentType",
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.F.name()));
    fieldValueMap.put("userAssignmentFirms.firm.firmId", Pair.of(EnumQueryCriteria.EQUALS, firmId));
    fieldValueMap.put(
        "userAssignmentResources.assignmentType",
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.S.name()));
    fieldValueMap.put(
        "userAssignmentResources.resource.name", Pair.of(EnumQueryCriteria.IGNORE_CASE_EQUALS, "firm_level_access"));
    fieldValueMap.put(
        "userAssignmentResources.resource.type", Pair.of(EnumQueryCriteria.IGNORE_CASE_EQUALS, "data_access"));
    if(nbinUsersOnly != null) {
      if(nbinUsersOnly) {
        fieldValueMap.put("idp", Pair.of(EnumQueryCriteria.IGNORE_CASE_EQUALS, "nbin"));
      } else {
        fieldValueMap.put("idp", Pair.of(EnumQueryCriteria.IGNORE_CASE_NOT_EQUALS, "nbin"));
      }
    }

    Specification<IamUserConfiguration> spec = new Specification<>(fieldValueMap);
    return iamUserConfigurationRepository.findAll(spec);
  }

  public void refreshUserSearchMaterializedView(boolean throwException) {
    userSearchViewRefreshService.refreshAsync(throwException);
  }
}
