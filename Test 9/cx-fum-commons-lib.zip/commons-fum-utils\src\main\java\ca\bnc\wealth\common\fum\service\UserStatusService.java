package ca.bnc.wealth.common.fum.service;

import ca.bnc.wealth.common.fum.model.UiUserStatusEnum;
import ca.bnc.wealth.common.fum.model.UserStateActionEnum;
import ca.bnc.wealth.common.fum.model.UserStateDescriptionEnum;
import ca.bnc.wealth.common.fum.model.UserStateEnum;
import ca.bnc.wealth.common.fum.model.UserStatusEnum;
import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class UserStatusService {

  public String getUiUserStatus(UserConfigSearchMaterializedView userConfig) {
    return getUiUserStatus(userConfig.getIdp(), userConfig.getState(), userConfig.getStateAction(), userConfig.getStateDescription(), userConfig.getActive() ? UserStatusEnum.ACTIVE.dbValue : UserStatusEnum.INACTIVE.dbValue, userConfig.getAccessProfileSet());

  }

  public String getUiUserStatus(String idp, String state, String stateAction, String stateDescription, String status, Boolean accessProfileSet) {
    try {
      if(!accessProfileSet && idp != null && !idp.equalsIgnoreCase("nbin")) {
        return UiUserStatusEnum.No_Account.status;
      }
      UserStateEnum stateEnum = UserStateEnum.getEnum(state);
      UserStateActionEnum stateActionEnum = UserStateActionEnum.getEnum(stateAction);
      UserStateDescriptionEnum stateDescriptionEnum = UserStateDescriptionEnum.getEnum(stateDescription);
      UserStatusEnum statusEnum = UserStatusEnum.getEnum(status);

      if(stateEnum == UserStateEnum.ONBOARDING && statusEnum == UserStatusEnum.INACTIVE) {
        return UiUserStatusEnum.Invited.status;
      } else if(stateEnum == UserStateEnum.PROVISIONED && statusEnum == UserStatusEnum.ACTIVE) {
        return UiUserStatusEnum.First_Sign_In.status;
      } else if(stateEnum == UserStateEnum.ACTIVE) {
        return UiUserStatusEnum.Active.status;
      } else if(stateEnum == UserStateEnum.RECOVERY && statusEnum == UserStatusEnum.ACTIVE) {
        return UiUserStatusEnum.Password_Reset.status;
      } else if(statusEnum == UserStatusEnum.INACTIVE && stateActionEnum == UserStateActionEnum.LOCKED) {
        return UiUserStatusEnum.Locked.status;
      } else if((stateEnum == UserStateEnum.DECOMMISSIONED || statusEnum == UserStatusEnum.INACTIVE)
          && (stateActionEnum == UserStateActionEnum.SUSPENDED || stateDescriptionEnum == UserStateDescriptionEnum.SUSPENDED)) {
        return UiUserStatusEnum.Inactive.status;
      }
    } catch (Exception e) {
      log.warn("Invalid enum value provided: {}", e.getMessage());
      return "";
    }
    return "";
  }


}
