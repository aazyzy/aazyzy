package ca.bnc.wealth.common.fum.service;

import org.springframework.context.EmbeddedValueResolverAware;
import org.springframework.stereotype.Component;
import org.springframework.util.StringValueResolver;

@Component
public class ValueResolverService  implements EmbeddedValueResolverAware {

  private StringValueResolver resolver;

  @Override
  public void setEmbeddedValueResolver(StringValueResolver resolver) {
    this.resolver = resolver;
  }

  public int getIntValue(String value) {
    return Integer.parseInt(resolver.resolveStringValue(value));
  }
}
