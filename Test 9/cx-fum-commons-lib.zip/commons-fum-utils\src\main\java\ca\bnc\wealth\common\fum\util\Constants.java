package ca.bnc.wealth.common.fum.util;

public class Constants {

  public static final String IDP_SUBJECT = "idpSubject";
  public static final String FIRM_ID = "firmId";
  public static final String FIRM_ENTITY_ID = "firmEntityId";
  public static final boolean ACTIVE_BOOLEAN = true;
  public static final String ASSIGNEE_ID = "assigneeId";
  public static final String FROM_RR_CODE = "fromRrCode";
  public static final String TO_RR_CODE = "toRrCode";
  public static final String ASSIGNEE_VALUE = "assigneeValue";
  public static final String FIRM_STATUS_ACTIVE = "active";
  public static final String FIRM_STATUS_INACTIVE = "inactive";
  public static final String EXPIRY_DATE = "9999-12-31 00:00:00.000";
  public static final String USER_NOT_FOUND_ERROR = "ERROR: %s USER NOT FOUND";
  public static final String FIRM_NOT_FOUND_ERROR = "ERROR: %s FIRM NOT FOUND";
  public static final String USER_GROUP_NOT_FOUND_ERROR = "ERROR: %s USER GROUP NOT FOUND";
  public static final String RESOURCE_NOT_FOUND_ERROR = "ERROR: %s RESOURCE NOT FOUND";
  public static final String ERROR_USER_NOT_FOUND_CODE = "error.user.notFound";
  public static final String ERROR_USER_NOT_FOUND_MESSAGE = "User %s was not found";
  public static final String FIRM_NOT_FOUND_CODE = "error.firm.not.found";
  public static final String FIRM_NOT_FOUND_MESSAGE = "Firm %s is deactivated or does not exist";
  public static final String FIRM_NOT_INACTIVE_CODE = "error.firm.not.inactive";
  public static final String FIRM_NOT_INACTIVE_MESSAGE = "Firm is not inactive";
  public static final String ERROR_FIRM_NOT_FOUND_CODE = "error.firm.notFound";
  public static final String FIRM_NOT_ASSIGNED_TO_USER_CODE = "error.firm.not.assigned";
  public static final String FIRM_NOT_ASSIGNED_TO_USER_MESSAGE = "Firm %s is not assigned to user.";
  public static final String ERROR_FIRM_NOT_FOUND_MESSAGE = "Firm %s was not found or not active";
  public static final String ERROR_USER_GROUP_NOT_FOUND_CODE = "error.userGroup.notFound";
  public static final String ERROR_USER_GROUP_NOT_FOUND_MESSAGE = "User group %s was not found";
  public static final String ERROR_RESOURCE_NOT_FOUND_CODE = "error.resource.notFound";
  public static final String ERROR_RESOURCE_NOT_FOUND_MESSAGE = "Resource %s was not found";
  public static final String PACKAGE_TEMPLATE_NOT_FOUND_CODE = "error.packageTemplate.notFound";
  public static final String PACKAGE_TEMPLATE_NOT_FOUND_MESSAGE = "Package Template %s not found";
  public static final String FEATURE_PACKAGE_NOT_FOUND_CODE = "error.featurePackage.notFound";
  public static final String FEATURE_PACKAGE_NOT_FOUND_MESSAGE = "Feature Package %s not found";
  public static final String FEATURE_PACKAGE_HAS_ASSIGNMENT_CODE = "error.FeaturePackage.hasAssignments";
  public static final String FEATURE_PACKAGE_HAS_ASSIGNMENT_MESSAGE = "FeaturePackage %s has Assignments";
  public static final String FEATURE_PACKAGE_UNWANTED_DATA_CODE = "error.FeaturePackage.unwantedData";
  public static final String FEATURE_PACKAGE_UNWANTED_DATA_MESSAGE = "FeaturePackage %s has incorrect assignment records provided";
  public static final String PACKAGE_TEMPLATE_ASSIGNMENT_NOT_MATCH_CODE = "error.packageTemplateAssignment.notMatchedToInput";
  public static final String PACKAGE_TEMPLATE_ASSIGNMENT_NOT_MATCH_MESSAGE = "Package Template Assignment not match to input";
  public static final String PACKAGE_TEMPLATE_ASSIGNMENT_INCLUDE_NOT_ACTIVE_CODE = "error.packageTemplateAssignment.includeMode.notActiveInInput";
  public static final String PACKAGE_TEMPLATE_ASSIGNMENT_INCLUDE_NOT_ACTIVE_MESSAGE = "Package Template Assignment include Mode is not active in input";
  public static final String USER_GROUP_NOT_EXIST_CODE = "error.userGroup.notExist";
  public static final String USER_GROUP_NOT_EXIST_MESSAGE = "User Group %s does not exists";
  public static final String RESOURCE_TYPE_NOT_EXIST_CODE = "error.resource.type.notExist";
  public static final String RESOURCE_TYPE_NOT_EXIST_MESSAGE = "Resource type %s does not exist";
  public static final String TEMPLATE_DOES_NOT_EXIST_CODE = "invalid.template";
  public static final String TEMPLATE_DOES_NOT_EXIST_MESSAGE = "The template %s does not exist.";
  public static final String CAN_NOT_DELETE_TEMPLATE_CODE = "template.usedbyFeaturePackage";
  public static final String CAN_NOT_DELETE_TEMPLATE_MESSAGE = "The template %s is used by Feature Package .";
  public static final String FEATURE_PACKAGE_NAME_NOTFOUND_CODE = "packageTemplate.notfound";
  public static final String FEATURE_PACKAGE_NAME_NOTFOUND_MESSAGE = "Package Template Not Found";
  public static final String ASSIGNMENT_TYPE = "assignmentType";
  public static final String ERROR_ASSIGNEE_ID_INVALID = "error.assigneeID.invalid";

  public static String GET_RERSOURCE_CACHE_NAME = "Authorization-API-GetResources-By-ResourceType-IdpSubject";
  public static final String GET_FIRM_CACHE = "FirmConfiguration-GetFirm-By-IdpSubject-FirmId-Hierarchy";
  public static final String REFRESH_ASSIGNMENT_QUERY =
      "SELECT * FROM \"IAM_V2\".refresh_user_assignment2(:idp_subject, :refresh_resources, :refresh_user_group, :requestedBy)";

  public static final String REFRESH_ASSIGNMENT_BY_FIRM_ID_QUERY =
      "SELECT * FROM \"IAM_V2\".refresh_assignment_for_all_user_of_firm(:firmId, :requestedBy)";
  public static final String NOT_FOUND_ERROR = "notFound";
  public static final String GET_FIRMS_BY_IDP_SUBJECT_QUERY = """
      select
            distinct f1_0."FIRM_ENTITY_ID",
            f1_0."ACTIVE",
            f1_0."FIRM_ID",
            f1_0."CREATED_BY",
            f1_0."CREATION_DATE",
            f1_0."DESCRIPTION",
            f1_0."FINANCIAL_ENTITY_ID",
            f1_0."TYPE",
            f1_0."LAST_UPDATE_DATE",
            f1_0."LAST_UPDATED_BY",
            f1_0."NAME",
            f1_0."PARENT_FIRM_ID",
            f1_0."PREFERRED_LANGUAGE",
            f1_0."FIRM_DISPLAY_NAME_EN",
            f1_0."FIRM_DISPLAY_NAME_FR",
            f1_0."STATE",
            f1_0."STATUS_LAST_UPDATED",
            p1_0."FIRM_ENTITY_ID" as "PARENT_FIRM_ENTITY_ID",
            f2_0."BROKER_CODE",
            f2_0."B_NUMBER",
            f2_0."DEALER_CODE",
            f1_0."FIRM_PREFERENCES"
        from
            "IAM_V2"."FIRM" f1_0
        join
            "IAM_V2"."USER_ASSIGNMENT" u1_0
                on f1_0."FIRM_ENTITY_ID"=u1_0."ASSIGNEE_ID"
        join
            "IAM_V2"."USER_CONFIGURATION" u2_0
                on u2_0."IDP_SUBJECT"=u1_0."IDP_SUBJECT"
        left join
            "IAM_V2"."FINANCIAL_ENTITY" f2_0
                on f2_0."FINANCIAL_ENTITY_ID"=f1_0."FINANCIAL_ENTITY_ID"
        left join
            "IAM_V2"."FIRM" p1_0
                on p1_0."FIRM_ID"=f1_0."PARENT_FIRM_ID"
        where
            u1_0."IDP_SUBJECT" = :idpSubject
            and cast(u1_0."ASSIGNMENT_TYPE" as text) = :assignmentType
            and f1_0."ACTIVE" = :active
      """;
  public static final String GET_RR_CODES_BY_FIRM = """
      select
            r1_0."RR_CODE_RANGE_ID",
            r1_0."ACTIVE",
            r1_0."CREATED_BY",
            r1_0."CREATION_DATE",
            r1_0."FROM_RR_CODE",
            r1_0."FROM_RR_CODE_B10",
            r1_0."LAST_UPDATE_DATE",
            r1_0."LAST_UPDATED_BY",
            r1_0."TO_RR_CODE",
            r1_0."TO_RR_CODE_B10"
        from
            "IAM_V2"."RR_CODE_RANGE" r1_0
        join
          "IAM_V2"."FIRM_ASSIGNMENT" f1_0
                on r1_0."RR_CODE_RANGE_ID"=f1_0."ASSIGNEE_ID"
        join "IAM_V2"."FIRM" f2_0
                on f1_0."FIRM_ENTITY_ID"=f2_0."FIRM_ENTITY_ID"
        where
            f2_0."FIRM_ID" = :firmId
            and cast(f1_0."ASSIGNMENT_TYPE" as text) = :assignmentType
      """;

  public static final String FIRM_QUERY = """
      SELECT
          f."FIRM_ENTITY_ID" AS firmEntityId,
          f."FIRM_ID" AS firmId,
          f."NAME" AS firmName,
          f."ACTIVE" AS isActive,
          f."STATE" AS firmState,
          f."TYPE" AS firmType,
          f."PARENT_FIRM_ID" AS parentFirmId,
          f."CREATION_DATE" AS creationDate,
          f."LAST_UPDATE_DATE" AS lastUpdatedDate,
          fe."BROKER_CODE" as brokerCode,
          fe."B_NUMBER" as brokerNo,
          fe."DEALER_CODE" as branchNo,
          f."IDENTITY_SOURCE" as identitySource,
          f."CX_ACCESS_UNSET_KEY" as cxAccessUnsetKey,
          f."USER_LOGOUT_URL" as userLogoutUrl,
          f."INITIAL_ACTIVITY_DAYS" as initialActivityDays,
          f."EXTENDED_ACTIVITY_DAYS" as extendedActivityDays,
          f."CREATED_BY" AS createdBy,
          f."LAST_UPDATED_BY" AS lastUpdatedBy,
          f."FIRM_PREFERENCES" AS firmPreferences
          %s
      FROM
          "IAM_V2"."FIRM" f
      JOIN
      	"IAM_V2"."FINANCIAL_ENTITY" fe ON fe."FINANCIAL_ENTITY_ID" = f."FINANCIAL_ENTITY_ID" LEFT JOIN
      	"IAM_V2"."FIRM" fparent ON fparent."FIRM_ID" = f."PARENT_FIRM_ID"
      %s
      LEFT JOIN
          "IAM_V2"."USER_ASSIGNMENT" ua ON (fparent."FIRM_ENTITY_ID" = ua."ASSIGNEE_ID" OR f."FIRM_ENTITY_ID" = ua."ASSIGNEE_ID") AND ua."ASSIGNMENT_TYPE" = 'F'
      WHERE
          ua."IDP_SUBJECT" = :idpSubject AND f."FIRM_ID" = :firmId
      %s
      """;

  public static final String FIRM_QUERY_CHILD_FIRM = ", STRING_AGG(f2.\"FIRM_ENTITY_ID\"::text, ',') AS childFirms";

  public static final String FIRM_QUERY_JOIN = "LEFT JOIN \"IAM_V2\".\"FIRM\" f2 ON f.\"FIRM_ID\" = f2.\"PARENT_FIRM_ID\"";
  public static final String FIRM_QUERY_GROUP_BY = """
      GROUP BY
          f."FIRM_ENTITY_ID",
          f."FIRM_ID",
          f."NAME",
          f."ACTIVE",
          f."STATE",
          f."TYPE",
          f."PARENT_FIRM_ID",
          f."CREATION_DATE",
          f."LAST_UPDATE_DATE",
          f."CREATED_BY",
          f."LAST_UPDATED_BY",
          fe."BROKER_CODE",
          fe."B_NUMBER",
          fe."DEALER_CODE",
          f."IDENTITY_SOURCE",
          f."CX_ACCESS_UNSET_KEY",
          f."USER_LOGOUT_URL",
          f."INITIAL_ACTIVITY_DAYS",
          f."EXTENDED_ACTIVITY_DAYS",
          f."FIRM_PREFERENCES";
      """;

  public static final String FIRM_FEATURE_PACKAGE_QUERY = """
      SELECT
        fp."FEATURE_PACKAGE_ID",
        fp."VERSION",
        fp."PACKAGE_TEMPLATE_ID",
        fp."ACTIVE",
        fp."CREATED_BY",
        fp."CREATED_DT",
        fp."UPDATED_BY",
        fp."UPDATED_DT"
      FROM
        "IAM_V2"."FEATURE_PACKAGE" fp
      JOIN
        "IAM_V2"."FIRM_ASSIGNMENT" fa ON fp."FEATURE_PACKAGE_ID"=fa."ASSIGNEE_ID"
      WHERE
        fa."FIRM_ENTITY_ID" = :firmEntityId
        AND cast(fa."ASSIGNMENT_TYPE" as text)= 'P'
      """;
  private Constants() {
    throw new IllegalStateException("Utility class");
  }
}
