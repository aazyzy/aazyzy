package ca.bnc.wealth.common.fum.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.enums.FirmAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackageAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackageAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class FeaturePackageServiceHelperTest {

  private FeaturePackageServiceHelper featurePackageServiceHelper;
  @MockitoBean
  private PackageTemplateRepository packageTemplateRepository;
  @MockitoBean
  private FeaturePackageTemplateServiceHelper featurePackageTemplateServiceHelper;
  @MockitoBean
  private FeaturePackageRepository featurePackageRepository;
  @MockitoBean
  private FeaturePackageAssignmentUserGroupRepository featurePackageAssignmentUserGroupRepository;
  @MockitoBean
  private FeaturePackageAssignmentResourceRepository featurePackageAssignmentResourceRepository;
  @MockitoBean
  private PackageTemplateServiceHelper packageTemplateServiceHelper;

  @MockitoBean
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
  @MockitoBean
  private PackageTemplateAssignmentUserGroupRepository packageTemplateAssignmentUserGroupRepository;
  @MockitoBean
  private PackageTemplateAssignmentResourceRepository packageTemplateAssignmentResourceRepository;
  @MockitoBean
  private UserAssignmentService userAssignmentService;
  @MockitoBean
  private FirmAssignmentService firmAssignmentService;

  @Before
  public void setup() throws IllegalAccessException {
    featurePackageServiceHelper = new FeaturePackageServiceHelper();
    FieldUtils.writeField(featurePackageServiceHelper, "packageTemplateRepository",
        packageTemplateRepository, true);
    FieldUtils.writeField(featurePackageServiceHelper, "featurePackageTemplateServiceHelper",
        featurePackageTemplateServiceHelper, true);
    FieldUtils.writeField(featurePackageServiceHelper, "featurePackageRepository",
        featurePackageRepository, true);
    FieldUtils.writeField(featurePackageServiceHelper, "featurePackageAssignmentUserGroupRepository",
        featurePackageAssignmentUserGroupRepository, true);
    FieldUtils.writeField(featurePackageServiceHelper, "featurePackageAssignmentResourceRepository",
        featurePackageAssignmentResourceRepository, true);
    FieldUtils.writeField(featurePackageServiceHelper, "namedParameterJdbcTemplate",
        namedParameterJdbcTemplate, true);
    FieldUtils.writeField(featurePackageServiceHelper, "packageTemplateServiceHelper",
        packageTemplateServiceHelper, true);
    FieldUtils.writeField(featurePackageServiceHelper, "userAssignmentService",
        userAssignmentService, true);
    FieldUtils.writeField(featurePackageServiceHelper, "firmAssignmentService",
        firmAssignmentService, true);
  }

  @Test
  public void createFeaturePackage_withModuleOverride() {
    PackageTemplate packageTemplate = new PackageTemplate();
    packageTemplate.setPackageTemplateId(1);
    when(packageTemplateRepository.findByName(anyString())).thenReturn(Optional.of(packageTemplate));

    PackageTemplateAssignmentUserGroup ptaug = new PackageTemplateAssignmentUserGroup();
    ptaug.setTemplateAssignmentId(1);
    when(featurePackageTemplateServiceHelper.getJpaSpecificationExecutorForPtAssignment(eq(
        PackageAssignmentType.G))).thenReturn(packageTemplateAssignmentUserGroupRepository);
    when(packageTemplateAssignmentUserGroupRepository.findAll(any(Specification.class))).thenReturn(
        List.of(ptaug));

    PackageTemplateAssignmentResource ptar1 = new PackageTemplateAssignmentResource();
    ptar1.setTemplateAssignmentId(2);
    Resource resource = new Resource();
    resource.setName("resource");
    resource.setRestriction(true);
    ptar1.setResource(resource);
    PackageTemplateAssignmentResource ptar2 = new PackageTemplateAssignmentResource();
    ptar2.setTemplateAssignmentId(3);
    Resource resource2 = new Resource();
    resource2.setName("resource1");
    resource2.setRestriction(false);
    ptar2.setResource(resource2);
    when(featurePackageTemplateServiceHelper.getJpaSpecificationExecutorForPtAssignment(eq(
        PackageAssignmentType.S))).thenReturn(packageTemplateAssignmentResourceRepository);
    when(packageTemplateAssignmentResourceRepository.findAll(any(Specification.class))).thenReturn(List.of(ptar1, ptar2));

    when(featurePackageRepository.save(any())).thenReturn(new ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage());

    Map<Long, EntityInterface> map1 = new HashMap<>();
    map1.put(1l, ptaug);
    when(packageTemplateServiceHelper.getPackageTemplateAssignment(anyLong(), eq(PackageAssignmentType.G))).thenReturn(map1);
    Map<Long, EntityInterface> map2 = new HashMap<>();
    map2.put(2l, ptar1);
    map2.put(3l, ptar2);
    when(packageTemplateServiceHelper.getPackageTemplateAssignment(anyLong(), eq(PackageAssignmentType.S))).thenReturn(map2);

    featurePackageServiceHelper.createFeaturePackage("packageTempleteName", Arrays.asList("resource"), Arrays.asList("resource"), "idpSubject");

    verify(featurePackageAssignmentUserGroupRepository, times(1)).save(any());
    verify(featurePackageAssignmentResourceRepository, times(2)).save(any());
  }

  @Test
  public void testCreateFeaturePackage() {
    PackageTemplate packageTemplate = new PackageTemplate();
    packageTemplate.setPackageTemplateId(1);
    when(packageTemplateRepository.findById(any())).thenReturn(Optional.of(packageTemplate));

    PackageTemplateAssignmentUserGroup ptaug = new PackageTemplateAssignmentUserGroup();
    ptaug.setTemplateAssignmentId(1);
    when(featurePackageTemplateServiceHelper.getJpaSpecificationExecutorForPtAssignment(eq(
        PackageAssignmentType.G))).thenReturn(packageTemplateAssignmentUserGroupRepository);
    when(packageTemplateAssignmentUserGroupRepository.findAll(any(Specification.class))).thenReturn(
        List.of(ptaug));

    PackageTemplateAssignmentResource ptar = new PackageTemplateAssignmentResource();
    ptar.setTemplateAssignmentId(2);
    when(featurePackageTemplateServiceHelper.getJpaSpecificationExecutorForPtAssignment(eq(
        PackageAssignmentType.S))).thenReturn(packageTemplateAssignmentResourceRepository);
    when(packageTemplateAssignmentResourceRepository.findAll(any(Specification.class))).thenReturn(List.of(ptar));

    when(featurePackageRepository.save(any())).thenReturn(new ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage());

    List<Pair<Integer, Boolean>> assignmentSelectionPairList = new ArrayList<>();
    assignmentSelectionPairList.add(Pair.of(1, true));
    assignmentSelectionPairList.add(Pair.of(2, true));

    Map<Long, EntityInterface> map1 = new HashMap<>();
    map1.put(1l, ptaug);
    when(packageTemplateServiceHelper.getPackageTemplateAssignment(anyLong(), eq(PackageAssignmentType.G))).thenReturn(map1);
    Map<Long, EntityInterface> map2 = new HashMap<>();
    map2.put(2l, ptar);
    when(packageTemplateServiceHelper.getPackageTemplateAssignment(anyLong(), eq(PackageAssignmentType.S))).thenReturn(map2);

    featurePackageServiceHelper.createFeaturePackage(1,assignmentSelectionPairList, "idpSubject");

    verify(featurePackageAssignmentUserGroupRepository, times(1)).save(any());
    verify(featurePackageAssignmentResourceRepository, times(1)).save(any());
  }

  @Test(expected = FumNotFoundException.class)
  public void deleteFeaturePackage_whenFeaturePackageHasUserAssignment_shouldThrowFumNotFoundException() {
    featurePackageServiceHelper.deleteFeaturePackage(123);
  }

  @Test(expected = FumValidationException.class)
  public void deleteFeaturePackage_whenFeaturePackageHasUserAssignment_shouldThrowFumValidationException() {
    FeaturePackage mockFeaturePackage = getFeaturePackage();
    when(featurePackageRepository.findById(anyLong())).thenReturn(
        Optional.of(mockFeaturePackage));
    when(userAssignmentService.hasUserAssignment(anyInt(), eq(UserAssignmentType.P))).thenReturn(true);
    when(firmAssignmentService.hasFirmAssignment(anyInt(), eq(FirmAssignmentType.P))).thenReturn(true);
    featurePackageServiceHelper.deleteFeaturePackage(123);
  }

  @Test(expected = FumValidationException.class)
  public void deleteFeaturePackage_whenFeaturePackageHasFirmAssignment_shouldThrowFumValidationException() {
    FeaturePackage mockFeaturePackage = getFeaturePackage();
    when(featurePackageRepository.findById(anyLong())).thenReturn(
        Optional.of(mockFeaturePackage));
    when(userAssignmentService.hasUserAssignment(anyInt(), eq(UserAssignmentType.P))).thenReturn(false);
    when(firmAssignmentService.hasFirmAssignment(anyInt(), eq(FirmAssignmentType.P))).thenReturn(true);
    featurePackageServiceHelper.deleteFeaturePackage(123);
  }

  @Test
  public void deleteFeaturePackage_whenFeaturePackageHasNoFirmAndUserAssignment_shouldDeleteFeaturePackage() {
    FeaturePackage mockFeaturePackage = getFeaturePackage();
    when(featurePackageRepository.findById(anyLong())).thenReturn(
        Optional.of(mockFeaturePackage));
    when(userAssignmentService.hasUserAssignment(anyInt(), eq(UserAssignmentType.P))).thenReturn(false);
    when(firmAssignmentService.hasFirmAssignment(anyInt(), eq(FirmAssignmentType.P))).thenReturn(false);
    when(featurePackageTemplateServiceHelper.getJpaSpecificationExecutorForFpAssignment(eq(PackageAssignmentType.G))).thenReturn(featurePackageAssignmentUserGroupRepository);
    when(featurePackageTemplateServiceHelper.getJpaSpecificationExecutorForFpAssignment(eq(PackageAssignmentType.S))).thenReturn(featurePackageAssignmentResourceRepository);
    when(featurePackageTemplateServiceHelper.getJpaRepositoryForFpAssignment(eq(PackageAssignmentType.G))).thenReturn(featurePackageAssignmentUserGroupRepository);
    when(featurePackageTemplateServiceHelper.getJpaRepositoryForFpAssignment(eq(PackageAssignmentType.S))).thenReturn(featurePackageAssignmentResourceRepository);

    when(featurePackageAssignmentUserGroupRepository.findAll(any(Specification.class))).thenReturn(
        Collections.emptyList());
    when(featurePackageAssignmentResourceRepository.findAll(any(Specification.class))).thenReturn(
        Collections.emptyList());

    featurePackageServiceHelper.deleteFeaturePackage(123);
  }

  @Test(expected = Exception.class)
  public void createFeaturePackage_whenNoPackageTemplateFound_shouldThrowFumNotFoundException() {
    when(packageTemplateServiceHelper.getPackageTemplate(anyLong())).thenThrow( new FumNotFoundException("", ""));
    featurePackageServiceHelper.createFeaturePackage(anyLong(), anyList(), anyString());
  }

  @Test(expected = FumValidationException.class)
  public void createFeaturePackage_whenFeaturePackageRequestAssignmentsDoNotMatchActualAssignments_shouldThrowFumValidationException() {
    when(packageTemplateServiceHelper.getPackageTemplate(anyLong())).thenReturn(getPackageTemplateEntity());
    Map<Long, EntityInterface> ptaugs = new HashMap<>();
    ptaugs.put(123l, getPackageTemplateAssignmentUserGroup());
    when(packageTemplateServiceHelper.getPackageTemplateAssignment(anyLong(), eq(PackageAssignmentType.G)))
        .thenReturn(ptaugs);
    Map<Long, EntityInterface> ptars = new HashMap<>();
        ptars.put(345l,getPackageTemplateAssignmentResource());
    when(packageTemplateServiceHelper.getPackageTemplateAssignment(anyLong(), eq(PackageAssignmentType.S)))
        .thenReturn(ptars);
    List<Pair<Integer, Boolean>> assignmentSelectionPairList = new ArrayList<>();
    featurePackageServiceHelper.createFeaturePackage(1, assignmentSelectionPairList, "idp");
  }

  @Test(expected = FumValidationException.class)
  public void createFeaturePackage_whenActiveInInputNotTrue_shouldThrowFumValidationException() {
    when(packageTemplateServiceHelper.getPackageTemplate(anyLong())).thenReturn(getPackageTemplateEntity());
    Map<Long, EntityInterface> ptaugs = new HashMap<>();
    ptaugs.put(123l, getPackageTemplateAssignmentUserGroup());
    when(packageTemplateServiceHelper.getPackageTemplateAssignment(anyLong(), eq(PackageAssignmentType.G)))
        .thenReturn(ptaugs);
    Map<Long, EntityInterface> ptars = new HashMap<>();
    ptars.put(345l,getPackageTemplateAssignmentResource());
    when(packageTemplateServiceHelper.getPackageTemplateAssignment(anyLong(), eq(PackageAssignmentType.S)))
        .thenReturn(ptars);
    List<Pair<Integer, Boolean>> assignmentSelectionPairList = new ArrayList<>();
    assignmentSelectionPairList.add(Pair.of(123, false));
    assignmentSelectionPairList.add(Pair.of(345, false));
    featurePackageServiceHelper.createFeaturePackage(1, assignmentSelectionPairList, "idp");
  }

  @Test
  public void createFeaturePackage_whenFeaturePackageRequestIsValid_shouldCreateFeaturePackage() {
    when(packageTemplateServiceHelper.getPackageTemplate(anyLong())).thenReturn(getPackageTemplateEntity());
    Map<Long, EntityInterface> ptaugs = new HashMap<>();
    ptaugs.put(123l, getPackageTemplateAssignmentUserGroup());
    when(packageTemplateServiceHelper.getPackageTemplateAssignment(anyLong(), eq(PackageAssignmentType.G)))
        .thenReturn(ptaugs);
    Map<Long, EntityInterface> ptars = new HashMap<>();
    ptars.put(345l,getPackageTemplateAssignmentResource());
    when(packageTemplateServiceHelper.getPackageTemplateAssignment(anyLong(), eq(PackageAssignmentType.S)))
        .thenReturn(ptars);
    List<Pair<Integer, Boolean>> assignmentSelectionPairList = new ArrayList<>();
    assignmentSelectionPairList.add(Pair.of(123, true));
    assignmentSelectionPairList.add(Pair.of(345, true));
    featurePackageServiceHelper.createFeaturePackage(1, assignmentSelectionPairList, "idp");
  }

  @Test
  public void updateFeaturePackageAssignments_whenFeaturePackageRequestIsValid_shouldUpdateFeaturePackage() {
    when(featurePackageRepository.findById(anyLong())).thenReturn(
        Optional.of(getFeaturePackage()));
    when(packageTemplateServiceHelper.getPackageTemplate(anyLong())).thenReturn(getPackageTemplateEntity());
    Map<Long, EntityInterface> ptaugs = new HashMap<>();
    ptaugs.put(123l, getPackageTemplateAssignmentUserGroup());
    when(packageTemplateServiceHelper.getPackageTemplateAssignment(anyLong(), eq(PackageAssignmentType.G)))
        .thenReturn(ptaugs);
    Map<Long, EntityInterface> ptars = new HashMap<>();
    ptars.put(345l,getPackageTemplateAssignmentResource());
    when(packageTemplateServiceHelper.getPackageTemplateAssignment(anyLong(), eq(PackageAssignmentType.S)))
        .thenReturn(ptars);
    when(featurePackageTemplateServiceHelper.getJpaSpecificationExecutorForFpAssignment(eq(PackageAssignmentType.G))).thenReturn(featurePackageAssignmentUserGroupRepository);
    when(featurePackageTemplateServiceHelper.getJpaSpecificationExecutorForFpAssignment(eq(PackageAssignmentType.S))).thenReturn(featurePackageAssignmentResourceRepository);

    List<Pair<Integer, Boolean>> assignmentSelectionPairList = new ArrayList<>();
    assignmentSelectionPairList.add(Pair.of(123, true));
    assignmentSelectionPairList.add(Pair.of(345, true));
    featurePackageServiceHelper.updateFeaturePackage(11,123, assignmentSelectionPairList, "idp");
  }

  @Test
  public void testGetFeaturePackageAssignmentResources_returnsResources() {
    Integer featurePackageId = 123;
    String resourceName = "resource1";
    FeaturePackageAssignmentResource resource = new FeaturePackageAssignmentResource();
    List<FeaturePackageAssignmentResource> expectedList = List.of(resource);

    when(featurePackageAssignmentResourceRepository.findAll(any(Specification.class)))
        .thenReturn(expectedList);

    List<FeaturePackageAssignmentResource> result =
        featurePackageServiceHelper.getFeaturePackageAssignmentResources(featurePackageId, resourceName);

    assertEquals(expectedList, result);
    verify(featurePackageAssignmentResourceRepository, times(1)).findAll(any(Specification.class));
  }

  @Test
  public void testFeaturePackageHasResourceType_returnsTrueWhenResourceTypeExists() {
    ca.bnc.wealth.common.userconfiguration.model.FeaturePackage featurePackage =
        new ca.bnc.wealth.common.userconfiguration.model.FeaturePackage();
    featurePackage.setPackageName("packageTemplate");
    featurePackage.setFeatures(Arrays.asList("resource1"));

    PackageTemplateAssignmentResource ptar = new PackageTemplateAssignmentResource();
    Resource resource = new Resource();
    resource.setType("type1");
    resource.setName("resource1");
    ptar.setResource(resource);

    when(packageTemplateServiceHelper.getPackageTemplateAssignmentResourceType(anyString(), anyString()))
        .thenReturn(Arrays.asList(ptar));

    boolean result = featurePackageServiceHelper.featurePackageHasResourceType(featurePackage, "type1");
    assertEquals(true, result);
  }

  @Test
  public void testFeaturePackageHasResource_returnsTrueForAssignmentModeM() {
    ca.bnc.wealth.common.userconfiguration.model.FeaturePackage featurePackage =
        new ca.bnc.wealth.common.userconfiguration.model.FeaturePackage();
    featurePackage.setPackageName("packageTemplate");

    PackageTemplateAssignmentResource ptar = new PackageTemplateAssignmentResource();
    ptar.setAssignmentMode(PackageAssignmentMode.M);
    ptar.setTemplateAssignmentId(1);

    boolean result = featurePackageServiceHelper.featurePackageHasResource(featurePackage, "resource1", Arrays.asList(ptar));
    assertEquals(true, result);
  }

  @Test
  public void testFeaturePackageHasResource_returnsFalseForNonMatchingFeatures() {
    ca.bnc.wealth.common.userconfiguration.model.FeaturePackage featurePackage =
        new ca.bnc.wealth.common.userconfiguration.model.FeaturePackage();
    featurePackage.setPackageName("packageTemplate");
    featurePackage.setFeatures(Arrays.asList("otherResource"));

    PackageTemplateAssignmentResource ptar = new PackageTemplateAssignmentResource();
    ptar.setAssignmentMode(PackageAssignmentMode.O);
    ptar.setTemplateAssignmentId(1);

    boolean result = featurePackageServiceHelper.featurePackageHasResource(featurePackage, "resource1", Arrays.asList(ptar));
    assertEquals(false, result);
  }

  public static FeaturePackage getFeaturePackage() {
    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setActive(true);
    featurePackage.setPackageTemplate(getPackageTemplateEntity());
    featurePackage.setFeaturePackageId(132);
    featurePackage.setFeaturePackageAssignmentResources(Arrays.asList(getFeaturePackageAssignmentResource()));
    featurePackage.setFeaturePackageAssignmentUserGroups(Arrays.asList(getFeaturePackageAssignmentUserGroup()));
    return featurePackage;
  }

  public static PackageTemplate getPackageTemplateEntity() {
    PackageTemplate packageTemplate = new PackageTemplate();
    packageTemplate.setPackageTemplateId(1234L);
    packageTemplate.setName("packageTemplate");
    packageTemplate.setDescription("description");
    packageTemplate.setActive(true);
    packageTemplate.setType(PackageType.F);
    packageTemplate.setFirmType(FirmType.IB);
    packageTemplate.setPackageTemplateAssignmentResources(Arrays.asList(getPackageTemplateAssignmentResource()));
    packageTemplate.setPackageTemplateAssignmentUserGroups(Arrays.asList(getPackageTemplateAssignmentUserGroup()));
    return packageTemplate;
  }

  public static FeaturePackageAssignmentResource getFeaturePackageAssignmentResource() {
    FeaturePackageAssignmentResource resource = new FeaturePackageAssignmentResource();
    resource.setFeaturePackage(new FeaturePackage());
    resource.setSelected(true);
    resource.setFeaturePackageAssignmentId(1234);
    resource.setPackageTemplateAssignmentResource(getPackageTemplateAssignmentResource());
    return resource;
  }

  public static FeaturePackageAssignmentUserGroup getFeaturePackageAssignmentUserGroup() {
    FeaturePackageAssignmentUserGroup userGroup = new FeaturePackageAssignmentUserGroup();
    userGroup.setFeaturePackage(new FeaturePackage());
    userGroup.setFeaturePackageAssignmentId(1234);
    userGroup.setPackageTemplateAssignmentUserGroup(getPackageTemplateAssignmentUserGroup());
    userGroup.setSelected(true);
    return userGroup;
  }
  public static PackageTemplateAssignmentResource getPackageTemplateAssignmentResource() {
    PackageTemplateAssignmentResource resource = new PackageTemplateAssignmentResource();
    resource.setTemplateAssignmentId(345);
    resource.setResource(getResourceEntity());
    resource.setAssignmentType(PackageAssignmentType.S);
    resource.setAssignmentMode(PackageAssignmentMode.O);
    return resource;
  }

  public static PackageTemplateAssignmentUserGroup getPackageTemplateAssignmentUserGroup() {
    PackageTemplateAssignmentUserGroup userGroup = new PackageTemplateAssignmentUserGroup();
    userGroup.setTemplateAssignmentId(123);
    userGroup.setAssignmentMode(PackageAssignmentMode.M);
    userGroup.setAssignmentType(PackageAssignmentType.G);
    userGroup.setUserGroup(getUserGroupEntity());
    return userGroup;
  }

  public static Resource getResourceEntity() {
    return getResourceEntityList().get(0);
  }

  public static List<Resource> getResourceEntityList() {
    Resource resource1 = new Resource();
    resource1.setName("resource1");
    resource1.setDescription("res desc");
    resource1.setConfUri("conf");
    resource1.setResourceId(1234L);
    resource1.setActive(true);
    resource1.setGroupName("groupName");
    resource1.setLabel("label2");
    resource1.setPurpose("purpose2");
    resource1.setRestriction(true);

    Resource resource2 = new Resource();
    resource2.setName("resource2");
    resource2.setDescription("res desc");
    resource2.setConfUri("conf");
    resource2.setResourceId(1234L);
    resource2.setActive(true);
    resource2.setGroupName("groupName");
    resource2.setLabel("label2");
    resource2.setPurpose("purpose2");
    resource2.setRestriction(false);

    return Arrays.asList(resource1, resource2);
  }

  public static ca.bnc.wealth.common.jpa.entity.iam.UserGroup getUserGroupEntity() {
    ca.bnc.wealth.common.jpa.entity.iam.UserGroup userGroup = new ca.bnc.wealth.common.jpa.entity.iam.UserGroup();
    userGroup.setIsFirmScope(true);
    userGroup.setUserGroupId(1234L);
    userGroup.setName("usergroup");
    userGroup.setIsInternal(true);
    userGroup.setDescription("usergroup desc");
    return userGroup;
  }
}
