package ca.bnc.wealth.common.fum.service;

import static org.junit.Assert.assertTrue;

import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentUserGroupRepository;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class FeaturePackageTemplateServiceHelperTest {

  private  FeaturePackageTemplateServiceHelper featurePackageTemplateServiceHelper;

  @MockitoBean
  private PackageTemplateAssignmentUserGroupRepository packageTemplateAssignmentUserGroupRepository;
  @MockitoBean
  private PackageTemplateAssignmentResourceRepository packageTemplateAssignmentResourceRepository;
  @MockitoBean
  private FeaturePackageAssignmentUserGroupRepository featurePackageAssignmentUserGroupRepository;
  @MockitoBean
  private FeaturePackageAssignmentResourceRepository featurePackageAssignmentResourceRepository;

  @Before
  public void setup() throws IllegalAccessException {
    featurePackageTemplateServiceHelper = new FeaturePackageTemplateServiceHelper();
    FieldUtils.writeField(featurePackageTemplateServiceHelper, "packageTemplateAssignmentUserGroupRepository",
        packageTemplateAssignmentUserGroupRepository, true);
    FieldUtils.writeField(featurePackageTemplateServiceHelper, "packageTemplateAssignmentResourceRepository",
        packageTemplateAssignmentResourceRepository, true);
    FieldUtils.writeField(featurePackageTemplateServiceHelper, "featurePackageAssignmentUserGroupRepository",
        featurePackageAssignmentUserGroupRepository, true);
    FieldUtils.writeField(featurePackageTemplateServiceHelper, "featurePackageAssignmentResourceRepository",
        featurePackageAssignmentResourceRepository, true);
  }

  @Test
  public void testAll() {
    assertTrue(featurePackageTemplateServiceHelper.getJpaRepositoryForPtAssignment(
        PackageAssignmentType.G) == packageTemplateAssignmentUserGroupRepository);
    assertTrue(featurePackageTemplateServiceHelper.getJpaRepositoryForPtAssignment(
        PackageAssignmentType.S) == packageTemplateAssignmentResourceRepository);

    assertTrue(featurePackageTemplateServiceHelper.getJpaSpecificationExecutorForPtAssignment(
        PackageAssignmentType.G) == packageTemplateAssignmentUserGroupRepository);
    assertTrue(featurePackageTemplateServiceHelper.getJpaSpecificationExecutorForPtAssignment(
        PackageAssignmentType.S) == packageTemplateAssignmentResourceRepository);

    assertTrue(featurePackageTemplateServiceHelper.getJpaRepositoryForFpAssignment(
        PackageAssignmentType.G) == featurePackageAssignmentUserGroupRepository);
    assertTrue(featurePackageTemplateServiceHelper.getJpaRepositoryForFpAssignment(
        PackageAssignmentType.S) == featurePackageAssignmentResourceRepository);

    assertTrue(featurePackageTemplateServiceHelper.getJpaSpecificationExecutorForFpAssignment(
        PackageAssignmentType.G) == featurePackageAssignmentUserGroupRepository);
    assertTrue(featurePackageTemplateServiceHelper.getJpaSpecificationExecutorForFpAssignment(
        PackageAssignmentType.S) == featurePackageAssignmentResourceRepository);
  }

}
