package ca.bnc.wealth.common.fum.service;

import ca.bnc.wealth.common.jpa.repo.iam.FirmAssignmentFeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmAssignmentRrCodeRangeRepository;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class FirmAssignmentServiceTest {

  FirmAssignmentService firmAssignmentService;

  @MockitoBean
  private FirmAssignmentServiceHelper firmAssignmentServiceHelper;

  @MockitoBean
  private FirmAssignmentRepository firmAssignmentRepository;

  @MockitoBean
  private FirmAssignmentRrCodeRangeRepository firmAssignmentRrCodeRangeRepository;

  @MockitoBean
  private FirmAssignmentFeaturePackageRepository firmAssignmentFeaturePackageRepository;

  @MockitoBean
  private RedisCacheOperationService redisCacheOperationService;


  @Before
  public void setup() throws IllegalAccessException {
    firmAssignmentService = new FirmAssignmentService();
    FieldUtils.writeField(firmAssignmentService, "firmAssignmentServiceHelper",
        firmAssignmentServiceHelper, true);
    FieldUtils.writeField(firmAssignmentService, "firmAssignmentRepository",
        firmAssignmentRepository, true);
    FieldUtils.writeField(firmAssignmentService, "firmAssignmentRrCodeRangeRepository",
        firmAssignmentRrCodeRangeRepository, true);
    FieldUtils.writeField(firmAssignmentService, "firmAssignmentFeaturePackageRepository",
        firmAssignmentFeaturePackageRepository, true);
    FieldUtils.writeField(firmAssignmentService, "redisCacheOperationService",
        redisCacheOperationService, true);
  }

  @Test
  public void deleteFirmAssignment_rrCode() {


    firmAssignmentService.deleteFirmAssignment("NBIN", "R", 123,"idp");
  }

  @Test
  public void deleteFirmAssignment_featuePackage() {
    firmAssignmentService.deleteFirmAssignment("NBIN", "P", 123,"idp");
  }

  @Test(expected = Exception.class)
  public void deleteFirmAssignment_invalid() {
    firmAssignmentService.deleteFirmAssignment("NBIN", "Pd", 123,"idp");
  }
}
