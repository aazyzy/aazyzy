package ca.bnc.wealth.common.fum.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.enums.FirmAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.FinancialEntity;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.FirmAssignmentRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.repo.iam.FinancialEntityRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class FirmServiceHelperTest {


  private FirmServiceHelper firmServiceHelper;

  @MockitoBean
  FirmRepository firmRepository;
  @MockitoBean
  private IamUserConfigurationRepository iamUserConfigurationRepository;
  @MockitoBean
  private IamRrCodeRangeRepository iamRrCodeRangeRepository;
  @MockitoBean
  private UserAssignmentRrCodeRangeRepository userAssignmentRrCodeRangeRepository;
  @MockitoBean
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
  @MockitoBean
  private FirmStateService firmStateService;
  @MockitoBean
  private RrCodeServiceHelper rrCodeServiceHelper;
  @MockitoBean
  private FinancialEntityRepository financialEntityRepository;
  @MockitoBean
  private FirmAssignmentService firmAssignmentService;
  @MockitoBean
  private FeaturePackageServiceHelper featurePackageServiceHelper;
  @MockitoBean
  private UserAssignmentService userAssignmentService;
  @MockitoBean
  private RedisCacheOperationService redisCacheOperationService;
  @MockitoBean
  private UserServiceHelper userServiceHelper;

  @Before
  public void setup() throws IllegalAccessException {
    firmServiceHelper = new FirmServiceHelper();
    FieldUtils.writeField(firmServiceHelper, "firmRepository",
        firmRepository, true);
    FieldUtils.writeField(firmServiceHelper, "namedParameterJdbcTemplate",
        namedParameterJdbcTemplate, true);
    FieldUtils.writeField(firmServiceHelper, "firmStateService",
        firmStateService, true);
    FieldUtils.writeField(firmServiceHelper, "rrCodeServiceHelper",
        rrCodeServiceHelper, true);
    FieldUtils.writeField(firmServiceHelper, "financialEntityRepository",
        financialEntityRepository, true);
    FieldUtils.writeField(firmServiceHelper, "firmAssignmentService",
        firmAssignmentService, true);
    FieldUtils.writeField(firmServiceHelper, "featurePackageServiceHelper",
        featurePackageServiceHelper, true);
    FieldUtils.writeField(firmServiceHelper, "userAssignmentService",
        userAssignmentService, true);
    FieldUtils.writeField(firmServiceHelper, "redisCacheOperationService",
        redisCacheOperationService, true);
    FieldUtils.writeField(firmServiceHelper, "userServiceHelper",
        userServiceHelper, true);
  }

  @Test
  public void getPrimaryFirmByIdpSubjectUsingJdbc() {
    List<Map<String, Object>> lst = new ArrayList<>();
    Map<String,Object> map = new HashMap<>();
    map.put("firmId", "WATER");
    lst.add(map);
    when(namedParameterJdbcTemplate.queryForList(anyString(), any(SqlParameterSource.class))).thenReturn(lst);
    List<Map<String, Object>> response = firmServiceHelper.getPrimaryFirmByIdpSubjectUsingJdbc("idp", true);
    assertTrue(response.size() ==1);
    assertTrue(response.get(0).get("firmId").equals("WATER"));
  }

  @Test
  public void getPrimaryFirm() {
    Firm firm = new Firm();
    firm.setFirmId("WATER");
    when(firmRepository.findOne(any(Specification.class))).thenReturn(Optional.of(firm));
    Optional<Firm> response = firmServiceHelper.getPrimaryFirm("idp", null);
    assertTrue(response.isPresent());
    assertEquals("WATER", response.get().getFirmId());

  }
  @Test
  public void getPrimaryFirm_active() {
    Firm firm = new Firm();
    firm.setFirmId("WATER");
    when(firmRepository.findOne(any(Specification.class))).thenReturn(Optional.of(firm));
    Optional<Firm> response = firmServiceHelper.getPrimaryFirm("idp", true);
    assertTrue(response.isPresent());
    assertEquals("WATER", response.get().getFirmId());

  }

  @Test
  public void testPatchFirmStatus_active() {
    Firm firm = new Firm();
    firm.setState("active");
    firm.setFirmAssignmentRrCodeRanges(List.of(getFirmAssignmentRrCodeRange(FirmAssignmentType.R),
        getFirmAssignmentRrCodeRange(FirmAssignmentType.P)));
    when(firmRepository.findByFirmId(any())).thenReturn(firm);


    firmServiceHelper.updateFirmStatusPreferences("NBIN", "active", new HashMap<>(), "requestedBy");
    verify(firmRepository, times(1)).save(any());
    verify(firmStateService, times(1)).setActive(any(), any());

  }

  @Test
  public void testPatchFirmStatus_inactive() {
    Firm firm = new Firm();
    firm.setState("active");
    firm.setFirmAssignmentRrCodeRanges(List.of(getFirmAssignmentRrCodeRange(FirmAssignmentType.R),
        getFirmAssignmentRrCodeRange(FirmAssignmentType.P)));
    when(firmRepository.findByFirmId(any())).thenReturn(firm);


    when(firmRepository.findByFirmId(any())).thenReturn(firm);
    firmServiceHelper.updateFirmStatusPreferences("NBIN", "inactive", new HashMap<>(), "requestedBy");
    verify(firmRepository, times(1)).save(any());
    verify(firmStateService, times(1)).setInactive(any(), any());
  }

  @Test
  public void testPatchFirmStatus_onboarded() {
    Firm firm = new Firm();
    firm.setState("active");
    firm.setFirmAssignmentRrCodeRanges(List.of(getFirmAssignmentRrCodeRange(FirmAssignmentType.R),
        getFirmAssignmentRrCodeRange(FirmAssignmentType.P)));
    when(firmRepository.findByFirmId(any())).thenReturn(firm);

    when(firmRepository.findByFirmId(any())).thenReturn(firm);
    firmServiceHelper.updateFirmStatusPreferences("NBIN", "onboarded", new HashMap<>(),"requestedBy");
    when(userServiceHelper.getFirmUsers(eq("NBIN"), eq(null))).thenReturn(new ArrayList<>());
    verify(firmRepository, times(1)).save(any());
    verify(firmStateService, times(0)).setActive(any(), any());
    verify(firmStateService, times(0)).setInactive(any(), any());
  }

  @Test(expected = FumNotFoundException.class)
  public void testPatchFirmStatus_whenFirmNotFound_shouldThrowException() {
    when(firmRepository.findByFirmId(any())).thenReturn(null);
    firmServiceHelper.updateFirmStatusPreferences("NBIN", "", new HashMap<>(),"requestedBy");
  }

  @Test(expected = FumNotFoundException.class)
  public void testPatchFirmStatus_whenFirmIsDecommissioned_shouldThrowException() {
    Firm firm = new Firm();
    firm.setState("decommissioned");
    when(firmRepository.findByFirmId(any())).thenReturn(firm);
    firmServiceHelper.updateFirmStatusPreferences("NBIN", "", new HashMap<>(), "requestedBy");
  }

  @Test
  public void createFinancialEntityIfNotExist_create() {
    FinancialEntity financialEntity = new FinancialEntity();
    financialEntity.setBrokerCode("code");

    // When financial entity doesn't exist
    when(financialEntityRepository
        .findByBrokerCodeAndBranchNumberAndDealerCode(any(), any(), any())).thenReturn(financialEntity);

    Optional<FinancialEntity> response = firmServiceHelper.createFinancialEntityIfNotExist(financialEntity);
    assertTrue(response.isPresent());
    assertEquals(financialEntity.getBrokerCode(), response.get().getBrokerCode());
  }

  @Test
  public void createFinancialEntityIfNotExist_exist() {
    FinancialEntity financialEntity = new FinancialEntity();
    financialEntity.setBrokerCode("code");

    // When financial entity doesn't exist
    when(financialEntityRepository
        .findByBrokerCodeAndBranchNumberAndDealerCode(any(), any(), any())).thenReturn(financialEntity);
    Optional<FinancialEntity> response = firmServiceHelper.createFinancialEntityIfNotExist(financialEntity);
    assertTrue(response.isPresent());
    assertEquals(financialEntity.getBrokerCode(), response.get().getBrokerCode());
  }
  @Test
  public void testIsFinancialEntityInfoExist() {
    FinancialEntity financialEntity = new FinancialEntity();
    assertFalse(firmServiceHelper.isFinancialEntityInfoExist(financialEntity));

    financialEntity.setLegalEntityIdentifier("id");
    assertTrue(firmServiceHelper.isFinancialEntityInfoExist(financialEntity));

    financialEntity.setDealerCode("dealerCode");
    assertTrue(firmServiceHelper.isFinancialEntityInfoExist(financialEntity));

    financialEntity.setBranchNumber("number");
    assertTrue(firmServiceHelper.isFinancialEntityInfoExist(financialEntity));

    financialEntity.setBrokerCode("code");
    assertTrue(firmServiceHelper.isFinancialEntityInfoExist(financialEntity));
  }

  @Test
  public void setRRCodeRangeToFirm() {
    when(rrCodeServiceHelper.createRrCodeEntityIfNotExist(anyString(), anyString())).thenReturn(new IamRrCodeRange());
    firmServiceHelper.setRRCodeRangeToFirm(new Firm(), new ArrayList<>());
  }

  @Test
  public void createFirm() {
    when(rrCodeServiceHelper.createRrCodeEntityIfNotExist(anyString(), anyString())).thenReturn(new IamRrCodeRange());
    Firm firm = new Firm();
    firm.setFirmEntityId(1234l);
    firm.setFirmId("NBIN");
    when(firmRepository.findByFirmId(eq("NBIN"))).thenReturn(firm);
    Firm saved = new Firm();
    saved.setFirmId("new");
    saved.setFirmEntityId(11l);
    when(firmRepository.save(any(Firm.class))).thenReturn(saved);

    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setFeaturePackageId(123l);
    when(featurePackageServiceHelper.createFeaturePackage(any(Long.class), anyList(), anyString())).thenReturn(featurePackage);

    List<Pair<String, String>> rrCodes = new ArrayList<>();
    rrCodes.add(Pair.of("from", "to"));
    List<Pair<Integer, Boolean>> assignmentSelectionPairList = new ArrayList<>();
    assignmentSelectionPairList.add(Pair.of(123,true));
    firmServiceHelper.createFirm(new Firm(), new FinancialEntity(), "NBIN",  rrCodes, 123, assignmentSelectionPairList, "idp");
  }

  @Test
  public void updateFirm() {
    when(rrCodeServiceHelper.createRrCodeEntityIfNotExist(anyString(), anyString())).thenReturn(new IamRrCodeRange());
    Firm firm = new Firm();
    firm.setFirmEntityId(1234l);
    firm.setFirmId("NBIN");
    when(firmRepository.findByFirmId(eq("NBIN"))).thenReturn(firm);
    Firm saved = new Firm();
    saved.setFirmId("new");
    saved.setFirmEntityId(11l);
    when(firmRepository.save(any(Firm.class))).thenReturn(saved);

    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setFeaturePackageId(123l);
    when(featurePackageServiceHelper.createFeaturePackage(any(Long.class), anyList(), anyString())).thenReturn(featurePackage);


    List<Pair<String, String>> rrCodes = new ArrayList<>();
    rrCodes.add(Pair.of("from", "to"));
    List<Pair<Integer, Boolean>> assignmentSelectionPairList = new ArrayList<>();
    assignmentSelectionPairList.add(Pair.of(123,true));
    firmServiceHelper.updateFirm(new Firm(), new FinancialEntity(),  rrCodes, 123, assignmentSelectionPairList, "idp");

  }

  @Test
  public void testDecommissionFirm() {
    Firm firm = new Firm();
    firm.setActive(false);
    firm.setState("inactive");
    firm.setFirmEntityId(1L);
    firm.setFirmAssignmentRrCodeRanges(List.of(getFirmAssignmentRrCodeRange(FirmAssignmentType.R)));
    when(firmRepository.findByFirmId(any())).thenReturn(firm);

    firmServiceHelper.decommissionFirm("firmId");
    verify(firmStateService, times(1)).setDecommission(any());
    verify(firmRepository, times(1)).save(any());
  }

  @Test(expected = FumValidationException.class)
  public void testDecommissionFirm_whenFirmIsInactive_shouldThrowException() {
    Firm firm = new Firm();
    firm.setActive(true);
    when(firmRepository.findByFirmId(any())).thenReturn(firm);
    firmServiceHelper.decommissionFirm("firmId");
  }

  @Test(expected = FumValidationException.class)
  public void testDecommissionFirm_whenFirmIsAlreadyDecommissioned_shouldThrowException() {
    Firm firm = new Firm();
    firm.setActive(false);
    firm.setState("active");
    when(firmRepository.findByFirmId(any())).thenReturn(firm);
    firmServiceHelper.decommissionFirm("firmId");
  }

  private FirmAssignmentRrCodeRange getFirmAssignmentRrCodeRange(FirmAssignmentType type) {
    FirmAssignmentRrCodeRange farcr = new FirmAssignmentRrCodeRange();
    farcr.setAssignmentType(type);
    farcr.setIamRrCodeRange(new IamRrCodeRange());
    return farcr;
  }
}
