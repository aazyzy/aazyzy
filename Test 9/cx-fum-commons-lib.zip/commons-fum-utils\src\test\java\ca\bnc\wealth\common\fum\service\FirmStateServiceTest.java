package ca.bnc.wealth.common.fum.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.fum.model.FirmStateEnum;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.FirmAssignmentFeaturePackage;
import ca.bnc.wealth.common.jpa.repo.iam.FirmAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import java.util.ArrayList;
import java.util.List;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class FirmStateServiceTest {

  @MockitoBean
  private FirmRepository firmRepository;

  @MockitoBean
  private FirmAssignmentRepository firmAssignmentRepository;

  private FirmStateService firmStateService;

  @Before
  @SneakyThrows
  public void setup() {
    firmStateService = new FirmStateService();
    FieldUtils.writeField(firmStateService, "firmRepository", firmRepository, true);
    FieldUtils.writeField(firmStateService, "firmAssignmentRepository", firmAssignmentRepository, true);
  }

  @Test
  public void testSetStateOnCreate() {
    Firm firm = new Firm();
    firmStateService.setStateOnCreate(firm);

    assertEquals(false, firm.getActive());
    assertEquals(FirmStateEnum.ONBOARDED.label, firm.getState());
  }

  @Test
  public void testSaveStateOnUpdate() {
    Firm firm = new Firm();
    firm.setState("onboarded");
    firm.setFirmAssignmentFeaturePackages(List.of(new FirmAssignmentFeaturePackage()));
    when(firmRepository.findByFirmId(any())).thenReturn(firm);
    when(firmAssignmentRepository.count(any(Specification.class))).thenReturn(1L);

    firmStateService.saveStateOnUpdate("firmId");
    verify(firmRepository, times(1)).save(any());
  }

  @Test
  public void testSaveStateOnUpdate_whenFirmNotFound() {
    when(firmRepository.findByFirmId(any())).thenReturn(null);

    firmStateService.saveStateOnUpdate("firmId");
    verify(firmRepository, times(0)).save(any());
  }

  @Test
  public void testSaveStateOnUpdate_whenFirmNotOnboarded() {
    Firm firm = new Firm();
    firm.setState("active");
    when(firmRepository.findByFirmId(any())).thenReturn(firm);

    firmStateService.saveStateOnUpdate("firmId");
    verify(firmRepository, times(0)).save(any());
  }

  @Test
  public void testSaveStateOnUpdate_whenFirmAssignmentFeaturePackagesIsNull() {
    Firm firm = new Firm();
    firm.setState("onboarded");
    firm.setFirmAssignmentFeaturePackages(null);
    when(firmRepository.findByFirmId(any())).thenReturn(firm);

    firmStateService.saveStateOnUpdate("firmId");
    verify(firmRepository, times(0)).save(any());
  }

  @Test
  public void testSaveStateOnUpdate_whenFirmAssignmentFeaturePackagesIsEmpty() {
    Firm firm = new Firm();
    firm.setState("onboarded");
    firm.setFirmAssignmentFeaturePackages(new ArrayList<>());
    when(firmRepository.findByFirmId(any())).thenReturn(firm);

    firmStateService.saveStateOnUpdate("firmId");
    verify(firmRepository, times(0)).save(any());
  }

  @Test
  public void testSetActive_whenFirmIsActive() {
    Firm firm = new Firm();
    firm.setActive(true);
    firmStateService.setActive(firm, "requestedBy");

    assertEquals(true, firm.getActive());
    assertNotEquals(FirmStateEnum.ACTIVE.label, firm.getState());
    assertNull(firm.getStatusLastUpdated());
    assertNotEquals("requestedBy", firm.getLastUpdatedBy());
  }

  @Test
  public void testSetActive_whenFirmIsInactive() {
    Firm firm = new Firm();
    firm.setActive(false);
    firmStateService.setActive(firm, "requestedBy");

    assertEquals(true, firm.getActive());
    assertEquals(FirmStateEnum.ACTIVE.label, firm.getState());
    assertNotNull(firm.getStatusLastUpdated());
    assertEquals("requestedBy", firm.getLastUpdatedBy());
  }

  @Test
  public void testSetInactive_whenFirmIsActive() {
    Firm firm = new Firm();
    firm.setActive(true);
    firmStateService.setInactive(firm, "requestedBy");

    assertEquals(false, firm.getActive());
    assertEquals(FirmStateEnum.INACTIVE.label, firm.getState());
    assertNotNull(firm.getStatusLastUpdated());
    assertEquals("requestedBy", firm.getLastUpdatedBy());
  }

  @Test
  public void testSetInactive_whenFirmIsInactive() {
    Firm firm = new Firm();
    firm.setActive(false);
    firmStateService.setInactive(firm, "requestedBy");

    assertEquals(false, firm.getActive());
    assertNotEquals(FirmStateEnum.INACTIVE.label, firm.getState());
    assertNull(firm.getStatusLastUpdated());
    assertNotEquals("requestedBy", firm.getLastUpdatedBy());
  }

  @Test
  public void testSetDecommission() {
    Firm firm = new Firm();
    firmStateService.setDecommission(firm);

    assertEquals(false, firm.getActive());
    assertEquals(FirmStateEnum.DECOMMISSIONED.label, firm.getState());
    assertNotNull(firm.getStatusLastUpdated());
  }
}
