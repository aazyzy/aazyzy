package ca.bnc.wealth.common.fum.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.entity.iam.UserGroup;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserGroupRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.lang3.tuple.Triple;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class PackageTemplateServiceHelperTest {

  private PackageTemplateServiceHelper packageTemplateServiceHelper;
  @MockitoBean
  private FeaturePackageTemplateServiceHelper featurePackageTemplateServiceHelper;
  @MockitoBean
  private PackageTemplateRepository packageTemplateRepository;
  @MockitoBean
  private UserGroupRepository userGroupRepository;
  @MockitoBean
  private ResourceRepository resourceRepository;
  @MockitoBean
  private PackageTemplateAssignmentUserGroupRepository packageTemplateAssignmentUserGroupRepository;
  @MockitoBean
  private PackageTemplateAssignmentResourceRepository packageTemplateAssignmentResourceRepository;

  @Before
  public void setup() throws IllegalAccessException {
    packageTemplateServiceHelper = new PackageTemplateServiceHelper();
    FieldUtils.writeField(packageTemplateServiceHelper, "featurePackageTemplateServiceHelper",
        featurePackageTemplateServiceHelper, true);
    FieldUtils.writeField(packageTemplateServiceHelper, "packageTemplateRepository",
        packageTemplateRepository, true);
    FieldUtils.writeField(packageTemplateServiceHelper, "userGroupRepository",
        userGroupRepository, true);
    FieldUtils.writeField(packageTemplateServiceHelper, "resourceRepository",
        resourceRepository, true);
    FieldUtils.writeField(packageTemplateServiceHelper, "packageTemplateAssignmentUserGroupRepository",
        packageTemplateAssignmentUserGroupRepository, true);
    FieldUtils.writeField(packageTemplateServiceHelper, "packageTemplateAssignmentResourceRepository",
        packageTemplateAssignmentResourceRepository, true);
  }

  @Test(expected = FumNotFoundException.class)
  public void getPackageTemplate_notFound() {
    when(packageTemplateRepository.findById(anyLong())).thenReturn(Optional.empty());
    packageTemplateServiceHelper.getPackageTemplate(123l);
  }

  @Test
  public void getPackageTemplate_found() {
    when(packageTemplateRepository.findById(anyLong())).thenReturn(Optional.of(getPackageTemplateEntity()));
    packageTemplateServiceHelper.getPackageTemplate(123l);
  }

  @Test
  public void getPackageTemplateAssignment() {
    when(featurePackageTemplateServiceHelper.getJpaSpecificationExecutorForPtAssignment(any(PackageAssignmentType.class))).thenReturn(packageTemplateAssignmentUserGroupRepository);
    when(packageTemplateAssignmentUserGroupRepository.findAll(any(Specification.class))).thenReturn(Arrays.asList(getPackageTemplateAssignmentUserGroup()));
    Map<Long, EntityInterface> map = packageTemplateServiceHelper.getPackageTemplateAssignment(12l, PackageAssignmentType.G);
    assertEquals(1, map.size());
  }

  @Test(expected = FumValidationException.class)
  public void testCreatePackageTemplate_whenResourceDoNotExist_shouldThrowFumValidationException() {
    PackageTemplate packageTemplate = getPackageTemplateEntity();
    packageTemplate.setPackageTemplateId(1l);
    when(packageTemplateRepository.save(any(PackageTemplate.class))).thenReturn(packageTemplate);
    when( resourceRepository.findFirstByNameAndRestriction(anyString(), anyBoolean())).thenReturn(Optional.empty());
    List<String> userGroup = new ArrayList<>();
    List<Pair<Pair<String, Boolean>, Pair<PackageAssignmentMode, Boolean>>> resources = new ArrayList<>();
    resources.add(Pair.of(Pair.of("resource", true), Pair.of(PackageAssignmentMode.M, true)));
    packageTemplateServiceHelper.createPackageTemplate(packageTemplate, userGroup, resources);
  }

  @Test(expected = FumValidationException.class)
  public void testCreatePackageTemplate_whenUserGroupDoNotExist_shouldThrowFumValidationException() {
    PackageTemplate packageTemplate = getPackageTemplateEntity();
    packageTemplate.setPackageTemplateId(1l);
    when(packageTemplateRepository.save(any(PackageTemplate.class))).thenReturn(packageTemplate);
    when( resourceRepository.findFirstByNameAndRestriction(anyString(), anyBoolean())).thenReturn(Optional.empty());
    when( userGroupRepository.findFirstByName(anyString())).thenReturn(Optional.empty());

    List<String> userGroup = new ArrayList<>();
    userGroup.add("ug1");
    List<Pair<Pair<String, Boolean>, Pair<PackageAssignmentMode, Boolean>>> resources = new ArrayList<>();
    resources.add(Pair.of(Pair.of("resource", true), Pair.of(PackageAssignmentMode.M, true)));
    packageTemplateServiceHelper.createPackageTemplate(packageTemplate, userGroup, resources);
  }

  @Test
  public void testCreatePackageTemplate() {
    PackageTemplate packageTemplate = getPackageTemplateEntity();
    packageTemplate.setPackageTemplateId(1l);
    when(packageTemplateRepository.save(any(PackageTemplate.class))).thenReturn(packageTemplate);
    when( resourceRepository.findFirstByNameAndRestriction(anyString(), anyBoolean())).thenReturn(Optional.of(getResourceEntity()));
    when( userGroupRepository.findFirstByName(anyString())).thenReturn(Optional.of(getUserGroupEntity()));

    List<String> userGroup = new ArrayList<>();
    userGroup.add("ug1");
    List<Pair<Pair<String, Boolean>, Pair<PackageAssignmentMode, Boolean>>> resources = new ArrayList<>();
    resources.add(Pair.of(Pair.of("resource", true), Pair.of(PackageAssignmentMode.M, true)));
    packageTemplateServiceHelper.createPackageTemplate(packageTemplate, userGroup, resources);
  }

  @Test
  public void testGetPackageTemplateDetails_returnsResources() {
    String templateName = "packageTemplate";
    String resourceName = "resource1";
    PackageTemplate packageTemplate = getPackageTemplateEntity();
    List<PackageTemplateAssignmentResource> expectedList = Arrays.asList(getPackageTemplateAssignmentResource());

    when(packageTemplateRepository.findByName(templateName)).thenReturn(Optional.of(packageTemplate));
    when(packageTemplateAssignmentResourceRepository.findAll(any(Specification.class))).thenReturn(expectedList);

    List<PackageTemplateAssignmentResource> result =
        packageTemplateServiceHelper.getPackageTemplateAssignmentResource(templateName, resourceName);

    assertEquals(expectedList, result);
    verify(packageTemplateRepository, times(1)).findByName(templateName);
    verify(packageTemplateAssignmentResourceRepository, times(1)).findAll(any(Specification.class));
  }

  public static PackageTemplate getPackageTemplateEntity() {
    PackageTemplate packageTemplate = new PackageTemplate();
    packageTemplate.setPackageTemplateId(1234L);
    packageTemplate.setName("packageTemplate");
    packageTemplate.setDescription("description");
    packageTemplate.setActive(true);
    packageTemplate.setType(PackageType.F);
    packageTemplate.setFirmType(FirmType.IB);
    packageTemplate.setPackageTemplateAssignmentResources(Arrays.asList(getPackageTemplateAssignmentResource()));
    packageTemplate.setPackageTemplateAssignmentUserGroups(Arrays.asList(getPackageTemplateAssignmentUserGroup()));
    return packageTemplate;
  }

  public static PackageTemplateAssignmentResource getPackageTemplateAssignmentResource() {
    PackageTemplateAssignmentResource resource = new PackageTemplateAssignmentResource();
    resource.setTemplateAssignmentId(345);
    resource.setResource(getResourceEntity());
    resource.setAssignmentType(PackageAssignmentType.S);
    resource.setAssignmentMode(PackageAssignmentMode.O);
    return resource;
  }

  public static PackageTemplateAssignmentUserGroup getPackageTemplateAssignmentUserGroup() {
    PackageTemplateAssignmentUserGroup userGroup = new PackageTemplateAssignmentUserGroup();
    userGroup.setTemplateAssignmentId(123);
    userGroup.setAssignmentMode(PackageAssignmentMode.M);
    userGroup.setAssignmentType(PackageAssignmentType.G);
    userGroup.setUserGroup(getUserGroupEntity());
    return userGroup;
  }

  public static Resource getResourceEntity() {
    Resource resource1 = new Resource();
    resource1.setName("resource1");
    resource1.setDescription("res desc");
    resource1.setConfUri("conf");
    resource1.setResourceId(1234L);
    resource1.setActive(true);
    resource1.setGroupName("groupName");
    resource1.setLabel("label2");
    resource1.setPurpose("purpose2");
    resource1.setRestriction(true);
    return resource1;
  }



  public static UserGroup getUserGroupEntity() {
    UserGroup userGroup = new UserGroup();
    userGroup.setIsFirmScope(true);
    userGroup.setUserGroupId(1234L);
    userGroup.setName("usergroup");
    userGroup.setIsInternal(true);
    userGroup.setDescription("usergroup desc");
    return userGroup;
  }
}
