package ca.bnc.wealth.common.fum.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.Set;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.support.SimpleValueWrapper;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class RedisCacheOperationServiceTest {

  private RedisCacheOperationService redisCacheOperationService;
  @MockitoBean
  @Qualifier("redisCacheManager")
  private CacheManager cacheManager;

  @MockitoBean
  private RedisTemplate redisTemplate;

  @Before
  @SneakyThrows
  public void setup() {
    redisCacheOperationService = new RedisCacheOperationService();
    FieldUtils.writeField(redisCacheOperationService, "cacheManager", cacheManager, true);
    FieldUtils.writeField(redisCacheOperationService, "enableCache", true, true);
    FieldUtils.writeField(redisCacheOperationService, "redisTemplate", redisTemplate, true);
  }

  @Test
  public void getCacheByCacheNameAndkey_CacheEnabled() {
    Cache cache = mock(Cache.class);
    when(cache.get(anyString(), eq(String.class))).thenReturn("abc");
    when(cacheManager.getCache(anyString())).thenReturn(cache);
    Optional<String> response = redisCacheOperationService.getCacheByCacheNameAndKey("name", "key", String.class);
    assertTrue(response.isPresent());
    assertEquals("abc", response.get());
  }

  @Test
  @SneakyThrows
  public void getCacheByCacheNameAndkey_CacheDisable() {
    FieldUtils.writeField(redisCacheOperationService, "enableCache", false, true);
    Optional<String> response = redisCacheOperationService.getCacheByCacheNameAndKey("name", "key", String.class);
    assertFalse(response.isPresent());
  }

  @Test
  public void addCache_CacheEnabled() {
    Cache cache = mock(Cache.class);
    when(cache.get(anyString(), eq(String.class))).thenReturn("abc");
    when(cacheManager.getCache(anyString())).thenReturn(cache);
    redisCacheOperationService.addCache("name", "key", "value");
  }

  @Test
  @SneakyThrows
  public void addCache_CacheDisabled() {
    FieldUtils.writeField(redisCacheOperationService, "enableCache", false, true);
    redisCacheOperationService.addCache("name", "key", "value");
  }

  @Test
  public void deleteCacheByCacheNameAndKey_CacheEnabled() {
    Cache cache = mock(Cache.class);
    when(cache.get(anyString())).thenReturn(new SimpleValueWrapper("abc"));
    when(cacheManager.getCache(anyString())).thenReturn(cache);
    redisCacheOperationService.deleteCacheByCacheNameAndKey("name", "key");
  }

  @Test
  @SneakyThrows
  public void deleteCacheByCacheNameAndKey_CacheDisabled() {
    FieldUtils.writeField(redisCacheOperationService, "enableCache", false, true);
    redisCacheOperationService.deleteCacheByCacheNameAndKey("name", "key");
  }

  @Test
  public void deleteCacheByCacheName_CacheEnabled() {
    Cache cache = mock(Cache.class);
    when(cache.get(anyString(), eq(String.class))).thenReturn("abc");
    when(cacheManager.getCache(anyString())).thenReturn(cache);
    redisCacheOperationService.deleteCacheByCacheName("name");
  }

  @Test
  @SneakyThrows
  public void deleteCacheByCacheName_CacheDisabled() {
    FieldUtils.writeField(redisCacheOperationService, "enableCache", false, true);
    redisCacheOperationService.deleteCacheByCacheName("name");
  }

  @Test
  public void deleteAllUserCache_CacheEnabled() {
    Cache cache = mock(Cache.class);
    when(cache.get(anyString())).thenReturn(new SimpleValueWrapper("abc"));
    when(cacheManager.getCache(anyString())).thenReturn(cache);
    redisCacheOperationService.deleteAllUserCache();
  }

  @Test
  @SneakyThrows
  public void deleteAllUserCache_CacheDisabled() {
    FieldUtils.writeField(redisCacheOperationService, "enableCache", false, true);
    redisCacheOperationService.deleteAllUserCache();
  }

  @Test
  public void deleteCacheByCacheNameAndPattern_CacheEnabled(){
    Cache cache = mock(Cache.class);
    when(cache.get(anyString())).thenReturn(new SimpleValueWrapper("abc"));
    when(cacheManager.getCache(anyString())).thenReturn(cache);
    when(redisTemplate.keys(anyString())).thenReturn(Set.of("akey"));
    redisCacheOperationService.deleteCacheByCacheNameAndPattern("abc", "a");
  }

  @Test
  @SneakyThrows
  public void deleteCacheByCacheNameAndPattern_CacheDisabled(){
    FieldUtils.writeField(redisCacheOperationService, "enableCache", false, true);
    redisCacheOperationService.deleteCacheByCacheNameAndPattern("abc", "a");
  }

  @Test
  public void deleteCacheByPattern_CacheEnabled(){
    when(redisTemplate.keys(anyString())).thenReturn(Set.of("akey"));
    redisCacheOperationService.deleteCacheByPattern("a");
  }

  @Test
  @SneakyThrows
  public void deleteCacheByPattern_CacheDisabled() {
    FieldUtils.writeField(redisCacheOperationService, "enableCache", false, true);
    redisCacheOperationService.deleteCacheByPattern("a");
  }

}
