package ca.bnc.wealth.common.fum.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class ResourceServiceHelperTest {

  private ResourceServiceHelper resourceServiceHelper;

  @MockitoBean
  private ResourceRepository resourceRepository;

  @Before
  public void setup() throws IllegalAccessException {
    resourceServiceHelper = new ResourceServiceHelper();
    FieldUtils.writeField(resourceServiceHelper, "resourceRepository",
        resourceRepository, true);
  }

  @Test
  public void getFirmResources_whenFirmResourcesAreRequested_shouldReturnResource() {
    when(resourceRepository.findAll(any(Specification.class))).thenReturn(
        getResourceEntityList());
    List<Resource> resources = resourceServiceHelper.getFirmResources("NBIN", true);
    assertNotNull(resources);
    assertTrue(resources.size() > 0);
  }

  @Test
  public void getUserResources_whenUserResourcesAreRequested_shouldReturnResource() {
    when(resourceRepository.findAll(any(Specification.class))).thenReturn(
        getResourceEntityList());
    List<Resource> resources = resourceServiceHelper.getUserResources("idpsubject");
    assertNotNull(resources);
    assertTrue(resources.size() > 0);
  }

  public static List<Resource> getResourceEntityList() {
    Resource resource = new Resource();
    resource.setName("Resource");
    resource.setResourceId(123);
    resource.setActive(true);
    resource.setPurpose("feature");
    resource.setLabel("label");
    return Arrays.asList(resource);
  }
}
