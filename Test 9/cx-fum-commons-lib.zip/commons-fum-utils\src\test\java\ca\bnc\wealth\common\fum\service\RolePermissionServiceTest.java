package ca.bnc.wealth.common.fum.service;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class RolePermissionServiceTest {
  private RolePermissionService rolePermissionService;

  @MockitoBean
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @Before
  public void setup() throws IllegalAccessException {
    rolePermissionService = new RolePermissionService();
    FieldUtils.writeField(rolePermissionService, "namedParameterJdbcTemplate",
        namedParameterJdbcTemplate, true);
  }

  @Test
  public void getRoles_whenRoleExist_shouldReturnRoles() {
    when(namedParameterJdbcTemplate.queryForList(anyString(),
        any(SqlParameterSource.class), eq(String.class))).thenReturn(
        Arrays.asList(new String[]{"role1", "role2"}));
    Optional<List<String>> roles = rolePermissionService.getRoles("idpSubject");
    assertTrue(roles.isPresent());
  }

  @Test
  public void getPermissions_whenPermissionExist_shouldReturnPermissions() {
    when(namedParameterJdbcTemplate.queryForList(anyString(),
        any(SqlParameterSource.class), eq(String.class))).thenReturn(Arrays.asList(new String[]{"permission1", "permission2"}));
    Optional<List<String>> permissions = rolePermissionService.getPermissions("idpSubject");
    assertTrue(permissions.isPresent());
  }
}
