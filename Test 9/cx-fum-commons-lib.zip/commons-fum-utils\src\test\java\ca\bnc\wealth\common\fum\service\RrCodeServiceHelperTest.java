package ca.bnc.wealth.common.fum.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class RrCodeServiceHelperTest {

  private RrCodeServiceHelper rrCodeServiceHelper;
  @MockitoBean
  private IamRrCodeRangeRepository iamRrCodeRangeRepository;
  @Qualifier("postgresJdbcTemplate")
  @MockitoBean
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @Before
  public void setup() throws IllegalAccessException {
    rrCodeServiceHelper = new RrCodeServiceHelper();
    FieldUtils.writeField(rrCodeServiceHelper, "namedParameterJdbcTemplate",
        namedParameterJdbcTemplate, true);
    FieldUtils.writeField(rrCodeServiceHelper, "iamRrCodeRangeRepository",
        iamRrCodeRangeRepository, true);
  }

  @Test
  public void getFirmRrCodeRange() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class))).thenReturn(
        Arrays.asList(getMockRrCode()));
    List<IamRrCodeRange> rrcode = rrCodeServiceHelper.getFirmRrCodeRange("NBIN");
    assertNotNull(rrcode);
    assertTrue(rrcode.size() > 0);
    assertTrue(rrcode.get(0).getFromRrCode().equalsIgnoreCase("from"));
    assertTrue(rrcode.get(0).getToRrCode().equalsIgnoreCase("to"));
  }

  @Test
  public void getRRCodeListByFirmIdUsingJdbc() {
    Map<String,Object> map = new HashMap<>();
    map.put("fromRrCode", "ABCD");
    map.put("toRrCode", "ABCD");
    when(namedParameterJdbcTemplate.queryForList(anyString(), any(SqlParameterSource.class))).thenReturn(List.of(map));
    List<Map<String, Object>> response = rrCodeServiceHelper.getRRCodeListByFirmIdUsingJdbc("NBIN");
    assertEquals(1, response.size());
    assertEquals("ABCD", response.get(0).get("fromRrCode"));
  }

  @Test
  @SneakyThrows
  public void getRrRangeEntityAsync() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class))).thenReturn(
        Arrays.asList(getMockRrCode()));
    CompletableFuture<IamRrCodeRange> response = rrCodeServiceHelper.getRrRangeEntityAsync("ABCD", "ABCD", true);
    assertEquals(getMockRrCode().getFromRrCode(), response.get().getFromRrCode());
    assertEquals(getMockRrCode().getToRrCode(), response.get().getToRrCode());
  }

  @Test
  public void createRrCodeEntityIfNotExist_create() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class))).thenReturn(Collections.emptyList());
    when(iamRrCodeRangeRepository.save(any(IamRrCodeRange.class))).thenReturn(getMockRrCode());
    IamRrCodeRange response = rrCodeServiceHelper.createRrCodeEntityIfNotExist("from", "to");
    assertEquals("from", response.getFromRrCode());
    assertEquals("to", response.getToRrCode());
  }

  @Test
  public void createRrCodeEntityIfNotExist_exist() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class))).thenReturn(List.of(getMockRrCode()));
    IamRrCodeRange response = rrCodeServiceHelper.createRrCodeEntityIfNotExist("from", "to");
    assertEquals("from", response.getFromRrCode());
    assertEquals("to", response.getToRrCode());
  }

  private IamRrCodeRange getMockRrCode() {
    IamRrCodeRange iamRrCodeRange = new IamRrCodeRange();
    iamRrCodeRange.setFromRrCode("from");
    iamRrCodeRange.setToRrCode("to");
    return iamRrCodeRange;
  }
}
