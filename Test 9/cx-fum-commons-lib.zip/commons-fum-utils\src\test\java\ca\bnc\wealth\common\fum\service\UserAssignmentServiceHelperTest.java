package ca.bnc.wealth.common.fum.service;

import static org.junit.Assert.assertTrue;

import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentFeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentFirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserGroupRepository;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class UserAssignmentServiceHelperTest {

  private UserAssignmentServiceHelper userAssignmentServiceHelper;

  @MockitoBean
  private UserAssignmentFeaturePackageRepository userAssignmentFeaturePackageRepository;
  @MockitoBean
  private UserAssignmentFirmRepository userAssignmentFirmRepository;
  @MockitoBean
  private UserAssignmentResourceRepository userAssignmentResourceRepository;
  @MockitoBean
  private UserAssignmentRrCodeRangeRepository userAssignmentRrCodeRangeRepository;
  @MockitoBean
  private UserAssignmentUserGroupRepository userAssignmentUserGroupRepository;
  @MockitoBean
  private ResourceRepository resourceRepository;
  @MockitoBean
  private UserGroupRepository userGroupRepository;
  @MockitoBean
  private IamRrCodeRangeRepository rrCodeRangeRepository;
  @MockitoBean
  private FeaturePackageRepository featurePackageRepository;
  @MockitoBean
  private FirmRepository firmRepository;

  @Before
  public void setup() throws IllegalAccessException {
    userAssignmentServiceHelper = new UserAssignmentServiceHelper();
    FieldUtils.writeField(userAssignmentServiceHelper, "userAssignmentFeaturePackageRepository", userAssignmentFeaturePackageRepository, true);
    FieldUtils.writeField(userAssignmentServiceHelper, "userAssignmentFirmRepository", userAssignmentFirmRepository, true);
    FieldUtils.writeField(userAssignmentServiceHelper, "userAssignmentResourceRepository", userAssignmentResourceRepository, true);
    FieldUtils.writeField(userAssignmentServiceHelper, "userAssignmentRrCodeRangeRepository", userAssignmentRrCodeRangeRepository, true);
    FieldUtils.writeField(userAssignmentServiceHelper, "userAssignmentUserGroupRepository", userAssignmentUserGroupRepository, true);
    FieldUtils.writeField(userAssignmentServiceHelper, "resourceRepository", resourceRepository, true);
    FieldUtils.writeField(userAssignmentServiceHelper, "userGroupRepository", userGroupRepository, true);
    FieldUtils.writeField(userAssignmentServiceHelper, "rrCodeRangeRepository", rrCodeRangeRepository, true);
    FieldUtils.writeField(userAssignmentServiceHelper, "featurePackageRepository", featurePackageRepository, true);
    FieldUtils.writeField(userAssignmentServiceHelper, "firmRepository", firmRepository, true);
  }

  @Test(expected = Exception.class)
  public void getJpaSpecificationRepository_null() {
    userAssignmentServiceHelper.getJpaSpecificationRepository(null);
  }

  @Test(expected = Exception.class)
  public void getUserAssignmentTypeJpaSpecificationRepository_null() {
    userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(null);
  }

  @Test
  public void getJpaSpecificationRepository() {

    JpaSpecificationExecutor jpaSpecificationExecutor = userAssignmentServiceHelper.getJpaSpecificationRepository(
        UserAssignmentType.R);
    assertTrue(jpaSpecificationExecutor instanceof UserAssignmentRrCodeRangeRepository);

    jpaSpecificationExecutor = userAssignmentServiceHelper.getJpaSpecificationRepository(
        UserAssignmentType.P);
    assertTrue(jpaSpecificationExecutor instanceof UserAssignmentFeaturePackageRepository );

    jpaSpecificationExecutor = userAssignmentServiceHelper.getJpaSpecificationRepository(
        UserAssignmentType.F);
    assertTrue(jpaSpecificationExecutor instanceof UserAssignmentFirmRepository );

    jpaSpecificationExecutor = userAssignmentServiceHelper.getJpaSpecificationRepository(
        UserAssignmentType.S);
    assertTrue(jpaSpecificationExecutor instanceof UserAssignmentResourceRepository );

    jpaSpecificationExecutor = userAssignmentServiceHelper.getJpaSpecificationRepository(
        UserAssignmentType.G);
    assertTrue(jpaSpecificationExecutor instanceof UserAssignmentUserGroupRepository );

  }

  @Test
  public void getUserAssignmentTypeJpaSpecificationRepository() {
    JpaSpecificationExecutor jpaSpecificationExecutor = userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(
        UserAssignmentType.R);
    assertTrue(jpaSpecificationExecutor instanceof IamRrCodeRangeRepository);

    jpaSpecificationExecutor = userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(
        UserAssignmentType.P);
    assertTrue(jpaSpecificationExecutor instanceof FeaturePackageRepository);

    jpaSpecificationExecutor = userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(
        UserAssignmentType.F);
    assertTrue(jpaSpecificationExecutor instanceof FirmRepository );

    jpaSpecificationExecutor = userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(
        UserAssignmentType.S);
    assertTrue(jpaSpecificationExecutor instanceof ResourceRepository );

    jpaSpecificationExecutor = userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(
        UserAssignmentType.G);
    assertTrue(jpaSpecificationExecutor instanceof UserGroupRepository );
  }
}
