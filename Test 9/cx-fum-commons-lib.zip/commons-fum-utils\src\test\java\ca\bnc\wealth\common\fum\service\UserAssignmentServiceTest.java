package ca.bnc.wealth.common.fum.service;

import static junit.framework.TestCase.fail;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.fum.model.AssignmentTypeEnum;
import ca.bnc.wealth.common.fum.util.Constants;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentFirm;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.UserGroup;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmAssignmentFeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmAssignmentRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentFeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentFirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserGroupRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.userconfiguration.model.PageInfo;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.UserAssignment;

@RunWith(SpringRunner.class)
public class UserAssignmentServiceTest {

  private static final String TEST_RESOURCE = "TEST_RESOURCE";
  private static final String TEST_USER_GROUP = "TEST_USER_GROUP";
  private UserAssignmentService userAssignmentService;
  @MockitoBean
  private UserAssignmentServiceHelper userAssignmentServiceHelper;
  @MockitoBean
  private UserAssignmentFeaturePackageRepository userAssignmentFeaturePackageRepository;
  @MockitoBean
  private UserAssignmentFirmRepository userAssignmentFirmRepository;
  @MockitoBean
  private UserAssignmentResourceRepository userAssignmentResourceRepository;
  @MockitoBean
  private UserAssignmentRrCodeRangeRepository userAssignmentRrCodeRangeRepository;
  @MockitoBean
  private UserAssignmentUserGroupRepository userAssignmentUserGroupRepository;
  @MockitoBean
  private ResourceRepository resourceRepository;
  @MockitoBean
  private UserGroupRepository userGroupRepository;
  @MockitoBean
  private IamRrCodeRangeRepository rrCodeRangeRepository;
  @MockitoBean
  private FeaturePackageRepository featurePackageRepository;
  @MockitoBean
  private FirmRepository firmRepository;
  @MockitoBean
  private UserAssignmentRepository userAssignmentRepository;
  @MockitoBean
  private IamUserConfigurationRepository iamUserConfigurationRepository;
  @MockitoBean
  private RolePermissionService rolePermissionService;
  @MockitoBean
  private ResourceServiceHelper resourceServiceHelper;
  @MockitoBean
  private UserServiceHelper userServiceHelper;
  @MockitoBean
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
  @MockitoBean
  private RedisCacheOperationService redisCacheOperationService;
  @MockitoBean
  private RrCodeServiceHelper rrCodeServiceHelper;
  @MockitoBean
  private FirmAssignmentRrCodeRangeRepository firmAssignmentRrCodeRangeRepository;
  @MockitoBean
  private FirmAssignmentFeaturePackageRepository firmAssignmentFeaturePackageRepository;

  @Before
  public void setup() throws IllegalAccessException {
    userAssignmentService = new UserAssignmentService();
    FieldUtils.writeField(userAssignmentService, "userAssignmentRrCodeRangeRepository", userAssignmentRrCodeRangeRepository, true);
    FieldUtils.writeField(userAssignmentService, "userAssignmentRepository", userAssignmentRepository, true);
    FieldUtils.writeField(userAssignmentService, "userAssignmentServiceHelper", userAssignmentServiceHelper, true);
    FieldUtils.writeField(userAssignmentService, "iamUserConfigurationRepository", iamUserConfigurationRepository, true);
    FieldUtils.writeField(userAssignmentService, "resourceServiceHelper", resourceServiceHelper, true);
    FieldUtils.writeField(userAssignmentService, "userServiceHelper", userServiceHelper, true);
    FieldUtils.writeField(userAssignmentService, "namedParameterJdbcTemplate", namedParameterJdbcTemplate, true);
    FieldUtils.writeField(userAssignmentService, "redisCacheOperationService", redisCacheOperationService, true);
    FieldUtils.writeField(userAssignmentService, "rrCodeServiceHelper", rrCodeServiceHelper, true);
    FieldUtils.writeField(userAssignmentService, "userGroupRepository", userGroupRepository, true);
    FieldUtils.writeField(userAssignmentService, "resourceRepository", resourceRepository, true);
  }

  @Test
  public void getUserAssignmentSp_whenRoleExist_shouldReturnRoles() {
    when(userAssignmentRepository.getUserAssignment(anyString(), anyString(), anyBoolean()))
        .thenReturn(getAssigneeNames());
    List<UserAssignment> userAssignmentsRoles =
        userAssignmentService.getUserAssignmentsSp("idp", List.of(AssignmentTypeEnum.ROLE.getDbCode()), false);
    assertTrue(userAssignmentsRoles.size() > 0);
    assertEquals(AssignmentTypeEnum.ROLE.getDbCode(), userAssignmentsRoles.get(0).getAssignmentType());
    assertEquals("assignee1", userAssignmentsRoles.get(0).getRole());
  }

  @Test
  public void getUserAssignmentSp_whenPermissionExist_shouldReturnPermissions() {
    when(userAssignmentRepository.getUserAssignment(anyString(), anyString(), anyBoolean()))
        .thenReturn(getAssigneeNames());
    List<UserAssignment> userAssignmentsPermissions =
        userAssignmentService.getUserAssignmentsSp("idp", List.of(AssignmentTypeEnum.PERMISSION.getDbCode()), false);
    assertTrue(userAssignmentsPermissions.size() > 0);
    assertEquals(AssignmentTypeEnum.PERMISSION.getDbCode(), userAssignmentsPermissions.get(0).getAssignmentType());
    assertEquals("assignee1", userAssignmentsPermissions.get(0).getPermission());
  }

  @Test
  public void getUserAssignmentSp_RrCode() {
    when(userAssignmentRepository.getUserAssignment(anyString(), anyString(), anyBoolean()))
        .thenReturn(getRrCodeAssignee());
    List<UserAssignment> userAssignmentsPermissions =
        userAssignmentService.getUserAssignmentsSp("idp", List.of("R"), false);
    assertTrue(userAssignmentsPermissions.size() > 0);
    assertEquals("R", userAssignmentsPermissions.get(0).getAssignmentType());
    assertEquals("from", userAssignmentsPermissions.get(0).getFromRrCode());
    assertEquals("to", userAssignmentsPermissions.get(0).getToRrCode());
  }

  @Test
  public void getUserAssignmentSp() {
    when(userAssignmentRepository.getUserAssignment(anyString(), anyString(), anyBoolean()))
        .thenReturn(getRrCodeAssignee());
    List<UserAssignment> userAssignmentsPermissions =
        userAssignmentService.getUserAssignmentsSp("idp", List.of("G"), false);
    assertTrue(userAssignmentsPermissions.size() > 0);
    assertEquals("G", userAssignmentsPermissions.get(0).getAssignmentType());
    assertEquals(123, userAssignmentsPermissions.get(0).getAssigneeId().intValue());
  }

  @Test
  public void testGetUserAssignmentType_whenUserTypeIsR_shouldCallIamRrCodeRangeRepository() {
    ca.bnc.wealth.common.jpa.entity.iam.UserAssignment userAssignment = getUserAssignment(
        UserAssignmentType.R);
    when(userAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(userAssignment));

    IamRrCodeRange expectedRrCodeRange = new IamRrCodeRange();
    expectedRrCodeRange.setFromRrCode("from");
    expectedRrCodeRange.setToRrCode("to");
    expectedRrCodeRange.setRrCodeRangeId(1L);
    when(rrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(expectedRrCodeRange));
    when(userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(UserAssignmentType.R)).thenReturn(rrCodeRangeRepository);
    Map<String, List<IamRrCodeRange>> response =
        userAssignmentService.getUserAssignmentType(List.of("idpSubject"), UserAssignmentType.R);

    assertTrue(response.containsKey(userAssignment.getIdpSubject()));
    List<IamRrCodeRange> actualRrCodeList = response.get(userAssignment.getIdpSubject());
    assertFalse(actualRrCodeList.isEmpty());
    assertEquals(expectedRrCodeRange.getFromRrCode(), actualRrCodeList.get(0).getFromRrCode());
    assertEquals(expectedRrCodeRange.getToRrCode(), actualRrCodeList.get(0).getToRrCode());
    assertEquals(
        expectedRrCodeRange.getRrCodeRangeId(), actualRrCodeList.get(0).getRrCodeRangeId());
  }

  @Test
  public void testGetUserAssignmentType_whenUserTypeIsP_shouldCallFeaturePackageRepository() {
    ca.bnc.wealth.common.jpa.entity.iam.UserAssignment userAssignment = getUserAssignment(UserAssignmentType.P);
    when(userAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(userAssignment));

    FeaturePackage expectedFeaturePackage = new FeaturePackage();
    expectedFeaturePackage.setFeaturePackageId(1L);
    expectedFeaturePackage.setPackageTemplate(new PackageTemplate());
    expectedFeaturePackage.setVersion("1");
    when(featurePackageRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(expectedFeaturePackage));
    when(userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(UserAssignmentType.P)).thenReturn(featurePackageRepository);
    Map<String, List<FeaturePackage>> response =
        userAssignmentService.getUserAssignmentType(List.of("idpSubject"), UserAssignmentType.P);

    assertTrue(response.containsKey(userAssignment.getIdpSubject()));
    List<FeaturePackage> actualFeaturePackageList = response.get(userAssignment.getIdpSubject());
    assertFalse(actualFeaturePackageList.isEmpty());
    assertEquals(
        expectedFeaturePackage.getFeaturePackageId(),
        actualFeaturePackageList.get(0).getFeaturePackageId());
    assertEquals(expectedFeaturePackage.getVersion(), actualFeaturePackageList.get(0).getVersion());
    assertEquals(
        expectedFeaturePackage.getPackageTemplate(),
        actualFeaturePackageList.get(0).getPackageTemplate());
  }

  @Test
  public void testGetUserAssignmentType_whenUserTypeIsF_shouldCallFirmRepository() {
    ca.bnc.wealth.common.jpa.entity.iam.UserAssignment userAssignment = getUserAssignment(UserAssignmentType.F);
    when(userAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(userAssignment));

    Firm expectedFirm = new Firm();
    expectedFirm.setFirmId("Firm");
    expectedFirm.setFirmEntityId(1L);
    when(firmRepository.findAll(any(Specification.class))).thenReturn(List.of(expectedFirm));
    when(userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(UserAssignmentType.F)).thenReturn(firmRepository);
    Map<String, List<Firm>> response =
        userAssignmentService.getUserAssignmentType(List.of("idpSubject"), UserAssignmentType.F);

    assertTrue(response.containsKey(userAssignment.getIdpSubject()));
    List<Firm> actualFirmList = response.get(userAssignment.getIdpSubject());
    assertFalse(actualFirmList.isEmpty());
    assertEquals(expectedFirm.getFirmId(), actualFirmList.get(0).getFirmId());
    assertEquals(expectedFirm.getFirmEntityId(), actualFirmList.get(0).getFirmEntityId());
  }

  @Test
  public void testGetUserAssignmentType_whenUserTypeIsS_shouldCallResourceRepository() {
    ca.bnc.wealth.common.jpa.entity.iam.UserAssignment userAssignment = getUserAssignment(UserAssignmentType.S);
    when(userAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(userAssignment));

    Resource expectedResource = new Resource();
    expectedResource.setName("Resource");
    expectedResource.setResourceId(1L);
    when(resourceRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(expectedResource));
    when(userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(UserAssignmentType.S)).thenReturn(resourceRepository);
    Map<String, List<Resource>> response =
        userAssignmentService.getUserAssignmentType(List.of("idpSubject"), UserAssignmentType.S);

    assertTrue(response.containsKey(userAssignment.getIdpSubject()));
    List<Resource> actualResourceList = response.get(userAssignment.getIdpSubject());
    assertFalse(actualResourceList.isEmpty());
    assertEquals(expectedResource.getName(), actualResourceList.get(0).getName());
    assertEquals(expectedResource.getId(), actualResourceList.get(0).getId());
  }

  @Test
  public void testGetUserAssignmentType_whenUserTypeIsG_shouldCallUserGroupRepository() {
    ca.bnc.wealth.common.jpa.entity.iam.UserAssignment userAssignment = getUserAssignment(UserAssignmentType.G);
    when(userAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(userAssignment));

    UserGroup expectedUserGroup = new UserGroup();
    expectedUserGroup.setName("UserGroup");
    expectedUserGroup.setUserGroupId(1L);
    when(userGroupRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(expectedUserGroup));
    when(userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(UserAssignmentType.G)).thenReturn(userGroupRepository);
    Map<String, List<UserGroup>> response =
        userAssignmentService.getUserAssignmentType(List.of("idpSubject"), UserAssignmentType.G);

    assertTrue(response.containsKey(userAssignment.getIdpSubject()));
    List<UserGroup> actualUserGroupList = response.get(userAssignment.getIdpSubject());
    assertFalse(actualUserGroupList.isEmpty());
    assertEquals(expectedUserGroup.getName(), actualUserGroupList.get(0).getName());
    assertEquals(expectedUserGroup.getUserGroupId(), actualUserGroupList.get(0).getUserGroupId());
  }

  @Test
  public void getUserAssignments_whenRoleExist_shouldReturnRoles() {
    when(iamUserConfigurationRepository.findFirstByIdpSubject(anyString()))
        .thenReturn(Optional.of(getIamUserConfigurationEntity()));
    when(rolePermissionService.getRoles(anyString()))
        .thenReturn(Optional.of(Arrays.asList("role1", "role2")));
    List<UserAssignment> userAssignments =
        userAssignmentService.getUserAssignments("idpSubject", List.of(AssignmentTypeEnum.ROLE.getDbCode()), false);
    assertTrue(userAssignments.size() == 0);
   // assertEquals(AssignmentTypeEnum.ROLES.getDbCode(), userAssignments.get(0).getAssignmentType());
   // assertEquals("role1", userAssignments.get(0).getRole());
  }

  @Test
  public void getUserAssignments_whenRoleNotExist_shouldNotReturnRoles() {
    when(iamUserConfigurationRepository.findFirstByIdpSubject(anyString()))
        .thenReturn(Optional.of(getIamUserConfigurationEntity()));
    when(rolePermissionService.getRoles(anyString())).thenReturn(Optional.of(List.of()));
    List<UserAssignment> userAssignments =
        userAssignmentService.getUserAssignments("idpSubject", List.of(AssignmentTypeEnum.ROLE.getDbCode()), false);
    assertEquals(0, userAssignments.size());
  }


  @Test
  public void testAssignUserGroupToUserByGroupName() {
    UserGroup expectedUserGroup = new UserGroup();
    expectedUserGroup.setName(TEST_USER_GROUP);
    expectedUserGroup.setUserGroupId(1L);
    when(userGroupRepository.findFirstByName(TEST_USER_GROUP)).thenReturn(Optional.of(expectedUserGroup));

    try {
      userAssignmentService.assignUserGroupNameToUser(1, "idpSubject", TEST_USER_GROUP, "requestedBy");
    } catch (Exception e) {
      fail("This test should not throw exception");
    }
  }

  @Test(expected = FumNotFoundException.class)
  public void testAssignUserGroupToUserByGroupName_whenUserGroupNotFound_shouldThrowFumNotFoundException() {
    FumNotFoundException exception = new FumNotFoundException(Constants.ERROR_USER_GROUP_NOT_FOUND_CODE,
        String.format(Constants.ERROR_USER_GROUP_NOT_FOUND_MESSAGE, TEST_USER_GROUP));
    doThrow(exception).when(userGroupRepository).findFirstByName(anyString());
    userAssignmentService.assignUserGroupNameToUser(1, "idpSubject", TEST_USER_GROUP, "requestedBy");
  }

  @Test
  public void testAssignResourceToUserByResourceName() {
    Resource expectedResource = new Resource();
    expectedResource.setName(TEST_RESOURCE);
    expectedResource.setResourceId(1L);
    when(resourceRepository.findFirstByName(TEST_RESOURCE)).thenReturn(Optional.of(expectedResource));

    try {
      userAssignmentService.assignResourceNameToUser(1, "idpSubject", TEST_RESOURCE, "requestedBy");
    } catch (Exception e) {
      fail("This test should not throw exception");
    }
  }

  @Test(expected = FumNotFoundException.class)
  public void testAssignResourceByResourceName_whenResourceNotFound_shouldThrowFumNotFoundException() {
    FumNotFoundException exception = new FumNotFoundException(Constants.ERROR_RESOURCE_NOT_FOUND_CODE,
        String.format(Constants.ERROR_RESOURCE_NOT_FOUND_MESSAGE, TEST_RESOURCE));
    doThrow(exception).when(resourceRepository).findFirstByName(anyString());
    userAssignmentService.assignResourceNameToUser(1, "idpSubject", TEST_RESOURCE, "requestedBy");
  }

  @Test
  public void getUserAssignments_whenPermissionExist_shouldReturnPermissions() {
    when(iamUserConfigurationRepository.findFirstByIdpSubject(anyString()))
        .thenReturn(Optional.of(getIamUserConfigurationEntity()));
    when(rolePermissionService.getPermissions(anyString()))
        .thenReturn(Optional.of(Arrays.asList("permission1", "permission2")));
    List<UserAssignment> userAssignments =
        userAssignmentService.getUserAssignments("idpSubject", List.of(AssignmentTypeEnum.PERMISSION.getDbCode()), false);
    assertTrue(userAssignments.size() == 0);
    //assertEquals(AssignmentTypeEnum.PERMISSION.getDbCode(), userAssignments.get(0).getAssignmentType());
    //assertEquals("permission1", userAssignments.get(0).getPermission());
  }

  @Test
  public void getUserAssignments_whenPermissionNotExist_shouldNotReturnPermissions() {
    when(iamUserConfigurationRepository.findFirstByIdpSubject(anyString()))
        .thenReturn(Optional.of(getIamUserConfigurationEntity()));
    when(rolePermissionService.getPermissions(anyString())).thenReturn(Optional.of(List.of()));
    List<UserAssignment> userAssignments =
        userAssignmentService.getUserAssignments("idpSubject", List.of(AssignmentTypeEnum.PERMISSION.getDbCode()), false);
    assertEquals(0, userAssignments.size());
  }

  @Test
  public void getUserAssignment() {
    when(userAssignmentServiceHelper.getJpaSpecificationRepository(any()))
        .thenReturn(userAssignmentFirmRepository);
    when(userAssignmentFirmRepository.findAll(any(Specification.class))).thenReturn(Collections.emptyList());
    List<UserAssignmentFirm> lst = userAssignmentService.getUserAssignment("idp", UserAssignmentType.F);
    assertTrue(lst.size() == 0);
  }

  @Test
  public void hasUserAssignment() {
    when(userAssignmentRepository.count(any(Specification.class))).thenReturn(10L);
    boolean response = userAssignmentService.hasUserAssignment("idp", 1234, UserAssignmentType.F);
    assertTrue(response);
  }

  @Test(expected = Exception.class)
  public void hasUserAssignmentRRCode() {
    userAssignmentService.hasUserAssignment("idp", "1bcd", UserAssignmentType.R);
  }

  @Test
  public void hasUserAssignmentPackage() {
    when(userAssignmentFeaturePackageRepository.count(any(Specification.class))).thenReturn(10L);
    when(userAssignmentServiceHelper.getJpaSpecificationRepository(UserAssignmentType.P)).thenReturn(userAssignmentFeaturePackageRepository);
    boolean response =
        userAssignmentService.hasUserAssignment("idp", "12343", UserAssignmentType.P);
    assertTrue(response);
  }

  @Test
  public void hasUserAssignmentFirm() {
    when(userAssignmentFirmRepository.count(any(Specification.class))).thenReturn(10L);
    when(userAssignmentServiceHelper.getJpaSpecificationRepository(UserAssignmentType.F)).thenReturn(userAssignmentFirmRepository);
    boolean response =
        userAssignmentService.hasUserAssignment("idp", "12343", UserAssignmentType.F);
    assertTrue(response);
  }

  @Test
  public void hasUserAssignmentResource() {
    when(userAssignmentResourceRepository.count(any(Specification.class))).thenReturn(10L);
    when(userAssignmentServiceHelper.getJpaSpecificationRepository(UserAssignmentType.S)).thenReturn(userAssignmentResourceRepository);
    boolean response =
        userAssignmentService.hasUserAssignment("idp", "12343", UserAssignmentType.S);
    assertTrue(response);
  }

  @Test
  public void hasUserAssignmentGroup() {
    when(userAssignmentUserGroupRepository.count(any(Specification.class))).thenReturn(10L);
    when(userAssignmentServiceHelper.getJpaSpecificationRepository(UserAssignmentType.G)).thenReturn(userAssignmentUserGroupRepository);
    boolean response =
        userAssignmentService.hasUserAssignment("idp", "12343", UserAssignmentType.G);
    assertTrue(response);
  }

  @Test
  public void getUserConfigByAssignment_byFirm() {
    PageInfo page = new PageInfo();
    page.setPageNumber(1);
    page.setPageSize(1);
    when(iamUserConfigurationRepository.findAll(any(Specification.class), any(PageRequest.class))).thenReturn(new PageImpl(Arrays.asList(getIamUserConfigurationEntity())));
    Page<IamUserConfiguration> response = userAssignmentService.getUserConfigByAssignment(UserAssignmentType.F, "NBIN", page);
    assertNotNull(response);
    assertTrue(response.getTotalElements() == 1);
  }

  @Test
  public void getUserConfigByAssignment_byUserGroup() {
    PageInfo page = new PageInfo();
    page.setPageNumber(1);
    page.setPageSize(1);
    when(iamUserConfigurationRepository.findAll(any(Specification.class), any(PageRequest.class))).thenReturn(new PageImpl(Arrays.asList(getIamUserConfigurationEntity())));
    Page<IamUserConfiguration> response = userAssignmentService.getUserConfigByAssignment(UserAssignmentType.G, "NBIN", page);
    assertNotNull(response);
    assertTrue(response.getTotalElements() == 1);
  }

  @Test
  public void getUserConfigByAssignment() {
    when(iamUserConfigurationRepository.findAll(any(Specification.class), any(PageRequest.class))).thenReturn(new PageImpl(Arrays.asList(getIamUserConfigurationEntity())));
    Page<IamUserConfiguration> response = userAssignmentService.getUserConfigByAssignment(UserAssignmentType.G, "NBIN", null);
    assertNotNull(response);
    assertTrue(response.getTotalElements() == 1);
  }

  @Test(expected = Exception.class)
  public void getUserConfigByAssignment_btRrCode() {
    PageInfo page = new PageInfo();
    page.setPageNumber(1);
    page.setPageSize(1);
    when(iamUserConfigurationRepository.findAll(any(Specification.class), any(PageRequest.class))).thenReturn(new PageImpl(Arrays.asList(getIamUserConfigurationEntity())));
    Page<IamUserConfiguration> response = userAssignmentService.getUserConfigByAssignment(UserAssignmentType.R, "NBIN", page);
  }

  @Test
  public void refreshUserAssignment_rrCode() {
    when(iamUserConfigurationRepository.findAll(any(Specification.class))).thenReturn(
        Arrays.asList(getIamUserConfigurationEntity()));
    Resource resource = new Resource();
    resource.setName("firm_level_access");
    resource.setType("data_access");
    when(resourceServiceHelper.getFirmResources(anyString(), anyBoolean())).thenReturn(Arrays.asList(resource));

    when(userServiceHelper.getFirmUsersWithFirmLevelAccess(anyString(), anyBoolean())).thenReturn(Arrays.asList(getIamUserConfigurationEntity()));
    when(rrCodeServiceHelper.getFirmRrCodeRange(anyString())).thenReturn(getRrCodeRangeEntityList());

    when(userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(eq(UserAssignmentType.R))).thenReturn(rrCodeRangeRepository);
    when(rrCodeRangeRepository.findAll(any(Specification.class))).thenReturn(Collections.emptyList());
    when(userAssignmentServiceHelper.getJpaRepository(UserAssignmentType.R)).thenReturn(userAssignmentRrCodeRangeRepository);
    when(userAssignmentServiceHelper.getJpaSpecificationRepository(eq(UserAssignmentType.R))).thenReturn(userAssignmentRrCodeRangeRepository);

    userAssignmentService.refreshUserAssignment("rr-range", "firm", "idp");
    verify(userAssignmentRrCodeRangeRepository, times(1)).save(
        any(UserAssignmentRrCodeRange.class));
  }

  @Test
  public void refreshUserAssignment_resource() {
    userAssignmentService.refreshUserAssignment("resource", "firm", "idp");
  }

  @Test
  public void refreshUserAssignment_rrCodeByAssignmentType() {
    when(iamUserConfigurationRepository.findAll(any(Specification.class))).thenReturn(
        Arrays.asList(getIamUserConfigurationEntity()));
    Resource resource = new Resource();
    resource.setName("firm_level_access");
    resource.setType("data_access");
    when(resourceServiceHelper.getFirmResources(anyString(), anyBoolean())).thenReturn(Arrays.asList(resource));

    when(userServiceHelper.getFirmUsersWithFirmLevelAccess(anyString(), anyBoolean())).thenReturn(Arrays.asList(getIamUserConfigurationEntity()));
    when(rrCodeServiceHelper.getFirmRrCodeRange(anyString())).thenReturn(getRrCodeRangeEntityList());

    when(userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(eq(UserAssignmentType.R))).thenReturn(rrCodeRangeRepository);
    when(rrCodeRangeRepository.findAll(any(Specification.class))).thenReturn(Collections.emptyList());
    when(userAssignmentServiceHelper.getJpaRepository(UserAssignmentType.R)).thenReturn(userAssignmentRrCodeRangeRepository);
    when(userAssignmentServiceHelper.getJpaSpecificationRepository(eq(UserAssignmentType.R))).thenReturn(userAssignmentRrCodeRangeRepository);

    userAssignmentService.refreshUserAssignment(UserAssignmentType.R, "firm", "idp");
    verify(userAssignmentRrCodeRangeRepository, times(1)).save(
        any(UserAssignmentRrCodeRange.class));
  }

  @Test
  public void refreshUserAssignment_resourceByAssignmentType() {
    userAssignmentService.refreshUserAssignment(UserAssignmentType.S, "firm", "idp");
  }

  @Test
  public void assignUserGroupToUser() {
    userAssignmentService.assignUserGroupToUser(1, "idpSubject", 1, "requestedBy");
  }

  @Test
  public void assignResourceToUser() {
    userAssignmentService.assignResourceToUser(1, "idpSubject", 1, "requestedBy");
  }

  @Test
  public void assignFirmToUser() {
    userAssignmentService.assignFirmToUser(1, "idpSubject", 1, "requestedBy");
  }

  @Test
  public void assignFeaturePackageToUser() {
    userAssignmentService.assignFeaturePackageToUser(1, "idpSubject", 1, "requestedBy");
  }

  @Test
  public void assignRrRangesSp() {
    List<RRCodeRange> targetRrRanges = new ArrayList<>();
    userAssignmentService.assignRrRangesSp(1, "idp", targetRrRanges, "requestedBy");
  }

  @Test
  public void deleteUnusedAssignment() {
    when(userAssignmentServiceHelper.getUserAssignmentTypeJpaSpecificationRepository(eq(UserAssignmentType.R))).thenReturn(rrCodeRangeRepository);
    when(rrCodeRangeRepository.findAll(any(org.springframework.data.jpa.domain.Specification.class))).thenReturn(
        Collections.EMPTY_LIST);
    when(userAssignmentRepository.findAll(any(org.springframework.data.jpa.domain.Specification.class))).thenReturn(
        Collections.EMPTY_LIST);
    when(rrCodeRangeRepository.findAll(any(org.springframework.data.jpa.domain.Specification.class))).thenReturn(
        Collections.EMPTY_LIST);
    userAssignmentService.deleteUnusedRrCodeAssignment("firmId");
  }

  public static List<Map<String, Object>> getAssigneeNames() {
    Map<String, Object> assignee1 = new HashMap<>();
    assignee1.put(Constants.ASSIGNEE_ID, null);
    assignee1.put(Constants.FROM_RR_CODE, null);
    assignee1.put(Constants.TO_RR_CODE, null);
    assignee1.put(Constants.ASSIGNEE_VALUE, "assignee1");

    Map<String, Object> assignee2 = new HashMap<>();
    assignee2.put(Constants.ASSIGNEE_ID, null);
    assignee2.put(Constants.FROM_RR_CODE, null);
    assignee2.put(Constants.TO_RR_CODE, null);
    assignee2.put(Constants.ASSIGNEE_VALUE, "assignee2");

    return Arrays.asList(assignee1, assignee2);
  }

  public static List<Map<String, Object>> getRrCodeAssignee() {
    Map<String, Object> assignee3 = new HashMap<>();
    assignee3.put(Constants.ASSIGNEE_ID, 123);
    assignee3.put(Constants.FROM_RR_CODE, "from");
    assignee3.put(Constants.TO_RR_CODE, "to");
    assignee3.put(Constants.ASSIGNEE_VALUE, null);
    return Arrays.asList(assignee3);
  }

  private ca.bnc.wealth.common.jpa.entity.iam.UserAssignment getUserAssignment(UserAssignmentType p) {
    ca.bnc.wealth.common.jpa.entity.iam.UserAssignment userAssignment = new ca.bnc.wealth.common.jpa.entity.iam.UserAssignment();
    userAssignment.setId(1L);
    userAssignment.setAssignmentType(p);
    userAssignment.setIdpSubject("idpSubject");
    userAssignment.setAssigneeId(1);
    return userAssignment;
  }

  public static IamUserConfiguration getIamUserConfigurationEntity() {
    IamUserConfiguration iamUserConfiguration = new IamUserConfiguration();
    iamUserConfiguration.setIdpSubject("idp");
    iamUserConfiguration.setIdpUserIdentifier("1234");
    iamUserConfiguration.setUserConfigurationId(1234L);
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setPreferredLanguageType(PreferredLanguageType.EN);
    iamUserConfiguration.setOssUserId("123");
    iamUserConfiguration.setOssGroupId("123");
    return iamUserConfiguration;
  }

  public static List<IamRrCodeRange> getRrCodeRangeEntityList() {
    IamRrCodeRange iamRrCodeRange = new IamRrCodeRange();
    iamRrCodeRange.setFromRrCode("AABB");
    iamRrCodeRange.setToRrCode("AABC");
    return Arrays.asList(iamRrCodeRange);
  }
}
