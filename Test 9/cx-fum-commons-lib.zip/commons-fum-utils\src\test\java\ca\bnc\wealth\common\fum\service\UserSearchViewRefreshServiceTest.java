package ca.bnc.wealth.common.fum.service;

import static org.mockito.Mockito.after;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.timeout;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.repo.iam.UserConfigSearchMaterializedViewRepository;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class UserSearchViewRefreshServiceTest {

  private static final long AWAIT_MILLIS = 5000L;

  @Mock
  private UserConfigSearchMaterializedViewRepository repository;

  @Test
  void refreshAsync_triggersRepositoryRefresh() {
    UserSearchViewRefreshService service = new UserSearchViewRefreshService(repository);

    service.refreshAsync(false);

    verify(repository, timeout(AWAIT_MILLIS)).refreshMeterializedView();
  }

  @Test
  void refreshAsync_withCallback_runsCallbackAndRefresh() throws InterruptedException {
    UserSearchViewRefreshService service = new UserSearchViewRefreshService(repository);
    CountDownLatch callbackRan = new CountDownLatch(1);

    service.refreshAsync(callbackRan::countDown, false);

    Assertions.assertTrue(
        callbackRan.await(AWAIT_MILLIS, TimeUnit.MILLISECONDS), "callback should always run");
    verify(repository, timeout(AWAIT_MILLIS)).refreshMeterializedView();
  }

  @Test
  void refreshAsync_withCallback_runsRefreshBeforeCallback() throws InterruptedException {
    UserSearchViewRefreshService service = new UserSearchViewRefreshService(repository);
    List<String> order = Collections.synchronizedList(new ArrayList<>());
    doAnswer(invocation -> {
      order.add("refresh");
      return null;
    }).when(repository).refreshMeterializedView();
    CountDownLatch callbackRan = new CountDownLatch(1);

    service.refreshAsync(() -> {
      order.add("callback");
      callbackRan.countDown();
    }, false);

    Assertions.assertTrue(callbackRan.await(AWAIT_MILLIS, TimeUnit.MILLISECONDS), "callback should run");
    Assertions.assertEquals(
        List.of("refresh", "callback"), order, "refresh must run before the callback");
  }

  @Test
  void refreshAsync_doesNotSurfaceRepositoryFailureOnCaller_whenThrowExceptionFalse() {
    doThrow(new RuntimeException("boom")).when(repository).refreshMeterializedView();
    UserSearchViewRefreshService service = new UserSearchViewRefreshService(repository);

    // Must not throw on the calling thread; the failure is handled on the worker thread.
    service.refreshAsync(false);

    verify(repository, timeout(AWAIT_MILLIS)).refreshMeterializedView();
  }

  @Test
  void refreshNow_triggersRepositoryRefreshSynchronously() {
    UserSearchViewRefreshService service = new UserSearchViewRefreshService(repository);

    service.refreshNow(false);

    verify(repository).refreshMeterializedView();
  }

  @Test
  void refreshAsyncIfSearchFieldChanged_refreshesWhenSearchFieldChanged() {
    UserSearchViewRefreshService service = new UserSearchViewRefreshService(repository);
    IamUserConfiguration before =
        IamUserConfiguration.builder().userConfigurationId(1L).firstName("Ann").build();
    IamUserConfiguration after =
        IamUserConfiguration.builder().userConfigurationId(1L).firstName("Anne").build();

    service.refreshAsyncIfSearchFieldChanged(before, after, false);

    verify(repository, timeout(AWAIT_MILLIS)).refreshMeterializedView();
  }

  @Test
  void refreshAsyncIfSearchFieldChanged_skipsWhenOnlyAuditFieldsChanged() {
    UserSearchViewRefreshService service = new UserSearchViewRefreshService(repository);
    IamUserConfiguration before = IamUserConfiguration.builder()
        .userConfigurationId(1L).firstName("Ann").lastUpdatedBy("u1")
        .lastUpdateDate(new Timestamp(1000L)).build();
    IamUserConfiguration after = IamUserConfiguration.builder()
        .userConfigurationId(1L).firstName("Ann").lastUpdatedBy("u2")
        .lastUpdateDate(new Timestamp(2000L)).build();

    service.refreshAsyncIfSearchFieldChanged(before, after, false);

    verify(repository, after(500).never()).refreshMeterializedView();
  }

  @Test
  void refreshAsyncIfSearchFieldChanged_refreshesWhenBeforeIsNull() {
    UserSearchViewRefreshService service = new UserSearchViewRefreshService(repository);
    IamUserConfiguration after =
        IamUserConfiguration.builder().userConfigurationId(1L).firstName("Ann").build();

    service.refreshAsyncIfSearchFieldChanged(null, after, false);

    verify(repository, timeout(AWAIT_MILLIS)).refreshMeterializedView();
  }

  @Test
  void refreshAsyncIfSearchFieldChanged_refreshesWhenAfterIsNull() {
    UserSearchViewRefreshService service = new UserSearchViewRefreshService(repository);
    IamUserConfiguration before =
        IamUserConfiguration.builder().userConfigurationId(1L).firstName("Ann").build();

    service.refreshAsyncIfSearchFieldChanged(before, null, false);

    verify(repository, timeout(AWAIT_MILLIS)).refreshMeterializedView();
  }

  @Test
  void refreshAsyncIfSearchFieldChanged_skipsWhenOnlyUserPreferencesChanged() {
    UserSearchViewRefreshService service = new UserSearchViewRefreshService(repository);
    HashMap<String, String> prefsBefore = new HashMap<>();
    prefsBefore.put("k", "v1");
    HashMap<String, String> prefsAfter = new HashMap<>();
    prefsAfter.put("k", "v2");
    IamUserConfiguration before = IamUserConfiguration.builder()
        .userConfigurationId(1L).firstName("Ann").userPreferences(prefsBefore).build();
    IamUserConfiguration after = IamUserConfiguration.builder()
        .userConfigurationId(1L).firstName("Ann").userPreferences(prefsAfter).build();

    service.refreshAsyncIfSearchFieldChanged(before, after, false);

    verify(repository, after(500).never()).refreshMeterializedView();
  }

  @Test
  void refreshNow_propagatesFailure_whenThrowExceptionTrue() {
    doThrow(new RuntimeException("boom")).when(repository).refreshMeterializedView();
    UserSearchViewRefreshService service = new UserSearchViewRefreshService(repository);

    Assertions.assertThrows(RuntimeException.class, () -> service.refreshNow(true));
  }

  @Test
  void refreshNow_swallowsFailure_whenThrowExceptionFalse() {
    doThrow(new RuntimeException("boom")).when(repository).refreshMeterializedView();
    UserSearchViewRefreshService service = new UserSearchViewRefreshService(repository);

    // Must not throw.
    service.refreshNow(false);

    verify(repository).refreshMeterializedView();
  }

  @Test
  void refreshAsync_withCallback_skipsCallbackWhenRefreshFails() throws InterruptedException {
    UserSearchViewRefreshService service = new UserSearchViewRefreshService(repository);
    AtomicBoolean callbackRan = new AtomicBoolean(false);
    CountDownLatch refreshAttempted = new CountDownLatch(1);
    doAnswer(invocation -> {
      refreshAttempted.countDown();
      throw new RuntimeException("boom");
    }).when(repository).refreshMeterializedView();

    service.refreshAsync(() -> callbackRan.set(true), false);

    Assertions.assertTrue(
        refreshAttempted.await(AWAIT_MILLIS, TimeUnit.MILLISECONDS), "refresh should be attempted");
    verify(repository, timeout(AWAIT_MILLIS)).refreshMeterializedView();
    Assertions.assertFalse(callbackRan.get(), "callback must not run when the refresh fails");
  }

  @Test
  void physicalRefreshesNeverOverlap() throws InterruptedException {
    UserSearchViewRefreshService service = new UserSearchViewRefreshService(repository);
    CountDownLatch firstInside = new CountDownLatch(1);
    CountDownLatch release = new CountDownLatch(1);
    AtomicInteger calls = new AtomicInteger();
    doAnswer(invocation -> {
      if (calls.getAndIncrement() == 0) {
        firstInside.countDown();
        release.await();
      }
      return null;
    }).when(repository).refreshMeterializedView();

    Thread first = new Thread(() -> service.refreshNow(false), "first-refresh");
    first.setDaemon(true);
    Thread second = new Thread(() -> service.refreshNow(false), "second-refresh");
    second.setDaemon(true);
    try {
      first.start();
      Assertions.assertTrue(
          firstInside.await(AWAIT_MILLIS, TimeUnit.MILLISECONDS), "first refresh should start");

      second.start();
      // The first refresh holds the lock, so the second thread must block (park) on it.
      Assertions.assertTrue(
          awaitThreadState(second, Thread.State.WAITING, AWAIT_MILLIS),
          "second refresh should block on the refresh lock while the first holds it");

      // Because the second is blocked on the lock, it cannot have reached the repository yet.
      verify(repository, times(1)).refreshMeterializedView();
    } finally {
      release.countDown();
      first.join(AWAIT_MILLIS);
      second.join(AWAIT_MILLIS);
    }

    verify(repository, times(2)).refreshMeterializedView();
  }

  private static boolean awaitThreadState(Thread thread, Thread.State target, long timeoutMillis) {
    long deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMillis);
    while (thread.getState() != target) {
      if (System.nanoTime() >= deadline) {
        return false;
      }
      Thread.onSpinWait();
    }
    return true;
  }
}
