package ca.bnc.wealth.common.fum.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class UserServiceHelperTest {

  private UserServiceHelper userServiceHelper;
  @MockitoBean
  private IamUserConfigurationRepository iamUserConfigurationRepository;
  @MockitoBean
  private IamRrCodeRangeRepository iamRrCodeRangeRepository;

  @Before
  public void setup() throws IllegalAccessException {
    userServiceHelper = new UserServiceHelper();
    FieldUtils.writeField(userServiceHelper, "iamRrCodeRangeRepository",
        iamRrCodeRangeRepository, true);
    FieldUtils.writeField(userServiceHelper, "iamUserConfigurationRepository",
        iamUserConfigurationRepository, true);
  }

  @Test
  public void getFirmUsers_nbinUsers() {
    when(iamUserConfigurationRepository.findAll(any(Specification.class))).thenReturn(
        Arrays.asList(getMockUserConfig()));
    List<IamUserConfiguration> users = userServiceHelper.getFirmUsers("NBIN", true);
    assertNotNull(users);
    assertTrue(users.size() > 0);
    assertTrue(users.get(0).getIdpSubject().equalsIgnoreCase("idp"));
  }

  @Test
  public void getFirmUsers_nonnbinUsers() {
    when(iamUserConfigurationRepository.findAll(any(Specification.class))).thenReturn(
        Arrays.asList(getMockUserConfig()));
    List<IamUserConfiguration> users = userServiceHelper.getFirmUsers("NBIN", false);
    assertNotNull(users);
    assertTrue(users.size() > 0);
    assertTrue(users.get(0).getIdpSubject().equalsIgnoreCase("idp"));
  }


  @Test
  public void getFirmUsersWithFirmLevelAccess_nbinUser() {
    when(iamUserConfigurationRepository.findAll(any(Specification.class))).thenReturn(
        Arrays.asList(getMockUserConfig()));
    List<IamUserConfiguration> users = userServiceHelper.getFirmUsersWithFirmLevelAccess("NBIN", true);
    assertNotNull(users);
    assertTrue(users.size() > 0);
    assertTrue(users.get(0).getIdpSubject().equalsIgnoreCase("idp"));
  }

  @Test
  public void getFirmUsersWithFirmLevelAccess_nonNbinUsers() {
    when(iamUserConfigurationRepository.findAll(any(Specification.class))).thenReturn(
        Arrays.asList(getMockUserConfig()));
    List<IamUserConfiguration> users = userServiceHelper.getFirmUsersWithFirmLevelAccess("NBIN", false);
    assertNotNull(users);
    assertTrue(users.size() > 0);
    assertTrue(users.get(0).getIdpSubject().equalsIgnoreCase("idp"));
  }

  private IamUserConfiguration getMockUserConfig() {
    IamUserConfiguration iamUserConfiguration = new IamUserConfiguration();
    iamUserConfiguration.setIdpSubject("idp");
    return  iamUserConfiguration;
  }
}
