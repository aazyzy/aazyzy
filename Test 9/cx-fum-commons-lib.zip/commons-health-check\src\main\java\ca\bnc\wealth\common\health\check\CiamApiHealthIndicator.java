package ca.bnc.wealth.common.health.check;

import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.health.contributor.Health;
import org.springframework.boot.health.contributor.HealthIndicator;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import ca.bnc.wealth.common.health.util.HealthCheckProperties;
import ca.bnc.wealth.common.health.util.HealthCheckUtil;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component("ciam")
@Slf4j
@AllArgsConstructor
@ConditionalOnProperty(prefix = "feign.ciamApi", name = "url_switch_validation_off_NWPI-13509")
public class CiamApiHealthIndicator implements HealthIndicator {

  @Autowired private HealthCheckProperties appProperties;
  @Autowired private HealthCheckUtil healthCheckUtil;

  @Override
  public Health health() {
    Map<String, String> statusMap = new HashMap<>();
    String apiUrl = appProperties.getCiamApiUrl() + appProperties.getCiamApiHealthUrlPath();
    boolean status = healthCheckUtil.testUrl("ciamApi", apiUrl, "GET", 403, statusMap);
    return status
        ? Health.up().withDetails(statusMap).build()
        : Health.down().withDetails(statusMap).build();
  }
}
