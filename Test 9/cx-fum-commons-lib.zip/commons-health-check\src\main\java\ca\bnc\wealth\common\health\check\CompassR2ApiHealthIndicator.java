package ca.bnc.wealth.common.health.check;

import ca.bnc.wealth.common.health.util.HealthCheckProperties;
import ca.bnc.wealth.common.health.util.HealthCheckUtil;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.health.contributor.Health;
import org.springframework.boot.health.contributor.HealthIndicator;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component("compassR2")
@Slf4j
@AllArgsConstructor
@ConditionalOnProperty(prefix = "feign.r2Api", name = "url")
public class CompassR2ApiHealthIndicator implements HealthIndicator {

  @Autowired private HealthCheckProperties appProperties;
  @Autowired private HealthCheckUtil healthCheckUtil;

  @Override
  public Health health() {
    Map statusMap = new HashMap<String, String>();
    String apiUrl = appProperties.getR2ApiUrl() + appProperties.getR2ApiHealthUrlPath();
    boolean status = healthCheckUtil.testUrl("r2Api", apiUrl, "GET", 200, statusMap);
    return status
        ? Health.up().withDetails(statusMap).build()
        : Health.down().withDetails(statusMap).build();
  }
}
