package ca.bnc.wealth.common.health.check;

import ca.bnc.wealth.api.authorization.security.token.TokenValidatorConfigLoader;
import ca.bnc.wealth.common.health.util.HealthCheckUtil;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.health.contributor.Health;
import org.springframework.boot.health.contributor.HealthIndicator;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component("oktaJwkKeys")
@Slf4j
@AllArgsConstructor
@ConditionalOnProperty(prefix = "oauth2.tokenValidators.okta", name = "keyUrl")
public class OktaJwkHealthIndicator implements HealthIndicator {

  @Autowired private TokenValidatorConfigLoader tokenValidatorConfigLoader;
  @Autowired HealthCheckUtil healthCheckUtil;

  @Override
  public Health health() {
    Map statusMap = new HashMap<String, String>();

    /** Total no. of Okta JWK urls that are being verified */
    int upSum =
        tokenValidatorConfigLoader.getTokenValidators().entrySet().stream()
            .mapToInt(
                tokenUrl ->
                    Boolean.TRUE.equals(
                            healthCheckUtil.testUrl(
                                tokenUrl.getKey(),
                                tokenUrl.getValue().getKeyUrl(),
                                "GET",
                                200,
                                statusMap))
                        ? 1
                        : 0)
            .sum();

    return tokenValidatorConfigLoader.getTokenValidators().size() == upSum
        ? Health.up().withDetails(statusMap).build()
        : Health.down().withDetails(statusMap).build();
  }
}
