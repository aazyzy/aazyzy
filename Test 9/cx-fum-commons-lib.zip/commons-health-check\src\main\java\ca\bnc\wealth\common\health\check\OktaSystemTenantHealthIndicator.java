package ca.bnc.wealth.common.health.check;

import ca.bnc.wealth.api.authorization.security.token.TokenValidatorConfigLoader;
import ca.bnc.wealth.common.health.util.HealthCheckUtil;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.health.contributor.Health;
import org.springframework.boot.health.contributor.HealthIndicator;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component("oktaSystemToken")
@Slf4j
@AllArgsConstructor
@ConditionalOnProperty(prefix = "oauth2.systemTokens.system", name = "tokenUrl")
public class OktaSystemTenantHealthIndicator implements HealthIndicator {

  @Autowired private TokenValidatorConfigLoader tokenValidatorConfigLoader;
  @Autowired HealthCheckUtil healthCheckUtil;

  @Override
  public Health health() {
    Map statusMap = new HashMap<String, String>();

    /** Total no. of System token urls that are being verified */
    int upSum =
        tokenValidatorConfigLoader.getSystemTokens().entrySet().stream()
            .mapToInt(
                tokenUrl ->
                    Boolean.TRUE.equals(
                            healthCheckUtil.testUrl(
                                tokenUrl.getKey(),
                                tokenUrl.getValue().getTokenUrl(),
                                "POST",
                                400,
                                statusMap))
                        ? 1
                        : 0)
            .sum();

    return tokenValidatorConfigLoader.getSystemTokens().size() == upSum
        ? Health.up().withDetails(statusMap).build()
        : Health.down().withDetails(statusMap).build();
  }
}
