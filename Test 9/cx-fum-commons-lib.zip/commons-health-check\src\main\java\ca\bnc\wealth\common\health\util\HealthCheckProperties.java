package ca.bnc.wealth.common.health.util;

import lombok.Data;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Data
@Getter
public class HealthCheckProperties {
  @Value("${feign.ciamApi.url}")
  private String ciamApiUrl;

  @Value("${feign.ciamApi.healthUrlPath:profiles/me}")
  private String ciamApiHealthUrlPath;

  @Value("${feign.r2Api.url}")
  private String r2ApiUrl;

  @Value("${feign.r2Api.healthUrlPath:cxr2/v1/rest-adaptor-docs}")
  private String r2ApiHealthUrlPath;
}
