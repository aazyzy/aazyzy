package ca.bnc.wealth.common.health.util;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@AllArgsConstructor
@Slf4j
@Service
public class HealthCheckUtil {
  public boolean testUrl(
      String name,
      String urlString,
      String connectionMethod,
      Integer responseCode,
      Map<String, String> statusMap) {
    URL urlToTest = toUrl(urlString);
    try {
      HttpURLConnection connection = (HttpURLConnection) urlToTest.openConnection();
      connection.setRequestMethod(connectionMethod);
      connection.connect();
      if (connection.getResponseCode() == responseCode) {
        statusMap.put(name, String.format("%s : Connection verified", urlString));
        return true;
      } else {
        statusMap.put(
            name,
            String.format(
                "%s: Connection failed with status code %d",
                urlString, connection.getResponseCode()));
        return false;
      }
    } catch (IOException e) {
      log.error("Error connecting to Key URL Host {} with error: {}", urlString, e.getMessage());
      return false;
    }
  }

  private URL toUrl(String url) {
    try {
      return new URL(url);
    } catch (MalformedURLException e) {
      throw new IllegalArgumentException("Invalid token validator url : " + url);
    }
  }
}
