package ca.bnc.wealth.common.health;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.health.check.CompassR2ApiHealthIndicator;
import ca.bnc.wealth.common.health.util.HealthCheckProperties;
import ca.bnc.wealth.common.health.util.HealthCheckUtil;
import java.util.HashMap;
import java.util.Map;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.health.contributor.Health;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class CompassR2ApiHealthIndicatorTest {

  private CompassR2ApiHealthIndicator compassR2ApiHealthIndicator;
  @MockitoBean private HealthCheckProperties appProperties;
  @MockitoBean private HealthCheckUtil healthCheckUtil;

  @Before
  public void setup() {
    compassR2ApiHealthIndicator = new CompassR2ApiHealthIndicator(appProperties, healthCheckUtil);
  }

  @Test
  public void testWhenServiceIsUp() {
    Map statusMap = new HashMap<String, String>();
    statusMap.put("compassR2", "SUCCESS");
    when(healthCheckUtil.testUrl(
            Mockito.anyString(),
            Mockito.anyString(),
            Mockito.anyString(),
            Mockito.anyInt(),
            Mockito.anyMap()))
        .thenReturn(true);
    Health ciamHealth = compassR2ApiHealthIndicator.health();
    assertEquals(Health.up().build().getStatus(), ciamHealth.getStatus());
  }

  @Test
  public void testWhenServiceIsDown() {
    Map statusMap = new HashMap<String, String>();
    statusMap.put("compassR2", "SUCCESS");
    when(healthCheckUtil.testUrl(
            Mockito.anyString(),
            Mockito.anyString(),
            Mockito.anyString(),
            Mockito.anyInt(),
            Mockito.anyMap()))
        .thenReturn(false);
    Health ciamHealth = compassR2ApiHealthIndicator.health();
    assertEquals(Health.down().build().getStatus(), ciamHealth.getStatus());
  }
}
