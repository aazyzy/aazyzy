package ca.bnc.wealth.common.health;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.security.token.TokenValidatorConfigLoader;
import ca.bnc.wealth.api.authorization.security.token.TokenValidatorProperty;
import ca.bnc.wealth.common.health.check.OktaJwkHealthIndicator;
import ca.bnc.wealth.common.health.util.HealthCheckUtil;
import java.util.HashMap;
import java.util.Map;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.health.contributor.Health;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class OktaJwkHealthIndicatorTest {

  private OktaJwkHealthIndicator oktaJwkHealthIndicator;
  @MockitoBean private TokenValidatorConfigLoader tokenValidatorConfigLoader;
  @MockitoBean private HealthCheckUtil healthCheckUtil;
  private Map<String, TokenValidatorProperty> oktaJwksMap;

  @Before
  public void setup() {

    oktaJwksMap =
        new HashMap<>() {
          {
            put("okta", getProperty("okta"));
            put("employee", getProperty("employee"));
          }
        };
    when(tokenValidatorConfigLoader.getTokenValidators()).thenReturn(oktaJwksMap);
    oktaJwkHealthIndicator =
        new OktaJwkHealthIndicator(tokenValidatorConfigLoader, healthCheckUtil);
  }

  public TokenValidatorProperty getProperty(String keyUrl) {
    TokenValidatorProperty prop = new TokenValidatorProperty();
    prop.setKeyUrl(keyUrl);
    return prop;
  }

  @Test
  public void testWhenServiceIsPartiallyUp() {
    Map statusMap = new HashMap<String, String>();
    when(healthCheckUtil.testUrl("okta", "okta", "GET", 200, statusMap)).thenReturn(true);
    when(healthCheckUtil.testUrl("employee", "employee", "GET", 200, statusMap)).thenReturn(false);
    Health oktaHealth = oktaJwkHealthIndicator.health();
    assertEquals(Health.down().build().getStatus(), oktaHealth.getStatus());
  }

  @Test
  public void testWhenServiceIsUp() {
    Map statusMap = new HashMap<String, String>();
    when(healthCheckUtil.testUrl("okta", "okta", "GET", 200, statusMap)).thenReturn(true);
    when(healthCheckUtil.testUrl("employee", "employee", "GET", 200, statusMap)).thenReturn(true);
    Health oktaHealth = oktaJwkHealthIndicator.health();
    assertEquals(Health.up().build().getStatus(), oktaHealth.getStatus());
  }

  @Test
  public void testWhenServiceIsDown() {
    when(healthCheckUtil.testUrl(
            Mockito.anyString(),
            Mockito.anyString(),
            Mockito.anyString(),
            Mockito.anyInt(),
            Mockito.anyMap()))
        .thenReturn(false);
    Health oktaHealth = oktaJwkHealthIndicator.health();
    assertEquals(Health.down().build().getStatus(), oktaHealth.getStatus());
  }
}
