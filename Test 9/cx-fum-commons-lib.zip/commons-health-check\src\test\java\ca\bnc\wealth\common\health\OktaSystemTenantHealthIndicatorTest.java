package ca.bnc.wealth.common.health;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.security.token.TokenValidatorConfigLoader;
import ca.bnc.wealth.api.authorization.system.token.config.SystemTokenProperty;
import ca.bnc.wealth.common.health.check.OktaSystemTenantHealthIndicator;
import ca.bnc.wealth.common.health.util.HealthCheckUtil;
import java.util.HashMap;
import java.util.Map;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.health.contributor.Health;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class OktaSystemTenantHealthIndicatorTest {

  private OktaSystemTenantHealthIndicator oktaSystemTenantHealthIndicator;
  @MockitoBean private TokenValidatorConfigLoader tokenValidatorConfigLoader;
  @MockitoBean private HealthCheckUtil healthCheckUtil;
  private Map<String, SystemTokenProperty> systemTenantMap;

  @Before
  public void setup() {

    systemTenantMap =
        new HashMap<>() {
          {
            put("system-1", getProperty("system-1"));
            put("system-2", getProperty("system-2"));
          }
        };
    when(tokenValidatorConfigLoader.getSystemTokens()).thenReturn(systemTenantMap);
    oktaSystemTenantHealthIndicator =
        new OktaSystemTenantHealthIndicator(tokenValidatorConfigLoader, healthCheckUtil);
  }

  public SystemTokenProperty getProperty(String tokenUrl) {
    SystemTokenProperty prop = new SystemTokenProperty();
    prop.setTokenUrl(tokenUrl);
    return prop;
  }

  @Test
  public void testWhenServiceIsPartiallyUp() {
    Map statusMap = new HashMap<String, String>();
    when(healthCheckUtil.testUrl("system-1", "system-1", "POST", 400, statusMap)).thenReturn(true);
    when(healthCheckUtil.testUrl("system-2", "system-2", "POST", 400, statusMap)).thenReturn(false);
    Health oktaHealth = oktaSystemTenantHealthIndicator.health();
    assertEquals(Health.down().build().getStatus(), oktaHealth.getStatus());
  }

  @Test
  public void testWhenServiceIsUp() {
    Map statusMap = new HashMap<String, String>();
    when(healthCheckUtil.testUrl("system-1", "system-1", "POST", 400, statusMap)).thenReturn(true);
    when(healthCheckUtil.testUrl("system-2", "system-2", "POST", 400, statusMap)).thenReturn(true);
    Health oktaHealth = oktaSystemTenantHealthIndicator.health();
    assertEquals(Health.up().build().getStatus(), oktaHealth.getStatus());
  }

  @Test
  public void testWhenServiceIsDown() {
    when(healthCheckUtil.testUrl(
            Mockito.anyString(),
            Mockito.anyString(),
            Mockito.anyString(),
            Mockito.anyInt(),
            Mockito.anyMap()))
        .thenReturn(false);
    Health oktaHealth = oktaSystemTenantHealthIndicator.health();
    assertEquals(Health.down().build().getStatus(), oktaHealth.getStatus());
  }
}
