package ca.bnc.wealth.common.jpa.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.util.Properties;
import javax.sql.DataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.util.StringUtils;
import software.amazon.jdbc.ds.AwsWrapperDataSource;


@Slf4j
@Configuration
public class DatabaseConfig {
  @Value("${postgres.datasource.jdbcUrl}")
  private String jdbcUrl;

  @Value("${postgres.datasource.username}")
  private String username;

  @Value("${postgres.datasource.password}")
  private String password;

  @Value("${postgres.read.datasource.jdbcUrl}")
  private String readJdbcUrl;

  @Value("${postgres.read.datasource.username}")
  private String readUsername;

  @Value("${postgres.read.datasource.password}")
  private String readPassword;

  @Value("${postgres.datasource.testQuery:select version()}")
  private String testQuery;

  @Value("${postgres.datasource.hikariMaximumPoolSize.userConfig:100}")
  private int hikariMaximumPoolSize;

  @Value("${postgres.datasource.hikariIdleTimeout.iam:-1}")
  private long hikariIdleTimeout;

  @Value("${postgres.datasource.hikariIdleConnections.iam:-1}")
  private int hikariIdleConnections;

  @Value("${postgres.iam.authentication:false}")
  private boolean useIamAuthentication;

  @Value("${postgres.iam.iamRegion:ca-central-1}")
  private String iamRegion;

  @Value("${postgres.iam.serverName}")
  private String serverName;

  @Value("${postgres.iam.serverPort}")
  private String serverPort;

  @Value("${postgres.iam.iamDefaultPort:5432}")
  private String iamDefaultPort;

  @Value("${postgres.iam.databaseUser}")
  private String iamDatabaseUser;

  @Value("${postgres.iam.database}")
  private String database;

  @Value("${postgres.iam.wrapperDialect:}")
  private String wrapperDialect;

  @Primary
  @Bean(name = "dataSourcePostgres")
  public DataSource dataSource() {
    if(useIamAuthentication) {
      return getDsWithIam();
    }
    return getDataSourceWithCredentials(jdbcUrl, username, password);
  }

  @Primary
  @Bean("postgresJdbcTemplate")
  public NamedParameterJdbcTemplate namedParameterJdbcTemplate(
      @Qualifier("dataSourcePostgres") DataSource postgresDataSource) {
    return new NamedParameterJdbcTemplate(postgresDataSource);
  }

  private DataSource getDsWithIam() {
    log.info("DS::Using IAM authentication for Postgres");
    HikariConfig config = new HikariConfig();
    String iamJdbcUrl = "jdbc:postgresql://" + serverName + ":" + serverPort + "/" + database;
    config.setJdbcUrl(iamJdbcUrl);
    config.setUsername(iamDatabaseUser);
    config.setConnectionTestQuery(testQuery);
    config.setMaximumPoolSize(hikariMaximumPoolSize);
    if (hikariIdleTimeout != -1) {
      config.setIdleTimeout(hikariIdleTimeout);
    }
    if (hikariIdleConnections != -1) {
      config.setMinimumIdle(hikariIdleConnections);
    }

    config.setDataSourceClassName(AwsWrapperDataSource.class.getName());
    config.setExceptionOverrideClassName("software.amazon.jdbc.util.HikariCPSQLException");
    config.addDataSourceProperty("serverName",serverName);
    config.addDataSourceProperty("jdbcProtocol", "jdbc:postgresql://");
    config.addDataSourceProperty("serverPort", serverPort);
    config.addDataSourceProperty("database", database);
    config.addDataSourceProperty("targetDataSourceClassName", "org.postgresql.ds.PGSimpleDataSource");
    config.addDataSourceProperty("targetDataSourceProperties", iamWrapperProperties());

    return new HikariDataSource(config);
  }

  Properties iamWrapperProperties() {
    Properties targetDataSourceProps = new Properties();
    targetDataSourceProps.setProperty("wrapperPlugins", "iam,failover,efm2");
    targetDataSourceProps.setProperty("iamRegion", iamRegion);
    targetDataSourceProps.setProperty("iamDefaultPort", iamDefaultPort);
    // A fixed dialect is never re-detected. aurora-pg keeps an Aurora Global Database cluster on the
    // single-region topology the 2.x wrapper used: the global dialect wrapper 4.x detects there
    // requires globalClusterInstanceHostPatterns.
    if (StringUtils.hasText(wrapperDialect)) {
      targetDataSourceProps.setProperty("wrapperDialect", wrapperDialect);
    }
    return targetDataSourceProps;
  }

  private DataSource getDataSourceWithCredentials(String jdbcUrl, String username, String password) {
    log.info("DS::Using Postgres Credentials");

    HikariConfig config = new HikariConfig();
    config.setJdbcUrl(jdbcUrl);
    config.setUsername(username);
    config.setPassword(password);
    config.setConnectionTestQuery(testQuery);
    config.setMaximumPoolSize(hikariMaximumPoolSize);
    if (hikariIdleTimeout != -1) {
      config.setIdleTimeout(hikariIdleTimeout);
    }
    if (hikariIdleConnections != -1) {
      config.setMinimumIdle(hikariIdleConnections);
    }

    return new HikariDataSource(config);
  }

  @Bean(name = "readDataSourcePostgres")
  public DataSource readDataSource() {
    return getDataSourceWithCredentials(readJdbcUrl, readUsername, readPassword);
  }

  @Bean("readJdbcTemplate")
  public NamedParameterJdbcTemplate readJdbcTemplate(
      @Qualifier("readDataSourcePostgres") DataSource postgresDataSource) {
    return new NamedParameterJdbcTemplate(postgresDataSource);
  }

}
