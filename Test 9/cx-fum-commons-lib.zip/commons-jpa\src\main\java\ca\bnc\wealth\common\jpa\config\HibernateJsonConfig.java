package ca.bnc.wealth.common.jpa.config;

import org.hibernate.cfg.AvailableSettings;
import org.hibernate.type.format.jackson.Jackson3JsonFormatMapper;
import org.springframework.boot.hibernate.autoconfigure.HibernatePropertiesCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tools.jackson.databind.json.JsonMapper;

/**
 * Maps the JSON columns with Jackson 3 and Jackson 2 defaults, which write the same JSON as the
 * Jackson 2 mapper Hibernate used on the Spring Boot 3 line, so either line reads the other's
 * rows. Without it Hibernate 7 picks Jackson 2 whenever it is on the classpath.
 */
@Configuration
public class HibernateJsonConfig {

  @Bean
  public HibernatePropertiesCustomizer jsonFormatMapperCustomizer() {
    return hibernateProperties ->
        hibernateProperties.putIfAbsent(
            AvailableSettings.JSON_FORMAT_MAPPER,
            new Jackson3JsonFormatMapper(JsonMapper.builderWithJackson2Defaults().build()));
  }
}
