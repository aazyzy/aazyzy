package ca.bnc.wealth.common.jpa.entity;

import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public interface EntityInterface {

    Long getId();

    default List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
        throw new RuntimeException("Entity don't have unique field defined");
    }
}
