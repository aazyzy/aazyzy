package ca.bnc.wealth.common.jpa.entity.enums;

public enum AttestationStatusType {
  PENDING,
  AWAITING_REVIEW,
  UNDER_REVIEW,
  PROCESSING,
  DRAFT,
  PUBLISHED,
  COMPLETE,
  CANCELLED,
  DELETED,
  SYSTEM_ERROR,
  INVALID
}