package ca.bnc.wealth.common.jpa.entity.enums;

public enum AuditEventDetailsType {
  IDENTITY, ACCESS, RR_CODE, R2, SZ, OSS, STATE, APP_PREFERENCES;;
}
