package ca.bnc.wealth.common.jpa.entity.enums;

public enum AuditEventType {
CREATE, UPDATE, UPDATE_BY_FIRM, PASSWORD_RESET;
}
