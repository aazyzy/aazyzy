package ca.bnc.wealth.common.jpa.entity.enums;

public enum BatchType {
  UPLOAD, EXPORT;
}
