package ca.bnc.wealth.common.jpa.entity.enums;

public enum BulkUploadStatus {
  UPLOADED, SUBMITTED, PROCESSING, PART_SUCCESS, SUCCESS, FAILED;
}
