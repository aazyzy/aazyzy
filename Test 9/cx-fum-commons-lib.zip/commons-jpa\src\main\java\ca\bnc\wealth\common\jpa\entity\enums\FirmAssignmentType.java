package ca.bnc.wealth.common.jpa.entity.enums;

public enum FirmAssignmentType {
    R, P, S;
}
