package ca.bnc.wealth.common.jpa.entity.enums;

public enum FirmType {
  IB, PM, IFM, OT, NBIN, Internal, MFDA;
}
