package ca.bnc.wealth.common.jpa.entity.enums;

public enum PackageAssignmentMode {
  M, O
}
