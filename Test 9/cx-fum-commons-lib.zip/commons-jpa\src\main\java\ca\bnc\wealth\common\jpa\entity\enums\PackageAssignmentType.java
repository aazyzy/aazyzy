package ca.bnc.wealth.common.jpa.entity.enums;

public enum PackageAssignmentType {
  G, S;
}
