package ca.bnc.wealth.common.jpa.entity.enums;

public enum PackageType {
  F, U;
}
