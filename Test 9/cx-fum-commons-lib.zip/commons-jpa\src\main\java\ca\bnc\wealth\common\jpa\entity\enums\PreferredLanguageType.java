package ca.bnc.wealth.common.jpa.entity.enums;

public enum PreferredLanguageType {
  EN,FR;
}
