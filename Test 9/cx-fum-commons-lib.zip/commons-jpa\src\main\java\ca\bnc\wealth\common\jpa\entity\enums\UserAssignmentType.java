package ca.bnc.wealth.common.jpa.entity.enums;

public enum UserAssignmentType {
    R, P, F,S,G;
}
