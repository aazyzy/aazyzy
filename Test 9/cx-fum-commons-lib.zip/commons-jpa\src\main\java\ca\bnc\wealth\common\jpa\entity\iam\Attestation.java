package ca.bnc.wealth.common.jpa.entity.iam;

import java.sql.Timestamp;
import java.util.List;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import ca.bnc.wealth.common.jpa.entity.enums.AttestationStatusType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "`ATTESTATION`", schema = "`IAM_V2`")
public class Attestation {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`ATTESTATION_ID`")
  private long attestationId;

  @Column(name = "`LABEL`")
  private String label;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATED_DATE`")
  private Timestamp createdDate;

  @Column(name = "`UPDATED_BY`")
  private String updatedBy;

  @Column(name = "`UPDATED_DATE`")
  private Timestamp updatedDate;

  @Column(name = "`PUBLISHED_BY`")
  private String publishedBy;

  @Column(name = "`PUBLISHED_DATE`")
  private Timestamp publishedDate;

  @Enumerated(EnumType.STRING)
  @Column(name = "`STATUS`")
  @JdbcTypeCode(SqlTypes.NAMED_ENUM)
  private AttestationStatusType attestationStatusType;

  @Column(name = "`COUNT`")
  private Integer count;

  @OneToMany(mappedBy = "attestation")
  List<AttestationSourceData> attestationSourceDataList;

  @OneToMany(mappedBy = "attestation")
  List<AttestationFirmStaging> attestationFirmStagingList;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "`UPDATED_BY`", referencedColumnName = "`IDP_SUBJECT`", insertable = false, updatable = false)
  private IamUserConfiguration updatedByName;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "`PUBLISHED_BY`", referencedColumnName = "`IDP_SUBJECT`", insertable = false, updatable = false)
  private IamUserConfiguration publishedByName;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "`CREATED_BY`", referencedColumnName = "`IDP_SUBJECT`", insertable = false, updatable = false)
  private IamUserConfiguration createdByName;

}