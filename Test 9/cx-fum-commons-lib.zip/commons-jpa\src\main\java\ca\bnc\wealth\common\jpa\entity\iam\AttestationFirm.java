package ca.bnc.wealth.common.jpa.entity.iam;

import java.sql.Timestamp;
import ca.bnc.wealth.common.jpa.entity.enums.AttestationStatusType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "vw_attestation_firm", schema = "`IAM_V2`")
public class AttestationFirm {

  @Id
  @Column(name = "`ID`")
  private Long id;

  @Column(name = "`ATTESTATION_FIRM_ID`")
  private Long attestationFirmId;

  @Column(name = "`ATTESTATION_ID`")
  private Long attestationId;

  @Column(name = "`LABEL`")
  private String label;

  @Column(name = "`STAGE`")
  private String stage;

  @Column(name = "`FIRM_ID`")
  private String firmId;

  @Column(name = "`FIRM_NAME`")
  private String firmName;

  @Enumerated(EnumType.STRING)
  @Column(name = "`STATUS`")
  private AttestationStatusType status;

  @Column(name = "`RECORD_COUNT`")
  private Integer recordCount;

  @Column(name = "`CREATED_BY_NAME`")
  private String createdByName;

  @Column(name = "`CREATED_DATE`")
  private Timestamp createdDate;

  @Column(name = "`ACKNOWLEDGED_BY_NAME`")
  private String acknowledgedByName;

  @Column(name = "`ACKNOWLEDGED_DATE`")
  private Timestamp acknowledgedDate;

}
