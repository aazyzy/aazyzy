package ca.bnc.wealth.common.jpa.entity.iam;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "`ATTESTATION_FIRM_FILE`", schema = "`IAM_V2`")
public class AttestationFirmFile {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`ATTESTATION_FIRM_FILE_ID`")
  private long attestationFirmFileId;

  @Column(name = "`DOWNLOADED_BY`")
  private String downloadedBy;

  @Column(name = "`DOWNLOADED_DATE`")
  private Timestamp downloadedDate;

  @Column(name = "`REPORT_ID`")
  private String reportId;

  @Column(name = "`REPORT_VERSION_ID`")
  private String reportVersionId;

  @ManyToOne
  @JoinColumn(name = "`ATTESTATION_FIRM_STAGING_ID`", referencedColumnName = "`ATTESTATION_FIRM_STAGING_ID`")
  private AttestationFirmStaging attestationFirmStaging;

  @ManyToOne
  @JoinColumn(name = "`ATTESTATION_FIRM_PUBLISHED_ID`", referencedColumnName = "`ATTESTATION_FIRM_PUBLISHED_ID`")
  private AttestationFirmPublished attestationFirmPublished;

  @Column(name = "`RECORD_COUNT`")
  private Integer recordCount;

  @Column(name = "`GENERATED`")
  private Boolean generated;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATED_DATE`")
  private Timestamp createdDate;

  @Column(name = "`UPDATED_BY`")
  private String updatedBy;

  @Column(name = "`UPDATED_DATE`")
  private Timestamp updatedDate;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "`CREATED_BY`", referencedColumnName = "`IDP_SUBJECT`", insertable = false, updatable = false)
  private IamUserConfiguration createdByName;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "`UPDATED_BY`", referencedColumnName = "`IDP_SUBJECT`", insertable = false, updatable = false)
  private IamUserConfiguration updatedByName;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "`DOWNLOADED_BY`", referencedColumnName = "`IDP_SUBJECT`", insertable = false, updatable = false)
  private IamUserConfiguration downloadedByName;
}