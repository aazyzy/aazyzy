package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.enums.AttestationStatusType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Getter
@Setter
@Entity
@Table(name = "`ATTESTATION_FIRM_HISTORY`", schema = "`IAM_V2`")
public class AttestationFirmHistory {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`ATTESTATION_FIRM_HISTORY_ID`")
  private long attestationFirmHistoryId;

  @Column(name = "`ATTESTATION_FIRM_PUBLISHED_ID`")
  private Integer attestationFirmPublishedId;

  @ManyToOne
  @JoinColumn(name = "`ATTESTATION_ID`", referencedColumnName = "`ATTESTATION_ID`")
  private Attestation attestation;

  @ManyToOne
  @JoinColumn(name = "`FIRM_ENTITY_ID`", referencedColumnName = "`FIRM_ENTITY_ID`")
  private Firm firm;

  @Enumerated(EnumType.STRING)
  @Column(name = "`STATUS`")
  @JdbcTypeCode(SqlTypes.NAMED_ENUM)
  private AttestationStatusType attestationStatusType;

  @Column(name = "`RECORD_COUNT`")
  private Integer recordCount;

  @Column(name = "`ACKNOWLEDGED_BY`")
  private String acknowledgedBy;

  @Column(name = "`ACKNOWLEDGED_DATE`")
  private Timestamp acknowledgedDate;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATED_DATE`")
  private Timestamp createdDate;

  @Column(name = "`UPDATED_BY`")
  private String updatedBy;

  @Column(name = "`UPDATED_DATE`")
  private Timestamp updatedDate;
}