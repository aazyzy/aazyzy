package ca.bnc.wealth.common.jpa.entity.iam;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "`ATTESTATION_SOURCE_DATA`", schema = "`IAM_V2`")
public class AttestationSourceData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`ATTESTATION_SOURCE_DATA_ID`")
    private long attestationSourceDataId;

    @Column(name = "`DATA_NAME`")
    private String dataName;

    @Column(name = "`REPORT_ID`")
    private String reportId;

    @Column(name = "`REPORT_VERSION_ID`")
    private String reportVersionId;

    @ManyToOne
    @JoinColumn(name = "`ATTESTATION_ID`", referencedColumnName = "`ATTESTATION_ID`")
    private Attestation attestation;

    @ManyToOne
    @JoinColumn(name = "`ATTESTATION_SOURCE_TYPE_ID`", referencedColumnName = "`ATTESTATION_SOURCE_TYPE_ID`")
    private AttestationSourceType attestationSourceType;

    @Column(name = "`RECORD_COUNT`")
    private Integer recordCount;

    @Column(name = "`UPDATED_BY`")
    private String updatedBy;

    @Column(name = "`UPDATED_DATE`")
    private Timestamp updatedDate;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATED_DATE`")
    private Timestamp createdDate;
}
