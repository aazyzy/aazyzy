package ca.bnc.wealth.common.jpa.entity.iam;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "`ATTESTATION_SOURCE_TYPE`", schema = "`IAM_V2`")
public class AttestationSourceType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`ATTESTATION_SOURCE_TYPE_ID`")
    private long attestationSourceTypeId;

    @Column(name = "`NAME`")
    private String name;

    @Column(name = "`CODE`")
    private String code;

    @Column(name = "`PARAMS`")
    private String params;

    @Column(name = "`ACTIVE`")
    private Boolean active;

    @Column(name = "`LATEST`")
    private Boolean latest;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATED_DATE`")
    private Timestamp createdDate;

    @Column(name = "`UPDATED_BY`")
    private String updatedBy;

    @Column(name = "`UPDATED_DATE`")
    private Timestamp updatedDate;
}
