package ca.bnc.wealth.common.jpa.entity.iam;

import jakarta.persistence.*;
import java.sql.Timestamp;
import java.sql.Types;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;

@Getter
@Setter
@Entity
@Table(name = "`AUDIT`", schema = "`IAM_V2`")
public class Audit {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`AUDIT_ID`")
  private long auditId;

  @Column(name = "`FILE_NAME`")
  private String fileName;

  @Lob
  @Column(name = "`METADATA`")
  @JdbcTypeCode(Types.VARBINARY)
  private byte[] metadata;

  @Lob
  @Column(name = "`FILE_CONTENTS`")
  @JdbcTypeCode(Types.VARBINARY)
  private byte[] fileContents;

  @Column(name = "`UPDATED_BY`")
  private String updatedBy;

  @Column(name = "`UPDATED_DATE`")
  private Timestamp updatedDate;

}
