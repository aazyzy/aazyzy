package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.enums.AuditEventType;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.sql.Timestamp;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Getter
@Setter
@Entity
@Table(name = "`AUDIT_LOG_EVENT`", schema = "`IAM_V2`",
    uniqueConstraints = {
    @UniqueConstraint(columnNames = {"`MESSAGE_UUID`"})
    })
public class AuditLogEvent {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`AUDIT_LOG_EVENT_ID`")
  private long auditLogEventID;

  @Column(name = "`MESSAGE_UUID`")
  private String messageUUID;

  @Column(name = "`IDP_SUBJECT`")
  private String idpSubject;

  @Enumerated(EnumType.STRING)
  @Column(name = "`AUDIT_EVENT_TYPE`")
  @JdbcTypeCode(SqlTypes.NAMED_ENUM)
  private AuditEventType auditEventType;

  @Column(name = "`RECORD`")
  @JdbcTypeCode(SqlTypes.JSON)
  private UserConfiguration record;

  @Column(name = "`RECORD_BEFORE`")
  @JdbcTypeCode(SqlTypes.JSON)
  private UserConfiguration recordBefore;

  @Column(name = "`CHANGE_BY`")
  private String changeBy;

  @Column(name = "`CHANGE_DATE`")
  private Timestamp changeDate;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATED_DATE`")
  private Timestamp createdDate;

  @OneToMany(mappedBy = "auditLogEvent")
  private List<AuditLogEventDetails> auditLogEventDetails;
}
