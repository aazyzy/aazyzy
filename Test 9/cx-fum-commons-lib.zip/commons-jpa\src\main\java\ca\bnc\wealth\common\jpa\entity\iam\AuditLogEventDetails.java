package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.enums.AuditEventDetailsType;
import ca.bnc.wealth.common.jpa.entity.jsonb.AuditEventDetails;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Getter
@Setter
@Entity
@Table(name = "`AUDIT_LOG_EVENT_DETAILS`", schema = "`IAM_V2`")
public class AuditLogEventDetails {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`AUDIT_LOG_EVENT_DETAILS_ID`")
  private long auditLogEventDetailsID;

  @ManyToOne
  @JoinColumn(name = "`AUDIT_LOG_EVENT_ID`", referencedColumnName = "`AUDIT_LOG_EVENT_ID`")
  private AuditLogEvent auditLogEvent;

  @Enumerated(EnumType.STRING)
  @Column(name = "`AUDIT_EVENT_DETAILS_TYPE`")
  @JdbcTypeCode(SqlTypes.NAMED_ENUM)
  private AuditEventDetailsType auditEventDetailsType;

  @Column(name = "`RECORD`")
  @JdbcTypeCode(SqlTypes.JSON)
  AuditEventDetails record;

  @Column(name = "`RECORD_BEFORE`")
  @JdbcTypeCode(SqlTypes.JSON)
  AuditEventDetails recordBefore;

  @Column(name = "`CHANGE_BY`")
  private String changeBy;

  @Column(name = "`CHANGE_DATE`")
  private Timestamp changeDate;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATED_DATE`")
  private Timestamp createdDate;
}
