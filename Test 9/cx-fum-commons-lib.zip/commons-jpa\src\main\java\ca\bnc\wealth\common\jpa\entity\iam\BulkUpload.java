package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Getter
@Setter
@Entity
@Table(name = "`BULK_UPLOAD`", schema = "`IAM_V2`")
public class BulkUpload {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`BULK_UPLOAD_ID`")
  private long bulkUploadID;

  @Column(name = "`BATCH_ID`")
  private String batchID;

  @ManyToOne
  @JoinColumn(name = "`BULK_UPLOAD_TEMPLATE_ID`", referencedColumnName = "`BULK_UPLOAD_TEMPLATE_ID`")
  private BulkUploadTemplate bulkUploadTemplate;

  @ManyToOne
  @JoinColumn(name = "`AUDIT_ID`", referencedColumnName = "`AUDIT_ID`")
  private Audit audit;

  @Column(name = "`USER_REQUESTED_BY`")
  private String userRequestedBy;

  @Column(name = "`FIRM_ID`")
  private String firmId;

  @Enumerated(EnumType.STRING)
  @Column(name = "`STATUS`")
  @JdbcTypeCode(SqlTypes.NAMED_ENUM)
  private BulkUploadStatus bulkUploadStatus;

  @Column(name = "`TOTAL_RECORDS`")
  private Integer totalRecords;

  @Column(name = "`TOTAL_SUCCESS`")
  private Integer totalSuccess;

  @Column(name = "`TOTAL_FAILED`")
  private Integer totalFailed;

  @Column(name = "`TOTAL_PENDING`")
  private Integer totalPending;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATED_DATE`")
  private Timestamp createdDate;

  @Column(name = "`UPDATED_BY`")
  private String updatedBy;

  @Column(name = "`UPDATED_DATE`")
  private Timestamp updatedDate;

  @OneToMany(mappedBy = "bulkUpload")
  private List<BulkUploadDetails> bulkUploadDetails;

  @ManyToOne
  @JoinColumn(name = "`GENERATED_AUDIT_ID`", referencedColumnName = "`AUDIT_ID`")
  private Audit generatedAudit;
}
