package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import java.sql.Types;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Getter
@Setter
@Entity
@Table(name = "`BULK_UPLOAD_DETAIL`", schema = "`IAM_V2`")
public class BulkUploadDetails {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`BULK_UPLOAD_DETAIL_ID`")
  private long bulkUploadDetailID;

  @ManyToOne
  @JoinColumn(name = "`BULK_UPLOAD_ID`", referencedColumnName = "`BULK_UPLOAD_ID`")
  private BulkUpload bulkUpload;

  @Enumerated(EnumType.STRING)
  @Column(name = "`STATUS`")
  @JdbcTypeCode(SqlTypes.NAMED_ENUM)
  private BulkUploadStatus bulkUploadStatus;

  @Lob
  @Column(name = "`REQUEST`")
  @JdbcTypeCode(Types.VARBINARY)
  private byte[] request;

  @Lob
  @Column(name = "`RESPONSE`")
  @JdbcTypeCode(Types.VARBINARY)
  private byte[] response;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATED_DATE`")
  private Timestamp createdDate;

  @Column(name = "`UPDATED_BY`")
  private String updatedBy;

  @Column(name = "`UPDATED_DATE`")
  private Timestamp updatedDate;
}
