package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.enums.BatchType;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Getter
@Setter
@Entity
@Table(name = "`BULK_UPLOAD_TEMPLATE`", schema = "`IAM_V2`",
    uniqueConstraints = @UniqueConstraint(columnNames = {"`TEMPLATE_NAME`", "`BATCH_TYPE`"}))
public class BulkUploadTemplate {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`BULK_UPLOAD_TEMPLATE_ID`")
  private long bulkUploadTemplateID;

  @Column(name = "`TEMPLATE_NAME`")
  private String templateName;

  @Enumerated(EnumType.STRING)
  @Column(name = "`BATCH_TYPE`")
  @JdbcTypeCode(SqlTypes.NAMED_ENUM)
  private BatchType batchType;

  @Column(name = "`CONFIG_JSON`")
  @JdbcTypeCode(SqlTypes.JSON)
  private Template config;

  @Column(name = "`PLUGIN_URL`")
  private String pluginUrl;

  @Column(name = "`BULK_ID_PREFIX`")
  private String prefix;

  @Column(name = "`PASSWORD_CONFIG_JSON`")
  @JdbcTypeCode(SqlTypes.JSON)
  private Template passwordConfig;

  @Lob
  @Column(name = "`LAYOUT_USER`")
  @JdbcTypeCode(Types.VARBINARY)
  private byte[] layoutUser;

  @Lob
  @Column(name = "`LAYOUT_PASSWORD`")
  @JdbcTypeCode(Types.VARBINARY)
  private byte[] layoutPassword;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATED_DATE`")
  private Timestamp createdDate;

  @Column(name = "`UPDATED_BY`")
  private String updatedBy;

  @Column(name = "`UPDATED_DATE`")
  private Timestamp updatedDate;

  @Column(name = "`TEMPLATE_PREFERENCES`")
  @JdbcTypeCode(SqlTypes.JSON)
  private Map<String, String> templatePreferences;

  @OneToMany(mappedBy = "bulkUploadTemplate")
  private List<BulkUpload> bulkUploads;
}
