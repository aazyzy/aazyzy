package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "`CAPABILITY`", schema = "`IAM_V2`",
    uniqueConstraints = @UniqueConstraint(columnNames = {"`NAME`"}))
public class Capability implements EntityInterface {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`CAPABILITY_ID`")
  private long capabilityID;

  @Column(name = "`NAME`")
  private String name;

  @Column(name = "`DESCRIPTION`")
  private String description;

  @Column(name = "`LOB`")
  private String lob;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATED_DT`")
  private Timestamp creationDate;

  @Column(name = "`UPDATED_BY`")
  private String updatedBy;

  @Column(name = "`UPDATED_DT`")
  private Timestamp updateDate;

  @OneToMany(mappedBy = "capability")
  List<Role> roles;

  @OneToMany(mappedBy = "capability")
  List<Permission> permissions;

  @Override
  public Long getId() {
    return this.capabilityID;
  }

  @Override
  public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
    List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

    Map<String, Supplier<Object>> map = new HashMap<>();
    map.put("name", this::getName);

    lst.add(map);

    return lst;
  }
}
