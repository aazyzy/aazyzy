package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "`FEATURE_PACKAGE`", schema = "`IAM_V2`")
public class FeaturePackage implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`FEATURE_PACKAGE_ID`")
    private long featurePackageId;

    @Column(name = "`VERSION`")
    private String version;

    @ManyToOne
    @JoinColumn(name = "`PACKAGE_TEMPLATE_ID`")
    private PackageTemplate packageTemplate;

    @Column(name = "`ACTIVE`")
    private boolean isActive;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATED_DT`")
    private Timestamp creationDate;

    @Column(name = "`UPDATED_BY`")
    private String updatedBy;

    @Column(name = "`UPDATED_DT`")
    private Timestamp updateDate;

    @OneToMany(mappedBy = "featurePackage")
    private List<FeaturePackageAssignmentResource> featurePackageAssignmentResources;

    @OneToMany(mappedBy = "featurePackage")
    private List<FeaturePackageAssignmentUserGroup> featurePackageAssignmentUserGroups;

    @OneToMany(mappedBy = "featurePackage")
    private List<FirmAssignmentFeaturePackage> firmAssignmentFeaturePackages;

    @OneToMany(mappedBy = "featurePackage")
    private List<UserAssignmentFeaturePackage> userAssignmentFeaturePackages;

    @Override
    public Long getId() {
        return this.featurePackageId;
    }

}
