package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;

@Getter
@Setter
@Entity
@Table(name = "`FEATURE_PACKAGE_DETAILS`", schema = "`IAM_V2`",
        uniqueConstraints = @UniqueConstraint(columnNames = {"`FEATURE_PACKAGE_ID`",
                "`TEMPLATE_DETAIL_ID`"}))
public class FeaturePackageAssignmentResource implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`FEATURE_PACKAGE_DETAIL_ID`")
    private long featurePackageAssignmentId;

    @ManyToOne
    @JoinColumn(name = "`FEATURE_PACKAGE_ID`")
    private FeaturePackage featurePackage;

    @ManyToOne
    @JoinColumn(name = "`TEMPLATE_DETAIL_ID`")
    private PackageTemplateAssignmentResource packageTemplateAssignmentResource;

    @Column(name = "`SELECTED`")
    private boolean isSelected;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATED_DT`")
    private Timestamp creationDate;

    @Column(name = "`UPDATED_BY`")
    private String updatedBy;

    @Column(name = "`UPDATED_DT`")
    private Timestamp updateDate;

    @Override
    public Long getId() {
        return this.featurePackageAssignmentId;
    }

}

