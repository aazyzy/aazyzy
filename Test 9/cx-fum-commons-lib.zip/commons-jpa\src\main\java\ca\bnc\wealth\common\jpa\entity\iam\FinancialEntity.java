package ca.bnc.wealth.common.jpa.entity.iam;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "`FINANCIAL_ENTITY`", schema = "`IAM_V2`")
public class FinancialEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`FINANCIAL_ENTITY_ID`")
  private long financialEntityId;

  @Column(name = "`BROKER_CODE`", nullable = false)
  private String brokerCode;

  @Column(name = "`B_NUMBER`")
  private String branchNumber;

  @Column(name = "`DEALER_CODE`")
  private String dealerCode;

  @Column(name = "`DESCRIPTION`")
  private String description;

  @Column(name = "`LEGAL_ENTITY_IDENTIFIER`")
  private String legalEntityIdentifier;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATION_DATE`")
  private Timestamp creationDate;

  @Column(name = "`LAST_UPDATED_BY`")
  private String lastUpdatedBy;

  @Column(name = "`LAST_UPDATE_DATE`")
  private Timestamp lastUpdateDate;

  @OneToMany(mappedBy = "financialEntity")
  List<Firm> firms;
}
