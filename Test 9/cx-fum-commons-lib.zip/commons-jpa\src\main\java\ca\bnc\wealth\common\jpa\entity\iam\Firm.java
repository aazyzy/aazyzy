package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.sql.Timestamp;
import java.util.*;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Getter
@Setter
@Entity
@Table(
        name = "`FIRM`",
        schema = "`IAM_V2`",
        uniqueConstraints = @UniqueConstraint(columnNames = {"`FIRM_ID`"}))
public class Firm implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`FIRM_ENTITY_ID`")
    private Long firmEntityId;

    @Column(name = "`FIRM_ID`")
    private String firmId;

    @ManyToOne
    @JoinColumn(name = "`FINANCIAL_ENTITY_ID`")
    private FinancialEntity financialEntity;

    @Column(name = "`NAME`")
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(name = "`TYPE`")
    @JdbcTypeCode(SqlTypes.NAMED_ENUM)
    private FirmType firmType;

    @Enumerated(EnumType.STRING)
    @Column(name = "`PREFERRED_LANGUAGE`")
    @JdbcTypeCode(SqlTypes.NAMED_ENUM)
    private PreferredLanguageType preferredLanguageType;

    @Column(name = "`DESCRIPTION`")
    private String description;

    @ManyToOne
    @JoinColumn(name = "`PARENT_FIRM_ID`",  referencedColumnName = "`FIRM_ID`")
    private Firm parentFirm;

    @Column(name = "`STATE`")
    private String state;

    @Column(name = "`ACTIVE`")
    private Boolean active;

    @Column(name = "`STATUS_LAST_UPDATED`")
    private Timestamp statusLastUpdated;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATION_DATE`")
    private Timestamp creationDate;

    @Column(name = "`LAST_UPDATED_BY`")
    private String lastUpdatedBy;

    @Column(name = "`LAST_UPDATE_DATE`")
    private Timestamp lastUpdateDate;

    @Column(name = "`IDENTITY_SOURCE`")
    private String identitySource;

    @Column(name = "`CX_ACCESS_UNSET_KEY`")
    private String cxAccessUnsetKey;

    @Column(name = "`USER_LOGOUT_URL`")
    private String userLogoutUrl;

    @Column(name = "`INITIAL_ACTIVITY_DAYS`")
    private Integer initialActivityDays;

    @Column(name = "`EXTENDED_ACTIVITY_DAYS`")
    private Integer extendedActivityDays;

    @Column(name = "`FIRM_DISPLAY_NAME_EN`")
    private String firmDisplayNameEn;

    @Column(name = "`FIRM_DISPLAY_NAME_FR`")
    private String firmDisplayNameFr;

    @Column(name = "`FIRM_PREFERENCES`")
    @JdbcTypeCode(SqlTypes.JSON)
    private Map<String, String> firmPreferences;

    @OneToMany(mappedBy = "firm")
    private List<FirmAssignmentFeaturePackage> firmAssignmentFeaturePackages;

    @OneToMany(mappedBy = "firm")
    private List<FirmAssignmentRrCodeRange> firmAssignmentRrCodeRanges;

    @OneToMany(mappedBy = "firm")
    private List<UserAssignmentFirm> userAssignmentFirms;

    @OneToMany(mappedBy = "parentFirm")
    private Set<Firm> childFirms = new HashSet<>();

    @Override
    public Long getId() {
        return this.firmEntityId;
    }

    @Override
    public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
        List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

        Map<String, Supplier<Object>> map = new HashMap<>();
        map.put("firmId", this::getFirmId);
        lst.add(map);

        return lst;
    }
}
