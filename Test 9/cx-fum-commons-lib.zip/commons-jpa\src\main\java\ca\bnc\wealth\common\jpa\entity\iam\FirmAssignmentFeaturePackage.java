package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.enums.FirmAssignmentType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;

import java.sql.Timestamp;
import org.hibernate.type.SqlTypes;

@Getter
@Setter
@Entity
@Table(name = "`FIRM_ASSIGNMENT`", schema = "`IAM_V2`")
public class FirmAssignmentFeaturePackage implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`ID`")
    private long id;

    @ManyToOne
    @JoinColumn(name = "`FIRM_ENTITY_ID`", referencedColumnName = "`FIRM_ENTITY_ID`")
    private Firm firm;


    @Enumerated(EnumType.STRING)
    @Column(name = "`ASSIGNMENT_TYPE`")
    @JdbcTypeCode(SqlTypes.NAMED_ENUM)
    private FirmAssignmentType assignmentType;

    @ManyToOne
    @JoinColumn(name = "`ASSIGNEE_ID`")
    FeaturePackage featurePackage;

    @Column(name = "`EFFECTIVE_DATE`")
    private Timestamp effectiveDate;

    @Column(name = "`EXPIRY_DATE`")
    private Timestamp expiryDate;


    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATED_DT`")
    private Timestamp creationDate;

    @Column(name = "`UPDATED_BY`")
    private String updatedBy;

    @Column(name = "`UPDATED_DT`")
    private Timestamp updateDate;

    @Override
    public Long getId() {
        return this.id;
    }
}
