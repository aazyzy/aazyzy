package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Getter
@Setter
@Entity
@Table(name = "`CONTENT_TRANSLATION`", schema = "`IAM_V2`",
        uniqueConstraints = @UniqueConstraint(columnNames = {"`TRANSLATION_KEY`",
                "`LANGUAGE`"}))
public class IamContentTranslation implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`CONTENT_TRANSLATION_ID`")
    private long contentTranslationId;

    @Column(name = "`TRANSLATION_KEY`")
    private String translationKey;

    @Column(name = "`TRANSLATION_VALUE`")
    private String translationValue;

    @Enumerated(EnumType.STRING)
    @Column(name = "`LANGUAGE`")
    @JdbcTypeCode(SqlTypes.NAMED_ENUM)
    private PreferredLanguageType preferredLanguage;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATED_DT`")
    private Timestamp creationDate;

    @Column(name = "`UPDATED_BY`")
    private String lastUpdatedBy;

    @Column(name = "`UPDATED_DT`")
    private Timestamp lastUpdateDate;

    @Override
    public Long getId() {
        return this.contentTranslationId;
    }

    @Override
    public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
        List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

        Map<String, Supplier<Object>> map = new HashMap<>();
        map.put("translationKey", this::getTranslationKey);
        map.put("preferredLanguage", this::getPreferredLanguage);
        lst.add(map);

        return lst;
    }
}
