package ca.bnc.wealth.common.jpa.entity.iam;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.sql.Timestamp;
import java.util.Objects;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "`IDP_USER_STATUS`", schema = "`IAM_V2`", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"`USER_CONFIGURATION_ID`"}),
    @UniqueConstraint(columnNames = {"`IDP_USER_ID`"})
})
public class IamIdpUserStatus {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`IDP_USER_STATUS_ID`")
  private long idpUserStatusId;

  @OneToOne
  @JoinColumn(name = "`USER_CONFIGURATION_ID`")
  private IamUserConfiguration userConfiguration;

  @Column(name = "`IDP_USER_ID`")
  private String idpUserId;

  @Column(name = "`IDP_STATUS`")
  private String idpStatus;

  @Column(name = "`CREATED`")
  private Timestamp created;

  @Column(name = "`ACTIVATED`")
  private Timestamp activated;

  @Column(name = "`STATUS_CHANGED`")
  private Timestamp statusChanged;

  @Column(name = "`LAST_LOGIN`")
  private Timestamp lastLogin;

  @Column(name = "`LAST_UPDATED`")
  private Timestamp lastUpdated;

  @Column(name = "`PASSWORD_CHANGED`")
  private Timestamp passwordChanged;

  @Column(name = "`CXP_SUB_STATUS`")
  private String cxpSubStatus;

  @Column(name = "`CXP_STATUS`")
  private String cxpStatus;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATION_DATE`")
  private Timestamp creationDate;

  @Column(name = "`LAST_UPDATED_BY`")
  private String lastUpdatedBy;

  @Column(name = "`LAST_UPDATE_DATE`")
  private Timestamp lastUpdateDate;

  public boolean equalByOktaValue(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    IamIdpUserStatus that = (IamIdpUserStatus) o;
    return Objects.equals(idpUserId, that.idpUserId)
        && Objects.equals(idpUserId, that.idpUserId)
        && Objects.equals(idpStatus, that.idpStatus)
        && Objects.equals(created, that.created)
        && Objects.equals(activated, that.activated)
        && Objects.equals(statusChanged, that.statusChanged)
        && Objects.equals(lastLogin, that.lastLogin)
        && Objects.equals(lastUpdated, that.lastUpdated)
        && Objects.equals(passwordChanged, that.passwordChanged);
  }

}
