package ca.bnc.wealth.common.jpa.entity.iam;


import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "`RR_CODE_RANGE`", schema = "`IAM_V2`", uniqueConstraints= @UniqueConstraint( columnNames={"`FROM_RR_CODE`", "`TO_RR_CODE`"})
)
public class IamRrCodeRange implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`RR_CODE_RANGE_ID`")
    private long rrCodeRangeId;

    @Column(name = "`FROM_RR_CODE`")
    private String fromRrCode;

    @Column(name = "`TO_RR_CODE`")
    private String toRrCode;

    @Column(name = "`FROM_RR_CODE_B10`")
    private long fromRrCodeB10;

    @Column(name = "`TO_RR_CODE_B10`")
    private long toRrCodeB10;

    @Column(name = "`ACTIVE`")
    private Boolean active;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATION_DATE`")
    private Timestamp creationDate;

    @Column(name = "`LAST_UPDATED_BY`")
    private String lastUpdatedBy;

    @Column(name = "`LAST_UPDATE_DATE`")
    private Timestamp lastUpdateDate;

    @OneToMany(mappedBy = "iamRrCodeRange")
    private List<FirmAssignmentRrCodeRange> firmAssignmentRrCodeRanges;

    @OneToMany(mappedBy = "iamRrCodeRange")
    private List<UserAssignmentRrCodeRange> userAssignmentRrCodeRanges;

    @Override
    public Long getId() {
        return this.rrCodeRangeId;
    }

    @Override
    public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
        List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

        Map<String, Supplier<Object>> map1 = new HashMap<>();
        map1.put("fromRrCode", this::getFromRrCode);
        map1.put("toRrCode", this::getToRrCode);
        lst.add(map1);

        Map<String, Supplier<Object>> map2 = new HashMap<>();
        map2.put("fromRrCodeB10", this::getFromRrCodeB10);
        map2.put("toRrCodeB10", this::getToRrCodeB10);
        lst.add(map2);
        return lst;
    }
}
