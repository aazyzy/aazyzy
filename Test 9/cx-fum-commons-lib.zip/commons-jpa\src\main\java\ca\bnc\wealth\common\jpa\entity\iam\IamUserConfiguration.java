package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.utils.EmailUtils;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(
    name = "`USER_CONFIGURATION`",
    schema = "`IAM_V2`",
    uniqueConstraints = {
      @UniqueConstraint(columnNames = {"`USERNAME`"}),
      @UniqueConstraint(columnNames = {"`IDP_USER_ID`"})
    })
public class IamUserConfiguration implements EntityInterface {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`USER_CONFIGURATION_ID`")
  private Long userConfigurationId;

  @Column(name = "`IDP_USER_ID`")
  private String idpUserIdentifier;

  @Column(name = "`IDP_SUBJECT`")
  private String idpSubject;

  @Column(name = "`IDP`")
  private String idp;

  @Column(name = "`PROFILE_LAST_UPDATED`")
  private Timestamp profileLastUpdated;

  @Column(name = "`FIRST_NAME`")
  private String firstName;

  @Column(name = "`LAST_NAME`")
  private String lastName;

  @Column(name = "`USERNAME`")
  private String username;

  @Enumerated(EnumType.STRING)
  @Column(name = "`PREFERRED_LANGUAGE`")
  @JdbcTypeCode(SqlTypes.NAMED_ENUM)
  private PreferredLanguageType preferredLanguageType;

  @Column(name = "`EMAIL`")
  private String email;

  @Column(name = "`STATE`")
  private String state;

  @Column(name = "`STATE_ACTION`")
  private String stateAction;

  @Column(name = "`STATE_DESCRIPTION`")
  private String stateDescription;

  @Column(name = "`ACTIVE`")
  private Boolean active;

  @Column(name = "`STATUS_LAST_UPDATED`")
  private Timestamp statusLastUpdated;

  @Column(name = "`OSS_GROUP_ID`")
  private String ossGroupId;

  @Column(name = "`OSS_USER_ID`")
  private String ossUserId;

  @Column(name = "`PREFERRED_CX_UI_MODULE`")
  private String preferredCxUtModule;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATION_DATE`")
  private Timestamp creationDate;

  @Column(name = "`LAST_UPDATED_BY`")
  private String lastUpdatedBy;

  @Column(name = "`LAST_UPDATE_DATE`")
  private Timestamp lastUpdateDate;

  @Column(name = "`ACTIVATION_DATE`")
  private Timestamp activationDate;

  @Column(name = "`IDENTITY_LAST_UPDATED`")
  private Timestamp identityLastUpdated;

  @Column(name = "`ACCESS_PROFILE_SET`")
  private Boolean accessProfileSet;

  @Column(name = "`SOURCE_IDP_SUBJECT`")
  private String sourceIdpSubject;

  @Column(name = "`BNGF_REFERENCE_ID`")
  private String bngfReferenceId;

  @Column(name = "`LAST_LOGIN_DATE`")
  private Timestamp lastLoginDate;

  @Column(name = "`USER_PREFERENCES`")
  @JdbcTypeCode(SqlTypes.JSON)
  private Map<String, String> userPreferences;

  @Column(name = "`SOURCE`")
  private String source;

  @OneToMany(mappedBy = "userConfiguration")
  private List<UserAssignmentFeaturePackage> userAssignmentFeaturePackages;

  @OneToMany(mappedBy = "userConfiguration")
  private List<UserAssignmentFirm> userAssignmentFirms;

  @OneToMany(mappedBy = "userConfiguration")
  private List<UserAssignmentResource> userAssignmentResources;

  @OneToMany(mappedBy = "userConfiguration")
  private List<UserAssignmentRrCodeRange> userAssignmentRrCodeRanges;

  @OneToMany(mappedBy = "userConfiguration")
  private List<UserAssignmentUserGroup> userAssignmentUserGroups;

  // EMAIL is stored lower-cased to stay consistent with IAM_V2.PERSON.EMAIL.
  @PrePersist
  @PreUpdate
  private void normalizeEmail() {
    this.email = EmailUtils.canonicalize(this.email);
  }

  @Override
  public Long getId() {
    return this.userConfigurationId;
  }

  @Override
  public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
    List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

    Map<String, Supplier<Object>> map1 = new HashMap<>();
    map1.put("username", this::getUsername);
    lst.add(map1);

    Map<String, Supplier<Object>> map2 = new HashMap<>();
    map2.put("email", this::getEmail);
    lst.add(map2);

    Map<String, Supplier<Object>> map3 = new HashMap<>();
    map3.put("idpSubject", this::getIdpSubject);
    lst.add(map3);

    Map<String, Supplier<Object>> map4 = new HashMap<>();
    map4.put("idpUserIdentifier", this::getIdpSubject);
    lst.add(map4);

    return lst;
  }
}
