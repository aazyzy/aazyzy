package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Getter
@Setter
@Entity
@Table(name = "`PACKAGE_TEMPLATE`", schema = "`IAM_V2`",
    uniqueConstraints = @UniqueConstraint(columnNames = {"`NAME`"}))
public class PackageTemplate implements EntityInterface {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`PACKAGE_TEMPLATE_ID`")
  private long packageTemplateId;

  @Column(name = "`NAME`")
  private String name;

  @Column(name = "`DESCRIPTION`")
  private String description;

  @Column(name = "`ACTIVE`")
  private boolean active;

  @Enumerated(EnumType.STRING)
  @Column(name = "`TYPE`")
  @JdbcTypeCode(SqlTypes.NAMED_ENUM)
  private PackageType type;

  @Enumerated(EnumType.STRING)
  @Column(name = "`FIRM_TYPE`")
  @JdbcTypeCode(SqlTypes.NAMED_ENUM)
  private FirmType firmType;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATED_DT`")
  private Timestamp creationDate;

  @Column(name = "`UPDATED_BY`")
  private String updatedBy;

  @Column(name = "`UPDATED_DT`")
  private Timestamp updateDate;

  @OneToMany(mappedBy = "packageTemplate")
  List<FeaturePackage> featurePackages;

  @OneToMany(mappedBy = "packageTemplate")
  List<PackageTemplateAssignmentResource> packageTemplateAssignmentResources;

  @OneToMany(mappedBy = "packageTemplate")
  List<PackageTemplateAssignmentUserGroup> packageTemplateAssignmentUserGroups;

  @Override
  public Long getId() {
    return this.packageTemplateId;
  }

  @Override
  public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
    List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

    Map<String, Supplier<Object>> map = new HashMap<>();
    map.put("name", this::getName);

    lst.add(map);

    return lst;
  }
}
