package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Getter
@Setter
@Entity
@Table(name = "`PACKAGE_TEMPLATE_DETAILS`", schema = "`IAM_V2`")
public class PackageTemplateAssignmentUserGroup implements EntityInterface {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`TEMPLATE_DETAIL_ID`")
    private long templateAssignmentId;

    @ManyToOne
    @JoinColumn(name = "`PACKAGE_TEMPLATE_ID`")
    PackageTemplate packageTemplate;

    @ManyToOne
    @JoinColumn(name = "`ASSIGNEE_ID`")
    UserGroup userGroup;

    @Enumerated(EnumType.STRING)
    @Column(name = "`ASSIGNMENT_TYPE`")
    @JdbcTypeCode(SqlTypes.NAMED_ENUM)
    private PackageAssignmentType assignmentType;

    @Enumerated(EnumType.STRING)
    @Column(name = "`ASSIGNMENT_MODE`")
    @JdbcTypeCode(SqlTypes.NAMED_ENUM)
    private PackageAssignmentMode assignmentMode;

    @Column(name = "`SELECTION_DEFAULT`")
    private boolean selectionDefault;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATED_DT`")
    private Timestamp creationDate;

    @Column(name = "`UPDATED_BY`")
    private String updatedBy;

    @Column(name = "`UPDATED_DT`")
    private Timestamp updateDate;

    @OneToMany(mappedBy = "packageTemplateAssignmentUserGroup")
    private List<FeaturePackageAssignmentUserGroup> packageTemplateAssignmentUserGroups;

    @Override
    public Long getId() {
        return this.templateAssignmentId;
    }

    @Override
    public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
        List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

        Map<String, Supplier<Object>> map = new HashMap<>();
        map.put("userGroup.name", () -> this.getUserGroup().getName());
        map.put("packageTemplate.name", () -> this.getPackageTemplate().getName());
        map.put("assignmentType", this::getAssignmentType);

        lst.add(map);

        return lst;
    }
}
