package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.utils.EmailUtils;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(
    name = "`PERSON`",
    schema = "`IAM_V2`",
    uniqueConstraints = {
      @UniqueConstraint(columnNames = {"`EMAIL`"})
    })
public class Person implements EntityInterface {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`PERSON_ID`")
  private Long personId;

  @Column(name = "`FIRST_NAME`")
  private String firstName;

  @Column(name = "`LAST_NAME`")
  private String lastName;

  @Enumerated(EnumType.STRING)
  @Column(name = "`LANGUAGE`")
  @JdbcTypeCode(SqlTypes.NAMED_ENUM)
  private PreferredLanguageType language;

  @Column(name = "`EMAIL`")
  private String email;

  @Column(name = "`ORGANIZATION`")
  private String organization;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATED_DT`")
  private Timestamp createdDt;

  @Column(name = "`UPDATED_BY`")
  private String updatedBy;

  @Column(name = "`UPDATED_DT`")
  private Timestamp updatedDt;

  @OneToMany(mappedBy = "person")
  private List<PersonAssignment> personAssignments;

  // EMAIL is stored lower-cased so the unique index on LOWER("EMAIL") never sees case variants.
  @PrePersist
  @PreUpdate
  private void normalizeEmail() {
    this.email = EmailUtils.canonicalize(this.email);
  }

  @Override
  public Long getId() {
    return this.personId;
  }

  @Override
  public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
    List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

    Map<String, Supplier<Object>> map1 = new HashMap<>();
    map1.put("email", this::getEmail);
    lst.add(map1);

    return lst;
  }
}
