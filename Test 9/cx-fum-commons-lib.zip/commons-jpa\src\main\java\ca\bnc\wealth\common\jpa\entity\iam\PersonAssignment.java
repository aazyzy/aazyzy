package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "`PERSON_USER`", schema = "`IAM_V2`")
public class PersonAssignment implements EntityInterface {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`PERSON_ASSIGNMENT_ID`")
  private Long personAssignmentId;

  @ManyToOne
  @JoinColumn(name = "`PERSON_ID`", nullable = false)
  private Person person;

  @Column(name = "`USER_ID`")
  private Integer userId;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATED_DT`")
  private Timestamp createdDt;

  @Column(name = "`UPDATED_BY`")
  private String updatedBy;

  @Column(name = "`UPDATED_DT`")
  private Timestamp updatedDt;

  @Override
  public Long getId() {
    return this.personAssignmentId;
  }
}
