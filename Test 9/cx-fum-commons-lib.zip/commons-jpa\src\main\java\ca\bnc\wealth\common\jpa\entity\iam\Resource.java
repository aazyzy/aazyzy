package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "`RESOURCE`", schema = "`IAM_V2`",
    uniqueConstraints = @UniqueConstraint(columnNames = {"`NAME`", "`VERSION`", "`RESTRICTION`"}))
public class Resource implements EntityInterface {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`RESOURCE_ID`")
  private long resourceId;

  @Column(name = "`NAME`", nullable = false)
  private String name;

  @Column(name = "`TYPE`", nullable = false)
  private String type;

  @Column(name = "`ACTIVE`", nullable = false)
  private boolean active;

  @Column(name = "`DESCRIPTION`", nullable = false)
  private String description;

  @Column(name = "`CONF_URI`", nullable = false)
  private String confUri;

  @Column(name = "`VERSION`", nullable = false)
  private String version;

  @Column(name = "`GROUP_NAME`")
  private String groupName;

  @Column(name = "`LABEL`")
  private String label;

  @Column(name = "`PURPOSE`")
  private String purpose;

  @Column(name = "`RESTRICTION`")
  private Boolean restriction;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATED_DT`")
  private Timestamp creationDate;

  @Column(name = "`UPDATED_BY`")
  private String updatedBy;

  @Column(name = "`UPDATED_DT`")
  private Timestamp updateDate;

  @OneToMany(mappedBy = "resource")
  List<PackageTemplateAssignmentResource> packageTemplateAssignmentResources;

  @OneToMany(mappedBy = "resource")
  List<UserAssignmentResource> userAssignmentResources;


  @Override
  public Long getId() {
    return this.resourceId;
  }

  @Override
  public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
    List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

    Map<String, Supplier<Object>> map = new HashMap<>();
    map.put("name", this::getName);
    map.put("version", this::getVersion);
    lst.add(map);

    return lst;
  }
}
