package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.platform.EntityResourceGroupAssignment;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

@Getter
@Setter
@Entity
@Table(name = "`RESOURCE_GROUP`", schema = "`IAM`",
        uniqueConstraints = @UniqueConstraint(columnNames = {"`RESOURCE_GROUP`"}))
public class ResourceGroup implements EntityInterface {

    @OneToMany(mappedBy = "resourceGroup")
    List<ResourceGroupAssignment> resourceGroupAssignments;
    @OneToMany(mappedBy = "resourceGroup")
    List<RoleResourceGroupAssignment> roleResourceGroupAssignments;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`RESOURCE_GROUP_ID`")
    private long resourceGroupId;
    @Column(name = "`REMEDY_APP_ID`")
    private String remedyAppId;
    @Column(name = "`RESOURCE_GROUP`")
    private String resourceGroup;
    @Column(name = "`CREATED_BY`")
    private String createdBy;
    @Column(name = "`CREATED_DT`")
    private Timestamp creationDate;
    @Column(name = "`UPDATED_BY`")
    private String updatedBy;
    @Column(name = "`UPDATED_DT`")
    private Timestamp updateDate;
    @OneToMany(mappedBy = "resourceGroup")
    private List<EntityResourceGroupAssignment> entityResourceGroupAssignments;

    @Override
    public Long getId() {
        return this.resourceGroupId;
    }

    @Override
    public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
        List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

        Map<String, Supplier<Object>> map = new HashMap<>();
        map.put("resourceGroup", this::getResourceGroup);
        lst.add(map);

        return lst;
    }
}
