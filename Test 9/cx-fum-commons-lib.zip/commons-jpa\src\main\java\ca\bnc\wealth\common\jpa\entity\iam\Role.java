package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "`ROLE`", schema = "`IAM_V2`",
    uniqueConstraints = @UniqueConstraint(columnNames = {"`NAME`", "`CAPABILITY`"}))
public class Role implements EntityInterface {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`ROLE_ID`")
  private long roleId;

  @Column(name = "`NAME`")
  private String name;

  @ManyToOne
  @JoinColumn(name = "`CAPABILITY`", referencedColumnName = "`NAME`")
  Capability capability;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATED_DT`")
  private Timestamp creationDate;

  @Column(name = "`UPDATED_BY`")
  private String updatedBy;

  @Column(name = "`UPDATED_DT`")
  private Timestamp updateDate;

  @OneToMany(mappedBy = "role")
  List<RolePermissionAssignment> rolePermissionAssignments;

  @OneToMany(mappedBy = "role")
  List<RoleResourceGroupAssignment> roleResourceGroupAssignments;

  @OneToMany(mappedBy = "role")
  private List<UserGroupRoleAssignment> userGroupRoleAssignments;

  @Override
  public Long getId() {
    return this.roleId;
  }

  @Override
  public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
    List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

    Map<String, Supplier<Object>> map = new HashMap<>();
    map.put("name", this::getName);
    map.put("capability.name", () -> this.getCapability().getName());

    lst.add(map);

    return lst;
  }
}
