package ca.bnc.wealth.common.jpa.entity.iam;


import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "`ROLE_RESOURCE_GROUP_ASSIGNMENT`", schema = "`IAM`",
    uniqueConstraints = @UniqueConstraint(columnNames = {"`ROLE_ID`", "`RESOURCE_GROUP_ID`"}))
public class RoleResourceGroupAssignment implements EntityInterface {

  @ManyToOne
  @JoinColumn(name = "`ROLE_ID`")
  Role role;
  @ManyToOne
  @JoinColumn(name = "`RESOURCE_GROUP_ID`")
  ResourceGroup resourceGroup;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`ROLE_RESOURCE_GROUP_ASSIGNMENT_ID`")
  private long roleResourceGroupAssignmentId;
  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATED_DT`")
  private Timestamp creationDate;

  @Column(name = "`UPDATED_BY`")
  private String updatedBy;

  @Column(name = "`UPDATED_DT`")
  private Timestamp updateDate;

  @Override
  public Long getId() {
    return this.roleResourceGroupAssignmentId;
  }

  @Override
  public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
    List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

    Map<String, Supplier<Object>> map = new HashMap<>();
    map.put("role.name", () -> this.getRole().getName());
    map.put("resourceGroup.resourceGroup", () -> this.getResourceGroup().getResourceGroup());
    lst.add(map);

    return lst;
  }
}
