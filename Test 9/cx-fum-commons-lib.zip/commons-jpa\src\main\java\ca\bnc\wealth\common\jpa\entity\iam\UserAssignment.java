package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Getter
@Setter
@Entity
@Table(name = "`USER_ASSIGNMENT`", schema = "`IAM_V2`")
public class UserAssignment implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`ID`")
    private Long id;

    @Column(name = "`IDP_SUBJECT`")
    private String idpSubject;

    @Enumerated(EnumType.STRING)
    @Column(name = "`ASSIGNMENT_TYPE`")
    @JdbcTypeCode(SqlTypes.NAMED_ENUM)
    private UserAssignmentType assignmentType;

    @Column(name = "`ASSIGNEE_ID`")
    private Integer assigneeId;

    @Column(name = "`EFFECTIVE_DATE`")
    private Timestamp effectiveDate;

    @Column(name = "`EXPIRY_DATE`")
    private Timestamp expiryDate;


    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATED_DT`")
    private Timestamp creationDate;

    @Column(name = "`UPDATED_BY`")
    private String updatedBy;

    @Column(name = "`UPDATED_DT`")
    private Timestamp updateDate;
}
