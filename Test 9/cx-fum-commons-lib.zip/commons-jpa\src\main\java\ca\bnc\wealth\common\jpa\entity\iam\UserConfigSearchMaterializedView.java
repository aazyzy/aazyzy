package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.sql.Timestamp;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "`USER_CONFIGURATION_MATERIALIZED`", schema = "`IAM_V2`", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"`ID`"})})
public class UserConfigSearchMaterializedView implements EntityInterface {
  @Id
  @Column(name = "`ID`")
  private Long id;

  @Column(name = "`USER_CONFIGURATION_ID`")
  private Long userConfigurationId;

  @Column(name = "`ACTIVE`")
  private Boolean active;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATION_DATE`")
  private Timestamp creationDate;

  @Column(name = "`EMAIL`")
  private String email;

  @Column(name = "`FIRST_NAME`")
  private String firstName;

  @Column(name = "`IDP_SUBJECT`")
  private String idpSubject;

  @Column(name = "`IDP_USER_ID`")
  private String idpUserIdentifier;

  @Column(name = "`LAST_NAME`")
  private String lastName;

  @Column(name = "`LAST_UPDATED_BY`")
  private String lastUpdatedBy;

  @Column(name = "`LAST_UPDATE_DATE`")
  private Timestamp lastUpdateDate;

  @Column(name = "`OSS_GROUP_ID`")
  private String ossGroupId;

  @Column(name = "`OSS_USER_ID`")
  private String ossUserId;

  @Column(name = "`PREFERRED_CX_UI_MODULE`")
  private String preferredCxUtModule;

  @Enumerated(EnumType.STRING)
  @Column(name = "`PREFERRED_LANGUAGE`")
  @JdbcTypeCode(SqlTypes.NAMED_ENUM)
  private PreferredLanguageType preferredLanguageType;

  @Column(name = "`PROFILE_LAST_UPDATED`")
  private Timestamp profileLastUpdated;

  @Column(name = "`STATE`")
  private String state;

  @Column(name = "`STATE_ACTION`")
  private String stateAction;

  @Column(name = "`STATE_DESCRIPTION`")
  private String stateDescription;

  @Column(name = "`STATUS_LAST_UPDATED`")
  private Timestamp statusLastUpdated;

  @Column(name = "`USERNAME`")
  private String username;

  @Column(name = "`IDP`")
  private String idp;

  @Column(name = "`FIRM_ENTITY_ID`")
  private Long firmEntityId;

  @Column(name = "`FIRM_ID`")
  private String firmId;

  @Column(name = "`USER_GROUP_NAME`")
  private String userGroupName;

  @Column(name = "`USER_GROUP_DESCRIPTION`")
  private String userGroupDescription;

  @Column(name = "`RR_RANGES`")
  private String rrRanges;

  @Column(name = "`ACCESS_PROFILE_SET`")
  private Boolean accessProfileSet;

  @Column(name = "`SOURCE`")
  private String source;
}
