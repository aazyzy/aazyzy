package ca.bnc.wealth.common.jpa.entity.iam;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

@Getter
@Setter
@Entity
@Table(name = "`USER_GROUP`", schema = "`IAM_V2`", uniqueConstraints = @UniqueConstraint(columnNames = {
        "`NAME`"}))
public class UserGroup implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`USER_GROUP_ID`")
    private long userGroupId;

    @Column(name = "`NAME`")
    private String name;

    @Column(name = "`DESCRIPTION`")
    private String description;

    @Column(name = "`IS_FIRM_SCOPE`")
    private Boolean isFirmScope;

    @Column(name = "`IS_INTERNAL`")
    private Boolean isInternal;

    @Column(name = "`ACTIVE`")
    private Boolean isActive;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATED_DT`")
    private Timestamp creationDate;

    @Column(name = "`UPDATED_BY`")
    private String updatedBy;

    @Column(name = "`UPDATED_DT`")
    private Timestamp updateDate;

    @OneToMany(mappedBy = "userGroup")
    List<PackageTemplateAssignmentUserGroup> packageTemplateAssignmentUserGroups;

    @OneToMany(mappedBy = "userGroup")
    private List<UserGroupRoleAssignment> userGroupRoleAssignments;

    @OneToMany(mappedBy = "userGroup")
    private List<UserAssignmentUserGroup> userAssignmentUserGroups;

    @Override
    public Long getId() {
        return this.userGroupId;
    }

    @Override
    public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
        List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

        Map<String, Supplier<Object>> map = new HashMap<>();
        map.put("name", this::getName);
        lst.add(map);

        return lst;
    }
}
