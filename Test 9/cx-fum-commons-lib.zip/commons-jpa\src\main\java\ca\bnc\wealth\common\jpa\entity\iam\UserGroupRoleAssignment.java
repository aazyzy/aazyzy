package ca.bnc.wealth.common.jpa.entity.iam;


import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "`USER_GROUP_ASSIGNMENT`", schema = "`IAM_V2`")
public class UserGroupRoleAssignment implements EntityInterface {

  @ManyToOne
  @JoinColumn(name = "`USER_GROUP_ID`")
  UserGroup userGroup;

  @ManyToOne
  @JoinColumn(name = "`ROLE_ID`")
  Role role;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`USER_GROUP_ASSIGNMENT_ID`")
  private long userGroupAssignmentId;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATED_DT`")
  private Timestamp creationDate;

  @Column(name = "`UPDATED_BY`")
  private String updatedBy;

  @Column(name = "`UPDATED_DT`")
  private Timestamp updateDate;

  @Override
  public Long getId() {
    return this.userGroupAssignmentId;
  }

  @Override
  public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
    List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

    Map<String, Supplier<Object>> map = new HashMap<>();
    map.put("userGroup.name", () -> this.getUserGroup().getName());
    map.put("role.name", () -> this.getRole().getName());
    lst.add(map);

    return lst;
  }
}
