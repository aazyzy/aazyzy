package ca.bnc.wealth.common.jpa.entity.jsonb;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AuditEventDetails {

  private String auditEventDetailsType;

  private String firstName;
  private String lastName;
  private String email;
  private String userName;
  private String firmId;

  private Boolean firmLevelAccess;
  private String role;
  private List<String> moduleOverrides;
  private List<String> features;
  private List<String> userGroups;
  private List<String> resources;
  private List<String> restrictedResources;

  private String r2;
  private List<String> securityZone;
  private String ossId;

  private List<String> rrCodes;

  private String idp;
  private String state;
  private String stateAction;
  private String stateDescription;
  private String status;
  private Boolean accessProfileSet;
  private String uiUserStatus;

  private Map<String, String> appPreferences;
}
