package ca.bnc.wealth.common.jpa.entity.jsonb;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FirmBrand {
    private String bg;

    private String text;

    private String border;

    private String accent;

    private String accentText;

    private LogoUrl logoUrl;
}
