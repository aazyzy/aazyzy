package ca.bnc.wealth.common.jpa.entity.jsonb;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class LogoUrl {
    private String en;

    private String fr;
}
