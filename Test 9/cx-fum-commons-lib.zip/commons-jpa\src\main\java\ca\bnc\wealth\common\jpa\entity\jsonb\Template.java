package ca.bnc.wealth.common.jpa.entity.jsonb;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Template {

  private long fileSize;
  private String fileFormat;
  private long batchSize;
  private String delimiter;
  private long retention;
  private List<String> headerNames;

  private List<TemplateField> fields;
}
