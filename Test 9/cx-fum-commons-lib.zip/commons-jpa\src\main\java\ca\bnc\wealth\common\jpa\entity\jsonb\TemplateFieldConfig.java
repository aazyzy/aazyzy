package ca.bnc.wealth.common.jpa.entity.jsonb;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TemplateFieldConfig {

  private String pattern;
  private Boolean mandatory;
  private String defaultValue;
  private Boolean multiValued;
  private String multiValueDelimiter;
  private String headerName;
}
