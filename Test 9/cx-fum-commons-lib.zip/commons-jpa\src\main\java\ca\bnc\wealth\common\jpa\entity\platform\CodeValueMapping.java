package ca.bnc.wealth.common.jpa.entity.platform;


import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.*;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "`CODE_VALUE_MAPPING`", schema = "`PLATFORM`", uniqueConstraints =
@UniqueConstraint(columnNames = {"`CODE_TYPE`", "`CODE_VALUE`"}))
public class CodeValueMapping implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`CODE_VALUE_MAPPING_ID`")
    private long codeValueMappingId;

    @Column(name = "`CODE_TYPE`")
    private String codeType;

    @Column(name = "`CODE_VALUE`")
    private String codeValue;

    @Column(name = "`DESCRIPTION`")
    private String description;

    @Column(name = "`ACTIVE`")
    private String active;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATION_DATE`")
    private Timestamp creationDate;

    @Column(name = "`LAST_UPDATED_BY`")
    private String lastUpdatedBy;

    @Column(name = "`LAST_UPDATE_DATE`")
    private Timestamp lastUpdateDate;


    @OneToMany(mappedBy = "codeValueMapping")
    private List<UserConfiguration> userConfigurations;

    @OneToMany(mappedBy = "codeValueMappingCxpStatusCode")
    private List<UserConfiguration> cxpStatusUserConfigurations;

    @OneToMany(mappedBy = "codeValueMappingCxpSubStatusCode")
    private List<UserConfiguration> cxpSubStatusUserConfigurations;

    @OneToMany(mappedBy = "resourceEntityTypeCodeId")
    private List<UserEntityAssignment> resourceEntityTypeCodeIds;

    @OneToMany(mappedBy = "assignmentTypeCodeId")
    private List<UserEntityAssignment> assignmentTypeCodeIds;

    @OneToMany(mappedBy = "codeValueMapping")
    private List<FirmConfiguration> firmConfigurations;

    @OneToMany(mappedBy = "codeValueMapping")
    private List<RrCodeRangeAssignment> rrCodeRangeAssignments;

    @Override
    public Long getId() {
        return this.codeValueMappingId;
    }

    @Override
    public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
        List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

        Map<String, Supplier<Object>> map = new HashMap<>();
        map.put("codeType", this::getCodeType);
        map.put("codeValue", this::getCodeValue);
        lst.add(map);

        return lst;
    }

}
