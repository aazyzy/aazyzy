package ca.bnc.wealth.common.jpa.entity.platform;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

@Getter
@Setter
@Entity
@Table(name = "`CONTENT_TRANSLATION`", schema = "`PLATFORM`",
        uniqueConstraints = @UniqueConstraint(columnNames = {"`TRANSLATION_KEY`",
                "`PREFERRED_LANGUAGE_CODE_ID`"}))
public class ContentTranslation implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`CONTENT_TRANSLATION_ID`")
    private long contentTranslationId;

    @Column(name = "`TRANSLATION_KEY`")
    private String translationKey;

    @Column(name = "`TRANSLATION_VALUE`")
    private String translationValue;

    @ManyToOne
    @JoinColumn(name = "`PREFERRED_LANGUAGE_CODE_ID`")
    private CodeValueMapping preferredLanguageCodeId;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATED_DT`")
    private Timestamp creationDate;

    @Column(name = "`UPDATED_BY`")
    private String lastUpdatedBy;

    @Column(name = "`UPDATED_DT`")
    private Timestamp lastUpdateDate;

    @Override
    public Long getId() {
        return this.contentTranslationId;
    }

    @Override
    public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
        List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

        Map<String, Supplier<Object>> map = new HashMap<>();
        map.put("translationKey", this::getTranslationKey);
        map.put("preferredLanguageCodeId.codeType", () -> "PREFERRED_LANGUAGE");
        map.put("preferredLanguageCodeId.codeValue", () -> this.getPreferredLanguageCodeId().getCodeValue());
        lst.add(map);

        return lst;
    }
}
