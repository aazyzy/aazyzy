package ca.bnc.wealth.common.jpa.entity.platform;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;

@Getter
@Setter
@Entity
@Table(name = "`DB_DATA_MANUAL_UPLOAD`", schema = "`PLATFORM`")
public class DbDataManualUpload implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`DB_DATA_MANUAL_UPLOAD_ID`")
    private long dbDataManualUploadId;

    @ManyToOne
    @JoinColumn(name = "`DB_DATA_UPDATE_HISTORY_ID`")
    private DbDataUpdateHistory dbDataUpdateHistory;

    @Column(name = "`TABLE`")
    private String table;

    @Column(name = "`DATA`")
    private String data;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATION_DATE`")
    private Timestamp creationDate;

    @Column(name = "`LAST_UPDATED_BY`")
    private String lastUpdatedBy;

    @Column(name = "`LAST_UPDATE_DATE`")
    private Timestamp lastUpdateDate;

    @Override
    public Long getId() {
        return this.dbDataManualUploadId;
    }
}
