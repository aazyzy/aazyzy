package ca.bnc.wealth.common.jpa.entity.platform;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;

@Getter
@Setter
@Entity
@Table(name = "`DB_DATA_UPDATE_HISTORY`", schema = "`PLATFORM`",
        uniqueConstraints = @UniqueConstraint(columnNames = {"`DB_DATA_UPDATE_VERSION`"}))
public class DbDataUpdateHistory implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`DB_DATA_UPDATE_HISTORY_ID`")
    private long dbDataUpdateHistoryId;

    @Column(name = "`DB_DATA_UPDATE_VERSION`")
    private String dbDataUpdateVersion;

    @Column(name = "`DB_DATA_UPDATE_TYPE`")
    private String dbDataUpdateType;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATION_DATE`")
    private Timestamp creationDate;

    @Column(name = "`LAST_UPDATED_BY`")
    private String lastUpdatedBy;

    @Column(name = "`LAST_UPDATE_DATE`")
    private Timestamp lastUpdateDate;

    @Override
    public Long getId() {
        return this.dbDataUpdateHistoryId;
    }
}
