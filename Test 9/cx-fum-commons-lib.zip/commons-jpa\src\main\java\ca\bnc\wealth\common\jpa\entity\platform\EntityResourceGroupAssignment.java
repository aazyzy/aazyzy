package ca.bnc.wealth.common.jpa.entity.platform;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.iam.ResourceGroup;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

@Getter
@Setter
@Entity
@Table(name = "`ENTITY_RESOURCE_GROUP_ASSIGNMENT`", schema = "`PLATFORM`")
public class EntityResourceGroupAssignment implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`ENTITY_RESOURCE_GROUP_ASSIGNMENT_ID`")
    private long entityResourceGroupAssignmentId;

    @ManyToOne
    @JoinColumn(name = "`RESOURCE_ENTITY_ID`")
    private FirmConfiguration firmConfiguration;

    @ManyToOne
    @JoinColumn(name = "`RESOURCE_GROUP_ID`")
    private ResourceGroup resourceGroup;


    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATION_DATE`")
    private Timestamp creationDate;

    @Column(name = "`LAST_UPDATED_BY`")
    private String lastUpdatedBy;

    @Column(name = "`LAST_UPDATE_DATE`")
    private Timestamp lastUpdateDate;

    @Override
    public Long getId() {
        return this.entityResourceGroupAssignmentId;
    }

    @Override
    public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
        List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

        Map<String, Supplier<Object>> map = new HashMap<>();
        map.put("firmConfiguration.firmId", () -> this.getFirmConfiguration().getFirmId());
        map.put("resourceGroup.resourceGroup", () -> this.getResourceGroup().getResourceGroup());
        lst.add(map);

        return lst;
    }
}
