package ca.bnc.wealth.common.jpa.entity.platform;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.*;
import java.util.function.Supplier;

@Getter
@Setter
@Entity
@Table(
        name = "`FIRM_CONFIGURATION`",
        schema = "`PLATFORM`",
        uniqueConstraints = @UniqueConstraint(columnNames = {"`FIRM_ID`"}))
public class FirmConfiguration implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`FIRM_CONFIGURATION_ID`")
    private long firmConfigurationId;

    @Column(name = "`FINANCIAL_ENTITY_ID`")
    private Long financialEntityId;

    @Column(name = "`FIRM_ID`")
    private String firmId;

    @Column(name = "`FIRM_NAME`")
    private String firmName;

    @ManyToOne
    @JoinColumn(name = "`FIRM_TYPE_CODE_ID`")
    private CodeValueMapping codeValueMapping;

    @Column(name = "`ACTIVE`")
    private String active;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATION_DATE`")
    private Timestamp creationDate;

    @Column(name = "`LAST_UPDATED_BY`")
    private String lastUpdatedBy;

    @Column(name = "`LAST_UPDATE_DATE`")
    private Timestamp lastUpdateDate;

    @OneToMany(mappedBy = "resourceEntityId")
    private List<UserEntityAssignment> userEntityAssignments;

    @ManyToOne
    @JoinColumn(name = "`PARENT_FIRM_CONFIGURATION_ID`")
    private FirmConfiguration parentFirmConfiguration;

    @Column(name = "`BROKER_CODE`")
    private String brokerCode;

    @Column(name = "`BROKER_NO`")
    private String brokerNo;

    @Column(name = "`BRANCH_NO`")
    private String branchNo;

    @ManyToOne
    @JoinColumn(name = "`FIRM_STATUS_CODE_ID`")
    private CodeValueMapping firmStatusCvm;

    @OneToMany(mappedBy = "parentFirmConfiguration")
    private Set<FirmConfiguration> childFirmConfigurations = new HashSet<>();

    @OneToMany(mappedBy = "firmConfiguration")
    private List<EntityResourceGroupAssignment> entityResourceGroupAssignments;

    @OneToMany(mappedBy = "firmConfiguration")
    private List<RrCodeRangeAssignmentFirm> rrCodeRangeAssignments;


    @Override
    public Long getId() {
        return this.firmConfigurationId;
    }

    @Override
    public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
        List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

        Map<String, Supplier<Object>> map = new HashMap<>();
        map.put("firmId", this::getFirmId);
        lst.add(map);

        return lst;
    }
}
