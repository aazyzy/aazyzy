package ca.bnc.wealth.common.jpa.entity.platform;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.jsonb.FirmConfigJson;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

@Getter
@Setter
@Entity
@Table(name = "`FIRM_WHITELABEL_CONFIG`", schema = "`PLATFORM`", uniqueConstraints =
@UniqueConstraint(columnNames = {"`FIRM_CONFIGURATION_ID`"}))
public class FirmWhitelabelConfig implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`FIRM_WHITELABEL_CONFIG_ID`")
    private long codeValueMappingId;

    @OneToOne
    @JoinColumn(name = "`FIRM_CONFIGURATION_ID`")
    private FirmConfiguration firmConfiguration;

    @Column(name = "`CONFIG`")
    @JdbcTypeCode(SqlTypes.JSON)
    private FirmConfigJson firmConfigJson;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATION_DATE`")
    private Timestamp creationDate;

    @Column(name = "`LAST_UPDATED_BY`")
    private String lastUpdatedBy;

    @Column(name = "`LAST_UPDATE_DATE`")
    private Timestamp lastUpdateDate;

    @Override
    public Long getId() {
        return this.codeValueMappingId;
    }

    @Override
    public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
        List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

        Map<String, Supplier<Object>> map = new HashMap<>();
        map.put("firmConfiguration.firmId", () -> this.getFirmConfiguration().getFirmId());
        lst.add(map);

        return lst;
    }
}
