package ca.bnc.wealth.common.jpa.entity.platform;


import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

@Getter
@Setter
@Entity
@Table(name = "`RR_CODE_RANGE`", schema = "`PLATFORM`"
        //  , uniqueConstraints= @UniqueConstraint( columnNames={"`FROM_RR_CODE`", "`TO_RR_CODE`"})
)
public class RrCodeRange implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`RR_CODE_RANGE_ID`")
    private long rrCodeRangeId;

    @Column(name = "`FROM_RR_CODE`")
    private String fromRrCode;

    @Column(name = "`TO_RR_CODE`")
    private String toRrCode;

    @Column(name = "`FROM_RR_CODE_B10`")
    private long fromRrCodeB10;

    @Column(name = "`TO_RR_CODE_B10`")
    private long toRrCodeB10;

    @Column(name = "`ACTIVE`")
    private String active;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATION_DATE`")
    private Timestamp creationDate;

    @Column(name = "`LAST_UPDATED_BY`")
    private String lastUpdatedBy;

    @Column(name = "`LAST_UPDATE_DATE`")
    private Timestamp lastUpdateDate;

    @OneToMany(mappedBy = "rrCodeRangeId")
    private List<RrCodeRangeAssignment> rrCodeRangeAssignments;

    @OneToMany(mappedBy = "rrCodeRangeId")
    private List<RrCodeRangeAssignmentFirm> rrCodeRangeAssignmentFirms;


    @Override
    public Long getId() {
        return this.rrCodeRangeId;
    }

    @Override
    public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
        List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

        Map<String, Supplier<Object>> map1 = new HashMap<>();
        map1.put("fromRrCode", this::getFromRrCode);
        map1.put("toRrCode", this::getToRrCode);
        lst.add(map1);

        Map<String, Supplier<Object>> map2 = new HashMap<>();
        map2.put("fromRrCodeB10", this::getFromRrCodeB10);
        map2.put("toRrCodeB10", this::getToRrCodeB10);
        lst.add(map2);
        return lst;
    }
}
