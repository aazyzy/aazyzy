package ca.bnc.wealth.common.jpa.entity.platform;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

@Getter
@Setter
@Entity
@Table(name = "`RR_CODE_RANGE_ASSIGNMENT`", schema = "`PLATFORM`")
public class RrCodeRangeAssignmentFirm implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`RR_CODE_RANGE_ASSIGNMENT_ID`")
    private long rrCodeRangeAssignmentId;

    @ManyToOne
    @JoinColumn(name = "`RR_CODE_RANGE_ENTITY_ID`")
    private FirmConfiguration firmConfiguration;

    @ManyToOne
    @JoinColumn(name = "`RR_CODE_RANGE_ID`")
    private RrCodeRange rrCodeRangeId;

    @ManyToOne
    @JoinColumn(name = "`RR_ASSIGNMENT_TYPE_CODE_ID`")
    private CodeValueMapping codeValueMapping;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATION_DATE`")
    private Timestamp creationDate;

    @Column(name = "`LAST_UPDATED_BY`")
    private String lastUpdatedBy;

    @Column(name = "`LAST_UPDATE_DATE`")
    private Timestamp lastUpdateDate;

    @Override
    public Long getId() {
        return this.rrCodeRangeAssignmentId;
    }

    @Override
    public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
        List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

        Map<String, Supplier<Object>> map = new HashMap<>();
        map.put("firmConfiguration.firmId", () -> this.getFirmConfiguration().getFirmId());
        map.put("rrCodeRangeId.fromRrCode", () -> this.getRrCodeRangeId().getFromRrCode());
        map.put("rrCodeRangeId.toRrCode", () -> this.getRrCodeRangeId().getToRrCode());
        map.put("codeValueMapping.codeType", () -> "RRCODE_ASSIGNMENT_TYPE");
        map.put("codeValueMapping.codeValue", () -> this.getCodeValueMapping().getCodeValue());
        lst.add(map);
        lst.add(map);

        return lst;
    }
}
