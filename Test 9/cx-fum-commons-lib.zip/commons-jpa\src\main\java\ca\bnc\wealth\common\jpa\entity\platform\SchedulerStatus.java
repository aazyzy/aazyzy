package ca.bnc.wealth.common.jpa.entity.platform;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "`SCHEDULER_STATUS`", schema = "`PLATFORM`")
public class SchedulerStatus {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`SCHEDULER_STATUS_ID`")
  private long schedulerStatusId;

  @Column(name = "`SCHEDULER_NAME`")
  private String schedulerName;

  @Column(name = "`SCHEDULER_START`")
  private Timestamp schedulerStart;

  @Column(name = "`SCHEDULER_END`")
  private Timestamp schedulerEnd;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATION_DATE`")
  private Timestamp creationDate;

  @Column(name = "`LAST_UPDATED_BY`")
  private String lastUpdatedBy;

  @Column(name = "`LAST_UPDATE_DATE`")
  private Timestamp lastUpdateDate;
}
