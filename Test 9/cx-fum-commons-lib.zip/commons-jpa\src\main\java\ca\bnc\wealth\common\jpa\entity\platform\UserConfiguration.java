package ca.bnc.wealth.common.jpa.entity.platform;

import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.iam.*;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

@Getter
@Setter
@Entity
@Table(name = "`USER_CONFIGURATION`", schema = "`PLATFORM`", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"`USERNAME`"}),
        @UniqueConstraint(columnNames = {"`IDP_USER_IDENTIFIER`"})})
public class UserConfiguration implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`USER_CONFIGURATION_ID`")
    private long userConfigurationId;

    @Column(name = "`IDP_USER_IDENTIFIER`")
    private String idpUserIdentifier;

    @Column(name = "`IDP_SUBJECT`")
    private String idpSubject;

    @Column(name = "`USERNAME`")
    private String username;

    @Column(name = "`OSS_USER_ID`")
    private String ossUserId;

    @Column(name = "`OSS_GROUP_ID`")
    private String ossGroupId;

    @Column(name = "`FIRST_NAME`")
    private String firstName;

    @Column(name = "`LAST_NAME`")
    private String lastName;

    @ManyToOne
    @JoinColumn(name = "`CXP_STATUS_CODE_ID`")
    private CodeValueMapping codeValueMappingCxpStatusCode;

    @ManyToOne
    @JoinColumn(name = "`CXP_SUB_STATUS_CODE_ID`")
    private CodeValueMapping codeValueMappingCxpSubStatusCode;

    @ManyToOne
    @JoinColumn(name = "`PREFERRED_LANGUAGE_CODE_ID`")
    private CodeValueMapping codeValueMapping;

    @Column(name = "`EMAIL`")
    private String email;

    @Column(name = "`ACTIVE`")
    private String active;


    @Column(name = "`IDP_USER_STATUS`")
    private String idpUserStatus;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATION_DATE`")
    private Timestamp creationDate;

    @Column(name = "`LAST_UPDATED_BY`")
    private String lastUpdatedBy;

    @Column(name = "`LAST_UPDATE_DATE`")
    private Timestamp lastUpdateDate;

    @OneToMany(mappedBy = "userConfiguration")
    private List<UserGroupAssignment> userGroupAssignments;

    @OneToMany(mappedBy = "userConfiguration")
    private List<UserEntityAssignment> userEntityAssignments;

    @OneToMany(mappedBy = "userConfiguration")
    private List<RrCodeRangeAssignment> rrCodeRangeAssignments;

    @Override
    public Long getId() {
        return this.userConfigurationId;
    }

    @Override
    public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
        List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

        Map<String, Supplier<Object>> map1 = new HashMap<>();
        map1.put("username", this::getUsername);
        lst.add(map1);

        Map<String, Supplier<Object>> map2 = new HashMap<>();
        map2.put("email", this::getEmail);
        lst.add(map2);

        Map<String, Supplier<Object>> map3 = new HashMap<>();
        map3.put("idpSubject", this::getIdpSubject);
        lst.add(map3);

        Map<String, Supplier<Object>> map4 = new HashMap<>();
        map4.put("idpUserIdentifier", this::getIdpSubject);
        lst.add(map4);

        return lst;
    }
}
