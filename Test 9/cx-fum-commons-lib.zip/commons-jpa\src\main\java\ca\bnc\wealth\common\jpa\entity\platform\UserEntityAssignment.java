package ca.bnc.wealth.common.jpa.entity.platform;


import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

@Getter
@Setter
@Entity
@Table(name = "`USER_ENTITY_ASSIGNMENT`", schema = "`PLATFORM`")
public class UserEntityAssignment implements EntityInterface {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`USER_ENTITY_ASSIGNMENT_ID`")
    private long userEntityAssignmentId;

    @ManyToOne
    @JoinColumn(name = "`USER_CONFIGURATION_ID`")
    private UserConfiguration userConfiguration;

    @ManyToOne
    @JoinColumn(name = "`RESOURCE_ENTITY_ID`")
    private FirmConfiguration resourceEntityId;

    @ManyToOne
    @JoinColumn(name = "`RESOURCE_ENTITY_TYPE_CODE_ID`")
    private CodeValueMapping resourceEntityTypeCodeId;

    @ManyToOne
    @JoinColumn(name = "`ASSIGNMENT_TYPE_CODE_ID`")
    private CodeValueMapping assignmentTypeCodeId;

    @Column(name = "`CREATED_BY`")
    private String createdBy;

    @Column(name = "`CREATION_DATE`")
    private Timestamp creationDate;

    @Column(name = "`LAST_UPDATED_BY`")
    private String lastUpdatedBy;

    @Column(name = "`LAST_UPDATE_DATE`")
    private Timestamp lastUpdateDate;

    @Override
    public Long getId() {
        return this.userEntityAssignmentId;
    }

    @Override
    public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
        List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

        Map<String, Supplier<Object>> map = new HashMap<>();
        map.put("resourceEntityId.firmId", () -> this.getResourceEntityId().getFirmId());
        map.put("userConfiguration.idpSubject", () -> this.getUserConfiguration().getIdpSubject());
        map.put("resourceEntityTypeCodeId.codeType", () -> "RESOURCE_ENTITY_TYPE");
        map.put("resourceEntityTypeCodeId.codeValue", () -> this.getResourceEntityTypeCodeId().getCodeValue());
        map.put("assignmentTypeCodeId.codeType", () -> "FIRM_ASSIGNMENT_TYPE");
        map.put("assignmentTypeCodeId.codeValue", () -> this.getAssignmentTypeCodeId().getCodeValue());
        lst.add(map);

        return lst;
    }
}
