package ca.bnc.wealth.common.jpa.entity.platform;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import java.sql.Types;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;

@Getter
@Setter
@Entity
@Table(name = "`USER_EXTRACT_DOWNLOAD`", schema = "`PLATFORM`")
public class UserExtractDownload {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`EXTRACT_ID`")
  private long extractId;

  @ManyToOne
  @JoinColumn(name = "`EXTRACT_TYPE_ID`")
  private CodeValueMapping extractTypeId;

  @ManyToOne
  @JoinColumn(name = "`STATUS_ID`")
  private CodeValueMapping statusId;

  @Lob
  @Column(name = "`EXTRACT_DATA`")
  @JdbcTypeCode(Types.VARBINARY)
  private byte[] extractData;

  @ManyToOne
  @JoinColumn(name = "`REQUESTED_BY`")
  private UserConfiguration requestedBy;

  @Column(name = "`REQUESTED_ON`")
  private Timestamp requestedOn;

  @Column(name = "`COMPLETED_ON`")
  private Timestamp completedOn;
}