package ca.bnc.wealth.common.jpa.entity.platform;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Data;


@Data
@Entity
@Table(name = "`VW_USER_FIRM_RESOURCE_ASSIGNMENT`", schema = "`PLATFORM`")
@IdClass(UserFirmResourceAssignmentViewIdClass.class)
public class UserFirmResourceAssignmentView {

  @Id
  @Column(name = "`USER_CONFIGURATION_ID`")
  private long userConfigurationId;

  @Id
  @Column(name = "`FIRM_CONFIGURATION_ID`")
  private long firmConfigurationId;

  @Id
  @Column(name = "`RESOURCE_NAME`")
  private String resourceName;

  @Column(name = "`IDP_SUBJECT`")
  private String idpSubject;

  @Column(name = "`USERNAME`")
  private String username;

  @Column(name = "`FIRM_ID`")
  private String firmId;

  @Column(name = "`RESOURCE_TYPE`")
  private String resourceType;
}
