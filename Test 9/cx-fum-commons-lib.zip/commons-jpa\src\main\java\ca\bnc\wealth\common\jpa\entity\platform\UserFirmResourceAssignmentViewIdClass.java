package ca.bnc.wealth.common.jpa.entity.platform;

import java.io.Serializable;
import lombok.Data;

@Data
public class UserFirmResourceAssignmentViewIdClass implements Serializable {

  private long userConfigurationId;
  private long firmConfigurationId;
  private String resourceName;
}
