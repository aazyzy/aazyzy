package ca.bnc.wealth.common.jpa.entity.platform;


import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.iam.UserGroup;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "`USER_GROUP_ASSIGNMENT`", schema = "`PLATFORM`")
public class UserGroupAssignment implements EntityInterface {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "`USER_GROUP_ASSIGNMENT_ID`")
  private long userGroupAssignmentId;

  @ManyToOne
  @JoinColumn(name = "`USER_CONFIGURATION_ID`")
  private UserConfiguration userConfiguration;

  @ManyToOne
  @JoinColumn(name = "`USER_GROUP_ID`")
  private UserGroup userGroupId;

  @Column(name = "`CREATED_BY`")
  private String createdBy;

  @Column(name = "`CREATION_DATE`")
  private Timestamp creationDate;

  @Column(name = "`LAST_UPDATED_BY`")
  private String lastUpdatedBy;

  @Column(name = "`LAST_UPDATE_DATE`")
  private Timestamp lastUpdateDate;

  @Override
  public Long getId() {
    return this.userGroupAssignmentId;
  }

  @Override
  public List<Map<String, Supplier<Object>>> getUniqueFieldMapping() {
    List<Map<String, Supplier<Object>>> lst = new ArrayList<>();

    Map<String, Supplier<Object>> map = new HashMap<>();
    map.put("userConfiguration.idpUserStatus",
        () -> this.getUserConfiguration().getIdpUserStatus());
    map.put("userGroupId.name", () -> this.getUserGroupId().getName());
    lst.add(map);

    return lst;
  }
}
