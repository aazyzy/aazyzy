package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmFile;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmStaging;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface AttestationFirmFileRepository extends JpaRepository<AttestationFirmFile, Long>,
    JpaSpecificationExecutor<AttestationFirmFile> {

  List<AttestationFirmFile> findAllByAttestationFirmStagingIn(List<AttestationFirmStaging> attestationFirmStagings);
  
  void deleteByAttestationFirmStaging(AttestationFirmStaging attestationFirmStaging);

  void deleteAllByAttestationFirmStaging_Attestation_AttestationId(Long attestationId);
  void deleteAllByAttestationFirmPublished_Attestation_AttestationId(Long attestationId);
}