package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface AttestationFirmHistoryRepository extends JpaRepository<AttestationFirmHistory, Long>,
    JpaSpecificationExecutor<AttestationFirmHistory> {

  void deleteAllByAttestation_AttestationId(Long attestationId);

}