package ca.bnc.wealth.common.jpa.repo.iam;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmPublished;

@Repository
public interface AttestationFirmPublishedRepository extends JpaRepository<AttestationFirmPublished, Long>,
    JpaSpecificationExecutor<AttestationFirmPublished> {

    List<AttestationFirmPublished> findAllByAttestation_AttestationId(Long attestationId);

    void deleteAllByAttestation_AttestationId(Long attestationId);
}