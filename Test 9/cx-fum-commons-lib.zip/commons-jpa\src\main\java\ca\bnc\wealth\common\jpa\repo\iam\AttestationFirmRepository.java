package ca.bnc.wealth.common.jpa.repo.iam;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirm;

@Repository
public interface AttestationFirmRepository extends JpaRepository<AttestationFirm, Long>, JpaSpecificationExecutor<AttestationFirm> {
}
