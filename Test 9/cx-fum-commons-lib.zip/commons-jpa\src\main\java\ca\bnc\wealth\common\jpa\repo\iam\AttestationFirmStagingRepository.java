package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmStaging;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface AttestationFirmStagingRepository extends JpaRepository<AttestationFirmStaging, Long>,
    JpaSpecificationExecutor<AttestationFirmStaging> {

  List<AttestationFirmStaging> findAllByAttestation_AttestationId(Long attestationId);

  void deleteAllByAttestation_AttestationId(Long attestationId);
}