package ca.bnc.wealth.common.jpa.repo.iam;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;
import ca.bnc.wealth.common.jpa.entity.iam.Attestation;

@Repository
public interface AttestationRepository extends JpaRepository<Attestation, Long>,
    JpaSpecificationExecutor<Attestation> {

  Attestation findFirstAttestationByLabel(String label);

  List<Attestation> findAllByOrderByCreatedDateDesc();

  void deleteById(Long id);
}
