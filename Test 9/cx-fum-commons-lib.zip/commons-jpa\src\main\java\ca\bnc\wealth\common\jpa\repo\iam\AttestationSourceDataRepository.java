package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.AttestationSourceData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AttestationSourceDataRepository extends JpaRepository<AttestationSourceData, Long>,
    JpaSpecificationExecutor<AttestationSourceData> {

    List<AttestationSourceData> findAllByAttestation_AttestationId(int attestationId);

    void deleteAllByAttestation_AttestationId(long attestationId);
}
