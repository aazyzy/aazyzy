package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.AttestationSourceType;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface AttestationSourceTypeRepository extends JpaRepository<AttestationSourceType, Long>,
    JpaSpecificationExecutor<AttestationSourceType> {

  List<AttestationSourceType> findAllByAttestationSourceTypeIdIn(List<Integer> attestationSourceTypeIds);

  List<AttestationSourceType> findAllByActive(boolean active);
}
