package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.AuditLogEventDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditLogEventDetailsRepository extends JpaRepository<AuditLogEventDetails, Long>, JpaSpecificationExecutor<AuditLogEventDetails> {

}
