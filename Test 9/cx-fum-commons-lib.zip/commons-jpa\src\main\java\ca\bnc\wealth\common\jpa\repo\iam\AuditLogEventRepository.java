package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.AuditLogEvent;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditLogEventRepository extends JpaRepository<AuditLogEvent, Long>, JpaSpecificationExecutor<AuditLogEvent> {

  List<AuditLogEvent> findByIdpSubject(String idpSubjectId);

}
