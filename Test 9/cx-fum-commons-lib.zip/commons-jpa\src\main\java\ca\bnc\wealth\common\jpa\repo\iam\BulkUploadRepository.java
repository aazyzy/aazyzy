package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.BulkUpload;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface BulkUploadRepository extends JpaRepository<BulkUpload, Long>,
    JpaSpecificationExecutor<BulkUpload> {

  @Query(value = "select * from nextval(:sequenceName);", countQuery = "SELECT count(*) from nextval(:sequenceName);", nativeQuery = true)
  long generateID(String sequenceName);

  Optional<BulkUpload> findByBatchID(String batchID);
}
