package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.enums.BatchType;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface BulkUploadTemplateRepository extends JpaRepository<BulkUploadTemplate, Long>,
    JpaSpecificationExecutor<BulkUploadTemplate> {

  Optional<BulkUploadTemplate> findByTemplateName(String templateName);

  Optional<BulkUploadTemplate> findByTemplateNameAndBatchType(String templateName, BatchType batchType);
}
