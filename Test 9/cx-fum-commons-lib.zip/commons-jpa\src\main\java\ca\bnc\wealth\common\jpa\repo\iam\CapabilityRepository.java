package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.Capability;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface CapabilityRepository extends JpaRepository<Capability, Long>,
    JpaSpecificationExecutor<Capability> {

  Capability findFirstByName(String name);
}
