package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackageAssignmentResource;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface FeaturePackageAssignmentResourceRepository extends JpaRepository<FeaturePackageAssignmentResource, Long>, JpaSpecificationExecutor<FeaturePackageAssignmentResource> {
}
