package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackageAssignmentUserGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface FeaturePackageAssignmentUserGroupRepository extends JpaRepository<FeaturePackageAssignmentUserGroup, Long>, JpaSpecificationExecutor<FeaturePackageAssignmentUserGroup> {
}
