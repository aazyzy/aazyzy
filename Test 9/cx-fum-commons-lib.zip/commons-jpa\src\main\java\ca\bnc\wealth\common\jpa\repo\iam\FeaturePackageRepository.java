package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface FeaturePackageRepository extends JpaRepository<FeaturePackage, Long>,
    JpaSpecificationExecutor<FeaturePackage> {

  List<FeaturePackage> findAllByPackageTemplate(PackageTemplate packageTemplate);
}
