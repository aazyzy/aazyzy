package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.FinancialEntity;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface FinancialEntityRepository extends JpaRepository<FinancialEntity, Long>,
    JpaSpecificationExecutor<Firm> {

  FinancialEntity findByFinancialEntityId(Long financialEntityId);

  FinancialEntity findByBrokerCodeAndBranchNumberAndDealerCode(String brokerCode,
      String branchNumber, String dealerCode);
}
