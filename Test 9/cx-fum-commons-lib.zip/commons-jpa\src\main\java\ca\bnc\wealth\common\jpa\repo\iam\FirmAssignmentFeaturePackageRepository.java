package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.FirmAssignmentFeaturePackage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface FirmAssignmentFeaturePackageRepository extends JpaRepository<FirmAssignmentFeaturePackage, Long>, JpaSpecificationExecutor<FirmAssignmentFeaturePackage> {

  @Query(
      value = "select * from \"IAM_V2\".firm_feature_package_assignment(:firmId, :featurePackageId, :requestedBy);",
      countQuery = "select count(*) from \"IAM_V2\".firm_feature_package_assignment(:firmId, :featurePackageId,  :requestedBy);",
      nativeQuery = true)
  void setFirmFeaturePackageAssignment(String firmId, long featurePackageId, String requestedBy);

  @Query(
      value = "select * from \"IAM_V2\".firm_feature_package_assignment(:firmId, :featurePackageId, :requestedBy, :systemClientId);",
      countQuery = "select count(*) from \"IAM_V2\".firm_feature_package_assignment(:firmId, :featurePackageId, :requestedBy, :systemClientId);",
      nativeQuery = true)
  void setFirmFeaturePackageAssignment(String firmId, long featurePackageId, String requestedBy, String systemClientId);
}
