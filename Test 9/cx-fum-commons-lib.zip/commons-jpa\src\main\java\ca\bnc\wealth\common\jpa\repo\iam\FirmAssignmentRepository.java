package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.FirmAssignment;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface FirmAssignmentRepository extends JpaRepository<FirmAssignment, Long>,
    JpaSpecificationExecutor<FirmAssignment> {

  Optional<List<FirmAssignment>> deleteFirmAssignmentByFirmEntityId(Integer firmEntityId);

}
