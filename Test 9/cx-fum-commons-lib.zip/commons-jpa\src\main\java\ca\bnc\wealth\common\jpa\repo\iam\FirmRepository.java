package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.Collection;
import java.util.List;
@Repository
public interface FirmRepository extends JpaRepository<Firm, Long>,
    JpaSpecificationExecutor<Firm> {

  Firm findByFirmId(String firmId);
  List<Firm> findAllByFirmIdIn(List<String> firmIds);
  List<Firm> findAllByFirmType(FirmType firmType);
  List<Firm> findAllByFirmTypeIn(Collection<FirmType> firmTypes);
  Firm findByIdentitySource(String identitySource);

  @Query(
      value =
          "select * from \"IAM_V2\".fn_validate_rr_code_range(:firmId, :fromRRCode,:toRRCode);",
      countQuery =
          "select count(*) from \"IAM_V2\".fn_validate_rr_code_range(:firmId, :fromRRCode,:toRRCode);",
      nativeQuery = true)
  boolean validRrCodeRangeForFirmId(String firmId, String fromRRCode, String toRRCode);

  @Query(
      value = "select \"IAM_V2\".GET_ALL_USER_FIRMS(:idpSubject);",
      countQuery = "select count(*) from \"IAM_V2\".GET_ALL_USER_FIRMS(:idpSubject);",
      nativeQuery = true)
  List<Long> getAllFirmsByIdpSubject(String idpSubject);

  @Query(
      value = "select \"IAM_V2\".GET_CHILD_FIRMS(:firmEntityId);",
      countQuery = "select count(*) from \"IAM_V2\".GET_CHILD_FIRMS(:firmEntityId);",
      nativeQuery = true)
  List<Integer> getAllChildFirmByFirmEntityId(long firmEntityId);

  @Modifying
  @Query(
      value = "UPDATE \"IAM_V2\".\"FIRM\" SET \"FIRM_PREFERENCES\" = CAST(:prefsJson AS jsonb) WHERE \"FIRM_ID\" = :firmId",
      nativeQuery = true)
  void updateFirmPreferences(@Param("firmId") String firmId, @Param("prefsJson") String prefsJson);

}
