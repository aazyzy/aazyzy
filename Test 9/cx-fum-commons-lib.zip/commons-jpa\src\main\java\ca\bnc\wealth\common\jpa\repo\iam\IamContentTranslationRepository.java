package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.iam.IamContentTranslation;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface IamContentTranslationRepository extends JpaRepository<IamContentTranslation, Long>,
    JpaSpecificationExecutor<IamContentTranslation> {

  List<IamContentTranslation> findByPreferredLanguage(PreferredLanguageType referredLanguage);
}
