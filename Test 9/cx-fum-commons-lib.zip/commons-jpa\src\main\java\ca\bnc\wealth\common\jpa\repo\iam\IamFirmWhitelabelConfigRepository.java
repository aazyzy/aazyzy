package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.IamFirmWhitelabelConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface IamFirmWhitelabelConfigRepository extends JpaRepository<IamFirmWhitelabelConfig, Long>,
    JpaSpecificationExecutor<IamFirmWhitelabelConfig> {

  IamFirmWhitelabelConfig findByFirmFirmId(String firmId);
}
