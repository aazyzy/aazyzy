package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.IamIdpUserStatus;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface IamIdpUserStatusRepository extends JpaRepository<IamIdpUserStatus, Long>,
    JpaSpecificationExecutor<IamIdpUserStatus> {

  Optional<IamIdpUserStatus> findByUserConfigurationUserConfigurationId(long userConfigurationId);
}
