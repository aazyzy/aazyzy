package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface IamRrCodeRangeRepository extends JpaRepository<IamRrCodeRange, Long>, JpaSpecificationExecutor<IamRrCodeRange> {

  Optional<IamRrCodeRange> findFirstByFromRrCodeAndToRrCode(String fromRrCode, String toRrCode);

  @Query(
      value = "select * from \"IAM_V2\".b36_decode(:rrCode);",
      countQuery = "select count(*) from \"PLATFORM\".b36_decode(:rrCode);",
      nativeQuery = true)
  long rrCodeDecoder(String rrCode);

  @Query(
      value = "select * from \"IAM_V2\".b36_encode(:rrCode);",
      countQuery = "select count(*) from \"PLATFORM\".b36_encode(:rrCode);",
      nativeQuery = true)
  String rrCodeEncode(long rrCode);

  @Query(
          value = "select * from \"IAM_V2\".fn_validate_rr_code_range_user(:idpSubject, :rrCodeFrom, :rrCodeTo);",
          nativeQuery = true)
    boolean validRrCodeRangeForUser(String idpSubject, String rrCodeFrom, String rrCodeTo);

}
