package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.IamSchedulerStatus;
import ca.bnc.wealth.common.jpa.entity.platform.SchedulerStatus;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.stereotype.Repository;

@Repository
public interface IamSchedulerStatusRepository extends JpaRepository<IamSchedulerStatus, Long>,
    JpaSpecificationExecutor<IamSchedulerStatus> {

  @Lock(LockModeType.PESSIMISTIC_WRITE)
  IamSchedulerStatus findFirstBySchedulerName(String scheduleName);

}
