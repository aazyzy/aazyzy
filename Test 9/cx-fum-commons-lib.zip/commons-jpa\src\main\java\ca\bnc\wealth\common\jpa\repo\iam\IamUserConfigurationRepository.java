package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Limit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface IamUserConfigurationRepository
    extends JpaRepository<IamUserConfiguration, Long>,
        JpaSpecificationExecutor<IamUserConfiguration> {

  IamUserConfiguration findByIdpSubject(String idpSubject);

  Optional<IamUserConfiguration> findFirstByIdpSubject(String idpSubject);

  Optional<IamUserConfiguration> findFirstByUsername(String username);

  Optional<IamUserConfiguration> findFirstByBngfReferenceId(String bngfReferenceId);

  Optional<IamUserConfiguration> findFirstByEmail(String email);

  // Employee Short IDs reach us in whatever case IdentityIQ used, so identity lookups must be
  // case-insensitive (NWPI-14901). Spring Data renders IgnoreCase as upper(x) = upper(?), which
  // matches the USER_CONFIGURATION_USERNAME_CI_uidx functional index.
  Optional<IamUserConfiguration> findFirstByUsernameIgnoreCase(String username);

  Optional<IamUserConfiguration> findFirstByIdpSubjectIgnoreCase(String idpSubject);

  Optional<IamUserConfiguration> findFirstByBngfReferenceIdIgnoreCase(String bngfReferenceId);

  // USER_CONFIGURATION.EMAIL is deliberately not unique (its UNIQUE was dropped in V1_0_121),
  // so the result must be limited or a shared email raises NonUniqueResultException.
  @Query("SELECT u FROM IamUserConfiguration u WHERE LOWER(u.email) = LOWER(:email)"
      + " ORDER BY u.userConfigurationId")
  List<IamUserConfiguration> findByEmailIgnoreCase(@Param("email") String email, Limit limit);

  default Optional<IamUserConfiguration> findFirstByEmailIgnoreCase(String email) {
    return findByEmailIgnoreCase(email, Limit.of(1)).stream().findFirst();
  }
}
