package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.Capability;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.Permission;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import java.util.Collection;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface PackageTemplateAssignmentResourceRepository extends JpaRepository<PackageTemplateAssignmentResource, Long>, JpaSpecificationExecutor<PackageTemplateAssignmentResource> {

  @Transactional
  @Modifying
  @Query("DELETE FROM PackageTemplateAssignmentResource ptar WHERE ptar.packageTemplate = :packageTemplate AND ptar.assignmentType = :assignmentType")
  void deleteByPackageTemplateAndAssignmentType(PackageTemplate packageTemplate, PackageAssignmentType assignmentType);

  @Transactional
  @Modifying
  @Query("DELETE FROM PackageTemplateAssignmentResource ptar WHERE ptar.packageTemplate = :packageTemplate AND ptar.assignmentType = :assignmentType AND ptar.resource IN (:resources)")
  void deleteByPackageTemplateAndAssignmentTypeAndResources(PackageTemplate packageTemplate, PackageAssignmentType assignmentType, List<Resource> resources);

  List<PackageTemplateAssignmentResource> findByAssignmentTypeAndAssignmentModeAndSelectionDefault(PackageAssignmentType assignmentType, PackageAssignmentMode assignmentMode, boolean selectionDefault);
}
