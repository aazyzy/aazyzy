package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentUserGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface PackageTemplateAssignmentUserGroupRepository extends JpaRepository<PackageTemplateAssignmentUserGroup, Long>, JpaSpecificationExecutor<PackageTemplateAssignmentUserGroup> {
}
