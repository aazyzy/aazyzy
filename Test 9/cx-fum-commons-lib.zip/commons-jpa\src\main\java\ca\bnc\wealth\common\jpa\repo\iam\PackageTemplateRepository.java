package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface PackageTemplateRepository extends
    JpaRepository<PackageTemplate, Long>,
    JpaSpecificationExecutor<PackageTemplate> {

  Optional<PackageTemplate> findByName(String packageTemplateName);

  Optional<PackageTemplate> findByNameAndType(String packageTemplateName, PackageType type);

  List<PackageTemplate> findByType(PackageType type);

  @Query(
      value = "select * from \"IAM_V2\".add_ptd_to_pt(:packageTemplateName,CAST(STRING_TO_ARRAY((:ptdsCsv),',') AS VARCHAR[]), :requestedBy);",
      countQuery = "select count(*) from \"IAM_V2\".add_ptd_to_pt(:packageTemplateName,CAST(STRING_TO_ARRAY((:ptdsCsv),',') AS VARCHAR[]), :requestedBy);",
      nativeQuery = true)
  void addPtdToPt(String packageTemplateName, String ptdsCsv, String requestedBy);
  //cast(string_to_array(cast(:orgInfoIds as varchar) , ',')as bigint[]

  @Query(
      value = "select * from \"IAM_V2\".delete_ptd_from_pt(:packageTemplateName, CAST(STRING_TO_ARRAY((:ptdResourcesCsv),',') AS VARCHAR[]));",
      countQuery = "select count(*) from \"IAM_V2\".delete_ptd_from_pt(:packageTemplateName,CAST(STRING_TO_ARRAY((:ptdResourcesCsv),',') AS VARCHAR[]));",
      nativeQuery = true)
  void deletePtdFromPt(String packageTemplateName, String ptdResourcesCsv);

  @Query(
      value = "select * from \"IAM_V2\".replace_ptd_for_pt(:packageTemplateName, CAST(STRING_TO_ARRAY((:ptdsCsv),',') AS VARCHAR[]), :requestedBy);",
      countQuery = "select count(*) from \"IAM_V2\".replace_ptd_for_pt(:packageTemplateName,CAST(STRING_TO_ARRAY((:ptdsCsv),',') AS VARCHAR[]), :requestedBy);",
      nativeQuery = true)
  void replacePtdForPt(String packageTemplateName, String ptdsCsv, String requestedBy);
}
