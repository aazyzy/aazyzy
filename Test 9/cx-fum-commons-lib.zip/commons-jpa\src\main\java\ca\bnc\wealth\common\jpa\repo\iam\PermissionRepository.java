package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.Capability;
import ca.bnc.wealth.common.jpa.entity.iam.Permission;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface PermissionRepository extends JpaRepository<Permission, Long>,
    JpaSpecificationExecutor<Permission> {

  List<Permission> findByNameInAndCapability(Collection<String> name, Capability capability);

  Optional<Permission> findFirstByNameAndCapability(String name, Capability capability);
}
