package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.PersonAssignment;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface PersonAssignmentRepository
    extends JpaRepository<PersonAssignment, Long>,
        JpaSpecificationExecutor<PersonAssignment> {

  List<PersonAssignment> findAllByPersonPersonId(Long personId);

  Optional<PersonAssignment> findFirstByPersonPersonIdAndUserId(Long personId, Integer userId);

  Optional<PersonAssignment> findFirstByUserId(Integer userId);
}
