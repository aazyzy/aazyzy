package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.Person;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Limit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PersonRepository
    extends JpaRepository<Person, Long>,
        JpaSpecificationExecutor<Person> {

  Optional<Person> findFirstByEmail(String email);

  // LOWER (not the derived IgnoreCase, which emits UPPER) so the query uses ux_person_email_lower.
  @Query("SELECT p FROM Person p WHERE LOWER(p.email) = LOWER(:email) ORDER BY p.personId")
  List<Person> findByEmailIgnoreCase(@Param("email") String email, Limit limit);

  default Optional<Person> findFirstByEmailIgnoreCase(String email) {
    return findByEmailIgnoreCase(email, Limit.of(1)).stream().findFirst();
  }
}
