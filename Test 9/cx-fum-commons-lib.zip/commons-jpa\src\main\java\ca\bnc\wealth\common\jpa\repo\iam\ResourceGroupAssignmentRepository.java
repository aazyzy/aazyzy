package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.ResourceGroupAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface ResourceGroupAssignmentRepository extends
    JpaRepository<ResourceGroupAssignment, Long>,
    JpaSpecificationExecutor<ResourceGroupAssignment> {

}
