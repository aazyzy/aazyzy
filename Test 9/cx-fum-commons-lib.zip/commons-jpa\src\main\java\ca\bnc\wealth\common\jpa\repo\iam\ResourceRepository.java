package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ResourceRepository extends JpaRepository<Resource, Long>, JpaSpecificationExecutor<Resource> {
  List<Resource> findByType(String type);
  List<Resource> findByRestriction(Boolean restriction);
  Optional<Resource> findFirstByTypeAndName(String type, String name);
  Optional<Resource> findFirstByName(String name);
  Optional<Resource> findFirstByNameAndRestriction(String name, Boolean restriction);
}
