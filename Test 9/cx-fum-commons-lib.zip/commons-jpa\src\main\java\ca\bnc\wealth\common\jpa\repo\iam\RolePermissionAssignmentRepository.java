package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.Role;
import ca.bnc.wealth.common.jpa.entity.iam.RolePermissionAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface RolePermissionAssignmentRepository extends JpaRepository<RolePermissionAssignment, Long>, JpaSpecificationExecutor<RolePermissionAssignment> {

  void deleteRolePermissionAssignmentsByRole(Role role);

}
