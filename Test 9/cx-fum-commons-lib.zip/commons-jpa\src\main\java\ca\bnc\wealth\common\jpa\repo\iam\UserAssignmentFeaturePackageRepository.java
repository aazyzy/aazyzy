package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentFeaturePackage;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface UserAssignmentFeaturePackageRepository extends JpaRepository<UserAssignmentFeaturePackage, Long>, JpaSpecificationExecutor<UserAssignmentFeaturePackage> {

  Optional<List<UserAssignmentFeaturePackage>> findAllByAssignmentTypeAndUserConfiguration(UserAssignmentType assignmentType, IamUserConfiguration userConfiguration);
}
