package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignment;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserAssignmentRepository extends JpaRepository<UserAssignment, Long>, JpaSpecificationExecutor<UserAssignment> {

  List<UserAssignment> findAllByAssignmentType(UserAssignmentType assignmentType);

  Optional<UserAssignment> findFirstByIdpSubjectAndAssignmentTypeAndAssigneeId(String idpSubject, UserAssignmentType userAssignmentType, Integer assigneeId);

  Optional<UserAssignment> findFirstByIdpSubjectAndAssignmentType(String idpSubject, UserAssignmentType userAssignmentType);

  Optional<List<UserAssignment>> findAllByIdpSubjectAndAssignmentType(String idpSubject, UserAssignmentType userAssignmentType);

  void deleteUserAssignmentsByIdpSubject(String idpSubject);

  void deleteUserAssignmentsByIdpSubjectAndAssignmentType(String idpSubject, UserAssignmentType assignmentType);

  @Query(
      value = "select * from \"IAM_V2\".create_update_user_assignment(:userConfigurationId, :assignmentId, :assignmentType, :requestedBy);",
      countQuery = "select count(*) from \"IAM_V2\".create_update_user_assignment(:userConfigurationId, :assignmentId, :assignmentType,  :requestedBy);",
      nativeQuery = true)
  void setUserAssignment(long userConfigurationId, long assignmentId, String assignmentType, String requestedBy);

  @Query(
      value = "select * from \"IAM_V2\".apply_firm_access_level_to_user(:userConfigurationId, :requestedBy);",
      countQuery = "select count(*) from \"IAM_V2\".apply_firm_access_level_to_user(:userConfigurationId, :requestedBy);",
      nativeQuery = true)
  void applyFirmAccessLevelCheck(long userConfigurationId, String requestedBy);


  @Query(
      value = "select * from \"IAM_V2\".get_user_assignment(:idpSubject, :assignmentType, :active);",
      countQuery = "select count(*) from \"IAM_V2\".get_user_assignment(:idpSubject, :assignmentType, :active);",
      nativeQuery = true)
  List<Map<String, Object>> getUserAssignment(String idpSubject, String assignmentType, Boolean active);

  @Query(
      value = "select * from \"IAM_V2\".user_rr_code_assignment(:userConfigurationId, :rrCodes, :requestedBy);",
      countQuery = "select count(*) from \"IAM_V2\".user_rr_code_assignment(:userConfigurationId, :rrCodes, :requestedBy);",
      nativeQuery = true)
  void setUserRrCodeAssignment(long userConfigurationId, String rrCodes, String requestedBy);
}
