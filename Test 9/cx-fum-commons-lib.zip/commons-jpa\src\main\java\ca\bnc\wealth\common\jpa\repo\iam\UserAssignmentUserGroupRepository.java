package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentUserGroup;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface UserAssignmentUserGroupRepository extends JpaRepository<UserAssignmentUserGroup, Long>, JpaSpecificationExecutor<UserAssignmentUserGroup> {

  Optional<List<UserAssignmentUserGroup>> findAllByAssignmentTypeAndUserConfiguration(UserAssignmentType assignmentType, IamUserConfiguration userConfiguration);

  @Transactional
  void deleteByUserConfigurationIdpSubjectAndAssignmentTypeAndUserGroupName(String idpSubject, UserAssignmentType assignmentType, String userGroupName);
}
