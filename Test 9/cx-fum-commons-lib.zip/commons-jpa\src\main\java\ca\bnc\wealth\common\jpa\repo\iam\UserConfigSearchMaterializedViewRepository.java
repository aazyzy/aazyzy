package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface UserConfigSearchMaterializedViewRepository extends
    JpaRepository<UserConfigSearchMaterializedView, Long>,
    JpaSpecificationExecutor<UserConfigSearchMaterializedView> {

  @Transactional
  @Modifying
  @Query(
      value = "REFRESH MATERIALIZED VIEW CONCURRENTLY \"IAM_V2\".\"USER_CONFIGURATION_MATERIALIZED\";", nativeQuery = true)
  void refreshMeterializedView();

  List<UserConfigSearchMaterializedView> findAllByIdpSubjectIn(List<String> idpSubject);
  UserConfigSearchMaterializedView findByIdpSubject(String idpSubject);
}
