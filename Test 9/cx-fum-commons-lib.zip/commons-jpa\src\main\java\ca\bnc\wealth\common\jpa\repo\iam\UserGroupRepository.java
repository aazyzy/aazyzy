package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.UserGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserGroupRepository extends JpaRepository<UserGroup, Long>,
    JpaSpecificationExecutor<UserGroup> {
    Optional<UserGroup> findFirstByName(String name);
}
