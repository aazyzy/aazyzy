package ca.bnc.wealth.common.jpa.repo.iam;

import ca.bnc.wealth.common.jpa.entity.iam.UserGroupRoleAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface UserGroupRoleAssignmentRepository extends
    JpaRepository<UserGroupRoleAssignment, Long>,
    JpaSpecificationExecutor<UserGroupRoleAssignment> {

}
