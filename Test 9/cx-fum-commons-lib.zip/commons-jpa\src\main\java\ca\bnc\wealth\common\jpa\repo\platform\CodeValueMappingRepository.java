package ca.bnc.wealth.common.jpa.repo.platform;

import ca.bnc.wealth.common.jpa.entity.platform.CodeValueMapping;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface CodeValueMappingRepository extends JpaRepository<CodeValueMapping, Long>,
    JpaSpecificationExecutor<CodeValueMapping> {

  List<CodeValueMapping> findByUserConfigurationsIdpSubject(String idpSubject);

  CodeValueMapping findFirstByCodeValueIgnoreCase(String codeValue);

  CodeValueMapping findFirstByCodeTypeAndCodeValueIgnoreCase(String codeType, String codeValue);

  List<CodeValueMapping> findByCodeType(String codeType);
}
