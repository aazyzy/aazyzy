package ca.bnc.wealth.common.jpa.repo.platform;

import ca.bnc.wealth.common.jpa.entity.platform.CodeValueMapping;
import ca.bnc.wealth.common.jpa.entity.platform.ContentTranslation;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface ContentTranslationRepository extends JpaRepository<ContentTranslation, Long>,
    JpaSpecificationExecutor<ContentTranslation> {

  List<ContentTranslation> findByPreferredLanguageCodeId(CodeValueMapping codeValueMapping);
}
