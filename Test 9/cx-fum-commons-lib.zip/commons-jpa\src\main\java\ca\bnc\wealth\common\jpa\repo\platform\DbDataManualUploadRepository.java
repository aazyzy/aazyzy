package ca.bnc.wealth.common.jpa.repo.platform;

import ca.bnc.wealth.common.jpa.entity.platform.DbDataManualUpload;
import ca.bnc.wealth.common.jpa.entity.platform.DbDataUpdateHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface DbDataManualUploadRepository extends JpaRepository<DbDataManualUpload, Long>,
    JpaSpecificationExecutor<DbDataManualUpload> {

  public void deleteByDbDataUpdateHistory(DbDataUpdateHistory dbDataUpdateHistory);
}
