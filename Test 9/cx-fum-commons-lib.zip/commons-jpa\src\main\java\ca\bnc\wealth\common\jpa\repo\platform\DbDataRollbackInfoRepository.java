package ca.bnc.wealth.common.jpa.repo.platform;

import ca.bnc.wealth.common.jpa.entity.platform.DbDataRollbackInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface DbDataRollbackInfoRepository extends JpaRepository<DbDataRollbackInfo, Long>,
    JpaSpecificationExecutor<DbDataRollbackInfo> {

}
