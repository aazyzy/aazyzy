package ca.bnc.wealth.common.jpa.repo.platform;

import ca.bnc.wealth.common.jpa.entity.platform.DbDataUpdateHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface DbDataUpdateHistoryRepository extends JpaRepository<DbDataUpdateHistory, Long>,
    JpaSpecificationExecutor<DbDataUpdateHistory> {

  public DbDataUpdateHistory findTopByDbDataUpdateTypeOrderByDbDataUpdateHistoryIdDesc(
      String dbDataUpdateType);

  public DbDataUpdateHistory findTopByOrderByDbDataUpdateHistoryIdDesc();
}
