package ca.bnc.wealth.common.jpa.repo.platform;

import ca.bnc.wealth.common.jpa.entity.platform.FirmConfiguration;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface FirmConfigurationRepository extends JpaRepository<FirmConfiguration, Long>,
    JpaSpecificationExecutor<FirmConfiguration> {

  List<FirmConfiguration> findByUserEntityAssignmentsUserConfigurationIdpSubjectAndUserEntityAssignmentsResourceEntityTypeCodeIdCodeTypeAndUserEntityAssignmentsResourceEntityTypeCodeIdCodeValue(
      String idpSubject, String codeType, String codeValue);

  long countByUserEntityAssignmentsUserConfigurationIdpSubjectAndUserEntityAssignmentsResourceEntityTypeCodeIdCodeTypeAndUserEntityAssignmentsResourceEntityTypeCodeIdCodeValue(
      String idpSubject, String codeType, String codeValue);

  @Query("Select fc from FirmConfiguration fc " +
      "inner join fc.userEntityAssignments uea " +
      "inner join uea.userConfiguration uc " +
      "inner join uea.resourceEntityTypeCodeId cvm " +
      "where uc.idpSubject = :idpSubject and cvm.codeType = :codeType and cvm.codeValue = :codeValue")
  List<FirmConfiguration> findFirmConfiguratoin(String idpSubject, String codeType,
      String codeValue);

  @Query(
      value = "select \"PLATFORM\".GET_ALL_USER_FIRMS(:idpSubject);",
      countQuery = "select count(*) from \"PLATFORM\".GET_ALL_USER_FIRMS(:idpSubject);",
      nativeQuery = true)
  List<Long> getAllFirmsByIdpSubject(String idpSubject);

  @Query(
      value = "select \"PLATFORM\".GET_CHILD_FIRMS(:firmConfigurationId);",
      countQuery = "select count(*) from \"PLATFORM\".GET_CHILD_FIRMS(:firmConfigurationId);",
      nativeQuery = true)
  List<Integer> getAllChildFirmByFirmConfigurationId(Integer firmConfigurationId);

  FirmConfiguration findByFirmId(String firmId);

  @Query(
      value =
          "select * from \"PLATFORM\".fn_validate_rr_code_range(:firmId, :fromRRCode,:toRRCode);",
      countQuery =
          "select count(*) from \"PLATFORM\".fn_validate_rr_code_range(:firmId, :fromRRCode,:toRRCode);",
      nativeQuery = true)
  boolean validRrCodeRangeForFirmId(String firmId, String fromRRCode, String toRRCode);

  List<FirmConfiguration> findByFirmConfigurationIdIn(List<Long> ids);
}
