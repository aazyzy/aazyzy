package ca.bnc.wealth.common.jpa.repo.platform;

import ca.bnc.wealth.common.jpa.entity.platform.FirmWhitelabelConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface FirmWhitelabelConfigRepository extends JpaRepository<FirmWhitelabelConfig, Long>,
        JpaSpecificationExecutor<FirmWhitelabelConfig> {

    FirmWhitelabelConfig findByFirmConfigurationFirmId(String firmId);
}
