package ca.bnc.wealth.common.jpa.repo.platform;

import ca.bnc.wealth.common.jpa.entity.platform.IdpUserStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface IdpUserStatusRepository extends JpaRepository<IdpUserStatus, Long>,
    JpaSpecificationExecutor<IdpUserStatus> {

}
