package ca.bnc.wealth.common.jpa.repo.platform;


import ca.bnc.wealth.common.jpa.entity.platform.RrCodeRangeAssignmentFirm;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface RrCodeRangeAssignmentFirmRepository extends
    JpaRepository<RrCodeRangeAssignmentFirm, Long>,
    JpaSpecificationExecutor<RrCodeRangeAssignmentFirm> {

  @Modifying
  @Query(
      value =
          "delete from \"PLATFORM\".\"RR_CODE_RANGE_ASSIGNMENT\" where \"RR_CODE_RANGE_ENTITY_ID\" = :firmId and \"RR_ASSIGNMENT_TYPE_CODE_ID\" = :codeValueMappingId and \"RR_CODE_RANGE_ID\" in (:rrCodeRangeIdList);",
      countQuery =
          "select count(*) from \"PLATFORM\".\"RR_CODE_RANGE_ASSIGNMENT\" where \"RR_CODE_RANGE_ENTITY_ID\" = :firmId and \"RR_ASSIGNMENT_TYPE_CODE_ID\" = :codeValueMappingId and \"RR_CODE_RANGE_ID\" in (:rrCodeRangeIdList);",
      nativeQuery = true)
  void deleteByFirmIdAndCodeValueMappingIdAndListOfRRCodeRangeIds(
      Integer firmId, Long codeValueMappingId, List<Integer> rrCodeRangeIdList);
}
