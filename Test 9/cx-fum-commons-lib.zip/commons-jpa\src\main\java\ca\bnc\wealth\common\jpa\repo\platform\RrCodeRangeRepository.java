package ca.bnc.wealth.common.jpa.repo.platform;

import ca.bnc.wealth.common.jpa.entity.platform.RrCodeRange;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface RrCodeRangeRepository extends JpaRepository<RrCodeRange, Long>,
    JpaSpecificationExecutor<RrCodeRange> {

  @Query(
      value = "select * from \"PLATFORM\".b36_decode(:rrCode);",
      countQuery = "select count(*) from \"PLATFORM\".b36_decode(:rrCode);",
      nativeQuery = true)
  long rrCodeDecoder(String rrCode);

  @Query(
      value = "select * from \"PLATFORM\".b36_encode(:rrCode);",
      countQuery = "select count(*) from \"PLATFORM\".b36_encode(:rrCode);",
      nativeQuery = true)
  String rrCodeEncode(long rrCode);

  @Query(
      value = "select * from \"PLATFORM\".split_rr_range_to_codes(:fromRRRange, :toRRRange);",
      countQuery = "select count(*) from \"PLATFORM\".split_rr_range_to_codes(:fromRRRange, :toRRRange);",
      nativeQuery = true)
  List<String> splitRrCode(String fromRRRange, String toRRRange);
}
