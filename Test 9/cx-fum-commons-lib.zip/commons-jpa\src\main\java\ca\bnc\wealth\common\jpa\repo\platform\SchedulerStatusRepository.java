package ca.bnc.wealth.common.jpa.repo.platform;

import ca.bnc.wealth.common.jpa.entity.platform.SchedulerStatus;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.stereotype.Repository;

@Repository
public interface SchedulerStatusRepository extends JpaRepository<SchedulerStatus, Long>,
    JpaSpecificationExecutor<SchedulerStatus> {

  @Lock(LockModeType.PESSIMISTIC_WRITE)
  SchedulerStatus findFirstBySchedulerName(String scheduleName);

}
