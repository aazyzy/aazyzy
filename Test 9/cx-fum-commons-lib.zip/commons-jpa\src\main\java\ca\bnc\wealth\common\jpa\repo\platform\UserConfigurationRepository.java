package ca.bnc.wealth.common.jpa.repo.platform;

import ca.bnc.wealth.common.jpa.entity.platform.UserConfiguration;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface UserConfigurationRepository extends JpaRepository<UserConfiguration, Long>,
    JpaSpecificationExecutor<UserConfiguration> {

  UserConfiguration findByIdpSubject(String idpSubject);


  List<UserConfiguration> findByIdpSubjectAndCodeValueMappingCodeType(String idpSubject,
      String codeType);

  List<UserConfiguration> findByUserConfigurationIdAndCodeValueMappingCodeType(
      Long userConfigurationId, String codeType);

  List<UserConfiguration> findByIdpSubjectAndUserEntityAssignmentsAssignmentTypeCodeIdCodeTypeAndUserEntityAssignmentsAssignmentTypeCodeIdCodeValue(
      String idpSubject, String codeType, String codeValue);
}
