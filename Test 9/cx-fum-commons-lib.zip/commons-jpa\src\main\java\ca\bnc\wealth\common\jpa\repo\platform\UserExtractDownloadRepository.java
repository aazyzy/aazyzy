package ca.bnc.wealth.common.jpa.repo.platform;

import ca.bnc.wealth.common.jpa.entity.platform.UserExtractDownload;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface UserExtractDownloadRepository extends JpaRepository<UserExtractDownload, Long>,
    JpaSpecificationExecutor<UserExtractDownload> {

}