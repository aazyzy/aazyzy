package ca.bnc.wealth.common.jpa.repo.platform;

import ca.bnc.wealth.common.jpa.entity.platform.UserFirmResourceAssignmentView;
import ca.bnc.wealth.common.jpa.entity.platform.UserFirmResourceAssignmentViewIdClass;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface UserFirmResourceAssignmentViewRepository extends
    JpaRepository<UserFirmResourceAssignmentView, UserFirmResourceAssignmentViewIdClass>,
    JpaSpecificationExecutor<UserFirmResourceAssignmentView> {

}
