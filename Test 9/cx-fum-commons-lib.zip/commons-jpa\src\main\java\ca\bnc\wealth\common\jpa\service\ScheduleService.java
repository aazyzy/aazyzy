package ca.bnc.wealth.common.jpa.service;

import ca.bnc.wealth.common.jpa.entity.platform.SchedulerStatus;
import ca.bnc.wealth.common.jpa.repo.platform.SchedulerStatusRepository;
import java.sql.Timestamp;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class ScheduleService {

  private SchedulerStatusRepository schedulerStatusRepository;


  @Autowired
  public ScheduleService(SchedulerStatusRepository schedulerStatusRepository) {
    this.schedulerStatusRepository = schedulerStatusRepository;
  }

  @Transactional
  public boolean canRunSchedule(String scheduleName, long duration, TimeUnit timeUnit) {
    SchedulerStatus schedulerStatus = this.schedulerStatusRepository.findFirstBySchedulerName(
        scheduleName);

    if (schedulerStatus == null) {
      schedulerStatus = new SchedulerStatus();
      schedulerStatus.setSchedulerName(scheduleName);
    } else if (!canRunSchedule(schedulerStatus.getSchedulerStart(),
        schedulerStatus.getSchedulerEnd(), duration, timeUnit)) {
      return false;
    }
    schedulerStatus.setSchedulerStart(new Timestamp(System.currentTimeMillis()));
    schedulerStatus.setSchedulerEnd(null);
    this.schedulerStatusRepository.save(schedulerStatus);
    return true;
  }

  @Transactional
  public void updateStatusToFinish(String scheduleName) {
    SchedulerStatus schedulerStatus = this.schedulerStatusRepository.findFirstBySchedulerName(
        scheduleName);
    schedulerStatus.setSchedulerEnd(new Timestamp(System.currentTimeMillis()));
    this.schedulerStatusRepository.save(schedulerStatus);
  }

  private boolean canRunSchedule(Timestamp start, Timestamp end, long duration, TimeUnit timeUnit) {
    long currentTime = System.currentTimeMillis();
    long durationInMillisec = duration;
    switch (timeUnit) {
      case NANOSECONDS:
        durationInMillisec = duration / 1000;
        break;
      case MICROSECONDS:
        durationInMillisec = duration;
        break;
      case SECONDS:
        durationInMillisec = duration * 1000;
        break;
      case MINUTES:
        durationInMillisec = duration * 60 * 1000;
        break;
      case HOURS:
        durationInMillisec = duration * 60 * 60 * 1000;
        break;
      case DAYS:
        durationInMillisec = duration * 24 * 60 * 60 * 1000;
        break;
    }
    if (start == null) {
      return true;
    } else if (end == null) {
      durationInMillisec = durationInMillisec * 10;
      return start.getTime() + durationInMillisec < currentTime;
    }
    return end.getTime() + durationInMillisec < currentTime;
  }
}
