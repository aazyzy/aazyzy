package ca.bnc.wealth.common.jpa.specification;

import ca.bnc.wealth.common.jpa.utils.EnumSpecificationOperation;
import ca.bnc.wealth.common.jpa.utils.GenericQuery;
import ca.bnc.wealth.common.jpa.utils.Query;
import ca.bnc.wealth.common.jpa.utils.QueryParameterCombination;
import ca.bnc.wealth.common.jpa.utils.QueryParameters;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;

@AllArgsConstructor
public class SpecificationWithQuery<T, I, E extends Enum<E> & GenericQuery> extends
    GenericSpecification<T> {

  private I input;
  private Class<E> enumClass;
  private Map<String, Object> derivedFieldValueMap;
  private EnumSpecificationOperation operation = EnumSpecificationOperation.AND;
  private Query query = null;
  private boolean distinctQuery = true;
  private Map<String, Join<Object, Object>> joinMap = new HashMap<>();

  public SpecificationWithQuery(I input, Class<E> enumClass,
      Map<String, Object> derivedFieldValueMap, EnumSpecificationOperation operation,
      boolean distinctQuery) {
    this.input = input;
    this.enumClass = enumClass;
    this.derivedFieldValueMap = derivedFieldValueMap;
    this.operation = operation;
    this.distinctQuery = distinctQuery;
  }

  public SpecificationWithQuery(I input, Class<E> enumClass,
      Map<String, Object> derivedFieldValueMap, Query query, boolean distinctQuery) {
    this.input = input;
    this.enumClass = enumClass;
    this.derivedFieldValueMap = derivedFieldValueMap;
    this.query = query;
    this.distinctQuery = distinctQuery;
  }


  public Predicate toPredicate(Root<T> root, CriteriaQuery<?> criteriaQuery,
      CriteriaBuilder criteriaBuilder) {
    Predicate predicate = null;
    criteriaQuery.distinct(distinctQuery);
    this.joinMap = new HashMap<>();
    if (Optional.ofNullable(query).isPresent()) {
      predicate = preOrderTraversal(root, criteriaBuilder, query);
    } else {
      Map<String, Object> fieldValueMap = Optional.ofNullable(input)
          .map(input -> Arrays.stream(input.getClass().getDeclaredFields())
              .filter(this::hasFieldValue)
              .collect(Collectors.toMap(Field::getName, this::getFieldvalue)))
          .orElse(new HashMap<>());

      Optional.ofNullable(derivedFieldValueMap)
          .orElse(new HashMap<>())
          .entrySet()
          .forEach(entry -> fieldValueMap.put(entry.getKey(), entry.getValue()));

      predicate = this.getPredicate(root, criteriaBuilder, fieldValueMap, operation, distinctQuery);
    }
    return predicate != null ? predicate : criteriaBuilder.isTrue(criteriaBuilder.literal(true));
  }

  private Predicate preOrderTraversal(Root<T> root, CriteriaBuilder criteriaBuilder, Query query) {
    if (query == null) {
      return null;
    }

    if (query instanceof QueryParameters && ((QueryParameters) query).getParameter() != null) {
      Map<String, Object> fieldValueMap = Optional.ofNullable(input)
          .map(input -> Arrays.stream(input.getClass().getDeclaredFields())
              .filter(field -> ((QueryParameters) query).getParameter().contains(field.getName()))
              .filter(this::hasFieldValue)
              .collect(Collectors.toMap(Field::getName, this::getFieldvalue)))
          .orElse(new HashMap<>());
      Optional.ofNullable(derivedFieldValueMap)
          .orElse(new HashMap<>())
          .entrySet()
          .stream()
          .filter(entry -> ((QueryParameters) query).getParameter().contains(entry.getKey()))
          .forEach(entry -> fieldValueMap.put(entry.getKey(), entry.getValue()));

      return this.getPredicate(root, criteriaBuilder, fieldValueMap,
          ((QueryParameters) query).getOperation() != null
              ? ((QueryParameters) query).getOperation() : EnumSpecificationOperation.AND,
          distinctQuery);
    }
    Predicate leftPredicate = preOrderTraversal(root, criteriaBuilder,
        ((QueryParameterCombination) query).getSubQueryLeft());
    Predicate rightPredicate = preOrderTraversal(root, criteriaBuilder,
        ((QueryParameterCombination) query).getSubQueryRight());
    Predicate[] predicates = Stream.of(leftPredicate, rightPredicate)
        .filter(predicate -> predicate != null).toArray(Predicate[]::new);

    return getPredicate(criteriaBuilder, ((QueryParameterCombination) query).getOperation(),
        predicates);
  }

  private Predicate getPredicate(Root<T> root, CriteriaBuilder criteriaBuilder,
      Map<String, Object> fieldValueMap, EnumSpecificationOperation specificationOperation,
      boolean distinctQuery) {
    Predicate[] predicates = Arrays.stream(enumClass.getEnumConstants())
        .filter(constrain -> fieldValueMap.containsKey(constrain.name())
            || constrain.getDefaultValue() != null)
        .map(constrain -> getPredicate(root, criteriaBuilder, constrain, fieldValueMap,
            distinctQuery))
        .filter(predicate -> predicate != null)
        .toArray(Predicate[]::new);

    return getPredicate(criteriaBuilder, specificationOperation, predicates);
  }

  private Predicate getPredicate(Root<T> root, CriteriaBuilder criteriaBuilder, E searchEnum,
      Map<String, Object> fieldValueMap, boolean distinctQuery) {
    Object fieldValue =
        fieldValueMap.containsKey(searchEnum.name()) ? fieldValueMap.get(searchEnum.name())
            : searchEnum.getDefaultValue();
    return getPredicate(root, criteriaBuilder, searchEnum.getCriteria(),
        searchEnum.getEntityField(), fieldValue, searchEnum.getJoinTypes(), joinMap);
  }

  @SneakyThrows
  private boolean hasFieldValue(Field field) {
    field.setAccessible(true);
    return field.get(this.input) != null;
  }

  @SneakyThrows
  private Object getFieldvalue(Field field) {
    return field.get(this.input);
  }
}
