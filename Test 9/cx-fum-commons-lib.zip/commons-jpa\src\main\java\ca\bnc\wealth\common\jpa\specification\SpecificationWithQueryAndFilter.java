package ca.bnc.wealth.common.jpa.specification;

import ca.bnc.wealth.common.jpa.utils.*;
import jakarta.persistence.criteria.*;
import java.lang.reflect.Field;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.SneakyThrows;

public class SpecificationWithQueryAndFilter<T, I, E extends Enum<E> & GenericQuery> extends
        GenericSpecification<T> {

    private I input;
    private Class<E> enumClass;
    private Map<String, Object> derivedFieldValueMap;
    private EnumSpecificationOperation operation = EnumSpecificationOperation.AND;
    private Query query = null;

    private List<Filter> filters;
    private boolean distinctQuery = true;

    private Map<String, Filter> fieldNameFilterMap;
    private Map<String, Join<Object, Object>> joinMap = new HashMap<>();

    public SpecificationWithQueryAndFilter(I input, Class<E> enumClass, Map<String, Object> derivedFieldValueMap,
                                           EnumSpecificationOperation operation, List<Filter> filters, boolean distinctQuery) {
        this.input = input;
        this.enumClass = enumClass;
        this.derivedFieldValueMap = derivedFieldValueMap;
        this.operation = operation;
        this.filters = filters;
        this.distinctQuery = distinctQuery;
    }

    public SpecificationWithQueryAndFilter(I input, Class<E> enumClass, Map<String, Object> derivedFieldValueMap,
                                           Query query, List<Filter> filters, boolean distinctQuery) {
        this.input = input;
        this.enumClass = enumClass;
        this.derivedFieldValueMap = derivedFieldValueMap;
        this.query = query;
        this.filters = filters;
        this.distinctQuery = distinctQuery;
    }


    public Predicate toPredicate(Root<T> root, CriteriaQuery<?> criteriaQuery,
                                 CriteriaBuilder criteriaBuilder) {
        Predicate predicate = null;
        criteriaQuery.distinct(distinctQuery);
        this.joinMap = new HashMap<>();
        fieldNameFilterMap = Optional.ofNullable(filters).stream()
                .flatMap(Collection::stream)
                .collect(Collectors.toMap(Filter::getFieldName, f -> f));
        if (Optional.ofNullable(query).isPresent()) {
            predicate = preOrderTraversal(root, criteriaBuilder, query);
        } else {
            Map<String, Object> fieldValueMap = Optional.ofNullable(input)
                    .map(input -> Arrays.stream(input.getClass().getDeclaredFields())
                            .filter(this::hasFieldValue)
                            .collect(Collectors.toMap(Field::getName, this::getFieldvalue)))
                    .orElse(new HashMap<>());

            Optional.ofNullable(derivedFieldValueMap)
                    .orElse(new HashMap<>())
                    .entrySet()
                    .forEach(entry -> fieldValueMap.put(entry.getKey(), entry.getValue()));

            predicate = this.getPredicate(root, criteriaBuilder, fieldValueMap, operation, distinctQuery);
        }
        Predicate filterPredicate = getFilterPredicate(root, criteriaBuilder);

        Predicate[] finalPredicates = Stream.of(predicate, filterPredicate)
                .filter(Objects::nonNull)
                .toArray(Predicate[]::new);

        return finalPredicates.length != 0 ? criteriaBuilder.and(finalPredicates) : criteriaBuilder.isTrue(criteriaBuilder.literal(true));
    }

    private Predicate preOrderTraversal(Root<T> root, CriteriaBuilder criteriaBuilder, Query query) {
        if (query == null) {
            return null;
        }

        if (query instanceof QueryParameters && ((QueryParameters) query).getParameter() != null) {
            Map<String, Object> fieldValueMap = Optional.ofNullable(input)
                    .map(input -> Arrays.stream(input.getClass().getDeclaredFields())
                            .filter(field -> ((QueryParameters) query).getParameter().contains(field.getName()))
                            .filter(this::hasFieldValue)
                            .collect(Collectors.toMap(Field::getName, this::getFieldvalue)))
                    .orElse(new HashMap<>());
            Optional.ofNullable(derivedFieldValueMap)
                    .orElse(new HashMap<>())
                    .entrySet()
                    .stream()
                    .filter(entry -> ((QueryParameters) query).getParameter().contains(entry.getKey()))
                    .forEach(entry -> fieldValueMap.put(entry.getKey(), entry.getValue()));

            Arrays.stream(enumClass.getEnumConstants())
                    .filter(constrain -> ((QueryParameters) query).getParameter().contains(constrain.name()))
                    .filter(constrain -> !fieldValueMap.containsKey(constrain.name()))
                    .forEach(constrain -> fieldValueMap.put(constrain.name(), constrain.getDefaultValue()));

            return this.getPredicate(root, criteriaBuilder, fieldValueMap,
                    ((QueryParameters) query).getOperation() != null
                            ? ((QueryParameters) query).getOperation() : EnumSpecificationOperation.AND,
                    distinctQuery);
        }
        Predicate leftPredicate = preOrderTraversal(root, criteriaBuilder,
                ((QueryParameterCombination) query).getSubQueryLeft());
        Predicate rightPredicate = preOrderTraversal(root, criteriaBuilder,
                ((QueryParameterCombination) query).getSubQueryRight());
        Predicate[] predicates = Stream.of(leftPredicate, rightPredicate)
                .filter(predicate -> predicate != null).toArray(Predicate[]::new);

        return getPredicate(criteriaBuilder, ((QueryParameterCombination) query).getOperation(),
                predicates);
    }

    private Predicate getPredicate(Root<T> root, CriteriaBuilder criteriaBuilder,
                                   Map<String, Object> fieldValueMap, EnumSpecificationOperation specificationOperation,
                                   boolean distinctQuery) {
        Predicate[] predicates = Arrays.stream(enumClass.getEnumConstants())
                .filter(constrain -> !fieldNameFilterMap.containsKey(constrain.name()))
                .filter(constrain -> fieldValueMap.containsKey(constrain.name()) && fieldValueMap.get(constrain.name()) != null)
                .map(constrain -> getPredicate(root, criteriaBuilder, constrain, fieldValueMap,
                        distinctQuery))
                .filter(predicate -> predicate != null)
                .toArray(Predicate[]::new);

        return getPredicate(criteriaBuilder, specificationOperation, predicates);
    }

    private Predicate getPredicate(Root<T> root, CriteriaBuilder criteriaBuilder, E searchEnum,
                                   Map<String, Object> fieldValueMap, boolean distinctQuery) {
        Object fieldValue =
                fieldValueMap.containsKey(searchEnum.name()) ? fieldValueMap.get(searchEnum.name())
                        : searchEnum.getDefaultValue();
        return getPredicate(root, criteriaBuilder, searchEnum.getCriteria(),
                searchEnum.getEntityField(), fieldValue, searchEnum.getJoinTypes(), joinMap);
    }

    private Predicate getFilterPredicate(Root<T> root, CriteriaBuilder criteriaBuilder) {
        if (filters == null || filters.size() == 0)
            return null;

        Predicate[] predicates = Arrays.stream(enumClass.getEnumConstants())
                .filter(constrain -> fieldNameFilterMap.containsKey(constrain.name()))
                .map(constrain -> getPredicate(root, criteriaBuilder, fieldNameFilterMap.get(constrain.name()).getCriteria(),
                        constrain.getEntityField(), fieldNameFilterMap.get(constrain.name()).getFieldValue(), constrain.getJoinTypes(), joinMap))
                .filter(predicate -> predicate != null)
                .toArray(Predicate[]::new);

        return getPredicate(criteriaBuilder, EnumSpecificationOperation.AND, predicates);
    }

    @SneakyThrows
    private boolean hasFieldValue(Field field) {
        field.setAccessible(true);
        return field.get(this.input) != null;
    }

    @SneakyThrows
    private Object getFieldvalue(Field field) {
        return field.get(this.input);
    }
}

