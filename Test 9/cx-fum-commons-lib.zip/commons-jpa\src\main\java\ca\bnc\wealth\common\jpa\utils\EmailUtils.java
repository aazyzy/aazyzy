package ca.bnc.wealth.common.jpa.utils;

/** Canonical form of an email address: trimmed and lower-cased (NWPI-14875). */
public final class EmailUtils {

  private EmailUtils() {
  }

  public static String canonicalize(String email) {
    return email == null ? null : email.trim().toLowerCase(java.util.Locale.ROOT);
  }
}
