package ca.bnc.wealth.common.jpa.utils;

public enum EnumSpecificationOperation {
  AND, OR;
}
