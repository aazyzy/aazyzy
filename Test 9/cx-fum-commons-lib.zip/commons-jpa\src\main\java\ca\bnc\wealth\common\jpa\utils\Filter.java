package ca.bnc.wealth.common.jpa.utils;

import lombok.Data;

@Data
public class Filter {

    String fieldName;
    EnumQueryCriteria criteria;
    Object fieldValue;
}
