package ca.bnc.wealth.common.jpa.utils;

import jakarta.persistence.criteria.JoinType;

public interface GenericQuery {

  EnumQueryCriteria getCriteria();

  String getEntityField();

  Object getDefaultValue();

  JoinType[] getJoinTypes();
}
