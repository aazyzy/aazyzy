package ca.bnc.wealth.common.jpa.utils;

public interface Query {

}
