package ca.bnc.wealth.common.jpa.utils;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class QueryParameters implements Query {

  List<String> parameter;
  EnumSpecificationOperation operation = EnumSpecificationOperation.AND;
}
