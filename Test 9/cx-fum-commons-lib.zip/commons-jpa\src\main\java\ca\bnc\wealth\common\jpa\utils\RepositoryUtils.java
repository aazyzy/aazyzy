package ca.bnc.wealth.common.jpa.utils;

import java.util.List;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

public class RepositoryUtils {

  public static PageRequest getPageRequest(Integer pageNumber, Integer pageSize,
      List<String> sortBy, String sortOrder, boolean ignoreCase) {
    Sort sort = getSortOrder(sortBy, sortOrder, ignoreCase);

    PageRequest page =
        pageSize == null || pageNumber == null ? PageRequest.of(0, Integer.MAX_VALUE, sort)
            : PageRequest.of(pageNumber - 1, pageSize, sort);

    return page;
  }

  public static PageRequest getPageRequest(Integer pageNumber, Integer pageSize) {

    PageRequest page = pageSize == null || pageNumber == null ? PageRequest.of(0, Integer.MAX_VALUE)
        : PageRequest.of(pageNumber - 1, pageSize);
    return page;
  }

  public static Sort getSortOrder(List<String> sortBy, String sortOrder, boolean ignoreCase) {
    Sort.Direction direction =
        sortOrder == null ? Sort.Direction.ASC : Sort.Direction.valueOf(sortOrder);

    Sort.Order[] orders = sortBy.stream()
        .map(field -> ignoreCase ? new Sort.Order(direction, field).ignoreCase()
            : new Sort.Order(direction, field))
        .toArray(Sort.Order[]::new);

    return Sort.by(orders);
  }
}
