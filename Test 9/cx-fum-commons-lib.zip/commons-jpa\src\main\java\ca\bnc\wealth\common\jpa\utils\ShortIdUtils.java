package ca.bnc.wealth.common.jpa.utils;

import java.util.Locale;

/**
 * Canonical form of an employee Short ID: trimmed and upper-cased (NWPI-14901).
 *
 * <p>Locale.ROOT is mandatory — the no-arg {@code toUpperCase()} would map "i" to "İ" under a
 * Turkish default locale and no longer match the PostgreSQL {@code upper("USERNAME")} index.
 */
public final class ShortIdUtils {

  private ShortIdUtils() {
  }

  public static String canonicalize(String shortId) {
    return shortId == null ? null : shortId.trim().toUpperCase(Locale.ROOT);
  }
}
