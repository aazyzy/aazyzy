package ca.bnc.wealth.common.jpa.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyNoInteractions;

import java.sql.Connection;
import java.util.Properties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;
import software.amazon.jdbc.HostSpecBuilder;
import software.amazon.jdbc.PluginService;
import software.amazon.jdbc.dialect.AuroraPgDialect;
import software.amazon.jdbc.dialect.Dialect;
import software.amazon.jdbc.dialect.DialectManager;
import software.amazon.jdbc.hostavailability.SimpleHostAvailabilityStrategy;

class DatabaseConfigTest {

  private static final String PROTOCOL = "jdbc:postgresql://";
  private static final String HOST = "fum-db.cluster-example.ca-central-1.rds.amazonaws.com";

  private DatabaseConfig databaseConfig;

  @BeforeEach
  void setUp() {
    databaseConfig = new DatabaseConfig();
    ReflectionTestUtils.setField(databaseConfig, "iamRegion", "ca-central-1");
    ReflectionTestUtils.setField(databaseConfig, "iamDefaultPort", "5432");
  }

  @Test
  void shouldLeaveTheDialectToTheWrapperWhenNoneIsConfigured() {
    ReflectionTestUtils.setField(databaseConfig, "wrapperDialect", "");

    Properties properties = databaseConfig.iamWrapperProperties();

    assertEquals("iam,failover,efm2", properties.getProperty("wrapperPlugins"));
    assertEquals("ca-central-1", properties.getProperty("iamRegion"));
    assertEquals("5432", properties.getProperty("iamDefaultPort"));
    assertFalse(properties.containsKey("wrapperDialect"));
  }

  @Test
  void shouldPassTheConfiguredDialectToTheWrapper() {
    ReflectionTestUtils.setField(databaseConfig, "wrapperDialect", "aurora-pg");

    assertEquals("aurora-pg", databaseConfig.iamWrapperProperties().getProperty("wrapperDialect"));
  }

  @Test
  void shouldNeverUpgradeAPinnedAuroraDialectToTheGlobalOne() throws Exception {
    ReflectionTestUtils.setField(databaseConfig, "wrapperDialect", "aurora-pg");
    DialectManager dialectManager = new DialectManager(mock(PluginService.class));
    Connection connection = mock(Connection.class);
    String url = PROTOCOL + HOST + ":5432/postgres";

    Dialect dialect =
        dialectManager.getDialect(PROTOCOL, url, databaseConfig.iamWrapperProperties());
    Dialect afterConnect =
        dialectManager.getDialect(
            url, new HostSpecBuilder(new SimpleHostAvailabilityStrategy()).host(HOST).build(),
            connection);

    assertEquals(AuroraPgDialect.class, dialect.getClass());
    assertSame(dialect, afterConnect);
    verifyNoInteractions(connection);
  }
}
