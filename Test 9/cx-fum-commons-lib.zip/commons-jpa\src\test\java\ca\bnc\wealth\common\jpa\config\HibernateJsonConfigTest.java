package ca.bnc.wealth.common.jpa.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertSame;

import ca.bnc.wealth.common.jpa.entity.iam.AuditLogEvent;
import ca.bnc.wealth.common.jpa.entity.iam.AuditLogEventDetails;
import ca.bnc.wealth.common.jpa.entity.iam.BulkUploadTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.jsonb.AuditEventDetails;
import ca.bnc.wealth.common.jpa.entity.jsonb.Template;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.lang.reflect.Type;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.type.format.jackson.Jackson3JsonFormatMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The expected JSON is what Hibernate 6.6's Jackson 2 mapper wrote for the same values on the
 * Spring Boot 3 line.
 */
class HibernateJsonConfigTest {

  private Jackson3JsonFormatMapper formatMapper;

  @BeforeEach
  void setUp() {
    Map<String, Object> properties = new HashMap<>();
    new HibernateJsonConfig().jsonFormatMapperCustomizer().customize(properties);
    formatMapper =
        assertInstanceOf(
            Jackson3JsonFormatMapper.class, properties.get(AvailableSettings.JSON_FORMAT_MAPPER));
  }

  @Test
  void shouldKeepAJsonFormatMapperTheApplicationAlreadySet() {
    Object configured = new Object();
    Map<String, Object> properties = new HashMap<>();
    properties.put(AvailableSettings.JSON_FORMAT_MAPPER, configured);

    new HibernateJsonConfig().jsonFormatMapperCustomizer().customize(properties);

    assertSame(configured, properties.get(AvailableSettings.JSON_FORMAT_MAPPER));
  }

  @Test
  void shouldMapAuditEventDetailsAsTheSpringBoot3LineDid() throws NoSuchFieldException {
    AuditEventDetails details = new AuditEventDetails();
    details.setFirstName("Ann");
    details.setFirmLevelAccess(false);
    Map<String, String> preferences = new LinkedHashMap<>();
    preferences.put("theme", "dark");
    preferences.put("nullValue", null);
    details.setAppPreferences(preferences);
    String json =
        "{\"firstName\":\"Ann\",\"firmLevelAccess\":false,"
            + "\"appPreferences\":{\"theme\":\"dark\",\"nullValue\":null}}";
    Type type = columnType(AuditLogEventDetails.class, "record");

    assertEquals(json, formatMapper.toString(details, type));
    assertEquals(details, formatMapper.fromString(json, type));
  }

  @Test
  void shouldMapAuditedUserConfigurationAsTheSpringBoot3LineDid() throws NoSuchFieldException {
    UserConfiguration user = new UserConfiguration();
    user.setFirmId("NBIN");
    user.setCreationDate(LocalDateTime.of(2026, 10, 8, 13, 14, 15, 120_000_000));
    user.setIsFirmScope(true);
    String json =
        "{\"firmId\":\"NBIN\",\"isFirmScope\":true,\"creationDate\":[2026,10,8,13,14,15,120000000]}";
    Type type = columnType(AuditLogEvent.class, "record");

    assertEquals(json, formatMapper.toString(user, type));
    assertEquals(user, formatMapper.fromString(json, type));
  }

  @Test
  void shouldWriteATemplateAsTheSpringBoot3LineDid() throws NoSuchFieldException {
    String json =
        "{\"fileSize\":0,\"fileFormat\":null,\"batchSize\":0,\"delimiter\":null,\"retention\":0,"
            + "\"headerNames\":null,\"fields\":null}";

    assertEquals(
        json, formatMapper.toString(new Template(), columnType(BulkUploadTemplate.class, "config")));
  }

  @Test
  void shouldReadNullPrimitivesAndUnknownPropertiesAsTheSpringBoot3LineDid()
      throws NoSuchFieldException {
    Template expected = new Template();
    expected.setFileFormat("csv");

    Template template =
        formatMapper.fromString(
            "{\"fileSize\":null,\"batchSize\":null,\"retention\":null,\"fileFormat\":\"csv\","
                + "\"unknown\":1}",
            columnType(BulkUploadTemplate.class, "config"));

    assertEquals(expected, template);
  }

  @Test
  void shouldMapPreferencesAsTheSpringBoot3LineDid() throws NoSuchFieldException {
    Map<String, String> preferences = new LinkedHashMap<>();
    preferences.put("b", "2");
    preferences.put("a", "1");
    preferences.put("n", null);
    String json = "{\"b\":\"2\",\"a\":\"1\",\"n\":null}";
    Type type = columnType(Firm.class, "firmPreferences");

    assertEquals(json, formatMapper.toString(preferences, type));
    assertEquals(preferences, formatMapper.fromString(json, type));
  }

  private static Type columnType(Class<?> entity, String field) throws NoSuchFieldException {
    return entity.getDeclaredField(field).getGenericType();
  }
}
