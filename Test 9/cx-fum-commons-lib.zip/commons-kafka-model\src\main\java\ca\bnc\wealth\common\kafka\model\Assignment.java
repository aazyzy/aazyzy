package ca.bnc.wealth.common.kafka.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Assignment {

  @JsonProperty("assignment_id")
  Integer assignmentId;

  @JsonProperty("selected")
  Boolean selected;
}
