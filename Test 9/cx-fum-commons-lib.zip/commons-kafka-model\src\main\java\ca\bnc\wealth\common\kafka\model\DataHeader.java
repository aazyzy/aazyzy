package ca.bnc.wealth.common.kafka.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class DataHeader {

  @JsonProperty("ref_id")
  String refId;

  @JsonProperty("action")
  String action;
}
