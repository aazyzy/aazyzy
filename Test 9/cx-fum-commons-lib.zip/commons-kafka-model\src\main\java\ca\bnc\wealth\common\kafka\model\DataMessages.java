package ca.bnc.wealth.common.kafka.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class DataMessages <T extends EventPayLoad> {

  @JsonProperty("header")
  DataHeader header;

  @JsonProperty("payload")
  T payload;
}
