package ca.bnc.wealth.common.kafka.model;

import lombok.Data;

@Data
public class EventMessages<T extends EventPayLoad> {

  Header header;
  Source source;
  T payload;
}
