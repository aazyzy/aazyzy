package ca.bnc.wealth.common.kafka.model;

public interface EventPayLoad {

}
