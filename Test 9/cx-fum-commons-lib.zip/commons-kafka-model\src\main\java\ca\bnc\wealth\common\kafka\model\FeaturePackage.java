package ca.bnc.wealth.common.kafka.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class FeaturePackage {

  @JsonProperty("package_template_id")
  Integer packageTemplateId;

  @JsonProperty("assignments")
  List<Assignment> assignments = new ArrayList<>();
}
