package ca.bnc.wealth.common.kafka.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Header {

  String id;
  @JsonProperty("ref_id")
  String refId;
  String action;
  String state;
  String reason;
  String version;
  Tags tags;
}
