package ca.bnc.wealth.common.kafka.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Date;
import lombok.Data;

@Data
public class Publisher {

  String system;
  @JsonProperty("nbc_id")
  String nbcId;
  Date time;
}
