package ca.bnc.wealth.common.kafka.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class RrCodeRanges {

  @JsonProperty("from_rr_code")
  String fromRRCode;

  @JsonProperty("to_rr_code")
  String toRRCode;
}
