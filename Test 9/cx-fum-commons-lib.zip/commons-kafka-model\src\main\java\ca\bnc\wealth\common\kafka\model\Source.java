package ca.bnc.wealth.common.kafka.model;

import lombok.Data;

@Data
public class Source {

  Origin origin;
  Publisher publisher;
}
