package ca.bnc.wealth.common.kafka.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Tags {

  @JsonProperty("compassR2-id")
  String compassR2Id;
  @JsonProperty("change-set")
  String changeSet;
}