package ca.bnc.wealth.common.kafka.model.audit;

import ca.bnc.wealth.common.kafka.model.EventPayLoad;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import lombok.Data;

@Data
public class AuditUserConfigPayLoad implements EventPayLoad {

  private String type;

  private UserConfiguration userConfigurationBefore;
  private UserConfiguration userConfigurationAfter;

}
