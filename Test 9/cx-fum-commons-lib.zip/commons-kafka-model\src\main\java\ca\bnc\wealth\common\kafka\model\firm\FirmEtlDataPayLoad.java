package ca.bnc.wealth.common.kafka.model.firm;

import ca.bnc.wealth.common.kafka.model.EventPayLoad;
import ca.bnc.wealth.common.kafka.model.RrCodeRanges;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class FirmEtlDataPayLoad implements EventPayLoad {

  @JsonProperty("msg_type")
  String msgType;

  @JsonProperty("firm_id")
  String firmId;

  @JsonProperty("firm_name")
  String firmName;

  String active;

  @JsonProperty("firm_status")
  String firmStatus;

  @JsonProperty("broker_code")
  String brokerCode;

  @JsonProperty("broker_no")
  String brokerNo;

  @JsonProperty("branch_no")
  String branchNo;

  @JsonProperty("firm_type")
  String firmType;

  @JsonProperty("parent_firm_id")
  String parentFirmId;

  @JsonProperty("firm_display_name_en")
  String firmDisplayNameEn;

  @JsonProperty("firm_display_name_fr")
  String firmDisplayNameFr;

  Integer financialLegalEntityId;

  @JsonProperty("rr_code_ranges")
  List<RrCodeRanges> rrCodeRanges = new ArrayList<>();
}
