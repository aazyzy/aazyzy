package ca.bnc.wealth.common.kafka.model.firm;

import ca.bnc.wealth.common.kafka.model.EventPayLoad;
import lombok.Data;

@Data
public class FirmEtlEventPayLoad implements EventPayLoad {

  String firmId;
}
