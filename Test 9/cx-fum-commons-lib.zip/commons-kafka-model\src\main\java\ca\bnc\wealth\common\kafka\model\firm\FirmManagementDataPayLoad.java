package ca.bnc.wealth.common.kafka.model.firm;

import ca.bnc.wealth.common.kafka.model.EventPayLoad;
import ca.bnc.wealth.common.kafka.model.FeaturePackage;
import ca.bnc.wealth.common.kafka.model.RrCodeRanges;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class FirmManagementDataPayLoad implements EventPayLoad {

  @JsonProperty("firm_id")
  String firmId;

  @JsonProperty("broker_code")
  String brokerCode;

  @JsonProperty("b_number")
  String branchNumber;

  @JsonProperty("dealer_code")
  String dealerCode;

  @JsonProperty("legal_entity_identifier")
  String legalEntityIdentifier;

  @JsonProperty("name")
  String name;

  @JsonProperty("type")
  String type;

  @JsonProperty("description")
  String description;

  @JsonProperty("parent_firm_id")
  String parentFirmId;

  @JsonProperty("firm_display_name_en")
  String firmDisplayNameEn;

  @JsonProperty("firm_display_name_fr")
  String firmDisplayNameFr;

  @JsonProperty("preferred_language")
  String preferredLanguage;

  @JsonProperty("rr_code_ranges")
  List<RrCodeRanges> rrCodeRanges = new ArrayList<>();

  @JsonProperty("feature_package")
  FeaturePackage featurePackage;
}
