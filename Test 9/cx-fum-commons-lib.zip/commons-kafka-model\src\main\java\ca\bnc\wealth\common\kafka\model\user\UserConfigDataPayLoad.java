package ca.bnc.wealth.common.kafka.model.user;

import ca.bnc.wealth.common.kafka.model.EventPayLoad;
import ca.bnc.wealth.common.kafka.model.RrCodeRanges;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;

@Data
public class UserConfigDataPayLoad implements EventPayLoad {

  @JsonProperty("msg_type")
  String messageType;
  String id;
  @JsonProperty("rr_code_ranges")
  List<RrCodeRanges> rrCodeRanges = new ArrayList<>();
}
