package ca.bnc.wealth.common.kafka.model.user;

import ca.bnc.wealth.common.kafka.model.EventPayLoad;
import java.util.Date;
import lombok.Data;

@Data
public class UserConfigEventPayLoad implements EventPayLoad {

  String type;
  String id;
  Date activationDate;
}
