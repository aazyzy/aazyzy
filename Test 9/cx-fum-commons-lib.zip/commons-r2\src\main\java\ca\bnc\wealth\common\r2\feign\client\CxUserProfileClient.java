package ca.bnc.wealth.common.r2.feign.client;

import ca.bnc.wealth.common.r2.model.R2UserProfile;
import java.util.List;
import java.util.Map;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(url = "${feign.r2Api.url}")
public interface CxUserProfileClient {

  @RequestMapping(path = "cxr2/v1/user-config/{cxUserId}/get", method = RequestMethod.GET)
  ResponseEntity<String> getR2UserProfile(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestHeader(name = "businessViewId") String businessViewId,
      @PathVariable String cxUserId);

  @RequestMapping(path = "cxr2/v1/user-config/r2IdGet", method = RequestMethod.POST)
  ResponseEntity<Map<String, String>> getCxR2UserMap(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestBody List<String> idpSubjects);


  @RequestMapping(path = "cxr2/v1/user-config/r2UserGet", method = RequestMethod.POST)
  ResponseEntity<Map<String, R2UserProfile>> getR2UserProfiles(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestBody List<String> idpSubjects);
}
