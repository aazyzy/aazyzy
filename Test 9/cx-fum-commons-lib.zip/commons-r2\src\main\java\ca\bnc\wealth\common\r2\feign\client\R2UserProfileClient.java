package ca.bnc.wealth.common.r2.feign.client;

import ca.bnc.wealth.common.r2.model.R2UserProfile;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(url = "${feign.r2Api.url}")
public interface R2UserProfileClient {

  @RequestMapping(
      path = "cxr2/v1/user-config/validateR2UserId/{r2UserId}",
      method = RequestMethod.GET)
  R2UserProfile getR2UserProfile(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestHeader(name = "businessViewId") String businessViewId,
      @PathVariable String r2UserId);
}
