package ca.bnc.wealth.common.r2.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class R2UserProfile {

  @JsonProperty("cx-user-id")
  private String cxUserId;

  @JsonProperty("user-id")
  private String userId;

  @JsonProperty("first-name")
  private String firstName;

  @JsonProperty("middle-name")
  private String middleName;

  @JsonProperty("last-name")
  private String lastName;

  @JsonProperty("email")
  private String email;

  @JsonProperty("broker-code")
  private String brokerCode;

  @JsonProperty("client-code")
  private String clientCode;

  @JsonProperty("rr-codes")
  private List<String> rrCodes;

  @JsonProperty("sub-advise-rr-codes")
  private List<String> subAdviseRrCodes;

  @JsonProperty("error")
  private String error;
}
