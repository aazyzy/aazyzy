package ca.bnc.wealth.common.report.feign.client;

import ca.bnc.wealth.common.report.model.ReportRequest;
import ca.bnc.wealth.common.report.model.S3Details;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@FeignClient(url = "${feign.reportApi.url}")
public interface ReportApiClient {

  @RequestMapping(path = "v2/reports", method = RequestMethod.POST, produces =  { "application/json" })
  ResponseEntity<List<S3Details>> getS3Details(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestBody ReportRequest reportRequest);

  @RequestMapping(path = "v2/reports?download=true", method = RequestMethod.POST, produces =  { "application/octet-stream", "application/json" })
  ResponseEntity<ByteArrayResource> download(@RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestBody ReportRequest reportRequest);
}
