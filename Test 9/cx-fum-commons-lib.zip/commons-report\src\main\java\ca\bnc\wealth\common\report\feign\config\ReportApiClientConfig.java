package ca.bnc.wealth.common.report.feign.config;

import ca.bnc.wealth.api.authorization.feign.config.FeignCodecs;
import ca.bnc.wealth.common.report.feign.client.ReportApiClient;
import feign.Feign;
import feign.Logger;
import feign.Util;
import feign.codec.Decoder;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.util.StreamUtils;
import tools.jackson.databind.JavaType;
import tools.jackson.databind.cfg.DateTimeFeature;
import tools.jackson.databind.json.JsonMapper;

@Configuration
@EnableFeignClients
@Slf4j
public class ReportApiClientConfig {

  // Jackson 2 defaults: what the Spring Boot 3 line's new ObjectMapper() with JavaTimeModule read
  private static final JsonMapper DECODER_MAPPER =
      JsonMapper.builderWithJackson2Defaults()
          .disable(DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS)
          .build();

  @Value("${feign.reportApi.url:#{null}}")
  private String reportApiUrl;

  @Bean
  public ReportApiClient getReportApiClient(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .decoder(new ResponseEntityDecoder(getResponseEntityDecoder()))
        .logger(new Slf4jLogger(ReportApiClient.class))
        .logLevel(Logger.Level.BASIC)
        .target(ReportApiClient.class, reportApiUrl);
  }

  public Decoder getResponseEntityDecoder() {
    return (response, type) -> {

      if (type instanceof Class && ByteArrayResource.class.isAssignableFrom((Class) type)) {
        return new ByteArrayResource(StreamUtils.copyToByteArray(response.body().asInputStream()));
      }
      String bodyStr = Util.toString(response.body().asReader(Util.UTF_8));
      JavaType javaType = DECODER_MAPPER.getTypeFactory().constructType(type);
      return DECODER_MAPPER.readValue(bodyStr, javaType);
    };
  }
}
