package ca.bnc.wealth.common.report.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import java.util.Map;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ReportRequest {
  @JsonProperty("object")
  private String _object;

  @JsonProperty("function")
  private String function;

  @JsonProperty("additionalCriteria")
  @Valid
  private Map<String, String> additionalCriteria = null;
}
