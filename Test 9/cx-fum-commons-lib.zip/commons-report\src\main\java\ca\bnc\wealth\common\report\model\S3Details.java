package ca.bnc.wealth.common.report.model;

import java.time.LocalDateTime;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class S3Details {
  private String s3Uri;
  private LocalDateTime lastUpdated;
  private String versionId;
}

