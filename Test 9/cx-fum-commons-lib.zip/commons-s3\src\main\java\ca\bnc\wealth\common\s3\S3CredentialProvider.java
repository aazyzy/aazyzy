package ca.bnc.wealth.common.s3;

import lombok.AllArgsConstructor;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;

@AllArgsConstructor
public class S3CredentialProvider implements AwsCredentialsProvider {

    private String accessKeyId;

    private String secretAccessKey;


    @Override
    public AwsCredentials resolveCredentials() {
        return AwsBasicCredentials.create(accessKeyId, secretAccessKey);
    }
}
