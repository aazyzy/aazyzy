package ca.bnc.wealth.common.s3;

import software.amazon.awssdk.regions.Region;

public interface S3PropertyInterface {

    String getS3AccessFor();

    Region getS3Region();

    String getS3AccessKeyId();

    String getS3SecretAccessKey();
}
