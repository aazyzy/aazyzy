package ca.bnc.wealth.common.s3;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.core.sync.ResponseTransformer;
import software.amazon.awssdk.services.s3.S3AsyncClient;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Request.Builder;
import software.amazon.awssdk.services.s3.paginators.ListObjectsV2Iterable;
import software.amazon.awssdk.transfer.s3.S3TransferManager;

@Slf4j
@Service
public class S3Service {

  public static final byte[] CSV_BOM_HEADER_BYTE = new byte[] {(byte) 0xEF, (byte) 0xBB, (byte) 0xBF};

  @Autowired private ConfigurableListableBeanFactory beanFactory;

  Map<String, S3PropertyInterface> propertieInterfaceMap = new HashMap<>();

  Map<String, S3TransferManager> s3TransferManagerMap = new HashMap<>();

  Map<String, S3Client> s3ClientMap = new HashMap<>();

  @EventListener(ApplicationReadyEvent.class)
  public void init() {
    beanFactory
        .getBeansOfType(S3PropertyInterface.class)
        .forEach((k, v) -> propertieInterfaceMap.put(v.getS3AccessFor(), v));
    propertieInterfaceMap.forEach(
        (k, v) -> {
          S3CredentialProvider s3CredentialProvider =
              new S3CredentialProvider(v.getS3AccessKeyId(), v.getS3SecretAccessKey());

          S3AsyncClient s3AsyncClient =
              S3AsyncClient.crtBuilder()
                  .credentialsProvider(s3CredentialProvider)
                  .region(v.getS3Region())
                  .build();

          S3TransferManager transferManager =
              S3TransferManager.builder().s3Client(s3AsyncClient).build();

          s3TransferManagerMap.put(v.getS3AccessFor(), transferManager);

          S3Client s3Client =
              S3Client.builder()
                  .region(v.getS3Region())
                  .credentialsProvider(s3CredentialProvider)
                  .build();
          s3ClientMap.put(v.getS3AccessFor(), s3Client);
        });
  }

  public byte[] download(String accessFor, String s3Uri) {
    Pair<String, String> parsed = parseS3Uri(s3Uri);
    return download(accessFor, parsed.getLeft(), parsed.getRight());
  }

  @SneakyThrows
  public byte[] download(String accessFor, String bucket, String key) {
    S3Client s3Client = s3ClientMap.get(accessFor);
    Optional.ofNullable(s3Client)
        .orElseThrow(() -> new Exception("S3PropertieInterface not defined for: " + accessFor));

    GetObjectRequest getObjectRequest = GetObjectRequest.builder().bucket(bucket).key(key).build();

    ResponseBytes<GetObjectResponse> s3Object =
        s3Client.getObject(getObjectRequest, ResponseTransformer.toBytes());

    return s3Object.asByteArray();
  }

  @SneakyThrows
  public String upload(String accessFor, String bucket, String keyPrefix, MultipartFile fileToUpload, boolean uploadWithOriginalName) {
    S3Client s3Client = s3ClientMap.get(accessFor);
    Optional.ofNullable(s3Client)
        .orElseThrow(() -> new Exception("S3PropertieInterface not defined for: " + accessFor));

    byte[] bytes = fileToUpload.getBytes();

    String fileName = uploadWithOriginalName ? fileToUpload.getOriginalFilename() : UUID.randomUUID().toString();

    String key =
        StringUtils.isNotBlank(keyPrefix)
            ? keyPrefix + "/" + fileName
            : fileName;

    PutObjectRequest putObjectRequest =
        PutObjectRequest.builder()
            .bucket(bucket)
            .key(key)
            .contentLength((long) bytes.length)
            .build();

    s3Client.putObject(putObjectRequest, RequestBody.fromByteBuffer(ByteBuffer.wrap(bytes)));

    return "s3://" + bucket + "/" + key;
  }

  @SneakyThrows
  public String uploadWithCsvBom(String accessFor, String bucket, String keyPrefix, String fileName, String fileContent) {
    S3Client s3Client = s3ClientMap.get(accessFor);
    Optional.ofNullable(s3Client)
        .orElseThrow(() -> new Exception("S3PropertieInterface not defined for: " + accessFor));
    log.info("Uploading file to S3: bucket={}, keyPrefix={}, fileName={}", bucket, keyPrefix, fileName);
    byte[] bytes = getCsvBomByteArray(fileContent);

    String key =
        StringUtils.isNotBlank(keyPrefix)
            ? keyPrefix + "/" + fileName
            : fileName;

    PutObjectRequest putObjectRequest =
        PutObjectRequest.builder()
            .bucket(bucket)
            .key(key)
            .contentLength((long) bytes.length)
            .build();

    s3Client.putObject(putObjectRequest, RequestBody.fromByteBuffer(ByteBuffer.wrap(bytes)));

    return "s3://" + bucket + "/" + key;
  }

  @SneakyThrows
  public String upload(String accessFor, String bucket, String keyPrefix, String fileName, String fileContent) {
    S3Client s3Client = s3ClientMap.get(accessFor);
    Optional.ofNullable(s3Client)
        .orElseThrow(() -> new Exception("S3PropertieInterface not defined for: " + accessFor));
    log.info("Uploading file to S3: bucket={}, keyPrefix={}, fileName={}", bucket, keyPrefix, fileName);
    byte[] bytes = fileContent.getBytes();

    String key =
        StringUtils.isNotBlank(keyPrefix)
            ? keyPrefix + "/" + fileName
            : fileName;

    PutObjectRequest putObjectRequest =
        PutObjectRequest.builder()
            .bucket(bucket)
            .key(key)
            .contentLength((long) bytes.length)
            .build();

    s3Client.putObject(putObjectRequest, RequestBody.fromByteBuffer(ByteBuffer.wrap(bytes)));

    return "s3://" + bucket + "/" + key;
  }

  @SneakyThrows
  public Pair<String, String> getVersionAfterUpload(String accessFor, String bucket, String keyPrefix, String fileName, String fileContent) {
    S3Client s3Client = s3ClientMap.get(accessFor);
    Optional.ofNullable(s3Client)
        .orElseThrow(() -> new Exception("S3PropertieInterface not defined for: " + accessFor));
    log.info("Uploading file to S3: bucket={}, keyPrefix={}, fileName={}", bucket, keyPrefix, fileName);
    byte[] bytes = fileContent.getBytes();

    String key =
        StringUtils.isNotBlank(keyPrefix)
            ? keyPrefix + "/" + fileName
            : fileName;

    PutObjectRequest putObjectRequest =
        PutObjectRequest.builder()
            .bucket(bucket)
            .key(key)
            .contentLength((long) bytes.length)
            .build();

    PutObjectResponse response = s3Client.putObject(putObjectRequest, RequestBody.fromByteBuffer(ByteBuffer.wrap(bytes)));

    return Pair.of("s3://" + bucket + "/" + key, response.versionId());
  }

  @SneakyThrows
  public List<S3Object> getListOfS3Objects(String accessFor, String bucket, String prefix) {
    S3Client s3Client = s3ClientMap.get(accessFor);
    Optional.ofNullable(s3Client)
        .orElseThrow(() -> new Exception("S3PropertieInterface not defined for: " + accessFor));

    Builder ListObjectsV2RequestBuilder = ListObjectsV2Request.builder().bucket(bucket);
    if(StringUtils.isNotBlank(prefix)) {
      ListObjectsV2RequestBuilder.prefix(prefix);
    }
    ListObjectsV2Request listObjectsV2Request = ListObjectsV2RequestBuilder.build();
    ListObjectsV2Iterable listRes = s3Client.listObjectsV2Paginator(listObjectsV2Request);

    return listRes.stream()
        .flatMap(r -> r.contents().stream())
        .toList();
  }

  @SneakyThrows
  public void deleteS3Object(String accessFor, String bucker, List<String> s3ObjectKeys) {
    S3Client s3Client = s3ClientMap.get(accessFor);
    ArrayList<ObjectIdentifier> objectIdentifiers = new ArrayList<>();
    s3ObjectKeys.forEach(key -> objectIdentifiers.add(ObjectIdentifier.builder().key(key).build()));

    Delete del = Delete.builder()
        .objects(objectIdentifiers)
        .build();

    DeleteObjectsRequest multiObjectDeleteRequest = DeleteObjectsRequest.builder()
        .bucket(bucker)
        .delete(del)
        .build();

    s3Client.deleteObjects(multiObjectDeleteRequest);
  }

  @SneakyThrows
  public String copyS3Object(String accessFor, String sourceS3Uri, String sourceVersion, String destinationBucket, String destinationKey) {
    Pair<String, String> source = parseS3Uri(sourceS3Uri);
    return copyS3Object(accessFor, source.getLeft(), source.getRight(), sourceVersion, destinationBucket, destinationKey);
  }

  @SneakyThrows
  public String copyS3Object(String accessFor, String sourceS3Uri, String sourceVersion, String destinationS3Uri) {
    Pair<String, String> source = parseS3Uri(sourceS3Uri);
    Pair<String, String> destination = parseS3Uri(destinationS3Uri);
    return copyS3Object(accessFor, source.getLeft(), source.getRight(), sourceVersion, destination.getLeft(), destination.getRight());
  }

  @SneakyThrows
  public String copyS3Object(String accessFor, String sourceBucket, String sourceKey, String sourceVersion, String destinationBucket, String destinationKey) {
    S3Client s3Client = s3ClientMap.get(accessFor);
    Optional.ofNullable(s3Client)
        .orElseThrow(() -> new Exception("S3PropertieInterface not defined for: " + accessFor));

    CopyObjectRequest copyObjRequest = CopyObjectRequest.builder()
        .sourceBucket(sourceBucket)
        .sourceKey(sourceKey)
        .destinationBucket(destinationBucket)
        .destinationKey(destinationKey)
        .build();
    if(StringUtils.isNotBlank(sourceVersion))
      copyObjRequest = copyObjRequest.toBuilder().sourceVersionId(sourceVersion).build();

    return s3Client.copyObject(copyObjRequest).versionId();
  }

  private Pair<String, String> parseS3Uri(String s3Uri) {
    String noScheme = s3Uri.substring(5);
    int idx = noScheme.indexOf('/');
    return Pair.of(noScheme.substring(0, idx), noScheme.substring(idx + 1));
  }

  private byte[] getCsvBomByteArray(String fileContent) {
    byte[] contentBytes = fileContent.getBytes(StandardCharsets.UTF_8);
    byte[] csvByteArray = new byte[CSV_BOM_HEADER_BYTE.length + contentBytes.length];
    System.arraycopy(CSV_BOM_HEADER_BYTE, 0, csvByteArray, 0, CSV_BOM_HEADER_BYTE.length);
    System.arraycopy(contentBytes, 0, csvByteArray, CSV_BOM_HEADER_BYTE.length, contentBytes.length);
    return csvByteArray;
  }
}
