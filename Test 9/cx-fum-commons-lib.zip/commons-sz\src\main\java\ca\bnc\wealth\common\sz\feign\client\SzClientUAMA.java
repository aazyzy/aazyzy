package ca.bnc.wealth.common.sz.feign.client;

import ca.bnc.wealth.common.sz.model.SzUser;
import ca.bnc.wealth.common.sz.model.SzUserSearch;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(url = "${feign.szApi.url}")
public interface SzClientUAMA {

  @PatchMapping(path = "user-access-management/Users/{szId}/{idpSubject}/{userType}")
  ResponseEntity<String> assignUsernameToSzId(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @PathVariable String szId,
      @PathVariable String idpSubject,
      @PathVariable String userType);

  @PutMapping(path = "user-access-management/Users/{szId}")
  ResponseEntity<String> updateUser(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @PathVariable String szId,
      @RequestBody SzUser szUser);

  @GetMapping(path = "user-access-management/Users/{szId}")
  ResponseEntity<SzUser> getUser(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @PathVariable String szId);

  @GetMapping(path = "user-access-management/Users")
  ResponseEntity<SzUserSearch> searchUsers(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestParam("filter") String filter);
}
