package ca.bnc.wealth.common.sz.feign.config;

import ca.bnc.wealth.api.authorization.feign.config.FeignCodecs;
import ca.bnc.wealth.common.sz.feign.client.SzClientUAMA;
import feign.Feign;
import feign.Logger;
import feign.Util;
import feign.codec.Decoder;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tools.jackson.databind.JavaType;
import tools.jackson.databind.cfg.DateTimeFeature;
import tools.jackson.databind.json.JsonMapper;

@Configuration
@EnableFeignClients
@Slf4j
public class SzFeignClientConfigUAMA {

  // Jackson 2 defaults: what the Spring Boot 3 line's new ObjectMapper() with JavaTimeModule read
  private static final JsonMapper DECODER_MAPPER =
      JsonMapper.builderWithJackson2Defaults()
          .disable(DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS)
          .build();

  @Value("${feign.szApi.url:#{null}}")
  private String szApiUrl;

  @Bean
  public SzClientUAMA getSzUserClient(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .dismiss404()
        .decoder(new ResponseEntityDecoder(getResponseDecoder()))
        .logger(new Slf4jLogger(SzClientUAMA.class))
        .logLevel(Logger.Level.BASIC)
        .target(SzClientUAMA.class, szApiUrl);
  }

  private Decoder getResponseDecoder() {
    return (response, type) -> {
      if (response.body() != null) {
        String bodyStr = Util.toString(response.body().asReader(Util.UTF_8));
        if(type == String.class)
          return bodyStr;
        JavaType javaType = DECODER_MAPPER.getTypeFactory().constructType(type);
        return DECODER_MAPPER.readValue(bodyStr, javaType);
      }
      return null;
    };
  }
}
