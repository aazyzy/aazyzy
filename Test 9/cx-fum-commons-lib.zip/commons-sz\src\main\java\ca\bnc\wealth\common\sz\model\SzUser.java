package ca.bnc.wealth.common.sz.model;

import java.util.List;
import lombok.Data;

@Data
public class SzUser {

  private boolean active;
  private String userName;
  private String familyName;
  private String givenName;
  private String externalId;
  private String userType;
  private String preferredLanguage;
  private List<String> groups;
  private String empId;
  private String id;
}
