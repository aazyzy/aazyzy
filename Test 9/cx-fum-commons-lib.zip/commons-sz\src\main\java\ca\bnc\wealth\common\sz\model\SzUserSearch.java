package ca.bnc.wealth.common.sz.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Data;

@Data
public class SzUserSearch {

  private int startIndex;
  private int pageResults;
  private int totalResults;

  @JsonProperty("Resources")
  private List<SzUser> resources;
}
