# Changelog

## [3.0.1](https://github.com/NBC-GPMF/cx-fum-commons-library/compare/v3.0.0...v3.0.1) (2026-11-02)


### Miscellaneous Chores

* move to parent-pom-core 3.0.1, which fixes the Snyk findings of the 5.0.0 release: Tomcat 11.0.27, Jackson 3.2.4 and 2.22.4, Hibernate Validator 9.1.6.Final and java-jwt 4.6.2

## [3.0.0](https://github.com/NBC-GPMF/cx-fum-commons-library/compare/v2.1.42...v3.0.0) (2026-10-29)


### Miscellaneous Chores

* freeze the common-schema search models in commons-core ([#48](https://github.com/NBC-GPMF/cx-fum-commons-library/pull/48)) ([afffadb](https://github.com/NBC-GPMF/cx-fum-commons-library/commit/afffadbd6f1b3b7456243e2b6f6ffd9498c47ced))
* move the Spring Boot 4 line into develop as 3.0.0-SNAPSHOT ([#46](https://github.com/NBC-GPMF/cx-fum-commons-library/pull/46)) ([dd3b371](https://github.com/NBC-GPMF/cx-fum-commons-library/commit/dd3b371fafe369578a409305fa777b7e96ced130))
* skip the SonarQube analysis for now ([#47](https://github.com/NBC-GPMF/cx-fum-commons-library/pull/47)) ([0b8f00c](https://github.com/NBC-GPMF/cx-fum-commons-library/commit/0b8f00ca29ef97794cdc6f10ee2ca5278958f238))
* sync 6900 dependency versions to develop SNAPSHOTs ([a59eefe](https://github.com/NBC-GPMF/cx-fum-commons-library/commit/a59eefe19f9bb29f85cc98b178f5b3a84ef7ae3b))

## [2.1.42](https://github.com/NBC-GPMF/cx-fum-commons-library/compare/v2.1.41...v2.1.42) (2026-10-14)


### Miscellaneous Chores

* NWPI-15097 reject employee tokens of inactive CX profiles ([150921a](https://github.com/NBC-GPMF/cx-fum-commons-library/commit/150921a4ee001e96a79ea3b42515864aa70900cc))
* pin released 6900 dependency versions for release 4.0.0 ([38bdfb8](https://github.com/NBC-GPMF/cx-fum-commons-library/commit/38bdfb874f16dbd5a2c5659e5c7c1146a7656601))

## [2.1.41](https://github.com/NBC-GPMF/cx-fum-commons-library/compare/v2.1.40...v2.1.41) (2026-09-15)


### Miscellaneous Chores

* pin released 6900 dependency versions for release 3.2.0 ([4bb709d](https://github.com/NBC-GPMF/cx-fum-commons-library/commit/4bb709da950be977ce14d1ca592ef05247d239be))

## [2.1.40](https://github.com/NBC-GPMF/cx-fum-commons-library/compare/v2.1.39...v2.1.40) (2026-09-15)


### Bug Fixes

* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([010a905](https://github.com/NBC-GPMF/cx-fum-commons-library/commit/010a9058d571e7438ad198e5f8d20783169856b2))
* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([49448f7](https://github.com/NBC-GPMF/cx-fum-commons-library/commit/49448f7f154f0904a9db8912a3639d7318737aad))

## [2.1.39](https://github.com/NBC-GPMF/cx-fum-commons-library/compare/v2.1.38...v2.1.39) (2026-08-19)


### Bug Fixes

* **deps:** pin tomcat-embed 10.1.56 and logback-core 1.5.36 (Snyk HIGH) ([#17](https://github.com/NBC-GPMF/cx-fum-commons-library/issues/17)) ([abd92e2](https://github.com/NBC-GPMF/cx-fum-commons-library/commit/abd92e27ae88076f0116392aaa0ca87c2f9192a4))
* **deps:** pin vulnerable transitive dependencies for Snyk remediation ([#22](https://github.com/NBC-GPMF/cx-fum-commons-library/issues/22)) ([0a97b8d](https://github.com/NBC-GPMF/cx-fum-commons-library/commit/0a97b8dcb6e400db920515f0164201e2f706cc19))

## [2.1.38](https://github.com/NBC-GPMF/cx-fum-commons-library/compare/v2.1.37...v2.1.38) (2026-06-29)


### Bug Fixes

* release 2.2.1 ([b7bfd11](https://github.com/NBC-GPMF/cx-fum-commons-library/commit/b7bfd112fe23964c8df8b19ae0f026371d867f7d))

## [2.1.37](https://github.com/NBC-GPMF/cx-fum-commons-library/compare/v2.1.36...v2.1.37) (2026-06-10)


### Bug Fixes

* first github release ([f9a5129](https://github.com/NBC-GPMF/cx-fum-commons-library/commit/f9a51293346edc0eb3c69c3c50100a4d8636ef13))
