# commons-lib

## Introduction
This is a common library used by all components
* It should contain shared code across all microservices
* It should NOT contain domain-specific code (e.g. common Order code should go in order-commons-lib)

## What's included?
- Core - Shared enums, constants, utils
- Authentication - Auth filters (To be built)
- Database Unique Identifier generator for Postgres DB configured by your app.

## How to use it

### Add Pom Dependency
Add the module dependencies in your project pom.xml, depending on which module(s) are needed.
Note - versions are managed centrally in parent-pom hence should be set in parent-pom instead of microservice

```yaml
<dependency>
  <groupId>ca.nbc.gpmf.cx-fum-commons-library</groupId>
  <artifactId>commons-lib</artifactId>
</dependency>
```
#### Postgres ID Generator
1. Please ensure that an instance of *org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate* is configured in your applicaton context, with a name qualifier of *postgresJdbcTemplate*.
2. Next please scan the package *ca.bnc.wealth.common.id*
3. Inject the *IdGeneratorService* and invoke *generateID()* passing the name of the sequence to it, from which you want the identifier to be generated.

#### we noticed v2.1.37 tag and artifact are missing from the repository*****
### so we rolled back the pom version from 2.1.38-SNAPSHOT to 2.1.37-SNAPSHOT, And created a dummy release with 2.1.37 tag and brought back main branch pom version to 2.1.38-SNAPSHOT, 



