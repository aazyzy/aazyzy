# Branch Cleanup Report: commons-lib #

Generated: 2026-06-09 15:00:04
Default Branch: develop
Total Branches: 36

---

## Summary

- Total Branches: 36
- Excluded from Deletion: 0
- Marked for Deletion: 36

---

## All Branches

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `master` | 2021-04-14 09:40:16 -0400 | 2021-04-14 09:40:16 -0400 | MERGED |
| `release/2.0.19` | 2023-12-06 15:36:42 -0500 | 2023-12-06 15:36:42 -0500 | MERGED |
| `feature/NOT-17247` | 2024-01-23 12:59:46 -0500 | 2024-01-23 12:59:46 -0500 | MERGED |
| `Task/NOT-17305` | 2024-02-07 14:00:26 -0500 | 2024-02-07 14:00:26 -0500 | MERGED |
| `snyk-fix-f826fef0761d9108bf6573900c2f8dbb` | 2024-02-21 11:09:10 -0500 | 2024-02-21 11:09:10 -0500 | MERGED |
| `release/1.15` | 2024-02-23 10:30:34 -0500 | 2024-02-23 10:30:34 -0500 | MERGED |
| `release/1.16` | 2024-03-12 16:21:35 -0400 | 2024-03-12 16:21:35 -0400 | MERGED |
| `feature/NBINPS-49` | 2024-03-26 17:19:27 -0400 | 2024-03-26 17:19:27 -0400 | MERGED |
| `feature/NBINPS-103` | 2024-04-01 12:28:37 -0400 | 2024-04-01 12:28:37 -0400 | MERGED |
| `feature/NBINPS-49-put` | 2024-04-10 23:10:07 -0400 | 2024-04-10 23:10:07 -0400 | MERGED |
| `release/1.16.2` | 2024-05-02 15:25:46 -0400 | 2024-05-02 15:25:46 -0400 | MERGED |
| `release/1.17` | 2024-05-14 16:42:14 -0400 | 2024-05-14 16:42:14 -0400 | MERGED |
| `release/1.18` | 2024-06-18 13:26:04 -0400 | 2024-06-18 13:26:04 -0400 | MERGED |
| `feature/scopePermissionInIstio` | 2024-08-16 13:19:00 -0400 | 2024-08-16 13:19:00 -0400 | MERGED |
| `snyk-fix-d3506ee7d17c2779da45d64c85c5d677` | 2024-10-22 12:51:10 -0400 | 2024-10-22 12:51:10 -0400 | MERGED |
| `release/1.20` | 2024-10-30 11:04:52 -0400 | 2024-10-30 11:04:52 -0400 | MERGED |
| `release/1.21.1` | 2025-01-07 14:46:52 -0500 | 2025-01-07 14:46:52 -0500 | MERGED |
| `release/1.21.4` | 2025-03-11 13:02:53 -0400 | 2025-03-11 13:02:53 -0400 | MERGED |
| `release/1.23.0` | 2025-04-17 17:15:34 -0400 | 2025-04-17 17:15:34 -0400 | MERGED |
| `release/1.24.0` | 2025-05-13 12:25:39 -0400 | 2025-05-13 12:25:39 -0400 | MERGED |
| `feature/NWPI-13171` | 2025-06-30 15:20:33 -0400 | 2025-06-30 15:20:33 -0400 | MERGED |
| `release/1.26.0` | 2025-07-11 16:59:14 -0400 | 2025-07-11 16:59:14 -0400 | MERGED |
| `feature/NWPI-13843-update-firm-assignments-endpoint-to-return-resources` | 2025-08-11 15:28:15 -0400 | 2025-08-11 15:28:15 -0400 | MERGED |
| `release/1.28.0` | 2025-10-29 13:25:58 -0400 | 2025-10-29 13:25:58 -0400 | MERGED |
| `feature/NWPI-14158-move-info-messages-to-debug-in-commons-auth-library` | 2025-11-19 14:24:54 -0500 | 2025-11-19 14:24:54 -0500 | MERGED |
| `feature/NWPI-14170-enhance-sorting-of-attestation-lists-back-end-afa4` | 2025-11-20 13:48:51 -0500 | 2025-11-20 13:48:51 -0500 | MERGED |
| `release/2.0.0` | 2025-11-20 13:48:51 -0500 | 2025-11-20 13:48:51 -0500 | MERGED |
| `feature/NWPI-14339-firm-attestation-list-is-taking-long-time-to-load-for-nbin-firm-part-2` | 2026-01-13 14:37:34 -0500 | 2026-01-13 14:37:34 -0500 | MERGED |
| `release/2.1.0` | 2026-01-13 14:37:34 -0500 | 2026-01-13 14:37:34 -0500 | MERGED |
| `snyk-fix-06e44e1cc510d9d89de54db282d4880b` | 2026-01-28 02:16:42 -0500 | 2026-01-28 02:16:42 -0500 | MERGED |
| `feature/NWPI-14340-create-attestation-api-for-all-firms-never-finish` | 2026-02-19 17:22:23 -0500 | 2026-02-19 17:22:23 -0500 | MERGED |
| `release/2.1.1` | 2026-03-06 11:39:21 -0500 | 2026-03-06 11:39:21 -0500 | MERGED |
| `feature/NWPI-14414-use-subscription-api-7461-for-web-socket-notifications-backend-changes-part-2` | 2026-03-26 08:12:32 -0400 | 2026-03-26 08:12:32 -0400 | MERGED |
| `release/2.1.1.0` | 2026-04-16 14:05:11 -0400 | 2026-04-16 14:05:11 -0400 | MERGED |
| `release/2.2.0` | 2026-04-30 12:08:14 -0400 | 2026-04-30 12:08:14 -0400 | MERGED |
| `fix/snyk-2026-05-09` | 2026-05-09 18:31:31 -0400 | 2026-05-09 18:31:31 -0400 | MERGED |

---

## Excluded from Deletion

Criteria: Unmerged branches with last commit less than 2 months old
Count: 0

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| No branches excluded | | | |

---

## Marked for Deletion

Criteria: All merged branches + unmerged branches with last commit older than 2 months
Count: 36

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `master` | 2021-04-14 09:40:16 -0400 | 2021-04-14 09:40:16 -0400 | MERGED |
| `release/2.0.19` | 2023-12-06 15:36:42 -0500 | 2023-12-06 15:36:42 -0500 | MERGED |
| `feature/NOT-17247` | 2024-01-23 12:59:46 -0500 | 2024-01-23 12:59:46 -0500 | MERGED |
| `Task/NOT-17305` | 2024-02-07 14:00:26 -0500 | 2024-02-07 14:00:26 -0500 | MERGED |
| `snyk-fix-f826fef0761d9108bf6573900c2f8dbb` | 2024-02-21 11:09:10 -0500 | 2024-02-21 11:09:10 -0500 | MERGED |
| `release/1.15` | 2024-02-23 10:30:34 -0500 | 2024-02-23 10:30:34 -0500 | MERGED |
| `release/1.16` | 2024-03-12 16:21:35 -0400 | 2024-03-12 16:21:35 -0400 | MERGED |
| `feature/NBINPS-49` | 2024-03-26 17:19:27 -0400 | 2024-03-26 17:19:27 -0400 | MERGED |
| `feature/NBINPS-103` | 2024-04-01 12:28:37 -0400 | 2024-04-01 12:28:37 -0400 | MERGED |
| `feature/NBINPS-49-put` | 2024-04-10 23:10:07 -0400 | 2024-04-10 23:10:07 -0400 | MERGED |
| `release/1.16.2` | 2024-05-02 15:25:46 -0400 | 2024-05-02 15:25:46 -0400 | MERGED |
| `release/1.17` | 2024-05-14 16:42:14 -0400 | 2024-05-14 16:42:14 -0400 | MERGED |
| `release/1.18` | 2024-06-18 13:26:04 -0400 | 2024-06-18 13:26:04 -0400 | MERGED |
| `feature/scopePermissionInIstio` | 2024-08-16 13:19:00 -0400 | 2024-08-16 13:19:00 -0400 | MERGED |
| `snyk-fix-d3506ee7d17c2779da45d64c85c5d677` | 2024-10-22 12:51:10 -0400 | 2024-10-22 12:51:10 -0400 | MERGED |
| `release/1.20` | 2024-10-30 11:04:52 -0400 | 2024-10-30 11:04:52 -0400 | MERGED |
| `release/1.21.1` | 2025-01-07 14:46:52 -0500 | 2025-01-07 14:46:52 -0500 | MERGED |
| `release/1.21.4` | 2025-03-11 13:02:53 -0400 | 2025-03-11 13:02:53 -0400 | MERGED |
| `release/1.23.0` | 2025-04-17 17:15:34 -0400 | 2025-04-17 17:15:34 -0400 | MERGED |
| `release/1.24.0` | 2025-05-13 12:25:39 -0400 | 2025-05-13 12:25:39 -0400 | MERGED |
| `feature/NWPI-13171` | 2025-06-30 15:20:33 -0400 | 2025-06-30 15:20:33 -0400 | MERGED |
| `release/1.26.0` | 2025-07-11 16:59:14 -0400 | 2025-07-11 16:59:14 -0400 | MERGED |
| `feature/NWPI-13843-update-firm-assignments-endpoint-to-return-resources` | 2025-08-11 15:28:15 -0400 | 2025-08-11 15:28:15 -0400 | MERGED |
| `release/1.28.0` | 2025-10-29 13:25:58 -0400 | 2025-10-29 13:25:58 -0400 | MERGED |
| `feature/NWPI-14158-move-info-messages-to-debug-in-commons-auth-library` | 2025-11-19 14:24:54 -0500 | 2025-11-19 14:24:54 -0500 | MERGED |
| `feature/NWPI-14170-enhance-sorting-of-attestation-lists-back-end-afa4` | 2025-11-20 13:48:51 -0500 | 2025-11-20 13:48:51 -0500 | MERGED |
| `release/2.0.0` | 2025-11-20 13:48:51 -0500 | 2025-11-20 13:48:51 -0500 | MERGED |
| `feature/NWPI-14339-firm-attestation-list-is-taking-long-time-to-load-for-nbin-firm-part-2` | 2026-01-13 14:37:34 -0500 | 2026-01-13 14:37:34 -0500 | MERGED |
| `release/2.1.0` | 2026-01-13 14:37:34 -0500 | 2026-01-13 14:37:34 -0500 | MERGED |
| `snyk-fix-06e44e1cc510d9d89de54db282d4880b` | 2026-01-28 02:16:42 -0500 | 2026-01-28 02:16:42 -0500 | MERGED |
| `feature/NWPI-14340-create-attestation-api-for-all-firms-never-finish` | 2026-02-19 17:22:23 -0500 | 2026-02-19 17:22:23 -0500 | MERGED |
| `release/2.1.1` | 2026-03-06 11:39:21 -0500 | 2026-03-06 11:39:21 -0500 | MERGED |
| `feature/NWPI-14414-use-subscription-api-7461-for-web-socket-notifications-backend-changes-part-2` | 2026-03-26 08:12:32 -0400 | 2026-03-26 08:12:32 -0400 | MERGED |
| `release/2.1.1.0` | 2026-04-16 14:05:11 -0400 | 2026-04-16 14:05:11 -0400 | MERGED |
| `release/2.2.0` | 2026-04-30 12:08:14 -0400 | 2026-04-30 12:08:14 -0400 | MERGED |
| `fix/snyk-2026-05-09` | 2026-05-09 18:31:31 -0400 | 2026-05-09 18:31:31 -0400 | MERGED |

---

## Deletion Results

Total Attempted: 36
Successfully Deleted: 35
Failed: 1
Skipped (Excluded Safety Gate): 0

### Failed Deletions

| Branch Name | Error |
|-------------|-------|
| `master` | Branch 'master' could not be deleted |
