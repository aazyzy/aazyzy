## Commons-auth

### Release Summary

##### v1.2.2-SNAPSHOT

    Moved the User model to store user's details that are linked to the access token from authorization-api schema.
    Added logic to enrich the User details from user-configuration api(secure zone id, ossid etc)

##### v1.2.3-SNAPSHOT

    Added system token request implementation

##### v1.2.4-SNAPSHOT

    Added system token scope validation filter 

##### v1.2.7-SNAPSHOT

    Fix for Swagger version change (AuthorizationScope annotation)
    Fix for providing secure zone id in test mode

##### v1.3.x-SNAPSHOT

    Support for scope validation in user and system tokens
    Support for permission validation based on api capability setup in IAM

##### v1.4.1-SNAPSHOT

    Added capabilty to selectively enable/disable scope and permission validations for user or system tokens
