package ca.bnc.wealth.api.authorization.enums;

public enum IdTokenEnum {
  SUB("sub"),
  BNGFIDENTITYSOURCE("bngfIdentitySource"),
  BNGFREFERENCEID("bngfReferenceId"),
  LOGIN("login"),
  FIRSTNAME("firstName"),
  LASTNAME("lastName"),
  EMAIL("email"),
  PREFERREDLANGUAGE("preferredLanguage"),
  UPDATEAT("updateAt");

  public final String tokenValue;

  IdTokenEnum(String tokenValue) {
    this.tokenValue = tokenValue;
  }
}
