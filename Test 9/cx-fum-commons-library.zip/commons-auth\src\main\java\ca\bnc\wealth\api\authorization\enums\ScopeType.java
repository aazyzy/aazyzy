package ca.bnc.wealth.api.authorization.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Getter
public enum ScopeType {
    PERMISSIONS("permissions"),
    ROLES("roles"),
    SYSTEM_ACCESS("system-access"),
    RESOURCES("resources"),
    UNKNOWN("unknown");

    private static final Map<String, ScopeType> map = new HashMap<>();
    private final String swaggerName;

    static {
        Arrays.stream(ScopeType.values()).forEach(scope -> map.put(scope.getSwaggerName(), scope));
    }

    ScopeType(String swaggerName) {
        this.swaggerName = swaggerName;
    }

    public static ScopeType getScopeType(String swaggerName) {
        return map.getOrDefault(swaggerName, ScopeType.UNKNOWN);
    }

}
