package ca.bnc.wealth.api.authorization.exception;

public class SystemTokenException extends RuntimeException {
  public SystemTokenException() {
    super();
  }

  public SystemTokenException(String message) {
    super(message);
  }
}
