package ca.bnc.wealth.api.authorization.feign.client;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

public interface FirmAPIClient {
  @RequestMapping(path = "/firms/assignments/users/me", method = RequestMethod.GET)
  ResponseEntity<Object> getUserFirmAssignments(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestParam(name = "assignment-type") String assignmentType);
}
