package ca.bnc.wealth.api.authorization.feign.client;

import ca.bnc.wealth.api.authorization.model.Resource;
import ca.bnc.wealth.api.authorization.model.ResourceData;
import ca.bnc.wealth.api.authorization.model.Role;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

public interface IamAPIClient {

  @RequestMapping(
      path = "/access-control/capabilities/{capability}/scopes/me",
      method = RequestMethod.GET)
  ResponseEntity<List<Role>> getRoles(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @PathVariable(value = "capability") String capability,
      @RequestParam(name = "assignments") boolean assignments);

  @RequestMapping(
      path = "/access-control/resources/{resource_type}/assignments/users/me",
      method = RequestMethod.GET)
  ResponseEntity<List<Resource>> getResources(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @PathVariable(value = "resource_type") String resourceType);

  @RequestMapping(
          path = "/access-control/resources/{resource-type}/assignments/firm/{rr-code}",
          method = RequestMethod.GET)
  ResponseEntity<List<ResourceData>> getResourceByResourceTypeAndRrCode(
          @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
          @PathVariable(value = "resource-type") String resourceType,
          @PathVariable(value = "rr-code") String rrCode);
}
