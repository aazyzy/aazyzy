package ca.bnc.wealth.api.authorization.feign.client;

import ca.bnc.wealth.api.authorization.model.SystemTokenRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/** Feign Client to download system token from okta */
public interface SystemTokenConfigClient {

  @RequestMapping(
      path = "",
      method = RequestMethod.POST,
      consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
  ResponseEntity<Object> getSystemToken(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authentication,
      SystemTokenRequest formData);
}
