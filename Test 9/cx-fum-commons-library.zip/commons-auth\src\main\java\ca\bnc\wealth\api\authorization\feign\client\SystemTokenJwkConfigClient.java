package ca.bnc.wealth.api.authorization.feign.client;

import ca.bnc.wealth.api.authorization.model.SystemTokenJwkRequest;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/** Feign Client to download system token from okta */
public interface SystemTokenJwkConfigClient {

  @RequestMapping(
      path = "",
      method = RequestMethod.POST,
      consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
  ResponseEntity<Object> getSystemToken(SystemTokenJwkRequest formData);
}
