package ca.bnc.wealth.api.authorization.feign.client;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

public interface UserConfigClient {

  @RequestMapping("/users/me")
  ResponseEntity<Object> getUserConfiguration(@RequestParam boolean internalAPICall);
}
