package ca.bnc.wealth.api.authorization.feign.config;

import ca.bnc.wealth.api.authorization.feign.client.FirmAPIClient;
import ca.bnc.wealth.api.authorization.feign.client.IamAPIClient;
import ca.bnc.wealth.api.authorization.feign.client.SystemTokenConfigClient;
import ca.bnc.wealth.api.authorization.feign.client.UserConfigClient;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.FeignErrorDecoder;
import ca.bnc.wealth.api.authorization.security.token.TokenValidatorService;
import ca.bnc.wealth.api.authorization.security.util.JwtUtil;
import feign.Feign;
import feign.RequestInterceptor;
import feign.Retryer;
import feign.codec.Decoder;
import feign.codec.Encoder;
import feign.form.FormEncoder;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;
import jakarta.servlet.http.HttpServletRequest;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.AuthenticationManagerResolver;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.server.resource.web.BearerTokenResolver;
import org.springframework.security.oauth2.server.resource.web.DefaultBearerTokenResolver;
import tools.jackson.databind.json.JsonMapper;

@Configuration
@EnableFeignClients
@Slf4j
public class AuthClientConfig {

  @Value("${feign.userConfigApi.url}")
  private String userConfigurationUrl;

  @Value("${feign.firmConfigApi.url:null}")
  private String firmApiUrl;

  @Value("${oauth2.system.tokenUrl:null}")
  private String systemTokenUrl;

  @Value("${oauth2.system.maxRetryAttempts:5}")
  private int maxRetryAttempts;

  @Value("${oauth2.system.retryInterval:1000}")
  private int retryInterval;

  @Value("${feign.iamApi.url:null}")
  private String iamApiUrl;

  // SET TO ONE OF NONE, BASIC,HEADERS,FULL
  @Value("${feign.logging.level:BASIC}")
  private String feignLoggingLevel;

  @Autowired JwtUtil jwtUtil;

  public RequestInterceptor authRequestInterceptor() {
    return requestTemplate -> {
      User jwt = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
      if (jwt != null) {
        requestTemplate.header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt.getJwtToken());
      }
    };
  }

  public Decoder getResponseEntityDecoder() {
    return FeignCodecs.jsonDecoder();
  }

  // Required for MediaType.APPLICATION_FORM_URLENCODED_VALUE
  public Encoder commonsAuthFormUrlEncoder(JsonMapper jsonMapper) {
    return new FormEncoder(FeignCodecs.jsonEncoder(jsonMapper));
  }

  @Bean
  public UserConfigClient getUserConfigClient(JsonMapper jsonMapper) {
    return Feign.builder()
        .requestInterceptor(authRequestInterceptor())
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .decoder(new ResponseEntityDecoder(getResponseEntityDecoder()))
        .logger(new Slf4jLogger(UserConfigClient.class))
        .logLevel(jwtUtil.getFeignLoggingLevel(feignLoggingLevel))
        .target(UserConfigClient.class, userConfigurationUrl);
  }

  @Bean
  public IamAPIClient getIamClient(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .decoder(new ResponseEntityDecoder(getResponseEntityDecoder()))
        .logger(new Slf4jLogger(IamAPIClient.class))
        .logLevel(jwtUtil.getFeignLoggingLevel(feignLoggingLevel))
        .target(IamAPIClient.class, iamApiUrl);
  }

  @Bean
  public SystemTokenConfigClient getSystemTokenConfigClient(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(commonsAuthFormUrlEncoder(jsonMapper))
        .decoder(new ResponseEntityDecoder(getResponseEntityDecoder()))
        .retryer(
            new Retryer.Default(retryInterval, TimeUnit.SECONDS.toMillis(100), maxRetryAttempts))
        .errorDecoder(new FeignErrorDecoder())
        .logger(new Slf4jLogger(SystemTokenConfigClient.class))
        .logLevel(jwtUtil.getFeignLoggingLevel(feignLoggingLevel))
        .target(SystemTokenConfigClient.class, systemTokenUrl);
  }

  @Bean
  public FirmAPIClient getFirmAPIClient(JsonMapper jsonMapper) {
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .decoder(new ResponseEntityDecoder(getResponseEntityDecoder()))
        .logger(new Slf4jLogger(FirmAPIClient.class))
        .logLevel(jwtUtil.getFeignLoggingLevel(feignLoggingLevel))
        .target(FirmAPIClient.class, firmApiUrl);
  }

  @Bean
  AuthenticationManagerResolver<HttpServletRequest> tokenAuthenticationManagerResolver(
      TokenValidatorService tokenValidatorService) {
    BearerTokenResolver bearerToken = new DefaultBearerTokenResolver();
    return request -> {
      String token = bearerToken.resolve(request);
      String issuer = jwtUtil.getIssuer(token);
      log.trace("Getting token validator for issuer " + issuer);
      return tokenValidatorService.getAuthenticationProvider(issuer)::authenticate;
    };
  }
}
