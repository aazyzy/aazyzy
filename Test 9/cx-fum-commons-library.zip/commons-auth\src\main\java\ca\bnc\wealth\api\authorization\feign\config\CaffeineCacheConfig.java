package ca.bnc.wealth.api.authorization.feign.config;

import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.util.concurrent.TimeUnit;

@Configuration
@EnableCaching
public class CaffeineCacheConfig {

    @Primary
    @Bean(name = "commonsSystemTokenCacheManager")
    public CacheManager cacheManager(
            @Value("${oauth2.system.token.cache.maximumSize:1}") int maximumSize,
            @Value("${oauth2.system.token.cache.ttl:55}") int ttl) {
        CaffeineCacheManager cacheManager = new CaffeineCacheManager("systemToken");
        cacheManager.setCaffeine(
                Caffeine.newBuilder().maximumSize(maximumSize).expireAfterWrite(ttl, TimeUnit.MINUTES));
        return cacheManager;
    }

    @Bean(name = "validPermissionCacheManager")
    public CacheManager validPermission(
            @Value("${iam.permission.cache.maximumSize:100}") int maximumSize,
            @Value("${iam.permission.cache.ttl:100}") int ttl) {
        CaffeineCacheManager cacheManager = new CaffeineCacheManager("validPermission", "validPermissionMap");
        cacheManager.setCaffeine(
                Caffeine.newBuilder().maximumSize(maximumSize).expireAfterWrite(ttl, TimeUnit.MINUTES));
        return cacheManager;
    }

    @Bean(name = "resourceCacheManager")
    public CacheManager resourceCacheManager(
            @Value("${iam.resource.cache.maximumSize:50}") int maximumSize,
            @Value("${iam.resource.cache.ttl:120}") int ttl) {
        CaffeineCacheManager cacheManager = new CaffeineCacheManager("resources");
        cacheManager.setCaffeine(
                Caffeine.newBuilder().maximumSize(maximumSize).expireAfterWrite(ttl, TimeUnit.MINUTES));
        return cacheManager;
    }
}
