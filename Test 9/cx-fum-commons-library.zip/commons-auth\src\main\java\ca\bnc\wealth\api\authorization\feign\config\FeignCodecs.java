package ca.bnc.wealth.api.authorization.feign.config;

import feign.Util;
import feign.codec.Decoder;
import org.springframework.beans.factory.support.StaticListableBeanFactory;
import org.springframework.boot.http.converter.autoconfigure.ClientHttpMessageConvertersCustomizer;
import org.springframework.cloud.openfeign.support.FeignHttpMessageConverters;
import org.springframework.cloud.openfeign.support.HttpMessageConverterCustomizer;
import org.springframework.cloud.openfeign.support.SpringEncoder;
import org.springframework.http.converter.json.JacksonJsonHttpMessageConverter;
import tools.jackson.databind.cfg.DateTimeFeature;
import tools.jackson.databind.json.JsonMapper;

/** Feign codecs shared by the clients commons-auth builds itself. */
public final class FeignCodecs {

  // Jackson 2 defaults: what the Spring Boot 3 line's new ObjectMapper() with JavaTimeModule read
  private static final JsonMapper DECODER_MAPPER =
      JsonMapper.builderWithJackson2Defaults()
          .disable(DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS)
          .build();

  private FeignCodecs() {}

  /** Spring's default client converters, with the JSON one writing through the given mapper. */
  public static SpringEncoder jsonEncoder(JsonMapper jsonMapper) {
    StaticListableBeanFactory beans = new StaticListableBeanFactory();
    beans.addBean(
        "jsonConverter",
        (ClientHttpMessageConvertersCustomizer)
            builder -> builder.withJsonConverter(new JacksonJsonHttpMessageConverter(jsonMapper)));
    beans.addBean(
        "feignHttpMessageConverters",
        new FeignHttpMessageConverters(
            beans.getBeanProvider(ClientHttpMessageConvertersCustomizer.class),
            beans.getBeanProvider(HttpMessageConverterCustomizer.class)));
    return new SpringEncoder(beans.getBeanProvider(FeignHttpMessageConverters.class));
  }

  /** Reads the response body into the requested type. */
  public static Decoder jsonDecoder() {
    return (response, type) -> {
      String bodyStr = Util.toString(response.body().asReader(Util.UTF_8));
      return DECODER_MAPPER.readValue(bodyStr, DECODER_MAPPER.getTypeFactory().constructType(type));
    };
  }
}
