package ca.bnc.wealth.api.authorization.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class PermissionInfo   implements Serializable {
    private static final long serialVersionUID = 1L;
    private String name;
}
