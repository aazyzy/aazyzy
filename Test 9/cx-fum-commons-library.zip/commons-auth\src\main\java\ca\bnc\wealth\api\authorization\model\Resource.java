package ca.bnc.wealth.api.authorization.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Resource {
    private Long resourceId;
    private String resourceName;
    private String resourceType;
    private Boolean active;
    private String description;
    private String confUri;
    private String version;
    private String groupName;
    private String label;
    private String purpose;
    private Boolean restriction;
}
