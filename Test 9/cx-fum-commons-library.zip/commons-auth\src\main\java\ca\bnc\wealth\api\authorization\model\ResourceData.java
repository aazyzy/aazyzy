package ca.bnc.wealth.api.authorization.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResourceData {
    private Long resourceId;
    private Boolean active;
    private String name;
    private String description;
    private String confUri;
    private String version;
    private String groupName;
    private String label;
    private String purpose;
    private Boolean restriction;
}
