package ca.bnc.wealth.api.authorization.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SystemTokenJwkRequest {
  private String grant_type;
  private String scope;
  private String client_assertion_type;
  private String client_assertion;
}
