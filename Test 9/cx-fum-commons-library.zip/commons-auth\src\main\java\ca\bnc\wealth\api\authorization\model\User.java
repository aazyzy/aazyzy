package ca.bnc.wealth.api.authorization.model;

import java.io.Serializable;
import lombok.*;

import java.util.List;

/**
 * Represents an authenticated User's profile derived from PLATFORM.USER_CONFIGURATION record for
 * the user
 */
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class User  implements Serializable {
  private Integer userConfigurationId; // user configuration
  private List<String> secureZoneIds; // user configuration
  private String idpSubject; // sub in JWT claim
  private String idpUserId; // uid in JWT claim
  private String username; // user configuration
  private List<String> roles; // scp in JWT claim
  private List<String> groups; // groups in JWT claim
  private String ossUserId; // user configuration
  private String ossGroupId; // user configuration
  private String firstName; // user configuration
  private String lastName; // user configuration
  private String preferredLanguage; // user configuration
  private String email; // user configuration
  private String firmId; // user configuration
  private String jwtToken; // JWT access token
  private boolean isSystemToken;
  private boolean isEmployeeToken;
  private boolean scopeChecked;
}
