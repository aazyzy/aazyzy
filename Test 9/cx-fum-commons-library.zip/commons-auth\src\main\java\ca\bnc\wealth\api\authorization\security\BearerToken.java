package ca.bnc.wealth.api.authorization.security;

import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
public class BearerToken {

    private String token;
}
