package ca.bnc.wealth.api.authorization.security;

import ca.bnc.wealth.api.authorization.model.User;
import java.util.HashMap;

public interface EnrichUserService {
  HashMap enrichWithUserConfig(String idpSubject);
}
