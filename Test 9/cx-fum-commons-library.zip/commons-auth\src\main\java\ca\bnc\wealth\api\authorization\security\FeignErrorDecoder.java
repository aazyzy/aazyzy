package ca.bnc.wealth.api.authorization.security;


import feign.Response;
import feign.RetryableException;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FeignErrorDecoder implements ErrorDecoder {


  @Override
  public Exception decode(String methodKey, Response response) {
    log.info("Unable to get System Token, Response: " + response);
    return new RetryableException(response.status(), response.reason(),
        response.request().httpMethod(), (Long) null, response.request());
  }
}
