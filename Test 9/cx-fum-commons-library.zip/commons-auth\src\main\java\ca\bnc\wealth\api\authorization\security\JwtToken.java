package ca.bnc.wealth.api.authorization.security;

import ca.bnc.wealth.api.authorization.model.User;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Optional;


public class JwtToken {

    public static String getAuthToken(){
        return Optional.ofNullable(SecurityContextHolder.getContext().getAuthentication())
                .map(authentication -> (User)authentication.getPrincipal())
                .map(User::getJwtToken).orElse(null);
    }

    public static String getBearerToken(){
        return "Bearer "+getAuthToken();
    }

}
