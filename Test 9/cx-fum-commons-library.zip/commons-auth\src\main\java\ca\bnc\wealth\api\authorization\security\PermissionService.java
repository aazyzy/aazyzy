package ca.bnc.wealth.api.authorization.security;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface PermissionService {

  List<String> getPermissions(String userIdpSubject, List<String> permissions);

  void clearValidPermissionCache();

  Map<String, Set<String>> getPermissionMap(String userIdpSubject, List<String> capabilities);

}
