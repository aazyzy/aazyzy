package ca.bnc.wealth.api.authorization.security;

public interface ResourceValidationFilter {
}
