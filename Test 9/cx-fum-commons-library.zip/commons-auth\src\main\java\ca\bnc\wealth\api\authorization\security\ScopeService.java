package ca.bnc.wealth.api.authorization.security;

import jakarta.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

public interface ScopeService {
    Map<String,List<String>> getScope(String className, Method method);

    Map<String,List<String>> getScope(HttpServletRequest request);
}
