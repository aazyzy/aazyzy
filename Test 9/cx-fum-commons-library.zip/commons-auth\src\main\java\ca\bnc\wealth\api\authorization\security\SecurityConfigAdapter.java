package ca.bnc.wealth.api.authorization.security;

import ca.bnc.wealth.api.authorization.enums.ErrorMessages;
import ca.bnc.wealth.api.authorization.security.impl.AuthTokenValidationFilterImpl;
import jakarta.servlet.Filter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManagerResolver;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Configuration
@EnableWebSecurity
@Slf4j
public class SecurityConfigAdapter {

  @Autowired private ScopeValidationFilter scopeValidationFilter;

  @Autowired private PermissionValidationFilter permissionValidationFilter;

  @Autowired private ResourceValidationFilter resourceValidationFilter;

  @Autowired(required = false)
  private AuthTokenValidationFilter authTokenvalidatorFilter;

  @Autowired
  private AuthenticationManagerResolver<HttpServletRequest> authenticationManagerResolver;

  @Value("${oauth2.unAuthorized.routes:#{null}}")
  private String unAuthorizedRoutes;

  public SecurityConfigAdapter() {
    if (authTokenvalidatorFilter == null) {
      this.authTokenvalidatorFilter = new AuthTokenValidationFilterImpl();
    }
  }

  @Bean
  public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    http.sessionManagement(
            session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
        .authorizeHttpRequests(
            authorize ->
                authorize
                    .requestMatchers(
                        "/v2/api-docs/**",
                        "/v3/api-docs/**",
                        "/swagger-ui/**",
                        "/docs/swagger-ui/**",
                        "/docs/swagger-resources/**",
                        "/swagger-resources/**",
                        "/manage/**")
                    .permitAll()
                    .anyRequest()
                    .authenticated())
        .exceptionHandling(
            exceptions ->
                exceptions.authenticationEntryPoint(
                    (request, response, ex) -> {
                      response.sendError(
                          HttpServletResponse.SC_UNAUTHORIZED,
                          ErrorMessages.INVALID_TOKEN.getValue());
                    }))
        .addFilterAfter((Filter) authTokenvalidatorFilter, BasicAuthenticationFilter.class)
        .addFilterAfter(
            (Filter) scopeValidationFilter, ((Filter) authTokenvalidatorFilter).getClass())
        .addFilterAfter(
            (Filter) permissionValidationFilter, ((Filter) scopeValidationFilter).getClass())
        .addFilterAfter(
            (Filter) resourceValidationFilter, ((Filter) permissionValidationFilter).getClass())
        .oauth2ResourceServer(
            oauth2 -> oauth2.authenticationManagerResolver(this.authenticationManagerResolver));
    return http.build();
  }

  // Skip authentication/authorizations for swagger resources
  @Bean
  public WebSecurityCustomizer webSecurityCustomizer() {
    List<String> unprotectedRoutesList = new ArrayList<>();

    if (unAuthorizedRoutes != null && !unAuthorizedRoutes.equalsIgnoreCase("null")) {
      log.trace("Disabling authorization for additional routes : {}", unAuthorizedRoutes);
      unprotectedRoutesList.addAll(
          Arrays.stream(unAuthorizedRoutes.split(",")).map(String::trim).toList());
    }
    return web -> {
      web.ignoring()
          .requestMatchers(
              "/v2/api-docs/**",
              "/v3/api-docs/**",
              "/swagger-ui/**",
              "/docs/swagger-ui/**",
              "/docs/swagger-resources/**",
              "/swagger-resources/**",
              "/manage/**");
      web.ignoring().requestMatchers(unprotectedRoutesList.toArray(String[]::new));
      web.ignoring().requestMatchers(HttpMethod.OPTIONS);
    };
  }
}
