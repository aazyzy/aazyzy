package ca.bnc.wealth.api.authorization.security;

import org.springframework.security.oauth2.jwt.JwtDecoder;

public interface TokenDecoder {
  public JwtDecoder getDecoder();
}
