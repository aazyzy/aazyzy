package ca.bnc.wealth.api.authorization.security;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;

/**
 * Checks whether a JWT token has been revoked by looking up its key in Redis.
 *
 * <p>The revoke endpoint (user-configuration-api) stores revoked tokens under
 * {@code revoked-token:{rawJwtToken}} with a 30-minute TTL. This service performs
 * a key-existence check against the same Redis instance.
 *
 * <p>Behaviour is fail-open: if Redis is unreachable the request is allowed through
 * and a warning is logged, so availability is not impacted.
 */
@Slf4j
public class TokenRevocationCheckService {

  private static final String REVOKED_TOKEN_PREFIX = "revoked-token:";

  private final RedisTemplate<String, Object> redisTemplate;

  @Value("${auth.token.revocation.enabled:true}")
  private boolean revocationEnabled;

  public TokenRevocationCheckService(RedisTemplate<String, Object> redisTemplate) {
    this.redisTemplate = redisTemplate;
  }

  /**
   * Returns {@code true} when the supplied raw JWT token value has been revoked.
   *
   * @param token the raw JWT string (without "Bearer " prefix)
   * @return {@code true} if the token is found in the Redis revocation store
   */
  public boolean isTokenRevoked(String token) {
    if (!revocationEnabled) {
      return false;
    }
    try {
      String key = REVOKED_TOKEN_PREFIX + token;
      Boolean exists = redisTemplate.hasKey(key);
      if (Boolean.TRUE.equals(exists)) {
        log.info("Token revocation check: token has been revoked");
        return true;
      }
      return false;
    } catch (Exception e) {
      log.warn("Token revocation check failed (Redis unavailable), allowing request: {}",
          e.getMessage());
      return false;
    }
  }
}
