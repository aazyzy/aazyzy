package ca.bnc.wealth.api.authorization.security.impl;

import ca.bnc.wealth.api.authorization.security.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;

@Slf4j
@Configuration
@Profile("!test")
public class AuthConfiguration {

  @Bean
  public AuthTokenValidationFilter getAuthTokenValidationFilter() {
    return new AuthTokenValidationFilterImpl();
  }

  @Bean
  JwtAuthenticationConverter jwtAuthenticationConverter() {
    final JwtAuthenticationConverter converter = new JwtAuthenticationConverter();
    return converter;
  }

  @Bean
  ScopeService getScopeService() {
    return new ScopeServiceImpl();
  }

  @Bean
  ScopeValidationFilter getScopeValidationFilter() {
    return new ScopeValidationFilterImpl();
  }

  @Bean
  PermissionValidationFilter getPermissionValidationFilter() {
    return new PermissionValidationFilterImpl();
  }

  @Bean
  ResourceValidationFilter getResourceValidationFilter() {
    return new ResourceValidationFilterImpl();
  }

  @Bean
  PermissionService getPermissionService() {
    return new PermissionServiceImpl();
  }

  @Bean
  EnrichUserService getEnrichUserService() {
    return new EnrichUserServiceImpl();
  }

  @Bean
  TokenRevocationCheckService tokenRevocationCheckService(
      RedisTemplate<String, Object> redisTemplate) {
    return new TokenRevocationCheckService(redisTemplate);
  }
}
