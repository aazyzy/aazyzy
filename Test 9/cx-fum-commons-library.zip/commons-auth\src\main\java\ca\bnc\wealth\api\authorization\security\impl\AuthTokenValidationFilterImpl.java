package ca.bnc.wealth.api.authorization.security.impl;

import ca.bnc.wealth.api.authorization.enums.ErrorMessages;
import ca.bnc.wealth.api.authorization.feign.client.UserConfigClient;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.AuthTokenValidationFilter;
import ca.bnc.wealth.api.authorization.security.BearerToken;
import ca.bnc.wealth.api.authorization.security.EnrichUserService;
import ca.bnc.wealth.api.authorization.security.TokenRevocationCheckService;
import ca.bnc.wealth.api.authorization.security.util.JwtUtil;
import datadog.trace.api.GlobalTracer;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.UrlPathHelper;

@Slf4j
public class AuthTokenValidationFilterImpl extends OncePerRequestFilter
    implements AuthTokenValidationFilter {

  private static final String USER_CONFIGURATION_LOOKUP_PATH = "/users/me";
  private static final String ACTIVE_STATUS = "active";

  @Autowired BearerToken bearerToken;
  @Autowired UserConfigClient userConfigClient;
  @Autowired JwtUtil jwtUtil;
  @Autowired EnrichUserService enrichUserService;

  @Autowired(required = false)
  TokenRevocationCheckService tokenRevocationCheckService;

  @SneakyThrows
  @Override
  public void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain chain) {
    if(StringUtils.isBlank(request.getHeader("Authorization"))) {
      log.info("Authorization header is missing for HTTP Method: {}, URL: {}", request.getMethod(), request.getRequestURI());
      response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Authorization header is missing");
      return;
    }
    Jwt jwt = (Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    // Check if the token has been revoked (e.g. user logged out)
    if (tokenRevocationCheckService != null
        && tokenRevocationCheckService.isTokenRevoked(jwt.getTokenValue())) {
      log.warn("Revoked token used for HTTP Method: {}, URL: {}",
          request.getMethod(), request.getRequestURI());
      response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
          ErrorMessages.INVALID_TOKEN.getValue());
      return;
    }

    boolean internalAPICall = request.getParameter("internalAPICall") == null ? false : true;
    boolean isSystemToken = jwtUtil.isSystemToken(jwt);
    boolean isEmployeeToken = jwtUtil.isEmployeeToken(jwt);
    User user = JwtUtil.createUserObject(jwt);
    // If system token, then load the bare minimum details from the JWT
    if (isSystemToken) {
      log.trace("SYSTEM ACCESS TOKEN VALIDATED");
      user.setSystemToken(true);
    } else if (isEmployeeToken) {
      log.trace("EMPLOYEE ACCESS TOKEN VALIDATED");
      user.setEmployeeToken(true);
    } else {
      log.trace("USER ACCESS TOKEN VALIDATED");
    }

    bearerToken.setToken(jwt.getTokenValue());
    setUserAuthenticationContext(user); // Set to basic user
    // The flag is a client-controlled query parameter, so for employee tokens it is honoured only
    // on the user-config lookup the enrichment makes; elsewhere it would skip the status check.
    boolean skipEnrichment =
        internalAPICall && (!isEmployeeToken || isUserConfigurationLookup(request));
    // For non system tokens, invoke user-config api and load user info
    if (!skipEnrichment && !isSystemToken) {
      HashMap userConfiguration = null;
      try {
        userConfiguration = enrichUserService.enrichWithUserConfig(user.getIdpSubject());
        User enrichedUser = JwtUtil.enrichUserObject(userConfiguration, user);
        setUserAuthenticationContext(enrichedUser); // Set to enriched user
        log.trace("Idp Subject: {},  Firm Id: {}, url: {}",user.getIdpSubject(), user.getFirmId(), request.getRequestURI());
      }catch (Exception ex){
        log.info("Unable to find user in CX, {}", user.getIdpSubject());
      }
      // FUM does not manage the employee Okta tenant, so an employee suspension only exists in
      // the CX profile and must be enforced here (NWPI-15097).
      if (isEmployeeToken && userConfiguration != null && !isActive(userConfiguration)) {
        log.warn("Inactive CX profile {} denied for HTTP Method: {}, URL: {}",
            user.getIdpSubject(), request.getMethod(), request.getRequestURI());
        response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
            ErrorMessages.INACTIVE_USER.getValue());
        return;
      }
    }

    // Add data-dog trace id when available
    if (response instanceof HttpServletResponse) {
      String traceId = GlobalTracer.get().getTraceId();
      // Add trace ID to the response header
      response.addHeader("X-Trace-Id", traceId);
    }

    chain.doFilter(request, response);
  }

  private void setUserAuthenticationContext(User user) {
    SecurityContextHolder.getContext()
        .setAuthentication(new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>()));
  }

  private static boolean isUserConfigurationLookup(HttpServletRequest request) {
    return HttpMethod.GET.matches(request.getMethod())
        && USER_CONFIGURATION_LOOKUP_PATH.equals(
            UrlPathHelper.defaultInstance.getPathWithinApplication(request));
  }

  // user-configuration-api derives "status" from the profile's ACTIVE flag.
  private static boolean isActive(HashMap userConfiguration) {
    return ACTIVE_STATUS.equalsIgnoreCase(String.valueOf(userConfiguration.get("status")));
  }
}
