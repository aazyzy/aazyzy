package ca.bnc.wealth.api.authorization.security.impl;

import ca.bnc.wealth.api.authorization.feign.client.UserConfigClient;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.EnrichUserService;
import ca.bnc.wealth.api.authorization.security.util.JwtUtil;
import feign.FeignException;
import java.util.HashMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;

@Slf4j
public class EnrichUserServiceImpl implements EnrichUserService {

  @Autowired
  private UserConfigClient userConfigClient;

  @Value("${redis.cache.enable:false}")
  private boolean enableCache;



  @Override
  @Cacheable(value = "UserConfiguration-Enrich", key = "#idpSubject", cacheManager = "redisCacheManager", condition = "#root.getTarget().redisCacheEnabled()")
  public HashMap enrichWithUserConfig(String idpSubject) {
    log.trace("Get user configuration for {}", idpSubject);
    User enrichedUser;
    try {
      ResponseEntity<Object> userConfiguration = userConfigClient.getUserConfiguration(true);
      return (HashMap) userConfiguration.getBody();
    } catch (Exception e) {
      // Hard coding CRITICAL in the log message instead of using MessageSeverity.CRITICAL because
      // we did not want to bring spring-microservice-starter dependency in this library
      if (e instanceof FeignException
          && (((FeignException) e).status() == -1 || ((FeignException) e).status() == 503)) {
        log.info("CRITICAL: Error connecting to user configuration api", e);
      }
      throw e;
    }
  }

  public boolean redisCacheEnabled() {
    return enableCache;
  }
}
