package ca.bnc.wealth.api.authorization.security.impl;

import ca.bnc.wealth.api.authorization.feign.client.IamAPIClient;
import ca.bnc.wealth.api.authorization.model.PermissionInfo;
import ca.bnc.wealth.api.authorization.model.Role;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.PermissionService;
import feign.FeignException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class PermissionServiceImpl implements PermissionService {

  private static final String VALID_PERMISSION = "validPermission";
  private static final String VALID_PERMISSION_MAP = "validPermissionMap";
  private static final String VALID_PERMISSION_CACHE_MANAGER = "validPermissionCacheManager";

  @Autowired private IamAPIClient iamAPIClient;

  @Autowired
  @Qualifier(VALID_PERMISSION_CACHE_MANAGER)
  private CacheManager cacheManager;

  @Override
  @Cacheable(cacheNames = VALID_PERMISSION, cacheManager = VALID_PERMISSION_CACHE_MANAGER)
  public List<String> getPermissions(String userIdpSubject, List<String> capabilities) {
    log.trace("Getting user {} permissions for capabilities {}", userIdpSubject, capabilities);
    User jwt = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    String token = "Bearer " + jwt.getJwtToken();
    List<String> permissions = new ArrayList<>();
    try {
      capabilities.forEach(
          capability -> {
            List<String> permissionsForCapability =
                iamAPIClient.getRoles(token, capability, true).getBody().stream()
                    .filter(role -> role.getPermissions() != null)
                    .map(Role::getPermissions)
                    .flatMap(List::stream)
                    .map(PermissionInfo::getName)
                    .collect(Collectors.toList());
            if (permissionsForCapability != null && permissionsForCapability.size() > 0) {
              permissions.addAll(permissionsForCapability);
            }
            log.trace("Capability {}, Permissions : {}", capability, permissionsForCapability);
          });
    } catch (Exception e) {
      if (e instanceof FeignException
          && (((FeignException) e).status() == -1 || ((FeignException) e).status() == 503)) {
        log.info("CRITICAL: Error connecting to AuthR api", e);
      }
      throw e;
    }
    return permissions;
  }

  @Override
  @Cacheable(cacheNames = VALID_PERMISSION_MAP, cacheManager = VALID_PERMISSION_CACHE_MANAGER)
  public Map<String, Set<String>> getPermissionMap(String userIdpSubject, List<String> capabilities) {
    log.trace("Getting user {} permissions for capabilities {}", userIdpSubject, capabilities);
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    String token = "Bearer " + user.getJwtToken();
    final Map<String, Set<String>> roleToPermission = new HashMap<>();
    try {
      capabilities.forEach(
              capability -> {
                for (Role role: Objects.requireNonNull(iamAPIClient.getRoles(token, capability, true).getBody())) {
                  if (role.getPermissions() != null) {
                    roleToPermission.put(role.getRoleName(),
                            role.getPermissions().stream().map(PermissionInfo::getName).collect(Collectors.toSet()));
                  }
                }
                log.trace("Capability {}, PermissionMap : {}", capability, roleToPermission);
              });
    } catch (Exception e) {
      if (e instanceof FeignException
              && (((FeignException) e).status() == -1 || ((FeignException) e).status() == 503)) {
        log.info("CRITICAL: Error connecting to AuthR api", e);
      }
      throw e;
    }
    return roleToPermission;
  }

  @Override
  public void clearValidPermissionCache() {
    Cache cache = cacheManager.getCache(VALID_PERMISSION);
    if (cache != null) {
      cache.clear();
    }
    cache = cacheManager.getCache(VALID_PERMISSION_MAP);
    if (cache != null) {
      cache.clear();
    }
  }
}
