package ca.bnc.wealth.api.authorization.security.impl;

import ca.bnc.wealth.api.authorization.enums.ErrorMessages;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.PermissionService;
import ca.bnc.wealth.api.authorization.security.PermissionValidationFilter;
import ca.bnc.wealth.api.authorization.security.ScopeService;
import ca.bnc.wealth.api.authorization.security.util.ClassUtil;
import ca.bnc.wealth.api.authorization.security.util.DisablePermissionCheck;
import feign.FeignException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ServletRequestPathUtils;

@Slf4j
public class PermissionValidationFilterImpl extends OncePerRequestFilter
    implements PermissionValidationFilter {
  private static String PERMISSIONS = "permissions";

  @Value("${iam.capabilities:aom,access-control,moe,user-conf,firm-conf}")
  protected String[] capabilities;

  @Autowired ClassUtil classUtil;
  @Autowired ScopeService scopeService;
  @Autowired PermissionService permissionService;

  @SneakyThrows
  @Override
  protected void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
      throws ServletException, IOException {

    /** To solve for this - https://github.com/spring-projects/spring-boot/issues/28874 */
    if (!ServletRequestPathUtils.hasParsedRequestPath(request)) {
      ServletRequestPathUtils.parseAndCache(request);
    }
    log.trace("CHECKING PERMISSIONS for {}", request.getRequestURI());
    checkPermission(request, response, filterChain);
  }

  @SneakyThrows
  private void checkPermission(
      HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    Method method;
    try {
      method = classUtil.getApiMethod(request).getRight();
    } catch (NullPointerException e) {
      response.sendError(
          HttpServletResponse.SC_NOT_FOUND,
          ErrorMessages.METHOD_VALIDATION_FAILED.getValue());
      return;
    }

    if (method.isAnnotationPresent(DisablePermissionCheck.class) && user.isScopeChecked()) {
      log.trace(
          "Skipping permission check as method is marked with DisablePermissionCheck annotation");
      filterChain.doFilter(request, response);
    } else {
      Map<String, List<String>> scopeMap = scopeService.getScope(request);
      boolean permissionsValid = false;
      try {
        permissionsValid = validatePermission(scopeMap.get(PERMISSIONS));
      } catch (FeignException e) {
        if (e.status() == 401) {
          response.sendError(
              HttpServletResponse.SC_UNAUTHORIZED,
              ErrorMessages.SCOPE_VALIDATION_FAILED.getValue());
          return;
        } else {
          throw e;
        }
      }
      if (!permissionsValid) {
        log.info(
            "PERMISSION VALIDATION FAILED! Required permission: "
                + scopeMap.get(PERMISSIONS)
                + ", is not available for the user");
        response.sendError(
            HttpServletResponse.SC_UNAUTHORIZED,
            ErrorMessages.PERMISSION_VALIDATION_FAILED.getValue());
      } else {
        filterChain.doFilter(request, response);
      }
    }
  }

  public boolean validatePermission(List<String> permissionsToVerify) {
    log.trace("Checking permissions assignments for {}", permissionsToVerify);
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    List<String> capabilitiesList = null;

    if (user.isSystemToken()) {
      log.trace("SKIPPING PERMISSIONS VALIDATION FOR SYSTEM SCOPES");
      return true;
    }

    if (permissionsToVerify == null) {
      return false;
    }

    /**
     * Extract the list of capabilities from the permission names for eg. moe:manage, aom:view_roles
     * -> ["moe","aom"] If permissions are of the old naming convention where capability was not
     * included in the naming scheme, then the full default list is used to fetch permissions
     */
    capabilitiesList =
        permissionsToVerify.stream()
            .filter(p -> p.split(":").length > 1)
            .map(p -> Arrays.stream(p.split(":")).findFirst().get())
            .distinct()
            .collect(Collectors.toList());
    /**
     * No capabilites were extracted from permission names, so default to full list of known
     * capabilities
     */
    if (capabilitiesList.size() == 0) {
      capabilitiesList = Arrays.asList(capabilities);
      log.trace("Using the default capabilities list : {}", capabilitiesList);
    }
    Map<String, Set<String>> userPermissions =
        permissionService.getPermissionMap(user.getIdpSubject(), capabilitiesList);
    log.trace("Api Permissions {} : User Permissions {}", permissionsToVerify, userPermissions);
    return checkPermission(userPermissions, permissionsToVerify)
        ? true
        : refreshCacheAndCheckPermission(user, capabilitiesList, permissionsToVerify);
  }

  private boolean checkPermission(Map<String, Set<String>> userRoleToPermissions, List<String> permissionsToVerify) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    Set<String> userPermissions = new HashSet<>();
    for (String roleInJwt: user.getRoles()) {
      if (userRoleToPermissions.containsKey(roleInJwt)) {
        userPermissions.addAll(userRoleToPermissions.get(roleInJwt));
      }
    }
    return userPermissions.containsAll(permissionsToVerify);
  }

  private boolean refreshCacheAndCheckPermission(
      User user, List<String> capabilitiesList, List<String> permissionsToVerify) {
    permissionService.clearValidPermissionCache();
    return checkPermission(permissionService.getPermissionMap(user.getIdpSubject(), capabilitiesList), permissionsToVerify);
  }
}
