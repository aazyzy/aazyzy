package ca.bnc.wealth.api.authorization.security.impl;

import ca.bnc.wealth.api.authorization.feign.client.IamAPIClient;
import ca.bnc.wealth.api.authorization.model.Resource;
import ca.bnc.wealth.api.authorization.model.User;
import feign.FeignException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
public class ResourceService {

    @Autowired
    private IamAPIClient iamAPIClient;

    @Cacheable(cacheNames = "resources", cacheManager = "resourceCacheManager")
    public List<String> getResources(String userIdpSubject, String resourceType) {
        log.trace("Getting resources for user {} and resourceType {} ", userIdpSubject, resourceType);
        User jwt = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String token = "Bearer " + jwt.getJwtToken();
        try {
            List<Resource> resourceList = iamAPIClient.getResources(token, resourceType)
                .getBody();

            if (resourceList != null) {
                return resourceList.stream()
                    .map(Resource::getResourceName)
                    .collect(Collectors.toList());
            }
        } catch (Exception e) {
            if (e instanceof FeignException
                    && (((FeignException) e).status() == -1 || ((FeignException) e).status() == 503)) {
                log.info("CRITICAL: Error connecting to AuthR api", e);
            }
            throw e;
        }
        return Collections.emptyList();
    }
}
