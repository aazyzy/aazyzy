package ca.bnc.wealth.api.authorization.security.impl;

import ca.bnc.wealth.api.authorization.enums.ErrorMessages;
import ca.bnc.wealth.api.authorization.enums.ScopeType;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.ResourceValidationFilter;
import ca.bnc.wealth.api.authorization.security.ScopeService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

@Slf4j
public class ResourceValidationFilterImpl extends OncePerRequestFilter
    implements ResourceValidationFilter {

  @Autowired private ResourceService resourceService;

  @Autowired private ScopeService scopeService;

  @SneakyThrows
  @Override
  protected void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    if (user.isSystemToken()) {
      log.trace("SKIPPING RESOURCE VALIDATION CHECKS FOR SYSTEM TOKEN CALLS ");
      filterChain.doFilter(request, response);
    } else {
      log.trace("CHECKING RESOURCES for {}", request.getRequestURI());
      checkResourceLevelAccess(request, response, filterChain);
    }
  }

  @SneakyThrows
  private void checkResourceLevelAccess(
      HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {

    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    Map<String,List<String>> scope;
    try {
      scope = scopeService.getScope(request);
    } catch (NullPointerException e) {
      response.sendError(
          HttpServletResponse.SC_NOT_FOUND,
          ErrorMessages.METHOD_VALIDATION_FAILED.getValue());
      return;
    }
    if(scope.keySet().contains(ScopeType.RESOURCES.getSwaggerName())) {
      Map<String, List<String>> userResources = getResourcesTypeName(user.getIdpSubject(), scope.get(ScopeType.RESOURCES.getSwaggerName()));
      checkResourceTypeAndName(request, response, filterChain, userResources, scope.get(ScopeType.RESOURCES.getSwaggerName()));
    } else {
      filterChain.doFilter(request, response);
    }
  }

  @SneakyThrows
  private void checkResourceTypeAndName(
      HttpServletRequest request,
      HttpServletResponse response,
      FilterChain filterChain,
      Map<String, List<String>> userResources,
      List<String> requiredResources) {
    Optional<String[]> userHasRequiredResource = requiredResources.stream()
        .map(rr -> rr.split("\\s+"))
        .filter(rrArr -> rrArr.length == 2)

        .filter(rrArr -> userResources.get(rrArr[0]) != null && userResources.get(rrArr[0]).contains(rrArr[1]))
        .findFirst();
    if (userHasRequiredResource.isEmpty()) {
      log.info(
          "RESOURCE VALIDATION FAILED! the required resource  "
              + requiredResources
              + " NOT found in the user resources:"
              + userResources);
      response.sendError(
          HttpServletResponse.SC_UNAUTHORIZED, ErrorMessages.RESOURCE_VALIDATION_FAILED.getValue());
    } else {
      filterChain.doFilter(request, response);
    }
  }

  private Map<String, List<String>> getResourcesTypeName(String idpSubject, List<String> resources) {
    Map<String, List<String>> map = new HashMap<>();
    List<String> resourceTypes = resources.stream().map(rtp -> rtp.split("\\s+")[0]).toList();
    resourceTypes.forEach(rt -> map.put(rt, resourceService.getResources(idpSubject, rt)));
    return map;
  }
}
