package ca.bnc.wealth.api.authorization.security.impl;

import ca.bnc.wealth.api.authorization.security.ScopeService;
import ca.bnc.wealth.api.authorization.security.util.ClassUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.AnnotationUtils;

@Slf4j
public class ScopeServiceImpl implements ScopeService {

  private Map<String, Map<String, List<String>>> methodScopeMap = new ConcurrentHashMap<>();

  @Autowired
  private ClassUtil classUtil;

  public Map<String, List<String>> getScope(HttpServletRequest request) {
    Pair<String, Method> requestService = classUtil.getApiMethod(request);
    return getScope(requestService.getLeft(), requestService.getRight());
  }

  @Override
  public Map<String, List<String>> getScope(String className, Method method) {
    return methodScopeMap.computeIfAbsent(
        className + "." + method.getName(), k -> getScope(method));
  }

  private synchronized Map<String, List<String>> getScope(Method method) {
    Map<String, List<String>> map = new HashMap<>();

    Object[] object =
        Optional.ofNullable(AnnotationUtils.findAnnotation(method, Operation.class))
            .map(opp -> opp.security())
            .orElse(null);

    Optional.ofNullable(object)
        .ifPresent(
            array ->
                Arrays.stream(array)
                    .forEach(obj -> this.getMapping((SecurityRequirement) obj, map)));

    return map;
  }

  private void getMapping(SecurityRequirement security, Map<String, List<String>> map) {
    String securityType = security.name();
    map.put(securityType, new ArrayList<>());

    Optional.ofNullable(security.scopes())
        .ifPresent(
            array -> Arrays.stream(array).forEach(scope -> map.get(securityType).add(scope)));
  }
}
