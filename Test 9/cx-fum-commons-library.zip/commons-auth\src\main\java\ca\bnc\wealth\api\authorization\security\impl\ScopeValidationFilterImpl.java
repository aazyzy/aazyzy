package ca.bnc.wealth.api.authorization.security.impl;

import ca.bnc.wealth.api.authorization.enums.ErrorMessages;
import ca.bnc.wealth.api.authorization.enums.ScopeType;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.ScopeService;
import ca.bnc.wealth.api.authorization.security.ScopeValidationFilter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ServletRequestPathUtils;

@Slf4j
public class ScopeValidationFilterImpl extends OncePerRequestFilter
    implements ScopeValidationFilter {

  @Value("${iam.capabilities:aom,access-control,moe,user-conf,firm-conf}")
  protected String[] capabilities;

  @Autowired ApplicationContext appContext;
  @Autowired ScopeService scopeService;

  @SneakyThrows
  @Override
  protected void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
      throws ServletException, IOException {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    /** To solve for this - https://github.com/spring-projects/spring-boot/issues/28874 */
    if (!ServletRequestPathUtils.hasParsedRequestPath(request)) {
      ServletRequestPathUtils.parseAndCache(request);
    }
    log.trace("CHECKING SCOPE for {}", request.getRequestURI());
    checkScope(request, response, filterChain);
  }

  @SneakyThrows
  private void checkScope(
      HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    List<String> userRoles = user.getRoles();

    Map<String, List<String>> scopeMap;
    try {
      scopeMap = scopeService.getScope(request);
    } catch (NullPointerException e) {
      response.sendError(
          HttpServletResponse.SC_NOT_FOUND,
          ErrorMessages.METHOD_VALIDATION_FAILED.getValue());
      return;
    }
    if (!bypassScopeValidation(user.isSystemToken(), scopeMap)) {
      Optional<String> scope =
          scopeMap.entrySet().stream()
              .filter(entry -> tokenType(user.isSystemToken(), entry.getKey()))
              .map(entry -> entry.getValue())
              .flatMap(lst -> lst.stream())
              .filter(userRoles::contains)
              .findFirst();
      if (!scope.isPresent()) {
        log.info(
            "ROLE VALIDATION FAILED! None of the required api scopes "
                + scopeMap
                + " found in the user access token scopes:"
                + user.getRoles());
        response.sendError(
            HttpServletResponse.SC_UNAUTHORIZED, ErrorMessages.SCOPE_VALIDATION_FAILED.getValue());
        return;
      }
    }
    user.setScopeChecked(true);
    filterChain.doFilter(request, response);
  }

  private boolean bypassScopeValidation(boolean systemToken, Map<String, List<String>> scopeMap) {
    boolean bypass = false;
    if (systemToken) {
      bypass =
          scopeMap.get(ScopeType.SYSTEM_ACCESS.getSwaggerName()) == null
              || scopeMap.get(ScopeType.SYSTEM_ACCESS.getSwaggerName()).isEmpty();
    } else {
      bypass =
          scopeMap.get(ScopeType.ROLES.getSwaggerName()) == null
              || scopeMap.get(ScopeType.ROLES.getSwaggerName()).isEmpty();
    }
    if (bypass) {
      log.trace("Bypassing role scope check as no scopes are defined on this api");
    }
    return bypass;
  }

  private boolean tokenType(boolean isSystemToken, String swaggerName) {

    switch (ScopeType.getScopeType(swaggerName)) {
      case ROLES:
        return !isSystemToken;
      case SYSTEM_ACCESS:
        return isSystemToken;
    }
    return false;
  }
}
