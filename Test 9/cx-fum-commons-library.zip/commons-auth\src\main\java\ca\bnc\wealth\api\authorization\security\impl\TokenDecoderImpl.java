package ca.bnc.wealth.api.authorization.security.impl;

import ca.bnc.wealth.api.authorization.security.TokenDecoder;
import ca.bnc.wealth.api.authorization.security.token.CustumJwtDecoder;
import com.nimbusds.jose.jwk.source.DefaultJWKSetCache;
import com.nimbusds.jose.jwk.source.JWKSetCache;
import com.nimbusds.jose.jwk.source.RemoteJWKSet;
import com.nimbusds.jose.proc.JWSAlgorithmFamilyJWSKeySelector;
import com.nimbusds.jose.proc.JWSKeySelector;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jose.util.DefaultResourceRetriever;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;
import dev.failsafe.Failsafe;
import dev.failsafe.RetryPolicy;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;

import java.net.URL;
import java.util.concurrent.TimeUnit;

@NoArgsConstructor
@Slf4j
public class TokenDecoderImpl implements TokenDecoder {

  private long jwksCacheLifeSpanSeconds;
  private long jwksRefreshTimeSeconds;
  private int jwksConnectTimeoutSeconds;
  private int jwksReadTimeoutSeconds;

  RetryPolicy<Object> retryPolicy;
  JWKSetCache jwkSetCache;
  private String keysUrl;

  private String[] defaultKey;

  public TokenDecoderImpl(
      String keysUrl,
      long jwksCacheLifeSpanSeconds,
      long jwksRefreshTimeSeconds,
      RetryPolicy retryPolicy,
      String[] defaultkey,
      int jwksConnectTimeoutSeconds,
      int jwksReadTimeoutSeconds) {
    this.keysUrl = keysUrl;
    this.jwksRefreshTimeSeconds = jwksRefreshTimeSeconds;
    this.jwksCacheLifeSpanSeconds = jwksCacheLifeSpanSeconds;
    this.retryPolicy = retryPolicy;
    jwkSetCache =
        new DefaultJWKSetCache(
            this.jwksCacheLifeSpanSeconds, this.jwksRefreshTimeSeconds, TimeUnit.SECONDS);
    this.defaultKey = defaultkey;
    this.jwksConnectTimeoutSeconds = jwksConnectTimeoutSeconds;
    this.jwksReadTimeoutSeconds = jwksReadTimeoutSeconds;
  }

  @SneakyThrows
  public JwtDecoder getDecoder() {
    try{
      if(defaultKey != null && defaultKey.length > 0) {
        return new CustumJwtDecoder(defaultKey);
      }
    } catch (Exception e) {
      log.info("Unable to create decoder with default key, so using the okta key generation");
    }
    JwtDecoder jwtDecoder = null;
    JWSKeySelector<SecurityContext> jwsKeySelector = null;
    URL jwksUrl = new URL(keysUrl);

    DefaultResourceRetriever resourceRetriever = new DefaultResourceRetriever(jwksConnectTimeoutSeconds, jwksReadTimeoutSeconds);
    RemoteJWKSet<SecurityContext> jwkSet = new RemoteJWKSet<>(jwksUrl, resourceRetriever, jwkSetCache);
    // Retry on key download exception
    jwsKeySelector =
        Failsafe.with(retryPolicy)
            .get(() -> JWSAlgorithmFamilyJWSKeySelector.fromJWKSource(jwkSet));
    DefaultJWTProcessor<SecurityContext> jwtProcessor = new DefaultJWTProcessor<>();
    jwtProcessor.setJWSKeySelector(jwsKeySelector);

    jwtDecoder = new NimbusJwtDecoder(jwtProcessor);
    return jwtDecoder;
  }
}
