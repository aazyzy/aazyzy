package ca.bnc.wealth.api.authorization.security.test;

import ca.bnc.wealth.api.authorization.security.*;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.authentication.AuthenticationManagerResolver;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;

@Configuration
@Profile("test")
@Slf4j
public class TestAuthConfiguration {

  @Value("${oauth2.system.createSystemTokenInLiveMode:false}")
  private boolean createSystemTokenInTestMode;

  @Bean
  public AuthTokenValidationFilter getAuthTokenValidationFilter() {
    return new TestAuthTokenValidationFilterImpl();
  }

  @Bean
  public BearerToken getBearerToken() {
    return new BearerToken();
  }

  @Bean
  JwtAuthenticationConverter jwtAuthenticationConverter() {
    final JwtAuthenticationConverter converter = new JwtAuthenticationConverter();
    return converter;
  }

  @Bean
  AuthenticationManagerResolver<HttpServletRequest> authenticationManagerResolver() {
    return request -> {
      TokenDecoder decoder = new TestAuthTokenDecoderImpl();
      AuthenticationProvider tokenAuthenticationProvider = new TestTokenAuthenticationProvider();
      return tokenAuthenticationProvider::authenticate;
    };
  }

  @Bean
  ScopeValidationFilter getScopeValidationFilter() {
    return new TestScopeValidationFilterImpl();
  }

  @Bean
  ResourceValidationFilter getResourceValidationFilter() {
    return new TestResourceValidationFilterImpl();
  }

  @Bean
  PermissionValidationFilter getPermissionValidationFilter() {
    return new TestPermissionValidationFilterImpl();
  }

  @Bean
  EnrichUserService getEnrichUserService() {
    return new TestEnrichUserServiceImpl();
  }
}
