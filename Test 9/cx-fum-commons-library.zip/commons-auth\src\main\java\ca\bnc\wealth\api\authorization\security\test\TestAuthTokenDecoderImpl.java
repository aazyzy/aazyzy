package ca.bnc.wealth.api.authorization.security.test;

import ca.bnc.wealth.api.authorization.security.TokenDecoder;
import ca.bnc.wealth.api.authorization.security.util.JwtUtil;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtException;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Slf4j
public class TestAuthTokenDecoderImpl implements TokenDecoder {

  /**
   * To be only used for local executions when you want to skip renewing the token intermittently.
   * This implementation skips both token validation and expiry checks
   *
   * @return
   */
  public JwtDecoder getDecoder() {
    log.info("!!!!!!!!!!!!USER TEST MODE. Token Validity and Expiry will not be checked!!!!!!!!!");
    JwtDecoder testDecoder =
        new JwtDecoder() {
          @SneakyThrows
          @Override
          public Jwt decode(String s) throws JwtException {

            Map<String, Object> claims = JwtUtil.extractClaims(s);
            Jwt.Builder builder =
                Jwt.withTokenValue(s)
                    .header("kid", "QuFOqXibL0b74ziml3Zbe96sOXJI2SiDdxe8de8edmw")
                    .header("alg", "RS256");
            claims.forEach(
                (key, value) -> {
                  switch (key) {
                    case "iss":
                      builder.issuer((String) value);
                      break;
                    case "sub":
                      builder.subject((String) value);
                      break;
                    case "aud":
                      builder.audience(Arrays.asList((String) value));
                      break;
                    case "exp":
                      builder.expiresAt(Instant.ofEpochSecond(Long.parseLong(value.toString())));
                      break;
                    case "nbf":
                      builder.notBefore(Instant.ofEpochSecond(Long.parseLong(value.toString())));
                      break;
                    case "iat":
                      builder.issuedAt(Instant.ofEpochSecond(Long.parseLong(value.toString())));
                      break;
                    case "jti":
                      builder.jti((String) value);
                      break;
                    default:
                      List claim = JwtUtil.stringToJsonArray(value);
                      if (claim != null) {
                        builder.claim(key, claim);
                      } else {
                        builder.claim(key, value);
                      }
                  }
                });
            return builder.build();
          }
        };
    return testDecoder;
  }
}
