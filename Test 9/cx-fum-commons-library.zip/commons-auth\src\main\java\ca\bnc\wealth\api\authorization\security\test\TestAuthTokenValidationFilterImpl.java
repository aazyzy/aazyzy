package ca.bnc.wealth.api.authorization.security.test;

import ca.bnc.wealth.api.authorization.enums.ErrorMessages;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.AuthTokenValidationFilter;
import ca.bnc.wealth.api.authorization.security.util.JwtUtil;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Map;
import java.util.Optional;
import java.util.Arrays;
import java.util.List;

/**
 * Test implementation of the AuthTokenValidation filter Supports the below scenarios- 1. Provide
 * the Access Token in Authorization header to use that to generate the Security User in the spring
 * context 2. Override the TestUserSingleton User instance with the custom User that will be then
 * injected into the Spring context 3. Set TestUserSingleton.IS_USER_UNAUTHORIZED to true to trigger
 * a 401-unauthorized error
 */
@Slf4j
public class TestAuthTokenValidationFilterImpl extends OncePerRequestFilter
    implements AuthTokenValidationFilter {

  @Value("${oauth2.user.secureZoneIds:JONESMA}")
  private List<String> secureZoneIds;

  @SneakyThrows
  @Override
  public void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain chain) {
    User user;
    Optional<Jwt> jwt = Optional.empty();
    // Scenario 1: Use the Authorization Bearer access token if its sent on the request
    try {
      jwt =
          Optional.of((Jwt) SecurityContextHolder.getContext().getAuthentication().getPrincipal());

    } catch (Exception e) {
      log.info(e.getMessage());
    }
    if (jwt.isPresent()) {
      log.trace("===========> ACCESS TOKEN");
      user = JwtUtil.createUserObject(jwt.get());
      if (this.secureZoneIds
          != null) { // If secure zone ids are provided in the spring config, use that
        user.setSecureZoneIds(this.secureZoneIds);
      } else { // Check if it's available in the access token
        Map claims = JwtUtil.extractClaims(jwt.get().getTokenValue());
        if (claims.containsKey("bngfSecureZoneId")) {
          String [] szIds = (String []) claims.get("bngfSecureZoneId");
          user.setSecureZoneIds(ArrayUtils.isNotEmpty(szIds) ? Arrays.asList(szIds) : null);
        }
      }

    } else {
      // Scenario 2:  Mock this implementation to override user object assigned to the Spring
      // security context
      log.trace("===========> USER OVERRIDE");
      user = TestUserSingleton.getTestUser();
    }

    // Scenario 3: Implementation to support 401 Unauthorized Error if required
    if (TestUserSingleton.USER_IS_UNAUTHORIZED) {
      log.trace("===========> USER UNAUTHORIZED");
      TestUserSingleton.USER_IS_UNAUTHORIZED = false;
      response.sendError(
          HttpServletResponse.SC_UNAUTHORIZED, ErrorMessages.INVALID_TOKEN.getValue());
    } else {
       SecurityContextHolder.getContext()
          .setAuthentication(
              new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>()));
      chain.doFilter(request, response);
    }
  }
}
