package ca.bnc.wealth.api.authorization.security.test;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.EnrichUserService;
import java.util.HashMap;

public class TestEnrichUserServiceImpl implements EnrichUserService {

  @Override
  public HashMap enrichWithUserConfig(String idpSubject) {
    return new HashMap();
  }
}
