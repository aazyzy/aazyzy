package ca.bnc.wealth.api.authorization.security.test;

import ca.bnc.wealth.api.authorization.security.ResourceValidationFilter;
import lombok.SneakyThrows;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class TestResourceValidationFilterImpl extends OncePerRequestFilter implements ResourceValidationFilter {
    @SneakyThrows
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        filterChain.doFilter(request, response);
    }
}
