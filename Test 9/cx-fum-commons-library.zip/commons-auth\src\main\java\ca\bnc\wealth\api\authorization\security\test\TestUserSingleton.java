package ca.bnc.wealth.api.authorization.security.test;

import ca.bnc.wealth.api.authorization.model.User;
import lombok.extern.slf4j.Slf4j;

/** Singleton class to mock Spring Authentication Principal */
@Slf4j
public final class TestUserSingleton {
  private static User userInstance;
  public static boolean USER_IS_UNAUTHORIZED = false;

  TestUserSingleton() {}

  public static User getTestUser() {
    if (userInstance == null) {
      userInstance = new User();
    }
    return userInstance;
  }

  public static void setTestUser(User user) {
    userInstance = user;
  }
}
