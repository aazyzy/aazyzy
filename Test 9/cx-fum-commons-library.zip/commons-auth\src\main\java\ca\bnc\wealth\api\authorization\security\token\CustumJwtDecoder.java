package ca.bnc.wealth.api.authorization.security.token;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.nimbusds.jwt.JWTParser;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.RSAPublicKeySpec;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.oauth2.jwt.BadJwtException;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;

public class CustumJwtDecoder implements JwtDecoder {

  private final Log logger = LogFactory.getLog(this.getClass());

  private List<JWTVerifier> jwtVerifiers = new ArrayList<>();
  private final String[] publicKeys;


  public CustumJwtDecoder(String[] publicKeys) {
    this.publicKeys = publicKeys;
    init();
  }

  @SneakyThrows
  private void init() {
    for(int i =0 ;i<publicKeys.length;i++) {
      BigInteger modulus = new BigInteger(1, Base64.getUrlDecoder().decode(publicKeys[i]));
      BigInteger exponent = new BigInteger(1, Base64.getUrlDecoder().decode("AQAB"));
      RSAPublicKeySpec rsaPublicKeySpec = new RSAPublicKeySpec(modulus, exponent);
      KeyFactory keyFactory = KeyFactory.getInstance("RSA");
      PublicKey publicKey = keyFactory.generatePublic(rsaPublicKeySpec);
      Algorithm alg = Algorithm.RSA256((RSAPublicKey) publicKey, null);
      jwtVerifiers.add(JWT.require(alg).build());
    }
  }

  @SneakyThrows
  @Override
  public Jwt decode(String token) {
    for (int i = 0; i < jwtVerifiers.size(); i++) {
      try {
        jwtVerifiers.get(i).verify(token);
        break;
      } catch (Exception e) {
        if (i == publicKeys.length - 1) {
          throw e;
        }
      }
    }
    com.nimbusds.jwt.JWT jwt = JWTParser.parse(token);
    return createJwt(token, jwt);
  }

  private Jwt createJwt(String token, com.nimbusds.jwt.JWT parsedJwt) {
    try {
      Map<String, Object> headers = new LinkedHashMap(parsedJwt.getHeader().toJSONObject());
      Map<String, Object> claims = parsedJwt.getJWTClaimsSet().getClaims();
      Jwt.Builder finalJwt = Jwt.withTokenValue(token)
          .headers(h -> h.putAll(headers))
          .claims(c -> c.putAll(claims));
      finalJwt.expiresAt(((Date) claims.get("exp")).toInstant());
      finalJwt.issuedAt(((Date) claims.get("iat")).toInstant());
      return finalJwt.build();
    } catch (Exception var8) {
      this.logger.trace("Failed to process JWT", var8);
      if (var8.getCause() instanceof ParseException) {
        throw new BadJwtException(
            String.format("An error occurred while attempting to decode the Jwt: %s",
                "Malformed payload"), var8);
      } else {
        throw new BadJwtException(
            String.format("An error occurred while attempting to decode the Jwt: %s",
                var8.getMessage()), var8);
      }
    }
  }
}
