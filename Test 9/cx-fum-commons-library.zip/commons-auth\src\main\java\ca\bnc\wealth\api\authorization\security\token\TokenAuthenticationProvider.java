package ca.bnc.wealth.api.authorization.security.token;

import com.auth0.jwt.exceptions.SignatureVerificationException;
import dev.failsafe.Failsafe;
import dev.failsafe.RetryPolicy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.BearerTokenAuthenticationToken;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;

@Slf4j
public class TokenAuthenticationProvider implements AuthenticationProvider {

  private String decoderName;
  private JwtDecoder tokenDecoder;
  RetryPolicy<Object> retryPolicy;
  @Autowired JwtAuthenticationConverter jwtAuthenticationConverter;

  public TokenAuthenticationProvider(
      String decoderName, JwtDecoder tokenDecoder, RetryPolicy retryPolicy) {
    this.tokenDecoder = tokenDecoder;
    this.decoderName = decoderName;
    this.retryPolicy = retryPolicy;
  }

  public Authentication authenticate(Authentication authentication) throws AuthenticationException {
    AbstractAuthenticationToken token = null;
    try {
      log.trace("Token validated by : " + decoderName);
      Jwt jwt =
          Failsafe.with(retryPolicy)
              .get(
                  () ->
                      this.tokenDecoder.decode(
                          ((BearerTokenAuthenticationToken) authentication).getToken()));
      token = jwtAuthenticationConverter.convert(jwt);
    } catch (Exception e) {
      if(e instanceof SignatureVerificationException) {
        log.info("CRITICAL: Error in token signature verification, update the latest keys", e);
      }
      log.info(
          String.format("Token validation failed for %s : %s", this.decoderName, e.getMessage()));
      throw e;
    }
    return token;
  }

  @Override
  public boolean supports(Class<?> aClass) {
    return aClass.equals(UsernamePasswordAuthenticationToken.class);
  }
}
