package ca.bnc.wealth.api.authorization.security.token;

import ca.bnc.wealth.api.authorization.system.token.config.SystemTokenProperty;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Configuration
@ConfigurationProperties(prefix = "oauth2")
@Data
public class TokenValidatorConfigLoader {
  private Map<String, TokenValidatorProperty> tokenValidators;
  private long jwksCacheLifeSpanSeconds;
  private long jwksRefreshTimeSeconds;
  private long jwksFailureRetryIntervalSeconds;
  private int jwksFailureRetryLimit;

  @Value("${oauth2.systemTokenCache.ttl:55}")
  private int systemTokenCacheTtl;

  @Value("${feign.client.config.default.connectTimeout:2000}")
  private int jwksConnectTimeoutSeconds;

  @Value("${feign.client.config.default.readTimeout:2000}")
  private int jwksReadTimeoutSeconds;

  private Map<String, SystemTokenProperty> systemTokens;
}
