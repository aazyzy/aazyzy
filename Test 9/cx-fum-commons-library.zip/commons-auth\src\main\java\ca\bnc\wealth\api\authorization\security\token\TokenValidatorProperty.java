package ca.bnc.wealth.api.authorization.security.token;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TokenValidatorProperty {
  private String keyUrl;
  private String issuer;
  private String[] defaultKey;
}
