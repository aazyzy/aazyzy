package ca.bnc.wealth.api.authorization.security.token;

import ca.bnc.wealth.api.authorization.security.impl.TokenDecoderImpl;
import ca.bnc.wealth.api.authorization.security.util.Constants;
import ca.bnc.wealth.api.authorization.security.util.JwtUtil;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

@Service
@EnableConfigurationProperties
@AllArgsConstructor
@Slf4j
public class TokenValidatorService {

  @Autowired private TokenValidatorConfigLoader tokenValidatorConfigLoader;

  @Autowired private final ConfigurableListableBeanFactory beanFactory;
  @Autowired private final AutowireCapableBeanFactory factory;
  private final Map<String, String> decoderMap = new ConcurrentHashMap<>();

  @Autowired JwtUtil jwtUtil;

  @PostConstruct
  @SneakyThrows
  public void registerValidators() {
    for (Map.Entry<String, TokenValidatorProperty> entry :
        tokenValidatorConfigLoader.getTokenValidators().entrySet()) {
      String validator = entry.getKey();
      TokenValidatorProperty validatorProperty = entry.getValue();
      String validatorServiceName = Constants.TOKEN_VALIDATOR_SERVICE_PREFIX + validator;
      log.trace(
          String.format(
              "Initializing token validator %s for issuer %s",
              validatorServiceName, validatorProperty.getIssuer()));
      JwtDecoder decoder =
          new TokenDecoderImpl(
                  validatorProperty.getKeyUrl(),
                  tokenValidatorConfigLoader.getJwksCacheLifeSpanSeconds(),
                  tokenValidatorConfigLoader.getJwksRefreshTimeSeconds(),
                  jwtUtil.getJwksRetryPolicy(),
                  validatorProperty.getDefaultKey(),
                  tokenValidatorConfigLoader.getJwksConnectTimeoutSeconds(),
                  tokenValidatorConfigLoader.getJwksReadTimeoutSeconds())
              .getDecoder();
      AuthenticationProvider tokenAuthenticationProvider =
          new TokenAuthenticationProvider(
              validatorServiceName, decoder, jwtUtil.getJwksRetryPolicy());
      factory.autowireBean(tokenAuthenticationProvider);
      factory.initializeBean(tokenAuthenticationProvider, validatorServiceName);
      beanFactory.registerSingleton(validatorServiceName, tokenAuthenticationProvider);
      decoderMap.put(validatorProperty.getIssuer(), validatorServiceName);
    }
  }

  public AuthenticationProvider getAuthenticationProvider(String issuer) {
    log.trace("Getting authentication for " + issuer);
    String validatorServiceBean = decoderMap.get(issuer);
    AuthenticationProvider authenticationProvider =
        beanFactory.getBean(decoderMap.get(issuer), AuthenticationProvider.class);
    return Optional.of(authenticationProvider).orElseThrow(RuntimeException::new);
  }
}
