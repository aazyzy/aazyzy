package ca.bnc.wealth.api.authorization.security.util;

import jakarta.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.Objects;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerExecutionChain;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;
import org.springframework.web.util.ServletRequestPathUtils;

@Component
@Slf4j
public class ClassUtil {

  @Autowired
  private ApplicationContext appContext;

  @SneakyThrows
  public Pair<String, Method> getApiMethod(HttpServletRequest request) {
    if (!ServletRequestPathUtils.hasParsedRequestPath(request)) {
      ServletRequestPathUtils.parseAndCache(request);
    }
    Method method = null;
    String className = null;
    RequestMappingHandlerMapping requestMappingHandlerMapping =
        (RequestMappingHandlerMapping) appContext.getBean("requestMappingHandlerMapping");
    try {
      HandlerExecutionChain handlerExeChain = requestMappingHandlerMapping.getHandler(request);
      HandlerMethod handlerMethod = (HandlerMethod) Objects.requireNonNull(handlerExeChain).getHandler();
      className = handlerMethod.getBean().getClass().getSimpleName();
      method = handlerMethod.getMethod();
    } catch (NullPointerException e) {
      log.info(
          "ERROR : Error getting a valid request handler for {}",
          request.getContextPath() + request.getRequestURI());
      log.info("Registered handlers found are :");
      requestMappingHandlerMapping
          .getHandlerMethods()
          .forEach((k, v) -> log.info(k.toString()));
      throw e;
    }
    return new ImmutablePair<>(className, method);
  }
}
