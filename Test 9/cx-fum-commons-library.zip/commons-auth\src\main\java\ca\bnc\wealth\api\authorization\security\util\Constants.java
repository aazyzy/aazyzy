package ca.bnc.wealth.api.authorization.security.util;

public class Constants {
  public static final String TOKEN_VALIDATOR_SERVICE_PREFIX = "tokenValidatorService-";
  public static final String CAFFEINE_SYSTEM_TOKEN_CACHE = "genericSystemTokenCache";
  public static final String SYSTEM_TOKEN_SERVICE_PREFIX = "systemTokenService";

  private Constants() {
    throw new IllegalStateException("Utility class");
  }
}
