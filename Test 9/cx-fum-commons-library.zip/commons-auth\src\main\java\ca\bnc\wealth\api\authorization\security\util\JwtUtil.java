package ca.bnc.wealth.api.authorization.security.util;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.token.TokenValidatorConfigLoader;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.nimbusds.jose.RemoteKeySourceException;
import dev.failsafe.RetryPolicy;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

import feign.Logger;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;

@Component
@Slf4j
public class JwtUtil {

  // Jackson 2 defaults: what the Spring Boot 3 line's new ObjectMapper() read
  private static final ObjectMapper CLAIMS_MAPPER = JsonMapper.builderWithJackson2Defaults().build();

  @Value("${oauth2.tokenValidators.employee.issuer:#{null}}")
  private String employeeIssuer;

  @Value("${oauth2.tokenValidators.system.issuer:#{null}}")
  private String systemIssuer;

  @Value(
      "${oauth2.okta.retryOnJwksErrors:Couldn't retrieve remote JWK set,Another algorithm expected,no matching key(s) found}")
  private String retryOnJwksErrors;

  @Value("${oauth2.jwksFailureRetryIntervalSeconds:5}")
  private long jwksFailureRetryIntervalSeconds;

  @Value("${oauth2.jwksFailureRetryLimit:5}")
  private int jwksFailureRetryLimit;

  /**
   * Converts a Jwt object to a Authorization.User object that gets included in the Spring security
   * context principal
   *
   * @param jwt
   * @return
   */
  public static User createUserObject(Jwt jwt)  {
    User user = new User();
    if (jwt.getClaims().get("scp") != null) {
      user.setRoles(jwt.getClaimAsStringList("scp"));
    }
    if (jwt.getClaims().get("groups") != null) {
      user.setGroups(jwt.getClaimAsStringList("groups"));
    }
    if (jwt.getClaims().get("sub") != null) {
      String subId = jwt.getClaims().get("sub").toString();
      user.setIdpSubject(subId);
    }
    if (jwt.getClaims().get("uid") != null) {
      String uid = jwt.getClaims().get("uid").toString();
      user.setIdpUserId(uid);
    }
    if (jwt.getClaims().get("bngfSecureZoneId") != null) {
      user.setSecureZoneIds(jwt.getClaimAsStringList("bngfSecureZoneId"));
    }
    if (jwt.getTokenValue() != null) {
      user.setJwtToken(jwt.getTokenValue());
    }
    return user;
  }

  public static User enrichUserObject(Map userConfiguration, User user) {
    user.setEmail((String) userConfiguration.get("email"));
    user.setUsername((String) userConfiguration.get("username"));
    user.setFirstName((String) userConfiguration.get("firstName"));
    user.setLastName((String) userConfiguration.get("lastName"));
    user.setPreferredLanguage((String) userConfiguration.get("preferredLanguage"));
    user.setOssUserId((String) userConfiguration.get("ossUserId"));
    user.setOssGroupId((String) userConfiguration.get("ossGroupId"));
    user.setUserConfigurationId((Integer) userConfiguration.get("userConfigurationId"));
    user.setFirmId((String) userConfiguration.get("firmId"));
    return user;
  }

  public static User createEmptyUser() {
    return new User();
  }

  /**
   * Converts a json array string to a Java List
   *
   * @param jsonArray
   * @return
   */
  public static List<String> jsonArrayToList(String jsonArray) throws JacksonException {
    if (jsonArray == null) {
      return Collections.emptyList();
    }
    List<String> claimsList = null;
    try {
      claimsList =
          CLAIMS_MAPPER.readValue(
              jsonArray,
              CLAIMS_MAPPER.getTypeFactory().constructCollectionType(List.class, String.class));

    } catch (JacksonException e) {
      log.info("Unable to convert {} to list : {}", jsonArray, e.getMessage());
      throw e;
    }
    return claimsList;
  }

  /**
   * Extracts the claims from a Jwt token payload into a Map
   *
   * @param token
   * @return
   * @throws JacksonException
   */
  public static Map<String, Object> extractClaims(String token) throws JacksonException {
    Base64.Decoder decoder = Base64.getUrlDecoder();
    String[] chunks = token.split("\\.");
    if (chunks.length < 2) {
      return Collections.emptyMap();
    }
    String payload = new String(decoder.decode(chunks[1]));
    return CLAIMS_MAPPER.readValue(payload, Map.class);
  }

  /**
   * Converts certain json array type claim to properly formatted Json Array String object for
   * cleaner parsing
   *
   * @param claim
   * @return
   */
  public static List<String> stringToJsonArray(Object claim) {
    try {
      List<Object> _items = (ArrayList<Object>) claim;
      // Convert to a json friendly string array form for the jwt decoder
      List<String> items =
          _items.stream()
              .map(v -> (String) v)
              .map(v -> "\"" + v + "\"")
              .collect(Collectors.toList());
      return items;
    } catch (Exception e) {
      // Not a fatal error if the string cannot be converted. Return null and continue
    }
    return Collections.emptyList();
  }

  // System token if it does not have an uid(User ID Identifier) claim field
  @SneakyThrows
  public boolean isSystemToken(Jwt jwt) {
    URI systemIssuerUri = new URI(systemIssuer);
    if (jwt != null && jwt.getIssuer()!=null) {
      URI jwtIssuerUri = new URI(jwt.getIssuer().toString());
      return systemIssuerUri.equals(jwtIssuerUri);
    }
    return false;
  }

  @SneakyThrows
  public boolean isEmployeeToken(Jwt jwt) {
    URI employeeIssuerUrl = new URI(employeeIssuer);
    if (jwt != null && jwt.getIssuer()!=null) {
      URI jwtIssuerUri = new URI(jwt.getIssuer().toString());
      return jwtIssuerUri.equals(employeeIssuerUrl);
    }
    return false;
  }

  @SneakyThrows
  public String getIssuer(String jwtToken) {
    return extractClaims(jwtToken).entrySet().stream()
        .filter(e -> e.getKey().equals("iss"))
        .map(e -> (String) e.getValue())
        .findFirst()
        .orElseThrow(() -> new RuntimeException("No issuer found for the provided JWT token"));
  }

  public RetryPolicy<Object> getJwksRetryPolicy() {
    return RetryPolicy.builder()
        .handle(RemoteKeySourceException.class, IOException.class)
        /**
         * Retry on any errors that match the retry exceptions like Key retrieve error on retired
         * keys exception
         */
        .handleIf(
            e ->
                Arrays.stream(this.retryOnJwksErrors.split(","))
                    .map(String::toLowerCase)
                    .anyMatch(e.getMessage().toLowerCase()::contains))
        .withDelay(Duration.ofSeconds(this.jwksFailureRetryIntervalSeconds))
        .withMaxRetries(this.jwksFailureRetryLimit)
        .onSuccess(e -> log.trace("successfull on the attempt: " + e.getAttemptCount()))
        .onFailedAttempt(e -> log.info("Token decode failed : {}", e.getLastException()))
        .onRetry(e -> log.info("Failure #{}...retrying", e.getAttemptCount()))
        .build();
  }
  public String cleanRsaKeys(String keyData){
    return keyData
            .replace("-----BEGIN PRIVATE KEY-----", "")
            .replace("-----END PRIVATE KEY-----", "")
            .replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .replaceAll("\s", "")
            .strip();
  }
  public String generateJwtToken(
      String publicKey, String privateKey, String issuer, String subject, String audience)
      throws NoSuchAlgorithmException, InvalidKeySpecException {
    Instant now = Instant.now();
    KeyFactory kf = KeyFactory.getInstance("RSA");

    PKCS8EncodedKeySpec keySpecPKCS8 =
        new PKCS8EncodedKeySpec(Base64.getDecoder().decode(cleanRsaKeys(privateKey)));
    RSAPrivateKey rsaPrivateKey = (RSAPrivateKey) kf.generatePrivate(keySpecPKCS8);

    X509EncodedKeySpec keySpecX509 =
        new X509EncodedKeySpec(Base64.getDecoder().decode(cleanRsaKeys(publicKey)));
    RSAPublicKey rsaPublicKey = (RSAPublicKey) kf.generatePublic(keySpecX509);
    String jwt =
        JWT.create()
            .withAudience(audience)
            .withIssuer(issuer)
            .withSubject(subject)
            .withIssuedAt(now)
            .withExpiresAt(Date.from(now.plus(5L, ChronoUnit.MINUTES)))
            .sign(Algorithm.RSA256(rsaPublicKey, rsaPrivateKey));
    return jwt;
  }

  public Logger.Level getFeignLoggingLevel(String feignLoggingLevel){
    if(feignLoggingLevel == null)
      return Logger.Level.BASIC;
    return switch (feignLoggingLevel){
      case "NONE" -> Logger.Level.NONE;
      case "HEADERS" -> Logger.Level.HEADERS;
      case "FULL" -> Logger.Level.FULL;
      default -> Logger.Level.BASIC;
    };
  }

  /**
   * Checks if a JWT token string is expired by comparing the 'exp' claim with the current time.
   * @param tokenString the JWT token as a string
   * @return true if the token is expired, false otherwise
   */
  public static boolean isTokenExpired(String tokenString) {
    try {
      Map<String, Object> claims = extractClaims(tokenString);
      Object expObj = claims.get("exp");
      if (expObj == null) {
        log.info("No 'exp' claim found in JWT token");
        return true;
      }
      long expirationTime;
      if (expObj instanceof Number) {
        expirationTime = ((Number) expObj).longValue();
      } else {
        log.info("Invalid 'exp' claim type: {}", expObj.getClass());
        return true;
      }
      long currentTimeSeconds = Instant.now().getEpochSecond();
      return currentTimeSeconds >= expirationTime;
    } catch (Exception e) {
      log.info("Error checking token expiration: {}", e.getMessage());
      return true;
    }
  }
}
