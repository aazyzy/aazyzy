package ca.bnc.wealth.api.authorization.security.util;

import java.util.Base64;

public class PasswordUtil {

  public static String basicAuthenticationEncode(String username, String password) {
    byte[] encodedBytes = Base64.getEncoder().encode((username + ":" + password).getBytes());
    return "Basic " + new String(encodedBytes);
  }
}
