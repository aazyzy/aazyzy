package ca.bnc.wealth.api.authorization.system.token;

import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import ca.bnc.wealth.api.authorization.security.util.Constants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class SystemTokenFactory {

  private final Map<String, SystemTokenService> map = new ConcurrentHashMap<>();
  private final Environment environment;

  @Autowired
  private ConfigurableListableBeanFactory beanFactory;

  public String getSystemToken(String service) {
    String tokenService = Constants.SYSTEM_TOKEN_SERVICE_PREFIX + service;
    SystemTokenService systemTokenService = map.computeIfAbsent(tokenService,
        k -> beanFactory.getBean(tokenService, SystemTokenService.class));
    return systemTokenService.getSystemToken();
  }


  public String getBearerToken(String service) {
    if (Arrays.asList(environment.getActiveProfiles()).contains("test")) {
      return "Bearer dummy_value_for_test_pofile";
    }
    return "Bearer " + this.getSystemToken(service);
  }
}
