package ca.bnc.wealth.api.authorization.system.token;

public interface SystemTokenService {

  String getSystemToken();
}
