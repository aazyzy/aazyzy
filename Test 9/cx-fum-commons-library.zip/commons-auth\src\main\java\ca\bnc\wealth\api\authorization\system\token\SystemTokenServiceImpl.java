package ca.bnc.wealth.api.authorization.system.token;

import ca.bnc.wealth.api.authorization.exception.SystemTokenException;
import ca.bnc.wealth.api.authorization.feign.client.SystemTokenConfigClient;
import ca.bnc.wealth.api.authorization.feign.client.SystemTokenJwkConfigClient;
import ca.bnc.wealth.api.authorization.model.SystemTokenJwkRequest;
import ca.bnc.wealth.api.authorization.model.SystemTokenRequest;
import ca.bnc.wealth.api.authorization.security.util.Constants;
import ca.bnc.wealth.api.authorization.security.util.JwtUtil;
import ca.bnc.wealth.api.authorization.security.util.PasswordUtil;
import ca.bnc.wealth.api.authorization.system.token.config.SystemTokenProperty;
import java.util.HashMap;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.http.ResponseEntity;

@Slf4j
@AllArgsConstructor
public class SystemTokenServiceImpl implements SystemTokenService {

  private final String serviceName;
  private final CaffeineCacheManager caffeineCacheManager;
  private final SystemTokenConfigClient systemTokenFeignClient;
  private final SystemTokenJwkConfigClient systemTokenJwkConfigClient;
  private final SystemTokenProperty systemTokenProperty;

  private static final String CLIENT_ASSERTION_TYPE =
      "urn:ietf:params:oauth:client-assertion-type:jwt-bearer";
  public static final String ACCESS_TOKEN = "access_token";
  private JwtUtil jwtUtil;

  @Override
  public String getSystemToken() {
    return getFromCache()
        .orElseGet(
            () -> {
              if (systemTokenProperty.getSecret() != null) {
                return getClientSecretBasedSystemToken();
              } else if (systemTokenProperty.getRsaPrivateKey() != null
                  && systemTokenProperty.getRsaPublicKey() != null) {
                return getJwkBasedSystemToken();
              } else {
                throw new SystemTokenException(
                    "CRITICAL: Either the client secret or RSA keys must be defined to get system tokens");
              }
            });
  }

  @SneakyThrows
  public String getClientSecretBasedSystemToken() {
    log.trace("Getting system token based on client secret for {}", serviceName);
    String basicAuthentication =
        PasswordUtil.basicAuthenticationEncode(
            systemTokenProperty.getClientId(), systemTokenProperty.getSecret());
    SystemTokenRequest systemTokenRequest = new SystemTokenRequest();
    systemTokenRequest.setGrant_type("client_credentials");
    systemTokenRequest.setScope(systemTokenProperty.getScopes());
    String token = null;
    try {
      ResponseEntity<Object> systemTokenResponse =
          systemTokenFeignClient.getSystemToken(basicAuthentication, systemTokenRequest);
      token = extractToken(systemTokenResponse);
    } catch (Exception e) {
      log.info("CRITICAL: Unable to get a system token", e.getMessage());
      throw e;
    }
    return token;
  }

  @SneakyThrows
  public String getJwkBasedSystemToken() {
    log.trace("Getting system token based on rsa key for {}", serviceName);
    SystemTokenJwkRequest systemTokenJwkRequest = new SystemTokenJwkRequest();
    systemTokenJwkRequest.setGrant_type("client_credentials");
    systemTokenJwkRequest.setScope(systemTokenProperty.getScopes());
    systemTokenJwkRequest.setClient_assertion_type(CLIENT_ASSERTION_TYPE);
    String token = null;

    try {
      String jwtToken =
          jwtUtil.generateJwtToken(
              systemTokenProperty.getRsaPublicKey(),
              systemTokenProperty.getRsaPrivateKey(),
              systemTokenProperty.getClientId(),
              systemTokenProperty.getClientId(),
              systemTokenProperty.getAudience());
      systemTokenJwkRequest.setClient_assertion(jwtToken);

      ResponseEntity<Object> systemTokenResponse =
          systemTokenJwkConfigClient.getSystemToken(systemTokenJwkRequest);
      token = extractToken(systemTokenResponse);
    } catch (Exception e) {
      log.info("CRITICAL: Unable to get a system token", e.getMessage());
      throw e;
    }

    return token;
  }

  private String extractToken(ResponseEntity<Object> systemTokenResponse) {
    HashMap systemTokenBody = (HashMap) systemTokenResponse.getBody();
    String token = null;
    if (systemTokenBody != null && systemTokenBody.containsKey(ACCESS_TOKEN)) {
      token = (String) systemTokenBody.get(ACCESS_TOKEN);
      setToCache(token);
    } else {
      log.info("Unable to set the system token from okta response " + systemTokenBody);
      throw new SystemTokenException(
          "CRITICAL: Unable to set the system token from token response");
    }
    return token;
  }

  private void setToCache(String token) {
    Cache cache = caffeineCacheManager.getCache(Constants.CAFFEINE_SYSTEM_TOKEN_CACHE);
    if (cache == null) {
      log.trace("Cache is null. Unable to store token for service: {}", serviceName);
      return;
    }
    cache.put(serviceName, token);
  }

  Optional<String> getFromCache() {
    Cache cache = caffeineCacheManager.getCache(Constants.CAFFEINE_SYSTEM_TOKEN_CACHE);
    try {
      if (cache != null && cache.get(serviceName) != null && cache.get(serviceName).get() != null) {
        String jwt = cache.get(serviceName).get().toString();
        
        if (JwtUtil.isTokenExpired(jwt)) {
          log.trace("Cached JWT token is expired for service: {}", serviceName);
          cache.evict(serviceName);
         return Optional.ofNullable(null);
        }
        return Optional.ofNullable(jwt);
      }
    } catch (Exception exception) {
      log.trace("Token not found in cache for {}", serviceName);
    }
    return Optional.ofNullable(null);
  }
}
