package ca.bnc.wealth.api.authorization.system.token.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SystemTokenProperty {

  private String tokenUrl;
  private String clientId;
  private String audience;
  private String secret;
  private String scopes;
  private String rsaPublicKey;
  private String rsaPrivateKey;
  private int maxRetryAttempts = 5;
  private int retryInterval = 1000;

  // SET TO ONE OF NONE, BASIC,HEADERS,FULL
  private String feignLoggingLevel = "BASIC";
}
