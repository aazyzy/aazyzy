package ca.bnc.wealth.api.authorization.system.token.config;

import ca.bnc.wealth.api.authorization.feign.client.SystemTokenConfigClient;
import ca.bnc.wealth.api.authorization.feign.client.SystemTokenJwkConfigClient;
import ca.bnc.wealth.api.authorization.feign.config.FeignCodecs;
import ca.bnc.wealth.api.authorization.security.FeignErrorDecoder;
import ca.bnc.wealth.api.authorization.security.token.TokenValidatorConfigLoader;
import ca.bnc.wealth.api.authorization.security.util.Constants;
import ca.bnc.wealth.api.authorization.security.util.JwtUtil;
import ca.bnc.wealth.api.authorization.system.token.SystemTokenServiceImpl;
import com.github.benmanes.caffeine.cache.Caffeine;
import feign.Feign;
import feign.Retryer;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;
import jakarta.annotation.PostConstruct;
import java.util.concurrent.TimeUnit;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.context.annotation.Configuration;
import tools.jackson.databind.json.JsonMapper;

@Configuration
@EnableConfigurationProperties
@AllArgsConstructor
@Slf4j
public class SystemTokenServiceLoader {

  private final TokenValidatorConfigLoader tokenValidatorConfigLoader;
  private final ConfigurableListableBeanFactory beanFactory;

  private final JsonMapper jsonMapper;

  @PostConstruct
  public void registerBeans() {
    CaffeineCacheManager cacheManager = new CaffeineCacheManager("genericSystemTokenCache");
    cacheManager.setCaffeine(
        Caffeine.newBuilder()
            .maximumSize(tokenValidatorConfigLoader.getSystemTokens().size())
            .expireAfterWrite(
                tokenValidatorConfigLoader.getSystemTokenCacheTtl(), TimeUnit.MINUTES));
    JwtUtil jwtUtil = new JwtUtil();
    tokenValidatorConfigLoader
        .getSystemTokens()
        .forEach(
            (serviceName, systemTokenProperty) -> {
              String systemTokenServiceName = Constants.SYSTEM_TOKEN_SERVICE_PREFIX + serviceName;
              log.trace("SYSTEM TOKEN: Instantiating system token for {}", serviceName);
              SystemTokenConfigClient systemTokenFeignClient = getFeignClient(systemTokenProperty);
              SystemTokenJwkConfigClient systemTokenJwkConfigClient =
                  getJwkFeignClient(systemTokenProperty);
              SystemTokenServiceImpl systemTokenService =
                  new SystemTokenServiceImpl(
                      systemTokenServiceName,
                      cacheManager,
                      systemTokenFeignClient,
                      systemTokenJwkConfigClient,
                      systemTokenProperty,
                      jwtUtil);
              beanFactory.initializeBean(systemTokenService, systemTokenServiceName);
              beanFactory.registerSingleton(systemTokenServiceName, systemTokenService);
            });
  }

  private SystemTokenConfigClient getFeignClient(SystemTokenProperty property) {
    JwtUtil jwtUtil = new JwtUtil();
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .decoder(new ResponseEntityDecoder(FeignCodecs.jsonDecoder()))
        .retryer(
            new Retryer.Default(
                property.getRetryInterval(),
                TimeUnit.SECONDS.toMillis(100),
                property.getMaxRetryAttempts()))
        .errorDecoder(new FeignErrorDecoder())
        .logger(new Slf4jLogger(SystemTokenConfigClient.class))
        .logLevel(jwtUtil.getFeignLoggingLevel(property.getFeignLoggingLevel()))
        .target(SystemTokenConfigClient.class, property.getTokenUrl());
  }

  private SystemTokenJwkConfigClient getJwkFeignClient(SystemTokenProperty property) {
    JwtUtil jwtUtil = new JwtUtil();
    return Feign.builder()
        .client(new OkHttpClient())
        .contract(new SpringMvcContract())
        .encoder(FeignCodecs.jsonEncoder(jsonMapper))
        .decoder(new ResponseEntityDecoder(FeignCodecs.jsonDecoder()))
        .retryer(
            new Retryer.Default(
                property.getRetryInterval(),
                TimeUnit.SECONDS.toMillis(100),
                property.getMaxRetryAttempts()))
        .errorDecoder(new FeignErrorDecoder())
        .logger(new Slf4jLogger(SystemTokenJwkConfigClient.class))
        .logLevel(jwtUtil.getFeignLoggingLevel(property.getFeignLoggingLevel()))
        .target(SystemTokenJwkConfigClient.class, property.getTokenUrl());
  }
}
