package ca.bnc.wealth.api.authorization;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestConfiguration {}
