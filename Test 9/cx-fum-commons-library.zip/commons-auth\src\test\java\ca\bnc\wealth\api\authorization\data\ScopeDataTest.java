package ca.bnc.wealth.api.authorization.data;

import ca.bnc.wealth.api.authorization.security.util.DisablePermissionCheck;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

public class ScopeDataTest {

  @Operation(
      security = {
        @SecurityRequirement(
            name = "permissions",
            scopes = {"moe:view_firms"}),
        @SecurityRequirement(
            name = "roles",
            scopes = {"wealth:cx-firm:viewer"}),
        @SecurityRequirement(
            name = "system-access",
            scopes = {"wealth:cx-firm:access"})
      })
  void method1() {}

  @Operation(
      security = {
        @SecurityRequirement(
            name = "permissions",
            scopes = {"moe:view_firms"}),
        @SecurityRequirement(
            name = "roles",
            scopes = {"wealth:cx-firm:editor"}),
        @SecurityRequirement(
            name = "system-access",
            scopes = {"wealth:cx-firm:access"})
      })
  void method2() {}

  @Operation(
      security = {
        @SecurityRequirement(
            name = "permissions",
            scopes = {"moe:view_firms"}),
        @SecurityRequirement(
            name = "roles",
            scopes = {"wealth:cx-firm:viewer"}),
        @SecurityRequirement(
            name = "system-access",
            scopes = {"wealth:cx-firm:access"})
      })
  void method3() {}

  @Operation(
      security = {
        @SecurityRequirement(
            name = "permissions",
            scopes = {"moe:view_firms"}),
        @SecurityRequirement(
            name = "roles",
            scopes = {"wealth:cx-firm:viewer_Test"}),
        @SecurityRequirement(
            name = "system-access",
            scopes = {"wealth:cx-firm:access_Test"})
      })
  void method4() {}

  @Operation(
      security = {
        @SecurityRequirement(
            name = "permissions",
            scopes = {"access-control:view_firms"}),
        @SecurityRequirement(
            name = "roles",
            scopes = {"wealth:cx-firm-conf:viewer"}),
        @SecurityRequirement(
            name = "system-access",
            scopes = {"wealth:cx-firm:access"})
      })
  void viewer_access() {}

  @Operation(
      security = {
        @SecurityRequirement(
            name = "permissions",
            scopes = {"access-control:view_firms", "access-control:edit_firms"}),
        @SecurityRequirement(
            name = "roles",
            scopes = {"wealth:cx-firm-conf:viewer"}),
        @SecurityRequirement(
            name = "system-access",
            scopes = {"wealth:cx-firm:access"})
      })
  void editor_access() {}

  @Operation(
      security = {
        @SecurityRequirement(
            name = "permissions",
            scopes = {"moe:edit_orders"}),
        @SecurityRequirement(
            name = "roles",
            scopes = {"wealth:cx-firm-conf:viewer"}),
        @SecurityRequirement(
            name = "system-access",
            scopes = {"wealth:cx-firm:access"})
      })
  @DisablePermissionCheck
  void permission_check_disabled() {}

  @Operation(
      security = {
          @SecurityRequirement(
              name = "permissions",
              scopes = {"moe:edit_orders"}),
          @SecurityRequirement(
              name = "roles",
              scopes = {"wealth:cx-firm-conf:viewer"}),
          @SecurityRequirement(
              name = "system-access",
              scopes = {"wealth:cx-firm:access"}),
          @SecurityRequirement(
              name = "resources",
              scopes = {"data_access  firm_level_access"})
      })
  void resourceValidation(){}
}
