package ca.bnc.wealth.api.authorization.security;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.enums.ErrorMessages;
import ca.bnc.wealth.api.authorization.security.impl.AuthTokenValidationFilterImpl;
import ca.bnc.wealth.api.authorization.security.util.JwtUtil;
import jakarta.servlet.http.HttpServletResponse;
import java.util.HashMap;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;

@ExtendWith(MockitoExtension.class)
class AuthTokenValidationFilterImplTest {

  private static final String SHORT_ID = "RAZA002";

  @Mock private BearerToken bearerToken;
  @Mock private JwtUtil jwtUtil;
  @Mock private EnrichUserService enrichUserService;

  @InjectMocks private AuthTokenValidationFilterImpl filter;

  private Jwt jwt;
  private MockHttpServletResponse response;
  private MockFilterChain chain;

  @BeforeEach
  void setUp() {
    jwt = Jwt.withTokenValue("token").header("alg", "RS256").subject(SHORT_ID).build();
    SecurityContextHolder.getContext().setAuthentication(new TestingAuthenticationToken(jwt, null));
    response = new MockHttpServletResponse();
    chain = new MockFilterChain();
  }

  @AfterEach
  void tearDown() {
    SecurityContextHolder.clearContext();
  }

  @Test
  void shouldRejectEmployeeTokenWhenProfileIsInactive() {
    givenToken(true);
    when(enrichUserService.enrichWithUserConfig(SHORT_ID)).thenReturn(profile("inactive"));

    filter.doFilterInternal(request("GET", "/firms/assignments/users/me"), response, chain);

    assertRejected();
  }

  @Test
  void shouldAllowEmployeeTokenWhenProfileIsActive() {
    givenToken(true);
    when(enrichUserService.enrichWithUserConfig(SHORT_ID)).thenReturn(profile("active"));

    filter.doFilterInternal(request("GET", "/firms/assignments/users/me"), response, chain);

    assertAllowed();
  }

  @Test
  void shouldAllowUserTokenWhenProfileIsInactive() {
    givenToken(false);
    when(enrichUserService.enrichWithUserConfig(SHORT_ID)).thenReturn(profile("inactive"));

    filter.doFilterInternal(request("GET", "/firms/assignments/users/me"), response, chain);

    assertAllowed();
  }

  @Test
  void shouldAllowEmployeeTokenWhenProfileLookupFails() {
    givenToken(true);
    when(enrichUserService.enrichWithUserConfig(SHORT_ID))
        .thenThrow(new IllegalStateException("user-configuration-api unavailable"));

    filter.doFilterInternal(request("GET", "/firms/assignments/users/me"), response, chain);

    assertAllowed();
  }

  @Test
  void shouldCheckEmployeeTokenDespiteInternalApiCallFlag() {
    givenToken(true);
    when(enrichUserService.enrichWithUserConfig(SHORT_ID)).thenReturn(profile("inactive"));
    MockHttpServletRequest request = request("GET", "/access-control/resources/cx_ui_module/assignments/users/me");
    request.setParameter("internalAPICall", "true");

    filter.doFilterInternal(request, response, chain);

    assertRejected();
  }

  @Test
  void shouldCheckEmployeeTokenWhenInternalApiCallFlagIsSentWithAnotherMethod() {
    givenToken(true);
    when(enrichUserService.enrichWithUserConfig(SHORT_ID)).thenReturn(profile("inactive"));
    MockHttpServletRequest request = request("PUT", "/users/me");
    request.setParameter("internalAPICall", "true");

    filter.doFilterInternal(request, response, chain);

    assertRejected();
  }

  @Test
  void shouldSkipEnrichmentForEmployeeUserConfigurationLookup() {
    givenToken(true);
    MockHttpServletRequest request = request("GET", "/users/me");
    request.setContextPath("/user-conf");
    request.setRequestURI("/user-conf/users/me");
    request.setParameter("internalAPICall", "true");

    filter.doFilterInternal(request, response, chain);

    verify(enrichUserService, never()).enrichWithUserConfig(anyString());
    assertAllowed();
  }

  @Test
  void shouldSkipEnrichmentForUserTokenWithInternalApiCallFlag() {
    givenToken(false);
    MockHttpServletRequest request = request("GET", "/firms/assignments/users/me");
    request.setParameter("internalAPICall", "true");

    filter.doFilterInternal(request, response, chain);

    verify(enrichUserService, never()).enrichWithUserConfig(anyString());
    assertAllowed();
  }

  private void givenToken(boolean employee) {
    when(jwtUtil.isSystemToken(jwt)).thenReturn(false);
    when(jwtUtil.isEmployeeToken(jwt)).thenReturn(employee);
  }

  private static MockHttpServletRequest request(String method, String uri) {
    MockHttpServletRequest request = new MockHttpServletRequest(method, uri);
    request.addHeader(HttpHeaders.AUTHORIZATION, "Bearer token");
    return request;
  }

  private static HashMap<String, Object> profile(String status) {
    HashMap<String, Object> profile = new HashMap<>();
    profile.put("username", SHORT_ID);
    profile.put("userConfigurationId", 26473);
    profile.put("status", status);
    return profile;
  }

  private void assertRejected() {
    assertEquals(HttpServletResponse.SC_UNAUTHORIZED, response.getStatus());
    assertEquals(ErrorMessages.INACTIVE_USER.getValue(), response.getErrorMessage());
    assertNull(chain.getRequest());
  }

  private void assertAllowed() {
    assertEquals(HttpServletResponse.SC_OK, response.getStatus());
    assertNotNull(chain.getRequest());
  }
}
