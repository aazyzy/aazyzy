package ca.bnc.wealth.api.authorization.security;

import ca.bnc.wealth.api.authorization.security.test.TestAuthConfiguration;
import ca.bnc.wealth.api.authorization.security.test.TestUserSingleton;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.junit.Assert.assertTrue;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
@TestPropertySource(properties = {"spring.profiles.active=dev"})
@ContextConfiguration(classes = {TestAuthConfiguration.class})
@AutoConfigureMockMvc
public class AuthTokenValidationFilterTest_LIVE {
  String invalidSignatureToken =
      "Bearer eyJraWQiOiJXTmZpRmF0eUZ0QURsclJrVzEtd3czOHU1Yk5mb1Bmbk12UEd6NHJ6NzM4IiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULnY4bzEwYjZzNllMXzEwb092aTIxQ0NqTXp5WUVZdUNTYTNiR1VURzB5ZEUiLCJpc3MiOiJodHRwczovL2F1dGgtcHAubmJpbi5jYS9vYXV0aDIvYXVzc2c0d3lkMkhaRUJHUjMwaDciLCJhdWQiOiJhcGk6Ly9kZWZhdWx0IiwiaWF0IjoxNjU1Mjk4NTA5LCJleHAiOjE2NTUyOTg4MDksImNpZCI6IjBvYTEwcmd6cThyTDNsQ1pHMGg4IiwidWlkIjoiMDB1MTd2eTI1amJYaGFoTDUwaDgiLCJzY3AiOlsiY2lhbTpwcm9maWxlczp3cml0ZSIsIndlYWx0aDphY2Nlc3MtY29udHJvbDp2aWV3ZXIiLCJ3ZWFsdGg6Y3gtdXNlci1jb25mOnZpZXdlciIsIm9wZW5pZCIsImNpYW06cHJvZmlsZXM6cmVhZCJdLCJhdXRoX3RpbWUiOjE2NTUyOTg0NTQsInN1YiI6InJlZklkU2hpcmxleUNveCIsInByZWZlcnJlZExhbmd1YWdlIjoiZnIiLCJibmdmU2VjdXJlWm9uZUlkIjpbIkFDSE9HSTMiXSwiZ3JvdXBzIjpbIldlYWx0aC5Db21wYXNzWCIsIldlYWx0aC5Db21wYXNzWC5UcmFkZXIiLCJXZWFsdGgiXX0.L0pvUyEWJ31kyNnaciPaPQvIR0IcksviqS_DMCluY1XA9bofwqSxgEpzeYNs1mzuwcdYV2nF1Qah6oN7d9l0QE-NGGGr5IJuxGTRCVCT4CoPNLC4XeaqbUuOeYseCIzevKp6S49kmytEG_CdS_ZP2N6_sn4tyBL3_feIgQewjzVuo_C043T4hyXW63q0Jc0iFquHwMf7D6ZUO4bMUSz2m2clP4N24z1sQsxJxvh0wG6NFZV7jvgLqrBOyiQLFSWoPnyG8KHw4AlBVqcCfRuCHtbPNH45wCeXXwzHfjPI_7ev05Od8jaJ1e8UL9TvmcSxVBwEDfKJUqKFspgbbV8a2g";
  String expiredToken =
      "Bearer eyJraWQiOiJXTmZpRmF0eUZ0QURsclJrVzEtd3czOHU1Yk5mb1Bmbk12UEd6NHJ6NzM4IiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULnY4bzEwYjZzNllMXzEwb092aTIxQ0NqTXp5WUVZdUNTYTNiR1VURzB5ZEUiLCJpc3MiOiJodHRwczovL2F1dGgtcHAubmJpbi5jYS9vYXV0aDIvYXVzc2c0d3lkMkhaRUJHUjMwaDciLCJhdWQiOiJhcGk6Ly9kZWZhdWx0IiwiaWF0IjoxNjU1Mjk4NTA5LCJleHAiOjE2NTUyOTg4MDksImNpZCI6IjBvYTEwcmd6cThyTDNsQ1pHMGg4IiwidWlkIjoiMDB1MTd2eTI1amJYaGFoTDUwaDgiLCJzY3AiOlsiY2lhbTpwcm9maWxlczp3cml0ZSIsIndlYWx0aDphY2Nlc3MtY29udHJvbDp2aWV3ZXIiLCJ3ZWFsdGg6Y3gtdXNlci1jb25mOnZpZXdlciIsIm9wZW5pZCIsImNpYW06cHJvZmlsZXM6cmVhZCJdLCJhdXRoX3RpbWUiOjE2NTUyOTg0NTQsInN1YiI6InJlZklkU2hpcmxleUNveCIsInByZWZlcnJlZExhbmd1YWdlIjoiZnIiLCJibmdmU2VjdXJlWm9uZUlkIjpbIkFDSE9HSTMiXSwiZ3JvdXBzIjpbIldlYWx0aC5Db21wYXNzWCIsIldlYWx0aC5Db21wYXNzWC5UcmFkZXIiLCJXZWFsdGgiXX0.L0pvUyEWJ31kyNnaciPaPQvIR0IcksviqS_DMCluY1XA9bofwqSxgEpzeYNs1mzuwcdYV2nF1Qah6oN7d9l0QE-NGGGr5IJuxGTRCVCT4CoPNLC4XeaqbUuOeYseCIzevKp6S49kmytEG_CdS_ZP2N6_sn4tyBL3_feIgQewjzVuo_C043T4hyXW63q0Jc0iFquHwMf7D6ZUO4bMUSz2m2clP4N24z1sQsxJxvh0wG6NFZV7jvgLqrBOyiQLFSWoPnyG8KHw4AlBVqcCfRuCHtbPNH45wCeXXwzHfjPI_7ev05Od8jaJ1e8UL9TvmcSxVBwEDfKJUqKFspgbbV8a2g";
  @Autowired private WebApplicationContext context;

  private MockMvc mvc;

  @Before
  public void setup() {
    mvc = MockMvcBuilders.webAppContextSetup(context).apply(springSecurity()).build();
  }

  @Test
  public void testDoFilter_InvalidSignature() throws Exception {
    MvcResult result =
        this.mvc
            .perform(
                get("/test")
                    .accept(MediaType.APPLICATION_JSON)
                    .header(HttpHeaders.AUTHORIZATION, invalidSignatureToken))
            .andExpect(status().isUnauthorized())
            .andReturn();
  }

  @Test
  public void testDoFilter_EmptyToken() throws Exception {
    try {
      MvcResult result =
          this.mvc
              .perform(
                  get("/test")
                      .accept(MediaType.APPLICATION_JSON)
                      .header(HttpHeaders.AUTHORIZATION, ""))
              .andExpect(status().isUnauthorized())
              .andReturn();
    } catch (Exception e) {
      assertTrue(e.getClass().getSimpleName().equals("NullPointerException"));
    }
  }

  @Test
  public void testDoFilter_Unauthorized() throws Exception {
    TestUserSingleton.USER_IS_UNAUTHORIZED = true;
    MvcResult result =
        this.mvc
            .perform(get("/test").accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isUnauthorized())
            .andReturn();
  }

  @Test
  public void testDoFilter_ExpiredToken() throws Exception {

    MvcResult result =
        this.mvc
            .perform(
                get("/test")
                    .accept(MediaType.APPLICATION_JSON)
                    .header(HttpHeaders.AUTHORIZATION, expiredToken))
            .andExpect(status().isUnauthorized())
            .andReturn();
  }
}
