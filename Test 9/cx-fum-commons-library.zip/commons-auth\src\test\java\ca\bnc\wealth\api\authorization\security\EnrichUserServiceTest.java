package ca.bnc.wealth.api.authorization.security;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import ca.bnc.wealth.api.authorization.feign.client.UserConfigClient;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.impl.EnrichUserServiceImpl;
import ca.bnc.wealth.api.authorization.security.test.TestEnrichUserServiceImpl;
import java.util.HashMap;
import java.util.Map;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

public class EnrichUserServiceTest {

  @Test
  public void enrichWithUserConfig() throws NoSuchMethodException {
    EnrichUserServiceImpl enrichUserService = new EnrichUserServiceImpl();

    UserConfigClient userConfigClient =  new UserConfigClient() {
      @Override
      public ResponseEntity<Object> getUserConfiguration(boolean internalAPICall) {
        Map hashMap = new HashMap<String, Object>();
        hashMap.put("username", "username");

        return ResponseEntity.ok(hashMap);
      }
    };

    ReflectionTestUtils.setField(enrichUserService, "userConfigClient", userConfigClient);
    HashMap user = enrichUserService.enrichWithUserConfig("idp");
    assertTrue(user.get("username").toString().equalsIgnoreCase("username"));
  }

  @Test(expected =  Exception.class)
  public void enrichWithUserConfig_usermeFailed() throws NoSuchMethodException {
    EnrichUserServiceImpl enrichUserService = new EnrichUserServiceImpl();

    UserConfigClient userConfigClient =  new UserConfigClient() {
      @Override
      public ResponseEntity<Object> getUserConfiguration(boolean internalAPICall) {

        return ResponseEntity.ok("");
      }
    };

    ReflectionTestUtils.setField(enrichUserService, "userConfigClient", userConfigClient);
    HashMap user = enrichUserService.enrichWithUserConfig("idp");
    assertTrue(user.get("username").toString().equalsIgnoreCase("username"));
  }

  @Test
  public void enrichWithUserConfigTest() throws NoSuchMethodException {
    TestEnrichUserServiceImpl enrichUserService = new TestEnrichUserServiceImpl();

    User user = new User();
    user.setUsername("username");
    HashMap response = enrichUserService.enrichWithUserConfig("idp");
    assertTrue(response.size() == 0);
  }

  @Test
  public void redisCacheEnabled() {
    EnrichUserServiceImpl enrichUserService = new EnrichUserServiceImpl();
    assertFalse(enrichUserService.redisCacheEnabled());
  }
}
