package ca.bnc.wealth.api.authorization.security;

import ca.bnc.wealth.api.authorization.model.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class JwtTokenTest {

    final static String MOCK_TOKEN = "MOCK_TOKEN";
    @Mock
    Authentication authentication;
    @Mock
    SecurityContext securityContext;
    User user;

    @BeforeEach
    void setUp(){
        user = new User();
        user.setJwtToken(MOCK_TOKEN);
    }

    @Test
    void testAuthToken_success(){
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
        when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(user);
        String actual = JwtToken.getAuthToken();
        assertEquals(MOCK_TOKEN, actual);
    }

    @Test
    void testAuthToken_noauth(){
        when(securityContext.getAuthentication()).thenReturn(null);
        SecurityContextHolder.setContext(securityContext);
        assertNull(JwtToken.getAuthToken());
    }

    @Test
    void testAuthToken_nouser(){
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
        when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(null);
        assertNull(JwtToken.getAuthToken());
    }


    @Test
    void testBeareToken_success(){
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
        when(SecurityContextHolder.getContext().getAuthentication().getPrincipal()).thenReturn(user);
        String actual = JwtToken.getBearerToken();
        assertEquals("Bearer "+MOCK_TOKEN, actual);
    }
}