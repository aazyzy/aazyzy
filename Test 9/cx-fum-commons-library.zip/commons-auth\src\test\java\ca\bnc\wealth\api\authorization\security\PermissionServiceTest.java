package ca.bnc.wealth.api.authorization.security;

import ca.bnc.wealth.api.authorization.feign.client.IamAPIClient;
import ca.bnc.wealth.api.authorization.model.*;
import ca.bnc.wealth.api.authorization.security.impl.PermissionServiceImpl;
import org.hamcrest.CoreMatchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
public class PermissionServiceTest {


  @Test
  public void getPermissions() {
    Role role = new Role();
    role.setRoleName("wealth:cx-firm:viewer");
    PermissionInfo permissionInfo = new PermissionInfo();
    permissionInfo.setName("view_firms");
    role.setPermissions(Arrays.asList(permissionInfo));

    IamAPIClient iamAPIClient = new IamAPIClient() {
      @Override
      public ResponseEntity<List<Role>> getRoles(String authorization, String capability, boolean assignments) {
        return ResponseEntity.ok(Arrays.asList(role));
      }

      @Override
      public ResponseEntity<List<Resource>> getResources(String authorization, String resourceType) {
        return ResponseEntity.ok(Arrays.asList(new Resource(123L, "test", "test-type",
            true, "test", "test", "test", "test", "test", "test", true)));
      }

      @Override
      public ResponseEntity<List<ResourceData>> getResourceByResourceTypeAndRrCode(String authorization, String resourceType, String rrCode) {
        return ResponseEntity.ok(List.of(new ResourceData(1L, true, "test", "description", "confUri", "version", "groupName" ,"label" ,"purpose", false)));
      }
    };

    Authentication authentication = mock(Authentication.class);
    SecurityContext securityContext = mock(SecurityContext.class);
    SecurityContextHolder.setContext(securityContext);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(getUser());


    PermissionService permissionService = new PermissionServiceImpl();
    ReflectionTestUtils.setField(permissionService, "iamAPIClient", iamAPIClient);

    List<String> permissions = permissionService.getPermissions("abc", Arrays.asList("moe:view"));
    assertThat(permissions, CoreMatchers.hasItem("view_firms"));
  }

  private User getUser() {
    User user = new User();
    user.setRoles(Arrays.asList("wealth:cx-firm:viewer", "wealth:cx-firm:access"));
    user.setSystemToken(true);
    return user;
  }
}
