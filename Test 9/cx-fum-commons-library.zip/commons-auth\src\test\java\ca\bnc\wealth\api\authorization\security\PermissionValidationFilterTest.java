package ca.bnc.wealth.api.authorization.security;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyList;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.data.ScopeDataTest;
import ca.bnc.wealth.api.authorization.feign.client.IamAPIClient;
import ca.bnc.wealth.api.authorization.model.PermissionInfo;
import ca.bnc.wealth.api.authorization.model.Resource;
import ca.bnc.wealth.api.authorization.model.ResourceData;
import ca.bnc.wealth.api.authorization.model.Role;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.impl.PermissionServiceImpl;
import ca.bnc.wealth.api.authorization.security.impl.PermissionValidationFilterImpl;
import ca.bnc.wealth.api.authorization.security.impl.ScopeServiceImpl;
import ca.bnc.wealth.api.authorization.security.util.ClassUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.cache.CacheManager;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.filter.OncePerRequestFilter;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class PermissionValidationFilterTest {
  PermissionValidationFilterImpl filter;
  MockHttpServletRequest req;
  MockHttpServletResponse res;
  MockFilterChain chain;
  ScopeServiceImpl scopeService;
  IamAPIClient iamAPIClient;
  CacheManager cacheManager;
  PermissionServiceImpl permissionService;
  Authentication authentication;
  SecurityContext securityContext;
  ClassUtil classUtil;

  @Before
  public void init() {
    filter = new PermissionValidationFilterImpl();
    req = new MockHttpServletRequest();
    res = new MockHttpServletResponse();
    chain = new MockFilterChain();
    scopeService = mock(ScopeServiceImpl.class);
    cacheManager = mock(CacheManager.class);
    permissionService = mock(PermissionServiceImpl.class);
    classUtil = mock(ClassUtil.class);

    ReflectionTestUtils.setField(filter, "scopeService", scopeService);
    ReflectionTestUtils.setField(filter, "permissionService", permissionService);
    ReflectionTestUtils.setField(filter, "scopeService", scopeService);
    ReflectionTestUtils.setField(filter, "classUtil", classUtil);

    Role role = new Role();
    role.setRoleName("wealth:cx-firm:viewer");
    PermissionInfo permissionInfo = new PermissionInfo();
    permissionInfo.setName("moe:view_firms");
    role.setPermissions(Arrays.asList(permissionInfo));
    iamAPIClient =
        new IamAPIClient() {
          @Override
          public ResponseEntity<List<Role>> getRoles(
              String authorization, String capability, boolean assignments) {
            return ResponseEntity.ok(Arrays.asList(role));
          }

          @Override
          public ResponseEntity<List<Resource>> getResources(
              String authorization, String resourceType) {
            return ResponseEntity.ok(Arrays.asList(new Resource(123L, "test", "test-type",
                true, "test", "test", "test", "test", "test", "test", true)));
          }

          @Override
          public ResponseEntity<List<ResourceData>> getResourceByResourceTypeAndRrCode(String authorization, String resourceType, String rrCode) {
            return ResponseEntity.ok(List.of(new ResourceData(1L, true, "test", "description", "confUri", "version", "groupName" ,"label" ,"purpose", false)));
          }
        };

    authentication = mock(Authentication.class);
    securityContext = mock(SecurityContext.class);
    SecurityContextHolder.setContext(securityContext);
    when(securityContext.getAuthentication()).thenReturn(authentication);
  }

  private User getUserToken() {
    User user = new User();
    user.setIdpSubject("test");
    user.setRoles(List.of("wealth:cx-firm:viewer"));
    user.setSystemToken(false);
    return user;
  }

  private User getSystemToken() {
    User user = new User();
    user.setRoles(Arrays.asList("wealth:cx-firm:viewer", "wealth:cx-firm:access"));
    user.setSystemToken(true);
    return user;
  }

  @Test
  public void permissionValidationFilterSuccessForSystemToken() throws Exception {
    when(authentication.getPrincipal()).thenReturn(getSystemToken());

    Method met = ScopeDataTest.class.getDeclaredMethod("method4");
    Pair<String, Method> map = new MutablePair<>("PermissionTest", met);
    when(classUtil.getApiMethod(any(HttpServletRequest.class))).thenReturn(map);

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filter, req, res, chain);
    log.info(res.getErrorMessage());
    assertEquals(200, res.getStatus());
  }

  @Test
  public void permissionValidationFilterFailure() throws Exception {
    ReflectionTestUtils.setField(filter, "capabilities", new String[] {"moe"});

    when(authentication.getPrincipal()).thenReturn(getUserToken());

    Method met = ScopeDataTest.class.getDeclaredMethod("method1");
    Pair<String, Method> map = new MutablePair<>("PermissionTest", met);
    when(classUtil.getApiMethod(any(HttpServletRequest.class))).thenReturn(map);
    doReturn(Collections.emptyList())
        .when(permissionService)
        .getPermissions(anyString(), anyList());

    Map<String, List<String>> scopePermissions = new HashMap<>();
    scopePermissions.put("permissions", List.of("moe:view_firms"));

    doReturn(scopePermissions).when(scopeService).getScope(any(HttpServletRequest.class));

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filter, req, res, chain);
    assertEquals(401, res.getStatus());
  }

  @Test
  public void permissionValidationFilterSuccess() throws Exception {
    ReflectionTestUtils.setField(filter, "capabilities", new String[] {"moe"});

    when(authentication.getPrincipal()).thenReturn(getUserToken());

    Method met = ScopeDataTest.class.getDeclaredMethod("method1");
    Pair<String, Method> map = new MutablePair<>("PermissionTest", met);
    when(classUtil.getApiMethod(any(HttpServletRequest.class))).thenReturn(map);
    Map<String, Set<String>> rolePremission = new HashMap<>();
    Set<String> permission = new HashSet<>();
    permission.add("moe:view_firms");
    rolePremission.put("wealth:cx-firm:viewer", permission);
    doReturn(rolePremission)
            .when(permissionService)
            .getPermissionMap(anyString(), anyList());

    Map<String, List<String>> scopePermissions = new HashMap<>();
    scopePermissions.put("permissions", List.of("moe:view_firms"));

    doReturn(scopePermissions).when(scopeService).getScope(any(HttpServletRequest.class));

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filter, req, res, chain);
    assertEquals(200, res.getStatus());
  }

  @Test
  public void permissionValidationFilterFailureForInvalidPermission() throws Exception {
    ReflectionTestUtils.setField(filter, "capabilities", new String[] {"moe"});

    when(authentication.getPrincipal()).thenReturn(getUserToken());

    Method met = ScopeDataTest.class.getDeclaredMethod("method1");
    Pair<String, Method> map = new MutablePair<>("PermissionTest", met);
    when(classUtil.getApiMethod(any(HttpServletRequest.class))).thenReturn(map);
    doReturn(List.of("moe:edit_firms"))
        .when(permissionService)
        .getPermissions(anyString(), anyList());

    Map<String, List<String>> scopePermissions = new HashMap<>();
    scopePermissions.put("permissions", List.of("moe:view_firms"));

    doReturn(scopePermissions).when(scopeService).getScope(any(HttpServletRequest.class));

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filter, req, res, chain);
    assertEquals(401, res.getStatus());
  }

  @Test
  public void permissionValidationFilterFailureForNoPermission() throws Exception {
    when(authentication.getPrincipal()).thenReturn(getUserToken());

    Method met = ScopeDataTest.class.getDeclaredMethod("method1");
    Pair<String, Method> map = new MutablePair<>("PermissionTest", met);
    when(classUtil.getApiMethod(any(HttpServletRequest.class))).thenReturn(map);

    Map<String, List<String>> scopePermissions = new HashMap<>();
    scopePermissions.put("permissions", null);
    doReturn(scopePermissions).when(scopeService).getScope(any(HttpServletRequest.class));

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filter, req, res, chain);
    assertEquals(401, res.getStatus());
  }

  @Test
  public void permissionValidationFilterEndpointNotFound() throws Exception {
    ReflectionTestUtils.setField(filter, "capabilities", new String[] {"moe"});

    when(authentication.getPrincipal()).thenReturn(getUserToken());
    when(classUtil.getApiMethod(any(HttpServletRequest.class))).thenThrow(NullPointerException.class);

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filter, req, res, chain);
    assertTrue(res.getErrorMessage().contains("ENDPOINT NOT FOUND"));
    assertEquals(404, res.getStatus());
  }
}
