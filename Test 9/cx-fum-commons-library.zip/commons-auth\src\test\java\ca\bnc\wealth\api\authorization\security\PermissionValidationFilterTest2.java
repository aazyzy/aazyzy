package ca.bnc.wealth.api.authorization.security;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.data.ScopeDataTest;
import ca.bnc.wealth.api.authorization.feign.client.IamAPIClient;
import ca.bnc.wealth.api.authorization.model.PermissionInfo;
import ca.bnc.wealth.api.authorization.model.Resource;
import ca.bnc.wealth.api.authorization.model.ResourceData;
import ca.bnc.wealth.api.authorization.model.Role;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.impl.PermissionServiceImpl;
import ca.bnc.wealth.api.authorization.security.impl.PermissionValidationFilterImpl;
import ca.bnc.wealth.api.authorization.security.impl.ScopeServiceImpl;
import ca.bnc.wealth.api.authorization.security.util.ClassUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Test;
import org.springframework.cache.CacheManager;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.filter.OncePerRequestFilter;

@Slf4j
public class PermissionValidationFilterTest2 {
  PermissionValidationFilterImpl filter;
  MockHttpServletRequest req;
  MockHttpServletResponse res;
  MockFilterChain chain;
  ScopeServiceImpl scopeService;
  IamAPIClient iamAPIClient;
  CacheManager cacheManager;
  PermissionServiceImpl permissionService;
  ClassUtil classUtil;


  private void init(List<String> role_permissions, User user) {
    filter = new PermissionValidationFilterImpl();
    req = new MockHttpServletRequest();
    res = new MockHttpServletResponse();
    chain = new MockFilterChain();
    //    scopeService = mock(ScopeServiceImpl.class);
    cacheManager = mock(CacheManager.class);
    permissionService = new PermissionServiceImpl();
    scopeService = new ScopeServiceImpl();
    classUtil = mock(ClassUtil.class);
    ReflectionTestUtils.setField(filter, "scopeService", scopeService);
    ReflectionTestUtils.setField(filter, "classUtil", classUtil);
    ReflectionTestUtils.setField(filter, "permissionService", permissionService);
    ReflectionTestUtils.setField(filter, "scopeService", scopeService);
    ReflectionTestUtils.setField(filter, "capabilities", new String[] {"moe"});
    ReflectionTestUtils.setField(scopeService, "classUtil", classUtil);

    Authentication authentication = mock(Authentication.class);
    SecurityContext securityContext = mock(SecurityContext.class);
    SecurityContextHolder.setContext(securityContext);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(user);

    // Initialize the iamAPIClient response for GET roles/me to fetch the user roles and associated
    // permissions
    List<Role> roles =
        role_permissions.stream()
            .map(
                rp -> {
                  Role role = new Role();
                  role.setRoleName(rp.split("->")[0]);
                  List<PermissionInfo> permissions =
                      Arrays.asList(rp.split("->")[1].split(",")).stream()
                          .map(
                              perm -> {
                                PermissionInfo p = new PermissionInfo();
                                p.setName(perm);
                                return p;
                              })
                          .collect(Collectors.toList());
                  role.setPermissions(permissions);
                  return role;
                })
            .collect(Collectors.toList());
    System.out.println(roles);
    iamAPIClient =
        new IamAPIClient() {
          @Override
          public ResponseEntity<List<Role>> getRoles(
              String authorization, String capability, boolean assignments) {
            return ResponseEntity.ok(roles);
          }

          @Override
          public ResponseEntity<List<Resource>> getResources(
              String authorization, String resourceType) {
            return ResponseEntity.ok(
                Arrays.asList(
                    new Resource(
                        123L,
                        "test",
                        "test-type",
                        true,
                        "test",
                        "test",
                        "test",
                        "test",
                        "test",
                        "test",
                        true)));
          }

          @Override
          public ResponseEntity<List<ResourceData>> getResourceByResourceTypeAndRrCode(
              String authorization, String resourceType, String rrCode) {
            return ResponseEntity.ok(
                List.of(
                    new ResourceData(
                        1L,
                        true,
                        "test",
                        "description",
                        "confUri",
                        "version",
                        "groupName",
                        "label",
                        "purpose",
                        false)));
          }
        };
    ReflectionTestUtils.setField(permissionService, "iamAPIClient", iamAPIClient);
    ReflectionTestUtils.setField(permissionService, "cacheManager", cacheManager);
  }

  private User getUserToken(List<String> roles) {
    User user = new User();
    user.setIdpSubject("test");
    user.setRoles(roles);
    user.setSystemToken(false);
    return user;
  }

  public Integer testPermission(List<String> iamRolePermissions, String methodToTest, User user)
      throws Exception {
    /** Mock the api response */
    init(iamRolePermissions, user);
    PermissionValidationFilterImpl filterSpy = spy(filter);
    Method met = ScopeDataTest.class.getDeclaredMethod(methodToTest);
    Pair<String, Method> map = new MutablePair<>("PermissionTest", met);
    when(classUtil.getApiMethod(any(HttpServletRequest.class))).thenReturn(map);

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filterSpy, new Object[] {req, res, chain});
    return res.getStatus();
  }

  @Test
  public void failTest01() throws Exception {
    /** IAM permissions available to the user does not match the api specifications = 401 */
    assertTrue(
        testPermission(
                Arrays.asList(
                    "wealth:cx-user-conf:viewer->access-control:view_users,access-control:list_users"),
                "editor_access",
                getUserToken(Arrays.asList("wealth:cx-firm-conf:viewer")))
            == 401);
  }

  @Test
  public void failTest02() throws Exception {
    /** IAM permissions available to the user are less than the api specifications = 401 */
    assertTrue(
        testPermission(
                Arrays.asList(
                    "wealth:cx-firm-conf:viewer->access-control:view_firms,access-control:list_firms"),
                "editor_access",
                getUserToken(Arrays.asList("wealth:cx-firm-conf:viewer")))
            == 401);
  }

  @Test
  public void failTest03() throws Exception {
    /**
     * API permissions are defined but has been annotated with DisablePermissionCheck but role check
     * was not successful
     */
    assertTrue(
        testPermission(
                Arrays.asList(
                    "wealth:cx-firm-conf:viewer->access-control:view_firms,access-control:list_firms"),
                "permission_check_disabled",
                getUserToken(Arrays.asList("wealth:cx-firm-conf:viewer")))
            == 401);
  }

  @Test
  public void failTest04() throws Exception {
    /**
     * API permissions are defined but has been annotated with DisablePermissionCheck but role check
     * was not successful
     */
    User user = getUserToken(Arrays.asList("wealth:cx-firm-conf:viewer"));
    user.setScopeChecked(false);
    assertTrue(
        testPermission(
                Arrays.asList(
                    "wealth:cx-firm-conf:viewer->access-control:view_firms,access-control:list_firms"),
                "permission_check_disabled",
                user)
            == 401);
  }

  @Test
  public void passTest01() throws Exception {
    /** IAM DB permissions all match the api defined permissions */
    assertTrue(
        testPermission(
                Arrays.asList(
                    "wealth:cx-firm-conf:viewer->access-control:view_firms,access-control:list_firms,access-control:edit_firms"),
                "viewer_access",
                getUserToken(Arrays.asList("wealth:cx-firm-conf:viewer")))
            == 200);
  }

  @Test
  public void passTest02() throws Exception {
    /**
     * IAM DB permissions all match the api defined permissions but available via different roles ->
     * permission assignments
     */
    assertTrue(
        testPermission(
                Arrays.asList(
                    "wealth:cx-firm-conf:viewer->access-control:view_firms,access-control:list_firms",
                    "wealth:cx-firm-conf:editor->access-control:edit_firms"),
                "editor_access",
                getUserToken(
                    Arrays.asList("wealth:cx-firm-conf:viewer", "wealth:cx-firm-conf:editor")))
            == 200);
  }

  @Test
  public void passTest03() throws Exception {
    /**
     * API permissions are defined but has been annotated with DisablePermissionCheck and role check
     * was successful, then allow permission checks to be skipped
     */
    User user = getUserToken(Arrays.asList("wealth:cx-firm-conf:viewer"));
    user.setScopeChecked(true);
    assertTrue(
        testPermission(
                Arrays.asList(
                    "wealth:cx-firm-conf:viewer->access-control:view_firms,access-control:list_firms",
                    "wealth:cx-firm-conf:editor->access-control:edit_firms"),
                "permission_check_disabled",
                user)
            == 200);
  }
}
