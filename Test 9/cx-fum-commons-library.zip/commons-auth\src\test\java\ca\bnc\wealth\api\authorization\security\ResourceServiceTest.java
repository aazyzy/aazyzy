package ca.bnc.wealth.api.authorization.security;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.feign.client.IamAPIClient;
import ca.bnc.wealth.api.authorization.model.Resource;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.impl.ResourceService;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

public class ResourceServiceTest {

  @Test
  public void getResources() {
    Authentication authentication = mock(Authentication.class);
    SecurityContext securityContext = mock(SecurityContext.class);
    SecurityContextHolder.setContext(securityContext);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(getUser());
    ResourceService resourceService = new ResourceService();
    IamAPIClient iamAPIClient = mock(IamAPIClient.class);
    Resource resource = new Resource();
    resource.setResourceName("abc");
    when(iamAPIClient.getResources(anyString(), anyString())).thenReturn(new ResponseEntity<>(
        List.of(resource), HttpStatus.OK));
    ReflectionTestUtils.setField(resourceService, "iamAPIClient", iamAPIClient);
    List<String> response = resourceService.getResources("idp", "type");
    assertTrue(response.size() == 1);
    assertEquals("abc", response.get(0));
  }

  @Test(expected =  Exception.class)
  public void getResources_faild() {
    Authentication authentication = mock(Authentication.class);
    SecurityContext securityContext = mock(SecurityContext.class);
    SecurityContextHolder.setContext(securityContext);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    when(authentication.getPrincipal()).thenReturn(getUser());
    ResourceService resourceService = new ResourceService();
    IamAPIClient iamAPIClient = mock(IamAPIClient.class);
    Resource resource = new Resource();
    resource.setResourceName("abc");
    when(iamAPIClient.getResources(anyString(), anyString())).thenThrow(new RuntimeException("error"));
    ReflectionTestUtils.setField(resourceService, "iamAPIClient", iamAPIClient);
    List<String> response = resourceService.getResources("idp", "type");
  }

  private User getUser() {
    User user = new User();
    user.setRoles(Arrays.asList("wealth:cx-firm:viewer", "wealth:cx-firm:access"));
    user.setSystemToken(true);
    return user;
  }
}
