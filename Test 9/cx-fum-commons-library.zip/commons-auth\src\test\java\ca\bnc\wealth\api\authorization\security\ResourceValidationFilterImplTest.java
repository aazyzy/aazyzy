package ca.bnc.wealth.api.authorization.security;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.data.ScopeDataTest;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.impl.ResourceService;
import ca.bnc.wealth.api.authorization.security.impl.ResourceValidationFilterImpl;
import ca.bnc.wealth.api.authorization.security.impl.ScopeServiceImpl;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.filter.OncePerRequestFilter;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class ResourceValidationFilterImplTest {
  ResourceValidationFilterImpl filter;
  MockHttpServletRequest req;
  MockHttpServletResponse res;
  MockFilterChain chain;
  ScopeServiceImpl scopeService;
  ResourceService resourceService;
  Authentication authentication;
  SecurityContext securityContext;

  @Before
  public void init() {
    filter = new ResourceValidationFilterImpl();
    req = new MockHttpServletRequest();
    res = new MockHttpServletResponse();
    chain = new MockFilterChain();
    scopeService = mock(ScopeServiceImpl.class);
    resourceService = mock(ResourceService.class);

    ReflectionTestUtils.setField(filter, "scopeService", scopeService);
    ReflectionTestUtils.setField(filter, "resourceService", resourceService);

    authentication = mock(Authentication.class);
    securityContext = mock(SecurityContext.class);
    SecurityContextHolder.setContext(securityContext);
    when(securityContext.getAuthentication()).thenReturn(authentication);
  }

  @Test
  public void resourceValidationForSystemToken() throws Exception {
    when(authentication.getPrincipal()).thenReturn(getSystemToken());

    Method met = ScopeDataTest.class.getDeclaredMethod("resourceValidation");
    ScopeServiceImpl scopeSerc = new ScopeServiceImpl();
    Map<String, List<String>> map = scopeSerc.getScope("ScopeDataTest", met);
    when(scopeService.getScope(any(HttpServletRequest.class))).thenReturn(map);

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filter, req, res, chain);
    log.info(res.getErrorMessage());
    assertTrue(res.getStatus() != 401);
  }

  @Test
  public void resourceValidationForUserToken() throws Exception {
    when(authentication.getPrincipal()).thenReturn(getUserToken());

    Method met = ScopeDataTest.class.getDeclaredMethod("resourceValidation");
    ScopeServiceImpl scopeSerc = new ScopeServiceImpl();
    Map<String, List<String>> map = scopeSerc.getScope("ScopeDataTest", met);
    when(scopeService.getScope(any(HttpServletRequest.class))).thenReturn(map);
    when(resourceService.getResources(anyString(), anyString())).thenReturn(List.of("firm_level_access"));

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filter, req, res, chain);
    log.info(res.getErrorMessage());
    assertTrue(res.getStatus() != 401);
  }

  @Test
  public void resourceValidationForUserToken_noUserResource() throws Exception {
    when(authentication.getPrincipal()).thenReturn(getUserToken());

    Method met = ScopeDataTest.class.getDeclaredMethod("resourceValidation");
    ScopeServiceImpl scopeSerc = new ScopeServiceImpl();
    Map<String, List<String>> map = scopeSerc.getScope("ScopeDataTest", met);
    when(scopeService.getScope(any(HttpServletRequest.class))).thenReturn(map);
    when(resourceService.getResources(anyString(), anyString())).thenReturn(Collections.emptyList());

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filter, req, res, chain);
    log.info(res.getErrorMessage());
    assertEquals(401, res.getStatus());
  }

  @Test
  public void resourceValidationForUserToken_resourceValidationNotRequired() throws Exception {
    when(authentication.getPrincipal()).thenReturn(getUserToken());

    Method met = ScopeDataTest.class.getDeclaredMethod("method4");
    ScopeServiceImpl scopeSerc = new ScopeServiceImpl();
    Map<String, List<String>> map = scopeSerc.getScope("ScopeDataTest", met);
    when(scopeService.getScope(any(HttpServletRequest.class))).thenReturn(map);
    when(resourceService.getResources(anyString(), anyString())).thenReturn(Collections.emptyList());

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filter, req, res, chain);
    log.info(res.getErrorMessage());
    assertTrue(res.getStatus() != 401);
  }

  @Test
  public void resourceValidationForUserToken_endpointNotFound() throws Exception {
    when(authentication.getPrincipal()).thenReturn(getUserToken());
    when(scopeService.getScope(any(HttpServletRequest.class))).thenThrow(NullPointerException.class);

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filter, req, res, chain);
    log.info(res.getErrorMessage());
    assertTrue(res.getErrorMessage().contains("ENDPOINT NOT FOUND"));
    assertEquals(404, res.getStatus());
  }

  private User getUserToken() {
    User user = new User();
    user.setRoles(List.of("wealth:cx-firm:viewer"));
    user.setSystemToken(false);
    user.setIdpSubject("idp");
    return user;
  }

  private User getSystemToken() {
    User user = new User();
    user.setRoles(Arrays.asList("wealth:cx-firm:viewer", "wealth:cx-firm:access"));
    user.setSystemToken(true);
    return user;
  }
}
