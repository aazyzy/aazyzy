package ca.bnc.wealth.api.authorization.security;

import ca.bnc.wealth.api.authorization.data.ScopeDataTest;
import ca.bnc.wealth.api.authorization.security.impl.ScopeServiceImpl;
import ca.bnc.wealth.api.authorization.security.util.ClassUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Test;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ScopeServiceTest {

  @Test
  public void getScopeWithHttpRequest()  throws NoSuchMethodException{
    ScopeServiceImpl scopeService = new ScopeServiceImpl();
    ClassUtil classUtil = mock(ClassUtil.class);
    ReflectionTestUtils.setField(scopeService, "classUtil", classUtil);
    Method method = ScopeDataTest.class.getDeclaredMethod("method3");
    when(classUtil.getApiMethod(any(HttpServletRequest.class))).thenReturn(Pair.of("method3", method));

    Map<String, List<String>> map = scopeService.getScope(new MockHttpServletRequest());
    assertTrue(map.keySet().contains("permissions"));
    assertTrue(map.get("permissions").contains("moe:view_firms"));
    assertTrue(map.keySet().contains("roles"));
    assertTrue(map.get("roles").contains("wealth:cx-firm:viewer"));
    assertTrue(map.keySet().contains("system-access"));
    assertTrue(map.get("system-access").contains("wealth:cx-firm:access"));

  }
  @Test
  public void getScopeWithSwaggerV3() throws NoSuchMethodException {
    ScopeServiceImpl scopeService = new ScopeServiceImpl();

    Method method = ScopeDataTest.class.getDeclaredMethod("method3");

    Map<String, List<String>> map = scopeService.getScope("ScopeDataTest", method);
    assertTrue(map.keySet().contains("permissions"));
    assertTrue(map.get("permissions").contains("moe:view_firms"));
    assertTrue(map.keySet().contains("roles"));
    assertTrue(map.get("roles").contains("wealth:cx-firm:viewer"));
    assertTrue(map.keySet().contains("system-access"));
    assertTrue(map.get("system-access").contains("wealth:cx-firm:access"));
  }
}
