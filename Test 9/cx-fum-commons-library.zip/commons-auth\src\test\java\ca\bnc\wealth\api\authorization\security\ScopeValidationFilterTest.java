package ca.bnc.wealth.api.authorization.security;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.data.ScopeDataTest;
import ca.bnc.wealth.api.authorization.feign.client.IamAPIClient;
import ca.bnc.wealth.api.authorization.model.PermissionInfo;
import ca.bnc.wealth.api.authorization.model.Resource;
import ca.bnc.wealth.api.authorization.model.ResourceData;
import ca.bnc.wealth.api.authorization.model.Role;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.impl.ScopeServiceImpl;
import ca.bnc.wealth.api.authorization.security.impl.ScopeValidationFilterImpl;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.cache.CacheManager;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.filter.OncePerRequestFilter;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class ScopeValidationFilterTest {
  ScopeValidationFilterImpl filter;
  MockHttpServletRequest req;
  MockHttpServletResponse res;
  MockFilterChain chain;
  ScopeServiceImpl scopeService;
  IamAPIClient iamAPIClient;
  CacheManager cacheManager;
  Authentication authentication;
  SecurityContext securityContext;

  @Before
  public void init() {
    filter = new ScopeValidationFilterImpl();
    req = new MockHttpServletRequest();
    res = new MockHttpServletResponse();
    chain = new MockFilterChain();
    scopeService = mock(ScopeServiceImpl.class);
    cacheManager = mock(CacheManager.class);

    ReflectionTestUtils.setField(filter, "scopeService", scopeService);

    Role role = new Role();
    role.setRoleName("wealth:cx-firm:viewer");
    PermissionInfo permissionInfo = new PermissionInfo();
    permissionInfo.setName("moe:view_firms");
    role.setPermissions(Arrays.asList(permissionInfo));
    iamAPIClient =
        new IamAPIClient() {
          @Override
          public ResponseEntity<List<Role>> getRoles(
              String authorization, String capability, boolean assignments) {
            return ResponseEntity.ok(Arrays.asList(role));
          }

          @Override
          public ResponseEntity<List<Resource>> getResources(
              String authorization, String resourceType) {
            return ResponseEntity.ok(Arrays.asList(new Resource(123L, "test", "test-type",
                true, "test", "test", "test", "test", "test", "test", true)));
          }

          @Override
          public ResponseEntity<List<ResourceData>> getResourceByResourceTypeAndRrCode(String authorization, String resourceType, String rrCode) {
            return ResponseEntity.ok(List.of(new ResourceData(1L, true, "test", "description", "confUri", "version", "groupName" ,"label" ,"purpose", false)));
          }
        };

    authentication = mock(Authentication.class);
    securityContext = mock(SecurityContext.class);
    SecurityContextHolder.setContext(securityContext);
    when(securityContext.getAuthentication()).thenReturn(authentication);
  }

  private User getUserToken() {
    User user = new User();
    user.setRoles(List.of("wealth:cx-firm:viewer"));
    user.setSystemToken(false);
    return user;
  }

  private User getSystemToken() {
    User user = new User();
    user.setRoles(Arrays.asList("wealth:cx-firm:viewer", "wealth:cx-firm:access"));
    user.setSystemToken(true);
    return user;
  }

  @Test
  public void scopeValidationFilterFailed() throws Exception {
    when(authentication.getPrincipal()).thenReturn(getSystemToken());

    Method met = ScopeDataTest.class.getDeclaredMethod("method4");
    ScopeServiceImpl scopeSerc = new ScopeServiceImpl();
    Map<String, List<String>> map = scopeSerc.getScope("ScopeDataTest", met);
    when(scopeService.getScope(any(HttpServletRequest.class))).thenReturn(map);

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filter, req, res, chain);
    log.info(res.getErrorMessage());
    assertTrue(res.getErrorMessage().contains("SCOPE VALIDATION FAILED"));
    assertEquals(401, res.getStatus());
  }

  @Test
  public void testScopeValidationFilter_whenNoSystemScope_shouldByPass() throws Exception {
    when(authentication.getPrincipal()).thenReturn(getSystemToken());
    when(scopeService.getScope(any(HttpServletRequest.class))).thenReturn(new HashMap<>());

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filter, req, res, chain);
    assertNull(res.getErrorMessage());
    assertTrue(res.getStatus() != 401);
  }

  @Test
  public void testScopeValidationFilter_whenNoUserScope_shouldByPass() throws Exception {
    when(authentication.getPrincipal()).thenReturn(getUserToken());
    when(scopeService.getScope(any(HttpServletRequest.class))).thenReturn(new HashMap<>());

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filter, req, res, chain);
    assertNull(res.getErrorMessage());
    assertTrue(res.getStatus() != 401);
  }

  @Test
  public void scopeValidationFilterEndpointNotFound() throws Exception {
    when(authentication.getPrincipal()).thenReturn(getSystemToken());
    when(scopeService.getScope(any(HttpServletRequest.class))).thenThrow(NullPointerException.class);

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filter, req, res, chain);
    log.info(res.getErrorMessage());
    assertTrue(res.getErrorMessage().contains("ENDPOINT NOT FOUND"));
    assertEquals(404, res.getStatus());
  }

  @Test
  public void scopeValidationFilterSuccess() throws Exception {
    when(authentication.getPrincipal()).thenReturn(getSystemToken());

    ReflectionTestUtils.setField(filter, "capabilities", new String[] {"moe"});

    Method met = ScopeDataTest.class.getDeclaredMethod("method1");
    ScopeServiceImpl scopeSerc = new ScopeServiceImpl();
    Map<String, List<String>> map = scopeSerc.getScope("ScopeDataTest", met);
    when(scopeService.getScope(any(HttpServletRequest.class))).thenReturn(map);

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);

    method.invoke(filter, req, res, chain);
    assertNull(res.getErrorMessage());
    assertTrue(res.getStatus() != 401);
  }

  @Test
  public void userScopeValidationFilterSuccess() throws Exception {
    when(authentication.getPrincipal()).thenReturn(getUserToken());

    ReflectionTestUtils.setField(filter, "capabilities", new String[] {"moe"});

    Method met = ScopeDataTest.class.getDeclaredMethod("method1");
    ScopeServiceImpl scopeSerc = new ScopeServiceImpl();
    Map<String, List<String>> map = scopeSerc.getScope("ScopeDataTest", met);
    when(scopeService.getScope(any(HttpServletRequest.class))).thenReturn(map);

    Method method =
        OncePerRequestFilter.class.getDeclaredMethod(
            "doFilterInternal",
            HttpServletRequest.class,
            HttpServletResponse.class,
            FilterChain.class);
    method.setAccessible(true);
    method.invoke(filter, req, res, chain);
    assertNull(res.getErrorMessage());
    assertTrue(res.getStatus() != 401);
  }
}
