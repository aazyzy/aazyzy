package ca.bnc.wealth.api.authorization.security;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import jakarta.servlet.Filter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.junit.jupiter.web.SpringJUnitWebConfig;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

/** Without {@code oauth2.unAuthorized.routes}, as every 6900 API runs. */
@SpringJUnitWebConfig(classes = {SecurityConfigAdapter.class, SecurityConfigAdapterTest.Beans.class})
class SecurityConfigAdapterNoRoutesTest {

  @Autowired private WebApplicationContext context;

  @Autowired
  @Qualifier("springSecurityFilterChain")
  private Filter springSecurityFilterChain;

  private MockMvc mvc;

  @BeforeEach
  void setUp() {
    mvc = MockMvcBuilders.webAppContextSetup(context).addFilters(springSecurityFilterChain).build();
  }

  @Test
  void onlyDocumentationAndManagementRoutesSkipSecurity() throws Exception {
    mvc.perform(get("/v3/api-docs")).andExpect(status().isNotFound());
    mvc.perform(get("/manage/health")).andExpect(status().isNotFound());
    mvc.perform(get("/open/a/b")).andExpect(status().isUnauthorized());
    mvc.perform(get("/public/ping")).andExpect(status().isUnauthorized());
  }
}
