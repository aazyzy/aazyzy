package ca.bnc.wealth.api.authorization.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.options;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ca.bnc.wealth.api.authorization.enums.ErrorMessages;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManagerResolver;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.BearerTokenAuthenticationToken;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.intercept.AuthorizationFilter;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.web.SpringJUnitWebConfig;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

/**
 * The filter chain {@link SecurityConfigAdapter} builds: which routes skip security, the 401 entry
 * point, and the order of the four FUM filters. Passes on the Spring Boot 3 and 4 lines alike.
 */
@SpringJUnitWebConfig(classes = {SecurityConfigAdapter.class, SecurityConfigAdapterTest.Beans.class})
@TestPropertySource(properties = "oauth2.unAuthorized.routes=/open/**, /public/ping")
class SecurityConfigAdapterTest {

  private static final String VALID_TOKEN = "valid-token";
  private static final String FILTERS_RUN = "filtersRun";

  @Autowired private WebApplicationContext context;
  @Autowired private SecurityFilterChain filterChain;

  @Autowired
  @Qualifier("springSecurityFilterChain")
  private Filter springSecurityFilterChain;

  private MockMvc mvc;

  @BeforeEach
  void setUp() {
    mvc = MockMvcBuilders.webAppContextSetup(context).addFilters(springSecurityFilterChain).build();
  }

  @Test
  void protectedRouteWithoutTokenRunsTheFiltersThenIsUnauthorized() throws Exception {
    MvcResult result =
        mvc.perform(get("/firms/123"))
            .andExpect(status().isUnauthorized())
            .andExpect(status().reason(ErrorMessages.INVALID_TOKEN.getValue()))
            .andReturn();

    assertThat(result.getRequest().getAttribute(FILTERS_RUN))
        .isEqualTo(List.of("auth", "scope", "permission", "resource"));
  }

  @Test
  void protectedRouteWithInvalidTokenIsUnauthorized() throws Exception {
    MvcResult result =
        mvc.perform(get("/firms/123").header("Authorization", "Bearer not-valid"))
            .andExpect(status().isUnauthorized())
            .andReturn();

    assertThat(result.getRequest().getAttribute(FILTERS_RUN)).isNull();
  }

  @Test
  void protectedRouteWithValidTokenRunsTheFourFiltersInOrder() throws Exception {
    MvcResult result =
        mvc.perform(get("/firms/123").header("Authorization", "Bearer " + VALID_TOKEN))
            .andExpect(status().isNotFound())
            .andReturn();

    assertThat(result.getRequest().getAttribute(FILTERS_RUN))
        .isEqualTo(List.of("auth", "scope", "permission", "resource"));
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "/v2/api-docs/group",
        "/v3/api-docs",
        "/v3/api-docs/swagger-config",
        "/swagger-ui/index.html",
        "/docs/swagger-ui/index.html",
        "/docs/swagger-resources/configuration",
        "/swagger-resources/configuration",
        "/manage/health",
        "/open/a/b",
        "/public/ping"
      })
  void documentationManagementAndConfiguredRoutesSkipSecurity(String path) throws Exception {
    MvcResult result = mvc.perform(get(path)).andExpect(status().isNotFound()).andReturn();

    assertThat(result.getRequest().getAttribute(FILTERS_RUN)).isNull();
  }

  @Test
  void preflightRequestsSkipSecurity() throws Exception {
    MvcResult result = mvc.perform(options("/firms/123")).andReturn();

    assertThat(result.getResponse().getStatus()).isNotEqualTo(HttpServletResponse.SC_UNAUTHORIZED);
    assertThat(result.getRequest().getAttribute(FILTERS_RUN)).isNull();
  }

  @Test
  void fumFiltersRunAfterBearerAuthenticationAndBeforeAuthorization() {
    List<Class<?>> filters =
        filterChain.getFilters().stream().<Class<?>>map(Object::getClass).toList();

    assertThat(filters)
        .containsSubsequence(
            BearerTokenAuthenticationFilter.class,
            AuthFilter.class,
            ScopeFilter.class,
            PermissionFilter.class,
            ResourceFilter.class,
            AuthorizationFilter.class);
  }

  @Configuration
  @EnableWebMvc
  static class Beans {

    @Bean
    AuthFilter authFilter() {
      return new AuthFilter();
    }

    @Bean
    ScopeFilter scopeFilter() {
      return new ScopeFilter();
    }

    @Bean
    PermissionFilter permissionFilter() {
      return new PermissionFilter();
    }

    @Bean
    ResourceFilter resourceFilter() {
      return new ResourceFilter();
    }

    @Bean
    AuthenticationManagerResolver<HttpServletRequest> authenticationManagerResolver() {
      return request ->
          authentication -> {
            String token = ((BearerTokenAuthenticationToken) authentication).getToken();
            if (!VALID_TOKEN.equals(token)) {
              throw new BadCredentialsException("Invalid token");
            }
            Jwt jwt =
                Jwt.withTokenValue(token)
                    .header("alg", "RS256")
                    .subject("user")
                    .issuedAt(Instant.now())
                    .expiresAt(Instant.now().plusSeconds(60))
                    .build();
            return new JwtAuthenticationToken(jwt, List.of());
          };
    }
  }

  /** Records that it ran, so a test can check which filters ran and in what order. */
  abstract static class RecordingFilter extends OncePerRequestFilter {

    private final String name;

    RecordingFilter(String name) {
      this.name = name;
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void doFilterInternal(
        HttpServletRequest request, HttpServletResponse response, FilterChain chain)
        throws ServletException, IOException {
      List<String> run = (List<String>) request.getAttribute(FILTERS_RUN);
      if (run == null) {
        run = new ArrayList<>();
        request.setAttribute(FILTERS_RUN, run);
      }
      run.add(name);
      chain.doFilter(request, response);
    }
  }

  static class AuthFilter extends RecordingFilter implements AuthTokenValidationFilter {
    AuthFilter() {
      super("auth");
    }
  }

  static class ScopeFilter extends RecordingFilter implements ScopeValidationFilter {
    ScopeFilter() {
      super("scope");
    }
  }

  static class PermissionFilter extends RecordingFilter implements PermissionValidationFilter {
    PermissionFilter() {
      super("permission");
    }
  }

  static class ResourceFilter extends RecordingFilter implements ResourceValidationFilter {
    ResourceFilter() {
      super("resource");
    }
  }
}
