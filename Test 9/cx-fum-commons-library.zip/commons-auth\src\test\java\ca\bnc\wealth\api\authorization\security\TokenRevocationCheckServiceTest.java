package ca.bnc.wealth.api.authorization.security;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.RedisConnectionFailureException;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class TokenRevocationCheckServiceTest {

  @Mock private RedisTemplate<String, Object> redisTemplate;

  private TokenRevocationCheckService service;

  @BeforeEach
  void setUp() {
    service = new TokenRevocationCheckService(redisTemplate);
    ReflectionTestUtils.setField(service, "revocationEnabled", true);
  }

  @Test
  void isTokenRevoked_returnsTrueWhenKeyExists() {
    String token = "some.jwt.token";
    when(redisTemplate.hasKey(eq("revoked-token:" + token))).thenReturn(Boolean.TRUE);

    assertTrue(service.isTokenRevoked(token));
  }

  @Test
  void isTokenRevoked_returnsFalseWhenKeyDoesNotExist() {
    String token = "some.jwt.token";
    when(redisTemplate.hasKey(eq("revoked-token:" + token))).thenReturn(Boolean.FALSE);

    assertFalse(service.isTokenRevoked(token));
  }

  @Test
  void isTokenRevoked_returnsFalseWhenKeyReturnsNull() {
    String token = "some.jwt.token";
    when(redisTemplate.hasKey(eq("revoked-token:" + token))).thenReturn(null);

    assertFalse(service.isTokenRevoked(token));
  }

  @Test
  void isTokenRevoked_returnsFalseOnRedisFailure() {
    String token = "some.jwt.token";
    when(redisTemplate.hasKey(eq("revoked-token:" + token)))
        .thenThrow(new RedisConnectionFailureException("Connection refused"));

    assertFalse(service.isTokenRevoked(token));
  }

  @Test
  void isTokenRevoked_returnsFalseWhenDisabled() {
    ReflectionTestUtils.setField(service, "revocationEnabled", false);
    String token = "some.jwt.token";

    assertFalse(service.isTokenRevoked(token));
    verify(redisTemplate, never()).hasKey(eq("revoked-token:" + token));
  }
}
