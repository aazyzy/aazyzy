package ca.bnc.wealth.api.authorization.security.util;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import jakarta.servlet.http.HttpServletRequest;
import java.util.HashMap;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerExecutionChain;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

@Slf4j
public class ClassUtilTest {


  //@Test
  public void getApiMethod() throws Exception {
    ClassUtil classUtil = new ClassUtil();
    MockHttpServletRequest req = new MockHttpServletRequest();
    ApplicationContext appContext = mock(ApplicationContext.class);
    ReflectionTestUtils.setField(classUtil, "appContext", appContext);
    RequestMappingHandlerMapping requestMappingHandlerMapping = mock(RequestMappingHandlerMapping.class);
    when(appContext.getBean(eq("requestMappingHandlerMapping"))).thenReturn(requestMappingHandlerMapping);
    HandlerExecutionChain handlerExeChain = mock(HandlerExecutionChain.class);
    when(requestMappingHandlerMapping.getHandler(any(MockHttpServletRequest.class))).thenReturn(handlerExeChain);
    HandlerExecutionChain test = requestMappingHandlerMapping.getHandler(req);
    HandlerMethod handlerMethod = mock(HandlerMethod.class);
    when(handlerExeChain.getHandler()).thenReturn(handlerMethod);
    when(handlerMethod.getBean()).thenReturn(new ClassUtil());
    when(handlerMethod.getMethod()).thenReturn(ClassUtil.class.getMethod("getApiMethod", HttpServletRequest.class));

    classUtil.getApiMethod(req);
  }

  @Test(expected = Exception.class)
  public void getApiMethod_gethandlerException() throws Exception {
    ClassUtil classUtil = new ClassUtil();
    ApplicationContext appContext = mock(ApplicationContext.class);
    ReflectionTestUtils.setField(classUtil, "appContext", appContext);

    RequestMappingHandlerMapping requestMappingHandlerMapping = mock(RequestMappingHandlerMapping.class);
    when(appContext.getBean(eq("requestMappingHandlerMapping"))).thenReturn(requestMappingHandlerMapping);
    when(requestMappingHandlerMapping.getHandler(any(MockHttpServletRequest.class))).thenThrow(new RuntimeException());
    when(requestMappingHandlerMapping.getHandlerMethods()).thenReturn(new HashMap<>());
    MockHttpServletRequest req = new MockHttpServletRequest();
    classUtil.getApiMethod(req);
  }
}
