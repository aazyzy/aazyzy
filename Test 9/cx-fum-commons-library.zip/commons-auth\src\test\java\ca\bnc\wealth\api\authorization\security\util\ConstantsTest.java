package ca.bnc.wealth.api.authorization.security.util;

import java.lang.reflect.Constructor;
import org.junit.Test;

public class ConstantsTest {

  @Test(expected = IllegalStateException.class)
  public void testConstantsConstructor() throws Exception {
    Constructor<Constants> constructor = Constants.class.getDeclaredConstructor();
    constructor.setAccessible(true);
    try {
      constructor.newInstance();
    } catch (Exception e) {
      throw (IllegalStateException) e.getCause();
    }
  }
}
