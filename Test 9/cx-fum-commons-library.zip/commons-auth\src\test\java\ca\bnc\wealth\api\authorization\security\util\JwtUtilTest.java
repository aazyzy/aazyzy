package ca.bnc.wealth.api.authorization.security.util;

import ca.bnc.wealth.api.authorization.model.User;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTParser;
import feign.Logger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import org.junit.Before;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.test.util.ReflectionTestUtils;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.dataformat.yaml.YAMLMapper;

public class JwtUtilTest {
  private Jwt jwtToken;
  private Jwt systemToken;
  private Jwt empToken;
  private final ObjectMapper mapper = YAMLMapper.builder().build();
  private Map map;

  @SneakyThrows
  @Before
  public void setup() {
    map = mapper.readValue(new ClassPathResource("application.yml").getInputStream(), Map.class);
    JWT jwt = JWTParser.parse(map.get("JWT_TOKEN").toString());
    jwtToken =
        Jwt.withTokenValue(map.get("JWT_TOKEN").toString())
            .header("alg", jwt.getHeader().getAlgorithm())
            .claim("scp", jwt.getJWTClaimsSet().getClaim("scp"))
            .claim("sub", jwt.getJWTClaimsSet().getClaim("sub"))
            .claim("groups", jwt.getJWTClaimsSet().getClaim("groups"))
            .build();
    jwt = JWTParser.parse(map.get("SYSTEM_TOKEN").toString());
    systemToken =
        Jwt.withTokenValue(map.get("SYSTEM_TOKEN").toString())
            .header("alg", jwt.getHeader().getAlgorithm())
            .claim("sub", jwt.getJWTClaimsSet().getClaim("sub"))
            .claim("iss", "https://sys-pp.bnc.ca/oauth2/ausor48vg7KVinzMM0h7")
            .build();

    jwt = JWTParser.parse(map.get("EMPLOYEE_TOKEN").toString());
    empToken =
        Jwt.withTokenValue(map.get("EMPLOYEE_TOKEN").toString())
            .header("alg", jwt.getHeader().getAlgorithm())
            .claim("sub", jwt.getJWTClaimsSet().getClaim("sub"))
            .claim("iss", "https://emp-nbc.oktapreview.com/oauth2/aust4o2r54FVc1IGl0h7")
            .build();
  }

  @SneakyThrows
  @Test
  public void createUserObjectTest() {
    User user = JwtUtil.createUserObject(jwtToken);
    assert (user.getRoles().size() > 0);
    assert (user.getGroups().size() > 0);
    assert (user.getIdpSubject() != null);
  }

  @Test
  public void enrichUserObjectTest() {
    Map userConfiguration =
        new HashMap() {
          {
            put("idpUserId", "TEST");
            put("email", "TEST");
            put("username", map.get("TEST_USERNAME").toString());
            put("firstName", "TEST");
            put("lastName", "TEST");
          }
        };
    User user = new User();
    JwtUtil.enrichUserObject(userConfiguration, user);
    assert (user.getEmail().equals("TEST"));
  }

  @SneakyThrows
  @Test
  public void jsonArrayToListTest() {
    List claimsList =
        JwtUtil.jsonArrayToList(
            "[\n"
                + "    \"ciam:profiles:write\",\n"
                + "    \"wealth:cx-user-conf:viewer\",\n"
                + "    \"ciam:profiles:read\"\n"
                + "  ]");
    assert (claimsList.size() == 3);
  }

  @SneakyThrows
  @Test
  public void extractClaimsTest() {
    Map claims = JwtUtil.extractClaims(map.get("JWT_TOKEN").toString());
    assert (claims.containsKey("scp"));
    assert (claims.containsKey("groups"));

    claims = JwtUtil.extractClaims("");
    assert (claims.isEmpty());
  }

  @SneakyThrows
  @Test
  public void stringToJsonArrayTest() {
    List<String> claims =
        JwtUtil.stringToJsonArray(JWTParser.parse(map.get("JWT_TOKEN").toString()).getJWTClaimsSet().getClaim("scp"));
    assert (claims.size() > 0);
  }

  @SneakyThrows
  @Test
  public void stringToJsonArrayTest1() {
    List<String> claims = JwtUtil.stringToJsonArray("");
    assert (claims.size() == 0);
  }

  @Test
  public void isSystemTokenTest() {
    JwtUtil jwtUtil = new JwtUtil();
    ReflectionTestUtils.setField(
        jwtUtil, "systemIssuer", "https://sys-pp.bnc.ca/oauth2/ausor48vg7KVinzMM0h7");
    assert (!jwtUtil.isSystemToken(jwtToken));
  }

  @Test
  public void isSystemTokenTest1() {
    JwtUtil jwtUtil = new JwtUtil();
    ReflectionTestUtils.setField(
        jwtUtil, "systemIssuer", "https://sys-pp.bnc.ca/oauth2/ausor48vg7KVinzMM0h7");
    assert (jwtUtil.isSystemToken(systemToken));
  }

  @Test
  public void isEmployeeTokenTest() {
    JwtUtil jwtUtil = new JwtUtil();
    ReflectionTestUtils.setField(
        jwtUtil, "employeeIssuer", "https://emp-nbc.oktapreview.com/oauth2/aust4o2r54FVc1IGl0h7");
    assert (!jwtUtil.isEmployeeToken(jwtToken));
  }

  @Test
  public void isEmployeeTokenTest1() {
    JwtUtil jwtUtil = new JwtUtil();
    ReflectionTestUtils.setField(
        jwtUtil, "employeeIssuer", "https://emp-nbc.oktapreview.com/oauth2/aust4o2r54FVc1IGl0h7");
    assert (jwtUtil.isEmployeeToken(empToken));
  }

  @Test
  public void cleanRsaKeysTest() {
    JwtUtil jwtUtil = new JwtUtil();
    String cleanString =
        jwtUtil.cleanRsaKeys("-----BEGIN PRIVATE KEY----- Some Data -----END PRIVATE KEY-----");
    assert (!cleanString.contains("BEGIN PRIVATE KEY"));
  }

  @SneakyThrows
  @Test
  public void generateJwtTokenTest() {
    KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
    generator.initialize(2048);
    KeyPair pair = generator.generateKeyPair();
    JwtUtil jwtUtil = new JwtUtil();

    String privateKey = Base64.getEncoder().encodeToString(pair.getPrivate().getEncoded());
    String publicKey = Base64.getEncoder().encodeToString(pair.getPublic().getEncoded());

    String jwt =
        jwtUtil.generateJwtToken(
            jwtUtil.cleanRsaKeys(publicKey),
            jwtUtil.cleanRsaKeys(privateKey),
            "TEST",
            "TEST",
            "TEST_AUDIENCE");
    Map claims = JwtUtil.extractClaims(jwt);
    assert (claims.containsKey("iss"));
    assert (claims.get("iss").equals("TEST"));
  }

  @Test
  public void testGetFeignLoggingLevel() {
    JwtUtil jwtUtil = new JwtUtil();
    assert (jwtUtil.getFeignLoggingLevel("INFO").equals(Logger.Level.BASIC));
    assert (jwtUtil.getFeignLoggingLevel("BASIC").equals(Logger.Level.BASIC));
    assert (jwtUtil.getFeignLoggingLevel("NONE").equals(Logger.Level.NONE));
    assert (jwtUtil.getFeignLoggingLevel("HEADERS").equals(Logger.Level.HEADERS));
    assert (jwtUtil.getFeignLoggingLevel("FULL").equals(Logger.Level.FULL));
    assert (jwtUtil.getFeignLoggingLevel(null).equals(Logger.Level.BASIC));
  }
}
