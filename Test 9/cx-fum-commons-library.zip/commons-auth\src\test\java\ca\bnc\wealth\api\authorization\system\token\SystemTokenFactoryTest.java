package ca.bnc.wealth.api.authorization.system.token;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.core.env.Environment;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

import ca.bnc.wealth.api.authorization.security.util.Constants;

@RunWith(SpringRunner.class)
public class SystemTokenFactoryTest {

  private static final String SERVICE_NAME = "SERVICE_NAME";
  private static final String TOKEN = "TOKEN";
  private static final Map<String, SystemTokenService> map = new ConcurrentHashMap<>();

  @MockitoBean
  private ConfigurableListableBeanFactory beanFactory;

  private Environment environment;

  private SystemTokenFactory systemTokenFactory;

  @Before
  public void setup() throws IllegalAccessException {
    environment = mock(Environment.class);
    when(environment.getActiveProfiles()).thenReturn(new String[] { "dev" }); 
    systemTokenFactory = new SystemTokenFactory(environment);
    FieldUtils.writeField(systemTokenFactory, "beanFactory", beanFactory, true);

    SystemTokenServiceImpl systemTokenService = mock(SystemTokenServiceImpl.class);
    when(systemTokenService.getSystemToken()).thenReturn(TOKEN);
    map.put(Constants.SYSTEM_TOKEN_SERVICE_PREFIX + SERVICE_NAME, systemTokenService);
    FieldUtils.writeField(systemTokenFactory, "map", map, true);
  }

  @Test
  public void testGetSystemToken() {
    assertEquals(TOKEN, systemTokenFactory.getSystemToken(SERVICE_NAME));
  }

  @Test
  public void testGetBearerToken() {
    assertEquals("Bearer " + TOKEN, systemTokenFactory.getBearerToken(SERVICE_NAME));
  }
}
