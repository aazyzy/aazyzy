package ca.bnc.wealth.api.authorization.system.token;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.cache.Cache;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

import ca.bnc.wealth.api.authorization.exception.SystemTokenException;
import ca.bnc.wealth.api.authorization.feign.client.SystemTokenConfigClient;
import ca.bnc.wealth.api.authorization.feign.client.SystemTokenJwkConfigClient;
import ca.bnc.wealth.api.authorization.model.SystemTokenJwkRequest;
import ca.bnc.wealth.api.authorization.model.SystemTokenRequest;
import ca.bnc.wealth.api.authorization.security.util.JwtUtil;
import ca.bnc.wealth.api.authorization.system.token.config.SystemTokenProperty;
import lombok.SneakyThrows;

@RunWith(SpringRunner.class)
public class SystemTokenServiceImplTest {

  private static final String SERVICE_NAME = "SERVICE_NAME";
  private static final String TOKEN = "TOKEN";

  @MockitoBean
  private CaffeineCacheManager caffeineCacheManager;
  @MockitoBean
  private SystemTokenConfigClient systemTokenFeignClient;
  @MockitoBean
  private SystemTokenJwkConfigClient systemTokenJwkFeignClient;
  @MockitoBean
  private SystemTokenProperty systemTokenProperty;
  @MockitoBean
  JwtUtil jwtUtil;

  private SystemTokenServiceImpl systemTokenService;

  @Before
  public void init() {
    systemTokenService = new SystemTokenServiceImpl(
        SERVICE_NAME,
        caffeineCacheManager,
        systemTokenFeignClient,
        systemTokenJwkFeignClient,
        systemTokenProperty,
        jwtUtil);
  }

  public void setup() {
    when(systemTokenProperty.getSecret()).thenReturn("");
  }

  public void setupRsa() {
    when(systemTokenProperty.getRsaPublicKey()).thenReturn("RSA_PUBLIC");
    when(systemTokenProperty.getRsaPrivateKey()).thenReturn("RSA_PRIVATE");
    when(systemTokenProperty.getAudience()).thenReturn("AUDIENCE");
    when(systemTokenProperty.getClientId()).thenReturn("CLIENT_ID");
  }

  public ResponseEntity createResponse(Object data, HttpStatus status) {
    HttpHeaders header = new HttpHeaders();
    header.setContentType(MediaType.APPLICATION_JSON);
    ResponseEntity<?> responseEntity = new ResponseEntity<>(data, header, status);
    return responseEntity;
  }

  @Test
  public void testGetSystemToken() {
    setup();
    HashMap<String, String> map = new HashMap<>();
    map.put("access_token", TOKEN);
    when(systemTokenFeignClient.getSystemToken(any(), any())).thenReturn(ResponseEntity.ok(map));
    when(caffeineCacheManager.getCache(any())).thenReturn(mock(Cache.class));
    assertEquals(TOKEN, systemTokenService.getSystemToken());
  }

  @Test
  public void testGetFromCache() {
    setup();
    when(caffeineCacheManager.getCache(any())).thenReturn(null);
    assertTrue(systemTokenService.getFromCache().isEmpty());

    Cache cache = mock(Cache.class);
    when(cache.get(any())).thenReturn(null);
    when(caffeineCacheManager.getCache(any())).thenReturn(cache);
    assertTrue(systemTokenService.getFromCache().isEmpty());

    Cache.ValueWrapper cacheWrapper = mock(Cache.ValueWrapper.class);
    when(cache.get(any())).thenReturn(cacheWrapper);
    when(caffeineCacheManager.getCache(any())).thenReturn(cache);
    assertTrue(systemTokenService.getFromCache().isEmpty());

    when(cacheWrapper.get()).thenReturn(TOKEN);
    when(cache.get(any())).thenReturn(cacheWrapper);
    when(caffeineCacheManager.getCache(any())).thenReturn(cache);
    assertEquals(Optional.ofNullable(null), systemTokenService.getFromCache());
  }

  @Test
  public void testGetFromCache_whenErrorFetchingFromCache_shouldReturnOptionalEmpty() {
    setup();
    Cache cache = mock(Cache.class);
    when(cache.get(any())).thenThrow(new RuntimeException());
    when(caffeineCacheManager.getCache(any())).thenReturn(cache);
    assertTrue(systemTokenService.getFromCache().isEmpty());
  }

  @SneakyThrows
  @Test
  public void testGetSystemTokenSecretBased() {
    when(systemTokenProperty.getSecret()).thenReturn("SECRET");
    setup();
    Map<String, String> tokens = new HashMap<>() {
      {
        put("access_token", TOKEN);
      }
    };
    when(systemTokenFeignClient.getSystemToken(
        Mockito.anyString(), Mockito.any(SystemTokenRequest.class)))
        .thenReturn(createResponse(tokens, HttpStatus.OK));
    when(caffeineCacheManager.getCache(Mockito.anyString())).thenReturn(Mockito.mock(Cache.class));
    assertEquals(TOKEN, systemTokenService.getSystemToken());
  }

  @SneakyThrows
  @Test(expected = SystemTokenException.class)
  public void testGetSystemTokenSecretBasedException() {
    when(systemTokenProperty.getSecret()).thenReturn("SECRET");
    setup();
    Map<String, String> tokens = new HashMap<>() {
      {
        put("NOT_access_token", TOKEN);
      }
    };
    when(systemTokenFeignClient.getSystemToken(
        Mockito.anyString(), Mockito.any(SystemTokenRequest.class)))
        .thenReturn(createResponse(tokens, HttpStatus.GATEWAY_TIMEOUT));
    when(caffeineCacheManager.getCache(Mockito.anyString())).thenReturn(Mockito.mock(Cache.class));
    systemTokenService.getClientSecretBasedSystemToken();
  }

  @SneakyThrows
  @Test(expected = SystemTokenException.class)
  public void testGetSystemTokenSecretBasedException1() {
    when(systemTokenProperty.getSecret()).thenReturn("SECRET");
    setup();
    when(systemTokenFeignClient.getSystemToken(
        Mockito.anyString(), Mockito.any(SystemTokenRequest.class)))
        .thenReturn(createResponse(null, HttpStatus.OK));
    when(caffeineCacheManager.getCache(Mockito.anyString())).thenReturn(Mockito.mock(Cache.class));
    systemTokenService.getClientSecretBasedSystemToken();
  }

  @SneakyThrows
  @Test(expected = NullPointerException.class)
  public void testGetSystemTokenSecretBasedException2() {
    when(systemTokenProperty.getSecret()).thenReturn("SECRET");
    setup();
    when(systemTokenFeignClient.getSystemToken(
        Mockito.anyString(), Mockito.any(SystemTokenRequest.class)))
        .thenThrow(NullPointerException.class);
    when(caffeineCacheManager.getCache(Mockito.anyString())).thenReturn(Mockito.mock(Cache.class));
    systemTokenService.getClientSecretBasedSystemToken();
  }

  @SneakyThrows
  @Test
  public void testGetSystemTokenRsaBased() {
    when(jwtUtil.generateJwtToken(
        "RSA_PUBLIC", "RSA_PRIVATE", "CLIENT_ID", "CLIENT_ID", "AUDIENCE"))
        .thenReturn(TOKEN);
    setupRsa();
    Map<String, String> tokens = new HashMap<>() {
      {
        put("access_token", TOKEN);
      }
    };
    when(systemTokenJwkFeignClient.getSystemToken(Mockito.any(SystemTokenJwkRequest.class)))
        .thenReturn(createResponse(tokens, HttpStatus.OK));
    when(caffeineCacheManager.getCache(Mockito.anyString())).thenReturn(Mockito.mock(Cache.class));
    assertEquals(TOKEN, systemTokenService.getSystemToken());
  }

  @SneakyThrows
  @Test(expected = SystemTokenException.class)
  public void testGetSystemTokenRsaBasedException1() {
    when(jwtUtil.generateJwtToken(
        "RSA_PUBLIC", "RSA_PRIVATE", "CLIENT_ID", "CLIENT_ID", "AUDIENCE"))
        .thenReturn(TOKEN);
    setupRsa();
    Map<String, String> tokens = new HashMap<>() {
      {
        put("NOT_access_token", TOKEN);
      }
    };
    when(systemTokenJwkFeignClient.getSystemToken(Mockito.any(SystemTokenJwkRequest.class)))
        .thenReturn(createResponse(tokens, HttpStatus.OK));
    when(caffeineCacheManager.getCache(Mockito.anyString())).thenReturn(Mockito.mock(Cache.class));
    systemTokenService.getJwkBasedSystemToken();
  }

  @SneakyThrows
  @Test(expected = ClassCastException.class)
  public void testGetSystemTokenRsaBasedException2() {
    when(jwtUtil.generateJwtToken(
        "RSA_PUBLIC", "RSA_PRIVATE", "CLIENT_ID", "CLIENT_ID", "AUDIENCE"))
        .thenReturn(TOKEN);
    setupRsa();

    when(systemTokenJwkFeignClient.getSystemToken(Mockito.any(SystemTokenJwkRequest.class)))
        .thenReturn(createResponse("BAD_DATA", HttpStatus.OK));
    when(caffeineCacheManager.getCache(Mockito.anyString())).thenReturn(Mockito.mock(Cache.class));
    systemTokenService.getJwkBasedSystemToken();
  }

  @SneakyThrows
  @Test(expected = SystemTokenException.class)
  public void testGetSystemTokenException() {
    systemTokenService.getSystemToken();
  }

  @SneakyThrows
  @Test(expected = SystemTokenException.class)
  public void testGetSystemTokenExceptionNoPrivate() {
    when(systemTokenProperty.getRsaPublicKey()).thenReturn("RSA_PUBLIC");
    systemTokenService.getSystemToken();
  }
}
