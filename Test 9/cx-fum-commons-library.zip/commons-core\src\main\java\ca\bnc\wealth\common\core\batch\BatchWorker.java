package ca.bnc.wealth.common.core.batch;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.ListUtils;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * Generic BatchWorker that splits the input data into partitions or chunks
 * Each partition is processed in parallel on a separate thread within a thread pool
 *
 * @param <T>
 * @param <R>
 */
@Slf4j
public class BatchWorker<T, R> {

    /**
     * Runs a task in parallel by partitioning the input data
     *
     * @param task      - a generic function that takes a list of T as input and returns a list of R as output result
     * @param inputList - the input data (list of T)
     * @return
     */
    public List<R> run(Function<List<T>, List<R>> task, List<T> inputList, int numWorkers) {
        log.info("BatchWorker - Start of run. Count of input rows: {}", inputList.size());

        if (inputList.isEmpty()) {
            return Collections.emptyList();
        }

        ExecutorService executorService = Executors.newFixedThreadPool(numWorkers);

        // Split input data into partitions based on number of worker threads
        int partitionSize = (int) Math.ceil((double) inputList.size() / numWorkers);
        List<List<T>> partitions = ListUtils.partition(inputList, partitionSize);

        log.info("BatchWorker - Split data into {} partitions", partitions.size());
        IntStream.range(0, partitions.size()).forEach(i -> log.info("BatchWorker - Partition {}: Number of rows = {}", i, partitions.get(i).size()));

        // Create a CompletableFuture for each partition and execute the task asynchronously in the given executor
        List<CompletableFuture<List<R>>> futuresList = partitions.stream()
                .map(partition -> (CompletableFuture.supplyAsync(() -> task.apply(partition), executorService)))
                .collect(Collectors.toList());

        // Wait for all CompletableFutures to finish and flatten results
        List<R> results = futuresList.stream()
                .map(CompletableFuture::join)
                .flatMap(List::stream)
                .collect(Collectors.toList());

        executorService.shutdown();

        log.info("BatchWorker - End of run. Count of output rows: {}", results.size());

        return results;
    }
}
