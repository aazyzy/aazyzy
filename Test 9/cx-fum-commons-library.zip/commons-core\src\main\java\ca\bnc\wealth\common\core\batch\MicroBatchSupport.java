package ca.bnc.wealth.common.core.batch;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Stream;

public class MicroBatchSupport {

    public static <T> Function<T, Optional<List<T>>> function(int batchSize, T eos) {
        
    	final List<T> microBatch = new ArrayList<>(batchSize);
        final int[] counter = {0};
        final boolean[] closed = {false};
        
        return e -> {
            List<T> list;
            ++counter[0];
            if (e == eos) {
                closed[0] = true;
            } else {
                microBatch.add(e);
            }
            if (counter[0] == batchSize || closed[0]) {
                list = new ArrayList<>(microBatch);
                microBatch.clear();
                counter[0] = 0;
            } else {
                list = null;
            }
            return Optional.ofNullable(list);
        };
    }

    /**
     *
     * @param elements list of non-null elements
     * @param batchSize
     * @return
     * @param <T> element type
     */
    public static <T> Stream<List<T>> stream(List<T> elements, int batchSize) {
        
    	Objects.requireNonNull(elements);
        final Iterator<T> itr = elements.iterator();
        
        return stream(() -> itr.hasNext() ? itr.next() : null, batchSize, null);
    }

    /**
     *
     * @param supplier
     * @param batchSize
     * @param eos This value when supplied from the 'supplier' will terminate micro-batching
     * @return
     * @param <T>
     */
    public static <T> Stream<List<T>> stream(Supplier<T> supplier, int batchSize, final T eos) {
        
    	final List<T> microBatch = new ArrayList<>(batchSize);
        final int[] counter = {0};
        final boolean[] closed = {false};
        final Stream<T> stream = Stream.iterate(supplier.get(), e -> !closed[0], e -> supplier.get());
        
        return stream.map(e -> {
            List<T> list;
            ++counter[0];
            
            if (e == eos) {
                closed[0] = true;
            } else {
                microBatch.add(e);
            }
            
            if (counter[0] == batchSize || closed[0]) {
                list = new ArrayList<>(microBatch);
                microBatch.clear();
                counter[0] = 0;
            } else {
                list = Collections.emptyList();
            }
            return list;
        } ).filter(Predicate.not(Collection::isEmpty));
    }
}