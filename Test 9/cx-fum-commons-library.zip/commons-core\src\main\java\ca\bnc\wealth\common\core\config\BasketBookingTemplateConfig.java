package ca.bnc.wealth.common.core.config;

import ca.bnc.wealth.common.core.constants.ErrorMessages;
import ca.bnc.wealth.common.core.enums.TemplateFormat;
import ca.bnc.wealth.common.core.model.Field;
import ca.bnc.wealth.common.core.model.Template;
import jakarta.annotation.PostConstruct;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.collections4.Transformer;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.DeserializationFeature;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.dataformat.yaml.YAMLMapper;

/**
 * This class loads the Basket Booking Template metadata from the
 * basket-booking-template-validator.yaml
 */
@Slf4j
@Configuration
public class BasketBookingTemplateConfig {

    @Value("${yaml.file}")
    private String yamlFile;

    private static Map<TemplateFormat, Template> templateMap = new EnumMap<>(TemplateFormat.class);

    @PostConstruct
    public void init() throws IOException {
        List<Template> templates = loadYamlFileToConfigList();
        templateMap = convertTemplatesToMap(templates);
    }

    /**
     * get the list of {@link Field}s for a given {@link TemplateFormat}
     * @param templateFormat the {@link TemplateFormat}
     * @return the list of {@link Field}s
     */
    public List<Field> getFieldsByTemplateFormat(TemplateFormat templateFormat) {
        return Arrays.asList(templateMap.get(templateFormat).getFields());
    }

    /**
     * Load yaml file and convert it to a map for templates.
     *
     * @return a Map with key {@link TemplateFormat}, value {@link Template}
     */
    public Map<TemplateFormat, Template> getValidationRules()  {
        return templateMap;
    }

    /**
     * Load yaml file and parse config to Template object
     *
     * @return list of Template {@link Template}
     * @throws IOException if error with IO
     */
    private List<Template> loadYamlFileToConfigList() throws IOException {
        File templatesConfigFile;
        try (InputStream inputStream = BasketBookingTemplateConfig.class.getResourceAsStream(
                "/" + yamlFile)) {
            templatesConfigFile = File.createTempFile("templates", ".yaml");
            FileUtils.copyInputStreamToFile(inputStream, templatesConfigFile);
        }
        ObjectMapper objectMapper = YAMLMapper.builder()
                .configureForJackson2()
                .enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
                .build();
        JsonNode rootNode = objectMapper.readTree(templatesConfigFile);
        JsonNode node = rootNode.path("templates");
        List<Template> config;
        try {
            config = objectMapper.convertValue(node, new TypeReference<List<Template>>() {});
        } catch (Exception e) {
            log.warn(ErrorMessages.ERROR_MESSAGE_YAML_FILE_CONVERT_FAILED + " " + e.getMessage());
            throw e;
        }

        return config;
    }

    /**
     * Convert template list to map
     *
     * @param templates parsed from yaml file {@link Template}
     * @return map of <TemplateFormat, Template>  {@link TemplateFormat}, {@link Template }
     */
    private Map<TemplateFormat, Template> convertTemplatesToMap(List<Template> templates) {
        if (CollectionUtils.isEmpty(templates)) {
            return templateMap;
        }
        MapUtils.populateMap(templateMap, templates, new Transformer<Template, TemplateFormat>() {
            @SneakyThrows
            @Override
            public TemplateFormat transform(Template template) {
                Optional<TemplateFormat> templateFormatOptional = TemplateFormat.getEnumByTemplateName(
                        template.getTemplateName());
                if (templateFormatOptional.isPresent()) {
                    return templateFormatOptional.get();
                }
                log.warn(ErrorMessages.ERROR_MESSAGE_TEMPLATE_NAME_NOT_VALID);
                throw new Exception(ErrorMessages.ERROR_MESSAGE_TEMPLATE_NAME_NOT_VALID);
            }
        });

        return templateMap;
    }

}

