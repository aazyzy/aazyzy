package ca.bnc.wealth.common.core.config;

import ca.bnc.wealth.common.core.feign.UserConfigApiClient;
import feign.Feign;
import feign.Logger;
import feign.RequestInterceptor;
import feign.Util;
import feign.codec.Decoder;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.support.StaticListableBeanFactory;
import org.springframework.boot.http.converter.autoconfigure.ClientHttpMessageConvertersCustomizer;
import org.springframework.cloud.openfeign.support.FeignHttpMessageConverters;
import org.springframework.cloud.openfeign.support.HttpMessageConverterCustomizer;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.cloud.openfeign.support.SpringEncoder;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.converter.json.JacksonJsonHttpMessageConverter;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import tools.jackson.databind.JavaType;
import tools.jackson.databind.cfg.DateTimeFeature;
import tools.jackson.databind.json.JsonMapper;

import java.util.Optional;

@Configuration
public class FeignConfig {
    // Jackson 2 defaults: what the Spring Boot 3 line's new ObjectMapper() with JavaTimeModule read
    private static final JsonMapper DECODER_MAPPER = JsonMapper.builderWithJackson2Defaults()
            .disable(DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS)
            .build();

    @Value("${feign.userConfigApi.url}")
    private String userConfigApiUrl;

    @Bean("commonsUserConfigApiClient")
    public UserConfigApiClient getUserConfigAPIClient(JsonMapper jsonMapper) {
        return Feign.builder()
                .requestInterceptor(requestInterceptor())
                .client(new OkHttpClient())
                .contract(new SpringMvcContract())
                .encoder(jsonEncoder(jsonMapper))
                .decoder(new ResponseEntityDecoder(getDecoder()))
                .logger(new Slf4jLogger(UserConfigApiClient.class))
                .logLevel(Logger.Level.FULL).target(UserConfigApiClient.class, userConfigApiUrl);
    }

    @Bean("commonsDecoder")
    public Decoder getDecoder() {
        return (response, type) -> {
            String bodyStr = Util.toString(response.body().asReader(Util.UTF_8));
            JavaType javaType = DECODER_MAPPER.getTypeFactory().constructType(type);
            return DECODER_MAPPER.readValue(bodyStr, javaType);
        };
    }

    @Bean("commonsRequestInterceptor")
    public RequestInterceptor requestInterceptor() {
        return requestTemplate -> {
            if (!requestTemplate.headers().containsKey(HttpHeaders.AUTHORIZATION))
                requestTemplate.header(HttpHeaders.AUTHORIZATION, getBearerToken());
        };
    }

    public static String getBearerToken(){
        return Optional.ofNullable(SecurityContextHolder.getContext().getAuthentication())
                .map(authentication -> (Jwt)authentication.getPrincipal())
                .map(jwt -> "Bearer " + jwt.getTokenValue()).orElse(null);

    }

    // Spring's default client converters, with the JSON one writing through the given mapper
    static SpringEncoder jsonEncoder(JsonMapper jsonMapper) {
        StaticListableBeanFactory beans = new StaticListableBeanFactory();
        beans.addBean("jsonConverter", (ClientHttpMessageConvertersCustomizer) builder ->
                builder.withJsonConverter(new JacksonJsonHttpMessageConverter(jsonMapper)));
        beans.addBean("feignHttpMessageConverters", new FeignHttpMessageConverters(
                beans.getBeanProvider(ClientHttpMessageConvertersCustomizer.class),
                beans.getBeanProvider(HttpMessageConverterCustomizer.class)));
        return new SpringEncoder(beans.getBeanProvider(FeignHttpMessageConverters.class));
    }
}
