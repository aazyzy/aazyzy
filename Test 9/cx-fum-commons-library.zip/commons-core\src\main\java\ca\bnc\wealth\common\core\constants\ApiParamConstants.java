package ca.bnc.wealth.common.core.constants;

/**
 * This class defines some shared params and values for API calls
 */
public class ApiParamConstants {

  public static final String PARAM_FORMAT = "format";
  public static final String PARAM_FORMAT_BULK = "bulk";
}
