package ca.bnc.wealth.common.core.constants;

/**
 *  This class defines placeholders which will be used in payload or json files
 */
public class BulkRequestPayloadConstants {
    public static final String BATCH_ID_PLACEHOLDER = "{{batchId}}";
}
