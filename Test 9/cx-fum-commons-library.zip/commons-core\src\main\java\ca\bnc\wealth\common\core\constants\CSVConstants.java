package ca.bnc.wealth.common.core.constants;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * Define CSV processing headers
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CSVConstants {
    public static final String CSV_ROW_NUMBER = "row-number";
}
