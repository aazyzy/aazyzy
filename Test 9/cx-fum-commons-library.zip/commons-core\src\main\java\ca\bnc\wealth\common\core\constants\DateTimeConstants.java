package ca.bnc.wealth.common.core.constants;

public class DateTimeConstants {
    // Date and time patterns
    public static final String DATE_PATTERN_DASHES = "yyyy-MM-dd";
    public static final String DATE_PATTERN_SLASHES = "yyyy/MM/dd";
    public static final String DATETIME_PATTERN_DASHES = "yyyy-MM-dd'T'HH:mm:ss.SSS";
    public static final String DATETIME_PATTERN_SPACES = "MMM dd yyyy HH:mm:ss:SSS";
    public static final String DATETIME_PATTERN_ISO = "yyyy-MM-dd HH:mm:ss";

    // Date math expressions
    public static final String NOW = "now";
    public static final String MINUS = "-";
    public static final String DAYS = "d";

    // Timezone constants
    public static final String ZONE_ID_AMERICA_NEW_YORK = "America/New_York";

    private DateTimeConstants() {
    }
}
