package ca.bnc.wealth.common.core.constants;

/**
 * Define error messages
 */
public class ErrorMessages {
    public static final String ERROR_MESSAGE_YAML_FILE_CONVERT_FAILED = "Yaml file convert failed.";
    public static final String ERROR_MESSAGE_TEMPLATE_NAME_NOT_VALID = "Template name is not valid.";
    public static final String ERROR_MESSAGE_TEMPLATES_YAML_FILE_PARSE_FAILED = "Templates yaml file parsing failed.";
    public static final String ERROR_MESSAGE_TEMPLATE_NOT_FOUND = "Template %s is not found.";

    public static final String ERROR_MESSAGE_INCORRECT_TEMPLATE_COLUMNS_MISSING = "Incorrect template: The mandatory columns are not available in file";

}
