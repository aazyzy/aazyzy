package ca.bnc.wealth.common.core.constants;

public class LanguageConstants {
    public static final String EN = "en";
    public static final String FR = "fr";

    private LanguageConstants() {
    }
}
