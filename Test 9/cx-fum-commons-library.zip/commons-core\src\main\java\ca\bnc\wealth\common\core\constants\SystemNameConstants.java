package ca.bnc.wealth.common.core.constants;

public class SystemNameConstants {
    public static final String NBIN = "nbin";
    public static final String INSTRUMENT_EVENTS_ADAPTER = "instrument-events-adapter";

    private SystemNameConstants() {
    }
}
