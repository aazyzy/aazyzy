package ca.bnc.wealth.common.core.constants;

public class SystemUserConstants {
    public static final String COMPASSX_ADMIN = "cxadmin";

    private SystemUserConstants() {
    }
}
