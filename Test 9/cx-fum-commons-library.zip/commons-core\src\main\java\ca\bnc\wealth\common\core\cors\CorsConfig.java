package ca.bnc.wealth.common.core.cors;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


@Configuration
@ConfigurationProperties(prefix = "cors")
@Data
public class CorsConfig implements WebMvcConfigurer {

    public CorsConfig(String[] allowedOrigins) {
        this.allowedOrigins = allowedOrigins;
    }

    @Value("${allowed-origins:}")
    private String[] allowedOrigins;

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins(allowedOrigins)
                .allowedMethods("GET","HEAD","POST", "PUT", "DELETE", "CONNECT", "OPTIONS", "TRACE", "PATCH")
                .allowedHeaders("*")
                .allowCredentials(true);
    }
}
