package ca.bnc.wealth.common.core.enums;

public enum Capability {
    ORDER_ENTRY
}
