package ca.bnc.wealth.common.core.enums;

public enum DateOperation {
    ADD, SUBTRACT
}
