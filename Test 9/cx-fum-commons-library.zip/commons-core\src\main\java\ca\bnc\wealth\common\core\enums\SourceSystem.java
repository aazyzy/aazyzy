package ca.bnc.wealth.common.core.enums;

import lombok.Getter;

@Getter
public enum SourceSystem {

    CX_TRADING("6588", "cx-trading"),
    PRIME_OE("0605", "primeOE"),
    CDB("6588", "CDB"),
    BULK_ACTIONS("6588", "bulk-actions");


    private final String nbcID;
    private final String name;

    SourceSystem(String nbcID, String name) {
        this.nbcID = nbcID;
        this.name = name;
    }
}
