package ca.bnc.wealth.common.core.enums;

import java.util.Optional;
import java.util.stream.Stream;

/**
 * Gets or sets template value for basket booking
 */
public enum TemplateFormat {
	COMPASSX("compassX");

	private final String templateName;

	TemplateFormat(String name) {
		templateName = name;
	}

	public String getValue() {
		return templateName;
	}

	public static Optional<TemplateFormat> getEnumByTemplateName(String templateName){
		return Stream.of(TemplateFormat.values())
				.filter(v -> v.getValue().equalsIgnoreCase(templateName))
				.findFirst();
	}
}
