package ca.bnc.wealth.common.core.feign;

import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@FeignClient(name = "commonsUserConfigApiClient", url = "${feign.userConfigApi.url}")
public interface UserConfigApiClient {
    @RequestMapping(path = "/users/me/rr-codes", method = RequestMethod.GET)
    List<RRCodeRange> getRRCodes();
}