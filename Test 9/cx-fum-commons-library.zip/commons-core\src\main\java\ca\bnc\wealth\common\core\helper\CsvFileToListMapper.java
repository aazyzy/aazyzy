package ca.bnc.wealth.common.core.helper;

import ca.bnc.wealth.common.core.config.BasketBookingTemplateConfig;
import ca.bnc.wealth.common.core.enums.TemplateFormat;
import ca.bnc.wealth.common.core.model.Template;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static ca.bnc.wealth.common.core.constants.CSVConstants.CSV_ROW_NUMBER;
import static ca.bnc.wealth.common.core.constants.ErrorMessages.ERROR_MESSAGE_INCORRECT_TEMPLATE_COLUMNS_MISSING;
import static ca.bnc.wealth.common.core.constants.ErrorMessages.ERROR_MESSAGE_TEMPLATE_NOT_FOUND;

/**
 * This class will convert a CSV file to a {@link List} of {@link Map}.
 * Each map represents a row of records
 *
 */
@Slf4j
@Component
public class CsvFileToListMapper {

    private BasketBookingTemplateConfig basketBookingTemplateConfig;

    /**
     * Constructor
     * @param basketBookingTemplateConfig the {@link BasketBookingTemplateConfig}
     */
    @Autowired
    public CsvFileToListMapper(BasketBookingTemplateConfig basketBookingTemplateConfig) {
        this.basketBookingTemplateConfig = basketBookingTemplateConfig;
    }

    /**
     * Converts a CSV file to a {@link List} of {@link Map}s
     * Each map will be a Header -> Value represents a row in the csv file.
     * @param csvFile the CSV file to be converted
     * @param templateFormat the {@link TemplateFormat} will be used to parse the file with
     * @return the list of content maps from the CSV file
     * @throws Exception when it happens
     */
    public List<Map<String, String>> convertCsvFileToMap(MultipartFile csvFile,
                                                         TemplateFormat templateFormat)
            throws Exception {
        List<Map<String, String>> results = new ArrayList<>();

        Map<TemplateFormat, Template> templateFormatValidationRulesMap;
        templateFormatValidationRulesMap = basketBookingTemplateConfig.getValidationRules();

        Template template = templateFormatValidationRulesMap.get(templateFormat);
        if (Objects.isNull(template)) {
            throw new Exception(String.format(ERROR_MESSAGE_TEMPLATE_NOT_FOUND, templateFormat));
        }

        try (BufferedReader fileReader = new BufferedReader(
                new InputStreamReader(csvFile.getInputStream(), StandardCharsets.UTF_8));
             CSVParser csvParser = new CSVParser(fileReader,
                     CSVFormat.RFC4180
                             .builder()
                             .setIgnoreEmptyLines(true)
                             .setHeader()
                             .setIgnoreHeaderCase(true)
                             .setSkipHeaderRecord(true)
                             .setTrim(true)
                             .build())) {
            // We can only visit CSVParser once, otherwise you need to reopen the stream
            for (CSVRecord record: csvParser) {
                long lineNum = csvParser.getCurrentLineNumber();
                Map<String, String> rowMap = new HashMap<>();
                rowMap.put(CSV_ROW_NUMBER, String.valueOf(lineNum));
                Arrays.stream(template.getFields()).forEach(field -> {
                    if (!record.isSet(field.getHeaderName()) && field.isMandatory()) {
                        throw new IllegalArgumentException(
                                ERROR_MESSAGE_INCORRECT_TEMPLATE_COLUMNS_MISSING);
                    }
                    if (record.isSet(field.getHeaderName())) {
                        rowMap.put(field.getHeaderName(), record.get(field.getHeaderName()));
                    }
                });
                results.add(rowMap);
            }

            if (CollectionUtils.isEmpty(results)) {
                log.warn("The file has no rows");
                throw new Exception(ERROR_MESSAGE_INCORRECT_TEMPLATE_COLUMNS_MISSING);
            }
        } catch (IOException e) {
            log.warn("Error while parsing csv data. ", e);
            throw e;
        } catch (IllegalArgumentException e) {
            throw new Exception(ERROR_MESSAGE_INCORRECT_TEMPLATE_COLUMNS_MISSING);
        }

        return results;
    }

}
