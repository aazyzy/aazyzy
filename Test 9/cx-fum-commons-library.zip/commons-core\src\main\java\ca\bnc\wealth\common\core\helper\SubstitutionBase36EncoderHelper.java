package ca.bnc.wealth.common.core.helper;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class SubstitutionBase36EncoderHelper {

    private final Map<String, String> substitutionCipher;
    private static final String ORIGINAL_CHARACTER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final String CIPHER_CHARACTER =   "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final int RADIX = 36;


    public SubstitutionBase36EncoderHelper() {
        String[] originalCharacters = ORIGINAL_CHARACTER.split("");
        String[] cipherCharacters = CIPHER_CHARACTER.split("");
        substitutionCipher = new HashMap<>();
        for (int i = 0; i < originalCharacters.length; i++) {
            substitutionCipher.put(originalCharacters[i], cipherCharacters[i]);
        }
    }

    public String createCipherText(String plaintext) {
        return Arrays.stream(plaintext.split("")).map(this::mapPlainCharToCipherChar).collect(Collectors.joining());
    }

    public String mapPlainCharToCipherChar(String plainChar) {
        if(plainChar.length() > 1 || !StringUtils.hasText(plainChar)) {
            return "";
        }
        return substitutionCipher.get(plainChar.toUpperCase(Locale.ROOT));
    }

    public Long base36EncodedCipher(String cipher) {
        return Long.parseLong(cipher, RADIX);
    }
}