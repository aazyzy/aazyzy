package ca.bnc.wealth.common.core.model;

import ca.bnc.wealth.common.core.model.Template;
import lombok.Data;

import java.util.List;

/**
 * This class has all the templates
 */
@Data
public class CSVFileValidation {
    private List<Template> templates;
}
