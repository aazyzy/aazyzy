package ca.bnc.wealth.common.core.model;

import lombok.Getter;
import lombok.Setter;

/**
 * Define if a field needs to be corrected before validating and converting.
 *
 */
@Getter
@Setter
public class Correction {

    /**
     * If the field should be all in uppercase
     */
    private Boolean uppercase;
}
