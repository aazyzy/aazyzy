package ca.bnc.wealth.common.core.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;

import java.util.List;


/**
 * A class to represent Field definition from Yaml files.
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Field {
    /**
     * The name of the filed, should be unique
     */
    @NonNull
    private String fieldName;
    /**
     * The name for the CSV header, used to load value
     */
    @NonNull
    private String headerName;
    /**
     * The schema field for this field
     */
    @NonNull
    private String schemaField;
    /**
     * If this field is mandatory
     */
    private boolean mandatory;
    /**
     * If this field should be corrected
     */
    private Correction correction;
    /**
     * The list of values this field supports
     */
    private List<String> caseSensitiveAcceptableValues;
}

