package ca.bnc.wealth.common.core.model;

import lombok.Data;

/**
 * This class defines all the template properties.
 *      financialInstrumentClassificationCode define financial Instrument as Mutual Fund, Equity Stock, Equity Option, or Common
 *      maxRows defines the max rows of csv file
 *      fileSize defines megabytes of csv file
 *      fileFormat is csv file
 *      headerNames contains all the csv file header name
 *      fields defines all the csv columns needs to be validated, with all the validation rules for each field. {@link Field}
 */
@Data
public class Template {
    private String templateName;
    private String financialInstrumentClassificationCode;
    private long maxRows;
    // File size is in Bytes
    private long fileSize;
    private String fileFormat;
    private String[] headerNames;
    private Field[] fields;
}


