package ca.bnc.wealth.common.core.model.message;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.jackson.Jacksonized;

/**
 * EventMessage defines the message format to be used for event notifications on the messaging bus.
 * It is a generic wrapper used to encapsulate the data, regardless of the data's type
 * Expectation is that systems that need to publish an event will conform to this schema, and consumers will consume events in this schema
 * <p>
 * The header section contains the metadata or information about the message
 * The payload section contains the data, which can be just basic attributes (type and ID) or basic plus full data (base64 encoded).
 *      For time-being, due to security requirements, the payload should only have basic attributes
 * The source section contains info on the source system where the event originated from and system that generated the event
 * The signature section is optional. It contains the digital signature used to verify the authenticity of the message
 */
@Jacksonized
@Getter
@Builder
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EventMessage {
	
    /**
     * Message Header - metadata or information about the message
     */
    private EventMessageHeader header;

    /**
     * Message Source - info on source systems
     */
    private EventMessageSource source;

    /**
     * Message Payload - the data
     */
    private EventMessagePayload payload;

    /**
     * Message Signature - Optional section. The digital signature that can be used verify the authenticity of the message
     */
    private EventMessageSignature signature;
}
