package ca.bnc.wealth.common.core.model.message;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.jackson.Jacksonized;

import java.time.LocalDateTime;

/**
 * Event Message Source
 * Info about the source system that generated the event
 */
@Jacksonized
@Getter
@Builder
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EventMessageSourceSystem {
    /**
     * System that generated the event
     */
    private String system;

    /**
     * CMDB application code or Remedy app id
     */
    private String nbcId;

    /**
     * When the event was generated in ISO-8601 format (yyyy-MM-ddThh:mm:ss+offset)
     */
    private LocalDateTime time;
}
