package ca.bnc.wealth.common.core.search;

import ca.bnc.wealth.common.search.model.SearchRequest;
import ca.bnc.wealth.common.search.model.SearchResponse;

public interface GenericSearch {
    SearchResponse search(SearchRequest request, String language, String configName);
}
