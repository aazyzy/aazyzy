package ca.bnc.wealth.common.core.utils;

import java.util.Locale;
import lombok.extern.slf4j.Slf4j;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Slf4j
public class DateUtil {
    private DateUtil() {
    }

    public static LocalDate stringToLocalDate(String inputDateStr, String pattern) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return LocalDate.parse(inputDateStr, formatter);
    }

    public static LocalDateTime stringToLocalDateTime(String inputDateStr, String pattern, Locale locale) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern, locale);
        return LocalDateTime.parse(inputDateStr, formatter);
    }

    /**
     * @deprecated (Require locale when using a month abbreviation such as Apr or Avr)
     */
    @Deprecated
    public static LocalDateTime stringToLocalDateTime(String inputDateStr, String pattern) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern, Locale.ENGLISH);
        return LocalDateTime.parse(inputDateStr, formatter);
    }

    public static Date stringToDate(String inputDateStr, String pattern) {
        SimpleDateFormat formatter = new SimpleDateFormat(pattern);
        try {
            return formatter.parse(inputDateStr);
        } catch (ParseException e) {
            log.warn("Unable to convert string {} to date", inputDateStr);
           return null;
        }
    }

    public static LocalDate dateToLocalDate(Date inputDate) {
        return inputDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

    public static LocalDateTime dateToLocalDateTime(Date inputDate) {
        return inputDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    }

    public static Date localDateToDate(LocalDate inputDate) {
        ZoneId defaultZoneId = ZoneId.systemDefault();
        return Date.from(inputDate.atStartOfDay(defaultZoneId).toInstant());
    }

    public static Date localDateTimeToDate(LocalDateTime inputDate) {
        ZoneId defaultZoneId = ZoneId.systemDefault();
        return Date.from(inputDate.atZone(defaultZoneId).toInstant());
    }

    public static LocalDateTime getMaxDate(List<LocalDateTime> dates) {
        return dates.stream()
                .filter(Objects::nonNull)
                .max(LocalDateTime::compareTo).orElse(null);
    }
}
