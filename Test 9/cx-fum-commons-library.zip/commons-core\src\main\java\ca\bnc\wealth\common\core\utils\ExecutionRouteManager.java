package ca.bnc.wealth.common.core.utils;

import lombok.AllArgsConstructor;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Slf4j
public class ExecutionRouteManager {

    @AllArgsConstructor
    @ToString
    private static class CalcArgs {
        private int modulo;
        private int addend;
    }

    // Pair < Addend, Modulo >
    private final Map<String, CalcArgs> modeToModuloAddendMapping;

    private ExecutionRouteManager(int totalRoutes, Map<String, Integer> weightedModes) {
        if (totalRoutes < 2) {
            throw new IllegalArgumentException("Min. of two totalRoutes are required");
        }
        int modesCount = weightedModes.size();
        if (modesCount < 2) {
            throw new IllegalArgumentException("Min. of two modes are required");
        }
        String[] modes = new String[modesCount];
        int[][] calcMatrix = new int[modesCount][3];
        int counter = 0;
        int cumulativeWeight = 0;
        int totalWeight = 0;
        for (Map.Entry<String, Integer> entry: weightedModes.entrySet().stream()
                .sorted(Map.Entry.comparingByValue()).toList()) {
            int weight = entry.getValue();
            if (weight < 1) {
                throw new IllegalArgumentException("Weight for every mode should be greater than 0");
            }
            modes[counter] = entry.getKey();
            calcMatrix[counter][0] = weight;
            calcMatrix[counter][1] = cumulativeWeight += weight;
            totalWeight += weight;
            counter++;
        }
        if (totalRoutes % cumulativeWeight != 0) {
            throw new IllegalArgumentException("Cumulative Weight should be a factor of total routes.");
        }
        int hashModulo = totalRoutes / totalWeight;
        this.modeToModuloAddendMapping = new HashMap<>(modesCount);
        modeToModuloAddendMapping.put(modes[0], new CalcArgs(hashModulo, 0));
        for (int i = 1; i < modesCount; i++) {
            modeToModuloAddendMapping.put(modes[i], new CalcArgs( calcMatrix[i][0] * hashModulo, calcMatrix[i-1][1] * hashModulo));
        }
        log.info("modeMapping = {}", modeToModuloAddendMapping);
    }

    public int getRoute(String mode, Object key) {
        CalcArgs pair = Objects.requireNonNull(modeToModuloAddendMapping.get(mode), "** unknown mode " + mode);
        int hashCode = Math.abs(Objects.hashCode(key));
        log.info("hash = {}", hashCode);
        return hashCode % pair.modulo + pair.addend;
    }

    public static ExecutionRouteManager newInstance(int totalRoutes, Map<String, Integer> weightedModes) {
        return new ExecutionRouteManager(totalRoutes, weightedModes);
    }

}
