package ca.bnc.wealth.common.core.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.extern.slf4j.Slf4j;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.cfg.DateTimeFeature;
import tools.jackson.databind.ext.javatime.deser.LocalDateTimeDeserializer;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.module.SimpleModule;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

@Slf4j
public class JsonUtil {
    // Note- use of static is anti-pattern, but only because ObjectMapper is thread-safe
    // Jackson 2 defaults keep the JSON identical to what the Spring Boot 3 line writes
    public static final ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults()
            .addModule(new SimpleModule().addDeserializer(LocalDateTime.class,
                    new LocalDateTimeDeserializer(DateTimeFormatter.ISO_DATE_TIME)))
            .changeDefaultPropertyInclusion(incl -> JsonInclude.Value.construct(JsonInclude.Include.NON_NULL, JsonInclude.Include.NON_NULL))
            .disable(DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS)
            .build();

    private JsonUtil() {
    }

    public static Optional<String> getJsonStr(Object obj) {
        try {
            return Optional.ofNullable(objectMapper.writeValueAsString(obj));
        } catch (JacksonException e) {
            log.warn("Error converting object to JSON string", e);
            return Optional.empty();
        }
    }

    public static <T> Optional<T> parseJson(String jsonStr, Class<T> clazz) {
        try {
            return Optional.ofNullable(objectMapper.readValue(jsonStr, clazz));
        } catch (JacksonException | IllegalArgumentException e) {
            log.warn("Error parsing JSON string: {}", jsonStr, e);
            return Optional.empty();
        }
    }
}
