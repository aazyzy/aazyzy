package ca.bnc.wealth.common.core.utils;

public class StringTemplate {

    private final String[] tokens;

    private StringTemplate(String template, String delimiter) {
        this.tokens = template.split(delimiter);
    }

    public static StringTemplate newInstance(String template) {
        return new StringTemplate(template, "\\{\\{\\}\\}");
    }

    public String getString(String... args) {
        if (tokens.length == 1) {
            return tokens[0];
        }
        if (tokens.length - 1 != args.length) {
            throw new IllegalArgumentException("Placeholders and args count mismatch !!");
        }
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < tokens.length; i++) {
            builder.append(tokens[i]);
            if (i < args.length) {
                builder.append(args[i]);
            }
        }
        return builder.toString();
    }

}
