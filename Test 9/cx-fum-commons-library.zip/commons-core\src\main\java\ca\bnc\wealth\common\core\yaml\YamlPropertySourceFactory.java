package ca.bnc.wealth.common.core.yaml;

import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.support.DefaultPropertySourceFactory;
import org.springframework.core.io.support.EncodedResource;
import java.util.Optional;
import java.util.Properties;

/**
 * Custom PropertySourceFactory that can be passed to @PropertySource to load a YAML file
 * <p>
 * Usage:
 * Create a configuration class with @Configuration (and @ConfigurationProperties)
 * Add the @PropertySource annotation to your configuration class:
 * <code><b>@PropertySource(value = "classpath:<yml_file_name>.yml", factory = YamlPropertySourceFactory.class)</b></code>
 */
public class YamlPropertySourceFactory extends DefaultPropertySourceFactory {
    @Override
    public PropertySource<?> createPropertySource(String name, EncodedResource resource) {
        Properties yamlProperties = loadYaml(resource);
        String sourceName = Optional.ofNullable(name).orElse(resource.getResource().getFilename());
        return new PropertiesPropertySource(sourceName, yamlProperties);
    }

    private Properties loadYaml(EncodedResource resource) {
        YamlPropertiesFactoryBean factory = new YamlPropertiesFactoryBean();
        factory.setResources(resource.getResource());
        factory.afterPropertiesSet();
        return factory.getObject();
    }
}
