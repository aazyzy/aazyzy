package ca.bnc.wealth.common.search.model;

import java.util.Set;

public enum ComparisonOperator {
    CONTAINS("IN"),
    EQUALS("="),
    GREATER_THAN(">"),
    GREATER_THAN_OR_EQUAL(">="),
    LESS_THAN("<"),
    LESS_THAN_OR_EQUAL("<="),
    BETWEEN("BETWEEN"),
    LIKE("LIKE", Set.of(FieldType.STRING)),
    LIKE_CASE_INSENSITIVE("ILIKE", Set.of(FieldType.STRING));

    private final String keyword;
    private final Set<FieldType> supportedTypes;

    ComparisonOperator(String keyword, Set<FieldType> supportedTypes) {
        this.keyword = keyword;
        this.supportedTypes = supportedTypes;
    }

    ComparisonOperator(String keyword) {
        this.keyword = keyword;
        this.supportedTypes = Set.of(FieldType.values());
    }

    public Set<FieldType> getSupportedTypes() {
        return supportedTypes;
    }

    public String getKeyword() {
        return keyword;
    }
}
