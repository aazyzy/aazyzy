package ca.bnc.wealth.common.search.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.time.LocalDate;
import java.time.LocalDateTime;

public enum FieldType {
    INTEGER("integer", Integer.class),
    BIGINT("bigint", Long.class),
    DECIMAL("decimal", Double.class),
    STRING("string", String.class),
    BOOLEAN("boolean", Boolean.class),
    DATE("date", LocalDate.class),
    TIMESTAMP("timestamp", LocalDateTime.class);

    private final String type;
    private final Class<?> clazz;

    FieldType(String type, Class<?> clazz) {
        this.type = type;
        this.clazz = clazz;
    }

    @JsonValue
    public String getType() {
        return type;
    }

    public Class<?> getClazz() {
        return clazz;
    }

    @JsonCreator
    public static FieldType fromType(String type) {
        for (FieldType fieldType : FieldType.values()) {
            if (fieldType.getType().equals(type)) {
                return fieldType;
            }
        }
        throw new IllegalArgumentException("Unknown type: " + type);
    }
}
