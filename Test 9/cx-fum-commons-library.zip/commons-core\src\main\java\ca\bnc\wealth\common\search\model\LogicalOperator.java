package ca.bnc.wealth.common.search.model;

public enum LogicalOperator {
    AND("AND"),
    OR("OR");

    private final String value;

    LogicalOperator(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
