package ca.bnc.wealth.common.search.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum SearchTextType {
    FULL("full"),
    SPLIT("split");

    private final String value;
    SearchTextType(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return this.value;
    }

    public String toString() {
        return String.valueOf(this.value);
    }

    @JsonCreator
    public static SearchTextType fromValue(String value) {
        for (SearchTextType searchTextType : values()) {
            if (searchTextType.getValue().equals(value)) {
                return searchTextType;
            }
        }
        throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
}
