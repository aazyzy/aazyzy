package ca.bnc.wealth.common.search.model;

public enum SortOrder {
    ASC,
    DESC
}
