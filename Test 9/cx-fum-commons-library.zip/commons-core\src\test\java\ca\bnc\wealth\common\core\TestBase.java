package ca.bnc.wealth.common.core;

import ca.bnc.wealth.common.core.model.Field;
import ca.bnc.wealth.common.core.model.Template;
import java.util.ArrayList;
import java.util.List;

/**
 * The test base for unit tests
 */
public class TestBase {

  protected Template generateCompassTemplate() {
    Template compassTemplate  = new Template();
    compassTemplate.setTemplateName("compassX");
    compassTemplate.setFinancialInstrumentClassificationCode("MutualFund");
    compassTemplate.setMaxRows(10000);
    compassTemplate.setFileSize(1048576); // In Bytes
    compassTemplate.setFileFormat("csv");

    String[] headers = new String[]{"Account No*", "Trade type*", "Symbol", "From Symbol",
        "Amount Type*", "Amount*", "Solicitation", "Dividend Options", "Front Load %",
        "Additional Commission", "Net after commissions"};
    compassTemplate.setHeaderNames(headers);

    Field amountType = new Field();
    amountType.setFieldName("amountType");
    amountType.setHeaderName("Amount Type*");
    amountType.setSchemaField("orderHeader.amountTypeCode");
    amountType.setMandatory(true);
    List<String> acceptableValues = new ArrayList<>();
    acceptableValues.add("Quantity");
    acceptableValues.add("Amount");
    acceptableValues.add("All");
    acceptableValues.add("NDSC");
    acceptableValues.add("MUO");
    acceptableValues.add("10F");
    amountType.setCaseSensitiveAcceptableValues(acceptableValues);

    Field amount = new Field();
    amount.setFieldName("amount");
    amount.setHeaderName("Amount*");
    amount.setSchemaField("orderHeader.orderAmount");
    amount.setMandatory(false);
    Field[] fields = new Field[]{amountType, amount};

    compassTemplate.setFields(fields);

    return compassTemplate;
  }
}
