package ca.bnc.wealth.common.core.batch;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class BatchWorkerTests {

    private BatchWorker<Integer, String> batchWorker;

    @Before
    public void setup() {
        batchWorker = new BatchWorker<Integer, String>();
    }

    @Test
    public void testRun() {
        // input parameters
        Function<List<Integer>, List<String>> task = createMockTask();
        List<Integer> inputList = IntStream.range(0, 995)
                .boxed()
                .collect(Collectors.toList());
        int numWorkers = 2;

        // Actual
        List<String> actual = batchWorker.run(task, inputList, numWorkers);

        // Test that output list is not null and expected output is returned
        assertThat(actual).isNotNull();
        assertThat(actual.size()).isEqualTo(inputList.size());
    }

    private Function<List<Integer>, List<String>> createMockTask() {
        // mock task takes List of integers and converts to List of Strings
        return inputList -> inputList.stream()
                .map(String::valueOf)
                .collect(Collectors.toList());
    }
}
