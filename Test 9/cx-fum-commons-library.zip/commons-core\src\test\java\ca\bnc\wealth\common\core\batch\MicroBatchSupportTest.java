package ca.bnc.wealth.common.core.batch;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class MicroBatchSupportTest {

    @Test
    public void testFunctionBatching() {
        int batchSize = 3;
        String eos = "EOS";
        Function<String, Optional<List<String>>> function = MicroBatchSupport.function(batchSize, eos);

        assertEquals(Optional.empty(), function.apply("A"));
        assertEquals(Optional.empty(), function.apply("B"));
        assertEquals(Optional.of(Arrays.asList("A", "B", "C")), function.apply("C"));
        assertEquals(Optional.empty(), function.apply("D"));
        assertEquals(Optional.empty(), function.apply("E"));
        assertEquals(Optional.of(Arrays.asList("D", "E")), function.apply(eos));
    }

    @Test
    public void testStreamBatchingWithList() {
        List<String> elements = Arrays.asList("A", "B", "C", "D", "E");
        int batchSize = 2;
        Stream<List<String>> stream = MicroBatchSupport.stream(elements, batchSize);

        List<List<String>> batches = stream.collect(Collectors.toList());
        assertEquals(3, batches.size());
        assertEquals(Arrays.asList("A", "B"), batches.get(0));
        assertEquals(Arrays.asList("C", "D"), batches.get(1));
        assertEquals(Arrays.asList("E"), batches.get(2));
    }

    @Test
    public void testStreamBatchingWithSupplier() {
        List<String> elements = Arrays.asList("A", "B", "C", "D", "E");
        Iterator<String> iterator = elements.iterator();
        Supplier<String> supplier = () -> iterator.hasNext() ? iterator.next() : null;
        int batchSize = 2;
        String eos = null;
        Stream<List<String>> stream = MicroBatchSupport.stream(supplier, batchSize, eos);

        List<List<String>> batches = stream.collect(Collectors.toList());
        assertEquals(3, batches.size());
        assertEquals(Arrays.asList("A", "B"), batches.get(0));
        assertEquals(Arrays.asList("C", "D"), batches.get(1));
        assertEquals(Arrays.asList("E"), batches.get(2));
    }
    
    @Test
    public void testStreamBatchingWithSupplier_empty() {
        List<String> elements = new ArrayList<>();
        Iterator<String> iterator = elements.iterator();
        Supplier<String> supplier = () -> iterator.hasNext() ? iterator.next() : null;
        int batchSize = 2;
        String eos = null;
        Stream<List<String>> stream = MicroBatchSupport.stream(supplier, batchSize, eos);

        List<List<String>> batches = stream.collect(Collectors.toList());
        assertEquals(0, batches.size());
    }
    
    @Test
    public void testStreamBatchingWithSupplier_singleItem() {
        List<String> elements = Arrays.asList("A");
        Iterator<String> iterator = elements.iterator();
        Supplier<String> supplier = () -> iterator.hasNext() ? iterator.next() : null;
        int batchSize = 2;
        String eos = null;
        Stream<List<String>> stream = MicroBatchSupport.stream(supplier, batchSize, eos);

        List<List<String>> batches = stream.collect(Collectors.toList());
        assertEquals(1, batches.size());
        assertEquals(Arrays.asList("A"), batches.get(0));
    }

    @Test
    public void testStreamBatchingWithSupplierAndEOS() {
        List<String> elements = Arrays.asList("A", "B", "C", "EOS", "D", "E");
        Iterator<String> iterator = elements.iterator();
        Supplier<String> supplier = () -> iterator.hasNext() ? iterator.next() : null;
        int batchSize = 2;
        String eos = "EOS";
        Stream<List<String>> stream = MicroBatchSupport.stream(supplier, batchSize, eos);

        List<List<String>> batches = stream.collect(Collectors.toList());
        assertEquals(2, batches.size());
        assertEquals(Arrays.asList("A", "B"), batches.get(0));
        assertEquals(Arrays.asList("C"), batches.get(1));
    }
}