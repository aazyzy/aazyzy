package ca.bnc.wealth.common.core.config;

import ca.bnc.wealth.common.core.TestBase;
import ca.bnc.wealth.common.core.enums.TemplateFormat;
import ca.bnc.wealth.common.core.model.Field;
import ca.bnc.wealth.common.core.model.Template;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Load sample yaml file from resources folder and verify the loaded data
 */
@ExtendWith(MockitoExtension.class)
public class BasketBookingTemplateValidatorConfigTest extends TestBase {

  private static BasketBookingTemplateConfig basketBookingTemplateConfig;

  @BeforeEach
  void initEach() {
    basketBookingTemplateConfig = new BasketBookingTemplateConfig();
  }

  @Test
  public void whenYamlFileWasLoaded_ThenConfigListIsGenerated_AndConfigValueIsCorrect()
          throws IOException {

    //Given
    Map<TemplateFormat, Template> expectedResult = new HashMap<>();
    expectedResult.put(TemplateFormat.COMPASSX, generateCompassTemplate());

    // Set YAML file name to read in
    ReflectionTestUtils.setField(basketBookingTemplateConfig, "yamlFile",
            "basket-booking-template-validator.yaml");

    //CUT
    basketBookingTemplateConfig.init(); // Call @PostConstruct manually
    Map<TemplateFormat, Template> validationRules = basketBookingTemplateConfig.getValidationRules();
    List<Field> fields = basketBookingTemplateConfig.getFieldsByTemplateFormat(TemplateFormat.COMPASSX);

    //Assert
    Template expectedTemplate = expectedResult.get(TemplateFormat.COMPASSX);
    Template actualTemplate = validationRules.get(TemplateFormat.COMPASSX);

    verifyFields(Arrays.asList(expectedTemplate.getFields()), Arrays.asList(actualTemplate.getFields()));

    assertThat(actualTemplate.getTemplateName()).isEqualTo(expectedTemplate.getTemplateName());
    assertThat(actualTemplate.getFileFormat()).isEqualTo(expectedTemplate.getFileFormat());
    assertThat(actualTemplate.getFileSize()).isEqualTo(expectedTemplate.getFileSize());
    assertThat(actualTemplate.getHeaderNames()).isEqualTo(expectedTemplate.getHeaderNames());
    assertThat(actualTemplate.getFinancialInstrumentClassificationCode()).isEqualTo(
            expectedTemplate.getFinancialInstrumentClassificationCode());
    assertThat(actualTemplate.getMaxRows()).isEqualTo(expectedTemplate.getMaxRows());

    assertThat(fields).isNotEmpty();
    assertThat(fields.size()).isEqualTo(expectedTemplate.getFields().length);
    verifyFields(Arrays.asList(expectedTemplate.getFields()), fields);
  }

  private void verifyFields(List<Field> expectedFields, List<Field> actualFields) {
    assertThat(expectedFields.size()).isEqualTo(actualFields.size());
    actualFields.stream().forEach(
            field -> {
              for (Field expectField : expectedFields) {
                if (expectField.getFieldName().equalsIgnoreCase(field.getFieldName())) {
                  assertThat(field).usingRecursiveComparison().isEqualTo(expectField);
                }
              }
            }
    );
  }
}