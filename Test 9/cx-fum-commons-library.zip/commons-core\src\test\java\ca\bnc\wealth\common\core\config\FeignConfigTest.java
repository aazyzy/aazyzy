package ca.bnc.wealth.common.core.config;

import feign.Request;
import feign.RequestTemplate;
import feign.Response;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.cfg.DateTimeFeature;
import tools.jackson.databind.json.JsonMapper;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class FeignConfigTest {

    record Body(String name, LocalDate date) {}

    private static final Body BODY = new Body("a", LocalDate.of(2026, 10, 7));

    @Test
    void jsonEncoderWritesThroughTheGivenMapper() {
        JsonMapper isoDates = JsonMapper.builderWithJackson2Defaults()
                .disable(DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS)
                .build();

        assertThat(encode(JsonMapper.builderWithJackson2Defaults().build()))
                .isEqualTo("{\"name\":\"a\",\"date\":[2026,10,7]}");
        assertThat(encode(isoDates)).isEqualTo("{\"name\":\"a\",\"date\":\"2026-10-07\"}");
    }

    @Test
    void decoderReadsTheResponseBody() throws Exception {
        Object decoded = new FeignConfig().getDecoder()
                .decode(response("{\"name\":\"a\",\"date\":\"2026-10-07\"}"), Body.class);

        assertThat(decoded).isEqualTo(BODY);
    }

    @Test
    void decoderRejectsUnknownPropertiesAsJackson2Did() {
        assertThatThrownBy(() -> new FeignConfig().getDecoder()
                .decode(response("{\"name\":\"a\",\"other\":1}"), Body.class))
                .isInstanceOf(JacksonException.class);
    }

    private static String encode(JsonMapper mapper) {
        RequestTemplate template = new RequestTemplate();
        template.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        FeignConfig.jsonEncoder(mapper).encode(BODY, Body.class, template);
        return new String(template.body(), StandardCharsets.UTF_8);
    }

    private static Response response(String json) {
        Request request = Request.create(
                Request.HttpMethod.GET, "http://localhost", Map.of(), null, StandardCharsets.UTF_8, null);
        return Response.builder()
                .status(200)
                .request(request)
                .headers(Map.of())
                .body(json, StandardCharsets.UTF_8)
                .build();
    }
}
