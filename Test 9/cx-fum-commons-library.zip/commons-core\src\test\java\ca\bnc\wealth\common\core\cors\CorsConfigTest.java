package ca.bnc.wealth.common.core.cors;
import org.junit.jupiter.api.Test;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;


import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
public class CorsConfigTest {
    private final CorsConfig corsConfig = new CorsConfig(new String[]{"localhost:3000"});


    /*
    * Trying to test this by setting up MockMvc, creating a fake controller, and sending a request to it is problematic.
    * This libary isn't designed to be a springboot application, so the amount of imports and changes needed to make it work
    * is overkill
    * */
    @Test
    void testCorsConfigurationViaReflection() {
        CorsRegistry registry = new CorsRegistry();
        corsConfig.addCorsMappings(registry);
        Map<String, CorsConfiguration> corsConfigurations = getCorsConfigurations(registry);
        assertThat(corsConfigurations).isNotNull();
        var corsConfiguration = corsConfigurations.get("/**");
        assertThat(corsConfiguration).isNotNull();
        assertThat(corsConfiguration.getAllowedOrigins()).isNotNull();
        assertThat(corsConfiguration.getAllowedOrigins().get(0)).isEqualTo("localhost:3000");
        assertThat(corsConfiguration.getAllowedHeaders()).isNotNull();
        assertThat(corsConfiguration.getAllowedHeaders().get(0)).isEqualTo("*");
        var allowedMethods = corsConfiguration.getAllowedMethods();
        assertThat(allowedMethods).hasSize(9);
        assertThat(corsConfiguration.getAllowCredentials()).isTrue();
    }

    // Helper method to access protected getCorsConfigurations()
    private static Map<String, CorsConfiguration> getCorsConfigurations(CorsRegistry corsRegistry) {
        try {
            Method getCorsConfigurationsMethod = CorsRegistry.class.getDeclaredMethod("getCorsConfigurations");
            getCorsConfigurationsMethod.setAccessible(true);
            return (Map<String, CorsConfiguration>) getCorsConfigurationsMethod.invoke(corsRegistry);
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyMap();
        }
    }
}
