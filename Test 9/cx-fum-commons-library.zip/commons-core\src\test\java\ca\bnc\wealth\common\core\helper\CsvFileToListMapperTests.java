package ca.bnc.wealth.common.core.helper;

import static ca.bnc.wealth.common.core.constants.CSVConstants.CSV_ROW_NUMBER;
import static ca.bnc.wealth.common.core.constants.ErrorMessages.ERROR_MESSAGE_INCORRECT_TEMPLATE_COLUMNS_MISSING;
import static ca.bnc.wealth.common.core.constants.ErrorMessages.ERROR_MESSAGE_TEMPLATE_NOT_FOUND;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.core.config.BasketBookingTemplateConfig;
import ca.bnc.wealth.common.core.enums.TemplateFormat;
import ca.bnc.wealth.common.core.model.Field;
import ca.bnc.wealth.common.core.model.Template;

import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

/**
 * Unit tests for {@link CsvFileToListMapper}
 */
@RunWith(MockitoJUnitRunner.class)
public class CsvFileToListMapperTests {
    private CsvFileToListMapper csvFileToListMapper;

    @Mock
    private BasketBookingTemplateConfig basketBookingTemplateConfig;

    @Before
    public void setUp() {
        csvFileToListMapper = new CsvFileToListMapper(basketBookingTemplateConfig);
    }

    @Test
    public void givenAValidCSVFile_WhenConvertToMap_ThenTheRightMapShouldBeReturned() throws Exception {
        // setup
        Path validCsvFile = Paths.get("src/test/resources/mutual_fund_bulk_order.csv");
        String contentType = "text/plain";
        byte[] content = Files.readAllBytes(validCsvFile);
        MultipartFile result = new MockMultipartFile("mutual_fund_bulk_order.csv",
                "mutual_fund_bulk_order.csv", contentType, content);
        Map<TemplateFormat, Template> templateFormatValidationRulesMap = new HashMap<>();
        templateFormatValidationRulesMap.put(TemplateFormat.COMPASSX, buildTemplate());
        when(basketBookingTemplateConfig.getValidationRules()).thenReturn(templateFormatValidationRulesMap);

        // execute
        List<Map<String, String>> results = csvFileToListMapper.convertCsvFileToMap(result, TemplateFormat.COMPASSX);

        // verify
        assertNotNull(results);
        assertEquals(3, results.size());
        results.forEach(rowMap -> assertNotNull(rowMap.get(CSV_ROW_NUMBER)));

        // Make sure values are correct
        assertEquals("4", results.get(0).get(CSV_ROW_NUMBER));
        assertEquals("6", results.get(1).get(CSV_ROW_NUMBER));
        assertEquals("8", results.get(2).get(CSV_ROW_NUMBER));
    }

    @Test
    public void givenAnInvalidCSVFile_WhenConvertToMap_ThenTheRightMapShouldStillBeReturned() throws Exception {
        // setup
        Path validCsvFile = Paths.get("src/test/resources/mutual_fund_bulk_order_invalid.csv");
        String contentType = "text/plain";
        byte[] content = Files.readAllBytes(validCsvFile);
        MultipartFile result = new MockMultipartFile("mutual_fund_bulk_order_invalid.csv",
                "mutual_fund_bulk_order_invalid.csv", contentType, content);
        Map<TemplateFormat, Template> templateFormatValidationRulesMap = new HashMap<>();
        templateFormatValidationRulesMap.put(TemplateFormat.COMPASSX, buildTemplate());
        when(basketBookingTemplateConfig.getValidationRules()).thenReturn(templateFormatValidationRulesMap);

        // execute
        List<Map<String, String>> results = csvFileToListMapper.convertCsvFileToMap(result, TemplateFormat.COMPASSX);

        // verify
        assertNotNull(results);
        assertEquals(9, results.size());
        results.forEach(rowMap -> assertNotNull(rowMap.get("Account No*")));
    }

    @Test
    public void givenAnEmptyCSVFile_WhenConvertToMap_ThenTheErrorMessageShouldBeReturned() throws Exception {
        // setup
        Path validCsvFile = Paths.get("src/test/resources/empty_file.csv");
        String contentType = "text/plain";
        MultipartFile result = new MockMultipartFile("empty_file.csv",
                "empty_file.csv", contentType, new FileInputStream(validCsvFile.toFile()));
        Map<TemplateFormat, Template> templateFormatValidationRulesMap = new HashMap<>();
        templateFormatValidationRulesMap.put(TemplateFormat.COMPASSX, buildTemplate());
        when(basketBookingTemplateConfig.getValidationRules()).thenReturn(templateFormatValidationRulesMap);

        // execute
        assertThatThrownBy(() -> csvFileToListMapper.convertCsvFileToMap(result, TemplateFormat.COMPASSX))
                .isInstanceOf(Exception.class).hasMessage(ERROR_MESSAGE_INCORRECT_TEMPLATE_COLUMNS_MISSING);
    }

    @Test
    public void givenAnCSVFileWithMandatoryFieldMissing_WhenConvertToMap_ThenTheErrorMessageShouldBeReturned() throws Exception {
        // setup
        Path validCsvFile = Paths.get("src/test/resources/order_file_with_missing_mandatory_field.csv");
        String contentType = "text/plain";
        MultipartFile result = new MockMultipartFile("order_file_with_missing_mandatory_field.csv",
                "order_file_with_missing_mandatory_field.csv", contentType, new FileInputStream(validCsvFile.toFile()));
        Map<TemplateFormat, Template> templateFormatValidationRulesMap = new HashMap<>();
        Template testTemplate = buildTemplate();
        Arrays.stream(testTemplate.getFields())
                .filter(field -> field.getHeaderName().equals("Account No*")).findFirst().get().setMandatory(true);
        templateFormatValidationRulesMap.put(TemplateFormat.COMPASSX, testTemplate);
        when(basketBookingTemplateConfig.getValidationRules()).thenReturn(templateFormatValidationRulesMap);

        // execute
        assertThatThrownBy(() -> csvFileToListMapper.convertCsvFileToMap(result, TemplateFormat.COMPASSX))
                .isInstanceOf(Exception.class).hasMessage(ERROR_MESSAGE_INCORRECT_TEMPLATE_COLUMNS_MISSING);
    }

    @Test
    public void givenANonExistingTemplate_WhenConvertToMap_ThenTheRightExceptionShouldReturn() {
        // setup
        Map<TemplateFormat, Template> templateFormatValidationRulesMap = new HashMap<>();
        templateFormatValidationRulesMap.put(TemplateFormat.COMPASSX, null);
        when(basketBookingTemplateConfig.getValidationRules()).thenReturn(templateFormatValidationRulesMap);

        // execute
        assertThatThrownBy(() -> csvFileToListMapper.convertCsvFileToMap(null, TemplateFormat.COMPASSX))
                .isInstanceOf(Exception.class).hasMessage(String.format(ERROR_MESSAGE_TEMPLATE_NOT_FOUND, TemplateFormat.COMPASSX));
    }

    private Template buildTemplate() {
        Template template = new Template();
        String[] headers = new String[]{"Account No*", "Trade type*", "Symbol", "From Symbol", "Amount Type*", "Amount*", "Solicitation", "Dividend Options", "Front Load %", "Additional Commission", "Net after commissions", "Advisor Code"};
        template.setFields(
                Arrays.stream(headers)
                        .map(header -> Field.builder().schemaField("Test").fieldName(header + "_fieldName").headerName(header).build())
                        .collect(Collectors.toList()).toArray(new Field[headers.length]));
        return template;
    }

}
