package ca.bnc.wealth.common.core.helper;

import lombok.RequiredArgsConstructor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

@RequiredArgsConstructor
class SubstitutionBase36EncoderHelperTest {

    SubstitutionBase36EncoderHelper encoderHelper;

    @BeforeEach
    public void before() {
        encoderHelper = new SubstitutionBase36EncoderHelper();
    }

    @Test
    public void testCipherCreation() {
        String cipherText = encoderHelper.createCipherText("AA567Z");

        assertTrue(cipherText.compareTo("00VWXP") == 0);
    }

    @Test
    public void testBase36Encoding() {

        assertTrue(encoderHelper.base36EncodedCipher(encoderHelper.createCipherText("AAAAAA")) <
                encoderHelper.base36EncodedCipher(encoderHelper.createCipherText("AAAAAB")));

        assertTrue(encoderHelper.base36EncodedCipher(encoderHelper.createCipherText("AAAAAZ")) <
                encoderHelper.base36EncodedCipher(encoderHelper.createCipherText("AAAAA0")));

        assertTrue(encoderHelper.base36EncodedCipher(encoderHelper.createCipherText("AAAAAZ")) <
                encoderHelper.base36EncodedCipher(encoderHelper.createCipherText("AAAAA0")));

        assertEquals(631152L, encoderHelper.base36EncodedCipher(encoderHelper.createCipherText("NTAA")));
    }
}