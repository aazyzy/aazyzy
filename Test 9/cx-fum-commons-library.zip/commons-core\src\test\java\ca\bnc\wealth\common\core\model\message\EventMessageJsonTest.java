package ca.bnc.wealth.common.core.model.message;

import ca.bnc.wealth.common.core.utils.JsonUtil;
import org.junit.jupiter.api.Test;
import tools.jackson.databind.json.JsonMapper;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * The JSON {@link JsonUtil} writes for an event message. The expected strings are what the Spring Boot 3
 * line (Jackson 2) writes.
 */
class EventMessageJsonTest {

    private static final LocalDateTime PUBLISHED = LocalDateTime.of(2021, 3, 22, 16, 5, 3, 123_000_000);

    private static final String JSON = "{"
            + "\"header\":{\"id\":\"h-1\",\"refId\":\"r-1\",\"action\":\"Booking\",\"state\":\"Pending\","
            + "\"reason\":\"why\",\"version\":\"1.0\","
            + "\"tags\":{\"originatingBookingSystem\":\"cx-trading\",\"cdb-id\":\"123456789\"}},"
            + "\"source\":{\"origin\":{\"system\":\"primeOE\",\"nbcId\":\"0605\",\"time\":\"2021-03-22T16:05:02\"},"
            + "\"publisher\":{\"system\":\"pub\",\"nbcId\":\"6588\",\"time\":\"2021-03-22T16:05:03.123\"}},"
            + "\"payload\":{\"type\":\"/wm/orders/mutual-fund\",\"id\":\"MF-123\",\"rrCode\":\"AB1\"},"
            + "\"signature\":{\"value\":\"sig\",\"kid\":\"key-1\"}}";

    @Test
    void writesTheSameJsonAsTheSpringBoot3Line() {
        EventMessage message = message(EventMessageSignature.builder().kId("key-1").value("sig").build());

        assertThat(JsonUtil.getJsonStr(message)).contains(JSON);
    }

    @Test
    void readsBackAMessageWithoutSignature() {
        String json = JsonUtil.getJsonStr(message(null)).orElseThrow();

        EventMessage read = JsonUtil.parseJson(json, EventMessage.class).orElseThrow();

        assertThat(read.getSource().getPublisher().getTime()).isEqualTo(PUBLISHED);
        assertThat(JsonUtil.getJsonStr(read)).contains(json);
    }

    @Test
    void readsTimesWithAnOffsetAsLocalTimes() {
        String json = "{\"system\":\"s\",\"time\":\"2021-03-22T16:05:02+01:00\"}";

        assertThat(JsonUtil.parseJson(json, EventMessageSourceSystem.class))
                .map(EventMessageSourceSystem::getTime)
                .contains(LocalDateTime.of(2021, 3, 22, 16, 5, 2));
    }

    @Test
    void keepsNullTagsForAMapperThatWritesNulls() {
        String json = JsonMapper.builderWithJackson2Defaults().build().writeValueAsString(message(null).getHeader());

        assertThat(json).contains("\"nullTag\":null");
    }

    private static EventMessage message(EventMessageSignature signature) {
        Map<String, String> tags = new LinkedHashMap<>();
        tags.put("originatingBookingSystem", "cx-trading");
        tags.put("cdb-id", "123456789");
        tags.put("nullTag", null);
        return EventMessage.builder()
                .header(EventMessageHeader.builder().id("h-1").refId("r-1").action("Booking").state("Pending")
                        .reason("why").version("1.0").tags(tags).build())
                .source(EventMessageSource.builder()
                        .origin(EventMessageSourceSystem.builder().system("primeOE").nbcId("0605")
                                .time(LocalDateTime.of(2021, 3, 22, 16, 5, 2)).build())
                        .publisher(EventMessageSourceSystem.builder().system("pub").nbcId("6588")
                                .time(PUBLISHED).build())
                        .build())
                .payload(EventMessagePayload.builder().type("/wm/orders/mutual-fund").id("MF-123").rrCode("AB1")
                        .build())
                .signature(signature)
                .build();
    }
}
