package ca.bnc.wealth.common.core.model.message;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.AbstractMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class EventMessageTest {
    private static final String SOME_HEADER_ID = "123e4567-e89b-12d3-a456-426614174000";
    private static final String SOME_HEADER_REF_ID = "MF-123";
    private static final String SOME_HEADER_STATE = "Pending";
    private static final String SOME_HEADER_ACTION = "Booking";
    private static final String SOME_HEADER_REASON = "Booking transmitted to PrimeOE";
    private static final String SOME_HEADER_VERSION = "1.0";
    private static final Map<String, String> SOME_HEADER_TAGS = Map.ofEntries(
            new AbstractMap.SimpleEntry<>("originatingBookingSystem", "cx-trading"),
            new AbstractMap.SimpleEntry<>("cdb-id", "123456789"),
            new AbstractMap.SimpleEntry<>("primeoe-id", "123123"));
    private static final String SOME_ORIGIN_SOURCE_SYSTEM = "primeOE";
    private static final String SOME_ORIGIN_SOURCE_NBC_ID = "0605";
    private static final LocalDateTime SOME_ORIGIN_SOURCE_TIME = LocalDateTime.of(2021, 3, 22, 16, 5, 2);
    private static final String SOME_PUBLISHER_SOURCE_SYSTEM = "nbin.cx-trading.mutual-fund-order-api";
    private static final String SOME_PUBLISHER_SOURCE_NBC_ID = "6588";
    private static final LocalDateTime SOME_PUBLISHER_SOURCE_TIME = LocalDateTime.of(2021, 3, 22, 16, 5, 3);
    private static final String SOME_PAYLOAD_TYPE = "/wm/orders/mutual-fund";
    private static final String SOME_PAYLOAD_ID = "MF-123";

    @Test
    void testEventMessageBuilder() {
        EventMessage actual = EventMessage.builder()
                .header(EventMessageHeader.builder()
                        .id(SOME_HEADER_ID)
                        .refId(SOME_HEADER_REF_ID)
                        .state(SOME_HEADER_STATE)
                        .action(SOME_HEADER_ACTION)
                        .reason(SOME_HEADER_REASON)
                        .version(SOME_HEADER_VERSION)
                        .tags(SOME_HEADER_TAGS)
                        .build())
                .source(EventMessageSource.builder()
                        .origin(new EventMessageSourceSystem(SOME_ORIGIN_SOURCE_SYSTEM, SOME_ORIGIN_SOURCE_NBC_ID, SOME_ORIGIN_SOURCE_TIME))
                        .publisher(new EventMessageSourceSystem(SOME_PUBLISHER_SOURCE_SYSTEM, SOME_PUBLISHER_SOURCE_NBC_ID, SOME_PUBLISHER_SOURCE_TIME))
                        .build())
                .payload(EventMessagePayload.builder()
                        .type(SOME_PAYLOAD_TYPE)
                        .id(SOME_PAYLOAD_ID)
                        .build())
                .build();

        assertThat(actual.getHeader().getId()).isEqualTo(SOME_HEADER_ID);
        assertThat(actual.getHeader().getRefId()).isEqualTo(SOME_HEADER_REF_ID);
        assertThat(actual.getHeader().getState()).isEqualTo(SOME_HEADER_STATE);
        assertThat(actual.getHeader().getAction()).isEqualTo(SOME_HEADER_ACTION);
        assertThat(actual.getHeader().getReason()).isEqualTo(SOME_HEADER_REASON);
        assertThat(actual.getHeader().getVersion()).isEqualTo(SOME_HEADER_VERSION);
        assertThat(actual.getHeader().getTags()).containsExactlyInAnyOrderEntriesOf(SOME_HEADER_TAGS);

        assertThat(actual.getSource().getOrigin().getSystem()).isEqualTo(SOME_ORIGIN_SOURCE_SYSTEM);
        assertThat(actual.getSource().getOrigin().getNbcId()).isEqualTo(SOME_ORIGIN_SOURCE_NBC_ID);
        assertThat(actual.getSource().getOrigin().getTime()).isEqualTo(SOME_ORIGIN_SOURCE_TIME);
        assertThat(actual.getSource().getPublisher().getSystem()).isEqualTo(SOME_PUBLISHER_SOURCE_SYSTEM);
        assertThat(actual.getSource().getPublisher().getNbcId()).isEqualTo(SOME_PUBLISHER_SOURCE_NBC_ID);
        assertThat(actual.getSource().getPublisher().getTime()).isEqualTo(SOME_PUBLISHER_SOURCE_TIME);

        assertThat(actual.getPayload().getType()).isEqualTo(SOME_PAYLOAD_TYPE);
        assertThat(actual.getPayload().getId()).isEqualTo(SOME_PAYLOAD_ID);
    }
}