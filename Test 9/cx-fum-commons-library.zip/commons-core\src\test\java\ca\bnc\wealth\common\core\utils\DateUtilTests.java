package ca.bnc.wealth.common.core.utils;

import static org.assertj.core.api.Assertions.assertThat;

import ca.bnc.wealth.common.core.constants.DateTimeConstants;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Date;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class DateUtilTests {

    @Test
    public void testStringToLocalDate() {
        String inputDateStr = "2021/04/15";
        String pattern = DateTimeConstants.DATE_PATTERN_SLASHES;

        LocalDate actual = DateUtil.stringToLocalDate(inputDateStr, pattern);

        assertThat(actual).isEqualTo("2021-04-15");
    }

    @Test
    public void testStringToLocalDateTime() {
        String inputDateStr = "Apr 15 2021 09:30:01:888";
        String pattern = DateTimeConstants.DATETIME_PATTERN_SPACES;

        LocalDateTime actual = DateUtil.stringToLocalDateTime(inputDateStr, pattern);

        assertThat(actual).isEqualTo("2021-04-15T09:30:01.888");
    }

    @Test
    public void testStringToDate() {
        String inputDateStr = "April 15 2021 09:30:01:888";
        String pattern = DateTimeConstants.DATETIME_PATTERN_SPACES;

        Date actual = DateUtil.stringToDate(inputDateStr, pattern);

        assertThat(actual).isEqualTo("2021-04-15T09:30:01.888");
    }

    @Test
    public void testDateToLocalDate() throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(DateTimeConstants.DATE_PATTERN_SLASHES);
        Date inputDate = sdf.parse("2021/04/15");

        LocalDate actual = DateUtil.dateToLocalDate(inputDate);

        assertThat(actual).isEqualTo("2021-04-15");
    }

    @Test
    public void testDateToLocalDateTime() throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(DateTimeConstants.DATETIME_PATTERN_SPACES);
        Date inputDate = sdf.parse("April 15 2021 09:30:01:888");

        LocalDateTime actual = DateUtil.dateToLocalDateTime(inputDate);

        assertThat(actual).isEqualTo("2021-04-15T09:30:01.888");
    }

    @Test
    public void testLocalDateToDate() {
        LocalDate inputDate = LocalDate.of(2015, 4, 15);

        Date actual = DateUtil.localDateToDate(inputDate);

        assertThat(actual).isEqualTo("2015-04-15");
    }

    @Test
    public void testLocalDateTimeToDate() {
        LocalDateTime inputDate = LocalDateTime.of(2021, 04, 15, 9, 30, 1);

        Date actual = DateUtil.localDateTimeToDate(inputDate);

        assertThat(actual).isEqualTo("2021-04-15T09:30:01.000");
    }

    @Test
    public void testGetMaxDate() {
        LocalDateTime inputDate1 = LocalDateTime.of(2021, 04, 15, 9, 30, 1, 888);
        LocalDateTime inputDate2 = LocalDateTime.of(2021, 04, 16, 10, 30, 1, 888);
        LocalDateTime inputDate3 = LocalDateTime.of(2021, 04, 16, 9, 30, 1, 888);

        LocalDateTime actual = DateUtil.getMaxDate(Arrays.asList(inputDate1, inputDate2, inputDate3));

        assertThat(actual).isEqualTo(inputDate2);
    }
}
