package ca.bnc.wealth.common.core.utils;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class ExecutionRouteManagerTest {


    @Test
    void testGetRoute_GivenTwoModes(){

        final Map<String, Integer> weightedModes = new HashMap<>();
        weightedModes.put("user", 1);
        weightedModes.put("batch", 1);
        final ExecutionRouteManager executionRouteManager = ExecutionRouteManager.newInstance(12, weightedModes);

        assertEquals(executionRouteManager.getRoute("user", "CMF10000001"),
                executionRouteManager.getRoute("user", "CMF10000001"));
        assertNotEquals(executionRouteManager.getRoute("user", "CMF10000001"),
                executionRouteManager.getRoute("batch", "CMF10000001"));

    }

    @Test
    void testException_GivenInvalidRoutesAndWeights(){
        final Map<String, Integer> weightedModes = new HashMap<>();
        weightedModes.put("user", 1);
        assertThrows(IllegalArgumentException.class, () -> ExecutionRouteManager.newInstance(12, weightedModes));
        weightedModes.put("batch", 1);
        assertThrows(IllegalArgumentException.class, () -> ExecutionRouteManager.newInstance(1, weightedModes));
    }
}