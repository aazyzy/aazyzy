package ca.bnc.wealth.common.core.utils;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class JsonUtilTests {

    @Getter
    @Setter
    @NoArgsConstructor
    public static class SomeObj {
        private String field1 = "abc";
        private String field2 = "def";
    }

    @Test
    public void testGetJsonStr() {
        SomeObj inputObj = new SomeObj();
        String actual = JsonUtil.getJsonStr(inputObj).orElse(null);
        assertThat(actual)
                .isNotNull()
                .isEqualTo("{\"field1\":\"abc\",\"field2\":\"def\"}");
    }

    @Test
    public void testParseJson() {
        String inputJsonStr = "{" +
                "  \"field1\": \"abc\"," +
                "  \"field2\": \"def\"" +
                "}";
        SomeObj actual = JsonUtil.parseJson(inputJsonStr, SomeObj.class).orElse(null);
        assertThat(actual).isNotNull();
        assertThat(actual.getField1()).isEqualTo("abc");
        assertThat(actual.getField2()).isEqualTo("def");
    }
}
