package ca.bnc.wealth.common.core.utils;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;

public class StringTemplateTests {

    @Test
    public void testStringNoArgs() {
        String text = "This is a no arg template test..";
        StringTemplate template = StringTemplate.newInstance(text);
        assertThat(template.getString("none")).isEqualTo(text);
    }

    @Test
    public void testStringSingleArg() {
        String text = "This is a {{}} arg template test..";
        StringTemplate template = StringTemplate.newInstance(text);
        assertThat(template.getString("one")).isEqualTo("This is a one arg template test..");
    }

    @Test
    public void testStringMultipleArgs() {
        String text = "Counting :: {{}}, {{}}, {{}}, {{}} and so on ...";
        StringTemplate template = StringTemplate.newInstance(text);
        assertThat(template.getString("one", "two", "three", "four")).isEqualTo("Counting :: one, two, three, four and so on ...");
    }

    @Test
    public void testStringExtraArgs() {
        String text = "Counting :: {{}}, {{}}, {{}}, {{}} and so on ...";
        StringTemplate template = StringTemplate.newInstance(text);
        assertThatIllegalArgumentException().isThrownBy(() -> template.getString("one", "two", "three", "four", "x", "y"));
    }

    @Test
    public void testStringLessArgs() {
        String text = "Counting :: {{}}, {{}}, {{}}, {{}} and so on ...";
        StringTemplate template = StringTemplate.newInstance(text);
        assertThatIllegalArgumentException().isThrownBy(() -> template.getString("one", "two"));
    }

}
