package ca.bnc.wealth.common.core.yaml;

import org.junit.Before;
import org.junit.Test;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.EncodedResource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

public class YamlPropertySourceFactoryTests {
    private static final String PROPERTY_SOURCE_NAME = "test";

    private YamlPropertySourceFactory factory;
    private PropertySource<?> propertiesPropertySource;

    @Before
    public void setup() {
        factory = new YamlPropertySourceFactory();
        propertiesPropertySource = null;
    }

    @Test
    public void testCreatePropertySource() {
        EncodedResource res = new EncodedResource(new ClassPathResource("test.yaml"), "UTF-8");
        propertiesPropertySource = factory.createPropertySource(PROPERTY_SOURCE_NAME, res);
        assertThat(propertiesPropertySource).isNotNull();
    }

    @Test
    public void testCreatePropertySource_UnhappyPathNullName() {
        EncodedResource res = new EncodedResource(new ClassPathResource("test.yaml"), "UTF-8");
        propertiesPropertySource = factory.createPropertySource(null, res);
        assertThat(propertiesPropertySource).isNotNull();
    }

    @Test
    public void testCreatePropertySource_UnhappyPathFileNotFound() {
        EncodedResource res = new EncodedResource(new ClassPathResource("test1.yaml"), "UTF-8");
        assertThatThrownBy(() -> factory.createPropertySource(PROPERTY_SOURCE_NAME, res))
                .isInstanceOf(IllegalStateException.class);
    }
}
