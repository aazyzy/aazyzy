package ca.bnc.wealth.common.id.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * This DAO is used to generate a unique identifier from the configured Postgres Database. Requires
 * an instance of {@link org.springframework.jdbc.core.JdbcTemplate} with a name qualifier of
 * 'postgresJdbcTemplate' in the {@link org.springframework.context.ApplicationContext} configured.
 */
@Repository
public class IdGeneratorDao {

    private static final String ID_SEQUENCE_SQL = "SELECT nextval(:sequenceName);";

    private static final String ID_SEQUENCE_BATCH_GENERATER_SQL = "SELECT nextval(:sequenceName) from generate_series(0, :size) ;";

    private final NamedParameterJdbcTemplate jdbcTemplate;

    /**
     * Constructor.
     *
     * @param jdbcTemplate A bean that is an instance of {@link JdbcTemplate} with Qualifier
     *     'postgresJdbcTemplate'
     */
    @Autowired
    public IdGeneratorDao(@Qualifier("postgresJdbcTemplate") NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Returns the next unique identifier from the configured Postgres Database.
     *
     * @param sequenceName Name of the sequence from which next identifier must be generated.
     * @return a long identifier.
     */
    public Long getNextId(String sequenceName) {
        SqlParameterSource namedParameters = new MapSqlParameterSource().addValue("sequenceName", sequenceName);
        return jdbcTemplate.queryForObject(ID_SEQUENCE_SQL, namedParameters, Long.class);
    }

    /**
     * Returns a bunch of next unique identifiers from the configured Postgres Database and the specified sequence.
     *
     * @param sequenceName Name of the sequence from which next identifier must be generated.
     * @param size number of identifiers needed.
     * @return
     */
    public List<Long> generateBatchIds(String sequenceName, int size) {
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("sequenceName", sequenceName)
                .addValue("size", size - 1);
        List<Map<String, Object>> listOfMap = jdbcTemplate.queryForList(ID_SEQUENCE_BATCH_GENERATER_SQL, namedParameters);
        return listOfMap.stream()
                .map(singleMap -> Long.valueOf(singleMap.values().stream().findFirst().get().toString()))
                .collect(Collectors.toList());
    }
}
