package ca.bnc.wealth.common.id.service;

import ca.bnc.wealth.common.id.dao.IdGeneratorDao;
import org.springframework.lang.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * This service class enables generation of a unique identifier from the configured Postgres
 * Database. Requires an instance of {@link org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate} with a name
 * qualifier of 'postgresJdbcTemplate' in the {@link org.springframework.context.ApplicationContext}
 * configured.
 */
@Slf4j
@Service
public class IdGeneratorService {

    private final IdGeneratorDao idGeneratorDao;

    /**
     * Constructor.
     *
     * @param idGeneratorDao {@link IdGeneratorDao}
     */
    @Autowired
    public IdGeneratorService(IdGeneratorDao idGeneratorDao) {
        this.idGeneratorDao = idGeneratorDao;
    }

    /**
     * This method is used to generate the next order id
     *
     * @param sequenceName Name of the sequence from which next identifier must be generated.
     * @param prefix Prefix to be added to the id, if not null.
     * @param suffix Suffix to be added to the id, if not null.
     * @return Next order id in the DB sequence
     */
    public String generateID(@NonNull String sequenceName, @Nullable String prefix, @Nullable String suffix) {
        Long id = idGeneratorDao.getNextId(sequenceName);
        if (id == null) {
            log.warn("ID generation from sequence failed.");
            return null;
        }
        return formatId(prefix, suffix, "%010d", id);
    }

    /**
     * This method is used to generate the next order id
     *
     * @param sequenceName Name of the sequence from which next identifier must be generated.
     * @param prefix Prefix to be added to the id, if not null.
     * @param suffix Suffix to be added to the id, if not null.
     * @param numericLength Length of the numeric part of the id.
     * @return Next order id in the DB sequence
     */
    public String generateID(@NonNull String sequenceName, @Nullable String prefix, @Nullable String suffix, @NonNull Integer numericLength) {
        String format = "%0" + numericLength + "d";
        Long id = idGeneratorDao.getNextId(sequenceName);
        if (id == null) {
            log.warn("ID generation from sequence failed.");
            return null;
        }
        return formatId(prefix, suffix, format, id);
    }

    /**
     * This is a performance optimized way of getting multiple unique ids from a DB sequence.
     *
     * @param sequenceName Name of the sequence from which next identifier must be generated.
     * @param size Batch size of the ids.
     * @param prefix Prefix to be added to the id, if not null.
     * @param suffix Suffix to be added to the id, if not null.
     * @return Next order id in the DB sequence
     * @return List of unique ids created.
     */
    public List<String> generateIDsForTheBatch(@NonNull String sequenceName, @Nullable int size, @Nullable String prefix, @Nullable String suffix) {
        List<Long> ids = idGeneratorDao.generateBatchIds(sequenceName, size);
        if (ids.isEmpty()) {
            log.warn("ID generation in a batch from sequence failed.");
            return null;
        }
        return ids.stream().map(id -> formatId(prefix, suffix, "%010d", id)).collect(Collectors.toList());
    }

    /**
     * @param prefix Prefix to the format.
     * @param format The format in which the identifier is desired.
     * @param id     The {@link Long} identifier to be formatted.
     * @return {@link String} formatted identifier string.
     * @Todo Move this to commons-lib
     */
    private String formatId(@Nullable String prefix, @Nullable String suffix, @NonNull String format, @NonNull Long id) {
        format = StringUtils.isBlank(prefix) ? format : prefix + format;
        format = StringUtils.isBlank(suffix) ? format : format + suffix;
        return String.format(format, id);
    }
}
