package ca.bnc.wealth.common.id;

import org.springframework.boot.SpringApplication;

public class TestConfiguration {
    public static void main(String[] args) {
        SpringApplication.run(TestConfiguration.class, args);
    }
}
