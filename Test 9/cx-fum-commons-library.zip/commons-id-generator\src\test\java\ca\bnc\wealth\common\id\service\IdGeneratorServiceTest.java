package ca.bnc.wealth.common.id.service;

import ca.bnc.wealth.common.id.CommonsIdGeneratorTestConfiguration;
import ca.bnc.wealth.common.id.dao.IdGeneratorDao;
import lombok.extern.slf4j.Slf4j;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@Slf4j
@SpringBootTest(classes = {TestConfiguration.class})
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {CommonsIdGeneratorTestConfiguration.class, IdGeneratorDao.class, ca.bnc.wealth.common.id.service.IdGeneratorService.class})
@Ignore
public class IdGeneratorServiceTest {

    @Autowired
    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    private IdGeneratorService idGeneratorService;

    @Before
    public void beforeTest() {
        assertThat(jdbcTemplate).isNotNull();
        jdbcTemplate.execute("CREATE SEQUENCE id_sequence INCREMENT BY 1;", (PreparedStatementCallback<Object>) ps -> ps.execute());
    }

    @Test
    public void shouldReturnNull_WhenDaoReturnsNull(){
        IdGeneratorDao dao = Mockito.mock(IdGeneratorDao.class);
        IdGeneratorService service = new IdGeneratorService(dao);
        when(dao.getNextId(anyString())).thenReturn(null);

        String id = service.generateID("id_sequence", "PFX", "SFX");

        assertThat(id).isNull();
    }

    @Test
    public void shouldReturnNull_WhenDaoReturnsNull_WithNumericLength(){
        int numericLength = 10;
        IdGeneratorDao dao = Mockito.mock(IdGeneratorDao.class);
        IdGeneratorService service = new IdGeneratorService(dao);
        when(dao.getNextId(anyString())).thenReturn(null);

        String id = service.generateID("id_sequence", "PFX", "SFX", numericLength);

        assertThat(id).isNull();
    }

    @Test
    public void shouldReturnNullBatch_WhenDaoReturnsEmptyList(){
        int batchSize = 1000;
        IdGeneratorDao dao = Mockito.mock(IdGeneratorDao.class);
        IdGeneratorService service = new IdGeneratorService(dao);
        when(dao.generateBatchIds(anyString(), anyInt())).thenReturn(Collections.emptyList());

        List<String> ids = service.generateIDsForTheBatch("id_sequence", batchSize, "PFX", "SFX");

        assertThat(ids).isNull();
    }

    @Test
    public void shouldReturnId_WithExpectedPrefix_AndSuffix() {
        assertThat(idGeneratorService).isNotNull();
        String prefix = "PFX";
        String suffix = "SFX";
        String identifier1 = idGeneratorService.generateID("id_sequence", prefix, suffix);
        assertThat(identifier1).isNotNull();
        String identifier2 = idGeneratorService.generateID("id_sequence", prefix, suffix);
        assertThat(identifier2).isNotNull();
        assertThat(identifier1).isNotEqualTo(identifier2);
        assertThat(identifier1.length()).isEqualTo(identifier2.length());
        assertThat(identifier1).startsWith(prefix);
        assertThat(identifier1).endsWith(suffix);
    }

    @Test
    public void shouldReturnId_WithExpectedPrefix_AndSuffix_SpecificNumericLength() {
        assertThat(idGeneratorService).isNotNull();
        String prefix = "PFX";
        String suffix = "SFX";
        int numericLength = 8;
        String identifier1 = idGeneratorService.generateID("id_sequence", prefix, suffix, numericLength);
        assertThat(identifier1)
                .isNotNull()
                .startsWith(prefix)
                .endsWith(suffix)
                .hasSize(prefix.length() + numericLength + suffix.length())
                .matches(prefix + "\\d{" + numericLength + "}" + suffix);
    }


    @Test
    public void shouldReturn_10000_BatchIds_InLessThan5Milliseconds() {
        assertThat(idGeneratorService).isNotNull();
        String prefix = "PFX";
        String suffix = "SFX";
        int sizeOfBatch = 10000;

        long startTimeInMillis = System.currentTimeMillis();
        List<String> ids = idGeneratorService.generateIDsForTheBatch("id_sequence", sizeOfBatch, prefix, suffix);
        long endTimeInMillis = System.currentTimeMillis();
        // verify performance and size.
        assertThat(endTimeInMillis-startTimeInMillis).isLessThan(500);
        assertThat(ids).isNotEmpty().hasSize(sizeOfBatch);

        // Repeat
        startTimeInMillis = System.currentTimeMillis();
        List<String> id2s = idGeneratorService.generateIDsForTheBatch("id_sequence", sizeOfBatch, prefix, suffix);
        endTimeInMillis = System.currentTimeMillis();
        // verify performance and size.
        assertThat(endTimeInMillis-startTimeInMillis).isLessThan(500);
        assertThat(id2s).isNotEmpty().hasSize(sizeOfBatch);

        //Verify that the id generated both times are unique.
        assertThat(ids).doesNotContainAnyElementsOf(id2s);
        assertThat(id2s).doesNotContainAnyElementsOf(ids);

        // Verify prefix and suffices
        ids.stream().forEach(id -> {
            assertThat(id).startsWith(prefix);
            assertThat(id).endsWith(suffix);
        });

    }

    @After
    public void afterTest() {
        jdbcTemplate.execute("DROP SEQUENCE id_sequence", (PreparedStatementCallback<Object>) ps -> ps.execute());
    }
}
