package ca.bnc.wealth.core.jpa.entity;

public interface EntityInterface {

    Long getId();
}
