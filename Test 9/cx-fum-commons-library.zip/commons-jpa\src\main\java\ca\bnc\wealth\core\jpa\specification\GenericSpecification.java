package ca.bnc.wealth.core.jpa.specification;

import ca.bnc.wealth.core.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.core.jpa.utils.EnumSpecificationOperation;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;


public abstract class GenericSpecification<T> implements Specification<T> {

    protected Path<Object> getPath(Root<T> root, String field, JoinType[] joinTypes, Map<String, Join<Object, Object>> joinMap) {
        String[] fields = field.split("\\.");
        if(fields.length > 1) {
            StringBuilder sb = new StringBuilder(fields[0]);

            if(!joinMap.containsKey(fields[0]))
                joinMap.put(fields[0], root.join(fields[0], getJoin(joinTypes, 0)));

            for(int i =1; i< fields.length - 1; i++) {
                String key = sb.toString() + "." + fields[i];
                if(!joinMap.containsKey(key))
                    joinMap.put(key, joinMap.get(sb.toString()).join(fields[i], getJoin(joinTypes, i)));
                sb.append(".").append(fields[i]);
            }
            return joinMap.get(sb.toString()).get(fields[fields.length -1]);
        }
        return root.get(field);
    }

    private JoinType getJoin(JoinType[] joinType, int index) {
        return Optional.ofNullable(joinType)
                .filter(array -> array.length > index)
                .map(array -> array[index])
                .orElse(JoinType.INNER);
    }

    protected Predicate getPredicate(CriteriaBuilder criteriaBuilder, EnumSpecificationOperation specificationOperation, Predicate[] predicates) {
        if( predicates != null && predicates.length == 0)
            return null;
        switch (specificationOperation) {
            case OR:
                return criteriaBuilder.or(predicates);
            case AND:
            default:
                return criteriaBuilder.and(predicates);
        }

    }

    protected Predicate getPredicate(Root<T> root, CriteriaBuilder criteriaBuilder, EnumQueryCriteria criteria, String field, Object fieldVale, JoinType[] joinTypes, Map<String, Join<Object,Object>> joinMap) {
        switch(criteria) {
            case EQUALS:
                return criteriaBuilder.equal(this.getPath(root, field, joinTypes, joinMap), fieldVale);
            case NOT_EQUALS:
                return criteriaBuilder.notEqual(this.getPath(root, field, joinTypes, joinMap), fieldVale);
            case CONTAINS:
                return criteriaBuilder.like(this.getPath(root, field, joinTypes, joinMap).as(String.class), "%" + fieldVale + "%");
            case STARTS_WITH:
                return criteriaBuilder.like(this.getPath(root, field, joinTypes, joinMap).as(String.class), fieldVale + "%");
            case ENDS_WITH:
                return criteriaBuilder.like(this.getPath(root, field, joinTypes, joinMap).as(String.class), "%" + fieldVale);
            case LESS_THAN:
                return criteriaBuilder.lessThan(this.getPath(root, field, joinTypes, joinMap).as(Integer.class), Integer.valueOf(fieldVale.toString()));
            case GREATER_THAN:
                return criteriaBuilder.greaterThan(this.getPath(root, field, joinTypes, joinMap).as(Integer.class), Integer.valueOf(fieldVale.toString()));
            case LESS_THAN_OR_EQUAL:
                return criteriaBuilder.lessThanOrEqualTo(this.getPath(root, field, joinTypes, joinMap).as(Integer.class), Integer.valueOf(fieldVale.toString()));
            case GREATER_THEN_OR_EQUAL:
                return criteriaBuilder.greaterThanOrEqualTo(this.getPath(root, field, joinTypes, joinMap).as(Integer.class), Integer.valueOf(fieldVale.toString()));
            case IN:
                if(fieldVale instanceof List<?>){
                    CriteriaBuilder.In<Object> predicate = criteriaBuilder.in(this.getPath(root, field, joinTypes, joinMap));
                    Optional.ofNullable((Collection<?>)fieldVale).orElse(new ArrayList<>()).forEach(predicate::value);
                    return predicate;
                }
                break;
            case IGNORE_CASE_EQUALS:
                Expression<String> equalExp = criteriaBuilder.upper(this.getPath(root, field, joinTypes, joinMap).as(String.class));
                return criteriaBuilder.equal(equalExp, fieldVale.toString().toUpperCase());
            case IGNORE_CASE_CONTAINS:
                Expression<String> containExp = criteriaBuilder.upper(this.getPath(root, field, joinTypes, joinMap).as(String.class));
                return criteriaBuilder.like(containExp, "%" + fieldVale.toString().toUpperCase() + "%");
            case IGNORE_CASE_ENDS_WITH:
                Expression<String> endwithExp = criteriaBuilder.upper(this.getPath(root, field, joinTypes, joinMap).as(String.class));
                return criteriaBuilder.like(endwithExp, "%"+ fieldVale.toString().toUpperCase());
            case IGNORE_CASE_STARTS_WITH:
                Expression<String> startwithExp = criteriaBuilder.upper(this.getPath(root, field, joinTypes, joinMap).as(String.class));
                return criteriaBuilder.like(startwithExp, fieldVale.toString().toUpperCase() + "%");
            case IS_NOT_NULL:
                return criteriaBuilder.isNotNull(this.getPath(root, field, joinTypes, joinMap));
            case IS_NULL:
                return criteriaBuilder.isNull(this.getPath(root, field, joinTypes, joinMap));
            case DATE_LESS_THAN:
                return criteriaBuilder.lessThan(this.getPath(root, field, joinTypes, joinMap).as(Timestamp.class), (Timestamp)fieldVale);
            case DATE_GREATER_THAN:
                return criteriaBuilder.greaterThan(this.getPath(root, field, joinTypes, joinMap).as(Timestamp.class), (Timestamp)fieldVale);
        }
        return null;
    }
}
