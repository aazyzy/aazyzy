package ca.bnc.wealth.core.jpa.specification;

import ca.bnc.wealth.core.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.core.jpa.utils.EnumSpecificationOperation;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.apache.commons.lang3.tuple.Pair;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Specification<T> extends GenericSpecification<T> {

    private EnumSpecificationOperation operation;
    private Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap;
    private List<Pair<String, Pair<EnumQueryCriteria, Object>>> fieldValue;
    private boolean distinctQuery;

    private Map<String, Join<Object,Object>> joinMap = new HashMap<>();

    public Specification(Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap) {
        this.operation = EnumSpecificationOperation.AND;
        this.fieldValueMap = fieldValueMap;
        this.distinctQuery = true;
    }

    public Specification(EnumSpecificationOperation operation, Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap, boolean distinctQuery) {
        this.operation = operation;
        this.fieldValueMap = fieldValueMap;
        this.distinctQuery = distinctQuery;
    }

    public Specification(List<Pair<String, Pair<EnumQueryCriteria, Object>>> fieldValue) {
        this.operation = EnumSpecificationOperation.AND;
        this.fieldValue = fieldValue;
        this.distinctQuery = true;
    }

    public Specification(EnumSpecificationOperation operation, List<Pair<String, Pair<EnumQueryCriteria, Object>>> fieldValue, boolean distinctQuery) {
        this.operation = operation;
        this.fieldValue = fieldValue;
        this.distinctQuery = distinctQuery;
    }

    @Override
    public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
        this.joinMap = new HashMap<>();
        query.distinct(distinctQuery);
        Predicate[] predicates = null;
        if(fieldValueMap != null && fieldValueMap.size() > 0) {
            predicates = fieldValueMap.entrySet().stream()
                    .map(entity -> getPredicate(root, criteriaBuilder, entity.getValue().getKey(), entity.getKey(), entity.getValue().getValue(), null, joinMap))
                    .toArray(Predicate[]::new);
        } else if(fieldValue != null && fieldValue.size() > 0) {
            predicates = fieldValue.stream()
                    .map(pair -> getPredicate(root, criteriaBuilder, pair.getValue().getKey(), pair.getKey(), pair.getValue().getValue(), null, joinMap))
                    .toArray(Predicate[]::new);
        }

        return getPredicate(criteriaBuilder, operation, predicates);
    }
}
