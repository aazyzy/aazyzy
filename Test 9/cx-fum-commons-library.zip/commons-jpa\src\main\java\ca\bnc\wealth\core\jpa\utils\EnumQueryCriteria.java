package ca.bnc.wealth.core.jpa.utils;

public enum EnumQueryCriteria {
    EQUALS,
    NOT_EQUALS,
    CONTAINS,
    STARTS_WITH,
    ENDS_WITH,
    GREATER_THAN,
    GREATER_THEN_OR_EQUAL,
    LESS_THAN,
    LESS_THAN_OR_EQUAL,
    IN,
    IGNORE_CASE_EQUALS,
    IGNORE_CASE_CONTAINS,
    IGNORE_CASE_STARTS_WITH,
    IGNORE_CASE_ENDS_WITH,
    IS_NOT_NULL,
    IS_NULL,
    DATE_LESS_THAN,
    DATE_GREATER_THAN
}
