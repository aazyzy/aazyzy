package ca.bnc.wealth.core.jpa.utils;

public enum EnumSpecificationOperation {
    AND, OR;
}
