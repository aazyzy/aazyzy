package ca.bnc.wealth.core.jpa.utils;

import jakarta.persistence.criteria.JoinType;

public interface GenericQuery {

    EnumQueryCriteria getCriteria();

    String getEntityField();

    Object getDefaultValue();

    JoinType[] getJoinTypes();
}
