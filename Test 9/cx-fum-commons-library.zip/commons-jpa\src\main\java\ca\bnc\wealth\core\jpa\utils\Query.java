package ca.bnc.wealth.core.jpa.utils;

public interface Query {

}
