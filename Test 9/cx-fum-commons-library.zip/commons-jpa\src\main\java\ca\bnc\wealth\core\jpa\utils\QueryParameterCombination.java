package ca.bnc.wealth.core.jpa.utils;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class QueryParameterCombination implements Query {
    Query subQueryLeft;
    EnumSpecificationOperation operation = EnumSpecificationOperation.AND;
    Query subQueryRight;
}
