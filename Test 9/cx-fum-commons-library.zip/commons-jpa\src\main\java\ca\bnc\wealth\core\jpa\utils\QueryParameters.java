package ca.bnc.wealth.core.jpa.utils;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class QueryParameters implements Query {
    List<String> parameter;
    EnumSpecificationOperation operation = EnumSpecificationOperation.AND;
}
