package ca.bnc.wealth.common.postgres.converters;

import ca.bnc.wealth.common.core.utils.JsonUtil;
import org.postgresql.util.PGobject;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.ObjectMapper;

import java.sql.SQLException;

/**
 * This converts a given Object into Postgres' {@link PGobject}
 * and vice versa.
 */
@Component
public class PostgresPGObjectConverter {

    private final ObjectMapper om;
    private static final String JSONB = "jsonb";

    /**
     * Constructor.
     *
     * @param om {@link ObjectMapper}
     */
    public PostgresPGObjectConverter(ObjectMapper om) {
        this.om = om;
    }

    /**
     * This converts a given object into {@link PGobject}
     *
     * @param object
     * @return {@link PGobject} equivalent.
     */
    public PGobject convertToPGobject(@NonNull Object object) {
        if (object == null) {
            return null;
        }
        String jsonValue = getJson(object);
        if (jsonValue == null) {
            return null;
        }
        PGobject jsonObject = new PGobject();
        jsonObject.setType(JSONB);
        try {
            jsonObject.setValue(jsonValue);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return jsonObject;
    }

    /**
     * Encapsulates the static function call to enable unit testing.
     *
     * @param object Object to be serialized.
     * @return Serialized string equivalent.
     */
    protected String getJson(Object object) {
        return JsonUtil.getJsonStr(object).orElse(null);
    }

    /**
     * Returns the equivalent Object (Of the passed {@link Class} type), of the
     * given {@link PGobject}
     *
     * @param pGobject {@link PGobject}
     * @param classs   {@link Class}
     * @return A deserialized object equivalent of the given input {@link PGobject }
     * @throws JacksonException Thrown in case of exceptional sutah;
     */
    public Object convertFromPGobject(@NonNull PGobject pGobject, Class classs) throws JacksonException {
        return om.readValue(pGobject.getValue(), classs);
    }

}
