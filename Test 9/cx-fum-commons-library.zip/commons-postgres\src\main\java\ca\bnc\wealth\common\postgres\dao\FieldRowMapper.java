package ca.bnc.wealth.common.postgres.dao;

import ca.bnc.wealth.common.postgres.query.SqlQueryBuilder;
import ca.bnc.wealth.common.search.model.Field;
import org.jetbrains.annotations.NotNull;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FieldRowMapper implements RowMapper<Map<String, Object>> {
    private final Map<String, String> fieldNameToFieldPathMap;

    public FieldRowMapper(String language, List<Field> fields) {
        this.fieldNameToFieldPathMap = buildFieldMap(language, fields);
    }

    private Map<String, String> buildFieldMap(String language, List<Field> fields) {
        Map<String, String> fieldNameToFieldPathMap = new HashMap<>();
        if("EN".equalsIgnoreCase(language)){
            fields.forEach(field -> fieldNameToFieldPathMap.put(field.getName(), field.getFieldPath().getEn()));
        }
        else if("FR".equalsIgnoreCase(language)){
            fields.forEach(field -> fieldNameToFieldPathMap.put(field.getName(), field.getFieldPath().getFr()));
        }
        else{
            throw new IllegalArgumentException("Invalid Language Used to build FieldRowMapper");
        }
        return fieldNameToFieldPathMap;
    }

    @Override
    public Map<String, Object> mapRow(@NotNull ResultSet rs, int rowNum) {
        Map<String, Object> mappedResults = new HashMap<>();
        this.fieldNameToFieldPathMap.forEach((key, value) -> {
            try {
                Object ob = rs.getObject(value);
                mappedResults.put(key, ob);
            } catch (SQLException ignored) {}
        });
        try {
            Integer totalRows = rs.getInt(SqlQueryBuilder.TOTAL_ROW_COUNT_FIELD_NAME);
            mappedResults.put(SqlQueryBuilder.TOTAL_ROW_COUNT_FIELD_NAME, totalRows);
        } catch (SQLException ignored) {}
        return mappedResults;
    }
}
