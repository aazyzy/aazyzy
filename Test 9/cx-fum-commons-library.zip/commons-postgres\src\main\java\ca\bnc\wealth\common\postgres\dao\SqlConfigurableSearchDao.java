package ca.bnc.wealth.common.postgres.dao;

import ca.bnc.wealth.common.core.utils.Timed;
import ca.bnc.wealth.common.postgres.query.SqlQuery;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Slf4j
@Repository
public class SqlConfigurableSearchDao {
    private final NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public SqlConfigurableSearchDao(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Timed
    public List<Map<String, Object>> search(SqlQuery query, FieldRowMapper rowMapper) {
        log.info("Executing sql: {}", query.getSql());
        log.info("Sql Parameters: {}", query.getParameterSource());
        return jdbcTemplate.query(query.getSql(), query.getParameterSource(), rowMapper);
    }
}
