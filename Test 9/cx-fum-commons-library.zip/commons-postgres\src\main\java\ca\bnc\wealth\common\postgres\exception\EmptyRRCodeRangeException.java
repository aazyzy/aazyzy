package ca.bnc.wealth.common.postgres.exception;

public class EmptyRRCodeRangeException extends RuntimeException {
    private static final String DEFAULT_MESSAGE = "User does not have any assigned RR-Codes.  Cannot perform query.";

    public EmptyRRCodeRangeException() {
        this(DEFAULT_MESSAGE);
    }

    public EmptyRRCodeRangeException(String message) {
        super(message);
    }
}
