package ca.bnc.wealth.common.postgres.query;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

@Getter
@AllArgsConstructor
public class SqlQuery {
    private String sql;
    private MapSqlParameterSource parameterSource;
}
