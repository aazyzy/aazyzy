package ca.bnc.wealth.common.postgres.query;

import ca.bnc.wealth.common.core.feign.UserConfigApiClient;
import ca.bnc.wealth.common.postgres.exception.EmptyRRCodeRangeException;
import ca.bnc.wealth.common.postgres.utils.QueryUtils;
import ca.bnc.wealth.common.search.model.*;
import ca.bnc.wealth.common.search.model.Field;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import feign.FeignException;
import feign.RetryableException;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
public class SqlQueryBuilder {
    private final UserConfigApiClient userConfigApiClient;

    @Getter
    private final SearchConfig searchConfig;
    private final boolean useInlineFilters;
    private SqlQueryTemplate englishSqlTemplate;
    private SqlQueryTemplate frenchSqlTemplate;

    private static final String DEFAULT_ACCESS_CONTROL_FIELD = "b10_rr_code";

    private static final String EMPTY_STRING = "";
    private static final String COMMA = ",";
    private static final String SPACE = " ";
    private static final String OPEN_PARENTHESIS = "(";
    private static final String CLOSE_PARENTHESIS = ")";
    public static final String NEW_LINE = "\n";
    private static final String INDENT = SPACE.repeat(4);
    private static final String END_STATEMENT = ";";

    private static final String ENGLISH = "EN";
    private static final String FRENCH = "FR";
    private static final String PARAM_INDICATOR = ":";
    private static final String LIKE_MATCHER = "%";
    private static final String SPLIT_TERM = "splitTerm";
    private static final String SEARCH_TEXT = "searchText";
    private static final String LIKE_SEARCH_TEXT = "likeSearchText";

    private static final String WHERE = "WHERE";
    private static final String AND_NOT = "AND NOT";
    private static final String NOT = "NOT";
    private static final String IS_DISTINCT_FROM = "IS DISTINCT FROM";
    private static final String IS_NULL = "IS NULL";
    private static final String UNION_ALL = "UNION ALL";
    private static final String OFFSET = "OFFSET";
    private static final String SELECT = "SELECT";
    private static final String FROM = "FROM";
    private static final String ORDER_BY = "ORDER BY";
    private static final String LIMIT = "LIMIT";

    private static final String INVALID_LANGUAGE_ERROR = "Invalid Language Used";
    private static final String INVALID_PAGE_ERROR = "Invalid Page Number";

    private static final String EXACT_MATCH_CONDITIONS_PLACEHOLDER = "EXACT_MATCH_CONDITIONS_PLACEHOLDER";
    private static final String LIKE_MATCH_CONDITIONS_PLACEHOLDER = "LIKE_MATCH_CONDITIONS_PLACEHOLDER";
    private static final String FULL_MATCH_NEGATION_PLACEHOLDER = "FULL_MATCH_NEGATION_PLACEHOLDER";
    private static final String LIKE_MATCH_NEGATION_PLACEHOLDER = "LIKE_MATCH_NEGATION_PLACEHOLDER";

    private static final String RESULT_SET_PLACEHOLDER = "RESULT_SET_PLACEHOLDER";
    private static final String FILTER_CONDITIONS_PLACEHOLDER = "FILTER_CONDITIONS_PLACEHOLDER";
    private static final String ACCESS_CONTROL_AND_FILTERS_PLACEHOLDER = "ACCESS_CONTROL_AND_FILTERS_PLACEHOLDER";
    private static final String TOKEN_CONDITIONS_PLACEHOLDER = "TOKEN_CONDITIONS_PLACEHOLDER";
    private static final String ADDITIONAL_SORT_PLACEHOLDER = "ADDITIONAL_SORT_PLACEHOLDER";
    private static final String OFFSET_PLACEHOLDER = "OFFSET_PLACEHOLDER";
    private static final String LIMIT_PLACEHOLDER = "LIMIT_PLACEHOLDER";

    private static final String FILTER_PARAM_PREFIX = "f";
    private static final String NESTED_FILTER_PARAM_PREFIX = "n";
    private static final String FILTER_VALUE_PREFIX = "v";

    private static final String TOTAL_ROW_COUNT_RESULT_SET_FIELD = "COUNT(*) OVER() AS";
    public static final String TOTAL_ROW_COUNT_FIELD_NAME = "meta_total_row_count";

    private static final String FULL_MATCH_SQL_TEMPLATE_CTE = """
            SELECT %s, 1 AS qorder FROM filtered_table
                WHERE EXACT_MATCH_CONDITIONS_PLACEHOLDER
            UNION ALL
            SELECT %s, 2 AS qorder FROM filtered_table
                WHERE LIKE_MATCH_CONDITIONS_PLACEHOLDER
                FULL_MATCH_NEGATION_PLACEHOLDER""";

    private static final String TOKEN_MATCH_SQL_TEMPLATE_CTE = """
            SELECT %s, 3 AS qorder FROM filtered_table
                WHERE (
                TOKEN_CONDITIONS_PLACEHOLDER
                )
                FULL_MATCH_NEGATION_PLACEHOLDER
                LIKE_MATCH_NEGATION_PLACEHOLDER""";

    private static final String SQL_QUERY_TEMPLATE_CTE = """
            WITH filtered_table AS (
            SELECT %s FROM %s
            ACCESS_CONTROL_AND_FILTERS_PLACEHOLDER
            )
            SELECT RESULT_SET_PLACEHOLDER FROM (
            %s
            ) AS results
            ORDER BY qorderADDITIONAL_SORT_PLACEHOLDER
            LIMIT_PLACEHOLDER OFFSET_PLACEHOLDER;""";

    private static final String FULL_MATCH_SQL_TEMPLATE_INLINE = """
            SELECT %s, 1 AS qorder FROM %s
                WHERE FILTER_CONDITIONS_PLACEHOLDEREXACT_MATCH_CONDITIONS_PLACEHOLDER
            UNION ALL
            SELECT %s, 2 AS qorder FROM %s
                WHERE FILTER_CONDITIONS_PLACEHOLDER(LIKE_MATCH_CONDITIONS_PLACEHOLDER
                FULL_MATCH_NEGATION_PLACEHOLDER)""";

    private static final String TOKEN_MATCH_SQL_TEMPLATE_INLINE = """
            SELECT %s, 3 AS qorder FROM %s
                WHERE FILTER_CONDITIONS_PLACEHOLDER((
                TOKEN_CONDITIONS_PLACEHOLDER
                )
                FULL_MATCH_NEGATION_PLACEHOLDER
                LIKE_MATCH_NEGATION_PLACEHOLDER)""";

    private static final String SQL_QUERY_TEMPLATE_INLINE = """
            SELECT RESULT_SET_PLACEHOLDER FROM (
            %s
            ) AS results
            ORDER BY qorderADDITIONAL_SORT_PLACEHOLDER
            LIMIT_PLACEHOLDER OFFSET_PLACEHOLDER;""";

    public SqlQueryBuilder(UserConfigApiClient userConfigApiClient,
                           SearchConfig searchConfig) {
        this(userConfigApiClient, searchConfig, false);
    }

    public SqlQueryBuilder(UserConfigApiClient userConfigApiClient,
                           SearchConfig searchConfig,
                           boolean useInlineFilters) {
        this.userConfigApiClient = userConfigApiClient;
        this.searchConfig = searchConfig;
        this.useInlineFilters = useInlineFilters;
        init();
    }

    private void init(){
        validateSearchConfig();
        initTemplates();
    }

    private void validateSearchConfig(){
        if(searchConfig == null){
            throw new IllegalArgumentException("Search Configuration is Required");
        }
        if(searchConfig.getFields() == null || searchConfig.getFields().isEmpty()){
            throw new IllegalArgumentException("Search Configuration must contain fields");
        }
        if(searchConfig.getSchema() == null || StringUtils.isAnyBlank(searchConfig.getSchema().getEn(), searchConfig.getSchema().getFr())){
            throw new IllegalArgumentException("Search Configuration must contain schema");
        }
        if(searchConfig.getPaging() == null || searchConfig.getPaging().getPageSize() == null){
            throw new IllegalArgumentException("Search Configuration must contain paging configuration");
        }
    }

    /**
     * Initializes the English and French static templates.
     */
    private void initTemplates(){
        this.englishSqlTemplate = buildTemplate(ENGLISH);
        this.frenchSqlTemplate = buildTemplate(FRENCH);
    }

    /**
     * Builds a static query template with placeholders for dynamic fields. Template is derived from the search configuration.
     *
     * @param language {@link String}
     * @return Static Query Template {@link SqlQueryTemplate}
     */
    protected SqlQueryTemplate buildTemplate(String language){
        //Set language specific fields
        String schema;
        Function<Field, String> fieldToPath;
        if(ENGLISH.equalsIgnoreCase(language)) {
            schema = searchConfig.getSchema().getEn();
            fieldToPath = field -> field.getFieldPath().getEn();
        }
        else if (FRENCH.equalsIgnoreCase(language)){
            schema = searchConfig.getSchema().getFr();
            fieldToPath = field -> field.getFieldPath().getFr();
        }
        else{
            throw new IllegalArgumentException(INVALID_LANGUAGE_ERROR);
        }

        //Build field maps
        Map<String, String> allFields = searchConfig.getFields()
                .stream()
                .collect(Collectors.toMap(Field::getName, fieldToPath));
        Map<String, String> fullSearchFields = searchConfig.getFields()
                .stream()
                .filter(field -> field.getSearchTextType() != null && field.getSearchTextType().contains(SearchTextType.FULL))
                .collect(Collectors.toMap(Field::getName, fieldToPath));
        Map<String, String> splitSearchFields = searchConfig.getFields()
                .stream()
                .filter(field -> field.getSearchTextType() != null && field.getSearchTextType().contains(SearchTextType.SPLIT))
                .collect(Collectors.toMap(Field::getName, fieldToPath));

        if(fullSearchFields.isEmpty() && splitSearchFields.isEmpty()){
            throw new IllegalArgumentException("No Fields Configured for Search");
        }

        List<String> textSearchComponents = new ArrayList<>();
        String allFieldsString = String.join(COMMA+SPACE, allFields.values());

        if(!fullSearchFields.isEmpty()){
            String exactConditions = buildExactConditions(fullSearchFields);
            String likeConditions = buildLikeConditions(fullSearchFields);
            String fullMatchTemplate = useInlineFilters ? FULL_MATCH_SQL_TEMPLATE_INLINE : FULL_MATCH_SQL_TEMPLATE_CTE;
            String fullMatchComponent = fullMatchTemplate.replace(EXACT_MATCH_CONDITIONS_PLACEHOLDER, exactConditions)
                    .replace(LIKE_MATCH_CONDITIONS_PLACEHOLDER, likeConditions);
            textSearchComponents.add(useInlineFilters
                    ? String.format(fullMatchComponent, allFieldsString, schema, allFieldsString, schema)
                    : String.format(fullMatchComponent, allFieldsString, allFieldsString));
        }

        if(!splitSearchFields.isEmpty()){
            textSearchComponents.add(useInlineFilters
                    ? String.format(TOKEN_MATCH_SQL_TEMPLATE_INLINE, allFieldsString, schema)
                    : String.format(TOKEN_MATCH_SQL_TEMPLATE_CTE, allFieldsString));
        }

        String textSearchSubQuery = String.join(NEW_LINE+UNION_ALL+NEW_LINE, textSearchComponents)
                .replaceAll(FULL_MATCH_NEGATION_PLACEHOLDER, buildFullMatchNegations(fullSearchFields))
                .replaceAll(LIKE_MATCH_NEGATION_PLACEHOLDER, buildLikeMatchNegations(fullSearchFields));

        //inline variant applies filters directly on the base table in each branch; CTE variant keeps the legacy filtered_table
        String templateSql = useInlineFilters
                ? String.format(SQL_QUERY_TEMPLATE_INLINE, textSearchSubQuery)
                : String.format(SQL_QUERY_TEMPLATE_CTE, allFieldsString, schema, textSearchSubQuery);

        //Assemble template
        SqlQueryTemplate template = new SqlQueryTemplate();
        template.setSql(templateSql);
        template.setFields(allFields);
        template.setFullSearchFields(fullSearchFields);
        template.setSplitSearchFields(splitSearchFields);
        template.setSchema(schema);
        return template;
    }

    private String buildFullMatchNegations(Map<String, String> fullSearchFields){
        StringBuilder negationBuilder = new StringBuilder();
        negationBuilder.append(fullSearchFields.values()
                .stream()
                .map(this::fullMatchNegation)
                .collect(Collectors.joining(NEW_LINE+INDENT)));
        return negationBuilder.toString();
    }

    private String fullMatchNegation(String field){
        StringBuilder negationBuilder = new StringBuilder();
        negationBuilder.append(LogicalOperator.AND.getValue())
                .append(SPACE)
                .append(field)
                .append(SPACE)
                .append(IS_DISTINCT_FROM)
                .append(SPACE)
                .append(PARAM_INDICATOR)
                .append(SEARCH_TEXT);
        return negationBuilder.toString();
    }

    private String buildLikeMatchNegations(Map<String, String> fullSearchFields){
        StringBuilder negationBuilder = new StringBuilder();
        negationBuilder.append(fullSearchFields.values()
                .stream()
                .map(this::likeMatchNegation)
                .collect(Collectors.joining(NEW_LINE+INDENT)));
        return negationBuilder.toString();
    }

    private String likeMatchNegation(String field){
        StringBuilder negationBuilder = new StringBuilder();
        negationBuilder.append(LogicalOperator.AND.getValue())
                .append(SPACE)
                .append(OPEN_PARENTHESIS)
                .append(field)
                .append(SPACE)
                .append(NOT)
                .append(SPACE)
                .append(ComparisonOperator.LIKE.getKeyword())
                .append(SPACE)
                .append(PARAM_INDICATOR)
                .append(LIKE_SEARCH_TEXT)
                .append(SPACE)
                .append(LogicalOperator.OR.getValue())
                .append(SPACE)
                .append(field)
                .append(SPACE)
                .append(IS_NULL)
                .append(CLOSE_PARENTHESIS);
        return negationBuilder.toString();
    }

    private String buildExactConditions(Map<String, String> fullSearchFields){
        //(X = :searchText OR Y = :searchText)
        StringBuilder conditionBuilder = new StringBuilder(OPEN_PARENTHESIS);
        conditionBuilder.append(fullSearchFields.values()
                .stream()
                .map(field -> field + SPACE + ComparisonOperator.EQUALS.getKeyword() + SPACE + PARAM_INDICATOR + SEARCH_TEXT)
                .collect(Collectors.joining(SPACE + LogicalOperator.OR.getValue() + SPACE)));
        conditionBuilder.append(CLOSE_PARENTHESIS);
        return conditionBuilder.toString();
    }

    private String buildLikeConditions(Map<String, String> fullSearchFields){
        //(X LIKE :likeSearchText AND NOT X = :searchText)
        //OR (Y LIKE :likeSearchText AND NOT Y = :searchText)
        StringBuilder conditionBuilder = new StringBuilder();
        conditionBuilder.append(fullSearchFields.values()
                .stream()
                .map(this::buildLikeConditionStatement)
                .collect(Collectors.joining(NEW_LINE + INDENT + LogicalOperator.OR.getValue() + SPACE)));
        return conditionBuilder.toString();
    }

    private String buildLikeConditionStatement(String fieldName){
        StringBuilder conditionBuilder = new StringBuilder();
        conditionBuilder.append(OPEN_PARENTHESIS)
                .append(fieldName)
                .append(SPACE)
                .append(ComparisonOperator.LIKE.getKeyword())
                .append(SPACE)
                .append(PARAM_INDICATOR)
                .append(LIKE_SEARCH_TEXT)
                .append(SPACE)
                .append(AND_NOT)
                .append(SPACE)
                .append(fieldName)
                .append(SPACE)
                .append(ComparisonOperator.EQUALS.getKeyword())
                .append(SPACE)
                .append(PARAM_INDICATOR)
                .append(SEARCH_TEXT)
                .append(CLOSE_PARENTHESIS);
        return conditionBuilder.toString();
    }

    public SqlQuery buildCountOnlyQuery(SearchRequest request, String language){
        SqlQueryTemplate template = findTemplate(language);
        MapSqlParameterSource parameterSource = new MapSqlParameterSource();

        String whereStatement = buildFilters(request.getFilters(), template.getFields(), parameterSource);
        String sql = "SELECT COUNT(*) as "+ TOTAL_ROW_COUNT_FIELD_NAME +" FROM "+template.getSchema() +"\n" + whereStatement;

        return new SqlQuery(sql, parameterSource);
    }

    private SqlQueryTemplate findTemplate(String language){
        if(ENGLISH.equalsIgnoreCase(language)){
            return this.englishSqlTemplate;
        }
        else if(FRENCH.equalsIgnoreCase(language)){
            return this.frenchSqlTemplate;
        }
        else{
            throw new IllegalArgumentException("Language Parameter is not supported: "+language);
        }
    }

    /**
     * Builds a query based on the static template by replacing placeholders with data from the incoming search request.
     *
     * @param request {@link SearchRequest}
     * @param language {@link String}
     * @return Sql Query Object with sql string and parameter map. {@link SqlQuery}
     */
    public SqlQuery buildQuery(SearchRequest request, String language){
        SqlQueryTemplate template = findTemplate(language);

        if(Boolean.TRUE.equals(searchConfig.getDataAccessControl())){
            addDataAccessControlFilter(request);
        }

        if(StringUtils.isBlank(request.getSearchText()) && CollectionUtils.isEmpty(request.getFilters())){
            throw new IllegalArgumentException("Query requires either search text, filters, or access control to be present.");
        }

        SqlQuery sqlQuery;
        if(StringUtils.isBlank(request.getSearchText())){
            sqlQuery = buildFindAllQuery(template, request);
        }
        else{
            sqlQuery = buildSearchTermQuery(template, request);
        }

        return sqlQuery;
    }

    private SqlQuery buildSearchTermQuery(SqlQueryTemplate template, SearchRequest request){
        Integer pageSize = QueryUtils.determinePageSize(searchConfig, request);

        //Build initial parameters
        MapSqlParameterSource parameterSource = new MapSqlParameterSource();
        addValueToParameterSource(SEARCH_TEXT, request.getSearchText(), parameterSource);
        addValueToParameterSource(LIKE_SEARCH_TEXT, LIKE_MATCHER + request.getSearchText() + LIKE_MATCHER, parameterSource);

        //Replace placeholders
        String sql = template.getSql();
        sql = sql.replace(RESULT_SET_PLACEHOLDER, buildResultSet(request.getResultSet(), template.getFields()));
        if(useInlineFilters){
            sql = sql.replace(FILTER_CONDITIONS_PLACEHOLDER, buildInlineFilterConditions(request.getFilters(), template.getFields(), parameterSource));
        } else {
            sql = sql.replace(ACCESS_CONTROL_AND_FILTERS_PLACEHOLDER, buildFilters(request.getFilters(), template.getFields(), parameterSource));
        }
        sql = sql.replace(TOKEN_CONDITIONS_PLACEHOLDER, buildTokenizedMatchConditions(request.getSearchText(), template.getSplitSearchFields(), parameterSource));
        sql = sql.replace(ADDITIONAL_SORT_PLACEHOLDER, buildSort(request.getSorting(), template.getFields()));
        sql = sql.replace(LIMIT_PLACEHOLDER, buildLimit(pageSize));
        sql = sql.replace(OFFSET_PLACEHOLDER, buildOffset(request.getPageNumber(), pageSize));

        return new SqlQuery(sql.trim(), parameterSource);
    }

    private SqlQuery buildFindAllQuery(SqlQueryTemplate template, SearchRequest request){
        Integer pageSize = QueryUtils.determinePageSize(searchConfig, request);

        MapSqlParameterSource parameterSource = new MapSqlParameterSource();
        String resultSetStatement = buildResultSet(request.getResultSet(), template.getFields());
        String filterStatement = buildFilters(request.getFilters(), template.getFields(), parameterSource);
        String sortStatement = buildSort(request.getSorting(), template.getFields());
        String offsetStatement = buildOffset(request.getPageNumber(), pageSize);

        StringBuilder sqlBuilder = new StringBuilder()
                .append(SELECT).append(SPACE).append(resultSetStatement).append(SPACE).append(FROM).append(SPACE).append(template.getSchema())
                .append(NEW_LINE);

        if(StringUtils.isNotBlank(filterStatement)) {
                sqlBuilder.append(filterStatement)
                    .append(NEW_LINE);
        }

        if (StringUtils.isNotBlank(sortStatement)) {
            //Take substring of sort statement starting at index 2 as it will remove the initial comma and space needed for the text search query building.
            sqlBuilder.append(ORDER_BY)
                    .append(SPACE)
                    .append(sortStatement.substring(2))
                    .append(NEW_LINE);
        }


        sqlBuilder.append(LIMIT).append(SPACE).append(pageSize);

        if (StringUtils.isNotBlank(offsetStatement)) {
            sqlBuilder.append(SPACE).append(offsetStatement);
        }

        sqlBuilder.append(END_STATEMENT);

        return new SqlQuery(sqlBuilder.toString().trim(), parameterSource);
    }

    private void addDataAccessControlFilter(SearchRequest searchRequest){
        List<RRCodeRange> rrCodeRanges = getRrCodes();
        if(CollectionUtils.isEmpty(rrCodeRanges)){
            throw new EmptyRRCodeRangeException();
        }

        Filter rrCodeFilter = new Filter()
                .field(DEFAULT_ACCESS_CONTROL_FIELD)
                .operator(ComparisonOperator.BETWEEN)
                .values(List.of(
                        rrCodeRanges.get(0).getFromRRCodeB10(),
                        rrCodeRanges.get(0).getToRRCodeB10()
                ));

        for(int rangeIndex=1; rangeIndex<rrCodeRanges.size(); rangeIndex++){
            rrCodeFilter.addNestedItem(
                    new Filter()
                            .logicalOperator(LogicalOperator.OR)
                            .field(DEFAULT_ACCESS_CONTROL_FIELD)
                            .operator(ComparisonOperator.BETWEEN)
                            .values(List.of(
                                    rrCodeRanges.get(rangeIndex).getFromRRCodeB10(),
                                    rrCodeRanges.get(rangeIndex).getToRRCodeB10()
                            ))
            );
        }
        searchRequest.addFiltersItem(rrCodeFilter);
    }

    /**
     * Builds the order by statement of the sql from the list of sorts provided by the request.
     *
     * @param sorting {@link List}
     * @param templateFields {@link Map}
     * @return Sql Order By Statement {@link String}
     */
    private String buildSort(List<Sort> sorting, Map<String, String> templateFields) {
        if(sorting == null || sorting.isEmpty()){
            return EMPTY_STRING;
        }

        List<String> sorts = new ArrayList<>();
        for(Sort sort : sorting){
            String fieldPath = templateFields.get(sort.getField());
            if(fieldPath == null){
                throw new IllegalArgumentException(String.format("Illegal Field In Sort: %s", sort.getField()));
            }
            sorts.add(fieldPath+SPACE+sort.getOrder().toString());
        }
        return (COMMA + SPACE) + String.join(COMMA + SPACE, sorts);
    }

    /**
     * Builds the limit statement of the sql with the provided page size.
     *
     * @param pageSize {@link Integer}
     * @return Sql Limit Statement {@link String}
     */
    private String buildLimit(Integer pageSize) {
        return LIMIT + SPACE + pageSize;
    }

    /**
     * Builds the offset statement of the sql with the page number provided by the request.
     *
     * @param pageNumber {@link Integer}
     * @param pageSize {@link Integer}
     * @return Sql Offset Statement {@link String}
     */
    private String buildOffset(Integer pageNumber, Integer pageSize) {
        if(pageNumber == null || pageNumber == 1){
            return EMPTY_STRING;
        }
        else if(pageNumber < 1){
            throw new IllegalArgumentException(INVALID_PAGE_ERROR);
        }
        else {
            return OFFSET + SPACE + (pageNumber-1)*pageSize;
        }
    }

    /**
     * Builds the select statement columns string of the sql with the result set information provided by the request.
     *
     * @param resultSet {@link List}
     * @param templateFields {@link Map}
     * @return Sql Select Statement Columns {@link String}
     */
    private String buildResultSet(List<String> resultSet, Map<String, String> templateFields) {
        List<String> resultSetFields = new ArrayList<>();
        if(resultSet == null || resultSet.isEmpty()){
            resultSetFields.addAll(templateFields.values());
        }
        else{
            resultSet.forEach(field -> {
                String fieldPath = templateFields.get(field);
                if(fieldPath == null){
                    throw new IllegalArgumentException(String.format("Illegal Field In Result Set: %s", field));
                }
                resultSetFields.add(fieldPath);
            });
        }
        if(!Boolean.TRUE.equals(this.searchConfig.getSeparatePagingQuery())) {
            resultSetFields.add(TOTAL_ROW_COUNT_RESULT_SET_FIELD+SPACE+TOTAL_ROW_COUNT_FIELD_NAME);
        }
        return String.join(COMMA + SPACE, resultSetFields);
    }

    /**
     * Builds the split-term-search where statement of the sql from the fields and search text. Populates the provided parameter source map with data as it builds.
     *
     * @param searchText {@link String}
     * @param templateSplitFields {@link Map}
     * @param parameterSource {@link MapSqlParameterSource}
     * @return Sql Split-Term-Search Where Statement {@link String}
     */
    private String buildTokenizedMatchConditions(String searchText, Map<String, String> templateSplitFields, MapSqlParameterSource parameterSource){
        if(templateSplitFields.isEmpty()) return EMPTY_STRING;

        List<String> terms = List.of(searchText.split(SPACE));
        List<String> qualifiedTerms = terms.stream().filter(term -> !searchConfig.getSplitTermExcludes().contains(term)).toList();
        List<String> tokenizedMatchConditions = new ArrayList<>();
        for(String field : templateSplitFields.values()){
            String condition = buildTokenizedMatchConditions(field, qualifiedTerms.size());
            if(!StringUtils.isBlank(condition)){
                tokenizedMatchConditions.add(condition);
            }
        }
        for(int i=0; i<qualifiedTerms.size(); i++){
            addValueToParameterSource(SPLIT_TERM+i, LIKE_MATCHER+qualifiedTerms.get(i)+LIKE_MATCHER, parameterSource);
        }

        return tokenizedMatchConditions.stream().collect(Collectors.joining(NEW_LINE + INDENT + LogicalOperator.OR.getValue() + SPACE));
    }

    private String buildTokenizedMatchConditions(String fieldName, int numberOfQualifiedTerms){
        if(numberOfQualifiedTerms <= 0) return EMPTY_STRING;

        List<String> qualifiedTermConditions = new ArrayList<>();
        for(int i=0; i<numberOfQualifiedTerms; i++){
            String condition = fieldName + SPACE + ComparisonOperator.LIKE.getKeyword() + SPACE + PARAM_INDICATOR + SPLIT_TERM + i;
            qualifiedTermConditions.add(condition);
        }
        String conditions = String.join(SPACE + LogicalOperator.OR.getValue() + SPACE, qualifiedTermConditions);
        StringBuilder conditionBuilder = new StringBuilder()
                .append(OPEN_PARENTHESIS)
                .append(conditions)
                .append(CLOSE_PARENTHESIS);

        return conditionBuilder.toString();
    }

    /**
     * Builds the corresponding where statements for the sql with the filters provided by the request.  Populates the provided parameter source map with data as it builds.
     *
     * @param parentFilters {@link List}
     * @param templateFields {@link Map}
     * @param parameterSource {@link MapSqlParameterSource}
     * @return Sql Where Statements {@link String}
     */
    public String buildFilters(List<Filter> parentFilters, Map<String, String> templateFields, MapSqlParameterSource parameterSource){
        if(parentFilters == null || parentFilters.isEmpty()){
            return EMPTY_STRING;
        }

        StringBuilder filterBuilder = new StringBuilder();
        AtomicInteger nestedFilterIndex = new AtomicInteger(0);
        String lineStart = WHERE;
        for(int filterIndex=0; filterIndex< parentFilters.size(); filterIndex++) {
            if(filterIndex > 0){
                lineStart = LogicalOperator.AND.getValue();
            }

            Filter parentFilter = parentFilters.get(filterIndex);
            validateFilter(parentFilter);
            String fieldPath = templateFields.get(parentFilter.getField());

            String condition = buildCondition(filterIndex, parentFilter, fieldPath, parameterSource);

            filterBuilder.append(INDENT)
                    .append(lineStart)
                    .append(SPACE)
                    .append(OPEN_PARENTHESIS)
                    .append(condition);

            if(parentFilter.getNested() != null && !parentFilter.getNested().isEmpty()){
                for(Filter nestedFilter : parentFilter.getNested()){
                    String nestedFilterString = buildNested(nestedFilterIndex, nestedFilter, templateFields, parameterSource);
                    filterBuilder.append(nestedFilterString);
                }
            }

            filterBuilder.append(CLOSE_PARENTHESIS)
                    .append(NEW_LINE);
        }
        filterBuilder.deleteCharAt(filterBuilder.length()-1);
        return filterBuilder.toString();
    }

    /**
     * Builds the filter conditions as an inline prefix applied directly on the base table within each search branch (replaces the former filtered_table CTE).
     * Returns an empty string when no filters are present, otherwise the parenthesized conditions terminated with a trailing AND.
     */
    private String buildInlineFilterConditions(List<Filter> parentFilters, Map<String, String> templateFields, MapSqlParameterSource parameterSource){
        String filterStatement = buildFilters(parentFilters, templateFields, parameterSource);
        if(StringUtils.isBlank(filterStatement)){
            return EMPTY_STRING;
        }
        String conditions = filterStatement.trim().substring(WHERE.length()).trim();
        return conditions + SPACE + LogicalOperator.AND.getValue() + SPACE;
    }

    public String buildNested(AtomicInteger nestedFilterIndex, Filter filter, Map<String, String> templateFields, MapSqlParameterSource parameterSource){
        validateFilter(filter, true);
        String fieldPath = templateFields.get(filter.getField());

        String condition = buildCondition(nestedFilterIndex.getAndIncrement(), NESTED_FILTER_PARAM_PREFIX, filter, fieldPath, parameterSource);
        StringBuilder filterBuilder = new StringBuilder(SPACE);
        filterBuilder.append(filter.getLogicalOperator().getValue())
                .append(SPACE)
                .append(OPEN_PARENTHESIS)
                .append(condition);

        if(filter.getNested() != null && !filter.getNested().isEmpty()){
            for(Filter nestedFilter : filter.getNested()){
                String nestedFilterString = buildNested(nestedFilterIndex, nestedFilter, templateFields, parameterSource);
                filterBuilder.append(nestedFilterString);
            }
        }

        filterBuilder.append(CLOSE_PARENTHESIS);

        return filterBuilder.toString();
    }

    private String buildCondition(int filterIndex, String paramPrefix, Filter filter, String fieldPath, MapSqlParameterSource parameterSource){
        StringBuilder filterBuilder = new StringBuilder();
        if(ComparisonOperator.BETWEEN.equals(filter.getOperator())) {
            filterBuilder.append(buildBetweenCondition(filterIndex, paramPrefix, filter, fieldPath, parameterSource));
        }
        else if (ComparisonOperator.CONTAINS.equals(filter.getOperator())) {
            filterBuilder.append(buildContainsCondition(filterIndex, paramPrefix, filter, fieldPath, parameterSource));
        }
        else {
            filterBuilder.append(buildSingleValueCondition(filterIndex, paramPrefix, filter, fieldPath, parameterSource));
        }
        return filterBuilder.toString();
    }

    private String buildCondition(int filterIndex, Filter filter, String fieldPath, MapSqlParameterSource parameterSource){
        return buildCondition(filterIndex, FILTER_PARAM_PREFIX, filter, fieldPath, parameterSource);
    }

    private String buildContainsCondition(int filterIndex, String paramPrefix, Filter filter, String fieldPath, MapSqlParameterSource parameterSource){
        StringBuilder filterBuilder = new StringBuilder();
        StringBuilder valueBuilder = new StringBuilder();
        for (int valueIndex = 0; valueIndex < filter.getValues().size(); valueIndex++) {
            String valueParam = createValueParamString(filterIndex, valueIndex, paramPrefix);
            Object value = filter.getValues().get(valueIndex);

            valueBuilder.append(":").append(valueParam).append(COMMA).append(SPACE);
            addValueToParameterSource(valueParam, value, fieldPath, parameterSource);
        }
        //Delete comma space at end of valueBuilder
        valueBuilder.delete(valueBuilder.length()-2, valueBuilder.length());
        filterBuilder.append(fieldPath)
                .append(SPACE)
                .append((filter.getNegation() != null && filter.getNegation()) ? (NOT + SPACE) : EMPTY_STRING)
                .append(filter.getOperator().getKeyword())
                .append(SPACE)
                .append(OPEN_PARENTHESIS)
                .append(valueBuilder)
                .append(CLOSE_PARENTHESIS);
        return filterBuilder.toString();
    }

    private String buildBetweenCondition(int filterIndex, String paramPrefix, Filter filter, String fieldPath, MapSqlParameterSource parameterSource){
        StringBuilder filterBuilder = new StringBuilder();
        if(filter.getValues().size() != 2){
            throw new IllegalArgumentException("Between Filter Requires Exactly Two Values");
        }

        Object startValue = filter.getValues().get(0);
        String startValueParam = createValueParamString(filterIndex, 0, paramPrefix);
        Object endValue = filter.getValues().get(1);
        String endValueParam = createValueParamString(filterIndex, 1, paramPrefix);

        filterBuilder.append((filter.getNegation() != null && filter.getNegation()) ? (NOT + SPACE) : EMPTY_STRING)
                .append(fieldPath)
                .append(SPACE)
                .append(filter.getOperator().getKeyword())
                .append(SPACE)
                .append(PARAM_INDICATOR).append(startValueParam)
                .append(SPACE)
                .append(LogicalOperator.AND.getValue())
                .append(SPACE)
                .append(PARAM_INDICATOR).append(endValueParam);

        addValueToParameterSource(startValueParam, startValue, fieldPath, parameterSource);
        addValueToParameterSource(endValueParam, endValue, fieldPath, parameterSource);

        return filterBuilder.toString();
    }

    private String buildSingleValueCondition(int filterIndex, String paramPrefix, Filter filter, String fieldPath, MapSqlParameterSource parameterSource){
        StringBuilder filterBuilder = new StringBuilder();
        if(filter.getValues().size() != 1){
            throw new IllegalArgumentException("Single Value Filter Requires Exactly One Value");
        }
        Object value = filter.getValues().get(0);
        String valueParam = createValueParamString(filterIndex, 0, paramPrefix);

        filterBuilder.append((filter.getNegation() != null && filter.getNegation()) ? (NOT + SPACE) : EMPTY_STRING)
                .append(fieldPath)
                .append(SPACE)
                .append(filter.getOperator().getKeyword())
                .append(SPACE)
                .append(PARAM_INDICATOR).append(valueParam);

        if(ComparisonOperator.LIKE.equals(filter.getOperator()) || ComparisonOperator.LIKE_CASE_INSENSITIVE.equals(filter.getOperator())){
            value = LIKE_MATCHER + value + LIKE_MATCHER;
        }

        addValueToParameterSource(valueParam, value, fieldPath, parameterSource);

        return filterBuilder.toString();
    }

    private void validateFilter(Filter filter) {
        validateFilter(filter, false);
    }

    private void validateFilter(Filter filter, boolean isNested) {
        FieldType type = searchConfig.getFields().stream()
                .filter(f -> f.getName().equals(filter.getField()))
                .map(Field::getType)
                .findFirst().orElseThrow( () ->
                        new IllegalArgumentException("Field " + filter.getField() + " not found in search configuration")
                );

        if (type == null || !filter.getOperator().getSupportedTypes().contains(type)) {
            throw new IllegalArgumentException("Operation " + filter.getOperator() + " is not compatible with type " + type);
        }
        if(isNested && filter.getLogicalOperator() == null){
            throw new IllegalArgumentException("Nested Filter Requires a Logical Operator");
        }
    }

    private String createValueParamString(int filterIndex, int valueIndex, String prefix) {
        return prefix + filterIndex + FILTER_VALUE_PREFIX + valueIndex;
    }

    private List<RRCodeRange> getRrCodes(){
        List<RRCodeRange> rrCodes;
        try{
            rrCodes = this.userConfigApiClient.getRRCodes();
        }catch (RetryableException serviceUnavailableException){
            log.error("CRITICAL: UserConfigAPI Not Available", serviceUnavailableException);
            throw serviceUnavailableException;
        }catch (FeignException genericFeignException) {
            log.error("ERROR: Call to UserConfigAPI failed.", genericFeignException);
            throw genericFeignException;
        }
        return rrCodes;
    }

    private FieldType getFieldTypeFromPath(String fieldPath){
        return searchConfig.getFields().stream()
                .filter(f -> f.getFieldPath().getEn().equals(fieldPath) || f.getFieldPath().getFr().equals(fieldPath))
                .map(Field::getType)
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Field path not found in search configuration"));
    }

    private void addValueToParameterSource(String paramName, Object value, String fieldPath, MapSqlParameterSource parameterSource) {
        FieldType fieldType = getFieldTypeFromPath(fieldPath);
        addValueToParameterSource(paramName, value, fieldType, parameterSource);
    }

    private void addValueToParameterSource(String paramName, Object value, MapSqlParameterSource parameterSource){
        addValueToParameterSource(paramName, value, FieldType.STRING, parameterSource);
    }

    private void addValueToParameterSource(String paramName, Object value, FieldType fieldType, MapSqlParameterSource parameterSource){
        if(FieldType.DATE.equals(fieldType)){
            LocalDate dateValue = LocalDate.parse(value.toString());
            parameterSource.addValue(paramName, dateValue);
        }
        else if (FieldType.TIMESTAMP.equals(fieldType)){
            LocalDateTime timestampValue = LocalDateTime.parse(value.toString());
            parameterSource.addValue(paramName, timestampValue);
        }
        else{
            parameterSource.addValue(paramName, value);
        }
    }
}