package ca.bnc.wealth.common.postgres.query;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;

import java.util.Map;

@Data
public class SqlQueryTemplate {
    private String sql;
    private Map<String, String> fields;
    @Getter(value = AccessLevel.NONE)
    private Map<String, String> fullSearchFields;
    private Map<String, String> splitSearchFields;
    private String schema;
}