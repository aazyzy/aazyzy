package ca.bnc.wealth.common.postgres.service;

import ca.bnc.wealth.common.core.feign.UserConfigApiClient;
import ca.bnc.wealth.common.core.search.GenericSearch;
import ca.bnc.wealth.common.postgres.exception.EmptyRRCodeRangeException;
import ca.bnc.wealth.common.postgres.utils.QueryUtils;
import ca.bnc.wealth.common.search.model.Paging;
import ca.bnc.wealth.common.search.model.SearchConfig;
import ca.bnc.wealth.common.search.model.SearchRequest;
import ca.bnc.wealth.common.search.model.SearchResponse;
import ca.bnc.wealth.common.core.utils.Timed;
import ca.bnc.wealth.common.postgres.dao.FieldRowMapper;
import ca.bnc.wealth.common.postgres.dao.SqlConfigurableSearchDao;
import ca.bnc.wealth.common.postgres.query.SqlQuery;
import ca.bnc.wealth.common.postgres.query.SqlQueryBuilder;
import jakarta.annotation.PostConstruct;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.core.io.ResourceLoader;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.*;

import static org.springframework.core.io.ResourceLoader.CLASSPATH_URL_PREFIX;

@Slf4j
@Service
@ConfigurationProperties(prefix = "generic-search")
class SqlConfigurableSearchService implements GenericSearch {
    private final SqlConfigurableSearchDao searchDao;
    private static final Map<String, SearchConfig> searchConfigs = new HashMap<>();
    private static final Map<String, SqlQueryBuilder> queryBuilders = new HashMap<>();
    private final ObjectMapper objectMapper;
    private final ResourceLoader resourceLoader;
    @Setter
    private Map<String, String> configPaths;
    // opt-in flag; when false the legacy filtered_table CTE query is used
    @Setter
    private boolean inlineFilters = false;

    private final UserConfigApiClient userConfigApiClient;

    private static final String META_DATA_TOTAL_ROW_COUNT = "meta_total_row_count";

    @Autowired
    public SqlConfigurableSearchService(SqlConfigurableSearchDao searchDao,
                                        ObjectMapper objectMapper,
                                        ResourceLoader resourceLoader,
                                        @Qualifier("commonsUserConfigApiClient") UserConfigApiClient userConfigApiClient) {
        this.searchDao = searchDao;
        this.objectMapper = objectMapper;
        this.resourceLoader = resourceLoader;
        this.userConfigApiClient = userConfigApiClient;
    }

    /**
     * Populates the Map of Search Configurations on initialization of the class.  The configPaths are populated through application.yml of the calling api.
     *
     */
    @PostConstruct
    private void init(){
        configPaths.forEach((key, path) -> {
            try {
                log.info("Generating QueryBuilder for {} at {}", key, path);
                String location = CLASSPATH_URL_PREFIX + path;
                log.info("URL Location: {}", location);
                URL configFileUrl = resourceLoader.getResource(location).getURL();
                SearchConfig config;
                try (InputStream configStream = configFileUrl.openStream()) {
                    config = objectMapper.readValue(configStream, SearchConfig.class);
                }
                searchConfigs.put(key, config);
                queryBuilders.put(key, new SqlQueryBuilder(userConfigApiClient, config, inlineFilters));
            } catch (IOException | JacksonException e) {
                throw new RuntimeException("Unable to initialize searchConfigs and/or queryBuilders.", e);
            }
        });
    }

    /**
     * Builds and performs a query on the repository specified by the config name parameter.
     * Will throw a NoResultsFoundException if the data list returned is empty.
     * Will throw a ServiceException if there was an error while performing the query.
     *
     * @param request {@link SearchRequest}
     * @param language {@link String}
     * @param configName {@link String}
     * @throws Exception processing query fails
     * @throws DataAccessException no data is found in query
     * @return {@link SearchResponse}
     */
    @Override
    @Timed
    public SearchResponse search(SearchRequest request, String language, String configName){
        try{
            log.debug("Request: {}", request);
            SqlQueryBuilder sqlQueryBuilder = queryBuilders.get(configName);
            boolean useSeparatePagingQuery = Boolean.TRUE.equals(sqlQueryBuilder.getSearchConfig().getSeparatePagingQuery());

            SqlQuery query = queryBuilders.get(configName).buildQuery(request, language);
            FieldRowMapper rowMapper = new FieldRowMapper(language, searchConfigs.get(configName).getFields());
            List<Map<String, Object>> results = searchDao.search(query, rowMapper);

            if(useSeparatePagingQuery){
                addTotalRowCountFromSeparateQuery(sqlQueryBuilder, request, language, rowMapper, results);
            }

            Integer pageSize = QueryUtils.determinePageSize(searchConfigs.get(configName), request);
            SearchResponse response = processResults(results, request.getPageNumber(), pageSize);
            log.debug("Response: {}", response);
            return response;
        } catch (EmptyRRCodeRangeException emptyRRCodeRangeException) {
            log.warn("Returning Empty Response. Access control on rr codes failed for request: {}",
                    request,
                    emptyRRCodeRangeException
            );
            return new SearchResponse()
                    .paging(
                            new Paging()
                                    .pageNumber(1)
                                    .nextPage(false)
                                    .totalPages(1)
                    )
                    .data(new ArrayList<>());
        } catch (DataAccessException dae){
            log.info("No results found for: {}", request);
            throw dae;
        } catch (Exception ex){
            log.warn("Error processing query: {}", ex.getMessage());
            throw ex;
        }
    }

    protected void addTotalRowCountFromSeparateQuery(SqlQueryBuilder sqlQueryBuilder, SearchRequest request, String language, FieldRowMapper rowMapper, List<Map<String, Object>> results) {
        SqlQuery countQuery = sqlQueryBuilder.buildCountOnlyQuery(request, language);
        List<Map<String, Object>> countResults = searchDao.search(countQuery, rowMapper);
        if(countResults.isEmpty()){
            throw new DataAccessException("Count query did not return any results."){};
        }
        int totalRows = (Integer) countResults.get(0).get(META_DATA_TOTAL_ROW_COUNT);
        //Add total rows to first result of main query results so that it can be used to calculate total pages and next page in the response
        if(!CollectionUtils.isEmpty(results)){
            results.get(0).put(META_DATA_TOTAL_ROW_COUNT, totalRows);
        }
    }

    /**
     * Processes a map of raw data to build and return a SearchResponse object.
     * Page number is required to build the SearchResponse.
     *
     * @param results {@link List<Map>}
     * @param requestPageNumber {@link Integer}
     * @return {@link SearchResponse}
     */
    private SearchResponse processResults(List<Map<String, Object>> results, Integer requestPageNumber, Integer pageSize){
        int pageNumber = (requestPageNumber == null || requestPageNumber == 0) ? 1 : requestPageNumber;
        int totalRowsFound = 0;
        if(!results.isEmpty()){
            totalRowsFound = (int) results.get(0).get(META_DATA_TOTAL_ROW_COUNT);
        }
        log.info("Total Rows Found for query: {}", totalRowsFound);
        int dividend = totalRowsFound / pageSize;
        int remainder = totalRowsFound % pageSize;
        int totalPages = remainder == 0 ? dividend : dividend + 1;

        boolean hasNextPage = pageNumber * pageSize < totalPages * pageSize;

        //Clean results by removing metadata row
        results.forEach(result -> result.remove(META_DATA_TOTAL_ROW_COUNT));

        return new SearchResponse()
                .paging(
                        new Paging()
                                .pageNumber(pageNumber)
                                .nextPage(hasNextPage)
                                .totalPages(totalPages)
                )
                .data(results);
    }
}