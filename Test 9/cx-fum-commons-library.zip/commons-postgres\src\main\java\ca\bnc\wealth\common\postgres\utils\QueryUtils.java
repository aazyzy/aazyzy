package ca.bnc.wealth.common.postgres.utils;

import ca.bnc.wealth.common.search.model.SearchConfig;
import ca.bnc.wealth.common.search.model.SearchRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.List;
import java.util.Optional;

@Slf4j
public class QueryUtils {

  public static <T> List<T> getSimpleList(
      NamedParameterJdbcTemplate template,
      String query,
      List<Pair<String, Object>> parameters,
      Class<T> t) {
    MapSqlParameterSource sqlParameters =
        Optional.ofNullable(parameters)
            .map(QueryUtils::getParameters)
            .orElse(new MapSqlParameterSource());
    return template.queryForList(query, sqlParameters, t);
  }

  public static <T> List<T> getResultList(
      NamedParameterJdbcTemplate template,
      String query,
      List<Pair<String, Object>> parameters,
      Class<T> t) {
    MapSqlParameterSource sqlParameters =
        Optional.ofNullable(parameters)
            .map(QueryUtils::getParameters)
            .orElse(new MapSqlParameterSource());
    return template.query(query, sqlParameters, BeanPropertyRowMapper.newInstance(t));
  }

  public static <T> List<T> getResultList(
      NamedParameterJdbcTemplate template,
      String query,
      List<Pair<String, Object>> parameters,
      RowMapper<T> rowMapper) {
    MapSqlParameterSource sqlParameters =
        Optional.ofNullable(parameters)
            .map(QueryUtils::getParameters)
            .orElse(new MapSqlParameterSource());
    return template.query(query, sqlParameters, rowMapper);
  }

  public static <T> Optional<T> getResult(
      NamedParameterJdbcTemplate template,
      String query,
      List<Pair<String, Object>> parameters,
      Class<T> t) {
    MapSqlParameterSource sqlParameters =
        Optional.ofNullable(parameters)
            .map(QueryUtils::getParameters)
            .orElse(new MapSqlParameterSource());
    try {
      return Optional.ofNullable(template.queryForObject(query, sqlParameters, t));
    } catch (EmptyResultDataAccessException e) {
      return Optional.empty();
    }
  }

  public static <T> Optional<T> getResult(
      NamedParameterJdbcTemplate template,
      String query,
      List<Pair<String, Object>> parameters,
      RowMapper<T> rowMapper) {
    MapSqlParameterSource sqlParameters =
        Optional.ofNullable(parameters)
            .map(QueryUtils::getParameters)
            .orElse(new MapSqlParameterSource());
    try {
      return Optional.ofNullable(template.queryForObject(query, sqlParameters, rowMapper));
    } catch (EmptyResultDataAccessException e) {
      return Optional.empty();
    }
  }

  private static MapSqlParameterSource getParameters(List<Pair<String, Object>> parameters) {
    MapSqlParameterSource sqlParameters = new MapSqlParameterSource();
    parameters.forEach(pair -> sqlParameters.addValue(pair.getKey(), pair.getValue()));
    return sqlParameters;
  }

    public static Integer determinePageSize(SearchConfig searchConfig, SearchRequest request){
        if(Boolean.FALSE.equals(searchConfig.getPaging().getUseRequestPageSize())){
            return searchConfig.getPaging().getPageSize();
        }

        if(request.getPageSize() == null
                || request.getPageSize() <= 0
                || request.getPageSize() > searchConfig.getPaging().getRequestPageSizeLimit()
        ){
            log.warn("Request page size {} is invalid. Must be between 1 and {}. Using default page size {} from search config.",
                    request.getPageSize(),
                    searchConfig.getPaging().getRequestPageSizeLimit(),
                    searchConfig.getPaging().getPageSize()
            );
            return searchConfig.getPaging().getPageSize();
        }
        else{
            return request.getPageSize();
        }
    }
}
