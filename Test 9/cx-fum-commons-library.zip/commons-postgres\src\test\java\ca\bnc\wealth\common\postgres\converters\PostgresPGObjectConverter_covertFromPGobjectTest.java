package ca.bnc.wealth.common.postgres.converters;

import org.junit.Test;
import org.postgresql.util.PGobject;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;

import java.sql.SQLException;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for {@link PostgresPGObjectConverter}
 */
public class PostgresPGObjectConverter_covertFromPGobjectTest {

    private final ObjectMapper om = JsonMapper.builderWithJackson2Defaults().build();
    private PostgresPGObjectConverter converter = new PostgresPGObjectConverter(om);

    @Test
    public void whenObjectIsNull_ThenNullIsReturned() throws SQLException {
        PGobject pgObject = new PGobject();
        pgObject.setType("jsonb");
        pgObject.setValue(om.writeValueAsString(new RandomObject()));
        // CUT
        RandomObject actual = (RandomObject) converter.convertFromPGobject(pgObject, RandomObject.class);
        //Verify
        assertThat(actual.field1).isEqualTo("field1");
        assertThat(actual.field2).isEqualTo("field2");
    }

    private static class RandomObject {
        public String field1 = "field1";
        public String field2 = "field2";
    }
}
