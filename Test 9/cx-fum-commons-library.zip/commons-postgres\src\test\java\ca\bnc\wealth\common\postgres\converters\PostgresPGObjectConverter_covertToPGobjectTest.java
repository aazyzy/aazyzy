package ca.bnc.wealth.common.postgres.converters;

import org.junit.Test;
import org.postgresql.util.PGobject;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for {@link PostgresPGObjectConverter}
 */
public class PostgresPGObjectConverter_covertToPGobjectTest {

    private final ObjectMapper om = JsonMapper.builderWithJackson2Defaults().build();
    private PostgresPGObjectConverter converter = null;

    @Test
    public void whenObjectIsNull_ThenNullIsReturned() {
        converter = new PostgresPGObjectConverter(om) {
            protected String getJson(Object object) {
                return "{}";
            }
        };
        assertThat(converter.convertToPGobject(null)).isNull();
    }

    @Test
    public void whenJsonValueIsNull_ThenNullIsReturned() {
        converter = new PostgresPGObjectConverter(om) {
            protected String getJson(Object object) {
                return null;
            }
        };
        assertThat(converter.convertToPGobject(new Object())).isNull();
    }


    @Test
    public void whenValidObjectIsPassed_ThenCorrespondingPGObjectIsReturned() {
        RandomObject ro = new RandomObject();
        String serializedRo = null;
        try {
            serializedRo = om.writeValueAsString(ro);
        } catch (JacksonException e) {
            // Dont bother. This is a test setup.
        }
        final String finalSerializedRo = serializedRo;

        converter = new PostgresPGObjectConverter(om) {
            protected String getJson(Object object) {
                return finalSerializedRo;
            }
        };

        // CUT
        PGobject actual = converter.convertToPGobject(new Object());

        // Verify
        assertThat(actual.getType()).isEqualTo("jsonb");
        assertThat(actual.getValue()).isNotBlank().isEqualTo(finalSerializedRo);
    }

    private static class RandomObject {
        public String field1 = "field1";
        public String field2 = "field2";
    }
}
