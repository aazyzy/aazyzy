package ca.bnc.wealth.common.postgres.dao;

import ca.bnc.wealth.common.postgres.query.SqlQuery;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ConfigurableSearchPostgresDaoTest {
    @Mock
    NamedParameterJdbcTemplate jdbcTemplate;

    @Mock
    FieldRowMapper rowMapper;

    private SqlConfigurableSearchDao dao;

    @BeforeEach
    public void setup(){
        dao = new SqlConfigurableSearchDao(jdbcTemplate);
    }

    @Test
    public void testSearch() {
        List<Map<String, Object>> mockResultSet = createMockResultSet();
        when(jdbcTemplate.query(anyString(), (SqlParameterSource) any(), (FieldRowMapper) any())).thenReturn(mockResultSet);

        List<Map<String, Object>> results = dao.search(new SqlQuery("", null), rowMapper);

        assertNotNull(results);
        assertEquals(2, results.size());
    }

    private List<Map<String, Object>> createMockResultSet() {
        Map<String, Object> data1 = new HashMap<>();
        data1.put("symbol", "NBC");
        data1.put("country", "CAN");
        data1.put("description", "National Bank of Canada");
        data1.put("market_price", 50);
        Map<String, Object> data2 = new HashMap<>();
        data1.put("symbol", "AMD");
        data1.put("country", "US");
        data1.put("description", "Advanced Micro Processors");
        data1.put("market_price", 99);
        return List.of(data1, data2);
    }


}
