package ca.bnc.wealth.common.postgres.dao;


import ca.bnc.wealth.common.postgres.query.SqlQueryBuilder;
import ca.bnc.wealth.common.search.model.Field;
import ca.bnc.wealth.common.search.model.SearchConfig;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class FieldRowMapperTest {
    @Mock
    private ResultSet resultSet;

    private SearchConfig searchConfig;
    private FieldRowMapper rowMapper;
    private static final String configurableSearchFilePath = "configurable-search-config.json";

    @BeforeEach
    public void setup() throws IOException {
        ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().build();
        ClassPathResource requestResource = new ClassPathResource(configurableSearchFilePath, this.getClass().getClassLoader());
        this.searchConfig = objectMapper.readValue(requestResource.getFile(), SearchConfig.class);
    }

    @ParameterizedTest
    @ValueSource(strings = {"EN", "FR"})
    public void testMapRow_Success(String language) throws SQLException {
        this.rowMapper = new FieldRowMapper(language, searchConfig.getFields());

        when(resultSet.getObject(anyString())).thenReturn("SomeDataValue");
        Map<String, Object> results = this.rowMapper.mapRow(resultSet, 0);
        Set<String> resultKeySet = results.keySet();
        Set<String> expectedKeys = searchConfig.getFields().stream().map(Field::getName).collect(Collectors.toSet());
        expectedKeys.add(SqlQueryBuilder.TOTAL_ROW_COUNT_FIELD_NAME);
        assertTrue(expectedKeys.containsAll(resultKeySet));
    }

    @Test
    public void testMapRow_failure() {
        IllegalArgumentException iae = assertThrows(IllegalArgumentException.class, ()-> this.rowMapper = new FieldRowMapper("not_a_language", searchConfig.getFields()));
        assertNotNull(iae);
    }
}
