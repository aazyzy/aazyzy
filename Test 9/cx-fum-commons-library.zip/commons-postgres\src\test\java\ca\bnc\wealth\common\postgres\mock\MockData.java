package ca.bnc.wealth.common.postgres.mock;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder(toBuilder = true)
public class MockData {

    private String id;

    private String firstName;

    private String lastName;
}
