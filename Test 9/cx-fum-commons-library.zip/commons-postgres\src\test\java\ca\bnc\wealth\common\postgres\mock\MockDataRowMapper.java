package ca.bnc.wealth.common.postgres.mock;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class MockDataRowMapper implements RowMapper<MockData> {

  @Override
  public MockData mapRow(ResultSet rs, int rowNum) throws SQLException {
    return new MockData.MockDataBuilder()
            .firstName("firstName")
            .lastName("lastName")
            .id("id")
            .build();
  }
}
