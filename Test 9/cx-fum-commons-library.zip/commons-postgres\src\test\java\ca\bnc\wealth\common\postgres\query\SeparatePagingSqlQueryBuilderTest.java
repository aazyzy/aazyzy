package ca.bnc.wealth.common.postgres.query;

import ca.bnc.wealth.common.core.feign.UserConfigApiClient;
import ca.bnc.wealth.common.search.model.*;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class SeparatePagingSqlQueryBuilderTest {
    private SqlQueryBuilder queryBuilder;
    private ObjectMapper objectMapper;

    @Mock
    private UserConfigApiClient userConfigApiClient;

    private static final String SEPARATE_PAGING_CONFIGURABLE_SEARCH_CONFIG_JSON = "separate-paging-configurable-search-config.json";

    @BeforeEach
    void setup() throws IOException {
        objectMapper = JsonMapper.builderWithJackson2Defaults().build();
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, createMockSeparatePagingQuerySearchConfig());
    }

    private SearchConfig createMockSeparatePagingQuerySearchConfig() throws IOException {
        ClassPathResource requestResource = new ClassPathResource(SEPARATE_PAGING_CONFIGURABLE_SEARCH_CONFIG_JSON, this.getClass().getClassLoader());
        return objectMapper.readValue(requestResource.getFile(), SearchConfig.class);
    }

    @Test
    void testUsesSeparatePagingQueryFlag() throws IOException {
        var searchConfig = createMockSeparatePagingQuerySearchConfig();
        assertTrue(searchConfig.getSeparatePagingQuery());
    }

    @Test
    void testBuildCountOnlyQuery_withFilters() {
        SearchRequest request = new SearchRequest();
        request.setFilters(List.of(new Filter().field("country").operator(ComparisonOperator.EQUALS).values(List.of("CAN"))));
        SqlQuery result = queryBuilder.buildCountOnlyQuery(request, "EN");

        assertNotNull(result);
        String expectedSql = """
                SELECT COUNT(*) as meta_total_row_count FROM instruments
                    WHERE (country = :f0v0)""";
        assertEquals(expectedSql, result.getSql());
    }

    @Test
    void testBuildCountOnlyQuery_noFilters() {
        SearchRequest request = new SearchRequest();
        SqlQuery result = queryBuilder.buildCountOnlyQuery(request, "EN");

        assertNotNull(result);
        String expectedSql = """
                SELECT COUNT(*) as meta_total_row_count FROM instruments
                """;
        assertEquals(expectedSql, result.getSql());
    }

    @Test
    void testBuildFindAllQuery_MinimalParams() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/findAllMinimal.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/findAllMinimalWithoutCount.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
        assertEquals(1, query.getParameterSource().getValues().size());
        assertEquals("US", query.getParameterSource().getValue("f0v0"));
    }

}
