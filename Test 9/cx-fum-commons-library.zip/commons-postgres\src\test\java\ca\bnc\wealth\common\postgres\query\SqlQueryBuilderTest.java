package ca.bnc.wealth.common.postgres.query;

import ca.bnc.wealth.common.core.feign.UserConfigApiClient;
import ca.bnc.wealth.common.postgres.exception.EmptyRRCodeRangeException;
import ca.bnc.wealth.common.search.model.Filter;
import ca.bnc.wealth.common.search.model.SearchConfig;
import ca.bnc.wealth.common.search.model.Sort;
import ca.bnc.wealth.common.search.model.ComparisonOperator;
import ca.bnc.wealth.common.search.model.SearchRequest;

import ca.bnc.wealth.common.search.model.SearchTextType;
import ca.bnc.wealth.common.search.model.SortOrder;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import feign.FeignException;
import feign.Request;
import feign.RetryableException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SqlQueryBuilderTest {
    private SqlQueryBuilder queryBuilder;
    private ObjectMapper objectMapper;

    @Mock
    private UserConfigApiClient userConfigApiClient;

    private static final String CONFIGURABLE_SEARCH_CONFIG_JSON = "configurable-search-config.json";
    private static final String ALL_TYPES_CONFIGURABLE_SEARCH_CONFIG_JSON = "all-types-configurable-search-config.json";

    @BeforeEach
    void setup() throws IOException {
        objectMapper = JsonMapper.builderWithJackson2Defaults().build();
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, createMockSearchConfig());
    }

    @Test
    void testValidateSearchConfig_Null() {
        assertThrows(IllegalArgumentException.class, () -> new SqlQueryBuilder(userConfigApiClient, null));
    }

    @Test
    void testValidateSearchConfig_NullFields() {
        SearchConfig searchConfig = new SearchConfig();
        assertThrows(IllegalArgumentException.class, () -> new SqlQueryBuilder(userConfigApiClient, searchConfig));
    }

    @Test
    void testValidateSearchConfig_EmptyFields() {
        SearchConfig searchConfig = new SearchConfig().fields(Collections.emptyList());
        assertThrows(IllegalArgumentException.class, () -> new SqlQueryBuilder(userConfigApiClient, searchConfig));
    }

    @Test
    void testValidateSearchConfig_NullSchema() throws IOException {
        SearchConfig searchConfig = createMockSearchConfig();
        searchConfig.setSchema(null);
        assertThrows(IllegalArgumentException.class, () -> new SqlQueryBuilder(userConfigApiClient, searchConfig));
    }

    @Test
    void testValidateSearchConfig_MissingSchema() throws IOException {
        SearchConfig searchConfig = createMockSearchConfig();
        searchConfig.getSchema().setEn(null);
        assertThrows(IllegalArgumentException.class, () -> new SqlQueryBuilder(userConfigApiClient, searchConfig));
    }

    @Test
    void testValidateSearchConfig_NullPagingInfo() throws IOException {
        SearchConfig searchConfig = createMockSearchConfig();
        searchConfig.setPaging(null);
        assertThrows(IllegalArgumentException.class, () -> new SqlQueryBuilder(userConfigApiClient, searchConfig));
    }

    @Test
    void testValidateSearchConfig_MissingPageSize() throws IOException {
        SearchConfig searchConfig = createMockSearchConfig();
        searchConfig.getPaging().setPageSize(null);
        assertThrows(IllegalArgumentException.class, () -> new SqlQueryBuilder(userConfigApiClient, searchConfig));
    }


    //Template testing
    @Test
    void testBuildTemplate_withFullAndSplit_English(){
        SqlQueryTemplate template = this.queryBuilder.buildTemplate("EN");
        assertNotNull(template);
        assertEquals("""
                WITH filtered_table AS (
                SELECT symbol, country, description_en FROM instruments
                ACCESS_CONTROL_AND_FILTERS_PLACEHOLDER
                )
                SELECT RESULT_SET_PLACEHOLDER FROM (
                SELECT symbol, country, description_en, 1 AS qorder FROM filtered_table
                    WHERE (symbol = :searchText OR description_en = :searchText)
                UNION ALL
                SELECT symbol, country, description_en, 2 AS qorder FROM filtered_table
                    WHERE (symbol LIKE :likeSearchText AND NOT symbol = :searchText)
                    OR (description_en LIKE :likeSearchText AND NOT description_en = :searchText)
                    AND symbol IS DISTINCT FROM :searchText
                    AND description_en IS DISTINCT FROM :searchText
                UNION ALL
                SELECT symbol, country, description_en, 3 AS qorder FROM filtered_table
                    WHERE (
                    TOKEN_CONDITIONS_PLACEHOLDER
                    )
                    AND symbol IS DISTINCT FROM :searchText
                    AND description_en IS DISTINCT FROM :searchText
                    AND (symbol NOT LIKE :likeSearchText OR symbol IS NULL)
                    AND (description_en NOT LIKE :likeSearchText OR description_en IS NULL)
                ) AS results
                ORDER BY qorderADDITIONAL_SORT_PLACEHOLDER
                LIMIT_PLACEHOLDER OFFSET_PLACEHOLDER;""", template.getSql());
    }

    @Test
    void testBuildTemplate_withFullAndSplit_French(){
        SqlQueryTemplate template = this.queryBuilder.buildTemplate("FR");
        assertNotNull(template);
        assertEquals("""
                WITH filtered_table AS (
                SELECT symbol_fr, country_fr, description_fr FROM instruments_fr
                ACCESS_CONTROL_AND_FILTERS_PLACEHOLDER
                )
                SELECT RESULT_SET_PLACEHOLDER FROM (
                SELECT symbol_fr, country_fr, description_fr, 1 AS qorder FROM filtered_table
                    WHERE (symbol_fr = :searchText OR description_fr = :searchText)
                UNION ALL
                SELECT symbol_fr, country_fr, description_fr, 2 AS qorder FROM filtered_table
                    WHERE (symbol_fr LIKE :likeSearchText AND NOT symbol_fr = :searchText)
                    OR (description_fr LIKE :likeSearchText AND NOT description_fr = :searchText)
                    AND symbol_fr IS DISTINCT FROM :searchText
                    AND description_fr IS DISTINCT FROM :searchText
                UNION ALL
                SELECT symbol_fr, country_fr, description_fr, 3 AS qorder FROM filtered_table
                    WHERE (
                    TOKEN_CONDITIONS_PLACEHOLDER
                    )
                    AND symbol_fr IS DISTINCT FROM :searchText
                    AND description_fr IS DISTINCT FROM :searchText
                    AND (symbol_fr NOT LIKE :likeSearchText OR symbol_fr IS NULL)
                    AND (description_fr NOT LIKE :likeSearchText OR description_fr IS NULL)
                ) AS results
                ORDER BY qorderADDITIONAL_SORT_PLACEHOLDER
                LIMIT_PLACEHOLDER OFFSET_PLACEHOLDER;""", template.getSql());
    }

    @Test
    void testBuildTemplate_withOnlyFull_English() throws IOException {
        SearchConfig modifiedSearchConfig = createMockSearchConfig();
        modifiedSearchConfig.getFields().get(1).getSearchTextType().remove(SearchTextType.SPLIT);
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, modifiedSearchConfig);

        SqlQueryTemplate template = this.queryBuilder.buildTemplate("EN");
        assertNotNull(template);
        assertEquals("""
                WITH filtered_table AS (
                SELECT symbol, country, description_en FROM instruments
                ACCESS_CONTROL_AND_FILTERS_PLACEHOLDER
                )
                SELECT RESULT_SET_PLACEHOLDER FROM (
                SELECT symbol, country, description_en, 1 AS qorder FROM filtered_table
                    WHERE (symbol = :searchText OR description_en = :searchText)
                UNION ALL
                SELECT symbol, country, description_en, 2 AS qorder FROM filtered_table
                    WHERE (symbol LIKE :likeSearchText AND NOT symbol = :searchText)
                    OR (description_en LIKE :likeSearchText AND NOT description_en = :searchText)
                    AND symbol IS DISTINCT FROM :searchText
                    AND description_en IS DISTINCT FROM :searchText
                ) AS results
                ORDER BY qorderADDITIONAL_SORT_PLACEHOLDER
                LIMIT_PLACEHOLDER OFFSET_PLACEHOLDER;""", template.getSql());
    }

    @Test
    void testBuildTemplate_withOnlySplit_English() throws IOException {
        SearchConfig modifiedSearchConfig = createMockSearchConfig();
        modifiedSearchConfig.getFields().get(0).getSearchTextType().remove(SearchTextType.FULL);
        modifiedSearchConfig.getFields().get(1).getSearchTextType().remove(SearchTextType.FULL);
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, modifiedSearchConfig);

        SqlQueryTemplate template = this.queryBuilder.buildTemplate("EN");
        assertNotNull(template);
        assertEquals("""
                WITH filtered_table AS (
                SELECT symbol, country, description_en FROM instruments
                ACCESS_CONTROL_AND_FILTERS_PLACEHOLDER
                )
                SELECT RESULT_SET_PLACEHOLDER FROM (
                SELECT symbol, country, description_en, 3 AS qorder FROM filtered_table
                    WHERE (
                    TOKEN_CONDITIONS_PLACEHOLDER
                    )
                   \s
                   \s
                ) AS results
                ORDER BY qorderADDITIONAL_SORT_PLACEHOLDER
                LIMIT_PLACEHOLDER OFFSET_PLACEHOLDER;""", template.getSql());
    }

    @Test
    void testBuildTemplate_noFieldsToSearch() throws IOException {
        SearchConfig modifiedSearchConfig = createMockSearchConfig();
        modifiedSearchConfig.getFields().get(0).getSearchTextType().remove(SearchTextType.FULL);
        modifiedSearchConfig.getFields().get(1).getSearchTextType().remove(SearchTextType.FULL);
        modifiedSearchConfig.getFields().get(1).getSearchTextType().remove(SearchTextType.SPLIT);

        assertThrows(IllegalArgumentException.class,
                () -> new SqlQueryBuilder(userConfigApiClient, modifiedSearchConfig));
    }

    // Inline-filters (opt-in) template testing
    @Test
    void testBuildTemplate_Inline_English() throws IOException {
        SqlQueryBuilder inlineBuilder = new SqlQueryBuilder(userConfigApiClient, createMockSearchConfig(), true);
        SqlQueryTemplate template = inlineBuilder.buildTemplate("EN");
        assertNotNull(template);
        assertEquals("""
                SELECT RESULT_SET_PLACEHOLDER FROM (
                SELECT symbol, country, description_en, 1 AS qorder FROM instruments
                    WHERE FILTER_CONDITIONS_PLACEHOLDER(symbol = :searchText OR description_en = :searchText)
                UNION ALL
                SELECT symbol, country, description_en, 2 AS qorder FROM instruments
                    WHERE FILTER_CONDITIONS_PLACEHOLDER((symbol LIKE :likeSearchText AND NOT symbol = :searchText)
                    OR (description_en LIKE :likeSearchText AND NOT description_en = :searchText)
                    AND symbol IS DISTINCT FROM :searchText
                    AND description_en IS DISTINCT FROM :searchText)
                UNION ALL
                SELECT symbol, country, description_en, 3 AS qorder FROM instruments
                    WHERE FILTER_CONDITIONS_PLACEHOLDER((
                    TOKEN_CONDITIONS_PLACEHOLDER
                    )
                    AND symbol IS DISTINCT FROM :searchText
                    AND description_en IS DISTINCT FROM :searchText
                    AND (symbol NOT LIKE :likeSearchText OR symbol IS NULL)
                    AND (description_en NOT LIKE :likeSearchText OR description_en IS NULL))
                ) AS results
                ORDER BY qorderADDITIONAL_SORT_PLACEHOLDER
                LIMIT_PLACEHOLDER OFFSET_PLACEHOLDER;""", template.getSql());
    }

    @Test
    void testBuildTemplate_Inline_French() throws IOException {
        SqlQueryBuilder inlineBuilder = new SqlQueryBuilder(userConfigApiClient, createMockSearchConfig(), true);
        SqlQueryTemplate template = inlineBuilder.buildTemplate("FR");
        assertNotNull(template);
        assertEquals("""
                SELECT RESULT_SET_PLACEHOLDER FROM (
                SELECT symbol_fr, country_fr, description_fr, 1 AS qorder FROM instruments_fr
                    WHERE FILTER_CONDITIONS_PLACEHOLDER(symbol_fr = :searchText OR description_fr = :searchText)
                UNION ALL
                SELECT symbol_fr, country_fr, description_fr, 2 AS qorder FROM instruments_fr
                    WHERE FILTER_CONDITIONS_PLACEHOLDER((symbol_fr LIKE :likeSearchText AND NOT symbol_fr = :searchText)
                    OR (description_fr LIKE :likeSearchText AND NOT description_fr = :searchText)
                    AND symbol_fr IS DISTINCT FROM :searchText
                    AND description_fr IS DISTINCT FROM :searchText)
                UNION ALL
                SELECT symbol_fr, country_fr, description_fr, 3 AS qorder FROM instruments_fr
                    WHERE FILTER_CONDITIONS_PLACEHOLDER((
                    TOKEN_CONDITIONS_PLACEHOLDER
                    )
                    AND symbol_fr IS DISTINCT FROM :searchText
                    AND description_fr IS DISTINCT FROM :searchText
                    AND (symbol_fr NOT LIKE :likeSearchText OR symbol_fr IS NULL)
                    AND (description_fr NOT LIKE :likeSearchText OR description_fr IS NULL))
                ) AS results
                ORDER BY qorderADDITIONAL_SORT_PLACEHOLDER
                LIMIT_PLACEHOLDER OFFSET_PLACEHOLDER;""", template.getSql());
    }

    @Test
    void testBuildQuery_Inline_AllParams_English() throws IOException {
        SqlQueryBuilder inlineBuilder = new SqlQueryBuilder(userConfigApiClient, createMockSearchConfig(), true);
        ClassPathResource requestResource = new ClassPathResource("searchRequests/complexSearch.json",
                this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/inline/complexSearchEnglish.sql",
                this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n",
                SqlQueryBuilder.NEW_LINE);

        SqlQuery query = inlineBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
    }

    @Test
    void testBuildQuery_Inline_Minimal_French() throws IOException {
        SqlQueryBuilder inlineBuilder = new SqlQueryBuilder(userConfigApiClient, createMockSearchConfig(), true);
        ClassPathResource requestResource = new ClassPathResource("searchRequests/minimalSearch.json",
                this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/inline/minimalSearchFrench.sql",
                this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n",
                SqlQueryBuilder.NEW_LINE);

        SqlQuery query = inlineBuilder.buildQuery(searchRequest, "FR");

        assertEquals(expectedSql, query.getSql());
    }

    @Test
    void testNested_Inline_TwoParents_TwoNested_WithAccessControl() throws IOException {
        SqlQueryBuilder inlineBuilder = new SqlQueryBuilder(userConfigApiClient, createMockAllFieldsSearchConfig(),
                true);
        ClassPathResource requestResource = new ClassPathResource("searchRequests/twoFiltersTwoNested.json",
                this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource(
                "searchSql/inline/twoFiltersTwoNestedWithAccessControl.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n",
                SqlQueryBuilder.NEW_LINE);

        when(userConfigApiClient.getRRCodes()).thenReturn(
                List.of(
                        new RRCodeRange().fromRRCodeB10(0).toRRCodeB10(10),
                        new RRCodeRange().fromRRCodeB10(20).toRRCodeB10(30),
                        new RRCodeRange().fromRRCodeB10(40).toRRCodeB10(50)));

        SqlQuery query = inlineBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
    }

    //Full query building Testing
    @Test
    void testBuildQuery_All_Params_English() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/complexSearch.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/complexSearchEnglish.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n",  SqlQueryBuilder.NEW_LINE);

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
        assertEquals("Bank of Canada", query.getParameterSource().getValue("searchText"));
        assertEquals("%Bank of Canada%", query.getParameterSource().getValue("likeSearchText"));
        assertEquals("US", query.getParameterSource().getValue("f0v0"));
        assertEquals("NBC", query.getParameterSource().getValue("f1v0"));
        assertEquals("BNC", query.getParameterSource().getValue("f1v1"));
        assertEquals("NBC", query.getParameterSource().getValue("f2v0"));
        assertEquals("%Bank%", query.getParameterSource().getValue("splitTerm0"));
        assertEquals("%of%", query.getParameterSource().getValue("splitTerm1"));
        assertEquals("%Canada%", query.getParameterSource().getValue("splitTerm2"));
    }

    @Test
    void testBuildQuery_All_Params_French() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/complexSearch.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/complexSearchFrench.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "FR");

        assertEquals(expectedSql, query.getSql());
        assertEquals("Bank of Canada", query.getParameterSource().getValue("searchText"));
        assertEquals("%Bank of Canada%", query.getParameterSource().getValue("likeSearchText"));
        assertEquals("US", query.getParameterSource().getValue("f0v0"));
        assertEquals("NBC", query.getParameterSource().getValue("f1v0"));
        assertEquals("BNC", query.getParameterSource().getValue("f1v1"));
        assertEquals("NBC", query.getParameterSource().getValue("f2v0"));
        assertEquals("%Bank%", query.getParameterSource().getValue("splitTerm0"));
        assertEquals("%of%", query.getParameterSource().getValue("splitTerm1"));
        assertEquals("%Canada%", query.getParameterSource().getValue("splitTerm2"));
    }

    @Test
    void testBuildQuery_Minimal_Params_French() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/minimalSearch.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/minimalSearchFrench.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "FR");

        assertEquals(expectedSql, query.getSql());
        assertEquals("Bank of Canada", query.getParameterSource().getValue("searchText"));
        assertEquals("%Bank of Canada%", query.getParameterSource().getValue("likeSearchText"));
        assertEquals("%Bank%", query.getParameterSource().getValue("splitTerm0"));
        assertEquals("%of%", query.getParameterSource().getValue("splitTerm1"));
        assertEquals("%Canada%", query.getParameterSource().getValue("splitTerm2"));
    }

    @Test
    void testBuildQuery_Invalid_Language(){
        SearchRequest searchRequest = new SearchRequest();
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> queryBuilder.buildQuery(searchRequest, "ABC"));
        assertNotNull(exception);
    }

    @ParameterizedTest
    @ValueSource(ints = {0, -1})
    void testBuildQuery_PageNumberInvalid(Integer pageNumber) {
        SearchRequest searchRequest = new SearchRequest();
        searchRequest.setSearchText("Test");
        searchRequest.setPageNumber(pageNumber);
        IllegalArgumentException iae = assertThrows(IllegalArgumentException.class, () -> queryBuilder.buildQuery(searchRequest, "EN"));
        assertNotNull(iae);
    }

    @Test
    void testBuildQuery_Spec_Example_1() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/specExample1.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/specExample1.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
        assertEquals("Bank of Canada", query.getParameterSource().getValue("searchText"));
        assertEquals("%Bank of Canada%", query.getParameterSource().getValue("likeSearchText"));
        assertEquals("%Bank%", query.getParameterSource().getValue("splitTerm0"));
        assertEquals("%of%", query.getParameterSource().getValue("splitTerm1"));
        assertEquals("%Canada%", query.getParameterSource().getValue("splitTerm2"));
    }

    @Test
    void testBuildQuery_Spec_Example_2() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/specExample2.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/specExample2.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
        assertEquals("Bank of Canada", query.getParameterSource().getValue("searchText"));
        assertEquals("%Bank of Canada%", query.getParameterSource().getValue("likeSearchText"));
        assertEquals("%Bank%", query.getParameterSource().getValue("splitTerm0"));
        assertEquals("%of%", query.getParameterSource().getValue("splitTerm1"));
        assertEquals("%Canada%", query.getParameterSource().getValue("splitTerm2"));
        assertEquals("US", query.getParameterSource().getValue("f0v0"));
    }

    @Test
    void testBuildQuery_Illegal_ResultSet() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/specExample2.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        List<String> badResultSet = List.of("not_a_field");
        searchRequest.setResultSet(badResultSet);

        IllegalArgumentException iae = assertThrows(IllegalArgumentException.class, ()-> queryBuilder.buildQuery(searchRequest, "EN"));

        assertNotNull(iae);
    }

    @Test
    void testBuildQuery_Illegal_Sort() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/specExample2.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        Sort badSort = new Sort().field("not_a_field").order(SortOrder.DESC);
        searchRequest.getSorting().add(badSort);

        IllegalArgumentException iae = assertThrows(IllegalArgumentException.class, ()-> queryBuilder.buildQuery(searchRequest, "EN"));

        assertNotNull(iae);
    }

    @Test
    void testBuildQuery_Illegal_Filter() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/specExample2.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        Filter badFilter = new Filter();
        badFilter.setField("not_a_field");
        badFilter.setOperator(ComparisonOperator.EQUALS);
        badFilter.setValues((List.of("value")));

        searchRequest.getFilters().add(badFilter);

        IllegalArgumentException iae = assertThrows(IllegalArgumentException.class, ()-> queryBuilder.buildQuery(searchRequest, "EN"));

        assertNotNull(iae);
    }

    private SearchConfig createMockSearchConfig() throws IOException {
        ClassPathResource requestResource = new ClassPathResource(CONFIGURABLE_SEARCH_CONFIG_JSON, this.getClass().getClassLoader());
        return objectMapper.readValue(requestResource.getFile(), SearchConfig.class);
    }

    private SearchConfig createMockAllFieldsSearchConfig() throws IOException {
        ClassPathResource requestResource = new ClassPathResource(ALL_TYPES_CONFIGURABLE_SEARCH_CONFIG_JSON, this.getClass().getClassLoader());
        return objectMapper.readValue(requestResource.getFile(), SearchConfig.class);
    }


    @Test
    void testNested_SingleParent_SingleNested() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/singleFilterWithNested.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/singleFilterWithNested.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
        assertEquals("Bank of Canada", query.getParameterSource().getValue("searchText"));
        assertEquals("%Bank of Canada%", query.getParameterSource().getValue("likeSearchText"));
        assertEquals("%Bank%", query.getParameterSource().getValue("splitTerm0"));
        assertEquals("%of%", query.getParameterSource().getValue("splitTerm1"));
        assertEquals("%Canada%", query.getParameterSource().getValue("splitTerm2"));
        assertEquals("US", query.getParameterSource().getValue("f0v0"));
        assertEquals("BAC", query.getParameterSource().getValue("n0v0"));
    }

    @Test
    void testNested_TwoParents_OnlyOneNested() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/twoFiltersWithOneNested.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/twoFiltersWithOneNested.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
        assertEquals("Bank of Canada", query.getParameterSource().getValue("searchText"));
        assertEquals("%Bank of Canada%", query.getParameterSource().getValue("likeSearchText"));
        assertEquals("%Bank%", query.getParameterSource().getValue("splitTerm0"));
        assertEquals("%of%", query.getParameterSource().getValue("splitTerm1"));
        assertEquals("%Canada%", query.getParameterSource().getValue("splitTerm2"));
        assertEquals("US", query.getParameterSource().getValue("f0v0"));
        assertEquals("BAC", query.getParameterSource().getValue("n0v0"));
        assertEquals("NBC", query.getParameterSource().getValue("f1v0"));
    }

    @Test
    void testNested_TwoParents_TwoNested() throws IOException {
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, createMockAllFieldsSearchConfig());

        ClassPathResource requestResource = new ClassPathResource("searchRequests/twoFiltersTwoNested.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/twoFiltersTwoNested.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        when(userConfigApiClient.getRRCodes()).thenReturn(List.of(new RRCodeRange().fromRRCodeB10(0).toRRCodeB10(9999)));

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
        assertEquals("Bank of Canada", query.getParameterSource().getValue("searchText"));
        assertEquals("%Bank of Canada%", query.getParameterSource().getValue("likeSearchText"));
        assertEquals("%Bank%", query.getParameterSource().getValue("splitTerm0"));
        assertEquals("%of%", query.getParameterSource().getValue("splitTerm1"));
        assertEquals("%Canada%", query.getParameterSource().getValue("splitTerm2"));
        assertEquals("US", query.getParameterSource().getValue("f0v0"));
        assertEquals("BAC", query.getParameterSource().getValue("n0v0"));
        assertEquals("NBC", query.getParameterSource().getValue("f1v0"));
        assertEquals(100, query.getParameterSource().getValue("n1v0"));
        assertEquals(200, query.getParameterSource().getValue("n1v1"));
    }

    @Test
    void testNested_TwoParents_TwoNested_WithAccessControl() throws IOException {
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, createMockAllFieldsSearchConfig());

        ClassPathResource requestResource = new ClassPathResource("searchRequests/twoFiltersTwoNested.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/twoFiltersTwoNestedWithAccessControl.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        when(userConfigApiClient.getRRCodes()).thenReturn(
                List.of(
                        new RRCodeRange().fromRRCodeB10(0).toRRCodeB10(10),
                        new RRCodeRange().fromRRCodeB10(20).toRRCodeB10(30),
                        new RRCodeRange().fromRRCodeB10(40).toRRCodeB10(50)
                )
        );

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
        assertEquals("Bank of Canada", query.getParameterSource().getValue("searchText"));
        assertEquals("%Bank of Canada%", query.getParameterSource().getValue("likeSearchText"));
        assertEquals("%Bank%", query.getParameterSource().getValue("splitTerm0"));
        assertEquals("%of%", query.getParameterSource().getValue("splitTerm1"));
        assertEquals("%Canada%", query.getParameterSource().getValue("splitTerm2"));
        assertEquals("US", query.getParameterSource().getValue("f0v0"));
        assertEquals("BAC", query.getParameterSource().getValue("n0v0"));
        assertEquals("NBC", query.getParameterSource().getValue("f1v0"));
        assertEquals(100, query.getParameterSource().getValue("n1v0"));
        assertEquals(200, query.getParameterSource().getValue("n1v1"));
        assertEquals(0, query.getParameterSource().getValue("f2v0"));
        assertEquals(10, query.getParameterSource().getValue("f2v1"));
        assertEquals(20, query.getParameterSource().getValue("n2v0"));
        assertEquals(30, query.getParameterSource().getValue("n2v1"));
        assertEquals(40, query.getParameterSource().getValue("n3v0"));
        assertEquals(50, query.getParameterSource().getValue("n3v1"));
    }

    @Test
    void testNested_SingleParent_DoublyNested() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/singleFilterDoublyNested.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/singleFilterDoublyNested.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
        assertEquals("Bank of Canada", query.getParameterSource().getValue("searchText"));
        assertEquals("%Bank of Canada%", query.getParameterSource().getValue("likeSearchText"));
        assertEquals("%Bank%", query.getParameterSource().getValue("splitTerm0"));
        assertEquals("%of%", query.getParameterSource().getValue("splitTerm1"));
        assertEquals("%Canada%", query.getParameterSource().getValue("splitTerm2"));
        assertEquals("US", query.getParameterSource().getValue("f0v0"));
        assertEquals("BAC", query.getParameterSource().getValue("n0v0"));
        assertEquals("NBIN", query.getParameterSource().getValue("n1v0"));
    }

    @Test
    void testNested_SingleParents_ThreeNested() throws IOException {
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, createMockAllFieldsSearchConfig());

        ClassPathResource requestResource = new ClassPathResource("searchRequests/singleFilterWithThreeNested.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/singleFilterWithThreeNested.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        when(userConfigApiClient.getRRCodes()).thenReturn(List.of(new RRCodeRange().fromRRCodeB10(0).toRRCodeB10(9999)));

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
        assertEquals("Bank of Canada", query.getParameterSource().getValue("searchText"));
        assertEquals("%Bank of Canada%", query.getParameterSource().getValue("likeSearchText"));
        assertEquals("%Bank%", query.getParameterSource().getValue("splitTerm0"));
        assertEquals("%of%", query.getParameterSource().getValue("splitTerm1"));
        assertEquals("%Canada%", query.getParameterSource().getValue("splitTerm2"));
        assertEquals(100, query.getParameterSource().getValue("f0v0"));
        assertEquals(200, query.getParameterSource().getValue("f0v1"));
        assertEquals(300, query.getParameterSource().getValue("n0v0"));
        assertEquals(400, query.getParameterSource().getValue("n0v1"));
        assertEquals(500, query.getParameterSource().getValue("n1v0"));
        assertEquals(600, query.getParameterSource().getValue("n1v1"));
        assertEquals(700, query.getParameterSource().getValue("n2v0"));
        assertEquals(800, query.getParameterSource().getValue("n2v1"));
    }

    @Test
    void testNested_ThreeParents_OneDoublyNested() throws IOException {
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, createMockAllFieldsSearchConfig());

        ClassPathResource requestResource = new ClassPathResource("searchRequests/threeFiltersWithOneDoublyNested.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/threeFiltersWithOneDoublyNested.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        when(userConfigApiClient.getRRCodes()).thenReturn(List.of(new RRCodeRange().fromRRCodeB10(0).toRRCodeB10(9999)));

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
        assertEquals("Bank of Canada", query.getParameterSource().getValue("searchText"));
        assertEquals("%Bank of Canada%", query.getParameterSource().getValue("likeSearchText"));
        assertEquals("%Bank%", query.getParameterSource().getValue("splitTerm0"));
        assertEquals("%of%", query.getParameterSource().getValue("splitTerm1"));
        assertEquals("%Canada%", query.getParameterSource().getValue("splitTerm2"));
        assertEquals(100, query.getParameterSource().getValue("f0v0"));
        assertEquals(200, query.getParameterSource().getValue("f0v1"));
        assertEquals(300, query.getParameterSource().getValue("n0v0"));
        assertEquals(400, query.getParameterSource().getValue("n0v1"));
        assertEquals("NBC", query.getParameterSource().getValue("n1v0"));
        assertEquals("BNC", query.getParameterSource().getValue("n1v1"));
        assertEquals(500, query.getParameterSource().getValue("n2v0"));
        assertEquals(600, query.getParameterSource().getValue("n2v1"));
        assertEquals(700, query.getParameterSource().getValue("n3v0"));
        assertEquals(800, query.getParameterSource().getValue("n3v1"));
    }

    @Test
    void testAllStringOperators() throws IOException {
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, createMockAllFieldsSearchConfig());

        ClassPathResource requestResource = new ClassPathResource("searchRequests/stringOperators.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/stringOperators.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        when(userConfigApiClient.getRRCodes()).thenReturn(List.of(new RRCodeRange().fromRRCodeB10(0).toRRCodeB10(9999)));

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
    }

    @Test
    void testAllIntegerOperators() throws IOException {
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, createMockAllFieldsSearchConfig());

        ClassPathResource requestResource = new ClassPathResource("searchRequests/integerOperators.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/integerOperators.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        when(userConfigApiClient.getRRCodes()).thenReturn(List.of(new RRCodeRange().fromRRCodeB10(0).toRRCodeB10(9999)));

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
    }

    @Test
    void testAllDateOperators() throws IOException {
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, createMockAllFieldsSearchConfig());

        ClassPathResource requestResource = new ClassPathResource("searchRequests/dateOperators.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/dateOperators.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        when(userConfigApiClient.getRRCodes()).thenReturn(List.of(new RRCodeRange().fromRRCodeB10(0).toRRCodeB10(9999)));

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
    }

    @Test
    void testAllTimeStampOperators() throws IOException {
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, createMockAllFieldsSearchConfig());

        ClassPathResource requestResource = new ClassPathResource("searchRequests/timestampOperators.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/timestampOperators.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        when(userConfigApiClient.getRRCodes()).thenReturn(List.of(new RRCodeRange().fromRRCodeB10(0).toRRCodeB10(9999)));

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
    }

    @Test
    void testAllBooleanOperators() throws IOException {
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, createMockAllFieldsSearchConfig());

        ClassPathResource requestResource = new ClassPathResource("searchRequests/booleanOperators.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/booleanOperators.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        when(userConfigApiClient.getRRCodes()).thenReturn(List.of(new RRCodeRange().fromRRCodeB10(0).toRRCodeB10(9999)));

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
    }

    @Test
    void testBuildFindAllQuery_MinimalParams() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/findAllMinimal.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/findAllMinimal.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
        assertEquals(1, query.getParameterSource().getValues().size());
        assertEquals("US", query.getParameterSource().getValue("f0v0"));
    }

    @Test
    void testBuildFindAllQuery_UsesRequestPageSize() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/requestPageSizeNoTextSearch.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/requestPageSizeNoTextSearch.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
    }

    @Test
    void testSearchTextQuery_UsesRequestPageSize() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/requestPageSizeWithTextSearch.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/requestPageSizeWithTextSearch.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "FR");

        assertEquals(expectedSql, query.getSql());
    }

    @Test
    void testBuildFindAllQuery_MinimalParams_French() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/findAllMinimal.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/findAllMinimalFrench.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "FR");

        assertEquals(expectedSql, query.getSql());
        assertEquals(1, query.getParameterSource().getValues().size());
        assertEquals("US", query.getParameterSource().getValue("f0v0"));
    }

    @Test
    void testBuildFindAllQuery_Complex() throws IOException {
        ClassPathResource requestResource = new ClassPathResource("searchRequests/findAllComplex.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);
        ClassPathResource sqlResource = new ClassPathResource("searchSql/findAllComplex.sql", this.getClass().getClassLoader());
        String expectedSql = Files.readString(Path.of(sqlResource.getFile().getPath())).replace("\r\n", SqlQueryBuilder.NEW_LINE);

        SqlQuery query = queryBuilder.buildQuery(searchRequest, "EN");

        assertEquals(expectedSql, query.getSql());
        assertEquals(4, query.getParameterSource().getValues().size());
        assertEquals("US", query.getParameterSource().getValue("f0v0"));
        assertEquals("NBC", query.getParameterSource().getValue("f1v0"));
        assertEquals("BNC", query.getParameterSource().getValue("f1v1"));
        assertEquals("NBC", query.getParameterSource().getValue("f2v0"));
    }

    @Test
    void testBuildFindAllQuery_NoParams_ThrowsException() {
        SearchRequest searchRequest = new SearchRequest();
        assertThrows(IllegalArgumentException.class, () -> queryBuilder.buildQuery(searchRequest, "EN"));
    }

    @Test
    void testUserConfigApi_Unavailable() throws IOException {
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, createMockAllFieldsSearchConfig());

        ClassPathResource requestResource = new ClassPathResource("searchRequests/booleanOperators.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);

        Request feignRequest = Request.create(Request.HttpMethod.GET, "", Collections.emptyMap(), null, null, null);
        when(userConfigApiClient.getRRCodes()).thenThrow(new RetryableException(503, "", (Request.HttpMethod) null, (Throwable) null, (Long) null, feignRequest));

        assertThrows(RetryableException.class, () -> queryBuilder.buildQuery(searchRequest, "EN"));
    }

    @Test
    void testUserConfigApi_GeneralError() throws IOException {
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, createMockAllFieldsSearchConfig());

        ClassPathResource requestResource = new ClassPathResource("searchRequests/booleanOperators.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);

        Request feignRequest = Request.create(Request.HttpMethod.GET, "", Collections.emptyMap(), null, null, null);
        when(userConfigApiClient.getRRCodes()).thenThrow(new FeignException.FeignServerException(500, "", feignRequest, null, Collections.emptyMap()));

        assertThrows(FeignException.class, () -> queryBuilder.buildQuery(searchRequest, "EN"));
    }

    @Test
    void testEmptyRRCodes_throwsException() throws IOException {
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, createMockAllFieldsSearchConfig());

        ClassPathResource requestResource = new ClassPathResource("searchRequests/booleanOperators.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);

        when(userConfigApiClient.getRRCodes()).thenReturn(Collections.emptyList());

        assertThrows(EmptyRRCodeRangeException.class, () -> queryBuilder.buildQuery(searchRequest, "EN"));
    }

    @Test
    void testNullRRCodes_throwsException() throws IOException {
        this.queryBuilder = new SqlQueryBuilder(userConfigApiClient, createMockAllFieldsSearchConfig());

        ClassPathResource requestResource = new ClassPathResource("searchRequests/booleanOperators.json", this.getClass().getClassLoader());
        SearchRequest searchRequest = objectMapper.readValue(requestResource.getFile(), SearchRequest.class);

        when(userConfigApiClient.getRRCodes()).thenReturn(null);

        assertThrows(EmptyRRCodeRangeException.class, () -> queryBuilder.buildQuery(searchRequest, "EN"));
    }


}
