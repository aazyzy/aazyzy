package ca.bnc.wealth.common.postgres.service;

import ca.bnc.wealth.common.core.feign.UserConfigApiClient;
import ca.bnc.wealth.common.postgres.dao.FieldRowMapper;
import ca.bnc.wealth.common.postgres.exception.EmptyRRCodeRangeException;
import ca.bnc.wealth.common.postgres.query.SqlQueryBuilder;
import ca.bnc.wealth.common.search.model.SearchConfig;
import ca.bnc.wealth.common.search.model.SearchRequest;
import ca.bnc.wealth.common.search.model.SearchResponse;
import ca.bnc.wealth.common.postgres.dao.SqlConfigurableSearchDao;
import tools.jackson.databind.json.JsonMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SqlConfigurableSearchServiceTest {
    private SqlConfigurableSearchService service;
    private final int PAGE_SIZE = 30;

    @Mock
    private SqlConfigurableSearchDao searchDao;

    @Mock
    private UserConfigApiClient userConfigApiClient;


    @BeforeEach
    void setup() {
        service = new SqlConfigurableSearchService(searchDao, JsonMapper.builderWithJackson2Defaults().build(), new DefaultResourceLoader(), userConfigApiClient);
        ReflectionTestUtils.setField(service, "configPaths", mockConfigPaths());
        ReflectionTestUtils.invokeMethod(service, "init");
    }

    @Test
    void testSearch_Success_ResultsSizeLessThanPageSize(){
        int resultSetSize = PAGE_SIZE - 1;
        SearchRequest request = new SearchRequest();
        request.setSearchText("NBC");
        request.setPageNumber(1);
        when(searchDao.search(any(), any())).thenReturn(createMockResultSet(resultSetSize, 0));

        SearchResponse response = service.search(request, "EN", "MutualFund");

        assertNotNull(response);
        assertEquals(false, response.getPaging().getNextPage());
        assertEquals(1, response.getPaging().getPageNumber());
        assertEquals(resultSetSize, response.getData().size());
    }

    @Test
    void testSearch_Success_ResultsSizeEqualsPageSize(){
        int resultSetSize = PAGE_SIZE;
        SearchRequest request = new SearchRequest();
        request.setSearchText("NBC");
        request.setPageNumber(1);
        when(searchDao.search(any(), any())).thenReturn(createMockResultSet(resultSetSize, 0));

        SearchResponse response = service.search(request, "EN", "MutualFund");

        assertNotNull(response);
        assertEquals(false, response.getPaging().getNextPage());
        assertEquals(1, response.getPaging().getPageNumber());
        assertEquals(resultSetSize, response.getData().size());
    }

    @Test
    void testSearch_Success_ResultsSizeGreaterThanPageSize(){
        SearchRequest request = new SearchRequest();
        request.setSearchText("NBC");
        request.setPageNumber(2);
        when(searchDao.search(any(), any())).thenReturn(createMockResultSet(PAGE_SIZE, PAGE_SIZE*3));

        SearchResponse response = service.search(request, "EN", "MutualFund");

        assertNotNull(response);
        assertTrue(response.getPaging().getNextPage());
        assertEquals(2, response.getPaging().getPageNumber());
        assertEquals(PAGE_SIZE, response.getData().size());
    }

    @Test
    void testSearch_Success_Multiple_SearchConfigs(){
        SearchRequest request = new SearchRequest();
        request.setSearchText("NBC");
        request.setPageNumber(2);

        SearchRequest requestEquity = new SearchRequest();
        requestEquity.setSearchText("CNTA");
        requestEquity.setPageNumber(3);

        when(searchDao.search(any(), any())).thenReturn(createMockResultSet(PAGE_SIZE, 50))
                .thenReturn(createMockResultSetEquity(PAGE_SIZE, 110));

        SearchResponse response = service.search(request, "EN", "MutualFund");
        SearchResponse responseEquity = service.search(requestEquity, "EN", "Equity");

        assertNotNull(response);
        assertEquals(false, response.getPaging().getNextPage());
        assertEquals(2, response.getPaging().getPageNumber());
        assertEquals(PAGE_SIZE, response.getData().size());

        assertNotNull(responseEquity);
        assertEquals(true, responseEquity.getPaging().getNextPage());
        assertEquals(3, responseEquity.getPaging().getPageNumber());
        assertEquals(PAGE_SIZE, responseEquity.getData().size());
    }

    @Test
    void testSearch_EmptyRRCodeRangeException(){
        SqlQueryBuilder mockQueryBuilder = mock(SqlQueryBuilder.class);
        when(mockQueryBuilder.getSearchConfig()).thenReturn(new SearchConfig().separatePagingQuery(false));
        when(mockQueryBuilder.buildQuery(any(), any())).thenThrow(new EmptyRRCodeRangeException());

        Map<String, SqlQueryBuilder> queryBuilderMap = (Map<String, SqlQueryBuilder>) ReflectionTestUtils.getField(service, "queryBuilders");
        if(queryBuilderMap != null) {
            queryBuilderMap.clear();
            queryBuilderMap.put("MutualFund", mockQueryBuilder);
        }

        SearchRequest request = new SearchRequest();
        request.setSearchText("NBC");
        request.setPageNumber(2);

        SearchResponse response = service.search(request, "EN", "MutualFund");

        assertEquals(1, response.getPaging().getPageNumber());
        assertEquals(1, response.getPaging().getTotalPages());
        assertFalse(response.getPaging().getNextPage());
        assertTrue(response.getData().isEmpty());
    }

    @Test
    void testSearch_DataAccessException(){
        SearchRequest request = new SearchRequest();
        request.setSearchText("NBC");
        request.setPageNumber(2);
        when(searchDao.search(any(), any())).thenThrow(new EmptyResultDataAccessException(PAGE_SIZE));

        DataAccessException exception = assertThrows(DataAccessException.class, () -> service.search(request, "EN", "MutualFund"));

        assertNotNull(exception);
    }

    @Test
    void testSearch_RuntimeException(){
        SearchRequest request = new SearchRequest();
        request.setSearchText("NBC");
        request.setPageNumber(2);
        when(searchDao.search(any(), any())).thenThrow(new RuntimeException());

        Exception exception = assertThrows(Exception.class, () -> service.search(request, "EN", "MutualFund"));

        assertNotNull(exception);
    }

    private List<Map<String, Object>> createMockResultSet(int size, int totalResultsSize) {
        List<Map<String, Object>> results = new ArrayList<>();
        for(int i=0; i<size; i++){
            Map<String, Object> data = new HashMap<>();
            data.put("symbol", "NBC");
            data.put("country", "CAN");
            data.put("description", "National Bank of Canada");
            data.put("market_price", 50);
            data.put("meta_total_row_count", totalResultsSize);
            results.add(data);
        }
        return results;
    }

    private List<Map<String, Object>> createMockResultSetEquity(int size, int totalResultsSize) {
        List<Map<String, Object>> results = new ArrayList<>();
        for(int i=0; i<size; i++){
            Map<String, Object> data = new HashMap<>();
            data.put("order_id", "CEQ00000000"+i);
            data.put("advisor_code", "CNTA");
            data.put("order_state", "Draft");
            data.put("meta_total_row_count", totalResultsSize);
            results.add(data);
        }
        return results;
    }

    private Map<String, String> mockConfigPaths() {
        Map<String, String> configPaths = new HashMap<>();
        configPaths.put("MutualFund", "configurable-search-config.json");
        configPaths.put("Equity", "configurable-search-config-equity.json");
        return configPaths;
    }

    @Test
    void testAddTotalRowCountFromSeparateQuery(){
        when(searchDao.search(any(), any())).thenReturn(List.of(Map.of("meta_total_row_count", 100)));

        List<Map<String, Object>> results = new ArrayList<>();
        HashMap<String, Object> row = new HashMap<>();
        row.put("country", "CAN");
        results.add(row);

        SqlQueryBuilder sqlQueryBuilder = mock(SqlQueryBuilder.class);
        FieldRowMapper fieldRowMapper = mock(FieldRowMapper.class);
        service.addTotalRowCountFromSeparateQuery(sqlQueryBuilder, new SearchRequest(), "EN", fieldRowMapper, results);

        assertEquals(100, results.get(0).get("meta_total_row_count"));
    }

    @Test
    void testAddTotalRowCountFromSeparateQuery_noResults(){
        when(searchDao.search(any(), any())).thenReturn(List.of(Map.of("meta_total_row_count", 100)));

        List<Map<String, Object>> results = new ArrayList<>();

        SqlQueryBuilder sqlQueryBuilder = mock(SqlQueryBuilder.class);
        FieldRowMapper fieldRowMapper = mock(FieldRowMapper.class);
        assertDoesNotThrow(() -> service.addTotalRowCountFromSeparateQuery(sqlQueryBuilder, new SearchRequest(), "EN", fieldRowMapper, results));
    }

    @Test
    void testAddTotalRowCountFromSeparateQuery_errorCountQuery(){
        when(searchDao.search(any(), any())).thenReturn(Collections.emptyList());

        List<Map<String, Object>> results = new ArrayList<>();
        HashMap<String, Object> row = new HashMap<>();
        row.put("country", "CAN");
        results.add(row);

        SqlQueryBuilder sqlQueryBuilder = mock(SqlQueryBuilder.class);
        FieldRowMapper fieldRowMapper = mock(FieldRowMapper.class);

        assertThrows(DataAccessException.class, () -> service.addTotalRowCountFromSeparateQuery(sqlQueryBuilder, new SearchRequest(), "EN", fieldRowMapper, results));

    }
}
