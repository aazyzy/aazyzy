package ca.bnc.wealth.common.postgres.utils;

import ca.bnc.wealth.common.postgres.mock.MockData;
import ca.bnc.wealth.common.postgres.mock.MockDataRowMapper;
import ca.bnc.wealth.common.search.model.PagingConfig;
import ca.bnc.wealth.common.search.model.SearchConfig;
import ca.bnc.wealth.common.search.model.SearchRequest;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.runner.RunWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
@ExtendWith(MockitoExtension.class)
public class QueryUtilsTests {

  @MockitoBean private NamedParameterJdbcTemplate template;

  @Test
  public void getResultListWithRowMapper() {
    MockData mockData = getMockData();
    when(template.query(anyString(), any(SqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(Arrays.asList(mockData));
    List<MockData> lst = QueryUtils.getResultList(template, "", null, new MockDataRowMapper());
    assertTrue(lst.size() == 1);
    assertTrue(lst.get(0).getId().equals("id"));
  }

  @Test
  public void getResultList() {
    MockData mockData = getMockData();
    when(template.query(
            anyString(), any(SqlParameterSource.class), any(BeanPropertyRowMapper.class)))
        .thenReturn(Arrays.asList(mockData));
    List<MockData> lst = QueryUtils.getResultList(template, "", null, MockData.class);
    assertTrue(lst.size() == 1);
  }

  @Test
  public void getResult() {
    MockData mockData = getMockData();
    when(template.queryForObject(anyString(), any(SqlParameterSource.class), any(RowMapper.class)))
        .thenReturn(mockData);
    Optional<MockData> response = QueryUtils.getResult(template, "", null, new MockDataRowMapper());
    assertTrue(response.isPresent());
  }

  private MockData getMockData() {
    return MockData.builder().firstName("firstName").lastName("lastName").id("id").build();
  }


  private static Stream<Arguments> pageSizeSource() {
    return Stream.of(
        Arguments.of(null, 50),
        Arguments.of(25, 25),
        Arguments.of(100, 100),
        Arguments.of(150, 50),
        Arguments.of(0, 50),
        Arguments.of(-1, 50)
    );
  }

  @MethodSource("pageSizeSource")
  @ParameterizedTest
    void testDeterminePageSize(Integer requestPageSize, Integer expectedPageSize) {
        SearchConfig searchConfig = new SearchConfig()
            .paging(
                new PagingConfig()
                    .pageSize(50)
                    .useRequestPageSize(true)
                    .requestPageSizeLimit(100)
            );
        SearchRequest searchRequest = new SearchRequest().pageSize(requestPageSize);
        Integer result = QueryUtils.determinePageSize(searchConfig, searchRequest);
      assertEquals(result, expectedPageSize);
    }
}
