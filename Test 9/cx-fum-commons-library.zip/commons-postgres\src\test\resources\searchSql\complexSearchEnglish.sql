WITH filtered_table AS (
SELECT symbol, country, description_en FROM instruments
    WHERE (country = :f0v0)
    AND (description_en IN (:f1v0, :f1v1))
    AND (symbol = :f2v0)
)
SELECT symbol, country, COUNT(*) OVER() AS meta_total_row_count FROM (
SELECT symbol, country, description_en, 1 AS qorder FROM filtered_table
    WHERE (symbol = :searchText OR description_en = :searchText)
UNION ALL
SELECT symbol, country, description_en, 2 AS qorder FROM filtered_table
    WHERE (symbol LIKE :likeSearchText AND NOT symbol = :searchText)
    OR (description_en LIKE :likeSearchText AND NOT description_en = :searchText)
    AND symbol IS DISTINCT FROM :searchText
    AND description_en IS DISTINCT FROM :searchText
UNION ALL
SELECT symbol, country, description_en, 3 AS qorder FROM filtered_table
    WHERE (
    (description_en LIKE :splitTerm0 OR description_en LIKE :splitTerm1 OR description_en LIKE :splitTerm2)
    )
    AND symbol IS DISTINCT FROM :searchText
    AND description_en IS DISTINCT FROM :searchText
    AND (symbol NOT LIKE :likeSearchText OR symbol IS NULL)
    AND (description_en NOT LIKE :likeSearchText OR description_en IS NULL)
) AS results
ORDER BY qorder, country ASC, description_en DESC
LIMIT 30 OFFSET 30;