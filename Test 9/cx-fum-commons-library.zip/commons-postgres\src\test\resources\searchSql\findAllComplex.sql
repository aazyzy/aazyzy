SELECT symbol, country, COUNT(*) OVER() AS meta_total_row_count FROM instruments
    WHERE (country = :f0v0)
    AND (description_en IN (:f1v0, :f1v1))
    AND (symbol = :f2v0)
ORDER BY country ASC, description_en DESC
LIMIT 30 OFFSET 30;