SELECT symbol, country, description_en, COUNT(*) OVER() AS meta_total_row_count FROM instruments
    WHERE (country = :f0v0)
LIMIT 30;