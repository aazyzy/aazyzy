SELECT symbol_fr, country_fr, description_fr, COUNT(*) OVER() AS meta_total_row_count FROM instruments_fr
    WHERE (country_fr = :f0v0)
LIMIT 30;