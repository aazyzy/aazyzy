SELECT symbol, country, description_en FROM instruments
    WHERE (country = :f0v0)
LIMIT 30;