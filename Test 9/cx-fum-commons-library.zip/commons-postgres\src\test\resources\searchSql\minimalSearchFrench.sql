WITH filtered_table AS (
SELECT symbol_fr, country_fr, description_fr FROM instruments_fr

)
SELECT symbol_fr, country_fr, description_fr, COUNT(*) OVER() AS meta_total_row_count FROM (
SELECT symbol_fr, country_fr, description_fr, 1 AS qorder FROM filtered_table
    WHERE (symbol_fr = :searchText OR description_fr = :searchText)
UNION ALL
SELECT symbol_fr, country_fr, description_fr, 2 AS qorder FROM filtered_table
    WHERE (symbol_fr LIKE :likeSearchText AND NOT symbol_fr = :searchText)
    OR (description_fr LIKE :likeSearchText AND NOT description_fr = :searchText)
    AND symbol_fr IS DISTINCT FROM :searchText
    AND description_fr IS DISTINCT FROM :searchText
UNION ALL
SELECT symbol_fr, country_fr, description_fr, 3 AS qorder FROM filtered_table
    WHERE (
    (description_fr LIKE :splitTerm0 OR description_fr LIKE :splitTerm1 OR description_fr LIKE :splitTerm2)
    )
    AND symbol_fr IS DISTINCT FROM :searchText
    AND description_fr IS DISTINCT FROM :searchText
    AND (symbol_fr NOT LIKE :likeSearchText OR symbol_fr IS NULL)
    AND (description_fr NOT LIKE :likeSearchText OR description_fr IS NULL)
) AS results
ORDER BY qorder
LIMIT 30 ;