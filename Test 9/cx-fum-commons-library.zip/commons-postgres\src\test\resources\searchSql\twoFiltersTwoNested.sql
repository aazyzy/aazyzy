WITH filtered_table AS (
SELECT symbol, country, entry_time, is_active, expiry_date, count, description_en, b10_rr_code FROM instruments
    WHERE (country = :f0v0 OR (symbol = :n0v0))
    AND (description_en = :f1v0 OR (count BETWEEN :n1v0 AND :n1v1))
    AND (b10_rr_code BETWEEN :f2v0 AND :f2v1)
)
SELECT symbol, country, entry_time, is_active, expiry_date, count, description_en, b10_rr_code, COUNT(*) OVER() AS meta_total_row_count FROM (
SELECT symbol, country, entry_time, is_active, expiry_date, count, description_en, b10_rr_code, 1 AS qorder FROM filtered_table
    WHERE (symbol = :searchText OR description_en = :searchText)
UNION ALL
SELECT symbol, country, entry_time, is_active, expiry_date, count, description_en, b10_rr_code, 2 AS qorder FROM filtered_table
    WHERE (symbol LIKE :likeSearchText AND NOT symbol = :searchText)
    OR (description_en LIKE :likeSearchText AND NOT description_en = :searchText)
    AND symbol IS DISTINCT FROM :searchText
    AND description_en IS DISTINCT FROM :searchText
UNION ALL
SELECT symbol, country, entry_time, is_active, expiry_date, count, description_en, b10_rr_code, 3 AS qorder FROM filtered_table
    WHERE (
    (description_en LIKE :splitTerm0 OR description_en LIKE :splitTerm1 OR description_en LIKE :splitTerm2)
    )
    AND symbol IS DISTINCT FROM :searchText
    AND description_en IS DISTINCT FROM :searchText
    AND (symbol NOT LIKE :likeSearchText OR symbol IS NULL)
    AND (description_en NOT LIKE :likeSearchText OR description_en IS NULL)
) AS results
ORDER BY qorder, country ASC, description_en DESC
LIMIT 30 ;