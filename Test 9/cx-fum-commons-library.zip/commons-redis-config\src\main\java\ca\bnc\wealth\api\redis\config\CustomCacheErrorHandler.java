package ca.bnc.wealth.api.redis.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.interceptor.CacheErrorHandler;


@Slf4j
public class CustomCacheErrorHandler implements CacheErrorHandler {

  private static String EXCEPTION = ", exception: ";
  @Override
  public void handleCacheGetError(RuntimeException exception, Cache cache, Object key) {
    log.error("Failure getting from cache: " + cache.getName() +  EXCEPTION  + exception.toString());
  }

  @Override
  public void handleCachePutError(RuntimeException exception, Cache cache, Object key, Object value) {
    log.error("Failure putting into cache: " + cache.getName() + EXCEPTION + exception.toString());
  }

  @Override
  public void handleCacheEvictError(RuntimeException exception, Cache cache, Object key) {
    log.error("Failure evicting from cache: " + cache.getName() + EXCEPTION + exception.toString());
  }

  @Override
  public void handleCacheClearError(RuntimeException exception, Cache cache) {
    log.error("Failure clearing cache: " + cache.getName() + EXCEPTION + exception.toString());
  }
}
