package ca.bnc.wealth.api.redis.config;

import java.time.Duration;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.CacheErrorHandler;
import org.springframework.cache.support.NoOpCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
@EnableCaching
public class RedisCacheConfig implements CachingConfigurer {

  @Value("${redis.hostname:localhost}")
  private String redisHostName;

  @Value("${redis.port:6379}")
  private int redisPort;

  @Value("${redis.password}")
  private String password;

  @Value("${redis.cache.enable:false}")
  private boolean enableCache;

  @Value("${redis.ttl:36000}")
  private int redisTtl;

  @Value("${redis.connectionTimeout:2}")
  private int redisConnectionTimeout;

  @Value("${redis.readTimeout.retry.maxAttempts:2}")
  private int readTimeoutRetryMaxAttempts;

  @Value("${redis.readTimeout.retry.backoffMillis:50}")
  private long readTimeoutRetryBackoffMillis;

  @Bean
  public LettuceConnectionFactory redisConnectionFactory() {
    RedisStandaloneConfiguration redisConf = new RedisStandaloneConfiguration();
    redisConf.setHostName(redisHostName);
    redisConf.setPort(redisPort);
    if(StringUtils.isNotBlank(password))
      redisConf.setPassword(RedisPassword.of(password));
    LettuceClientConfiguration configuration = LettuceClientConfiguration.builder()
        .commandTimeout(Duration.ofSeconds(redisConnectionTimeout))
        .useSsl()
        .disablePeerVerification()
        .build();
    return new LettuceConnectionFactory(redisConf, configuration);
  }

  @Bean
  public RedisCacheConfiguration cacheConfiguration() {
    return RedisCacheConfiguration.defaultCacheConfig()
        .entryTtl(Duration.ofSeconds(redisTtl))
        .disableCachingNullValues();
  }

  @Override
  @Bean(name = "redisCacheManager")
  public CacheManager cacheManager() {
    log.info("redis.cache.enable::::" + enableCache);
    if(enableCache) {
      log.info("Using redis cache::::");
      RedisCacheManager redisCacheManager = RedisCacheManager.builder(redisConnectionFactory())
          .cacheDefaults(cacheConfiguration())
          .transactionAware()
          .build();
      return new RetryingCacheManager(
          redisCacheManager,
          readTimeoutRetryMaxAttempts,
          Duration.ofMillis(readTimeoutRetryBackoffMillis));
    }
    log. info("Using NoOpCacheManager::::");
    return new NoOpCacheManager();
  }

  @Override
  public CacheErrorHandler errorHandler() {
    return new CustomCacheErrorHandler();
  }

  @Bean
  public RedisTemplate<String, Object> redisTemplate() {
    RedisTemplate<String, Object> template = new RedisTemplate<>();
    template.setConnectionFactory(redisConnectionFactory());
    template.setKeySerializer(new StringRedisSerializer());
    return template;
  }
}
