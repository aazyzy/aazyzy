package ca.bnc.wealth.api.redis.config;

import io.lettuce.core.RedisCommandTimeoutException;
import java.net.SocketTimeoutException;
import java.time.Duration;
import java.util.Locale;
import java.util.concurrent.Callable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;

@Slf4j
public class RetryingCache implements Cache {

  private static final int MAX_CAUSE_DEPTH = 10;

  private final Cache delegate;
  private final int maxAttempts;
  private final Duration backoff;

  public RetryingCache(Cache delegate, int maxAttempts, Duration backoff) {
    this.delegate = delegate;
    this.maxAttempts = Math.max(1, maxAttempts);
    this.backoff = backoff == null ? Duration.ZERO : backoff;
  }

  @Override
  public String getName() {
    return delegate.getName();
  }

  @Override
  public Object getNativeCache() {
    return delegate.getNativeCache();
  }

  @Override
  public ValueWrapper get(Object key) {
    return executeWithRetry(() -> delegate.get(key), "get", key);
  }

  @Override
  public <T> T get(Object key, Class<T> type) {
    return executeWithRetry(() -> delegate.get(key, type), "get", key);
  }

  @Override
  public <T> T get(Object key, Callable<T> valueLoader) {
    return executeWithRetry(() -> delegate.get(key, valueLoader), "get", key);
  }

  @Override
  public void put(Object key, Object value) {
    delegate.put(key, value);
  }

  @Override
  public ValueWrapper putIfAbsent(Object key, Object value) {
    return delegate.putIfAbsent(key, value);
  }

  @Override
  public void evict(Object key) {
    delegate.evict(key);
  }

  @Override
  public void clear() {
    delegate.clear();
  }

  private <T> T executeWithRetry(Callable<T> action, String operation, Object key) {
    int attempt = 0;
    while (true) {
      attempt++;
      try {
        return action.call();
      } catch (RuntimeException ex) {
        if (!isReadTimeout(ex) || attempt >= maxAttempts) {
          throw ex;
        }
        log.warn("Retrying cache {} after read timeout (attempt {}/{}). Cache: {}, key: {}", operation,
            attempt, maxAttempts, getName(), key);
        sleepBackoff();
      } catch (Exception ex) {
        if (ex instanceof RuntimeException) {
          throw (RuntimeException) ex;
        }
        throw new IllegalStateException("Unexpected checked exception in cache operation.", ex);
      }
    }
  }

  private void sleepBackoff() {
    if (backoff.isZero() || backoff.isNegative()) {
      return;
    }
    try {
      Thread.sleep(backoff.toMillis());
    } catch (InterruptedException ex) {
      Thread.currentThread().interrupt();
    }
  }

  private boolean isReadTimeout(Throwable ex) {
    Throwable current = ex;
    int depth = 0;
    while (current != null && depth < MAX_CAUSE_DEPTH) {
      if (current instanceof RedisCommandTimeoutException) {
        return true;
      }
      if (current instanceof SocketTimeoutException) {
        return true;
      }
      String className = current.getClass().getName();
      if ("io.netty.handler.timeout.ReadTimeoutException".equals(className)) {
        return true;
      }
      String message = current.getMessage();
      if (message != null && message.toLowerCase(Locale.ROOT).contains("read timed out")) {
        return true;
      }
      current = current.getCause();
      depth++;
    }
    return false;
  }
}
