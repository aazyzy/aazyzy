package ca.bnc.wealth.api.redis.config;

import java.time.Duration;
import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;

public class RetryingCacheManager implements CacheManager {

  private final CacheManager delegate;
  private final int maxAttempts;
  private final Duration backoff;
  private final ConcurrentMap<String, Cache> cacheMap = new ConcurrentHashMap<>();

  public RetryingCacheManager(CacheManager delegate, int maxAttempts, Duration backoff) {
    this.delegate = delegate;
    this.maxAttempts = maxAttempts;
    this.backoff = backoff;
  }

  @Override
  public Cache getCache(String name) {
    Cache cache = delegate.getCache(name);
    if (cache == null) {
      return null;
    }
    return cacheMap.computeIfAbsent(name, key -> new RetryingCache(cache, maxAttempts, backoff));
  }

  @Override
  public Collection<String> getCacheNames() {
    return delegate.getCacheNames();
  }
}
