package ca.bnc.wealth.api.redis.config;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import ca.bnc.wealth.api.redis.config.RedisCacheConfig;
import org.junit.Test;
import org.springframework.cache.CacheManager;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.test.util.ReflectionTestUtils;

public class RedisCacheConfigTest {

  @Test
  public void redisConnectionFactory_withoutPassword() {
    RedisCacheConfig redisCacheConfig = new RedisCacheConfig();
    ReflectionTestUtils.setField(redisCacheConfig, "password", null);
    LettuceConnectionFactory connectionFactory = redisCacheConfig.redisConnectionFactory();
    assertNotNull(connectionFactory);
  }

  @Test
  public void redisConnectionFactory_password() {
    RedisCacheConfig redisCacheConfig = new RedisCacheConfig();
    ReflectionTestUtils.setField(redisCacheConfig, "password", "pas");
    LettuceConnectionFactory connectionFactory = redisCacheConfig.redisConnectionFactory();
    assertNotNull(connectionFactory);
  }

  @Test
  public void cacheConfiguration() {
    RedisCacheConfig redisCacheConfig = new RedisCacheConfig();
    RedisCacheConfiguration redisCacheConfiguration = redisCacheConfig.cacheConfiguration();
    assertNotNull(redisCacheConfiguration);
  }

  @Test
  public void cacheManager_redisCacheEnabled() {
    RedisCacheConfig redisCacheConfig = new RedisCacheConfig();
    ReflectionTestUtils.setField(redisCacheConfig, "enableCache", true);
    CacheManager cacheManager = redisCacheConfig.cacheManager();
    assertNotNull(cacheManager);
  }

  @Test
  public void cacheManager_redisCacheDisabled() {
    RedisCacheConfig redisCacheConfig = new RedisCacheConfig();
    ReflectionTestUtils.setField(redisCacheConfig, "enableCache", false);
    CacheManager cacheManager = redisCacheConfig.cacheManager();
    assertNotNull(cacheManager);
  }
}
