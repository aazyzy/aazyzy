package ca.bnc.wealth.common.sanitization;

import ca.bnc.wealth.common.core.config.BasketBookingTemplateConfig;
import ca.bnc.wealth.common.core.enums.TemplateFormat;
import ca.bnc.wealth.common.core.model.Template;
import ca.bnc.wealth.common.sanitization.consumers.AcceptedValuesFieldSanitizer;
import ca.bnc.wealth.common.sanitization.consumers.FileFieldCorrectionContext;
import ca.bnc.wealth.common.sanitization.consumers.TrimSpacesFieldSanitizer;
import ca.bnc.wealth.common.sanitization.consumers.UppercaseFieldSanitizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;

import static ca.bnc.wealth.common.core.constants.ErrorMessages.ERROR_MESSAGE_TEMPLATE_NOT_FOUND;

/**
 * This engine class will sanitize given values based on the file template format
 */
@Component
public class BulkFileFieldsSanitizationEngine {

  private AcceptedValuesFieldSanitizer acceptedValuesFieldSanitizer;
  private TrimSpacesFieldSanitizer trimSpacesFieldSanitizer;
  private UppercaseFieldSanitizer uppercaseFieldSanitizer;
  private BasketBookingTemplateConfig basketBookingTemplateConfig;

  /**
   * Constructor
   *
   * @param acceptedValuesFieldSanitizer the {@link AcceptedValuesFieldSanitizer}
   * @param trimSpacesFieldSanitizer     the {@link TrimSpacesFieldSanitizer}
   * @param uppercaseFieldSanitizer      the {@link UppercaseFieldSanitizer}
   * @param basketBookingTemplateConfig  the {@link BasketBookingTemplateConfig}
   */
  @Autowired
  public BulkFileFieldsSanitizationEngine(AcceptedValuesFieldSanitizer acceptedValuesFieldSanitizer,
      TrimSpacesFieldSanitizer trimSpacesFieldSanitizer,
      UppercaseFieldSanitizer uppercaseFieldSanitizer,
      BasketBookingTemplateConfig basketBookingTemplateConfig) {
    this.acceptedValuesFieldSanitizer = acceptedValuesFieldSanitizer;
    this.trimSpacesFieldSanitizer = trimSpacesFieldSanitizer;
    this.uppercaseFieldSanitizer = uppercaseFieldSanitizer;
    this.basketBookingTemplateConfig = basketBookingTemplateConfig;
  }

  /**
   * Sanitizes a row of CSV file which represented in a {@link Map} for the given
   * {@link TemplateFormat}, the results will be in the same map
   *
   * @param rowMap         a map with csv header name to field value.
   * @param templateFormat the {@link TemplateFormat}
   * @throws Exception when template is not found
   */
  public void sanitizeContents(Map<String, String> rowMap, TemplateFormat templateFormat) throws Exception {
    FileFieldCorrectionContext context = FileFieldCorrectionContext.builder()
        .rowMap(rowMap).build();
    Consumer<FileFieldCorrectionContext> sanitizers =
        trimSpacesFieldSanitizer.andThen(uppercaseFieldSanitizer)
            .andThen(acceptedValuesFieldSanitizer);

    Template template = basketBookingTemplateConfig.getValidationRules().get(templateFormat);
    if (Objects.isNull(template)) {
      throw new Exception(String.format(ERROR_MESSAGE_TEMPLATE_NOT_FOUND, templateFormat));
    }

    basketBookingTemplateConfig.getFieldsByTemplateFormat(templateFormat).forEach(field -> {
      context.setField(field);
      sanitizers.accept(context);
    });
  }
}

