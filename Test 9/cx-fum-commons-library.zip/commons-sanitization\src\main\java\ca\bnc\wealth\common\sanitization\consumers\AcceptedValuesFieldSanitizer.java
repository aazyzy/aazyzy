package ca.bnc.wealth.common.sanitization.consumers;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.function.Consumer;


/**
 * A corrector to check if the value of the field is in the accepted values list, then sanitize them
 * to be the right enum values.
 */
@Component
public class AcceptedValuesFieldSanitizer implements Consumer<FileFieldCorrectionContext> {

    @Override
    public void accept(@NonNull FileFieldCorrectionContext context) {
        String fieldValue = context.getRowMap().get(context.getField().getHeaderName());

        if (CollectionUtils.isEmpty(
                context.getField().getCaseSensitiveAcceptableValues())
                || StringUtils.isBlank(fieldValue)) {
            return;
        }

        Optional<String> correctedValue = context.getField().getCaseSensitiveAcceptableValues()
                .stream()
                .filter(value -> value.equalsIgnoreCase(fieldValue)).distinct().findFirst();

        correctedValue.ifPresent(
                value -> context.getRowMap().put(context.getField().getHeaderName(), value));

    }

}
