package ca.bnc.wealth.common.sanitization.consumers;

import ca.bnc.wealth.common.core.model.Field;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Map;

/**
 * This context will carry over the {@link Map} for correction, for the {@link Field}
 *
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileFieldCorrectionContext {
    // the record is under correction
    private Map<String, String> rowMap;
    // the field is being corrected
    private Field field;
}