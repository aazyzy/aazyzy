package ca.bnc.wealth.common.sanitization.consumers;

import org.apache.commons.lang3.StringUtils;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

import java.util.function.Consumer;


/**
 * A corrector to trim the leading and tailing spaces for the value in the field
 */
@Component
public class TrimSpacesFieldSanitizer implements Consumer<FileFieldCorrectionContext> {

    @Override
    public void accept(@NonNull FileFieldCorrectionContext context) {
        String fieldValue = context.getRowMap().get(context.getField().getHeaderName());

        if (StringUtils.isBlank(fieldValue)) {
            return;
        }

        context.getRowMap().put(context.getField().getHeaderName(), fieldValue.trim());
    }

}
