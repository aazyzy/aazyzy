package ca.bnc.wealth.common.sanitization.consumers;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.function.Consumer;


/**
 * A corrector to correct the value in the field to uppercase.
 */
@Component
public class UppercaseFieldSanitizer implements Consumer<FileFieldCorrectionContext> {

    @Override
    public void accept(FileFieldCorrectionContext context) {
        String fieldValue = context.getRowMap().get(context.getField().getHeaderName());

        if (StringUtils.isBlank(fieldValue)
                || Objects.isNull(context.getField().getCorrection())
                || Boolean.FALSE.equals(context.getField().getCorrection().getUppercase())) {
            return;
        }

        context.getRowMap().put(context.getField().getHeaderName(), fieldValue.toUpperCase());
    }

}
