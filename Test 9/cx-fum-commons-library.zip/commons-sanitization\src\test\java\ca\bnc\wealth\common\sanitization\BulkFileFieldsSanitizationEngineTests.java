package ca.bnc.wealth.common.sanitization;

import ca.bnc.wealth.common.core.config.BasketBookingTemplateConfig;
import ca.bnc.wealth.common.core.enums.TemplateFormat;
import ca.bnc.wealth.common.core.helper.CsvFileToListMapper;
import ca.bnc.wealth.common.core.model.Correction;
import ca.bnc.wealth.common.core.model.Field;
import ca.bnc.wealth.common.core.model.Template;
import ca.bnc.wealth.common.sanitization.consumers.AcceptedValuesFieldSanitizer;
import ca.bnc.wealth.common.sanitization.consumers.TrimSpacesFieldSanitizer;
import ca.bnc.wealth.common.sanitization.consumers.UppercaseFieldSanitizer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BulkFileFieldsSanitizationEngineTests {
    @Mock
    private BasketBookingTemplateConfig basketBookingTemplateConfig;

    private BulkFileFieldsSanitizationEngine bulkFileFieldsSanitizationEngine;

    @BeforeEach
    void setUp() {
        bulkFileFieldsSanitizationEngine = new BulkFileFieldsSanitizationEngine(
                new AcceptedValuesFieldSanitizer(),
                new TrimSpacesFieldSanitizer(),
                new UppercaseFieldSanitizer(),
                basketBookingTemplateConfig);
    }

    @Test
    void givenFileWithFieldNeedToBeSanitized_whenSanitizeTheFile_thenFieldsBeenSanitized() throws Exception {
        // setup
        Path validCsvFile = Paths.get("src/test/resources/mutual_fund_bulk_order_for_sanitization.csv");
        String contentType = "text/plain";
        byte[] content = Files.readAllBytes(validCsvFile);
        MultipartFile result = new MockMultipartFile("mutual_fund_bulk_order_for_sanitization.csv",
                "mutual_fund_bulk_order_for_sanitization.csv", contentType, content);
        Correction correction = new Correction();
        correction.setUppercase(true);
        Map<TemplateFormat, Template> templateFormatValidationRulesMap = new HashMap<>();
        Template template = buildTemplate();
        template.getFields()[0].setCorrection(correction);
        template.getFields()[1].setCaseSensitiveAcceptableValues(new ArrayList<>(Arrays.asList("Buy", "Sell")));
        template.getFields()[2].setCorrection(correction);
        templateFormatValidationRulesMap.put(TemplateFormat.COMPASSX, template);
        when(basketBookingTemplateConfig.getValidationRules()).thenReturn(templateFormatValidationRulesMap);
        when(basketBookingTemplateConfig.getFieldsByTemplateFormat(TemplateFormat.COMPASSX)).thenReturn(Arrays.asList(template.getFields()));

        CsvFileToListMapper csvFileToListMapper = new CsvFileToListMapper(basketBookingTemplateConfig);
        List<Map<String, String>> rowMaps = csvFileToListMapper.convertCsvFileToMap(result, TemplateFormat.COMPASSX);

        // execute and verify
        rowMaps.forEach(rowMap -> {
            try {
                bulkFileFieldsSanitizationEngine.sanitizeContents(rowMap, TemplateFormat.COMPASSX);
            } catch (Exception e) {
                fail(e);
            }
            assertThat(rowMap).containsEntry("Account No*", "2YTESTB"); // To uppercase
            assertThat(rowMap).containsEntry("Trade type*", "Buy"); // To Enum value
            assertThat(rowMap).containsEntry("Symbol", "OLF1502"); // Trim spaces and to uppercase
            assertThat(rowMap).containsEntry("Solicitation", "y"); // Do nothing for invalid value
            assertThat(rowMap.get("From Symbol")).isBlank(); // Do nothing for empty field
        });
    }

    /**
     * Build the template for test
     * @return the {@link Template}
     */
    private Template buildTemplate() {
        Template template = new Template();
        String[] headers = new String[]{"Account No*", "Trade type*", "Symbol", "From Symbol", "Amount Type*", "Amount*", "Solicitation", "Dividend Options", "Front Load %", "Additional Commission", "Net after commissions", "Advisor Code"};
        template.setFields(
                Arrays.stream(headers)
                        .map(header -> Field.builder().schemaField("Test").fieldName(header).headerName(header).build())
                        .collect(Collectors.toList()).toArray(new Field[headers.length]));

        return template;
    }
}
