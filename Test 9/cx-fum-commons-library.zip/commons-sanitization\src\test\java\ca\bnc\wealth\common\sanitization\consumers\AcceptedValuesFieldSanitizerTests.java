package ca.bnc.wealth.common.sanitization.consumers;

import org.assertj.core.util.Lists;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test class for {@link AcceptedValuesFieldSanitizer}
 */
class AcceptedValuesFieldSanitizerTests extends SanitizerTestsBase {

    private AcceptedValuesFieldSanitizer acceptedValuesFieldSanitizer;
    private Map<String, String> rowMap;
    private FileFieldCorrectionContext context;

    @BeforeEach
    void setUp() {
        acceptedValuesFieldSanitizer = new AcceptedValuesFieldSanitizer();
        rowMap = new HashMap<>();
        context = generateContext("solicitation", null, Lists.newArrayList("Yes", "No"), rowMap);
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {"  ", "\t", "\n"})
    void givenABlankField_whenSanitize_thenNothingBeingChanged(String value) {
        // setup
        rowMap.put("solicitation", value);

        // execute
        acceptedValuesFieldSanitizer.accept(context);

        // verify
        assertThat(rowMap.get("solicitation")).isBlank();
    }

    @ParameterizedTest
    @CsvSource({"Yes,Yes", "yES,Yes", "NO,No", "abcd,abcd"})
    void givenANonEmptyField_whenSanitize_thenTheValueShouldBeSanitizedIfItIsAcceptedValue(String input, String expected) {
        // setup
        rowMap.put("solicitation", input);

        // execute
        acceptedValuesFieldSanitizer.accept(context);

        // verify
        assertThat(rowMap).containsEntry("solicitation", expected);
    }

}
