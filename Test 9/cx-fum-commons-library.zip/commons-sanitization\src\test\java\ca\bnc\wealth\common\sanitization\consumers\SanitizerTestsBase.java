package ca.bnc.wealth.common.sanitization.consumers;

import ca.bnc.wealth.common.core.model.Correction;
import ca.bnc.wealth.common.core.model.Field;

import java.util.List;
import java.util.Map;

/**
 * The base test class for all Sanitizer related tests.
 */
public class SanitizerTestsBase {

    /**
     * Generate a {@link FileFieldCorrectionContext} for test
     * @param rowMap the row map to be used for test
     * @return the {@link FileFieldCorrectionContext}
     */
    public FileFieldCorrectionContext generateContext(String fieldName, Correction correction,
                                                      List<String> acceptedValues,
                                                      Map<String, String> rowMap) {
        Field field = Field.builder()
                .fieldName(fieldName)
                .headerName(fieldName)
                .correction(correction)
                .schemaField("TestSchema")
                .caseSensitiveAcceptableValues(acceptedValues)
                .build();

        return FileFieldCorrectionContext.builder()
                .field(field)
                .rowMap(rowMap).build();

    }
}
