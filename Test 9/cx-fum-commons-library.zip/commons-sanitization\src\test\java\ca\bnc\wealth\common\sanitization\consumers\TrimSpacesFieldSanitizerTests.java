package ca.bnc.wealth.common.sanitization.consumers;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test class for {@link TrimSpacesFieldSanitizer}
 */
class TrimSpacesFieldSanitizerTests extends SanitizerTestsBase {

    private TrimSpacesFieldSanitizer trimSpacesFieldSanitizer;
    private Map<String, String> rowMap;
    private FileFieldCorrectionContext context;

    @BeforeEach
    void setUp() {
        trimSpacesFieldSanitizer = new TrimSpacesFieldSanitizer();
        rowMap = new HashMap<>();
        context = generateContext("Account No*", null, null, rowMap);
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {"  ", "\t", "\n"})
    void givenABlankField_whenSanitize_thenNothingBeingChanged(String input) {
        // setup
        rowMap.put("Account No*", input);

        // execute
        trimSpacesFieldSanitizer.accept(context);

        // verify
        assertThat(rowMap.get("Account No*")).isBlank();
    }

    @ParameterizedTest
    @CsvSource({"ABCDEFG,ABCDEFG", "Do Not Sanitize,Do Not Sanitize"})
    void givenAValidField_whenSanitize_thenTheValueShouldBeSanitized(String input, String expected) {
        // setup
        rowMap.put("Account No*", input);

        // execute
        trimSpacesFieldSanitizer.accept(context);

        // verify
        assertThat(rowMap).containsEntry("Account No*", expected);
    }

    /**
     * Before Jupiter 5.8, the @CsvSource will automatically trim the spaces for parameterized values,
     * so I have to have a separated test for this. If we upgrade to 5.8 then we can move this to
     * the previous test
     */
    @Test
    void givenAFieldWithWhiteSpaces_whenSanitize_thenTheValueShouldBeSanitized() {
        // setup
        rowMap.put("Account No*", "         ABCDEFG  ");

        // execute
        trimSpacesFieldSanitizer.accept(context);

        // verify
        assertThat(rowMap).containsEntry("Account No*", "ABCDEFG");
    }

}
