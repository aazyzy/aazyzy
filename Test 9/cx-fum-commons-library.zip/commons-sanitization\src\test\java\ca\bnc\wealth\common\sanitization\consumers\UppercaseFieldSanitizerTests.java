package ca.bnc.wealth.common.sanitization.consumers;

import ca.bnc.wealth.common.core.model.Correction;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test class for {@link UppercaseFieldSanitizer}
 */
class UppercaseFieldSanitizerTests extends SanitizerTestsBase {

    private UppercaseFieldSanitizer uppercaseFieldSanitizer;
    private Map<String, String> rowMap;
    private FileFieldCorrectionContext context;

    @BeforeEach
    void setUp() {
        uppercaseFieldSanitizer = new UppercaseFieldSanitizer();
        rowMap = new HashMap<>();
        Correction correction = new Correction();
        correction.setUppercase(true);
        context = generateContext("Account No*", correction, null, rowMap);
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {"  ", "\t", "\n"})
    void givenABlankField_whenSanitize_thenNothingBeingChanged(String input) {
        // setup
        rowMap.put("Account No*", input);

        // execute
        uppercaseFieldSanitizer.accept(context);

        // verify
        assertThat(rowMap.get("Account No*")).isBlank();
    }

    @Test
    void givenAValidField_whenSanitize_thenTheValueShouldBeSanitized() {
        // setup
        rowMap.put("Account No*", "abCdefG");

        // execute
        uppercaseFieldSanitizer.accept(context);

        // verify
        assertThat(rowMap).containsEntry("Account No*", "ABCDEFG");
    }

}
