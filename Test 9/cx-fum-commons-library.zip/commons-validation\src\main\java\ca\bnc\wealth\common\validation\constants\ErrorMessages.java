package ca.bnc.wealth.common.validation.constants;

/**
 * Define error messages
 */
public class ErrorMessages {
    public static final String ERROR_MESSAGE_FIELD_IS_BLANK = "%s cannot be blank";
    public static final String ERROR_MESSAGE_FILE_FORMAT_IS_INCORRECT = "Incorrect File format (%s files only).";
    public static final String ERROR_MESSAGE_FILE_SIZE_EXCEEDS_MAXIMUM = "File exceeds limit of %s.";
    public static final String ERROR_MESSAGE_BASKET_FILE_VALIDATOR_UNABLE_TO_GET_RULES = "Error loading rules";
}
