package ca.bnc.wealth.common.validation.predicates;

import ca.bnc.wealth.common.core.config.BasketBookingTemplateConfig;
import ca.bnc.wealth.common.core.enums.TemplateFormat;
import ca.bnc.wealth.common.core.model.Template;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

import static ca.bnc.wealth.common.validation.constants.ErrorMessages.ERROR_MESSAGE_BASKET_FILE_VALIDATOR_UNABLE_TO_GET_RULES;
import static ca.bnc.wealth.common.validation.constants.ErrorMessages.ERROR_MESSAGE_FILE_FORMAT_IS_INCORRECT;
import static ca.bnc.wealth.common.validation.constants.ErrorMessages.ERROR_MESSAGE_FILE_SIZE_EXCEEDS_MAXIMUM;

/**
 * This class loads validates the file size and extension from the Basket Booking Template metadata
 */
@Slf4j
@Component
public class BasketFileValidatorEngine {
  private final BasketBookingTemplateConfig config;

  @Autowired
  public BasketFileValidatorEngine(BasketBookingTemplateConfig config) {
    this.config = config;
  }

  /**
   * Validate the multipart file {@link MultipartFile} for the given {@link TemplateFormat},
   * the results will be a String message with an error or empty for valid.
   * @param multipartFile the {@link MultipartFile} to be validated
   * @param templateFormat the {@link TemplateFormat}
   * @return errorMessage is the error message or an empty string if valid
   */
  public String validateFile(MultipartFile multipartFile, TemplateFormat templateFormat) {

    long maxFileSize;
    String allowedFileFormat;
    Map<TemplateFormat, Template> rulesMap = config.getValidationRules();

    // Check the file based on the rules retrieved, otherwise error
    if (rulesMap == null || rulesMap.isEmpty()) {
      return ERROR_MESSAGE_BASKET_FILE_VALIDATOR_UNABLE_TO_GET_RULES;
    }

    // Check file size is above maximum (in Bytes)
    maxFileSize = rulesMap.get(templateFormat).getFileSize();
    if (multipartFile.getSize() > maxFileSize) {
      return String.format(ERROR_MESSAGE_FILE_SIZE_EXCEEDS_MAXIMUM, FileUtils.byteCountToDisplaySize(maxFileSize));
    }

    // Check for valid file extension
    allowedFileFormat = rulesMap.get(templateFormat).getFileFormat();
    log.info("The allowed file format is: "+allowedFileFormat);
    log.info("The original file name is: "+multipartFile.getOriginalFilename());
    String extension = FilenameUtils.getExtension(multipartFile.getOriginalFilename());
    log.info("The extension of the file name is: "+extension);
    log.info("Do extensions match: "+allowedFileFormat.equalsIgnoreCase(extension));
    if (!allowedFileFormat.equalsIgnoreCase(extension)) {
      return String.format(ERROR_MESSAGE_FILE_FORMAT_IS_INCORRECT, allowedFileFormat);
    }

    // Return empty string if everything is fine
    return "";
  }

}
