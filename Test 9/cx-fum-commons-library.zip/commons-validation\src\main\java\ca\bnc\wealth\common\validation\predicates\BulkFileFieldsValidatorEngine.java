package ca.bnc.wealth.common.validation.predicates;

import ca.bnc.wealth.common.core.config.BasketBookingTemplateConfig;
import ca.bnc.wealth.common.core.enums.TemplateFormat;
import ca.bnc.wealth.common.core.model.Field;
import ca.bnc.wealth.common.core.model.Template;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Predicate;

import static ca.bnc.wealth.common.core.constants.ErrorMessages.ERROR_MESSAGE_TEMPLATE_NOT_FOUND;

/**
 * The validator to validate a {@link Map} based on the file template format
 * Each file type should have a YAML file defined the fields in {@link Field} objects.
 *
 */
@Component
public class BulkFileFieldsValidatorEngine {

    /**
     * All the existing validators which implements a {@link Predicate} for {@link FileFieldValidatorContext}
     */
    private List<Predicate<FileFieldValidatorContext>> validators;
    private BasketBookingTemplateConfig basketBookingTemplateConfig;

    /**
     * Constructor
     * @param validators a list of {@link Predicate}s
     * @param basketBookingTemplateConfig the {@link BasketBookingTemplateConfig}
     */
    @Autowired
    public BulkFileFieldsValidatorEngine(List<Predicate<FileFieldValidatorContext>> validators,
                                         BasketBookingTemplateConfig basketBookingTemplateConfig) {
        this.validators = validators;
        this.basketBookingTemplateConfig = basketBookingTemplateConfig;
    }

    /**
     * Validate a row of CSV file which represented in a {@link Map} for the given {@link TemplateFormat},
     * the results will be in the map
     *
     * @param rowMap a map with csv header name to field value.
     * @param rowNumber the number of current row
     * @param templateFormat the {@link TemplateFormat}
     * @param errorMessageToRowNumbers is the map where we save the validate error messages with row number
     * @throws Exception when template is not found
     */
    public void validate(Map<String, String> rowMap, int rowNumber, TemplateFormat templateFormat,
                         Map<String, List<Long>> errorMessageToRowNumbers) throws Exception {
        FileFieldValidatorContext context = FileFieldValidatorContext.builder()
                .errorMessageToRowNumbers(errorMessageToRowNumbers)
                .rowMap(rowMap).rowNumber(rowNumber).build();

        Template template = basketBookingTemplateConfig.getValidationRules().get(templateFormat);
        if (Objects.isNull(template)) {
            throw new Exception(String.format(ERROR_MESSAGE_TEMPLATE_NOT_FOUND, templateFormat));
        }

        basketBookingTemplateConfig.getFieldsByTemplateFormat(templateFormat).forEach(field -> {
            context.setField(field);
            for (Predicate<FileFieldValidatorContext> predicate : validators) {
                if (!predicate.test(context)) {
                    break;
                }
            }
        });
    }
}

