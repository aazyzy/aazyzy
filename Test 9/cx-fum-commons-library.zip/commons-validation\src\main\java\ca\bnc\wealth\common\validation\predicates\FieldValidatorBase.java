package ca.bnc.wealth.common.validation.predicates;

import java.util.ArrayList;
import java.util.function.Predicate;

/**
 * An abstract class for validators with common methods.
 *
 */
public abstract class FieldValidatorBase implements Predicate<FileFieldValidatorContext> {

    /**
     * Add the record number to the error message map.
     * @param context the {@link FileFieldValidatorContext}
     * @param errorKey the error key in the map
     */
    protected void addRowNumberToErrorMessageMap(FileFieldValidatorContext context, String errorKey) {
        long recordNumber = context.getRowNumber();

        if (!context.getErrorMessageToRowNumbers().containsKey(errorKey)) {
            context.getErrorMessageToRowNumbers().put(errorKey, new ArrayList<>());
        }

        context.getErrorMessageToRowNumbers().get(errorKey).add(recordNumber);
    }
}

