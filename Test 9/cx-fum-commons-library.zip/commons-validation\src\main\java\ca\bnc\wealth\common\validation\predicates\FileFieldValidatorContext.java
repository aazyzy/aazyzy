package ca.bnc.wealth.common.validation.predicates;

import ca.bnc.wealth.common.core.model.Field;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
import java.util.Map;

/**
 * This context will carry over the {@link Map} for validate, for the {@link Field} and
 * save the error messages into the error message to row number map.
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileFieldValidatorContext {
    // the record is under validating
    private Map<String, String> rowMap;
    private int rowNumber;
    // the error map carries the error message
    private Map<String, List<Long>> errorMessageToRowNumbers;
    // the field is being validated
    private Field field;
}