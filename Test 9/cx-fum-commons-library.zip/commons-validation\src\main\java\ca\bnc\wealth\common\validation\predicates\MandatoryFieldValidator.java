package ca.bnc.wealth.common.validation.predicates;

import org.apache.commons.lang3.StringUtils;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

import static ca.bnc.wealth.common.validation.constants.ErrorMessages.ERROR_MESSAGE_FIELD_IS_BLANK;

/**
 * This validator validates if this field has value when it is configured as mandatory.
 */
@Component
public class MandatoryFieldValidator extends FieldValidatorBase {

    @Override
    public boolean test(@Nullable FileFieldValidatorContext context) {
        String fieldValue = context.getRowMap().get(context.getField().getHeaderName());

        if (!context.getField().isMandatory()
                || StringUtils.isNotBlank(fieldValue)) {
            return true;
        }

        String errorKey = String.format(ERROR_MESSAGE_FIELD_IS_BLANK,
                context.getField().getHeaderName());
        addRowNumberToErrorMessageMap(context, errorKey);

        return false;
    }

}
