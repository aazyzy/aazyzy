package ca.bnc.wealth.common.validation.predicates;

import ca.bnc.wealth.common.core.config.BasketBookingTemplateConfig;
import ca.bnc.wealth.common.core.enums.TemplateFormat;
import ca.bnc.wealth.common.core.model.Field;
import ca.bnc.wealth.common.core.model.Template;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static ca.bnc.wealth.common.validation.constants.ErrorMessages.ERROR_MESSAGE_BASKET_FILE_VALIDATOR_UNABLE_TO_GET_RULES;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class BasketFileValidatorEngineTests {

    private static MultipartFile multipartFile;
    Map<TemplateFormat, Template> expectedResult;
    private BasketFileValidatorEngine engine;
    @Mock
    private BasketBookingTemplateConfig config;

    @BeforeAll
    static void init() {
        multipartFile = mock(MultipartFile.class);
    }

    @BeforeEach
    void setup() {
        engine = new BasketFileValidatorEngine(config);

        //Given
        expectedResult = new HashMap<>();
        expectedResult.put(TemplateFormat.COMPASSX, prepareCompassXTemplate());
    }

    @Test
    void givenAValidFile_whenValidate_thenReturnNoError() throws Exception {
        when(multipartFile.getSize()).thenReturn(123L);
        when(multipartFile.getOriginalFilename()).thenReturn("mutual_fund_bulk_order.csv");
        when(config.getValidationRules()).thenReturn(expectedResult);
        assertEquals("", engine.validateFile(multipartFile, TemplateFormat.COMPASSX));
    }

    @Test
    void givenAnInvalidFileSize_whenValidate_thenReturnError() throws Exception {
        when(multipartFile.getSize()).thenReturn(1234567L);
        when(config.getValidationRules()).thenReturn(expectedResult);
        assertEquals("File exceeds limit of 1 MB.",
            engine.validateFile(multipartFile, TemplateFormat.COMPASSX));
    }

    @Test
    void givenAnInvalidFileExtension_whenValidate_thenReturnError() throws Exception {
        when(multipartFile.getSize()).thenReturn(123L);
        when(multipartFile.getOriginalFilename()).thenReturn("mutual_fund_bulk_order.xxx");
        when(config.getValidationRules()).thenReturn(expectedResult);
        assertEquals("Incorrect File format (csv files only).",
            engine.validateFile(multipartFile, TemplateFormat.COMPASSX));
    }

    @Test
    void givenANullRuleMap_whenValidate_thenReturnError() throws Exception {
        when(config.getValidationRules()).thenReturn(null);
        assertEquals(ERROR_MESSAGE_BASKET_FILE_VALIDATOR_UNABLE_TO_GET_RULES,
            engine.validateFile(multipartFile, TemplateFormat.COMPASSX));
    }

    private Template prepareCompassXTemplate() {
        Template r2Template = new Template();
        r2Template.setTemplateName("compassX");
        r2Template.setFinancialInstrumentClassificationCode("MutualFund");
        r2Template.setMaxRows(10000);
        r2Template.setFileSize(1048576); // In Bytes
        r2Template.setFileFormat("csv");

        String[] headers = new String[]{"Account No*", "Trade type*", "Symbol", "From Symbol", "Amount Type*", "Amount*", "Solicitation", "Dividend Options", "Front Load %", "Additional Commission", "Net after commissions"};
        r2Template.setHeaderNames(headers);

        Field amountType = new Field();
        amountType.setFieldName("amountType");
        amountType.setHeaderName("Amount Type*");
        amountType.setSchemaField("orderHeader.amountTypeCode");
        amountType.setMandatory(true);
        List<String> acceptableValues = new ArrayList<>();
        acceptableValues.add("Quantity");
        acceptableValues.add("Amount");
        acceptableValues.add("All");
        acceptableValues.add("NDSC");
        acceptableValues.add("MUO");
        acceptableValues.add("10F");
        amountType.setCaseSensitiveAcceptableValues(acceptableValues);

        Field amount = new Field();
        amount.setFieldName("amount");
        amount.setHeaderName("Amount*");
        amount.setSchemaField("orderHeader.orderAmount");
        amount.setMandatory(false);
        Field[] fields = new Field[]{amountType, amount};

        r2Template.setFields(fields);

        return r2Template;
    }


}
