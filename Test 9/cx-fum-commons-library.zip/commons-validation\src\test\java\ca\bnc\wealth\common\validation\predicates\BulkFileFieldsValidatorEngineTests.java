package ca.bnc.wealth.common.validation.predicates;

import ca.bnc.wealth.common.core.config.BasketBookingTemplateConfig;
import ca.bnc.wealth.common.core.enums.TemplateFormat;
import ca.bnc.wealth.common.core.model.Field;
import ca.bnc.wealth.common.core.model.Template;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static ca.bnc.wealth.common.validation.constants.ErrorMessages.ERROR_MESSAGE_FIELD_IS_BLANK;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link BulkFileFieldsValidatorEngine}
 */
@RunWith(MockitoJUnitRunner.class)
public class BulkFileFieldsValidatorEngineTests extends FieldValidatorTestBase {

    @Mock
    private BasketBookingTemplateConfig basketBookingTemplateConfig;
    private BulkFileFieldsValidatorEngine bulkFileFieldsValidatorEngine;

    @Before
    public void before() {
        Field[] fields = generateTestFieldsForComprassX();
        Template template = new Template();
        template.setFields(fields);
        Map map = new HashMap();
        map.put(TemplateFormat.COMPASSX, template);
        when(basketBookingTemplateConfig.getValidationRules()).thenReturn(map);
        when(basketBookingTemplateConfig.getFieldsByTemplateFormat(TemplateFormat.COMPASSX)).thenReturn(Arrays.asList(fields));
        errorMessageToRowNumbers = generateErrorMessageToRowNumbersMap();

        List<Predicate<FileFieldValidatorContext>> validators = new ArrayList<>();
        validators.add(new MandatoryFieldValidator());

        bulkFileFieldsValidatorEngine = new BulkFileFieldsValidatorEngine(validators, basketBookingTemplateConfig);
    }

    @Test
    public void testWithValidRows() {
        List<Map<String, String>> rowMaps = parseFileToRowMap("src/test/resources/mutual_fund_bulk_order.csv");
        AtomicInteger rowNumber = new AtomicInteger(1);
        rowMaps.stream().forEach(row -> {
            try {
                bulkFileFieldsValidatorEngine.validate(row, rowNumber.getAndIncrement(),
                        TemplateFormat.COMPASSX, errorMessageToRowNumbers);
            } catch (Exception e) {
                fail(e);
            }
        });


        errorMessageToRowNumbers.keySet().stream().forEach(key -> {
            assertThat(errorMessageToRowNumbers.get(key)).isEmpty();
        });
    }

    @Test
    public void givenParseYamlAndAddFieldsMultipleTimes_whenValidate_thenOnlyOneFieldWillBeUsed() {
        // setup
        List<Map<String, String>> rowMaps = parseFileToRowMap("src/test/resources/mutual_fund_bulk_order_invalid.csv");
        AtomicInteger rowNumber = new AtomicInteger(1);
        rowMaps.stream().forEach(row -> {
            try {
                bulkFileFieldsValidatorEngine.validate(row, rowNumber.getAndIncrement(),
                        TemplateFormat.COMPASSX, errorMessageToRowNumbers);
            } catch (Exception e) {
                fail(e);
            }
        });

        assertEquals(1, errorMessageToRowNumbers.size());

        List<Long> rowsNumbers = errorMessageToRowNumbers.entrySet().stream()
                .filter(entry -> entry.getKey().equals(String.format(ERROR_MESSAGE_FIELD_IS_BLANK, TEST_ACCOUNT_NUMBER_HEADER_NAME)))
                .map(entry -> entry.getValue()).flatMap(List::stream)
                .collect(Collectors.toList());
        assertEquals(2, rowsNumbers.size());
        assertTrue(rowsNumbers.contains(4L));
        assertTrue(rowsNumbers.contains(5L));
    }

    @Test
    public void testWithInvalidFile() {
        List<Map<String, String>> rowMaps = parseFileToRowMap("src/test/resources/mutual_fund_bulk_order_invalid.csv");
        AtomicInteger rowNumber = new AtomicInteger(1);
        rowMaps.stream().forEach(row -> {
            try {
                bulkFileFieldsValidatorEngine.validate(row, rowNumber.getAndIncrement(),
                        TemplateFormat.COMPASSX, errorMessageToRowNumbers);
            } catch (Exception e) {
                fail(e);
            }
        });

        assertEquals(1, errorMessageToRowNumbers.size());

        List<Long> rowsNumbers = errorMessageToRowNumbers.entrySet().stream()
                .filter(entry -> entry.getKey().equals(String.format(ERROR_MESSAGE_FIELD_IS_BLANK, TEST_ACCOUNT_NUMBER_HEADER_NAME)))
                .map(entry -> entry.getValue()).flatMap(List::stream)
                .collect(Collectors.toList());
        assertEquals(2, rowsNumbers.size());
        assertTrue(rowsNumbers.contains(4L));
        assertTrue(rowsNumbers.contains(5L));
    }

    private Field[] generateTestFieldsForComprassX() {
        return new Field[]{generateAccountNumberField()};
    }

}
