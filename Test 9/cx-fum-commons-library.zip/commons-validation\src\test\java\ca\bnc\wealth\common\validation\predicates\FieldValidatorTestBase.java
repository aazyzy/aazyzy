package ca.bnc.wealth.common.validation.predicates;

import ca.bnc.wealth.common.core.model.Field;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * A base class for all the field validator unit tests.
 */
public class FieldValidatorTestBase {
    protected static final int VALID_ACCOUNT_NUMBER_LENGTH = 7;
    protected static final long DEFAULT_RECORD_NUMBER = 2L;
    protected static final String DEFAULT_SCHEMA = "TestSchema";
    protected final static String TEST_ACCOUNT_NUMBER_HEADER_NAME = "Account No*";

    protected Map<String, List<Long>> errorMessageToRowNumbers;
    protected String[] headers = new String[]{"Account No*", "Trade type*", "Symbol", "From Symbol", "Amount Type*", "Amount*", "Solicitation", "Dividend Options", "Front Load %", "Additional Commission", "Net after commissions", "Advisor Code"};

    protected Map<String, String> rowMap = Arrays.asList(headers).stream().collect(Collectors.toMap(header -> header, header -> ""));

    /**
     * Generate the error message to row number mapping for tests.
     *
     * @return the generated empty-ready map.
     */
    protected Map<String, List<Long>> generateErrorMessageToRowNumbersMap() {
        Map<String, List<Long>> errorMessageToRowNumbers = new HashMap<>();

        return errorMessageToRowNumbers;
    }

    /**
     * Verify for a given record number, there is an error message
     *
     * @param recordNumber the record row number
     * @param errorMessage the error message to be found
     */
    protected void verifyARowNumberWithErrorMessage(long recordNumber, String errorMessage) {
        assertThat(errorMessageToRowNumbers.get(errorMessage)).isNotEmpty();
        assertEquals(1, errorMessageToRowNumbers.get(errorMessage).size());
        assertEquals(recordNumber, errorMessageToRowNumbers.get(errorMessage).get(0));
    }

    protected Field generateAccountNumberField() {
        return Field.builder()
                .fieldName("accountNo")
                .headerName(TEST_ACCOUNT_NUMBER_HEADER_NAME)
                .mandatory(true)
                .schemaField("relatedAccount.accountNumber")
                .build();
    }

    /**
     * Parse the given test CSV file to a {@link List} of {@link Map} represents the file contents.
     * @param testFilePath the file path
     * @return the parsed {@link List} of {@link Map}
     */
    protected List<Map<String, String>> parseFileToRowMap(String testFilePath) {
        List<Map<String, String>> results = new ArrayList<>();
        try (InputStream csvFile = new FileInputStream(testFilePath);
             BufferedReader fileReader = new BufferedReader(new InputStreamReader(csvFile, StandardCharsets.UTF_8));
             CSVParser csvParser = new CSVParser(fileReader,
                     CSVFormat.RFC4180.builder().setHeader().setIgnoreHeaderCase(true)
                             .setSkipHeaderRecord(true).setTrim(true).build())
        ) {
            while (csvParser.iterator().hasNext()) {
                Map<String, String> eachRowMap = new HashMap<>();
                CSVRecord csvRecord = csvParser.iterator().next();
                rowMap.keySet().stream().forEach(key -> {
                    eachRowMap.put(key, csvRecord.get(key));
                });
                results.add(eachRowMap);
            }
        } catch (IOException e) {
            fail(e.getMessage());
        }

        return results;
    }

    /**
     * Prepare the {@link FileFieldValidatorContext} for test.
     * The context will be built with fieldName, headerName, schemaField
     * @param headerName the name of the header for the field
     * @param value the value to be set as a content in the csv file for the given header
     * @return the {@link FileFieldValidatorContext}
     */
    protected FileFieldValidatorContext prepareContext(String headerName, String value) {
        Field field = Field.builder().fieldName(headerName).headerName(headerName)
                .schemaField(DEFAULT_SCHEMA).build();
        FileFieldValidatorContext.FileFieldValidatorContextBuilder builder = FileFieldValidatorContext.builder();
        rowMap.put(headerName, value);
        builder.rowMap(rowMap).rowNumber(2).field(field).errorMessageToRowNumbers(errorMessageToRowNumbers);

        return builder.build();
    }

}