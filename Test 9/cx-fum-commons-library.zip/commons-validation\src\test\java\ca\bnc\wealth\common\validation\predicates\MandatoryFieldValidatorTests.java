package ca.bnc.wealth.common.validation.predicates;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static ca.bnc.wealth.common.validation.constants.ErrorMessages.ERROR_MESSAGE_FIELD_IS_BLANK;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for {@link MandatoryFieldValidator}
 */
@RunWith(MockitoJUnitRunner.class)
public class MandatoryFieldValidatorTests extends FieldValidatorTestBase {
    private MandatoryFieldValidator mandatoryFieldValidator;

    @Before
    public void before() {
        mandatoryFieldValidator = new MandatoryFieldValidator();
        errorMessageToRowNumbers = generateErrorMessageToRowNumbersMap();
    }

    @Test
    public void givenAValue_WhenValidate_ThenThereShouldBeNoErrors() {
        // setup
        FileFieldValidatorContext context = prepareContext(TEST_ACCOUNT_NUMBER_HEADER_NAME,
                RandomStringUtils.randomAlphabetic(VALID_ACCOUNT_NUMBER_LENGTH));
        context.getField().setMandatory(true);

        // execute
        boolean result = mandatoryFieldValidator.test(context);

        // verify
        assertThat(result).isTrue();
        errorMessageToRowNumbers.keySet().stream().forEach(key -> {
            assertThat(errorMessageToRowNumbers.get(key)).isEmpty();
        });
    }

    @Test
    public void givenANullValue_WhenValidate_ThenTheRightErrorMessageShouldReturn() {
        // setup
        FileFieldValidatorContext context = prepareContext(TEST_ACCOUNT_NUMBER_HEADER_NAME, null);
        context.getField().setMandatory(true);

        // execute
        boolean result = mandatoryFieldValidator.test(context);

        // verify
        assertThat(result).isFalse();
        verifyARowNumberWithErrorMessage(DEFAULT_RECORD_NUMBER, generateErrorKey());
    }

    @Test
    public void givenAnEmptyValue_WhenValidate_ThenTheRightErrorMessageShouldReturn() {
        // setup
        FileFieldValidatorContext context = prepareContext(TEST_ACCOUNT_NUMBER_HEADER_NAME, " ");
        context.getField().setMandatory(true);

        // execute
        boolean result = mandatoryFieldValidator.test(context);

        // verify
        assertThat(result).isFalse();
        verifyARowNumberWithErrorMessage(DEFAULT_RECORD_NUMBER, generateErrorKey());
    }

    private String generateErrorKey() {
        return String.format(ERROR_MESSAGE_FIELD_IS_BLANK, TEST_ACCOUNT_NUMBER_HEADER_NAME);
    }
}
