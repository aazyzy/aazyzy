# Changelog

## [5.0.2](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/compare/v5.0.1...v5.0.2) (2026-11-20)


### Bug Fixes

* rebuild image on base image java-25-1.2.2 ([#69](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/issues/69)) ([5510c88](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/5510c8867c5eaa23205084a52b08942b99194bb5))

## [5.0.1](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/compare/v5.0.0...v5.0.1) (2026-11-02)


### Miscellaneous Chores

* move to parent-pom-core 3.0.1, which fixes the Snyk findings of the 5.0.0 release: Tomcat 11.0.27, Jackson 3.2.4 and 2.22.4, Hibernate Validator 9.1.6.Final and java-jwt 4.6.2

## [5.0.0](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/compare/v4.0.1...v5.0.0) (2026-10-29)


### Miscellaneous Chores

* align develop versions with main after the 4.0.1 release ([#48](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/pull/48)) ([c563e86](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/c563e86f17e69a02c987290b011d1d8c6e7617aa))
* move firm-conf-api to Spring Boot 4.1.1 in develop ([#50](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/pull/50)) ([d69798d](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/d69798d6b83875622e4c7fbd19a60b9e6bee1ed3))
* skip Sonar in the release workflow on Java 25 ([#54](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/pull/54)) ([9656792](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/96567926d6c4bbfbb7552e6e54dc2fd004e38f8e))
* skip the SonarQube analysis for now ([#52](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/pull/52)) ([bd4367f](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/bd4367f431dc2c66f6496d384c0efe12757ea199))
* sync 6900 dependency versions to develop SNAPSHOTs ([#53](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/pull/53)) ([f00c6bb](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/f00c6bb5c60179aa57e6b7e108f53e8db3a1ddf3))

## [4.0.1](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/compare/v4.0.0...v4.0.1) (2026-10-14)


### Miscellaneous Chores

* remediate Snyk vulnerabilities on the 4.0 release line ([#44](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/issues/44)) ([c0ef02b](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/c0ef02bce7df12b6e5446bf42de88557f1c1362f))

## [4.0.0](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/compare/v3.2.0...v4.0.0) (2026-10-14)


### Miscellaneous Chores

* pin released 6900 dependency versions for release 4.0.0: commons-lib 2.1.42 (NWPI-15097), api-schemas-wealth 1.11.58 ([31cf6b6](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/31cf6b66f40780c5f7ea3a6058feb28e13a7cf58))

## [3.2.0](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/compare/v3.0.0...v3.2.0) (2026-09-16)


### Bug Fixes

* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([50c6596](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/50c6596595e63323c46868275a92e3a2ee7040c2))
* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([4ddd2e1](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/4ddd2e1a90af08884ba2dcd64a5324b9e7b374f9))


### Miscellaneous Chores

* pin released 6900 dependency versions for release 3.2.0 ([e2a04a0](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/e2a04a0c1e690ba10e0ef5c34597dede90e2b28b))

## [3.0.0](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/compare/v2.2.3...v3.0.0) (2026-08-19)


### Miscellaneous Chores

* release 3.0.0 ([2613815](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/26138150a43fe32563229395d1dd12dcbee2f97a))

## [2.2.3](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/compare/v2.2.2...v2.2.3) (2026-08-19)


### Bug Fixes

* **deps:** pin at.yawk.lz4:lz4-java 1.11.1 for CVE-2026-59949 ([#21](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/issues/21)) ([0ed66a7](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/0ed66a7b0d99128e0bc18667ab9fabd42c3e8e0e))
* **deps:** pin at.yawk.lz4:lz4-java 1.11.1 for CVE-2026-59949 ([#22](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/issues/22)) ([735ca47](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/735ca47bb762e3a160e60a7585d2be9c6e0bced4))
* **deps:** pin tomcat-embed 10.1.56 and logback-core 1.5.36 (Snyk HIGH) ([#15](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/issues/15)) ([3cd0fdc](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/3cd0fdc3a5d3a1ca349f87ec328723fb7c5ede0c))
* **deps:** pin vulnerable transitive dependencies for Snyk remediation ([#23](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/issues/23)) ([85700f1](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/85700f173b1a58c2904af8eec2679c5c9789c424))

## [2.2.2](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/compare/v2.2.1...v2.2.2) (2026-06-29)


### Bug Fixes

* release 2.2.1 ([6dd3998](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/6dd3998a40f314a938aec9515c09e14505282ce7))

## [2.2.1](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/compare/v2.2.0...v2.2.1) (2026-06-09)


### Bug Fixes

* first release in github ([4ec3199](https://github.com/NBC-GPMF/cx-fum-firm-conf-api/commit/4ec319976cfad6ade68ed1903fd140b02ee2f611))
