# Firm Configuration API (firm-conf-api)

> API to manage firm configuration, RR code range assignments, and feature packages for the BNC Wealth Management platform.

| Property | Value |
|----------|-------|
| **Artifact** | `ca.bnc.wealth.api:firm-conf-api` |
| **Version** | 2.1.4-SNAPSHOT |
| **Java** | 17 |
| **Framework** | Spring Boot 2.x + spring-microservice-starter 2.0.27 |
| **Context Path** | `/firm-conf` |
| **Port** | 8081 (production) / 8082 (local) |
| **Database** | PostgreSQL — `IAM_V2` schema |
| **App ID** | 6900-firm-api |

## Architecture

The service is part of the **6900 IAM Platform** — a suite of ~15 microservices managing identity, access, and configuration for wealth management firms and users.

```
                           ┌──────────────────────┐
                           │   firm-data-schema    │ (OpenAPI spec → generated interfaces)
                           └──────────┬───────────┘
┌──────────────────────────────────────▼─────────────────────────────────────────┐
│                         firm-conf-api (this service)                           │
│                                                                                │
│  Controllers:  FirmController                                                  │
│                │                                                               │
│  Services:     FirmServiceJpa            FirmValidationService                 │
│                FirmSearchService         FirmServiceBma                        │
│                AuditLogService                                                 │
│                                                                                │
│  Integrations: PostgreSQL (IAM_V2)  │  Kafka (audit events)                   │
│                Redis (cache)        │  Report API                             │
│                Bulk Management API  │                                          │
└────────────────────────────────────────────────────────────────────────────────┘
```

## REST Endpoints

### Firm Management (`FirmController` → `FirmApi`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/firms/assignments/users/me` | Get authenticated user's firm assignments |
| POST | `/firms/firmSearch` | Search firms (exact match) |
| POST | `/firms/genericSearch` | Generic firm search (CONTAINS-based) |
| POST | `/firms/genericSearchWithPagination` | Generic firm search with pagination |
| POST | `/firms/search` | Search firms by RR code ranges |
| PUT | `/firms/{firm-id}/assignments/rr-range` | Update RR code range assignments |
| PUT | `/firms/{firm-id}/assignments/feature-package` | Assign feature package (direct or BMA) |
| DELETE | `/firms/{firm-id}/assignments/{assignment-type}/{assignee-id}` | Delete firm assignment |
| GET | `/firms/{firm-id}/assignments` | Get firm assignments by type |

## Project Structure

```
src/main/java/ca/bnc/wealth/api/firm/
├── Application.java                    # Spring Boot entry point
├── config/
│   └── ServiceConfig.java              # Core component scanning
├── controller/
│   └── FirmController.java             # Firm management endpoints
├── dao/
│   ├── ReportRequestAdditionalCriteria.java  # S3 request DAO
│   └── RrCodeRangeDao.java             # RR code range DAO
├── jpa/
│   ├── FirmSearchCriteria.java         # Exact-match search criteria
│   └── GenericFirmSearchCriteria.java  # CONTAINS-based search criteria
├── kafka/
│   └── AuditLogEventPublisher.java     # Kafka audit event publisher
├── service/
│   ├── AuditLogService.java            # Audit before/after state capture
│   ├── FirmSearchService.java          # Dynamic firm search queries
│   ├── FirmServiceBma.java             # Bulk Management API integration
│   ├── FirmServiceJpa.java             # Core firm data access
│   └── FirmValidationService.java      # Input validation
└── util/
    ├── ApiUtil.java                    # Date/number utilities
    ├── EntityMapperUtils.java          # Entity ↔ DTO conversions
    ├── FirmConfigurationRowMapper.java # JDBC row mapper
    └── FirmConstants.java              # Error codes, SQL queries, constants
```

## Dependencies

### Shared Libraries (6900 Ecosystem)
| Library | Version | Purpose |
|---------|---------|---------|
| spring-microservice-starter | 2.0.27 | Base framework, CORS, security |
| firm-data-schema | 1.10.63 | OpenAPI models and API interfaces |
| commons-auth | 2.1.33 | OAuth2, token validation, system tokens |
| commons-jpa | 1.0.69 | JPA entities and repositories |
| commons-exception | 1.0.69 | Exception types (Validation, NotFound, Conflict) |
| commons-fum-utils | 1.0.69 | Firm/User service helpers, Redis cache |
| commons-kafka-model | 1.0.69 | Kafka event models, Messenger abstraction |
| commons-bma | 1.0.69 | Bulk Management API client |
| commons-report | 1.0.69 | Report API client (S3 operations) |
| commons-health-check | 1.0.69 | Health check endpoints |
| lib7461-messaging | 2.1.10 | Cross-project messaging (7461 documents) |
| commons-postgres | 2.1.33 | PostgreSQL JDBC configuration |

## How to Run Locally

### Prerequisites
- Java 17
- Maven 3.8.4+
- PostgreSQL running on `localhost:5432` (user: `postgres`)
- Kafka running on `localhost:9092`
- Redis running on `localhost:9999`

### Run
```bash
# Build
mvn clean package -DskipTests

# Run with local config
java -Dspring.config.additional-location=src/main/resources/application-local.yml \
     -jar target/firm-conf-api-exec.jar
```

### IDE (IntelliJ)
1. Run `Application.main()` once to generate run configuration
2. Edit Configuration → add VM Option:
   ```
   -Dspring.config.additional-location="src/main/resources/application-local.yml"
   ```

### Run Tests
```bash
mvn test
```

## CI/CD

- **Jenkins:** `wealthPipeline()` shared library
- **Docker:** Base image `docker-staging.bnc.ca/7461/compassx-base-docker-image:1.0.24`
- **Maven:** 3.8.4 with OpenJDK 17
- **Security Scanning:** Snyk enabled, IQ Server disabled

## AI Agent Configuration

- [Copilot Instructions](.github/copilot-instructions.md) — Project-wide coding conventions