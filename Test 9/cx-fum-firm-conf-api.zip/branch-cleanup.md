# Branch Cleanup Report: firm-api

Generated: 2026-06-08 19:19:26
Default Branch: develop
Total Branches: 40

---

## Summary

- Total Branches: 40
- Excluded from Deletion: 0
- Marked for Deletion: 40

---

## All Branches

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `master` | 2021-12-29 12:28:25 -0500 | 2021-12-29 12:28:25 -0500 | MERGED |
| `release/1.14` | 2023-12-07 16:50:57 -0500 | 2023-12-07 16:50:57 -0500 | MERGED |
| `feature/adding-secret-extractor` | 2024-01-29 17:37:31 -0500 | 2024-01-29 17:37:31 -0500 | MERGED |
| `release/1.15` | 2024-02-23 15:33:09 -0500 | 2024-02-23 15:33:09 -0500 | MERGED |
| `release/1.16` | 2024-03-20 10:41:22 -0400 | 2024-03-20 10:41:22 -0400 | MERGED |
| `release/1.16.2` | 2024-05-02 18:27:35 -0400 | 2024-05-02 18:27:35 -0400 | MERGED |
| `release/1.17` | 2024-05-15 15:29:43 -0400 | 2024-05-15 15:29:43 -0400 | MERGED |
| `release/1.18` | 2024-06-25 16:38:04 -0400 | 2024-06-25 16:38:04 -0400 | MERGED |
| `release/1.19` | 2024-08-22 21:00:49 -0400 | 2024-08-22 21:00:49 -0400 | MERGED |
| `release/1.20` | 2024-10-31 15:21:50 -0400 | 2024-10-31 15:21:50 -0400 | MERGED |
| `release/1.21` | 2024-12-15 23:01:05 -0500 | 2024-12-15 23:01:05 -0500 | MERGED |
| `release/1.21.1` | 2025-01-07 19:38:15 -0500 | 2025-01-07 19:38:15 -0500 | MERGED |
| `release/1.21.4` | 2025-03-11 13:49:56 -0400 | 2025-03-11 13:49:56 -0400 | MERGED |
| `release/1.24.0` | 2025-05-15 14:18:14 -0400 | 2025-05-15 14:18:14 -0400 | MERGED |
| `feature/NWPI-13635-update-fum-af10-endpoint` | 2025-06-28 08:40:48 -0400 | 2025-06-28 08:40:48 -0400 | MERGED |
| `feature/NWPI-13777-user-onboarding-user-skips-sms-authentication-backend` | 2025-07-22 12:28:19 -0400 | 2025-07-22 12:28:19 -0400 | MERGED |
| `feature/NWPI-13843-update-firm-assignments-endpoint-to-return-resources` | 2025-08-16 21:53:02 -0400 | 2025-08-16 21:53:02 -0400 | MERGED |
| `feature/NWPI-13843-update-firm-assignments-endpoint-1` | 2025-08-19 09:25:08 -0400 | 2025-08-19 09:25:08 -0400 | MERGED |
| `release/1.26.0` | 2025-08-19 12:25:26 -0400 | 2025-08-19 12:25:26 -0400 | MERGED |
| `feature/NWPI-14002` | 2025-10-15 14:32:59 -0400 | 2025-10-15 14:32:59 -0400 | MERGED |
| `feature/NWPI-14000` | 2025-10-17 14:16:56 -0400 | 2025-10-17 14:16:56 -0400 | MERGED |
| `feature/NWPI-14000_2` | 2025-10-17 14:43:46 -0400 | 2025-10-17 14:43:46 -0400 | MERGED |
| `feature/NWPI-14013-afa4-get-firm-config-api-attestations-display-based-on-labels` | 2025-10-19 17:43:41 -0400 | 2025-10-19 17:43:41 -0400 | MERGED |
| `feature/NWPI-14000_1` | 2025-10-24 14:04:33 -0400 | 2025-10-24 14:04:33 -0400 | MERGED |
| `NWPI-14087-afa18-delete-firm-attestation` | 2025-10-26 08:26:26 -0400 | 2025-10-26 08:26:26 -0400 | MERGED |
| `feature/NWPI-14054-afa11-acknowledge-firm-attestation` | 2025-10-26 08:26:26 -0400 | 2025-10-26 08:26:26 -0400 | MERGED |
| `feature/NWPI-14066` | 2025-10-30 10:31:26 -0400 | 2025-10-30 10:31:26 -0400 | MERGED |
| `release/1.28.0` | 2025-11-10 16:02:12 -0500 | 2025-11-10 16:02:12 -0500 | MERGED |
| `feature/NWPI-13977` | 2025-11-13 10:24:01 -0500 | 2025-11-13 10:24:01 -0500 | MERGED |
| `feature/NWPI-14088-afa17-get-attestation-info` | 2025-11-13 14:17:10 -0500 | 2025-11-13 14:17:10 -0500 | MERGED |
| `feature/NWPI-14088-afa17-get-attestation-info-1` | 2025-11-13 16:20:20 -0500 | 2025-11-13 16:20:20 -0500 | MERGED |
| `NWPI-14170-enhance-sorting-of-attestation-lists-back-end-afa4` | 2025-11-21 16:34:22 -0500 | 2025-11-21 16:34:22 -0500 | MERGED |
| `feature/NWPI-14170-enhance-sorting-of-attestation-lists-back-end-afa4-1` | 2025-12-04 10:54:29 -0500 | 2025-12-04 10:54:29 -0500 | MERGED |
| `feature/NWPI-14278-create-attestation-api-performance-fixes` | 2025-12-23 15:08:22 -0500 | 2025-12-23 15:08:22 -0500 | MERGED |
| `feature/NWPI-1-14278-create-attestation-api-performance-fixes` | 2026-01-13 14:56:36 -0500 | 2026-01-13 14:56:36 -0500 | MERGED |
| `release/2.1.0` | 2026-01-16 17:20:05 -0500 | 2026-01-16 17:20:05 -0500 | MERGED |
| `feature/NWPI-14270-firm-attestation-list-is-taking-long-time-to-load-for-nbin-firm` | 2026-02-06 14:40:48 -0500 | 2026-02-06 14:40:48 -0500 | MERGED |
| `feature/NWPI-14053-move-attestation-end-points-related-to-ui-into-a-separate-project` | 2026-03-23 16:48:00 -0400 | 2026-03-23 16:48:00 -0400 | MERGED |
| `release/2.1.1` | 2026-04-11 11:45:56 -0400 | 2026-04-11 11:45:56 -0400 | MERGED |
| `release/2.2.0` | 2026-05-15 10:38:50 -0400 | 2026-05-15 10:38:50 -0400 | MERGED |

---

## Excluded from Deletion

Criteria: Unmerged branches with last commit less than 2 months old
Count: 0

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| No branches excluded | | | |

---

## Marked for Deletion

Criteria: All merged branches + unmerged branches with last commit older than 2 months
Count: 40

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `master` | 2021-12-29 12:28:25 -0500 | 2021-12-29 12:28:25 -0500 | MERGED |
| `release/1.14` | 2023-12-07 16:50:57 -0500 | 2023-12-07 16:50:57 -0500 | MERGED |
| `feature/adding-secret-extractor` | 2024-01-29 17:37:31 -0500 | 2024-01-29 17:37:31 -0500 | MERGED |
| `release/1.15` | 2024-02-23 15:33:09 -0500 | 2024-02-23 15:33:09 -0500 | MERGED |
| `release/1.16` | 2024-03-20 10:41:22 -0400 | 2024-03-20 10:41:22 -0400 | MERGED |
| `release/1.16.2` | 2024-05-02 18:27:35 -0400 | 2024-05-02 18:27:35 -0400 | MERGED |
| `release/1.17` | 2024-05-15 15:29:43 -0400 | 2024-05-15 15:29:43 -0400 | MERGED |
| `release/1.18` | 2024-06-25 16:38:04 -0400 | 2024-06-25 16:38:04 -0400 | MERGED |
| `release/1.19` | 2024-08-22 21:00:49 -0400 | 2024-08-22 21:00:49 -0400 | MERGED |
| `release/1.20` | 2024-10-31 15:21:50 -0400 | 2024-10-31 15:21:50 -0400 | MERGED |
| `release/1.21` | 2024-12-15 23:01:05 -0500 | 2024-12-15 23:01:05 -0500 | MERGED |
| `release/1.21.1` | 2025-01-07 19:38:15 -0500 | 2025-01-07 19:38:15 -0500 | MERGED |
| `release/1.21.4` | 2025-03-11 13:49:56 -0400 | 2025-03-11 13:49:56 -0400 | MERGED |
| `release/1.24.0` | 2025-05-15 14:18:14 -0400 | 2025-05-15 14:18:14 -0400 | MERGED |
| `feature/NWPI-13635-update-fum-af10-endpoint` | 2025-06-28 08:40:48 -0400 | 2025-06-28 08:40:48 -0400 | MERGED |
| `feature/NWPI-13777-user-onboarding-user-skips-sms-authentication-backend` | 2025-07-22 12:28:19 -0400 | 2025-07-22 12:28:19 -0400 | MERGED |
| `feature/NWPI-13843-update-firm-assignments-endpoint-to-return-resources` | 2025-08-16 21:53:02 -0400 | 2025-08-16 21:53:02 -0400 | MERGED |
| `feature/NWPI-13843-update-firm-assignments-endpoint-1` | 2025-08-19 09:25:08 -0400 | 2025-08-19 09:25:08 -0400 | MERGED |
| `release/1.26.0` | 2025-08-19 12:25:26 -0400 | 2025-08-19 12:25:26 -0400 | MERGED |
| `feature/NWPI-14002` | 2025-10-15 14:32:59 -0400 | 2025-10-15 14:32:59 -0400 | MERGED |
| `feature/NWPI-14000` | 2025-10-17 14:16:56 -0400 | 2025-10-17 14:16:56 -0400 | MERGED |
| `feature/NWPI-14000_2` | 2025-10-17 14:43:46 -0400 | 2025-10-17 14:43:46 -0400 | MERGED |
| `feature/NWPI-14013-afa4-get-firm-config-api-attestations-display-based-on-labels` | 2025-10-19 17:43:41 -0400 | 2025-10-19 17:43:41 -0400 | MERGED |
| `feature/NWPI-14000_1` | 2025-10-24 14:04:33 -0400 | 2025-10-24 14:04:33 -0400 | MERGED |
| `NWPI-14087-afa18-delete-firm-attestation` | 2025-10-26 08:26:26 -0400 | 2025-10-26 08:26:26 -0400 | MERGED |
| `feature/NWPI-14054-afa11-acknowledge-firm-attestation` | 2025-10-26 08:26:26 -0400 | 2025-10-26 08:26:26 -0400 | MERGED |
| `feature/NWPI-14066` | 2025-10-30 10:31:26 -0400 | 2025-10-30 10:31:26 -0400 | MERGED |
| `release/1.28.0` | 2025-11-10 16:02:12 -0500 | 2025-11-10 16:02:12 -0500 | MERGED |
| `feature/NWPI-13977` | 2025-11-13 10:24:01 -0500 | 2025-11-13 10:24:01 -0500 | MERGED |
| `feature/NWPI-14088-afa17-get-attestation-info` | 2025-11-13 14:17:10 -0500 | 2025-11-13 14:17:10 -0500 | MERGED |
| `feature/NWPI-14088-afa17-get-attestation-info-1` | 2025-11-13 16:20:20 -0500 | 2025-11-13 16:20:20 -0500 | MERGED |
| `NWPI-14170-enhance-sorting-of-attestation-lists-back-end-afa4` | 2025-11-21 16:34:22 -0500 | 2025-11-21 16:34:22 -0500 | MERGED |
| `feature/NWPI-14170-enhance-sorting-of-attestation-lists-back-end-afa4-1` | 2025-12-04 10:54:29 -0500 | 2025-12-04 10:54:29 -0500 | MERGED |
| `feature/NWPI-14278-create-attestation-api-performance-fixes` | 2025-12-23 15:08:22 -0500 | 2025-12-23 15:08:22 -0500 | MERGED |
| `feature/NWPI-1-14278-create-attestation-api-performance-fixes` | 2026-01-13 14:56:36 -0500 | 2026-01-13 14:56:36 -0500 | MERGED |
| `release/2.1.0` | 2026-01-16 17:20:05 -0500 | 2026-01-16 17:20:05 -0500 | MERGED |
| `feature/NWPI-14270-firm-attestation-list-is-taking-long-time-to-load-for-nbin-firm` | 2026-02-06 14:40:48 -0500 | 2026-02-06 14:40:48 -0500 | MERGED |
| `feature/NWPI-14053-move-attestation-end-points-related-to-ui-into-a-separate-project` | 2026-03-23 16:48:00 -0400 | 2026-03-23 16:48:00 -0400 | MERGED |
| `release/2.1.1` | 2026-04-11 11:45:56 -0400 | 2026-04-11 11:45:56 -0400 | MERGED |
| `release/2.2.0` | 2026-05-15 10:38:50 -0400 | 2026-05-15 10:38:50 -0400 | MERGED |

---

## Deletion Results

Total Attempted: 40
Successfully Deleted: 40
Failed: 0
Skipped (Excluded Safety Gate): 0
