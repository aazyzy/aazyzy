# Source Code — Firm Configuration API

## Main Application

### Package: `ca.bnc.wealth.api.firm`

The Spring Boot application with component scanning across:
- `ca.bnc.wealth.api.*` — This service's components
- `ca.bnc.wealth.common.kafka.*` — Kafka messaging
- `ca.bnc.wealth.common.exception.*` — Exception handling
- `ca.bnc.wealth.common.fum.*` — FUM utilities (firm/user service helpers)
- `ca.bnc.wealth.common.core.cors` — CORS configuration
- `ca.bnc.wealth.common.health.*` — Health checks
- `ca.bnc.wealth.common.jpa.*` — JPA entities and repositories
- `ca.bnc.wealth.common.bma.*` — Bulk Management API
- `ca.bnc.wealth.common.report.*` — Report API client

JPA repositories scanned from `ca.bnc.wealth.common.jpa.repo` and entities from `ca.bnc.wealth.common.jpa.entity`.

## Package Overview

| Package | Classes | Responsibility |
|---------|---------|---------------|
| `controller/` | FirmController | REST API entry points implementing generated interfaces |
| `service/` | FirmServiceJpa, FirmSearchService, FirmValidationService, AuditLogService, FirmServiceBma | Business logic layer |
| `config/` | ServiceConfig | Spring configuration |
| `dao/` | RrCodeRangeDao, ReportRequestAdditionalCriteria | Data access POJOs |
| `jpa/` | FirmSearchCriteria, GenericFirmSearchCriteria | JPA search criteria enums |
| `kafka/` | AuditLogEventPublisher | Kafka message publishing |
| `util/` | ApiUtil, EntityMapperUtils, FirmConfigurationRowMapper, FirmConstants | Utilities and constants |
