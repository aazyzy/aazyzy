package ca.bnc.wealth.api.firm.controller;

import ca.bnc.wealth.common.bma.service.BulkManagementApiCallBack;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.firm.service.AuditLogService;
import ca.bnc.wealth.api.firm.service.FirmSearchService;
import ca.bnc.wealth.api.firm.service.FirmServiceBma;
import ca.bnc.wealth.api.firm.service.FirmServiceJpa;
import ca.bnc.wealth.api.firm.service.FirmValidationService;
import ca.bnc.wealth.api.firm.util.FirmConstants;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.firm.api.FirmApi;
import ca.bnc.wealth.common.firm.model.Assignment;
import ca.bnc.wealth.common.firm.model.FeaturePackageAssignment;
import ca.bnc.wealth.common.firm.model.Firm;
import ca.bnc.wealth.common.firm.model.FirmAssignmentType;
import ca.bnc.wealth.common.firm.model.FirmIdHierarchy;
import ca.bnc.wealth.common.firm.model.FirmSearch;
import ca.bnc.wealth.common.firm.model.GenericSearch;
import ca.bnc.wealth.common.firm.model.GenericSearchResponse;
import ca.bnc.wealth.common.firm.model.SearchPayload;
import ca.bnc.wealth.common.firm.model.UpdateRRCodeRange;
import ca.bnc.wealth.common.fum.service.FirmAssignmentService;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
public class FirmController implements FirmApi {

  private final FirmServiceJpa firmServiceJpa;

  private final FirmSearchService firmSearchService;
  private final FirmValidationService firmValidationService;

  private final UserAssignmentService userAssignmentService;
  private final FirmAssignmentService firmAssignmentService;

  private final AuditLogService auditLogService;
  private final FirmServiceBma firmServiceBma;

  @Override
  public ResponseEntity<Firm> getUserFirmAssignments(String authorization) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getUserFirmAssignments # Start: idpSubject: {}", user.getIdpSubject());
    Firm firmInfo = firmServiceJpa.getUserFirmAssignments(user.getIdpSubject());

    return new ResponseEntity<>(firmInfo, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<List<Firm>> firmSearch(String authorization, FirmSearch firmSearch) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("firmSearch # Start: user={}", user.getIdpSubject());

    List<Firm> lst = this.firmSearchService.searchFirm(user.getIdpSubject(), firmSearch);
    return new ResponseEntity<>(lst, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<List<Firm>> genericSearch(String authorization,
      GenericSearch genericSearch) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("genericSearch # Start: user={}", user.getIdpSubject());
    List<Firm> lst = this.firmSearchService.genericFirmSearch(user.getIdpSubject(), genericSearch)
        .getFirms();
    return new ResponseEntity<>(lst, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<GenericSearchResponse> genericSearchWithPagination(String authorization,
      GenericSearch genericSearch) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("genericSearchWithPagination # Start: user={}", user.getIdpSubject());
    GenericSearchResponse response = this.firmSearchService.genericFirmSearch(user.getIdpSubject(),
        genericSearch);
    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<List<FirmIdHierarchy>> getFirmByRRCodeRangeAndB10RRCodeRange(
      String authorization,
      SearchPayload searchPayload) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getFirmByRRCodeRangeAndB10RRCodeRange # Start: user={}", user.getIdpSubject());
    return new ResponseEntity<>(
        this.firmSearchService.getFirmByRRCodeRangeAndB10RRCodeRange(user.getIdpSubject(),
            searchPayload),
        HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Void> assignmentsRrRangeToFirm(String firmId,
      UpdateRRCodeRange updateRRCodeRangeRequest) {
    validateFirmId(firmId);
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("updateRRCodes # Start: user={}, firmId={}, rrRangeCount={}",
        user.getIdpSubject(), firmId,
        updateRRCodeRangeRequest != null && updateRRCodeRangeRequest.getRrRanges() != null
            ? updateRRCodeRangeRequest.getRrRanges().size() : 0);
    auditLogService.publishFirmUpdateAuditLog(firmId, () -> {
      firmValidationService.validateUpdateRrCodeRangeInput(updateRRCodeRangeRequest);
      firmServiceJpa.assignmentsRrRangeToFirm(user.getIdpSubject(), firmId, updateRRCodeRangeRequest);

      userAssignmentService.refreshUserRrCode(firmId, user.getIdpSubject());

      firmServiceJpa.refreshUserSearchMaterializedView(false);
    });
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  @BulkManagementApiCallBack
  public ResponseEntity<Firm> assignmentsFeaturePackageToFirm(String authorization, String firmId,
      FeaturePackageAssignment featurePackageAssignment, Boolean useBMA) {
    validateFirmId(firmId);
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    if (useBMA != null && useBMA) {
      firmServiceBma.assignmentsFeaturePackageToFirm(firmId, featurePackageAssignment);
    } else {
      auditLogService.publishFirmUpdateAuditLog(firmId, () -> {
        firmServiceJpa.assignmentsFeaturePackageToFirm(user.getIdpSubject(), firmId,
            featurePackageAssignment);
        userAssignmentService.refreshUserRrCode(firmId, user.getIdpSubject());

        firmServiceJpa.refreshUserSearchMaterializedView(false);
      });
    }

    return new ResponseEntity<>(firmServiceJpa.getFirmByFirmId(firmId), HttpStatus.CREATED);
  }

  @Override
  public ResponseEntity<Void> deleteFirmAssignment(
      String authorization, String firmId, FirmAssignmentType assignmentType, Integer assigneeId) {
    validateFirmId(firmId);
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    firmAssignmentService.deleteFirmAssignment(firmId, assignmentType.name(), assigneeId, user.getIdpSubject());
    userAssignmentService.refreshUserAssignment(UserAssignmentType.R, firmId, user.getIdpSubject());

    firmServiceJpa.refreshUserSearchMaterializedView(false);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<List<Assignment>> getFirmAssignments(String firmId, List<FirmAssignmentType> assignmentTypes) {
    validateFirmId(firmId);
    List<Assignment> assignments = firmServiceJpa.getFirmAssignments(firmId, assignmentTypes);
    return new ResponseEntity<>(assignments, HttpStatus.OK);
  }

  private void validateFirmId(String firmId) {
    if (firmId == null || firmId.isBlank() || !firmId.matches(FirmConstants.FIRM_ID_PATTERN)) {
      log.warn("INVALID_FIRM_ID: firmId={}", firmId);
      throw new FumValidationException(
          FirmConstants.INVALID_FIRM_ID_CODE, FirmConstants.INVALID_FIRM_ID_MESSAGE);
    }
  }

}