package ca.bnc.wealth.api.firm.dao;

import lombok.Data;

@Data
public class ReportRequestAdditionalCriteria {

  private String s3SubPrefix;
}
