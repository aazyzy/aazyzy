package ca.bnc.wealth.api.firm.dao;

import java.sql.Timestamp;
import lombok.Data;

@Data
public class RrCodeRangeDao {

  private long rrCodeRangeId;
  private String fromRrCode;
  private String toRrCode;
  private Boolean active;
  private Timestamp effectiveDate;
  private Timestamp expiryDate;
}
