package ca.bnc.wealth.api.firm.jpa;

import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.jpa.utils.GenericQuery;
import jakarta.persistence.criteria.JoinType;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum FirmSearchCriteria implements GenericQuery {
  firmEntityId(EnumQueryCriteria.IN, "firmEntityId", null, null),
  name(EnumQueryCriteria.IGNORE_CASE_EQUALS, "name", null, null),
  firmId(EnumQueryCriteria.IGNORE_CASE_EQUALS, "firmId", null, null),
  firmType(EnumQueryCriteria.IGNORE_CASE_EQUALS, "firmType", null, null),
  description(EnumQueryCriteria.IGNORE_CASE_EQUALS, "description", null,
      null),
  brokerCode(EnumQueryCriteria.IGNORE_CASE_EQUALS, "financialEntity.brokerCode", null, null),
  brokerNo(EnumQueryCriteria.IGNORE_CASE_EQUALS, "financialEntity.bNumber", null, null),
  branchNo(EnumQueryCriteria.IGNORE_CASE_EQUALS, "financialEntity.dealerCode", null, null),
  firmStatus(EnumQueryCriteria.IGNORE_CASE_EQUALS, "state", null, null),
  firmIdByIdpUserSubject(EnumQueryCriteria.IN, "firmEntityId", null, null);

  private EnumQueryCriteria criteria;
  private String field;
  private Object defaultValue;
  private JoinType[] joinTypes;

  @Override
  public EnumQueryCriteria getCriteria() {
    return this.criteria;
  }

  @Override
  public String getEntityField() {
    return this.field;
  }

  @Override
  public Object getDefaultValue() {
    return this.defaultValue;
  }

  @Override
  public JoinType[] getJoinTypes() {
    return this.joinTypes;
  }
}
