package ca.bnc.wealth.api.firm.jpa;

import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.jpa.utils.GenericQuery;
import jakarta.persistence.criteria.JoinType;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum GenericFirmSearchCriteria implements GenericQuery {
  firmEntityId(EnumQueryCriteria.EQUALS, "firmEntityId", null, null),
  name(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "name", null, null),
  firmId(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "firmId", null, null),
  type(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "firmType", null, null),
  description(
      EnumQueryCriteria.IGNORE_CASE_CONTAINS, "description", null, null),
  brokerCode(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "financialEntity.brokerCode", null, null),
  brokerNo(EnumQueryCriteria.IGNORE_CASE_EQUALS, "financialEntity.branchNumber", null, null),
  branchNo(EnumQueryCriteria.IGNORE_CASE_EQUALS, "financialEntity.dealerCode", null, null),
  firmIdByIdpUserSubject(EnumQueryCriteria.IN, "firmEntityId", null, null),
  state(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "state", null, null);

  private EnumQueryCriteria criteria;
  private String field;
  private Object defaultValue;
  private JoinType[] joinTypes;

  @Override
  public EnumQueryCriteria getCriteria() {
    return this.criteria;
  }

  @Override
  public String getEntityField() {
    return this.field;
  }

  @Override
  public Object getDefaultValue() {
    return this.defaultValue;
  }

  @Override
  public JoinType[] getJoinTypes() {
    return this.joinTypes;
  }
}
