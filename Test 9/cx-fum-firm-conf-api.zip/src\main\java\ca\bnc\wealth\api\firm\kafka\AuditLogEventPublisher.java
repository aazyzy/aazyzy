package ca.bnc.wealth.api.firm.kafka;

import ca.bnc.wealth.common.kafka.model.EventMessages;
import ca.bnc.wealth.common.kafka.model.audit.AuditUserConfigPayLoad;
import ca.bnc.wealth.common.messenger.MessagingType;
import ca.bnc.wealth.common.messenger.Messenger;
import ca.bnc.wealth.common.messenger.config.KafkaConfig;
import ca.bnc.wealth.common.messenger.config.KafkaMessenger;
import ca.bnc.wealth.common.messenger.model.KafkaMessage;
import tools.jackson.databind.ObjectMapper;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.util.Optional;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class AuditLogEventPublisher {
  @Value("${kafka.core.bootstrap-server}")
  private String kafkaBootstrapServer;

  @Value("${kafka.core.security-protocol}")
  private String kafkaSecurityProtocol;

  @Value("${kafka.core.api-key}")
  private String kafkaApiKey;

  @Value("${kafka.core.api-secret}")
  private String kafkaApiSecret;

  @Value("${kafka.producers.UserAuditData.topic}")
  private String topicName;

  @Autowired
  private ObjectMapper objectMapper;

  private Messenger messager;

  @PostConstruct
  public void init()
      throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {
    if ("PLAINTEXT".equalsIgnoreCase(kafkaSecurityProtocol)) {
      log.error("INSECURE_KAFKA_TRANSPORT: protocol=PLAINTEXT");
    }
    KafkaMessenger kafkaProducerConfig = KafkaMessenger.builder()
        .provider(MessagingType.KAFKA_PRODUCER)
        .queue(topicName)
        .build();
    KafkaConfig kafkaServer = KafkaConfig.builder()
        .bootstrapServer(kafkaBootstrapServer)
        .apiKey(kafkaApiKey)
        .apiSecret(kafkaApiSecret)
        .securityProtocol(kafkaSecurityProtocol)
        .saslMechanism("PLAIN")
        .messenger(kafkaProducerConfig)
        .build();

    Messenger.MessengerBuilder<String, String, byte[]> builder = Messenger.builder();
    messager = builder.type(MessagingType.KAFKA_PRODUCER)
        .kafkaConfig(kafkaServer)
        .producerConverter(() -> (String data) ->{
          return  data != null ? data.getBytes(StandardCharsets.UTF_8) : null;
        })
        .build();
  }

  public void publish(EventMessages<AuditUserConfigPayLoad> originalMessage) {
    try {

      KafkaMessage message = KafkaMessage.builder().message(objectMapper.writeValueAsString(originalMessage)).key("key").build();
      messager.process(message);
    } catch (Exception e) {
      log.error("AUDIT_PUBLISH_FAILED: error={}", e.getMessage(), e);
    }
  }
}
