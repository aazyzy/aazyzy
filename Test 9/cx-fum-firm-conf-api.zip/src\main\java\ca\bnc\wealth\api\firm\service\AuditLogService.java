package ca.bnc.wealth.api.firm.service;

import ca.bnc.wealth.api.firm.kafka.AuditLogEventPublisher;
import ca.bnc.wealth.common.fum.model.FirmPreferencesEnum;
import ca.bnc.wealth.common.fum.model.UserPreferencesEnum;
import ca.bnc.wealth.common.fum.model.UserStatusEnum;
import ca.bnc.wealth.common.fum.service.UserServiceHelper;
import ca.bnc.wealth.common.jpa.entity.enums.AuditEventType;
import ca.bnc.wealth.common.kafka.model.EventMessages;
import ca.bnc.wealth.common.kafka.model.Header;
import ca.bnc.wealth.common.kafka.model.audit.AuditUserConfigPayLoad;
import ca.bnc.wealth.common.userconfiguration.model.FeaturePackage;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import jakarta.annotation.PreDestroy;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;
import tools.jackson.core.JacksonException;

@Service
@Slf4j
public class AuditLogService {

  public static final String GET_MODULE_OVERRIDES_QUERY = """
      select * from "IAM_V2".fn_getFirmLevelAccess_moduleOverride_features(CAST(STRING_TO_ARRAY((:idpSubjects),',') AS VARCHAR[]))
  """;
  public static final String GET_USER_RESOURCES_BY_IDP_SUBJECT_QUERY = """
      select ua."IDP_SUBJECT", r."NAME", r."RESTRICTION" from "IAM_V2"."USER_ASSIGNMENT" ua 
          inner join "IAM_V2"."RESOURCE" r on ua."ASSIGNEE_ID" = r."RESOURCE_ID"  and ua."ASSIGNMENT_TYPE" = 'S'
              where ua."IDP_SUBJECT" in (:idpSubjects);
  """;

  public static final String GET_USER_RR_CODE_BY_IDP_SUBJECT_QUERY = """
      select ua."IDP_SUBJECT", rr."FROM_RR_CODE", rr."TO_RR_CODE" from "IAM_V2"."USER_ASSIGNMENT" ua
          inner join "IAM_V2"."RR_CODE_RANGE" rr on ua."ASSIGNEE_ID" = rr."RR_CODE_RANGE_ID"  and ua."ASSIGNMENT_TYPE" = 'R'
              where ua."IDP_SUBJECT" in (:idpSubjects);
  """;
  public static final String GET_USER_FROM_MV_BY_FIRM_ID_QUERY = """
  select *
  from
    "IAM_V2"."USER_CONFIGURATION_LIVE" ucm
  where
    ucm."FIRM_ID" = :firmId
  """;

  @Autowired
  private UserServiceHelper userServiceHelper;

  @Autowired
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @Autowired
  private AuditLogEventPublisher auditLogEventPublisher;

  @Value("${userConfiguration.audit.enable:true}")
  private boolean enableUserConfigAudit;
  @Value("${userConfiguration.audit.batchSize:100}")
  private int auditBatchSize;

  private ExecutorService executorService = Executors.newFixedThreadPool(2);

  @PreDestroy
  public void shutdownExecutor() {
    log.info("AUDIT_EXECUTOR_SHUTDOWN: awaitingTerminationSeconds={}", 30);
    executorService.shutdown();
    try {
      if (!executorService.awaitTermination(30, TimeUnit.SECONDS)) {
        executorService.shutdownNow();
      }
    } catch (InterruptedException e) {
      executorService.shutdownNow();
      Thread.currentThread().interrupt();
    }
  }


  public void publishFirmUpdateAuditLog(String firmId, Runnable runnable) {
    try {
      List<UserConfiguration> beforeUserconfigurationList = enableUserConfigAudit ?  new ArrayList<>(getUseCofigurations(firmId).values()) : new ArrayList<>();

      runnable.run();

      if(enableUserConfigAudit) {
        this.publishMessages(firmId, beforeUserconfigurationList);
      }
    } catch (Exception exception) {
      log.warn("Failed to publish audit log, details: " +  exception.getMessage());
      throw exception;
    }
  }

  private void publishMessages(String firmId, List<UserConfiguration> beforeUserconfigurationList) {
    Map<String, UserConfiguration> afterUserconfigurationMap =  getUseCofigurations(firmId);
    executorService.submit(() -> {
      try {
        beforeUserconfigurationList.forEach(beforeUserConfiguration ->{
          UserConfiguration afterUserconfiguration = afterUserconfigurationMap.get(beforeUserConfiguration.getIdpSubject());
          if(afterUserconfiguration != null) {
            EventMessages<AuditUserConfigPayLoad> messages = getEventMessage(AuditEventType.UPDATE_BY_FIRM.name(),  beforeUserConfiguration, afterUserconfiguration);
            publishMessages(messages);
          }
        });
      } catch (Exception e) {
        log.error("AUDIT_PUBLISH_FAILED: firmId={}, error={}", firmId, e.getMessage(), e);
      }
    });
  }

  private Map<String, UserConfiguration> getUseCofigurations(String firmId) {
    Map<String, UserConfiguration> userConfigurationMap = new HashMap<>();
    List<String> idpSubjects = new ArrayList<>();
    try {
      SqlParameterSource parameters = new MapSqlParameterSource().addValue("firmId", firmId);
      List<Map<String, Object>> userMapList = namedParameterJdbcTemplate.queryForList(GET_USER_FROM_MV_BY_FIRM_ID_QUERY, parameters);
      userMapList.forEach(map -> {
            UserConfiguration userConfiguration = toDto(map);
            userConfiguration.setRrCodeRanges(new ArrayList<>());
            userConfiguration.setResources(new ArrayList<>());
            userConfiguration.setRestrictedResources(new ArrayList<>());
            FeaturePackage featurePackage = new FeaturePackage();
            featurePackage.setPackageName(userConfiguration.getUserRole());
            userConfiguration.setFeaturePackage(featurePackage);
            userConfigurationMap.put(userConfiguration.getIdpSubject(), userConfiguration);
            idpSubjects.add(userConfiguration.getIdpSubject());
          });

      for (List<String> subIdpSubjectlist : ListUtils.partition(idpSubjects, auditBatchSize)) {
        updateRrCode(subIdpSubjectlist, userConfigurationMap);
        updateFeaturePackages(subIdpSubjectlist, userConfigurationMap);
        updateResources(subIdpSubjectlist, userConfigurationMap);
      }
    } catch (Exception e) {
      log.warn("Error while fetching user configurations for firmId: {}", firmId, e);
    }
    return userConfigurationMap;
  }

  private void updateRrCode(List<String> subIdpSubjectlist, Map<String, UserConfiguration> userConfigurationMap) {
    SqlParameterSource userParameters = new MapSqlParameterSource()
        .addValue("idpSubjects", subIdpSubjectlist);
    List<Map<String, Object>> userMapList = namedParameterJdbcTemplate.queryForList(GET_USER_RR_CODE_BY_IDP_SUBJECT_QUERY, userParameters);
    userMapList.forEach(map -> {
      String idpSubject = getStringValue(map.get("IDP_SUBJECT"));
      String fromRrCode = getStringValue(map.get("FROM_RR_CODE"));
      String toRrCode = getStringValue(map.get("TO_RR_CODE"));
      userConfigurationMap.get(idpSubject).getRrCodeRanges().add(RRCodeRange.builder().fromRRCode(fromRrCode).toRRCode(toRrCode).build());
    });
  }

  private void updateFeaturePackages(List<String> subIdpSubjectlist, Map<String, UserConfiguration> userConfigurationMap) {
    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("idpSubjects",  String.join(",", subIdpSubjectlist));
    String idpFlaMoFs = namedParameterJdbcTemplate.queryForObject(GET_MODULE_OVERRIDES_QUERY, parameters, String.class);
    if(StringUtils.isNotBlank(idpFlaMoFs)) {
      Arrays.stream(idpFlaMoFs.split("#")).forEach(idpFlaMoF -> {
        String[] idpFlaMoFArray = idpFlaMoF.split("\\|");
        if(idpFlaMoFArray.length == 4) {
          List<String> moduleOverrides = StringUtils.isNotBlank(idpFlaMoFArray[2]) ? Arrays.asList(idpFlaMoFArray[2].split(",")) : new ArrayList<>();
          List<String> features = StringUtils.isNotBlank(idpFlaMoFArray[3]) ? new ArrayList<>(Arrays.asList(idpFlaMoFArray[3].split(","))) : new ArrayList<>();
          if(idpFlaMoFArray[1].trim().equalsIgnoreCase("true")) {
            features.add("firm_level_access");
          }
          String idpSubject = idpFlaMoFArray[0].trim();
          userConfigurationMap.get(idpSubject).getFeaturePackage().setModuleOverrides(moduleOverrides);
          userConfigurationMap.get(idpSubject).getFeaturePackage().setFeatures(features);
        }
      });
    }
  }

  private void updateResources(List<String> subIdpSubjectlist, Map<String, UserConfiguration> userConfigurationMap) {
    SqlParameterSource userParameters = new MapSqlParameterSource()
        .addValue("idpSubjects", subIdpSubjectlist);
    List<Map<String, Object>> userMapList = namedParameterJdbcTemplate.queryForList(GET_USER_RESOURCES_BY_IDP_SUBJECT_QUERY, userParameters);
    userMapList.forEach(map -> {
      String idpSubject = getStringValue(map.get("IDP_SUBJECT"));
      String resourceName = getStringValue(map.get("NAME"));
      if(getBooleanValue(map.get("RESTRICTION"))) {
        userConfigurationMap.get(idpSubject).getRestrictedResources().add(resourceName);
      } else {
        userConfigurationMap.get(idpSubject).getResources().add(resourceName);
      }
    });
  }

  private void publishMessages(EventMessages<AuditUserConfigPayLoad> messages) {
    if(messages.getPayload().getUserConfigurationAfter() != null)
      auditLogEventPublisher.publish(messages);
  }

  private EventMessages<AuditUserConfigPayLoad> getEventMessage(String auditEventType, UserConfiguration userConfigurationBefore, UserConfiguration userConfigurationAfter) {
    EventMessages<AuditUserConfigPayLoad> messages = new EventMessages<>();

    Header header = new Header();
    header.setId(UUID.randomUUID().toString());
    messages.setHeader(header);

    AuditUserConfigPayLoad payload = new AuditUserConfigPayLoad();
    payload.setType(auditEventType);
    payload.setUserConfigurationBefore(userConfigurationBefore);
    payload.setUserConfigurationAfter(userConfigurationAfter);

    messages.setPayload(payload);

    return messages;
  }

  private UserConfiguration toDto(Map<String, Object> map) {
    UserConfiguration dto = new UserConfiguration();
    dto.setUserConfigurationId(getIntegerValue(map.get("USER_CONFIGURATION_ID")));
    dto.setIdpUserId(getStringValue(map.get("IDP_USER_ID")));
    dto.setIdpSubject(getStringValue(map.get("IDP_SUBJECT")));
    dto.setIdp(getStringValue(map.get("IDP")));
    dto.setUsername(getStringValue(map.get("USERNAME")));
    dto.setOssId(getStringValue(map.get("OSS_USER_ID")));
    dto.setOssProxyId(getStringValue(map.get("OSS_GROUP_ID")));
    dto.setOssUserId(getStringValue(map.get("OSS_USER_ID")));
    dto.setOssGroupId(getStringValue(map.get("OSS_GROUP_ID")));
    dto.setFirstName(getStringValue(map.get("FIRST_NAME")));
    dto.setLastName(getStringValue(map.get("LAST_NAME")));
    dto.setEmail(getStringValue(map.get("EMAIL")));

    dto.setStatus(getBooleanValue(map.get("ACTIVE")) ? UserStatusEnum.ACTIVE.dbValue : UserStatusEnum.INACTIVE.dbValue);
    dto.setState(getStringValue(map.get("STATE")));
    dto.setStateDescription(getStringValue(map.get("STATE_DESCRIPTION")));
    dto.setStateAction(getStringValue(map.get("STATE_ACTION")));

    dto.setPreferredLanguage(getStringValue(map.get("PREFERRED_LANGUAGE")));
    dto.setActive(getBooleanValue(map.get("ACTIVE"))  ? "Active" : "Inactive");
    dto.setCreatedBy(getStringValue(map.get("CREATED_BY")));
    dto.setLastUpdatedBy(getStringValue(map.get("LAST_UPDATED_BY")));
    dto.setCreationDate(getLocalDateTimeValue(map.get("CREATION_DATE")));
    dto.setLastUpdatedDate(getLocalDateTimeValue(map.get("LAST_UPDATE_DATE")));
    dto.setIdentityLastUpdatedDate(getLocalDateTimeValue(map.get("IDENTITY_LAST_UPDATED")));
    dto.setAccessProfileSet(getBooleanValue(map.get("ACCESS_PROFILE_SET")));
    dto.setUserGroup(getStringValue(map.get("USER_GROUP_NAME")));
    dto.setUserGroupDescription(getStringValue(map.get("USER_GROUP_DESCRIPTION")));
    dto.setIsFirmScope(getBooleanValue(map.get("IS_FIRM_SCOPE")));

    dto.setFirmId(getStringValue(map.get("FIRM_ID")));
    dto.setFirmName(getStringValue(map.get("FIRM_NAME")));
    dto.setFirmType(getStringValue(map.get("FIRM_TYPE")));
    dto.setActivationDate(getLocalDateTimeValue(map.get("ACTIVATION_DATE")));
    dto.setSourceIdpSubject(getStringValue(map.get("SOURCE_IDP_SUBJECT")));
    dto.setBngfReferenceId(getStringValue(map.get("BNGF_REFERENCE_ID")));
    dto.setIdentityLastUpdatedDate(getLocalDateTimeValue(map.get("IDENTITY_LAST_UPDATED")));
    dto.setUserRole(getStringValue(map.get("USER_ROLE")));
    dto.setUserRoleDescription(getStringValue(map.get("USER_ROLE_DESCRIPTION")));

    dto.setUserPreferences(Optional.ofNullable(map.get("USER_PREFERENCES"))
        .map(String::valueOf)
        .map(this::getMap)
        .orElse(new HashMap<>()));
    return dto;
  }

  private String getStringValue(Object object) {
    return object != null ? object.toString() : null;
  }

  private Boolean getBooleanValue(Object object) {
    return object != null ? Boolean.valueOf(getStringValue(object)) : false;
  }

  private LocalDateTime getLocalDateTimeValue(Object object) {
    return object != null ? ((Timestamp)object).toLocalDateTime(): null;
  }

  private Integer getIntegerValue(Object object) {
    return object != null ? Integer.valueOf(getStringValue(object)) : null;
  }

  public Map<String,String> getMap(String mapString) {
    try {
      ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().build();
      return objectMapper.readValue(mapString, Map.class);
    } catch (JacksonException e) {
      return null;
    }
  }

}
