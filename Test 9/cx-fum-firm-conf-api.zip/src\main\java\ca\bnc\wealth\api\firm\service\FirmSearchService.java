package ca.bnc.wealth.api.firm.service;

import ca.bnc.wealth.api.firm.jpa.FirmSearchCriteria;
import ca.bnc.wealth.api.firm.jpa.GenericFirmSearchCriteria;
import ca.bnc.wealth.api.firm.util.ApiUtil;
import ca.bnc.wealth.api.firm.util.EntityMapperUtils;
import ca.bnc.wealth.api.firm.util.FirmConstants;
import ca.bnc.wealth.common.firm.model.Firm;
import ca.bnc.wealth.common.firm.model.FirmIdHierarchy;
import ca.bnc.wealth.common.firm.model.FirmSearch;
import ca.bnc.wealth.common.firm.model.GenericSearch;
import ca.bnc.wealth.common.firm.model.GenericSearchResponse;
import ca.bnc.wealth.common.firm.model.SearchPayload;
import ca.bnc.wealth.common.fum.service.FirmServiceHelper;
import ca.bnc.wealth.common.jpa.entity.enums.FirmAssignmentType;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.specification.SpecificationWithQuery;
import ca.bnc.wealth.common.jpa.specification.SpecificationWithQueryAndFilter;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.jpa.utils.EnumSpecificationOperation;
import ca.bnc.wealth.common.jpa.utils.Filter;
import ca.bnc.wealth.common.jpa.utils.QueryParameterCombination;
import ca.bnc.wealth.common.jpa.utils.QueryParameters;
import ca.bnc.wealth.common.jpa.utils.RepositoryUtils;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ErrorSeverity;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ServiceException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
@Slf4j
public class FirmSearchService {

  @Autowired
  IamRrCodeRangeRepository iamRrCodeRangeRepository;
  @Autowired
  private FirmRepository firmRepository;
  @Autowired
  private FirmServiceHelper firmServiceHelper;

  @Autowired
  @Qualifier("postgresJdbcTemplate")
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;


  public List<Firm> searchFirm(String idpUserSubject, FirmSearch firmSearch) {
    Map<String, Object> derivedFieldValueMap = new HashMap<>();
    List<Long> userFirmIds =
        this.firmRepository.getAllFirmsByIdpSubject(idpUserSubject);
    long totalFirms = this.firmRepository.count();
    if (userFirmIds.size() != totalFirms) {
      derivedFieldValueMap.put(
          FirmSearchCriteria.firmIdByIdpUserSubject.name(),
          Pair.of(EnumQueryCriteria.IN, userFirmIds));
    }

    SpecificationWithQuery<ca.bnc.wealth.common.jpa.entity.iam.Firm, FirmSearch, FirmSearchCriteria> specification =
        new SpecificationWithQuery<>(
            firmSearch,
            FirmSearchCriteria.class,
            derivedFieldValueMap,
            EnumSpecificationOperation.AND,
            true);
    List<ca.bnc.wealth.common.jpa.entity.iam.Firm> lst = this.firmRepository.findAll(specification);
    return lst.stream().map(EntityMapperUtils::toDto).toList();
  }


  public GenericSearchResponse genericFirmSearch(
      String idpUserSubject, GenericSearch genericSearch) {

    List<String> fields =
        CollectionUtils.isEmpty(genericSearch.getSortBy())
            ? List.of(GenericFirmSearchCriteria.name.getEntityField())
            : genericSearch.getSortBy().stream()
                .map(field -> GenericFirmSearchCriteria.valueOf(field).getEntityField())
                .toList();

    String direction =
        genericSearch.getSortOrder() != null ? genericSearch.getSortOrder().name() : null;

    Integer requestedPageSize = genericSearch.getPageSize();
    Integer safePageSize = requestedPageSize;
    if (requestedPageSize != null && requestedPageSize > FirmConstants.MAX_PAGE_SIZE) {
      log.warn("PAGINATION_LIMIT: user={}, requested={}, capped={}",
          idpUserSubject, requestedPageSize, FirmConstants.MAX_PAGE_SIZE);
      safePageSize = FirmConstants.MAX_PAGE_SIZE;
    }

    PageRequest page =
        RepositoryUtils.getPageRequest(
            genericSearch.getPageNumber(), safePageSize, fields, direction, true);

    Specification<ca.bnc.wealth.common.jpa.entity.iam.Firm> spec =
        this.getGenericSearchSpecification(idpUserSubject, genericSearch);
    Page<ca.bnc.wealth.common.jpa.entity.iam.Firm> jpaResponse = this.firmRepository.findAll(spec,
        page);

    GenericSearchResponse response = new GenericSearchResponse();

    response.setTotalCount((int) jpaResponse.getTotalElements());
    if (safePageSize != null && safePageSize > 0) {
      response.setNumberOfPages(
          response.getTotalCount() / safePageSize
              + (response.getTotalCount() % safePageSize == 0 ? 0 : 1));
    }
    List<Firm> lst =
        this.firmRepository.findAll(spec, page).stream()
            .map(EntityMapperUtils::toDto)
            .toList();
    response.setFirms(lst);

    return response;
  }


  public List<FirmIdHierarchy> getFirmByRRCodeRangeAndB10RRCodeRange(
      String idpUserSubject, SearchPayload searchPayload) {
    StringBuilder getFirmByRrCodeQuery = new StringBuilder();
    getFirmByRrCodeQuery.append(FirmConstants.GET_FIRM_BY_RR_CODE_QUERY);

    if (StringUtils.isNotBlank(searchPayload.getRrCode())) {
      getFirmByRrCodeQuery.append(getRrCode(searchPayload.getRrCode(), searchPayload.getRrCode()));
    }
    if (searchPayload.getRrCodeRange() != null
        && StringUtils.isNotBlank(searchPayload.getRrCodeRange().getFrom())
        && StringUtils.isNotBlank(searchPayload.getRrCodeRange().getTo())) {
      getFirmByRrCodeQuery.append(
          getRrCode(searchPayload.getRrCodeRange().getFrom(),
              searchPayload.getRrCodeRange().getTo()));
    }
    if (searchPayload.getB10RrCode() != null) {
      getFirmByRrCodeQuery.append(
          getRrCode(searchPayload.getB10RrCode(), searchPayload.getB10RrCode()));
    }
    if (searchPayload.getB10RrCodeRange() != null
        && searchPayload.getB10RrCodeRange().getFrom() != null
        && searchPayload.getB10RrCodeRange().getTo() != null) {
      getFirmByRrCodeQuery.append(getRrCode(
          searchPayload.getB10RrCodeRange().getFrom(),
          searchPayload.getB10RrCodeRange().getTo()));
    }

    SqlParameterSource parameters = new MapSqlParameterSource()
        .addValue("assignmentType", FirmAssignmentType.R.name());
    List<ca.bnc.wealth.common.jpa.entity.iam.Firm> rrCodeFirms = namedParameterJdbcTemplate.queryForList(
            getFirmByRrCodeQuery.toString(), parameters)
        .stream()
        .map(EntityMapperUtils::toEntity)
        .toList();

    List<Long> primaryFirmIds = firmServiceHelper.getPrimaryFirmByIdpSubjectUsingJdbc(idpUserSubject, true).stream()
            .map(firmMap -> ((Integer) firmMap.get("FIRM_ENTITY_ID")).longValue())
            .toList();

    Long primeFirmId = primaryFirmIds.get(0);

    Map<Long, Long> childParentId =
        rrCodeFirms.stream()
            .collect(
                Collectors.toMap(
                    ca.bnc.wealth.common.jpa.entity.iam.Firm::getFirmEntityId,
                    fc -> {
                      if (fc.getParentFirm() != null) {
                        return fc.getParentFirm().getFirmEntityId();
                      }
                      return -1L;
                    }));

    Map<Long, List<Long>> parentChildId =
        childParentId.entrySet().stream()
            .collect(
                Collectors.groupingBy(
                    Map.Entry::getValue,
                    Collectors.mapping(Map.Entry::getKey, Collectors.toList())));

    Map<Long, Long> idHierarchyMap = new HashMap<>();
    idHierarchyMap.put(primeFirmId, 1L);
    addHierarchy(primeFirmId, parentChildId, idHierarchyMap);

    return rrCodeFirms.stream()
        .filter(f -> idHierarchyMap.containsKey(f.getFirmEntityId()))
        .map(
            f ->
                new FirmIdHierarchy()
                    .firmId(f.getFirmId())
                    .hierarchyLevel(idHierarchyMap.get(f.getFirmEntityId()).toString()))
        .toList();
  }

  private Specification<ca.bnc.wealth.common.jpa.entity.iam.Firm> getGenericSearchSpecification(
      String idpUserSubject, GenericSearch genericSearch) {

    if (StringUtils.isNotBlank(genericSearch.getSearchText())
        && genericSearch.getSearchText().length() > FirmConstants.MAX_SEARCH_TEXT_LENGTH) {
      log.warn("SEARCH_INPUT_REJECTED: user={}, reason=length, len={}",
          idpUserSubject, genericSearch.getSearchText().length());
      throw new FumValidationException(
          FirmConstants.SEARCH_TEXT_TOO_LONG_CODE,
          FirmConstants.SEARCH_TEXT_TOO_LONG_MESSAGE);
    }

    Map<String, Object> derivedFieldValueMap = new HashMap<>();

    if (StringUtils.isNotBlank(genericSearch.getSearchText())) {
      Arrays.stream(GenericFirmSearchCriteria.class.getEnumConstants())
          .forEach(
              constrain ->
                  derivedFieldValueMap.put(constrain.name(), genericSearch.getSearchText()));
    }

    if (!ApiUtil.isNumber(genericSearch.getSearchText())) {
      derivedFieldValueMap.remove(GenericFirmSearchCriteria.firmEntityId.name());
    }
    //ignore fields from search
    Optional.ofNullable(genericSearch.getIgnoreFields()).stream()
        .flatMap(Collection::stream)
        .forEach(derivedFieldValueMap::remove);

    List<Long> userFirmIds =
        this.firmRepository.getAllFirmsByIdpSubject(idpUserSubject);
    long totalFirms = this.firmRepository.count();
    if (userFirmIds.size() != totalFirms) {
      derivedFieldValueMap.put(
          GenericFirmSearchCriteria.firmIdByIdpUserSubject.name(), userFirmIds);
    } else {
      derivedFieldValueMap.remove(GenericFirmSearchCriteria.firmIdByIdpUserSubject.name());
    }

    QueryParameterCombination query = new QueryParameterCombination();
    query.setOperation(EnumSpecificationOperation.AND);

    QueryParameters leftChild = new QueryParameters();
    leftChild.setOperation(EnumSpecificationOperation.AND);
    leftChild.setParameter(List.of(GenericFirmSearchCriteria.firmIdByIdpUserSubject.name()));

    QueryParameterCombination rightChild = new QueryParameterCombination();
    rightChild.setOperation(EnumSpecificationOperation.OR);

    QueryParameters rightChild1 = new QueryParameters();
    rightChild1.setOperation(EnumSpecificationOperation.OR);
    rightChild1.setParameter(
        Arrays.stream(GenericFirmSearchCriteria.class.getEnumConstants())
            .map(Enum::name)
            .filter(
                name ->
                    !name.equalsIgnoreCase(GenericFirmSearchCriteria.firmIdByIdpUserSubject.name()))
            .toList());

    rightChild.setSubQueryLeft(rightChild1);

    query.setSubQueryLeft(leftChild);
    query.setSubQueryRight(rightChild);

    List<Filter> filters = EntityMapperUtils.getFilter(genericSearch.getFilter());

    return new SpecificationWithQueryAndFilter<>(null, GenericFirmSearchCriteria.class, derivedFieldValueMap, query, filters, false);
  }

  private void addHierarchy(
      Long currentFirmId, Map<Long, List<Long>> parentChildId, Map<Long, Long> idHierarchyMap) {
    if (parentChildId.get(currentFirmId) != null) {
      for (long id : parentChildId.get(currentFirmId)) {
        if (idHierarchyMap.containsKey(id)) {
          log.error("FIRM_HIERARCHY_CYCLE: firmEntityId={}", id);
          continue;
        }
        idHierarchyMap.put(id, idHierarchyMap.get(currentFirmId) + 1);
        addHierarchy(id, parentChildId, idHierarchyMap);
      }
    }
  }

  private String getRrCode(String from, String to) {
    SqlParameterSource fromParameters = new MapSqlParameterSource().addValue("rrCode", from);
    long fromL = (Long) namedParameterJdbcTemplate.queryForMap(FirmConstants.DECODE_RR_CODE_QUERY,
        fromParameters).get("b36_decode");
    SqlParameterSource toParameters = new MapSqlParameterSource().addValue("rrCode", to);
    long toL = (Long) namedParameterJdbcTemplate.queryForMap(FirmConstants.DECODE_RR_CODE_QUERY,
        toParameters).get("b36_decode");
    return getRrCode(fromL, toL);
  }

  private String getRrCode(long from, long to) {
    if (from > to) {
      throw new ServiceException(
          ErrorSeverity.ERROR, "Invalid input. From value can't be greater than To value");
    }
    return String.format(FirmConstants.RR_CODE_B10_CLAUSE, from, to);
  }
}
