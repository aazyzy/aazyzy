package ca.bnc.wealth.api.firm.service;

import ca.bnc.wealth.api.firm.util.FirmConstants;
import ca.bnc.wealth.common.bma.model.JsonPayLoad;
import ca.bnc.wealth.common.bma.service.BulkManagementClientService;
import ca.bnc.wealth.common.firm.model.FeaturePackageAssignment;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import tools.jackson.databind.ObjectMapper;
import jakarta.transaction.Transactional;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tools.jackson.core.JacksonException;

@Service
@Slf4j
public class FirmServiceBma {

  private static final String TEMPLATE_NAME = "FirmSetting";

  @Autowired
  private BulkManagementClientService bulkManagementClientService;

  @Autowired
  private FirmRepository firmRepository;

  @Autowired
  private ObjectMapper objectMapper;

  @Transactional
  public void assignmentsFeaturePackageToFirm(String firmId, FeaturePackageAssignment featurePackageAssignment) {
    List<JsonPayLoad> jsonPayLoads = createPayLoad(firmId, featurePackageAssignment);

    String batchId = bulkManagementClientService.upload(TEMPLATE_NAME, firmId, jsonPayLoads, "feature-package-assignments_" + System.currentTimeMillis()+ ".json");
    log.info("Batch ID for feature package assignment upload: {}", batchId);
    bulkManagementClientService.triggerBulkProcess(batchId);

    addFirmPreferences(firmId, batchId);
  }

  private List<JsonPayLoad> createPayLoad(String firmId, FeaturePackageAssignment featurePackageAssignment) {
    List<JsonPayLoad> jsonPayLoads = new ArrayList<>();
    JsonPayLoad jsonPayLoad = new JsonPayLoad();
    jsonPayLoad.setPayload(featurePackageAssignment);
    jsonPayLoad.setTargetUrl("/firm-conf/firms/" + firmId + "/assignments/feature-package");
    jsonPayLoad.setHttpMethod("PUT");
    jsonPayLoad.setRequiresCallback(true);

    jsonPayLoads.add(jsonPayLoad);
    return jsonPayLoads;
  }

  private void addFirmPreferences(String firmId, String batchId) {
    Firm firm = firmRepository.findByFirmId(firmId);
    Map<String, String> prefs = firm.getFirmPreferences() != null
        ? new HashMap<>(firm.getFirmPreferences())
        : new HashMap<>();
    prefs.put(FirmConstants.FIRM_FEATURE_PACKAGE_ASSIGNMENT_BATCH_ID, batchId);

    try {
      String prefsJson = objectMapper.writeValueAsString(prefs);
      firmRepository.updateFirmPreferences(firmId, prefsJson);
    } catch (JacksonException e) {
      log.error("Failed to serialize firm preferences for firmId {}: {}", firmId, e.getMessage(), e);
      throw new FumServiceException(
          FirmConstants.FIRM_PREFERENCES_UPDATE_FAILED_CODE,
          String.format(FirmConstants.FIRM_PREFERENCES_UPDATE_FAILED_MESSAGE, firmId));
    }
  }
}
