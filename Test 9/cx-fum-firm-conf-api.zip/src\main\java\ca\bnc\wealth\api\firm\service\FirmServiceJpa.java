package ca.bnc.wealth.api.firm.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ca.bnc.wealth.api.firm.dao.RrCodeRangeDao;
import ca.bnc.wealth.api.firm.util.ApiUtil;
import ca.bnc.wealth.api.firm.util.EntityMapperUtils;
import ca.bnc.wealth.api.firm.util.FirmConstants;
import ca.bnc.wealth.common.exception.Entity.FumConflictException;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.firm.model.Assignment;
import ca.bnc.wealth.common.firm.model.FeaturePackageAssignment;
import ca.bnc.wealth.common.firm.model.Firm;
import ca.bnc.wealth.common.firm.model.RRCodeRange;
import ca.bnc.wealth.common.firm.model.UpdateRRCodeRange;
import ca.bnc.wealth.common.fum.service.FirmAssignmentService;
import ca.bnc.wealth.common.fum.service.FirmServiceHelper;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.fum.service.RrCodeServiceHelper;
import ca.bnc.wealth.common.fum.util.Constants;
import ca.bnc.wealth.common.jpa.entity.enums.FirmAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FirmAssignmentRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.fum.service.UserSearchViewRefreshService;
import ca.bnc.wealth.common.jpa.repo.iam.FirmAssignmentRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FirmServiceJpa {

  private static final int NUMBER_FIXED_THREADS = 10;

  private final FirmAssignmentRrCodeRangeRepository firmAssignmentRrCodeRangeRepository;

  private final FirmRepository firmRepository;

  private final FirmValidationService firmValidationService;

  @Qualifier("postgresJdbcTemplate")
  private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  private final UserSearchViewRefreshService userSearchViewRefreshService;
  private final FirmServiceHelper firmServiceHelper;
  private final RrCodeServiceHelper rrCodeServiceHelper;
  private final FirmAssignmentService firmAssignmentService;
  private final RedisCacheOperationService redisCacheOperationService;

  @Value("${oauth2.systemTokens.fum.clientId}")
  private String systemClientId;

  @Autowired
  public FirmServiceJpa(
      FirmAssignmentRrCodeRangeRepository firmAssignmentRrCodeRangeRepository,
      FirmRepository firmRepository,
      FirmValidationService firmValidationService,
      NamedParameterJdbcTemplate namedParameterJdbcTemplate,
      UserSearchViewRefreshService userSearchViewRefreshService,
      FirmServiceHelper firmServiceHelper,
      RrCodeServiceHelper rrCodeServiceHelper,
      FirmAssignmentService firmAssignmentService,
      RedisCacheOperationService redisCacheOperationService) {

    this.firmAssignmentRrCodeRangeRepository = firmAssignmentRrCodeRangeRepository;
    this.firmRepository = firmRepository;
    this.firmValidationService = firmValidationService;
    this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    this.userSearchViewRefreshService = userSearchViewRefreshService;
    this.firmServiceHelper = firmServiceHelper;
    this.rrCodeServiceHelper = rrCodeServiceHelper;
    this.firmAssignmentService = firmAssignmentService;
    this.redisCacheOperationService = redisCacheOperationService;
  }

  public Firm getUserFirmAssignments(String idpUserSubject) {
    ExecutorService executorService = Executors.newFixedThreadPool(NUMBER_FIXED_THREADS);
    List<ca.bnc.wealth.common.jpa.entity.iam.Firm> firms = firmServiceHelper
        .getPrimaryFirmByIdpSubjectUsingJdbc(idpUserSubject, true).stream()
        .map(EntityMapperUtils::toEntity)
        .toList();

    List<Firm> response = firms.stream()
        .map(EntityMapperUtils::toDto)
        .map(f -> this.updateRrcode(executorService, f))
        .collect(Collectors.toList());

    shutdownAndAwait(executorService);
    return response.get(0);
  }

  public List<Assignment> getFirmAssignments(String firmId,
      List<ca.bnc.wealth.common.firm.model.FirmAssignmentType> assignmentTypes) {
    List<Assignment> assignments = new ArrayList<>();
    if (firmId == null || firmId.isBlank() || assignmentTypes == null || assignmentTypes.isEmpty()) {
      return assignments;
    }

    assignmentTypes.forEach(assignmentType -> {
      Optional.ofNullable(assignmentType).ifPresent(type -> {
        switch (type) {
          case R -> {
            SqlParameterSource parameters = new MapSqlParameterSource()
                .addValue("assignmentType", FirmAssignmentType.R.name())
                .addValue("firm", firmId);
            namedParameterJdbcTemplate.queryForList(FirmConstants.GET_RR_CODE_RANGES_BY_FIRM_QUERY,
                parameters)
                .stream()
                .map(EntityMapperUtils::toDao)
                .filter(this::isRRCodeRangeActive)
                .map(EntityMapperUtils::toDto)
                .forEach(assignments::add);
          }
          case P -> {
            SqlParameterSource parameters = new MapSqlParameterSource()
                .addValue("assignmentType", FirmAssignmentType.P.name())
                .addValue("firm", firmId);
            namedParameterJdbcTemplate.queryForList(FirmConstants.GET_FEATURE_PACKAGE_BY_FIRM_QUERY,
                parameters)
                .stream()
                .map(EntityMapperUtils::toDto)
                .forEach(assignments::add);
          }
          case S -> {
            SqlParameterSource parameters = new MapSqlParameterSource()
                .addValue("firm", firmId);
            List<Map<String, Object>> queryResult = namedParameterJdbcTemplate.queryForList(
                FirmConstants.GET_RESOURCES_BY_FIRM_QUERY,
                parameters);
            Set<String> excludes = queryResult.stream()
                .filter(r -> (Boolean) r.get("RESTRICTION"))
                .map(r -> (String) r.get("NAME"))
                .collect(Collectors.toSet());
            queryResult.stream()
                .filter(Predicate.not(r -> excludes.contains(r.get("NAME"))))
                .map(EntityMapperUtils::toDtoResource)
                .forEach(assignments::add);
          }
        }
      });
    });

    return assignments;
  }

  public boolean isRRCodeRangeActive(RrCodeRangeDao rrCodeRange) {
    return ApiUtil.isDateWithinCurrentDate(rrCodeRange.getEffectiveDate(),
        rrCodeRange.getExpiryDate());
  }

  private Firm updateRrcode(ExecutorService executorService, Firm firm) {
    executorService.submit(
        () -> firm.setRrCodeRanges(this.rrCodeServiceHelper.getRRCodeListByFirmIdUsingJdbc(firm.getFirmId())
            .stream()
            .map(EntityMapperUtils::toRRCodeRangeDto)
            .toList()));
    return firm;
  }

  @Transactional(rollbackFor = Exception.class)
  public void assignmentsRrRangeToFirm(
      String idpSubject, String firmId, UpdateRRCodeRange updateRRCodeRangeRequest) {
    ca.bnc.wealth.common.jpa.entity.iam.Firm firm = getFirm(firmId)
        .orElseThrow(() -> new FumNotFoundException(FirmConstants.FIRM_CONFIGURATION_NOT_FOUND_CODE,
            String.format(FirmConstants.FIRM_CONFIGURATION_NOT_FOUND_MESSAGE, firmId)));

    List<IamRrCodeRange> rrRangeEntityList = getRrRangeEntityList(
        updateRRCodeRangeRequest.getRrRanges());
    if (rrRangeEntityList.size() != updateRRCodeRangeRequest.getRrRanges().size()) {
      throw new FumConflictException(
          FirmConstants.UPDATE_RR_RANGE_LIST_NOT_ACTIVE_CODE,
          FirmConstants.UPDATE_RR_RANGE_LIST_NOT_ACTIVE_MESSAGE);
    }

    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("iamRrCodeRange", Pair.of(EnumQueryCriteria.IN, rrRangeEntityList));
    Specification<FirmAssignmentRrCodeRange> specification = new Specification<>(fieldValueMap);
    List<FirmAssignmentRrCodeRange> firmAssignmentRrRangeEntityList = firmAssignmentRrCodeRangeRepository.findAll(
        specification);

    firmAssignmentRrRangeEntityList.forEach(firmAssignmentRrCodeRange -> {
      firmAssignmentRrCodeRange.setExpiryDate(
          Timestamp.valueOf(updateRRCodeRangeRequest.getEffectiveDate().atStartOfDay()));
      firmAssignmentRrCodeRange.setUpdatedBy(idpSubject);
      firmAssignmentRrCodeRange.setUpdateDate(new Timestamp(System.currentTimeMillis()));
    });
    firmAssignmentRrCodeRangeRepository.saveAllAndFlush(firmAssignmentRrRangeEntityList);

    List<FirmAssignmentRrCodeRange> assignmentRrCodeRanges = new ArrayList<>();
    rrRangeEntityList.forEach(rrCodeRange -> {
      FirmAssignmentRrCodeRange firmAssignmentRrCodeRange = new FirmAssignmentRrCodeRange();
      firmAssignmentRrCodeRange.setFirm(firm);
      firmAssignmentRrCodeRange.setAssignmentType(FirmAssignmentType.R);
      firmAssignmentRrCodeRange.setIamRrCodeRange(rrCodeRange);
      firmAssignmentRrCodeRange.setCreatedBy(idpSubject);
      firmAssignmentRrCodeRange.setCreationDate(new Timestamp(System.currentTimeMillis()));
      firmAssignmentRrCodeRange.setExpiryDate(
          Timestamp.valueOf(updateRRCodeRangeRequest.getExpiryDate().atStartOfDay()));
      firmAssignmentRrCodeRange.setEffectiveDate(
          Timestamp.valueOf(updateRRCodeRangeRequest.getEffectiveDate().atStartOfDay()));
      assignmentRrCodeRanges.add(firmAssignmentRrCodeRange);
    });
    firmAssignmentRrCodeRangeRepository.saveAll(assignmentRrCodeRanges);
    redisCacheOperationService.deleteCacheByCacheNameAndPattern(Constants.GET_FIRM_CACHE, firmId);
  }

  @SneakyThrows
  public void shutdownAndAwait(ExecutorService executorService) {
    executorService.shutdown();
    try {
      executorService.awaitTermination(100000, TimeUnit.MILLISECONDS);
    } catch (InterruptedException e) {
      executorService.shutdownNow();
      log.error("Error in executor service with error: {}", e.getMessage());
      throw e;
    }
  }

  @SneakyThrows
  public List<IamRrCodeRange> getRrRangeEntityList(List<RRCodeRange> rrCodeRangeListInput) {
    List<IamRrCodeRange> rrCodeRangeEntityList = Collections.synchronizedList(new ArrayList<>());
    List<CompletableFuture<IamRrCodeRange>> futures = new ArrayList<>();

    rrCodeRangeListInput.forEach(rrCode -> {
      CompletableFuture<IamRrCodeRange> completableFuture = rrCodeServiceHelper
          .getRrRangeEntityAsync(rrCode.getFromRRCode(), rrCode.getToRRCode(), true);
      futures.add(completableFuture);
    });
    CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();

    for (CompletableFuture<IamRrCodeRange> future : futures) {
      rrCodeRangeEntityList.add(future.get());
    }
    return rrCodeRangeEntityList;
  }

  public Optional<ca.bnc.wealth.common.jpa.entity.iam.Firm> getFirm(String firmId) {
    return ApiUtil.isNumber(firmId)
        ? firmRepository.findById(Long.parseLong(firmId))
        : Optional.ofNullable(firmRepository.findByFirmId(firmId));
  }

  public Firm getFirmByFirmId(String firmId) {
    return EntityMapperUtils.toDto(firmRepository.findByFirmId(firmId));
  }

  public void refreshUserSearchMaterializedView(boolean throwException) {
    userSearchViewRefreshService.refreshNow(throwException);
  }

  @Transactional(rollbackFor = Exception.class)
  public void assignmentsFeaturePackageToFirm(
      String idpSubject, String firmId, FeaturePackageAssignment featurePackageAssignment) {

    firmValidationService.validateFeaturePackageAssignment(featurePackageAssignment);
    firmAssignmentService.createFirmFeaturePackageAssignment(
         firmId, featurePackageAssignment.getFeaturePackageId(), idpSubject, systemClientId);
  }
}
