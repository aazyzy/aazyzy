package ca.bnc.wealth.api.firm.service;

import ca.bnc.wealth.api.firm.util.FirmConstants;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.firm.model.FeaturePackageAssignment;
import ca.bnc.wealth.common.firm.model.UpdateRRCodeRange;
import java.time.LocalDate;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
@Slf4j
public class FirmValidationService {

  public void validateUpdateRrCodeRangeInput(UpdateRRCodeRange updateRRCodeRange) {
    if (updateRRCodeRange == null) {
      throw new FumValidationException(
          FirmConstants.UPDATE_RR_RANGE_NULL_CODE,
          FirmConstants.UPDATE_RR_RANGE_NULL_MESSAGE);
    }

    if (updateRRCodeRange.getEffectiveDate() == null) {
      throw new FumValidationException(
          FirmConstants.UPDATE_RR_RANGE_EFFECTIVE_DATE_NULL_CODE,
          FirmConstants.UPDATE_RR_RANGE_EFFECTIVE_DATE_NULL_MESSAGE);
    }

    if (updateRRCodeRange.getEffectiveDate().isBefore(LocalDate.now())) {
      throw new FumValidationException(
          FirmConstants.UPDATE_RR_RANGE_EFFECTIVE_DATE_INVALID_CODE,
          FirmConstants.UPDATE_RR_RANGE_EFFECTIVE_DATE_INVALID_MESSAGE);
    }

    if (updateRRCodeRange.getExpiryDate() == null) {
      updateRRCodeRange.setExpiryDate(
          LocalDate.parse(FirmConstants.UPDATE_RR_RANGE_EXPIRY_DATE_DEFAULT));
    } else if (updateRRCodeRange.getExpiryDate().isBefore(LocalDate.now())) {
      throw new FumValidationException(
          FirmConstants.UPDATE_RR_RANGE_EXPIRY_DATE_INVALID_CODE,
          FirmConstants.UPDATE_RR_RANGE_EXPIRY_DATE_INVALID_MESSAGE);
    }

    if (CollectionUtils.isEmpty(updateRRCodeRange.getRrRanges())) {
      throw new FumValidationException(
          FirmConstants.UPDATE_RR_RANGE_LIST_EMPTY_CODE,
          FirmConstants.UPDATE_RR_RANGE_LIST_EMPTY_MESSAGE);
    }

    updateRRCodeRange.getRrRanges().forEach(rrCodeRange -> {
      if (StringUtils.isEmpty(rrCodeRange.getFromRRCode()) || StringUtils.isEmpty(
          rrCodeRange.getToRRCode())) {
        throw new FumValidationException(
            FirmConstants.UPDATE_RR_RANGE_LIST_FROM_TO_CODE,
            FirmConstants.UPDATE_RR_RANGE_LIST_FROM_TO_MESSAGE);
      }
    });
  }

  public void validateFeaturePackageAssignment(FeaturePackageAssignment featurePackageAssignment) {
    if (featurePackageAssignment == null) {
      throw new FumValidationException(
          FirmConstants.FEATURE_PACKAGE_ASSIGNMENT_NULL_CODE,
          FirmConstants.FEATURE_PACKAGE_ASSIGNMENT_NULL_MESSAGE);
    }
    if (featurePackageAssignment.getFeaturePackageId() == null) {
      throw new FumValidationException(FirmConstants.FEATURE_PACKAGE_ID_NULL_CODE,
          FirmConstants.FEATURE_PACKAGE_ID_NULL_MESSAGE);
    }
  }

}
