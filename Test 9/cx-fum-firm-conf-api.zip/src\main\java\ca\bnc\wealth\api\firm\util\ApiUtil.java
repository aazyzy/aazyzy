package ca.bnc.wealth.api.firm.util;

import java.sql.Timestamp;
import java.time.LocalDateTime;

public class ApiUtil {

  private ApiUtil() {
    throw new IllegalStateException("Utility class");
  }

  public static LocalDateTime toLocalDateTime(Timestamp dateValue) {
    if (dateValue == null) {
      return null;
    }
    return dateValue.toLocalDateTime();
  }

  public static boolean isNumber(String firmId) {
    try {
      Integer.parseInt(firmId);
      return true;
    } catch (NumberFormatException e) {
      return false;
    }
  }

  public static boolean isDateWithinCurrentDate(Timestamp startDate, Timestamp endDate) {
    return isDateWithinRange(Timestamp.valueOf(LocalDateTime.now()), startDate, endDate);
  }

  public static boolean isDateWithinRange(Timestamp currentTimestamp, Timestamp startDate,
      Timestamp endDate) {
    return currentTimestamp.after(startDate) && currentTimestamp.before(endDate);
  }
}
