package ca.bnc.wealth.api.firm.util;

import ca.bnc.wealth.api.firm.dao.RrCodeRangeDao;
import ca.bnc.wealth.common.firm.model.Assignment;
import ca.bnc.wealth.common.firm.model.Firm;
import ca.bnc.wealth.common.firm.model.FirmAssignmentType;
import ca.bnc.wealth.common.firm.model.GenericSearchFilter;
import ca.bnc.wealth.common.firm.model.RRCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.FinancialEntity;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.jpa.utils.Filter;
import ca.bnc.wealth.common.kafka.model.RrCodeRanges;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import tools.jackson.core.JacksonException;

public class EntityMapperUtils {

  private EntityMapperUtils() {
    throw new IllegalStateException("Utility class");
  }

  public static Firm toDto(ca.bnc.wealth.common.jpa.entity.iam.Firm firmEntity) {
    Firm firm = new Firm();

    Optional.ofNullable(firmEntity.getParentFirm())
        .map(ca.bnc.wealth.common.jpa.entity.iam.Firm::getFirmEntityId)
        .ifPresent(firm::setParentFirmEntityId);
    firm.setFirmEntityId(firmEntity.getFirmEntityId());
    firm.setFirmId(firmEntity.getFirmId());
    firm.setFirmName(firmEntity.getName());
    firm.setFirmDisplayNameEn(firmEntity.getFirmDisplayNameEn());
    firm.setFirmDisplayNameFr(firmEntity.getFirmDisplayNameFr());
    Optional.ofNullable(firmEntity.getParentFirm())
        .ifPresent(pFirm -> firm.setParentFirmId(pFirm.getFirmId()));
    firm.setFirmType(ca.bnc.wealth.common.firm.model.FirmType.valueOf(
        firmEntity.getFirmType().name().toUpperCase(
            Locale.ROOT)));
    firm.setState(convertState(firmEntity.getState()));
    Optional.ofNullable(firmEntity.getFinancialEntity())
        .ifPresent(fentity -> {
          firm.setFinancialLegalEntityId((int) fentity.getFinancialEntityId());
          firm.setBrokerCode(fentity.getBrokerCode());
          firm.setBrokerNo(fentity.getBranchNumber());
          firm.setBranchNo(fentity.getDealerCode());
        });

    Optional.ofNullable(firmEntity.getFirmPreferences())
        .ifPresent(firm::setFirmPreferences);

    firm.setCreatedBy(firmEntity.getCreatedBy());
    Optional.ofNullable(firmEntity.getCreationDate())
        .ifPresent(timestamp -> firm.setCreationDate(timestamp.toLocalDateTime()));
    firm.lastUpdatedBy(firmEntity.getLastUpdatedBy());
    Optional.ofNullable(firmEntity.getLastUpdateDate())
        .ifPresent(timestamp -> firm.setLastUpdateDate(timestamp.toLocalDateTime()));
    return firm;
  }

  public static ca.bnc.wealth.common.jpa.entity.iam.Firm toEntity(Map<String, Object> firmMap) {
    ca.bnc.wealth.common.jpa.entity.iam.Firm firm = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm.setFirmEntityId(((Integer) firmMap.get("FIRM_ENTITY_ID")).longValue());
    firm.setFirmId(String.valueOf(firmMap.get("FIRM_ID")));
    firm.setFirmType(ca.bnc.wealth.common.jpa.entity.enums.FirmType.valueOf(
        String.valueOf(firmMap.get("TYPE"))));
    firm.setName(String.valueOf(firmMap.get("NAME")));
    firm.setFirmDisplayNameEn(String.valueOf(firmMap.get("FIRM_DISPLAY_NAME_EN")));
    firm.setFirmDisplayNameFr(String.valueOf(firmMap.get("FIRM_DISPLAY_NAME_FR")));
    firm.setActive((Boolean) firmMap.get("ACTIVE"));
    firm.setState(String.valueOf(firmMap.get("STATE")));
    firm.setPreferredLanguageType(
        ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType.valueOf(
            String.valueOf(firmMap.get("PREFERRED_LANGUAGE"))));
    firm.setCreatedBy(String.valueOf(firmMap.get("CREATED_BY")));
    firm.setCreationDate(Timestamp.valueOf(String.valueOf(firmMap.get("CREATION_DATE"))));
    firm.setLastUpdatedBy(String.valueOf(firmMap.get("LAST_UPDATED_BY")));

    Timestamp lastUpdateDate = Optional.ofNullable(firmMap.get("LAST_UPDATE_DATE")).map(
        o -> Timestamp.valueOf(String.valueOf(o))).orElse(null);
    if (lastUpdateDate != null) {
      firm.setLastUpdateDate(lastUpdateDate);
    }

    String parentFirmEntityId = Optional.ofNullable(firmMap.get("PARENT_FIRM_ENTITY_ID")).map(
        String::valueOf).orElse(null);
    if (StringUtils.isNotEmpty(parentFirmEntityId)) {
      ca.bnc.wealth.common.jpa.entity.iam.Firm parentFirm = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
      parentFirm.setFirmEntityId(Long.valueOf(parentFirmEntityId));
      parentFirm.setFirmId(String.valueOf(firmMap.get("PARENT_FIRM_ID")));
      firm.setParentFirm(parentFirm);
    }

    String financialEntityId = Optional.ofNullable(firmMap.get("FINANCIAL_ENTITY_ID")).map(
        String::valueOf).orElse(null);
    if (StringUtils.isNotEmpty(financialEntityId)) {
      FinancialEntity financialEntity = new FinancialEntity();
      financialEntity.setFinancialEntityId(Long.parseLong(financialEntityId));
      financialEntity.setBrokerCode(String.valueOf(firmMap.get("BROKER_CODE")));
      financialEntity.setBranchNumber(String.valueOf(firmMap.get("B_NUMBER")));
      financialEntity.setDealerCode(String.valueOf(firmMap.get("DEALER_CODE")));
      firm.setFinancialEntity(financialEntity);
    }

    String firmPreferences = Optional.ofNullable(firmMap.get("FIRM_PREFERENCES")).map(
        String::valueOf).orElse(null);
    if (StringUtils.isNotEmpty(firmPreferences)) {
      firm.setFirmPreferences(getMap(firmPreferences));
    }
    return firm;
  }

  public static String convertState(String state) {
    if (FirmConstants.FIRM_STATE_ACTIVE.equalsIgnoreCase(state)) {
      return FirmConstants.FIRM_STATE_ENABLED;
    }
    if (FirmConstants.FIRM_STATE_INACTIVE.equalsIgnoreCase(state)) {
      return FirmConstants.FIRM_STATE_DISABLED;
    }

    if (FirmConstants.FIRM_STATE_ONBOARDED.equalsIgnoreCase(state)) {
      return FirmConstants.FIRM_STATE_ONBOARDED;
    }
    if (FirmConstants.FIRM_STATE_DECOMMISSIONED.equalsIgnoreCase(state)) {
      return FirmConstants.FIRM_STATE_DECOMMISSIONED;
    }
    return null;
  }

  private static String convertStateToDB(String state) {
    if (FirmConstants.FIRM_STATE_ENABLED.equalsIgnoreCase(state)) {
      return FirmConstants.FIRM_STATE_ACTIVE;
    }
    if (FirmConstants.FIRM_STATE_DISABLED.equalsIgnoreCase(state)) {
      return FirmConstants.FIRM_STATE_INACTIVE;
    }

    if (FirmConstants.FIRM_STATE_ONBOARDED.equalsIgnoreCase(state)) {
      return FirmConstants.FIRM_STATE_ONBOARDED.toLowerCase();
    }
    if (FirmConstants.FIRM_STATE_DECOMMISSIONED.equalsIgnoreCase(state)) {
      return FirmConstants.FIRM_STATE_DECOMMISSIONED.toLowerCase();
    }
    return null;
  }

  public static RRCodeRange toRRCodeRangeDto(Map<String, Object> rrCodeRangeMap) {
    RRCodeRange dto = new RRCodeRange();
    dto.setRrCodeRangeId((Integer) rrCodeRangeMap.get("RR_CODE_RANGE_ID"));
    dto.setFromRRCode(String.valueOf(rrCodeRangeMap.get("FROM_RR_CODE")));
    dto.setFromRRCodeB10(((Long) rrCodeRangeMap.get("FROM_RR_CODE_B10")).intValue());
    dto.setToRRCode(String.valueOf(rrCodeRangeMap.get("TO_RR_CODE")));
    dto.setToRRCodeB10(((Long) rrCodeRangeMap.get("TO_RR_CODE_B10")).intValue());
    dto.setCreatedBy(String.valueOf(rrCodeRangeMap.get("CREATED_BY")));
    Optional.ofNullable(rrCodeRangeMap.get("CREATION_DATE")).map(
        o -> Timestamp.valueOf(String.valueOf(o)).toLocalDateTime())
        .ifPresent(dto::setCreationDate);
    dto.setLastUpdatedBy(String.valueOf(rrCodeRangeMap.get("LAST_UPDATED_BY")));
    Optional.ofNullable(rrCodeRangeMap.get("LAST_UPDATE_DATE")).map(
        o -> Timestamp.valueOf(String.valueOf(o)).toLocalDateTime())
        .ifPresent(dto::setLastUpdatedDate);
    return dto;
  }

  public static List<Filter> getFilter(List<GenericSearchFilter> lst) {
    return Optional.ofNullable(lst).stream()
        .flatMap(Collection::stream)
        .map(EntityMapperUtils::toDto)
        .map(EntityMapperUtils::updateState)
        .toList();
  }

  public static Filter toDto(GenericSearchFilter genericSearchFilter) {
    Filter filter = new Filter();
    filter.setFieldName(genericSearchFilter.getFieldName());
    filter.setCriteria(EnumQueryCriteria.valueOf(genericSearchFilter.getFilterCondition().name()));
    filter.setFieldValue(filter.getCriteria() == EnumQueryCriteria.IN ? getList(
        genericSearchFilter.getFieldValue()) : genericSearchFilter.getFieldValue());
    return filter;
  }

  public static Filter updateState(Filter filter) {
    if ("state".equalsIgnoreCase(filter.getFieldName())) {
      if (filter.getFieldValue() instanceof ArrayList) {
        List<String> lst = ((ArrayList<?>) filter.getFieldValue()).stream()
            .map(String::valueOf)
            .map(EntityMapperUtils::convertStateToDB)
            .toList();
        filter.setFieldValue(lst);
      } else {
        filter.setFieldValue(convertStateToDB(filter.getFieldValue().toString()));
      }
    }
    return filter;
  }

  @SneakyThrows
  private static List<Object> getList(String listString) {
    ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().build();
    return objectMapper.readValue(listString, List.class);
  }

  private static Map<String, String> getMap(String mapString) {
    return Optional.ofNullable(mapString)
        .map((str) -> {
          ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().build();
          try {
            return objectMapper.readValue(str, HashMap.class);
          } catch (JacksonException e) {
          }
          return null;
        }).orElse(null);
  }

  public static List<RRCodeRange> toDto(List<RrCodeRanges> rrCodeRanges) {
    List<RRCodeRange> lst = new ArrayList<>();
    Optional.ofNullable(rrCodeRanges)
        .ifPresent(list -> list.stream().forEach(r -> lst.add(toDto(r))));
    return lst;
  }

  public static RRCodeRange toDto(RrCodeRanges rrCodeRange) {
    RRCodeRange rr = new RRCodeRange();
    rr.setFromRRCode(rrCodeRange.getFromRRCode());
    rr.setToRRCode(rrCodeRange.getToRRCode());
    return rr;
  }

  public static Assignment toDto(RrCodeRangeDao rrCodeRange) {
    Assignment assignment = new Assignment();
    assignment.setAssignmentType(FirmAssignmentType.R);
    assignment.setAssigneeId(rrCodeRange.getRrCodeRangeId());
    assignment.setFromRRCode(rrCodeRange.getFromRrCode());
    assignment.setToRRCode(rrCodeRange.getToRrCode());
    return assignment;
  }

  public static Assignment toDto(Map<String, Object> featurePackageMap) {
    Assignment assignment = new Assignment();
    assignment.setAssignmentType(FirmAssignmentType.P);
    assignment.setAssigneeId(((Integer) featurePackageMap.get("FEATURE_PACKAGE_ID")).longValue());
    assignment.setTemplateName((String) featurePackageMap.get("NAME"));
    return assignment;
  }

  public static Assignment toDtoResource(Map<String, Object> featurePackageMap) {
    Assignment assignment = new Assignment();
    assignment.setAssignmentType(FirmAssignmentType.S);
    assignment.setAssigneeId(((Integer) featurePackageMap.get("RESOURCE_ID")).longValue());
    assignment.setResourceName((String) featurePackageMap.get("NAME"));
    return assignment;
  }

  public static RrCodeRangeDao toDao(Map<String, Object> rrCodeRangeMap) {
    RrCodeRangeDao rrCodeRangeDao = new RrCodeRangeDao();
    rrCodeRangeDao.setRrCodeRangeId(((Integer) rrCodeRangeMap.get("RR_CODE_RANGE_ID")).longValue());
    rrCodeRangeDao.setFromRrCode(String.valueOf(rrCodeRangeMap.get("FROM_RR_CODE")));
    rrCodeRangeDao.setToRrCode(String.valueOf(rrCodeRangeMap.get("TO_RR_CODE")));
    rrCodeRangeDao.setActive((Boolean) rrCodeRangeMap.get("ACTIVE"));
    rrCodeRangeDao.setEffectiveDate(
        Timestamp.valueOf(String.valueOf(rrCodeRangeMap.get("EFFECTIVE_DATE"))));
    rrCodeRangeDao.setExpiryDate(
        Timestamp.valueOf(String.valueOf(rrCodeRangeMap.get("EXPIRY_DATE"))));
    return rrCodeRangeDao;
  }

}