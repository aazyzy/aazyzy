package ca.bnc.wealth.api.firm.util;

import ca.bnc.wealth.common.firm.model.AssignmentType;
import ca.bnc.wealth.common.firm.model.Firm;
import ca.bnc.wealth.common.firm.model.FirmType;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class FirmConfigurationRowMapper implements RowMapper<Firm> {

  @Override
  public Firm mapRow(ResultSet rs, int rowNum) throws SQLException {
    Firm firm =
        new Firm()
            .parentFirmEntityId((long) rs.getInt("parentFirmConfigurationId"))
            .firmEntityId((long) (rs.getInt("firmConfigurationId")))
            .firmId(rs.getString("firmId"))
            .firmName(rs.getString("firmName"))
            .financialLegalEntityId(rs.getInt("financialLegalEntityId"))
            .firmType(FirmType.fromValue(rs.getString("firmType")))
            .brokerCode(rs.getString("brokerCode"))
            .createdBy(rs.getString("createdBy"))
            .creationDate(ApiUtil.toLocalDateTime(rs.getTimestamp("creationDate")))
            .lastUpdatedBy(rs.getString("lastUpdatedBy"))
            .lastUpdateDate(ApiUtil.toLocalDateTime(rs.getTimestamp("lastUpdateDate")));

    if (rs.getString("assignmentType") != null) {
      firm.assignmentType(AssignmentType.fromValue(rs.getString("assignmentType")));
    }
    return firm;
  }
}
