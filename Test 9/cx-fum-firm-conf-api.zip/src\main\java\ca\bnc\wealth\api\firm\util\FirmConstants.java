package ca.bnc.wealth.api.firm.util;

public class FirmConstants {

  public static final String FIRM_ASSIGNMENT_NOT_FOUND_CODE = "error.firmAssignment.notFound";
  public static final String FIRM_ASSIGNMENT_NOT_FOUND_MESSAGE = "Firm Assignment %s not found";
  public static final String FIRM_CONFIGURATION_NOT_FOUND_CODE = "error.firmConfiguration.notFound";
  public static final String FIRM_CONFIGURATION_NOT_FOUND_MESSAGE = "Firm Configuration %s not found";
  public static final String FEATURE_PACKAGE_NOT_FOUND_CODE = "error.featurePackage.notFound";
  public static final String FEATURE_PACKAGE_NOT_FOUND_MESSAGE = "Feature Package %s not found";
  public static final String FEATURE_PACKAGE_ASSIGNMENT_NULL_CODE = "error.featurePackageAssignment.input.null";
  public static final String FEATURE_PACKAGE_ASSIGNMENT_NULL_MESSAGE = "Input is null";
  public static final String FEATURE_PACKAGE_ID_NULL_CODE = "error.featurePackageId.null";
  public static final String FEATURE_PACKAGE_ID_NULL_MESSAGE = "Feature Package Id is null";
  public static final String FEATURE_PACKAGE_ASSIGNMENT_EFFECTIVE_DATE_NULL_CODE = "error.featurePackageAssignment.effectiveDate.input.null";
  public static final String FEATURE_PACKAGE_ASSIGNMENT_EFFECTIVE_DATE_NULL_MESSAGE = "effectiveDate Input is null";
  public static final String UPDATE_RR_RANGE_NULL_CODE = "error.updateRrRange.null";
  public static final String UPDATE_RR_RANGE_NULL_MESSAGE = "Input is null";
  public static final String UPDATE_RR_RANGE_EFFECTIVE_DATE_NULL_CODE = "error.updateRrRange.effectiveDate.null";
  public static final String UPDATE_RR_RANGE_EFFECTIVE_DATE_NULL_MESSAGE = "Effective date is null";
  public static final String UPDATE_RR_RANGE_EFFECTIVE_DATE_INVALID_CODE = "error.updateRrRange.effectiveDate.invalid";
  public static final String UPDATE_RR_RANGE_EFFECTIVE_DATE_INVALID_MESSAGE = "Effective date cannot be in the past";
  public static final String UPDATE_RR_RANGE_EXPIRY_DATE_INVALID_CODE = "error.updateRrRange.expiryDate.invalid";
  public static final String UPDATE_RR_RANGE_EXPIRY_DATE_INVALID_MESSAGE = "Expiry date cannot be in the past";
  public static final String UPDATE_RR_RANGE_EXPIRY_DATE_DEFAULT = "9999-12-31";
  public static final String UPDATE_RR_RANGE_LIST_EMPTY_CODE = "error.updateRrRange.rrRange.null";
  public static final String UPDATE_RR_RANGE_LIST_EMPTY_MESSAGE = "RR Range is empty or null";
  public static final String UPDATE_RR_RANGE_LIST_FROM_TO_CODE = "error.updateRrRange.rrRange.fromTo.null";
  public static final String UPDATE_RR_RANGE_LIST_FROM_TO_MESSAGE = "The fields fromRRCode and toRRCode must be provided";
  public static final String UPDATE_RR_RANGE_LIST_NOT_ACTIVE_CODE = "error.updateRrRange.rrRange.notActive";
  public static final String UPDATE_RR_RANGE_LIST_NOT_ACTIVE_MESSAGE = "The RR code range(s) provided does not exist or not active";
  public static final String FIRM_STATE_ACTIVE = "active";
  public static final String FIRM_STATE_INACTIVE = "inactive";
  public static final String FIRM_STATE_DISABLED = "DISABLED";
  public static final String FIRM_STATE_ENABLED = "ENABLED";
  public static final String FIRM_STATE_ONBOARDED = "ONBOARDED";
  public static final String FIRM_STATE_DECOMMISSIONED = "DECOMMISSIONED";
  public static final String NBIN = "NBIN";

  public static final Integer DEFAULT_PAGE_NO = 1;
  public static final Integer DEFAULT_PAGE_SIZE = 50;
  public static final int MAX_PAGE_SIZE = 1000;
  public static final int MAX_SEARCH_TEXT_LENGTH = 200;
  public static final String FIRM_ID_PATTERN = "^[A-Za-z0-9_-]{1,32}$";
  public static final String SEARCH_TEXT_TOO_LONG_CODE = "error.genericSearch.searchText.tooLong";
  public static final String SEARCH_TEXT_TOO_LONG_MESSAGE = "Search text exceeds the maximum allowed length";
  public static final String INVALID_FIRM_ID_CODE = "error.firmId.invalid";
  public static final String INVALID_FIRM_ID_MESSAGE = "Firm id format is invalid";
  public static final String GET_RR_CODE_RANGES_BY_FIRM_QUERY = """
      select
            distinct i1_0."RR_CODE_RANGE_ID",
            i1_0."ACTIVE",
            i1_0."CREATED_BY",
            i1_0."CREATION_DATE",
            i1_0."FROM_RR_CODE",
            i1_0."FROM_RR_CODE_B10",
            i1_0."LAST_UPDATE_DATE",
            i1_0."LAST_UPDATED_BY",
            i1_0."TO_RR_CODE",
            i1_0."TO_RR_CODE_B10",
            f1_0."EFFECTIVE_DATE",
            f1_0."EXPIRY_DATE"
        from
            "IAM_V2"."RR_CODE_RANGE" i1_0
        join
            "IAM_V2"."FIRM_ASSIGNMENT" f1_0
                on i1_0."RR_CODE_RANGE_ID"=f1_0."ASSIGNEE_ID"
        join
            "IAM_V2"."FIRM" f2_0\s
                on f2_0."FIRM_ENTITY_ID"=f1_0."FIRM_ENTITY_ID"
        where
            f2_0."FIRM_ID"=:firm
            and cast(f1_0."ASSIGNMENT_TYPE" as text)=:assignmentType
      """;
  public static final String GET_FEATURE_PACKAGE_BY_FIRM_QUERY = """
      select
            distinct f1_0."FEATURE_PACKAGE_ID",
            f1_0."CREATED_BY",
            f1_0."CREATED_DT",
            f1_0."ACTIVE",
            f1_0."PACKAGE_TEMPLATE_ID",
            f1_0."UPDATED_DT",
            f1_0."UPDATED_BY",
            f1_0."VERSION",
			f4_0."NAME"
        from
            "IAM_V2"."FEATURE_PACKAGE" f1_0
        join
            "IAM_V2"."FIRM_ASSIGNMENT" f2_0
                on f1_0."FEATURE_PACKAGE_ID"=f2_0."ASSIGNEE_ID"
        join
            "IAM_V2"."FIRM" f3_0
                on f3_0."FIRM_ENTITY_ID"=f2_0."FIRM_ENTITY_ID"
        left outer join 
			"IAM_V2"."PACKAGE_TEMPLATE" f4_0
				on f1_0."PACKAGE_TEMPLATE_ID"=f4_0."PACKAGE_TEMPLATE_ID"
        where
            cast(f2_0."ASSIGNMENT_TYPE" as text)=:assignmentType
            and f3_0."FIRM_ID"=:firm
      """;
  public static final String DECODE_RR_CODE_QUERY = """
        select *
          from "IAM_V2".b36_decode(:rrCode);
      """;
  public static final String GET_FIRM_BY_RR_CODE_QUERY = """
      select
            distinct f1_0."FIRM_ENTITY_ID",
            f1_0."ACTIVE",
            f1_0."FIRM_ID",
            f1_0."CREATED_BY",
            f1_0."CREATION_DATE",
            f1_0."DESCRIPTION",
            f1_0."FINANCIAL_ENTITY_ID",
            f1_0."TYPE",
            f1_0."LAST_UPDATE_DATE",
            f1_0."LAST_UPDATED_BY",
            f1_0."NAME",
            f1_0."PARENT_FIRM_ID",
            f1_0."PREFERRED_LANGUAGE",
            f1_0."STATE",
            f1_0."STATUS_LAST_UPDATED",
            p1_0."FIRM_ENTITY_ID" as "PARENT_FIRM_ENTITY_ID",
            f3_0."BROKER_CODE",
            f3_0."B_NUMBER",
            f3_0."DEALER_CODE"
        from
            "IAM_V2"."FIRM" f1_0
        join
            "IAM_V2"."FIRM_ASSIGNMENT" f2_0
                on f1_0."FIRM_ENTITY_ID"=f2_0."FIRM_ENTITY_ID"
        join
            "IAM_V2"."RR_CODE_RANGE" i1_0\s
                on i1_0."RR_CODE_RANGE_ID"=f2_0."ASSIGNEE_ID"
        left join
            "IAM_V2"."FINANCIAL_ENTITY" f3_0
                on f3_0."FINANCIAL_ENTITY_ID"=f1_0."FINANCIAL_ENTITY_ID"
        left join
            "IAM_V2"."FIRM" p1_0
                on p1_0."FIRM_ID"=f1_0."PARENT_FIRM_ID"
        where
          cast(f2_0."ASSIGNMENT_TYPE" as text) = :assignmentType
        """;
  public static final String RR_CODE_B10_CLAUSE = """
      and cast(i1_0."FROM_RR_CODE_B10" as integer)<='%s'
      and cast(i1_0."TO_RR_CODE_B10" as integer)>='%s'
      """;
  public static final String FIRM_FEATURE_PACKAGE_ASSIGNMENT_BATCH_ID = "FEATURE_PACKAGE_ASSIGNMENT_BATCH_ID";

  public static final String GET_RESOURCES_BY_FIRM_QUERY = """
    select R1."NAME", R1."RESOURCE_ID", R1."RESTRICTION"
        from "IAM_V2"."FIRM_ASSIGNMENT" FA
        inner join "IAM_V2"."FIRM" F1 on F1."FIRM_ENTITY_ID"=FA."FIRM_ENTITY_ID"
        inner join "IAM_V2"."FEATURE_PACKAGE" FP on FA."ASSIGNEE_ID" = FP."FEATURE_PACKAGE_ID" and FA."ASSIGNMENT_TYPE" = 'P'
        inner join "IAM_V2"."PACKAGE_TEMPLATE" PT on PT."PACKAGE_TEMPLATE_ID" = FP."PACKAGE_TEMPLATE_ID"
        inner join "IAM_V2"."PACKAGE_TEMPLATE_DETAILS" PTD on PTD."PACKAGE_TEMPLATE_ID" = PT."PACKAGE_TEMPLATE_ID" and PTD."ASSIGNMENT_TYPE" = 'S'
        inner join "IAM_V2"."FEATURE_PACKAGE_DETAILS" FPD on FP."FEATURE_PACKAGE_ID" = FPD."FEATURE_PACKAGE_ID" and PTD."TEMPLATE_DETAIL_ID" = FPD."TEMPLATE_DETAIL_ID" and FPD."SELECTED" = true
        inner join "IAM_V2"."RESOURCE" R1 on R1."RESOURCE_ID" = PTD."ASSIGNEE_ID"
        where F1."FIRM_ID" = :firm;
    """;

  public static final String FIRM_PREFERENCES_UPDATE_FAILED_CODE = "error.firmPreferences.update.failed";
  public static final String FIRM_PREFERENCES_UPDATE_FAILED_MESSAGE = "Failed to update firm preferences for firm %s";

  private FirmConstants() {
    throw new IllegalStateException("Utility class");
  }
}