# Tests — Firm Configuration API

## Test Configuration

### TestConfiguration.java
Custom Spring test configuration that sets up the test application context with mock beans and test-specific settings.

## Test Coverage

| Test File | Component Under Test | Focus |
|-----------|---------------------|-------|
| FirmControllerTests | FirmController | HTTP status codes, response bodies, security context |
| AuditLogEventPublisherTests | AuditLogEventPublisher | Kafka message publishing |
| AuditLogServiceTests | AuditLogService | Before/after state capture, batch processing |
| FirmSearchServiceTests | FirmSearchService | Search criteria, pagination, firm access filtering |
| FirmServiceJpaTest | FirmServiceJpa | RR range assignments, feature packages, materialized view |
| FirmValidationServiceTests | FirmValidationService | Input validation, error codes |
| ApiUtilTests | ApiUtil | Date utilities, number parsing |
| EntityMapperUtilsTests | EntityMapperUtils | Entity ↔ DTO conversions |
| FirmConfigurationRowMapperTests | FirmConfigurationRowMapper | JDBC result set mapping |

## Mock Data

### MockData.java (`utility/MockData.java`)
Centralized test data factory. Use this class to create consistent test fixtures:
- Firm entities and DTOs
- RR code range objects
- User principal objects for security context
- Search request/response payloads

## Running

```bash
# All tests
mvn test

# Specific test class
mvn test -Dtest=FirmControllerTests

# Specific test method
mvn test -Dtest=FirmControllerTests#testGetUserFirmAssignments
```
