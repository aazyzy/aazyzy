package ca.bnc.wealth.api.firm.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.SecurityConfigAdapter;
import ca.bnc.wealth.api.authorization.security.test.TestAuthConfiguration;
import ca.bnc.wealth.api.authorization.security.test.TestUserSingleton;
import ca.bnc.wealth.api.firm.service.*;
import ca.bnc.wealth.api.firm.utility.MockData;
import ca.bnc.wealth.common.firm.model.FeaturePackageAssignment;
import ca.bnc.wealth.common.firm.model.Firm;
import ca.bnc.wealth.common.firm.model.FirmAssignmentType;
import ca.bnc.wealth.common.firm.model.FirmIdHierarchy;
import ca.bnc.wealth.common.firm.model.FirmSearch;
import ca.bnc.wealth.common.firm.model.GenericSearch;
import ca.bnc.wealth.common.firm.model.GenericSearchResponse;
import ca.bnc.wealth.common.firm.model.SearchPayload;
import ca.bnc.wealth.common.firm.model.UpdateRRCodeRange;
import ca.bnc.wealth.common.fum.service.FirmAssignmentService;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import tools.jackson.databind.ObjectMapper;
import java.util.List;
import lombok.SneakyThrows;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@WebMvcTest(properties = {"spring.profiles.active=test"})
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@ContextConfiguration(
    classes = {
        SecurityConfigAdapter.class,
        TestAuthConfiguration.class,
        FirmController.class,
        ca.bnc.wealth.common.spring.microservice.starter.core.exception.GlobalDefaultExceptionHandler
            .class
    })
public class FirmControllerTests {

  @Autowired
  WebApplicationContext webApplicationContext;
  @Autowired
  private MockMvc mockMvc;
  @Autowired
  private ObjectMapper objectMapper;
 

  @MockitoBean
  private FirmServiceJpa firmServiceJpa;
  @MockitoBean
  private FirmSearchService firmSearchService;
  @MockitoBean
  private FirmValidationService firmValidationService;

  @MockitoBean
  private UserAssignmentService userAssignmentService;
  @MockitoBean
  private FirmAssignmentService firmAssignmentService;

  @MockitoBean
  private AuditLogService auditLogService;

  @MockitoBean
  private FirmServiceBma firmServiceBma;

  @Before
  public void setup() {
    mockMvc =
        MockMvcBuilders.webAppContextSetup(webApplicationContext).apply(springSecurity()).build();
    User testUser = new User();
    TestUserSingleton.setTestUser(testUser);
  }

  @Test
  public void testValidateRRCodeRangeJsonResponse() throws Exception {
   Firm firm = MockData.createMockFirmInfoListWithRRCodes().get(0);
    when(firmServiceJpa.getUserFirmAssignments(any())).thenReturn(firm);
    MvcResult mvcResult =
        this.mockMvc
            .perform(get("/firms/assignments/users/me").header(HttpHeaders.AUTHORIZATION, ""))
            .andExpect(status().isOk())
            .andReturn();
    final String json = mvcResult.getResponse().getContentAsString();
    JSONObject jsonObject  = new JSONObject(json);
    JSONArray rrCodeArray = jsonObject.getJSONArray("rrCodeRanges");
    assertTrue(rrCodeArray.length() > 0);
  }





  @Test
  public void testGetFirmByRRCodeRangeAndB10RRCodeRange() throws Exception {
    List<FirmIdHierarchy> firmIdHierarchies = MockData.getFirmIdHierarchyList();

    SearchPayload searchPayload = MockData.getSearchPayload();

    when(firmSearchService.getFirmByRRCodeRangeAndB10RRCodeRange(
        anyString(), Mockito.eq(searchPayload)))
        .thenReturn(firmIdHierarchies);

    MvcResult mvcResult =
        this.mockMvc
            .perform(
                post("/firms/search")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(searchPayload)))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }


  @Test
  public void testFirmSearch() throws Exception{

    List<Firm> firmList = MockData.createMockFirmInfoListWithRRCodes();
    FirmSearch firmSearch = MockData.createFirmSearch();
    String searchjson = objectMapper.writeValueAsString(firmSearch);

    when(firmSearchService.searchFirm(any(),any(FirmSearch.class))).thenReturn(firmList);
    MvcResult mvcResult =
        this.mockMvc
            .perform(post("/firms/firmSearch")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(searchjson)
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();
    final String json = mvcResult.getResponse().getContentAsString();
    JSONArray jsonArray = new JSONArray(json);
    JSONObject jsonObject = jsonArray.getJSONObject(0);
    JSONArray rrCodeArray = jsonObject.getJSONArray("rrCodeRanges");
    assertTrue(rrCodeArray.length() > 0);

  }

  @Test
  public void testGenericSearch()throws Exception{

    GenericSearchResponse genericSearchResponse = MockData.createGenericSearchResponse();
    GenericSearch genericSearch = MockData.createGenericSearch();
    String searchjson = objectMapper.writeValueAsString(genericSearch);

    when(firmSearchService.genericFirmSearch(any(),any(GenericSearch.class))).thenReturn(genericSearchResponse);

    MvcResult mvcResult =
        this.mockMvc
            .perform(post("/firms/genericSearch")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(searchjson)
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();
    final String json = mvcResult.getResponse().getContentAsString();
    JSONArray jsonArray  = new JSONArray(json);
    JSONObject jsonObject = jsonArray.getJSONObject(0);
    String firmId = jsonObject.getString("firmId");
    assertNotNull(firmId);
  }

  @Test
  public void testGenericSearchWithPagination()throws Exception{

    GenericSearchResponse genericSearchResponse = MockData.createGenericSearchResponse();
    GenericSearch genericSearch = MockData.createGenericSearch();
    String searchjson = objectMapper.writeValueAsString(genericSearch);

    when(firmSearchService.genericFirmSearch(any(),any(GenericSearch.class))).thenReturn(genericSearchResponse);

    MvcResult mvcResult =
        this.mockMvc
            .perform(post("/firms/genericSearchWithPagination")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(searchjson)
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();

  }

@Test
@SneakyThrows
public void testAssignmentsRrRangeToFirm(){
  doNothing().when(firmValidationService).validateUpdateRrCodeRangeInput(any());
  firmValidationService.validateUpdateRrCodeRangeInput(any(UpdateRRCodeRange.class));
  doNothing().when(firmServiceJpa).assignmentsRrRangeToFirm(any(),any(),any());

  UpdateRRCodeRange  updateRRCodeRange=MockData.createUpdateRRCodeRange();
  String searchjson = objectMapper.writeValueAsString(updateRRCodeRange);
  MvcResult mvcResult =
      this.mockMvc
          .perform(put("/firms/COR/assignments/rr-range")
              .header(HttpHeaders.AUTHORIZATION, "")
              .with(csrf())
              .content(searchjson)
              .accept(MediaType.APPLICATION_JSON)
              .contentType(MediaType.APPLICATION_JSON))
          .andExpect(status().isNoContent())
          .andReturn();
  assertNotNull(mvcResult);
}

  @Test
  @SneakyThrows
  public void testAssignmentsFeaturePackageToFirm(){
    doNothing().when(firmServiceJpa).assignmentsFeaturePackageToFirm(any(),any(),any());

    FeaturePackageAssignment FeaturePackageAssignment=MockData.createFeaturePackageAssignment();
    String searchjson = objectMapper.writeValueAsString(FeaturePackageAssignment);
    MvcResult mvcResult =
        this.mockMvc
            .perform(put("/firms/COR/assignments/feature-package")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(searchjson)
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isCreated())
            .andReturn();
    assertNotNull(mvcResult);

  }

  @Test
  @SneakyThrows
  public void testDeleteFirmAssignment(){
    doNothing().when(firmAssignmentService).deleteFirmAssignment(any(),any(),any(),any());

    MvcResult mvcResult =
        this.mockMvc
            .perform(delete("/firms/COR/assignments/"+FirmAssignmentType.P+"/123")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf()))
            .andExpect(status().isNoContent())
            .andReturn();
    assertNotNull(mvcResult);
  }



  @Test
  @SneakyThrows
  public void testGetFirmAssignments(){
    when(firmServiceJpa.getFirmAssignments(any(), any())).thenReturn(MockData.createAssignments());
    MvcResult mvcResult =
        this.mockMvc
            .perform(get("/firms/ROC/assignments")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf()))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }
}
