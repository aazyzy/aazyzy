package ca.bnc.wealth.api.firm.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.firm.util.FirmConstants;
import ca.bnc.wealth.api.firm.utility.MockData;
import ca.bnc.wealth.common.firm.model.B10RRCodeRanges;
import ca.bnc.wealth.common.firm.model.Firm;
import ca.bnc.wealth.common.firm.model.FirmIdHierarchy;
import ca.bnc.wealth.common.firm.model.FirmSearch;
import ca.bnc.wealth.common.firm.model.GenericSearch;
import ca.bnc.wealth.common.firm.model.GenericSearchResponse;
import ca.bnc.wealth.common.firm.model.SearchPayload;
import ca.bnc.wealth.common.fum.service.FirmServiceHelper;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class FirmSearchServiceTests {

  private FirmSearchService firmSearchService;

  @MockitoBean
  private FirmRepository firmRepository;

  @MockitoBean
  private IamRrCodeRangeRepository iamRrCodeRangeRepository;

  @MockitoBean
  private FirmServiceHelper firmServiceHelper;

  @MockitoBean
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @SneakyThrows
  @Before
  public void setup() {
    firmSearchService = new FirmSearchService();
    FieldUtils.writeField(firmSearchService, "firmRepository", firmRepository, true);
    FieldUtils.writeField(firmSearchService, "iamRrCodeRangeRepository", iamRrCodeRangeRepository,
        true);
    FieldUtils.writeField(firmSearchService, "firmServiceHelper", firmServiceHelper, true);
    FieldUtils.writeField(firmSearchService, "namedParameterJdbcTemplate",
        namedParameterJdbcTemplate,
        true);
  }


  @Test
  public void searchFirmByNbinUser() {
    ca.bnc.wealth.common.jpa.entity.iam.Firm firm1 = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm1.setFirmEntityId(1L);
    firm1.setFirmId("NBIN");
    firm1.setFirmType(FirmType.IB);

    ca.bnc.wealth.common.jpa.entity.iam.Firm firm2 = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm2.setFirmEntityId(2L);
    firm2.setFirmId("NBC");
    firm2.setFirmType(FirmType.IB);
    when(firmRepository.getAllFirmsByIdpSubject(anyString())).thenReturn(
        List.of(1L, 2L));
    when(firmRepository.count()).thenReturn(2L);
    when(firmRepository.findAll(any(Specification.class))).thenReturn(
        List.of(firm1, firm2));

    List<Firm> lst = firmSearchService.searchFirm("abc", new FirmSearch());
    assertEquals(2, lst.size());
  }

  @Test
  public void searchFirm() {
    ca.bnc.wealth.common.jpa.entity.iam.Firm firm1 = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm1.setFirmEntityId(1L);
    firm1.setFirmId("NBIN");
    firm1.setFirmType(FirmType.IB);
    ca.bnc.wealth.common.jpa.entity.iam.Firm firm2 = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm2.setFirmEntityId(2L);
    firm2.setFirmId("NBC");
    firm2.setFirmType(FirmType.IB);

    when(firmRepository.getAllFirmsByIdpSubject(anyString())).thenReturn(List.of(2L));
    when(firmRepository.count()).thenReturn(2L);
    when(firmRepository.findAll(any(Specification.class))).thenReturn(
        List.of(firm2));

    List<Firm> lst = firmSearchService.searchFirm("abc", new FirmSearch());
    assertEquals(1, lst.size());
  }

  @Test
  public void genericFirmSearchByNbinUser() {
    ca.bnc.wealth.common.jpa.entity.iam.Firm firm1 = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm1.setFirmEntityId(1L);
    firm1.setFirmId("NBIN");
    firm1.setFirmType(FirmType.IB);
    ca.bnc.wealth.common.jpa.entity.iam.Firm firm2 = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm2.setFirmEntityId(2L);
    firm2.setFirmId("NBC");
    firm2.setFirmType(FirmType.IB);

    when(firmRepository.getAllFirmsByIdpSubject(anyString())).thenReturn(
        List.of(1L, 2L));
    when(firmRepository.count(any(Specification.class))).thenReturn(2L);
    when(firmRepository.findAll(any(Specification.class),
        any(PageRequest.class))).thenReturn(
        new PageImpl(List.of(firm1, firm2)));
    GenericSearch gs = new GenericSearch();
    gs.searchText("NB");
    GenericSearchResponse response = firmSearchService.genericFirmSearch("abc", gs);
    assertEquals(2, response.getFirms().size());
  }

  @Test
  public void genericFirmSearch() {
    ca.bnc.wealth.common.jpa.entity.iam.Firm firm1 = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm1.setFirmEntityId(1L);
    firm1.setFirmId("NBIN");
    firm1.setFirmType(FirmType.IB);
    ca.bnc.wealth.common.jpa.entity.iam.Firm firm2 = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm2.setFirmEntityId(2L);
    firm2.setFirmId("NBC");
    firm2.setFirmType(FirmType.IB);
    when(firmRepository.getAllFirmsByIdpSubject(anyString())).thenReturn(List.of(2L));
    when(firmRepository.count(any(Specification.class))).thenReturn(2L);
    when(firmRepository.findAll(any(Specification.class),
        any(PageRequest.class))).thenReturn(new PageImpl(List.of(firm2)));

    GenericSearch gs = new GenericSearch();
    gs.searchText("NB");
    GenericSearchResponse response = firmSearchService.genericFirmSearch("abc", gs);
    assertEquals(1, response.getFirms().size());
  }

  @Test
  public void testGetFirmByRRCodeRangeAndB10RRCodeRangeWithRrCode() {
    Map<String, Object> rrCodeMap = Map.of("b36_decode", 123L);
    when(namedParameterJdbcTemplate.queryForMap(eq(FirmConstants.DECODE_RR_CODE_QUERY),
        any(SqlParameterSource.class))).thenReturn(rrCodeMap);

    int firmId = 123;
    Map<String, Object> firmMap = Map.of("FIRM_ENTITY_ID", firmId,
        "FIRM_ID", "NBIN",
        "TYPE", FirmType.IB,
        "PREFERRED_LANGUAGE", PreferredLanguageType.EN,
        "CREATION_DATE", new Timestamp(System.currentTimeMillis()));
    when(namedParameterJdbcTemplate.queryForList(
        eq(FirmConstants.GET_FIRM_BY_RR_CODE_QUERY + String.format(FirmConstants.RR_CODE_B10_CLAUSE,
            firmId, firmId)),
        any(SqlParameterSource.class))).thenReturn(List.of(firmMap));

    ca.bnc.wealth.common.jpa.entity.iam.Firm firm = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm.setFirmEntityId(123L);
    when(firmServiceHelper.getPrimaryFirmByIdpSubjectUsingJdbc(anyString(), anyBoolean())).thenReturn(List.of(firmMap));

    List<FirmIdHierarchy> firmIdHierarchies = firmSearchService.getFirmByRRCodeRangeAndB10RRCodeRange(
        "1234", MockData.getSearchPayloadWithRrCode());
    assertEquals(String.valueOf(firmMap.get("FIRM_ID")), firmIdHierarchies.get(0).getFirmId());
    assertEquals("1", firmIdHierarchies.get(0).getHierarchyLevel());
  }

  @Test
  public void testGetFirmByRRCodeRangeAndB10RRCodeRangeWithRrCodeRange() {
    long rrCodeB10Value = 123L;
    Map<String, Object> rrCodeMap = Map.of("b36_decode", rrCodeB10Value);
    when(namedParameterJdbcTemplate.queryForMap(eq(FirmConstants.DECODE_RR_CODE_QUERY),
        any(SqlParameterSource.class))).thenReturn(rrCodeMap);

    int parentFirmId = 123;
    int childFirmId = 124;
    Map<String, Object> parentFirmMap = Map.of("FIRM_ENTITY_ID", parentFirmId,
        "FIRM_ID", "NBIN",
        "TYPE", FirmType.IB,
        "PREFERRED_LANGUAGE", PreferredLanguageType.EN,
        "CREATION_DATE", new Timestamp(System.currentTimeMillis()));

    Map<String, Object> childFirmMap = Map.of("FIRM_ENTITY_ID", childFirmId,
        "FIRM_ID", "CHILD_FIRM",
        "TYPE", FirmType.IB,
        "PARENT_FIRM_ENTITY_ID", parentFirmId,
        "PARENT_FIRM_ID", "NBIN",
        "PREFERRED_LANGUAGE", PreferredLanguageType.EN,
        "CREATION_DATE", new Timestamp(System.currentTimeMillis()));

    String firmQuery = FirmConstants.GET_FIRM_BY_RR_CODE_QUERY
        + String.format(FirmConstants.RR_CODE_B10_CLAUSE, rrCodeB10Value, rrCodeB10Value)
        + String.format(FirmConstants.RR_CODE_B10_CLAUSE, rrCodeB10Value, rrCodeB10Value)
        + String.format(FirmConstants.RR_CODE_B10_CLAUSE, rrCodeB10Value, rrCodeB10Value)
        + String.format(FirmConstants.RR_CODE_B10_CLAUSE, rrCodeB10Value, rrCodeB10Value);
    when(namedParameterJdbcTemplate.queryForList(
        eq(firmQuery), any(SqlParameterSource.class))).thenReturn(
        List.of(parentFirmMap, childFirmMap));

    ca.bnc.wealth.common.jpa.entity.iam.Firm firm = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm.setFirmEntityId(123L);
    when(firmServiceHelper.getPrimaryFirmByIdpSubjectUsingJdbc(any(String.class), anyBoolean())).thenReturn(List.of(parentFirmMap));

    SearchPayload searchPayload = MockData.getSearchPayloadWithRrCodeRange();
    searchPayload.setRrCode(String.valueOf(rrCodeB10Value));
    searchPayload.setB10RrCode((int) rrCodeB10Value);
    searchPayload.setB10RrCodeRange(
        new B10RRCodeRanges().from((int) rrCodeB10Value).to((int) rrCodeB10Value));
    List<FirmIdHierarchy> firmIdHierarchies = firmSearchService.getFirmByRRCodeRangeAndB10RRCodeRange(
        "1234", searchPayload);
    assertEquals(String.valueOf(parentFirmMap.get("FIRM_ID")),
        firmIdHierarchies.get(0).getFirmId());
    assertEquals("1", firmIdHierarchies.get(0).getHierarchyLevel());
    assertEquals(String.valueOf(childFirmMap.get("FIRM_ID")), firmIdHierarchies.get(1).getFirmId());
    assertEquals("2", firmIdHierarchies.get(1).getHierarchyLevel());
  }
}
