package ca.bnc.wealth.api.firm.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.bma.service.BulkManagementClientService;
import ca.bnc.wealth.common.firm.model.FeaturePackageAssignment;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import tools.jackson.databind.ObjectMapper;
import java.util.HashMap;
import java.util.Map;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import tools.jackson.core.JacksonException;

@RunWith(MockitoJUnitRunner.class)
public class FirmServiceBmaTest {

  @Mock
  private BulkManagementClientService bulkManagementClientService;

  @Mock
  private FirmRepository firmRepository;

  @Mock
  private ObjectMapper objectMapper;

  @InjectMocks
  private FirmServiceBma firmServiceBma;

  private static final String FIRM_ID = "FIRM001";
  private static final String BATCH_ID = "batch-123";

  private Firm firm;
  private FeaturePackageAssignment featurePackageAssignment;

  @Before
  public void setUp() {
    firm = new Firm();
    firm.setFirmId(FIRM_ID);

    featurePackageAssignment = new FeaturePackageAssignment();
  }

  @Test
  public void testAssignmentsFeaturePackageToFirm_withExistingPreferences() {
    Map<String, String> existingPrefs = new HashMap<>();
    existingPrefs.put("existingKey", "existingValue");
    firm.setFirmPreferences(existingPrefs);

    when(bulkManagementClientService.upload(eq("FirmSetting"), eq(FIRM_ID), anyList(), anyString()))
        .thenReturn(BATCH_ID);
    doNothing().when(bulkManagementClientService).triggerBulkProcess(BATCH_ID);
    when(firmRepository.findByFirmId(FIRM_ID)).thenReturn(firm);
    when(objectMapper.writeValueAsString(any())).thenReturn("{\"existingKey\":\"existingValue\",\"featurePackageAssignmentBatchId\":\"batch-123\"}");

    firmServiceBma.assignmentsFeaturePackageToFirm(FIRM_ID, featurePackageAssignment);

    verify(firmRepository).updateFirmPreferences(eq(FIRM_ID), anyString());
    verify(bulkManagementClientService).triggerBulkProcess(BATCH_ID);
  }

  @Test
  public void testAssignmentsFeaturePackageToFirm_withNullPreferences() {
    firm.setFirmPreferences(null);

    when(bulkManagementClientService.upload(eq("FirmSetting"), eq(FIRM_ID), anyList(), anyString()))
        .thenReturn(BATCH_ID);
    doNothing().when(bulkManagementClientService).triggerBulkProcess(BATCH_ID);
    when(firmRepository.findByFirmId(FIRM_ID)).thenReturn(firm);
    when(objectMapper.writeValueAsString(any())).thenReturn("{\"featurePackageAssignmentBatchId\":\"batch-123\"}");

    firmServiceBma.assignmentsFeaturePackageToFirm(FIRM_ID, featurePackageAssignment);

    verify(firmRepository).updateFirmPreferences(eq(FIRM_ID), anyString());
    verify(bulkManagementClientService).triggerBulkProcess(BATCH_ID);
  }

  @Test(expected = FumServiceException.class)
  public void testAssignmentsFeaturePackageToFirm_jsonProcessingException() {
    firm.setFirmPreferences(null);

    when(bulkManagementClientService.upload(eq("FirmSetting"), eq(FIRM_ID), anyList(), anyString()))
        .thenReturn(BATCH_ID);
    doNothing().when(bulkManagementClientService).triggerBulkProcess(BATCH_ID);
    when(firmRepository.findByFirmId(FIRM_ID)).thenReturn(firm);
    when(objectMapper.writeValueAsString(any()))
        .thenThrow(new JacksonException("Serialization failed") {});

    firmServiceBma.assignmentsFeaturePackageToFirm(FIRM_ID, featurePackageAssignment);
  }
}
