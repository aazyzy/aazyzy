package ca.bnc.wealth.api.firm.service;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.firm.dao.RrCodeRangeDao;
import ca.bnc.wealth.api.firm.utility.MockData;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.firm.model.FeaturePackageAssignment;
import ca.bnc.wealth.common.firm.model.RRCodeRange;
import ca.bnc.wealth.common.firm.model.UpdateRRCodeRange;
import ca.bnc.wealth.common.fum.service.FirmAssignmentService;
import ca.bnc.wealth.common.fum.service.FirmServiceHelper;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.fum.service.RrCodeServiceHelper;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.platform.RrCodeRange;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmAssignmentRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.fum.service.UserSearchViewRefreshService;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class FirmServiceJpaTest {

  private FirmServiceJpa firmServiceJpa;

  @MockitoBean
  private FirmAssignmentRrCodeRangeRepository firmAssignmentRrCodeRangeRepository;
  @MockitoBean
  private FirmRepository firmRepository;
  @MockitoBean
  private IamRrCodeRangeRepository iamRrCodeRangeRepository;

  @MockitoBean
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
  @MockitoBean
  private UserSearchViewRefreshService userSearchViewRefreshService;
  @MockitoBean
  private FirmServiceHelper firmServiceHelper;
  @MockitoBean
  private RrCodeServiceHelper rrCodeServiceHelper;
  @MockitoBean
  FirmValidationService firmValidationService;
  @MockitoBean
  FeaturePackageRepository featurePackageRepository;
  @MockitoBean
  FirmAssignmentService firmAssignmentService;
  @MockitoBean
  RedisCacheOperationService redisCacheOperationService;

  @Before
  public void setup() {
    firmServiceJpa = new FirmServiceJpa(firmAssignmentRrCodeRangeRepository, firmRepository,
        firmValidationService, namedParameterJdbcTemplate, userSearchViewRefreshService,
        firmServiceHelper, rrCodeServiceHelper, firmAssignmentService, redisCacheOperationService);
    // Mockito 5.23 answers an unstubbed CompletableFuture with a completed future; 5.11 (Spring Boot 3) answered null
    when(rrCodeServiceHelper.getRrRangeEntityAsync(anyString(), anyString(), eq(true))).thenReturn(null);
  }

  @Test
  public void testUpdateFirmRRCodeRange() {
    IamRrCodeRange iamRrCodeRange = new IamRrCodeRange();
    iamRrCodeRange.setFromRrCode("R0AA");
    iamRrCodeRange.setToRrCode("R099");

    ca.bnc.wealth.common.jpa.entity.iam.Firm firm = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm.setFirmId("100");
    firm.setFirmEntityId(100L);
    UpdateRRCodeRange UpdateRRCodeRange = MockData.createUpdateRRCodeRange();
    when(firmRepository.getAllFirmsByIdpSubject(anyString())).thenReturn(List.of(100L));
    when(firmRepository.findByFirmId(anyString())).thenReturn(firm);
    when(rrCodeServiceHelper.getRrRangeEntityAsync(anyString(), anyString(), eq(true))).thenReturn(CompletableFuture.completedFuture(iamRrCodeRange));
    /*when(iamRrCodeRangeRepository.findAll(any(Specification.class))).thenReturn(
        List.of(iamRrCodeRange));*/

    try {
      firmServiceJpa.assignmentsRrRangeToFirm("1234", "NBIN", UpdateRRCodeRange);
    } catch (Exception e) {
      fail("This test case should not throw any exception");
    }
  }

  @Test
  public void testGetFirmAssignment() {
    IamRrCodeRange iamRrCodeRange = new IamRrCodeRange();
    iamRrCodeRange.setFromRrCode("ADC12");
    iamRrCodeRange.setToRrCode("ADC1F");
    when(iamRrCodeRangeRepository.findAll(any(Specification.class))).thenReturn(
        List.of(iamRrCodeRange));

    firmServiceJpa.getFirmAssignments("abc", List.of(ca.bnc.wealth.common.firm.model.FirmAssignmentType.R));
    firmServiceJpa.getFirmAssignments("abc", List.of(ca.bnc.wealth.common.firm.model.FirmAssignmentType.P));
  }

  @Test
  public void testGetFirmAssignment_whenAssignmentTypeIsNull_shouldNotHaveAnyAssignments() {
    assertTrue(firmServiceJpa.getFirmAssignments("abc", null).isEmpty());
  }

  @Test
  public void TestGetFirm() {
    ca.bnc.wealth.common.jpa.entity.iam.Firm firm = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm.setFirmEntityId(1L);
    firm.setFirmId("NBIN");
    firm.setFirmType(FirmType.IB);

    when(firmRepository.findById(anyLong())).thenReturn(Optional.of(firm));

    when(firmRepository.findByFirmId(anyString())).thenReturn(firm);
    firmServiceJpa.getFirm("123");
    firmServiceJpa.getFirm("abc");
  }

  @Test
  public void testIsRRCodeRangeActive() {
    RrCodeRangeDao rrCodeRange = new RrCodeRangeDao();
    rrCodeRange.setFromRrCode("AAAA");
    rrCodeRange.setToRrCode("ZZZZ");
    rrCodeRange.setRrCodeRangeId(1);
    rrCodeRange.setActive(true);

    // when invalid effective and expiry date
    rrCodeRange.setEffectiveDate(new Timestamp(System.currentTimeMillis() - 100));
    rrCodeRange.setExpiryDate(new Timestamp(System.currentTimeMillis() - 200));
    assertFalse(firmServiceJpa.isRRCodeRangeActive(rrCodeRange));

    // when valid effective and expiry date
    rrCodeRange.setEffectiveDate(new Timestamp(System.currentTimeMillis() - 100));
    rrCodeRange.setExpiryDate(new Timestamp(System.currentTimeMillis() + 100));
    assertTrue(firmServiceJpa.isRRCodeRangeActive(rrCodeRange));
  }

  @Test(expected = Exception.class)
  public void testUpdateFirmRRCodeRange_whenFindCodeValueMappingCallFails_shouldThrowException() {
    RRCodeRange rrCodeRangeModel = MockData.getRRCodeRange("R0AA", "R099");
    RrCodeRange rrCodeRangeEntity = mapRRCodeRangeModelToEntity(rrCodeRangeModel);

    ca.bnc.wealth.common.jpa.entity.iam.Firm firm = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm.setFirmId("100");
    firm.setFirmEntityId(100L);

    when(firmRepository.getAllFirmsByIdpSubject(anyString())).thenReturn(List.of(100L));
    when(firmRepository.findByFirmId(anyString())).thenReturn(firm);
    when(iamRrCodeRangeRepository.findAll(any(Specification.class))).thenReturn(
        List.of(rrCodeRangeEntity));

    firmServiceJpa.assignmentsRrRangeToFirm("1234", "NBIN", MockData.createUpdateRRCodeRange());
  }

  @Test(expected = Exception.class)
  public void testUpdateFirmRRCodeRange_whenDeleteExistingRrCodeRangeAssignmentsCallFails_shouldThrowException() {
    RRCodeRange rrCodeRangeModel = MockData.getRRCodeRange("R0AA", "R099");
    RrCodeRange rrCodeRangeEntity = mapRRCodeRangeModelToEntity(rrCodeRangeModel);

    ca.bnc.wealth.common.jpa.entity.iam.Firm firm = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm.setFirmId("100");
    firm.setFirmEntityId(100L);

    when(firmRepository.getAllFirmsByIdpSubject(anyString())).thenReturn(List.of(100L));
    when(firmRepository.findByFirmId(anyString())).thenReturn(firm);
    when(firmRepository.findAll(any(Specification.class))).thenReturn(List.of(rrCodeRangeEntity));

    firmServiceJpa.assignmentsRrRangeToFirm("1234", "NBIN", MockData.createUpdateRRCodeRange());
  }

  @Test(expected = Exception.class)
  public void testUpdateFirmRRCodeRange_whenSavingNewRrCodeRangeAssignmentsCallFails_shouldThrowException() {
    ca.bnc.wealth.common.jpa.entity.iam.Firm firm = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm.setFirmId("100");
    firm.setFirmEntityId(100L);

    when(firmRepository.getAllFirmsByIdpSubject(anyString())).thenReturn(
        List.of(100L));
    when(firmRepository.findByFirmId(anyString())).thenReturn(firm);

    firmServiceJpa.assignmentsRrRangeToFirm("1234", "NBIN", MockData.createUpdateRRCodeRange());
  }

  @Test(expected = FumNotFoundException.class)
  public void testUpdateFirmRRCodeRange_FumNotFoundException() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class))).thenReturn(
        MockData.getRrCodeRangeListOneItem());
    firmServiceJpa.assignmentsRrRangeToFirm("1234", "NBIN", MockData.createUpdateRRCodeRange());
  }

  @Test
  public void testShutdownAndAwait() {
    ExecutorService executor = Executors.newFixedThreadPool(10);
    firmServiceJpa.shutdownAndAwait(executor);
  }

  @Test
  public void refreshUserSearchMaterializedView_delegatesToRefreshService() {
    firmServiceJpa.refreshUserSearchMaterializedView(true);
    verify(userSearchViewRefreshService).refreshNow(true);
  }

  @Test(expected = FumNotFoundException.class)
  public void testAssignmentsFeaturePackageToFirm_FumNotFoundException() {

    doThrow(new FumNotFoundException("","Not Found")).when(firmValidationService).validateFeaturePackageAssignment(any());
    when(firmRepository.findById(any())).thenReturn(MockData.createMockFirm());

    when(featurePackageRepository.findById(any())).thenReturn(Optional.of(MockData.createFeaturePackage()));
    firmServiceJpa.assignmentsFeaturePackageToFirm("123","ROC",null);

  }

  @Test
  public void testAssignmentsFeaturePackageToFirm() {
    doNothing().when(firmValidationService).validateFeaturePackageAssignment(any(
        FeaturePackageAssignment.class));
    when(firmRepository.findById(any())).thenReturn(MockData.createMockFirm());

    when(featurePackageRepository.findById(any())).thenReturn(Optional.of(MockData.createFeaturePackage()));
    FeaturePackageAssignment featurePackageAssignment=MockData.createFeaturePackageAssignment();
    firmServiceJpa.assignmentsFeaturePackageToFirm("123","126",featurePackageAssignment);
  }

  private RrCodeRange mapRRCodeRangeModelToEntity(RRCodeRange rrCodeRangeModel) {
    RrCodeRange rrCodeRangeEntity = new RrCodeRange();
    rrCodeRangeEntity.setFromRrCode(rrCodeRangeModel.getFromRRCode());
    rrCodeRangeEntity.setToRrCode(rrCodeRangeModel.getToRRCode());
    return rrCodeRangeEntity;
  }
}