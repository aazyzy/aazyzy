package ca.bnc.wealth.api.firm.service;

import static org.junit.Assert.fail;

import ca.bnc.wealth.api.firm.utility.MockData;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.firm.model.FeaturePackageAssignment;
import ca.bnc.wealth.common.firm.model.UpdateRRCodeRange;
import java.time.LocalDate;
import org.junit.Test;

public class FirmValidationServiceTests {

  private final FirmValidationService validationService = new FirmValidationService();

  @Test
  public void testValidateUpdateRrCodeRangeInput_whenValidInput_shouldNotThrowException() {
    try {
      validationService.validateUpdateRrCodeRangeInput(MockData.createUpdateRRCodeRange());
    } catch (Exception e) {
      fail("Should not throw exception");
    }
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUpdateRrCodeRangeInput_whenInputIsNull_shouldThrowException() {
    validationService.validateUpdateRrCodeRangeInput(null);
  }

  @Test
  public void testValidateUpdateRrCodeRangeInput_whenEmptyInput_shouldNotThrowException() {
    try {
      validationService.validateUpdateRrCodeRangeInput(new UpdateRRCodeRange() );
    } catch (Exception e) {

    }
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUpdateRrCodeRangeInput_whenFromRRCodeFieldIsNull_shouldThrowException() {
    UpdateRRCodeRange updateRRCodeRange= MockData.createUpdateRRCodeRange();
    updateRRCodeRange.getRrRanges().get(0).setFromRRCode(null);
    validationService.validateUpdateRrCodeRangeInput(updateRRCodeRange);
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUpdateRrCodeRangeInput_expiredateistooearly_shouldThrowException() {
    UpdateRRCodeRange updateRRCodeRange= MockData.createUpdateRRCodeRange();
    updateRRCodeRange.setExpiryDate(LocalDate.of(2023,01,01));

    validationService.validateUpdateRrCodeRangeInput(updateRRCodeRange);
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUpdateRrCodeRangeInput_effectivedateistooearly_shouldThrowException() {
    UpdateRRCodeRange updateRRCodeRange= MockData.createUpdateRRCodeRange();
    updateRRCodeRange.setEffectiveDate(LocalDate.of(2023,01,01));

    validationService.validateUpdateRrCodeRangeInput(updateRRCodeRange);
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUpdateRrCodeRangeInput_whenToRRCodeFieldIsNull_shouldThrowException() {
    UpdateRRCodeRange updateRRCodeRange= MockData.createUpdateRRCodeRange();
    updateRRCodeRange.getRrRanges().get(0).setToRRCode(null);
    validationService.validateUpdateRrCodeRangeInput(updateRRCodeRange);
  }

  @Test(expected = FumValidationException.class)
  public void testValidateFeaturePackageAssignment(){

    validationService.validateFeaturePackageAssignment(null);
  }

  @Test(expected = FumValidationException.class)
  public void testValidateFeaturePackageAssignmentNullFeaturePackage(){
    FeaturePackageAssignment featurePackageAssignment=new FeaturePackageAssignment();
    validationService.validateFeaturePackageAssignment(featurePackageAssignment);
  }
}
