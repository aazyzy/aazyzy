package ca.bnc.wealth.api.firm.util;


import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.Constructor;
import java.sql.Timestamp;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class ApiUtilTests {

  @Test(expected = IllegalStateException.class)
  public void testApiUtilsConstructor() throws Exception {
    Constructor<ApiUtil> constructor = ApiUtil.class.getDeclaredConstructor();
    constructor.setAccessible(true);
    try {
      constructor.newInstance();
    } catch (Exception e) {
      throw (IllegalStateException) e.getCause();
    }
  }

  @Test
  public void testToLocalDateTime() {
    assertNull(ApiUtil.toLocalDateTime(null));
    assertNotNull(ApiUtil.toLocalDateTime(new Timestamp(System.currentTimeMillis())));
  }

  @Test
  public void testIsNumber() {
    assertTrue(ApiUtil.isNumber("1"));
    assertFalse(ApiUtil.isNumber("String"));
  }



  @Test
  public void testIsDateWithinCurrentDate(){

    Timestamp startDate=new Timestamp(System.currentTimeMillis()-100);
    Timestamp endDate=new Timestamp(System.currentTimeMillis()+100);
    assertTrue(ApiUtil.isDateWithinCurrentDate(startDate,endDate));
  }


  @Test
  public void testIsDateWithinRange(){
    Timestamp currentTimeStamp=new Timestamp(System.currentTimeMillis());
    Timestamp startDate=new Timestamp(System.currentTimeMillis()-100);
    Timestamp endDate=new Timestamp(System.currentTimeMillis()+100);
    assertTrue(ApiUtil.isDateWithinRange(currentTimeStamp,startDate,endDate));

  }

}
