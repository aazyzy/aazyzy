package ca.bnc.wealth.api.firm.util;

import ca.bnc.wealth.api.firm.dao.RrCodeRangeDao;
import ca.bnc.wealth.api.firm.utility.MockData;
import ca.bnc.wealth.common.firm.model.*;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.iam.FinancialEntity;
import ca.bnc.wealth.common.jpa.utils.Filter;
import ca.bnc.wealth.common.kafka.model.RrCodeRanges;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

@RunWith(SpringRunner.class)
public class EntityMapperUtilsTests {

  @Test(expected = IllegalStateException.class)
  public void testEntityMapperUtilsConstructor() throws Exception {
    Constructor<EntityMapperUtils> constructor = EntityMapperUtils.class.getDeclaredConstructor();
    constructor.setAccessible(true);
    try {
      constructor.newInstance();
    } catch (Exception e) {
      throw (IllegalStateException) e.getCause();
    }
  }

  @Test
  public void toDtoFirmConfiguration() {
    FinancialEntity financialEntity = new FinancialEntity();
    financialEntity.setFinancialEntityId(1);
    ca.bnc.wealth.common.jpa.entity.iam.Firm firm = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firm.setFirmEntityId(1L);
    firm.setFirmId("NBIN");
    firm.setFirmType(FirmType.IB);
    firm.setFinancialEntity(financialEntity);

    Firm firmRes = EntityMapperUtils.toDto(firm);
    assertEquals(1, firmRes.getFirmEntityId());
    assertEquals("NBIN", firmRes.getFirmId());
    assertEquals(1, firmRes.getFinancialLegalEntityId());
  }

  @Test
  public void toDtoRRCodeRange() {
    Map<String, Object> rrCodeRangeMap = new HashMap<>();
    rrCodeRangeMap.put("RR_CODE_RANGE_ID", 1);
    rrCodeRangeMap.put("FROM_RR_CODE", "AA11");
    rrCodeRangeMap.put("FROM_RR_CODE_B10", 0L);
    rrCodeRangeMap.put("TO_RR_CODE", "AA99");
    rrCodeRangeMap.put("TO_RR_CODE_B10", 1679615L);
    rrCodeRangeMap.put("CREATED_BY", "createdBy");
    rrCodeRangeMap.put("LAST_UPDATED_BY", "lastUpdatedBy");

    RRCodeRange response = EntityMapperUtils.toRRCodeRangeDto(rrCodeRangeMap);

    assertEquals(rrCodeRangeMap.get("RR_CODE_RANGE_ID"), response.getRrCodeRangeId());
    assertEquals(rrCodeRangeMap.get("FROM_RR_CODE"), response.getFromRRCode());
    assertEquals(((Long) rrCodeRangeMap.get("FROM_RR_CODE_B10")).intValue(), response.getFromRRCodeB10());
    assertEquals(rrCodeRangeMap.get("TO_RR_CODE"), response.getToRRCode());
    assertEquals(((Long) rrCodeRangeMap.get("TO_RR_CODE_B10")).intValue(), response.getToRRCodeB10());
    assertEquals(rrCodeRangeMap.get("CREATED_BY"), response.getCreatedBy());
    assertNull(response.getCreationDate());
    assertEquals(rrCodeRangeMap.get("LAST_UPDATED_BY"), response.getLastUpdatedBy());
    assertNull(response.getLastUpdatedDate());

    rrCodeRangeMap.put("CREATION_DATE", new Timestamp(System.currentTimeMillis()));
    rrCodeRangeMap.put("LAST_UPDATE_DATE", new Timestamp(System.currentTimeMillis()));

    response = EntityMapperUtils.toRRCodeRangeDto(rrCodeRangeMap);
    assertEquals(((Timestamp) rrCodeRangeMap.get("CREATION_DATE")).toLocalDateTime(), response.getCreationDate());
    assertEquals(((Timestamp) rrCodeRangeMap.get("LAST_UPDATE_DATE")).toLocalDateTime(), response.getLastUpdatedDate());
  }

  @Test
  public void testToDtoRRCodeRange() {
    RrCodeRangeDao rrCodeRange = new RrCodeRangeDao();
    rrCodeRange.setFromRrCode("AA11");
    rrCodeRange.setToRrCode("AA99");

    ca.bnc.wealth.common.firm.model.Assignment response = EntityMapperUtils.toDto(rrCodeRange);
    assertEquals("AA11", response.getFromRRCode());
    assertEquals("AA99", response.getToRRCode());
  }

  @Test
  public void testToDtoRrCode() {
    RrCodeRanges rrCodeRange = new RrCodeRanges();
    rrCodeRange.setFromRRCode("from");
    rrCodeRange.setToRRCode("to");

    RRCodeRange rrCode = EntityMapperUtils.toDto(rrCodeRange);
    assertEquals(rrCodeRange.getFromRRCode(), rrCode.getFromRRCode());
    assertEquals(rrCodeRange.getToRRCode(), rrCode.getToRRCode());
  }

  @Test
  public void testConvertState() {
    assertNull(EntityMapperUtils.convertState(""));
    assertEquals("ENABLED", EntityMapperUtils.convertState("active"));
    assertEquals("DISABLED", EntityMapperUtils.convertState("inactive"));
    assertEquals("ONBOARDED", EntityMapperUtils.convertState("onboarded"));
    assertEquals("DECOMMISSIONED", EntityMapperUtils.convertState("decommissioned"));
  }

  @Test
  public void testConvertStateToDB()
      throws InvocationTargetException, IllegalAccessException, NoSuchMethodException {
    assertEquals(FirmConstants.FIRM_STATE_ACTIVE,
        getConvertStateToDBMethod().invoke(null, new String[]{FirmConstants.FIRM_STATE_ENABLED}));
    assertTrue(FirmConstants.FIRM_STATE_INACTIVE.equalsIgnoreCase(
        (String) getConvertStateToDBMethod().invoke(null,
            new String[]{FirmConstants.FIRM_STATE_DISABLED})));
    assertTrue(FirmConstants.FIRM_STATE_ONBOARDED.equalsIgnoreCase(
        (String) getConvertStateToDBMethod().invoke(null,
            new String[]{FirmConstants.FIRM_STATE_ONBOARDED})));
    assertTrue(FirmConstants.FIRM_STATE_DECOMMISSIONED.equalsIgnoreCase(
        (String) getConvertStateToDBMethod().invoke(null,
            new String[]{FirmConstants.FIRM_STATE_DECOMMISSIONED})));
  }

  @Test
  public void testGenericSearchFilterToDto() {
    GenericSearchFilter genericSearchFilter = new GenericSearchFilter();
    genericSearchFilter.setFieldName("abc");

    genericSearchFilter.setFilterCondition(FilterCondition.ENDS_WITH);
    assertEquals("abc", EntityMapperUtils.toDto(genericSearchFilter).getFieldName());
  }

  @Test
  public void testUpdateState() {
    Filter filter = new Filter();
    filter.setFieldName("state");
    List list = new ArrayList();
    list.add(FirmConstants.FIRM_STATE_ENABLED);
    filter.setFieldValue(list);
    Filter filterRes = EntityMapperUtils.updateState(filter);
    List a = (List) filterRes.getFieldValue();
    assertEquals(FirmConstants.FIRM_STATE_ACTIVE, (a.stream().findFirst().get()));
  }

  @Test
  public void testGetList() throws Exception {
    List list = new ArrayList();
    list.add("a");
    list.add("b");
    ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().build();
    List<Object> objs = (List<Object>) getGetListMethod().invoke(null,
        new String[]{objectMapper.writeValueAsString(list)});
    assertEquals("a", objs.get(0));
  }

  @Test
  public void testRrCodeRangesToDto() {
    RrCodeRanges rrCodeRanges = new RrCodeRanges();
    List list = List.of(rrCodeRanges);

    List<RRCodeRange> listRrcodeRange = EntityMapperUtils.toDto(list);
    assertEquals(1, listRrcodeRange.size());
  }

  @Test
  public void testAssignmentToDto() {
    Map<String, Object> featurePackageMap = new HashMap<>();
    featurePackageMap.put("FEATURE_PACKAGE_ID", 1);

    Assignment assignment = EntityMapperUtils.toDto(featurePackageMap);
    assertEquals(FirmAssignmentType.P, assignment.getAssignmentType());
    assertEquals(((Integer) featurePackageMap.get("FEATURE_PACKAGE_ID")).longValue(),
        assignment.getAssigneeId());
  }

  @Test
  public void testRrCodeRangeDaoToDao() {
    Map<String, Object> rrCodeRangeMap = new HashMap<>();
    rrCodeRangeMap.put("RR_CODE_RANGE_ID", 1);
    rrCodeRangeMap.put("FROM_RR_CODE", "AA00");
    rrCodeRangeMap.put("TO_RR_CODE", "AA99");
    rrCodeRangeMap.put("ACTIVE", true);
    rrCodeRangeMap.put("EFFECTIVE_DATE", new Timestamp(System.currentTimeMillis()));
    rrCodeRangeMap.put("EXPIRY_DATE", new Timestamp(System.currentTimeMillis()));

    RrCodeRangeDao rrCodeRangeDao = EntityMapperUtils.toDao(rrCodeRangeMap);
    assertEquals(((Integer) rrCodeRangeMap.get("RR_CODE_RANGE_ID")).longValue(),
        rrCodeRangeDao.getRrCodeRangeId());
    assertEquals(rrCodeRangeMap.get("FROM_RR_CODE"), rrCodeRangeDao.getFromRrCode());
    assertEquals(rrCodeRangeMap.get("TO_RR_CODE"), rrCodeRangeDao.getToRrCode());
    assertEquals(rrCodeRangeMap.get("ACTIVE"), rrCodeRangeDao.getActive());
    assertEquals(rrCodeRangeMap.get("EFFECTIVE_DATE"), rrCodeRangeDao.getEffectiveDate());
    assertEquals(rrCodeRangeMap.get("EXPIRY_DATE"), rrCodeRangeDao.getExpiryDate());
  }

  @Test
  public void testFirmToEntity() {
    Map<String, Object> firmMap = new HashMap<>();
    firmMap.put("FIRM_ENTITY_ID", 1);
    firmMap.put("FIRM_ID", "NBIN");
    firmMap.put("TYPE", FirmType.IB);
    firmMap.put("NAME", "NBIN");
    firmMap.put("ACTIVE", true);
    firmMap.put("STATE", "onboarding");
    firmMap.put("PREFERRED_LANGUAGE", PreferredLanguageType.EN);
    firmMap.put("CREATED_BY", "user");
    firmMap.put("CREATION_DATE", new Timestamp(System.currentTimeMillis()));
    firmMap.put("LAST_UPDATED_BY", "user");
    firmMap.put("LAST_UPDATE_DATE", new Timestamp(System.currentTimeMillis()));
    firmMap.put("PARENT_FIRM_ENTITY_ID", 2);
    firmMap.put("PARENT_FIRM_ID", "PARENT");
    firmMap.put("FINANCIAL_ENTITY_ID", 3);
    firmMap.put("BROKER_CODE", "123");
    firmMap.put("B_NUMBER", "123");
    firmMap.put("DEALER_CODE", "123");

    ca.bnc.wealth.common.jpa.entity.iam.Firm firm = EntityMapperUtils.toEntity(firmMap);
    assertEquals(((Integer) firmMap.get("FIRM_ENTITY_ID")).longValue(), firm.getFirmEntityId());
    assertEquals(firmMap.get("FIRM_ID"), firm.getFirmId());
    assertEquals(firmMap.get("TYPE"), firm.getFirmType());
    assertEquals(firmMap.get("NAME"), firm.getName());
    assertEquals(firmMap.get("ACTIVE"), firm.getActive());
    assertEquals(firmMap.get("STATE"), firm.getState());
    assertEquals(firmMap.get("PREFERRED_LANGUAGE"), firm.getPreferredLanguageType());
    assertEquals(firmMap.get("CREATED_BY"), firm.getCreatedBy());
    assertEquals(firmMap.get("CREATION_DATE"), firm.getCreationDate());
    assertEquals(firmMap.get("LAST_UPDATED_BY"), firm.getLastUpdatedBy());
    assertEquals(firmMap.get("LAST_UPDATE_DATE"), firm.getLastUpdateDate());
    assertEquals(((Integer) firmMap.get("PARENT_FIRM_ENTITY_ID")).longValue(),
        firm.getParentFirm().getFirmEntityId());
    assertEquals(firmMap.get("PARENT_FIRM_ID"), firm.getParentFirm().getFirmId());
    assertEquals(((Integer) firmMap.get("FINANCIAL_ENTITY_ID")).longValue(),
        firm.getFinancialEntity().getFinancialEntityId());
    assertEquals(firmMap.get("BROKER_CODE"), firm.getFinancialEntity().getBrokerCode());
    assertEquals(firmMap.get("B_NUMBER"), firm.getFinancialEntity().getBranchNumber());
    assertEquals(firmMap.get("DEALER_CODE"), firm.getFinancialEntity().getDealerCode());
  }

  private Method getGetListMethod() throws NoSuchMethodException {
    Method method = EntityMapperUtils.class.getDeclaredMethod("getList", String.class);
    method.setAccessible(true);
    return method;
  }

  private Method getConvertStateToDBMethod() throws NoSuchMethodException {
    Method method = EntityMapperUtils.class.getDeclaredMethod("convertStateToDB", String.class);
    method.setAccessible(true);
    return method;
  }
}
