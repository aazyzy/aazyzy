package ca.bnc.wealth.api.firm.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.firm.model.AssignmentType;
import ca.bnc.wealth.common.firm.model.Firm;
import ca.bnc.wealth.common.firm.model.FirmType;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class FirmConfigurationRowMapperTests {

  private FirmConfigurationRowMapper rowMapper;

  @MockitoBean
  private ResultSet resultSet;

  @Before
  public void setup() throws SQLException {
    rowMapper = new FirmConfigurationRowMapper();
    when(resultSet.getInt("parentFirmConfigurationId")).thenReturn(1);
    when(resultSet.getInt("firmConfigurationId")).thenReturn(1);
    when(resultSet.getString("firmId")).thenReturn("1");
    when(resultSet.getString("firmName")).thenReturn("firm");
    when(resultSet.getInt("financialLegalEntityId")).thenReturn(1);
    when(resultSet.getString("firmType")).thenReturn("IB");
    when(resultSet.getString("createdBy")).thenReturn("KnightCoders");
    when(resultSet.getTimestamp("creationDate")).thenReturn(
        new Timestamp(System.currentTimeMillis()));
    when(resultSet.getString("lastUpdatedBy")).thenReturn("KnightCoders");
    when(resultSet.getTimestamp("lastUpdateDate")).thenReturn(
        new Timestamp(System.currentTimeMillis()));
  }

  @Test
  public void testMapRow() throws SQLException {
    Firm result = rowMapper.mapRow(resultSet, 1);
    assertEquals("1", result.getFirmId());
    assertEquals("firm", result.getFirmName());
    assertEquals(FirmType.IB, result.getFirmType());
    assertEquals("KnightCoders", result.getCreatedBy());
  }

  @Test
  public void testMapRowWithAssignmentType() throws SQLException {
    when(resultSet.getString("assignmentType")).thenReturn("P");
    Firm result = rowMapper.mapRow(resultSet, 1);
    assertEquals("1", result.getFirmId());
    assertEquals("firm", result.getFirmName());
    assertEquals(FirmType.IB, result.getFirmType());
    assertEquals(AssignmentType.P, result.getAssignmentType());
    assertEquals("KnightCoders", result.getCreatedBy());
  }

}
