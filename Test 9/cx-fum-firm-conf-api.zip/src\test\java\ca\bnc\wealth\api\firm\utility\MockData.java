package ca.bnc.wealth.api.firm.utility;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.common.firm.model.Assignment;
import ca.bnc.wealth.common.firm.model.AssignmentType;
import ca.bnc.wealth.common.firm.model.B10RRCodeRanges;
import ca.bnc.wealth.common.firm.model.FeaturePackageAssignment;
import ca.bnc.wealth.common.firm.model.Firm;
import ca.bnc.wealth.common.firm.model.FirmAssignmentType;
import ca.bnc.wealth.common.firm.model.FirmIdHierarchy;
import ca.bnc.wealth.common.firm.model.FirmSearch;
import ca.bnc.wealth.common.firm.model.FirmType;
import ca.bnc.wealth.common.firm.model.GenericSearch;
import ca.bnc.wealth.common.firm.model.GenericSearchResponse;
import ca.bnc.wealth.common.firm.model.RRCodeRange;
import ca.bnc.wealth.common.firm.model.RRCodeRanges;
import ca.bnc.wealth.common.firm.model.SearchPayload;
import ca.bnc.wealth.common.firm.model.UpdateRRCodeRange;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentRrCodeRange;

public class MockData {

  public static String IDP_USER_SUBJECT = "idpSubject";
  public static AssignmentType ASSIGNMENT_TYPE = AssignmentType.P;

  public static List createEmptyFirmInfoList() {
    return Collections.emptyList();
  }

  public static List<Firm> createMockFirmInfoList() {
    List<Firm> firmList = new ArrayList<>();
    Firm firmInfo = new Firm();
    firmInfo.setFirmEntityId(new Long(1));
    firmInfo.setFinancialLegalEntityId(2);
    firmInfo.setFirmType(FirmType.IB);
    firmList.add(firmInfo);
    return firmList;
  }

  public static FeaturePackage createFeaturePackage() {
    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setPackageTemplate(new PackageTemplate());
    featurePackage.setFeaturePackageId(12l);
    return featurePackage;
  }

  public static Optional<ca.bnc.wealth.common.jpa.entity.iam.Firm> createMockFirm() {

    ca.bnc.wealth.common.jpa.entity.iam.Firm firmInfo = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
    firmInfo.setFirmEntityId(new Long(1));

    firmInfo.setFirmType(ca.bnc.wealth.common.jpa.entity.enums.FirmType.IB);

    return Optional.of(firmInfo);
  }

  public static List<UserAssignmentRrCodeRange> createUserAssignmentRrCodeRanges() {
    UserAssignmentRrCodeRange userAssignmentRrCodeRange = new UserAssignmentRrCodeRange();
    userAssignmentRrCodeRange.setAssignmentType(UserAssignmentType.P);
    IamRrCodeRange iamRrCodeRange = new IamRrCodeRange();
    iamRrCodeRange.setToRrCode("XF22");
    iamRrCodeRange.setFromRrCode("23EF");
    userAssignmentRrCodeRange.setIamRrCodeRange(iamRrCodeRange);
    return List.of(userAssignmentRrCodeRange);

  }

  public static List<Firm> createMockFirmInfoListWithAssignmentType() {
    List<Firm> firmList = new ArrayList<>();
    Firm firmInfo = new Firm();
    firmInfo.setFirmEntityId(new Long(1));
    firmInfo.setFinancialLegalEntityId(2);
    firmInfo.setFirmType(FirmType.IB);
    firmInfo.setAssignmentType(AssignmentType.P);
    firmList.add(firmInfo);
    return firmList;
  }

  public static List<Firm> createMockFirmInfoListWithRRCodes() {
    List<Firm> firmList = new ArrayList<>();
    List<RRCodeRange> rrCodeRanges = new ArrayList<>();
    RRCodeRange rrCodeRange = new RRCodeRange();
    rrCodeRange.setToRRCode("AZ99");
    rrCodeRange.setRrCodeRangeId(12345);
    rrCodeRange.setFromRRCode("AB10");
    rrCodeRange.setFromRRCodeB10(10000);
    rrCodeRange.setToRRCodeB10(1999);
    rrCodeRanges.add(rrCodeRange);

    Firm firmInfo = new Firm();
    firmInfo.setFirmEntityId(1L);
    firmInfo.setFirmId("NBIN");
    firmInfo.setFinancialLegalEntityId(2);
    firmInfo.setFirmType(FirmType.IB);
    firmInfo.setAssignmentType(AssignmentType.P);
    firmInfo.setRrCodeRanges(rrCodeRanges);
    firmList.add(firmInfo);
    return firmList;
  }

  public static List<Firm> createMockFirmInfoListWithoutAssignmentType() {
    List<Firm> firmList = new ArrayList<>();
    Firm firmInfo = new Firm();
    firmInfo.setFirmEntityId(new Long(1));
    firmInfo.setFinancialLegalEntityId(2);
    firmInfo.setFirmType(FirmType.IB);
    firmInfo.setAssignmentType(null);
    firmList.add(firmInfo);
    return firmList;
  }

  public static String getFirmInfoJson() {
    String firmJson = "{\n"
        + "        \"firmEntityRecordUniqueId\": 2,\n"
        + "        \"financialLegalEntityRecordUniqueId\": 2,\n"
        + "        \"firmId\": \"Siva-Test1\",\n"
        + "        \"firmName\": \"Align\",\n"
        + "        \"firmType\": \"PM\",\n"
        + "        \"creationDate\": null,\n"
        + "        \"lastUpdateDate\": null,\n"
        + "        \"createdBy\": \"Siva\",\n"
        + "        \"lastUpdatedBy\": \"Siva\"\n"
        + "    }";
    return firmJson;
  }

  public static String getFirmInfoInvalidJson() {
    String firmJson = "{\n"
        + "        \"firmEntityRecordUniqueId\": 2,\n"
        + "        \"financialLegalEntityRecordUniqueId\": 2,\n"
        + "        \"firmId\": \"Siva-Test1\",\n"
        + "        \"firmName\": \"Align\",\n"
        + "        \"firmType\": \"SS\",\n"
        + "        \"creationDate\": null,\n"
        + "        \"lastUpdateDate\": null,\n"
        + "        \"createdBy\": \"Siva\",\n"
        + "        \"lastUpdatedBy\": \"Siva\"\n"
        + "    }";
    return firmJson;
  }

  public static String getAssignedResourceJson() {
    String assignedResource = "{\"resourceGroup\": \"default\"}";
    return assignedResource;
  }

  public static SearchPayload getSearchPayload() {
    SearchPayload searchPayload = new SearchPayload();
    searchPayload.setRrCode("AABB");
    searchPayload.setRrCodeRange(createRRCodeRanges("AABB", "AACC"));
    searchPayload.setB10RrCode(43707);
    searchPayload.setB10RrCodeRange(createB10RRCodeRanges(43707, 43724));
    return searchPayload;
  }

  private static B10RRCodeRanges createB10RRCodeRanges(int from, int to) {
    B10RRCodeRanges b10RRCodeRanges = new B10RRCodeRanges();
    b10RRCodeRanges.from(from);
    b10RRCodeRanges.to(to);
    return b10RRCodeRanges;
  }

  private static RRCodeRanges createRRCodeRanges(String from, String to) {
    RRCodeRanges rrCodeRanges = new RRCodeRanges();
    rrCodeRanges.from(from);
    rrCodeRanges.to(to);
    return rrCodeRanges;
  }

  public static SearchPayload getSearchPayloadWithRrCode() {
    SearchPayload searchPayload = new SearchPayload();
    searchPayload.setRrCode("AABB");
    return searchPayload;
  }

  public static SearchPayload getSearchPayloadWithRrCodeRange() {
    SearchPayload searchPayload = new SearchPayload();
    searchPayload.setRrCodeRange(createRRCodeRanges("AABB", "AACC"));
    return searchPayload;
  }

  public static SearchPayload getSearchPayloadWithB10RrCode() {
    SearchPayload searchPayload = new SearchPayload();
    searchPayload.setB10RrCode(43707);
    return searchPayload;
  }

  public static SearchPayload getSearchPayloadWithB10RrCodeRange() {
    SearchPayload searchPayload = new SearchPayload();
    searchPayload.setB10RrCodeRange(createB10RRCodeRanges(43707, 43724));
    return searchPayload;
  }

  public static FirmIdHierarchy getFirmIdHierarchy() {
    FirmIdHierarchy firmIdHierarchy = new FirmIdHierarchy();
    firmIdHierarchy.setFirmId("firmId");
    firmIdHierarchy.hierarchyLevel("1");
    return firmIdHierarchy;
  }

  public static List<FirmIdHierarchy> getFirmIdHierarchyList() {
    return Collections.singletonList(getFirmIdHierarchy());
  }

  public static List<RRCodeRange> getRrCodeRangeListOneItem() {
    RRCodeRange rrCodeRange1 = getRRCodeRange("R0AA", "R099");

    return List.of(rrCodeRange1);
  }

  public static List<RRCodeRange> getRrCodeRangeList() {
    RRCodeRange rrCodeRange1 = getRRCodeRange("R0AA", "R099");
    RRCodeRange rrCodeRange2 = getRRCodeRange("PIAA", "PI99");
    return List.of(rrCodeRange1, rrCodeRange2);
  }

  public static UpdateRRCodeRange createUpdateRRCodeRange() {
    UpdateRRCodeRange updateRRCodeRange = new UpdateRRCodeRange();
    LocalDate date = LocalDate.of(2049, 1, 8);
    updateRRCodeRange.setEffectiveDate(date);

    updateRRCodeRange.setExpiryDate(date);
    updateRRCodeRange.setRrRanges(getRrCodeRangeList());
    return updateRRCodeRange;
  }

  public static RRCodeRange getRRCodeRange(String fromRRCode, String toRRCode) {
    RRCodeRange rrCodeRange = new RRCodeRange();
    rrCodeRange.setFromRRCode(fromRRCode);
    rrCodeRange.setToRRCode(toRRCode);
    return rrCodeRange;
  }

  public static FirmSearch createFirmSearch() {
    FirmSearch firmSearch = new FirmSearch();
    firmSearch.setFirmId("abc");
    return firmSearch;
  }

  public static GenericSearch createGenericSearch() {
    GenericSearch genericSearch = new GenericSearch();
    genericSearch.searchText("abc");
    return genericSearch;

  }

  public static GenericSearchResponse createGenericSearchResponse() {
    GenericSearchResponse genericSearchResponse = new GenericSearchResponse();
    Firm firm = new Firm();
    firm.setFirmEntityId(new Long(123));
    firm.setFirmId("abc");
    genericSearchResponse.setFirms(new ArrayList());
    genericSearchResponse.getFirms().add(firm);
    return genericSearchResponse;
  }

  public static List<IamUserConfiguration> createIamUserConfigurations() {
    IamUserConfiguration iamUserConfiguration = new IamUserConfiguration();
    iamUserConfiguration.setUserConfigurationId(123l);
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setEmail("test@nbc.ca");
    List list = List.of(iamUserConfiguration);
    return list;

  }

  public static FeaturePackageAssignment createFeaturePackageAssignment() {

    FeaturePackageAssignment featurePackageAssignment = new FeaturePackageAssignment();
    featurePackageAssignment.setFeaturePackageId(12);
    return featurePackageAssignment;
  }

  public static List<Assignment> createAssignments() {
    Assignment assignment = new Assignment();
    assignment.setAssignmentType(FirmAssignmentType.R);
    assignment.setFromRRCode("12DC");
    assignment.setToRRCode("12FD");
    return List.of(assignment);
  }

  public static User getUser() {
    User user = new User();
    user.setIdpSubject(IDP_USER_SUBJECT);
    user.setFirmId("NBIN");
    return user;
  }
}
