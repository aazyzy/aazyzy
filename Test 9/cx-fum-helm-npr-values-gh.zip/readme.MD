# Initial Setup - ArgoCD

This repository contains the templates that defines the ArgoCD applications for
APP6900.


## Deploying

### Requirements

- ArgoCD cli is installed
- User has access to `deployment-management` Vault secrets


### Authentication

To deploy the application sets you need to use the Jenkins service account
token.

At the time of writing this README.md, the usual roles do not have the
permissions to create applications sets.


```bash
# login to ArgoCD using SSO
argocd login argocd.bnc.ca --sso

# Vault path: Production
# secret/stores/5f0dfb00-0b11-422d-9ec8-bc24b9521acd/6900/production/deployment-management/d0b0ae7b-1157-4a43-9cb8-45fd5c355162

# Vault path: Non Production
# secret/stores/17df5542-6821-41b1-b28a-db3c722eed4a/6900/non_production/deployment-management/d0b0ae7b-1157-4a43-9cb8-45fd5c355162

# set the ARGOCD_AUTH_TOKEN using the Jenkins service account token from Vault
export ARGOCD_AUTH_TOKEN="<TOKEN>"
```


## References

- [ArgoCD User Guide](https://wiki.bnc.ca/pages/viewpage.action?spaceKey=SAD&title=ArgoCD+User+Guide)