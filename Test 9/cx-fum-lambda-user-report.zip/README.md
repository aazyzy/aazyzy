# cx-fum-lambda-user-report

AWS Lambda that triggers user report generation against the Compass bulk-user-uploads API. It obtains a bearer token via RSA private key authentication, then POSTs a report request with optional firm/CSV filtering parameters.

- **Runtime**: Node.js 20.x
- **Handler**: `index.handler`
- **Package**: `@nbc-gpmf/cx-fum-lambda-user-report`

## How it works

1. Reads configuration from environment variables (and optionally a Vault secret file for the RSA private key).
2. Acquires a bearer token using `SystemToken` (JWT/RSA client credentials flow).
3. Calls `POST /bulk-user-uploads/user/report` on Compass with an optional filter body.
4. Returns HTTP 200 on success, 500 on failure.

## Environment variables

| Variable | Required | Description |
|---|---|---|
| `TOKEN_URL` | Yes | OAuth token endpoint |
| `CLIENT_ID` | Yes | OAuth client ID |
| `TOKEN_SCOPE` | Yes | OAuth scope |
| `COMPASS_ROOT_URL` | Yes | Base URL for the Compass API |
| `FIRM_ID` | No | Firm ID filter for the report |
| `CSV_HEADER_MAPPING` | No | JSON string mapping CSV headers |
| `CSV_HEADER_ORDER` | No | JSON array defining CSV column order |
| `FILE_NAME_STARTS_WITH` | No | File name prefix filter |
| `ACTIVE_USERS` | No | Filter report to active users only |
| `MFT_FOLDER_INBOX` | No | MFT inbox folder path (default: `./Inbox`) |
| `LOCAL_TEMP_FOLDER` | No | Local temp directory (default: `/tmp`) |
| `PEM_BEGIN` | No | PEM header for the private key |
| `PEM_END` | No | PEM footer for the private key |
| `VAULT_SECRET_FILE` | No | Path to Vault secret JSON file; if present, `RSA_PRIVATE_KEY_NOCRYPT` is read from it |
| `CLIENT_RSA_PRIVATE_KEY_NOCRYPT` | No | RSA private key fallback when Vault file is absent |

## Deployment environments

Defined in [`lambda-config.yaml`](lambda-config.yaml):

| Environment | S3 bucket | Lambda function name |
|---|---|---|
| `dev` | `6900-npr-dev` | `tf-dev-user-report` |
| `qa` | `6900-npr-qa` | `tf-qa-user-report` |
| `stg` | `6900-npr-uat` | `tf-uat-user-report` |
| `preprod` | `6900-pp-pr` | `tf-pre-prod-user-report` |
| `prod` | `6900-prod-pr` | `lambda-user-report` |

## Local development

```bash
cd src
node -e "require('./index').handler({})"
```

## Pre-requisites

> **One-time setup:** Lambda infrastructure must be provisioned via the `devops-terraform-plans` repository before the first deployment.
