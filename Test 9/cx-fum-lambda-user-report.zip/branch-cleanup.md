# Branch Cleanup Report: lambda-user-report

Generated: 2026-06-24 11:16:34
Default Branch: develop
Total Branches: 0

---

## Summary

- Total Branches: 0
- Excluded from Deletion: 0
- Marked for Deletion: 0

---

## All Branches

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| No branches found | | | |

---

## Excluded from Deletion

Criteria: Unmerged branches with last commit less than 2 months old
Count: 0

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| No branches excluded | | | |

---

## Marked for Deletion

Criteria: All merged branches + unmerged branches with last commit older than 2 months
Count: 0

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| No branches marked for deletion | | | |
