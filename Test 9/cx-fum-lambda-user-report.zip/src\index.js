const main = require('./lib/Main.js');
const fs = require('fs');

function getEnvironmentVariables(event){
  const env = {};
  env.tokenUrl = process.env.TOKEN_URL;
  env.clientId = process.env.CLIENT_ID;
  env.scope = process.env.TOKEN_SCOPE;
  env.root = process.env.COMPASS_ROOT_URL;
  env.remoteFolderInbox = event?.MFT_FOLDER_INBOX|| process.env.MFT_FOLDER_INBOX || './Inbox';
  env.localFolder = process.env.LOCAL_TEMP_FOLDER || '/tmp';
  env.firmId = process.env.FIRM_ID;
  env.csvHeaderMapping = process.env.CSV_HEADER_MAPPING;
  env.csvHeaderOrder = process.env.CSV_HEADER_ORDER ;
  env.fileNameStartsWith = process.env.FILE_NAME_STARTS_WITH ;
  env.activeUsers = process.env.ACTIVE_USERS ;
  env.pemBegin = process.env.PEM_BEGIN;
  env.pemEnd = process.env.PEM_END;
  // TODO Enable certificate in lambda
  env.rejectUnauthorized = false;
  //process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

  // Getting values from Vault
  if(process.env.VAULT_SECRET_FILE && fs.existsSync(process.env.VAULT_SECRET_FILE)) {
    const obj = JSON.parse(fs.readFileSync(process.env.VAULT_SECRET_FILE, 'utf8'));
    const sec = obj.data.data;
    if(sec.RSA_PRIVATE_KEY_NOCRYPT) {
      env.clientSecret = sec.RSA_PRIVATE_KEY_NOCRYPT;
    } else {
      console.error("Unable to get RSA_PRIVATE_KEY_NOCRYPT");
      env.clientSecret = process.env.CLIENT_RSA_PRIVATE_KEY_NOCRYPT;
    }
  } else {
    console.warn("Vault secret file not found, using environment variables");
    env.clientSecret = process.env.CLIENT_RSA_PRIVATE_KEY_NOCRYPT;
  }

  return env;
}


exports.handler = async (event) => {
    return await main.start(getEnvironmentVariables(event));
};
