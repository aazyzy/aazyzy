# Changelog

## [3.0.1](https://github.com/NBC-GPMF/cx-fum-messaging-lib/compare/v3.0.0...v3.0.1) (2026-11-02)


### Miscellaneous Chores

* move to parent-pom-core 3.0.1, which fixes the Snyk findings of the 5.0.0 release: Tomcat 11.0.27, Jackson 3.2.4 and 2.22.4, Hibernate Validator 9.1.6.Final and java-jwt 4.6.2

## [3.0.0](https://github.com/NBC-GPMF/cx-fum-messaging-lib/compare/v2.0.32...v3.0.0) (2026-10-29)


### Miscellaneous Chores

* move the Spring Boot 4 line into develop as 3.0.0-SNAPSHOT ([#32](https://github.com/NBC-GPMF/cx-fum-messaging-lib/pull/32)) ([e0511c0](https://github.com/NBC-GPMF/cx-fum-messaging-lib/commit/e0511c04b0bff74f616b6dbd9e3bbb2fd0387521))
* skip the SonarQube analysis for now ([#33](https://github.com/NBC-GPMF/cx-fum-messaging-lib/pull/33)) ([ea569e0](https://github.com/NBC-GPMF/cx-fum-messaging-lib/commit/ea569e011b06c6ba0846c2796842c37e4e670087))
* sync 6900 dependency versions to develop SNAPSHOTs ([3f4e983](https://github.com/NBC-GPMF/cx-fum-messaging-lib/commit/3f4e98300b052902b360be13b12483817db69f8c))

## [2.0.32](https://github.com/NBC-GPMF/cx-fum-messaging-lib/compare/v2.0.31...v2.0.32) (2026-09-15)


### Bug Fixes

* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([99b7d73](https://github.com/NBC-GPMF/cx-fum-messaging-lib/commit/99b7d73ed4913eedcf15da52b1459b109a92a33f))
* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([c81bdd6](https://github.com/NBC-GPMF/cx-fum-messaging-lib/commit/c81bdd6fbfee409fe97ab46ecd1f5a3aaacacb6b))

## [2.0.31](https://github.com/NBC-GPMF/cx-fum-messaging-lib/compare/v2.0.30...v2.0.31) (2026-08-19)


### Bug Fixes

* **deps:** pin at.yawk.lz4 1.11.1 (CVE-2026-59949), align commons-lang3 3.20.0 ([#19](https://github.com/NBC-GPMF/cx-fum-messaging-lib/issues/19)) ([021e23c](https://github.com/NBC-GPMF/cx-fum-messaging-lib/commit/021e23c1a7ba365588e860f4380a568d5da07924))
* **deps:** pin at.yawk.lz4 1.11.1 (CVE-2026-59949), align commons-lang3 3.20.0 ([#20](https://github.com/NBC-GPMF/cx-fum-messaging-lib/issues/20)) ([247b550](https://github.com/NBC-GPMF/cx-fum-messaging-lib/commit/247b5501360a4f7898d8f3a02a73f00f62c161c6))
* **deps:** pin tomcat-embed 10.1.56 and logback-core 1.5.36 (Snyk HIGH) ([#15](https://github.com/NBC-GPMF/cx-fum-messaging-lib/issues/15)) ([988b145](https://github.com/NBC-GPMF/cx-fum-messaging-lib/commit/988b145a5b978398d2387b36f61afa1a744ecf92))

## [2.0.30](https://github.com/NBC-GPMF/cx-fum-messaging-lib/compare/v2.0.29...v2.0.30) (2026-06-29)


### Bug Fixes

* release 2.2.1 ([2364037](https://github.com/NBC-GPMF/cx-fum-messaging-lib/commit/2364037e18c07d42a63709d3337960f3786f3f6f))

## [2.0.29](https://github.com/NBC-GPMF/cx-fum-messaging-lib/compare/v2.0.28...v2.0.29) (2026-06-10)


### Bug Fixes

* rerunning release workflow to test ([d824d6a](https://github.com/NBC-GPMF/cx-fum-messaging-lib/commit/d824d6a41df622c6e67ef026c9107a9c4764e362))

## [2.0.28](https://github.com/NBC-GPMF/cx-fum-messaging-lib/compare/v2.0.27...v2.0.28) (2026-06-10)


### Bug Fixes

* retry  github release as earlier release failed ([dee9423](https://github.com/NBC-GPMF/cx-fum-messaging-lib/commit/dee942385046532f39bdbaaad8b984b686a04afa))

## [2.0.27](https://github.com/NBC-GPMF/cx-fum-messaging-lib/compare/v2.0.26...v2.0.27) (2026-06-10)


### Bug Fixes

* first github release ([43d7516](https://github.com/NBC-GPMF/cx-fum-messaging-lib/commit/43d751645280627d1af97bf01aa75436f9b2584f))
