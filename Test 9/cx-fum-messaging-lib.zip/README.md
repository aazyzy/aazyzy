# cx-fum-messaging-lib

A Spring Boot Kafka messaging library providing two abstraction layers for publishing and consuming Kafka events within the CX-FUM platform.

## Modules

| Module | Artifact ID | Description |
|---|---|---|
| `kafka-core` | `kafka-core` | Low-level Kafka abstractions: producers, consumers, streams, and factory beans |
| `messaging` | `messaging` | Higher-level `EventMessage` envelope and typed publisher/subscriber built on top of `kafka-core` |

---

## Maven Dependency

Add the modules you need to your `pom.xml`:

```xml
<!-- Low-level Kafka operations -->
<dependency>
    <groupId>ca.nbc.gpmf.cx-fum-messaging-lib</groupId>
    <artifactId>kafka-core</artifactId>
    <version>${messaging-lib.version}</version>
</dependency>

<!-- EventMessage envelope (includes kafka-core transitively) -->
<dependency>
    <groupId>ca.nbc.gpmf.cx-fum-messaging-lib</groupId>
    <artifactId>messaging</artifactId>
    <version>${messaging-lib.version}</version>
</dependency>
```

---

## Architecture Overview

```
messaging
  └── EventMessagePublisherFactory  (Spring @Component)
  └── EventMessagePublisher         (publishes EventMessage objects)
  └── EventMessage / EventMessageHeader / EventMessagePayload / EventMessageSource / EventMessageSignature
  └── HeaderTagRecordFilterStrategy (header-based consumer filtering)

kafka-core
  └── KafkaConfiguration            (@ConfigurationProperties prefix "kafka")
  └── KafkaCoreConfiguration        (@ConfigurationProperties prefix "kafka.core")
  └── PublisherFactory  ──► Publisher  ──► KafkaProducer
  └── SubscriberFactory ──► Subscriber ──► KafkaConsumer
```

---

## Configuration

### Core (bootstrap server, security)

Place in your application's `application.yml` (or an imported `kafka-core.yml`):

```yaml
kafka:
  core:
    bootstrap-server: ${KAFKA_BOOTSTRAP_SERVER}
    security-protocol: SASL_SSL          # use PLAINTEXT for local
    sasl-mechanism: PLAIN
    login-module: org.apache.kafka.common.security.plain.PlainLoginModule
    flag-value: required
    producer-config:
      acks: all
      idempotence: true

  sync-send-timeout: 2                   # seconds; 0 = block indefinitely
```

**Local cluster** (docker-compose):

```yaml
kafka:
  core:
    bootstrap-server: localhost:29092
    security-protocol: PLAINTEXT
```

### Environment variables

| Variable | Example (DEV) | Example (QA) |
|---|---|---|
| `KAFKA_WM_ENV` | `wm.dev` | `wm.qa` |
| `KAFKA_WM_APPID_ENV` | `wm.6588.dev` | `wm.6588.qa` |

### Producer configuration

```yaml
kafka:
  producers:
    MyEventProducer:
      key-serializer: org.apache.kafka.common.serialization.StringSerializer
      value-serializer: org.apache.kafka.common.serialization.StringSerializer
      api-key: ${KAFKA_API_KEY}
      api-secret: ${KAFKA_API_SECRET}
      topic: ${KAFKA_WM_ENV}.my-domain-events
```

### Consumer configuration

```yaml
kafka:
  consumers:
    MyEventConsumer:
      group-id: my-service-group
      topic: ${KAFKA_WM_ENV}.my-domain-events
      api-key: ${KAFKA_API_KEY}
      api-secret: ${KAFKA_API_SECRET}
      key-deserializer: org.apache.kafka.common.serialization.StringDeserializer
      value-deserializer: org.apache.kafka.common.serialization.StringDeserializer
      auto-commit: false
      interval: 1000           # ms between retry attempts
      max-attempts: 3
      max-poll-records: 10
      concurrency: 1
```

> **Topic naming conventions:** https://wiki.bnc.ca/pages/viewpage.action?spaceKey=NA&title=Naming+Conventions

---

## Usage

### Publishing with `EventMessagePublisherFactory` (recommended)

`EventMessagePublisherFactory` is a Spring `@Component`. Inject it and create a typed publisher:

```java
@Autowired
private EventMessagePublisherFactory eventMessagePublisherFactory;

// Create once (e.g. in @PostConstruct)
EventMessagePublisher publisher = eventMessagePublisherFactory.createNewEventMessagePublisher("MyEventProducer");

// Build and publish
EventMessage event = EventMessage.builder()
    .header(EventMessageHeader.builder()
        .id(UUID.randomUUID().toString())
        .action("CREATE")
        .state("PENDING")
        .version("1.0")
        .tags(Map.of("eventType", "USER_CREATED"))
        .build())
    .source(EventMessageSource.builder()
        .publisher(EventMessageSourceSystem.builder()
            .name("my-service")
            .build())
        .build())
    .payload(EventMessagePayload.builder()
        .type("USER")
        .id("user-123")
        .build())
    .build();

publisher.publishEventMessage(event);

// With explicit timeout (seconds)
publisher.publishEventMessage(event, 5L);

// To a specific partition
publisher.publishEventMessage(0, event);
```

### Publishing with low-level `PublisherFactory`

```java
@Autowired
private PublisherFactory publisherFactory;

Publisher<String, String> publisher = publisherFactory.createNewPublisher("MyEventProducer");

publisher.publish("my-key", "raw-string-value");                 // async
publisher.publishSynchronous("raw-string-value");                // sync, default timeout
publisher.publishSynchronous("raw-string-value", 5L);           // sync, 5-second timeout
```

### Consuming with `SubscriberFactory`

Auto-commit is **disabled** by default; consumers must manually acknowledge or nack.

```java
@Autowired
private SubscriberFactory subscriberFactory;

Subscriber<String, String> subscriber = subscriberFactory.createNewSubscriber(
    "MyEventConsumer",
    "my-service-group",
    (consumerRecord, ack) -> {
        try {
            processMessage(consumerRecord.value());
            if (ack != null) ack.acknowledge();
        } catch (RecoverableException e) {
            if (ack != null) ack.acknowledge();        // skip poison pill
        } catch (RuntimeException e) {
            if (ack != null) ack.nack(Duration.ZERO);  // redeliver same offset
        }
    }
);

subscriber.subscribe();    // starts the listener container
// subscriber.unsubscribe(); // stops the listener container
```

### Filtered consumption with `HeaderTagRecordFilterStrategy`

Use `HeaderTagRecordFilterStrategy` to consume only records whose Kafka headers match a given set of tags.

```java
Map<String, String> requiredTags = Map.of("eventType", "USER_CREATED");

HeaderTagRecordFilterStrategy<String, String> filterStrategy =
    new HeaderTagRecordFilterStrategy<>(requiredTags, FilterMode.MATCH_ALL);

Subscriber<String, String> subscriber = subscriberFactory.createNewFilteredSubscriber(
    "MyEventConsumer",
    "my-service-group",
    (consumerRecord, ack) -> {
        processMessage(consumerRecord.value());
        if (ack != null) ack.acknowledge();
    },
    filterStrategy
);

subscriber.subscribe();
```

`FilterMode.MATCH_ALL` — all supplied tags must match.  
`FilterMode.MATCH_ANY` — at least one tag must match.

---

## EventMessage Schema

`EventMessage` is a JSON-serializable envelope with four top-level sections:

```
EventMessage
├── header   (EventMessageHeader)
│   ├── id          UUID for this message
│   ├── refId       correlation ID across events
│   ├── action      action that triggered the event (e.g. "CREATE")
│   ├── state       lifecycle state (e.g. "PENDING")
│   ├── reason      reason / step in the process
│   ├── version     schema version
│   └── tags        Map<String,String> – used for header-based filtering
├── source   (EventMessageSource)
│   ├── origin      system where the business event originated
│   └── publisher   system that produced the Kafka message
├── payload  (EventMessagePayload)
│   ├── type        data domain type (e.g. "USER")
│   ├── id          domain entity ID used for correlation
│   └── rrCode      optional supplementary code
└── signature (EventMessageSignature)   [optional]
    └── digital signature for message authenticity verification
```

> **Security note:** The payload intentionally carries only `type` and `id`, not the full entity data. Consumers must query the source system using these fields to retrieve full data.

---

## Local Development

### Start a local Kafka cluster

```sh
cd kafka-core/src/test/resources
docker-compose -f docker-compose.yml up -d
```

Requires [Docker Desktop](https://docs.docker.com/get-docker/).

Use the following core settings to connect:

```yaml
kafka:
  core:
    bootstrap-server: localhost:29092
    security-protocol: PLAINTEXT
```

### Build

```sh
./mvnw clean install
```

### Run tests

```sh
./mvnw test
```


