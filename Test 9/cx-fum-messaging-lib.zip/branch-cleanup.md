# Branch Cleanup Report: messaging-lib

Generated: 2026-06-09 15:02:29
Default Branch: develop
Total Branches: 13

---

## Summary

- Total Branches: 13
- Excluded from Deletion: 0
- Marked for Deletion: 13

---

## All Branches

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `master` | 2021-05-10 15:36:35 -0400 | 2021-05-10 15:36:35 -0400 | MERGED |
| `release/2.0.11` | 2023-11-01 13:10:03 -0400 | 2023-11-01 13:10:03 -0400 | MERGED |
| `release/2.0.13` | 2023-12-06 16:45:30 -0500 | 2023-12-06 16:45:30 -0500 | MERGED |
| `release/1.15` | 2024-02-01 14:03:12 -0500 | 2024-02-01 14:03:12 -0500 | MERGED |
| `release/1.16` | 2024-04-17 09:24:55 -0400 | 2024-04-17 09:24:55 -0400 | MERGED |
| `release/1.17` | 2024-05-14 12:29:02 -0400 | 2024-05-14 12:29:02 -0400 | MERGED |
| `release/1.18` | 2024-06-18 13:13:38 -0400 | 2024-06-18 13:13:38 -0400 | MERGED |
| `release/1.21.1` | 2025-01-07 10:42:44 -0500 | 2025-01-07 10:42:44 -0500 | MERGED |
| `release/1.24.0` | 2025-05-13 13:58:57 -0400 | 2025-05-13 13:58:57 -0400 | MERGED |
| `release/1.28.0` | 2025-10-29 14:07:43 -0400 | 2025-10-29 14:07:43 -0400 | MERGED |
| `release/2.1.0` | 2026-01-13 17:08:08 -0500 | 2026-01-13 17:08:08 -0500 | MERGED |
| `release/2.1.1.0` | 2026-04-16 14:24:00 -0400 | 2026-04-16 14:24:00 -0400 | MERGED |
| `release/2.2.0` | 2026-04-30 12:16:46 -0400 | 2026-04-30 12:16:46 -0400 | MERGED |

---

## Excluded from Deletion

Criteria: Unmerged branches with last commit less than 2 months old
Count: 0

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| No branches excluded | | | |

---

## Marked for Deletion

Criteria: All merged branches + unmerged branches with last commit older than 2 months
Count: 13

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `master` | 2021-05-10 15:36:35 -0400 | 2021-05-10 15:36:35 -0400 | MERGED |
| `release/2.0.11` | 2023-11-01 13:10:03 -0400 | 2023-11-01 13:10:03 -0400 | MERGED |
| `release/2.0.13` | 2023-12-06 16:45:30 -0500 | 2023-12-06 16:45:30 -0500 | MERGED |
| `release/1.15` | 2024-02-01 14:03:12 -0500 | 2024-02-01 14:03:12 -0500 | MERGED |
| `release/1.16` | 2024-04-17 09:24:55 -0400 | 2024-04-17 09:24:55 -0400 | MERGED |
| `release/1.17` | 2024-05-14 12:29:02 -0400 | 2024-05-14 12:29:02 -0400 | MERGED |
| `release/1.18` | 2024-06-18 13:13:38 -0400 | 2024-06-18 13:13:38 -0400 | MERGED |
| `release/1.21.1` | 2025-01-07 10:42:44 -0500 | 2025-01-07 10:42:44 -0500 | MERGED |
| `release/1.24.0` | 2025-05-13 13:58:57 -0400 | 2025-05-13 13:58:57 -0400 | MERGED |
| `release/1.28.0` | 2025-10-29 14:07:43 -0400 | 2025-10-29 14:07:43 -0400 | MERGED |
| `release/2.1.0` | 2026-01-13 17:08:08 -0500 | 2026-01-13 17:08:08 -0500 | MERGED |
| `release/2.1.1.0` | 2026-04-16 14:24:00 -0400 | 2026-04-16 14:24:00 -0400 | MERGED |
| `release/2.2.0` | 2026-04-30 12:16:46 -0400 | 2026-04-30 12:16:46 -0400 | MERGED |

---

## Deletion Results

Total Attempted: 13
Successfully Deleted: 12
Failed: 1
Skipped (Excluded Safety Gate): 0

### Failed Deletions

| Branch Name | Error |
|-------------|-------|
| `master` | Branch 'master' could not be deleted |
