package ca.bnc.wealth.common.kafka.core.config;

import ca.bnc.wealth.common.kafka.core.publisher.ProducerProperty;
import ca.bnc.wealth.common.kafka.core.publisher.PublisherFactory;
import ca.bnc.wealth.common.kafka.core.streams.StreamsProperty;
import ca.bnc.wealth.common.kafka.core.subscriber.ConsumerProperty;
import ca.bnc.wealth.common.kafka.core.subscriber.SubscriberFactory;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import java.util.Map;

@Configuration
@ConfigurationProperties(prefix = "kafka")
@Data
public class KafkaConfiguration {
    @Autowired
    private KafkaCoreConfiguration kafkaCoreConfiguration;

    @Value("${syncSendTimeout: 2}")
    private long syncSendTimeout;

    private Map<String, ConsumerProperty> consumers;

    private Map<String, ProducerProperty> producers;

    private Map<String, StreamsProperty> streams;

    @Bean
    public SubscriberFactory subscriberFactory() {
        return new SubscriberFactory();
    }

    @Bean
    public PublisherFactory publisherFactory() {
        return new PublisherFactory();
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer properties() {
        PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
        propertySourcesPlaceholderConfigurer.setIgnoreUnresolvablePlaceholders(true);
        return propertySourcesPlaceholderConfigurer;
    }

    public String getSaslJaasString(String loginModule, String flagValue, String apiKey, String apiSecret) {
        StringBuilder sb = new StringBuilder(500);
        sb.append(loginModule).append("   ").append(flagValue).append(" ");
        sb.append("username=").append("'").append(apiKey).append("'   ");
        sb.append("password=").append("'").append(apiSecret).append("'");
        sb.append(";");
        return sb.toString();
    }
}
