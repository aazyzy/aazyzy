package ca.bnc.wealth.common.kafka.core.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "kafka.core")
@Data
public class KafkaCoreConfiguration {

    @Value("${sasl-mechanism:PLAIN}")
    private String saslMechanism;

    @Value("${security-protocol:SASL_SSL}")
    private String securityProtocol;

    @Value("${loginModule:org.apache.kafka.common.security.plain.PlainLoginModule}")
    private String loginModule;

    @Value("${flagValue:required}")
    private String flagValue;

    @Value("${producerConfig.acks:all}")
    private String acks;

    @Value("${producerConfig.idempotence:true}")
    private Boolean idempotence;

    private String bootstrapServer;


}
