package ca.bnc.wealth.common.kafka.core.config;

import ca.bnc.wealth.common.kafka.core.streams.StreamsProperty;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.streams.StreamsConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.support.MimeTypeJacksonModule;
import org.springframework.kafka.support.serializer.JacksonJsonDeserializer;
import org.springframework.kafka.support.serializer.JacksonJsonSerializer;
import tools.jackson.databind.DeserializationFeature;
import tools.jackson.databind.MapperFeature;
import tools.jackson.databind.json.JsonMapper;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class KafkaStreamsConfig {

    // Jackson 2 defaults plus what spring-kafka's Jackson 2 JsonSerializer added, so the bytes match the Spring Boot 3 line
    private static final JsonMapper MESSAGE_MAPPER = JsonMapper.builderWithJackson2Defaults()
            .disable(MapperFeature.DEFAULT_VIEW_INCLUSION)
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
            .addModule(new MimeTypeJacksonModule())
            .build();

    @Autowired
    private KafkaCoreConfiguration kafkaCoreConfiguration;

    @Autowired
    protected KafkaConfiguration kafkaConfiguration;

    public<T> Serde<T> messageValueSerde(Class<T> messageClass) {
        return Serdes.serdeFrom(new JacksonJsonSerializer<>(MESSAGE_MAPPER),
                new JacksonJsonDeserializer<>(messageClass, MESSAGE_MAPPER));
    }

    public Map<String,Object> getKafkaStreamsProperties(String streamName) {

        StreamsProperty streamsProperty = kafkaConfiguration.getStreams().get(streamName);

        Map<String,Object> kafkaProperties = new HashMap<>();
        kafkaProperties.put(StreamsConfig.APPLICATION_ID_CONFIG,streamsProperty.getGroupId());
        kafkaProperties.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG,kafkaCoreConfiguration.getBootstrapServer());
        kafkaProperties.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, streamsProperty.getKeySerde());
        kafkaProperties.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG,streamsProperty.getValueSerde());
        kafkaProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        kafkaProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JacksonJsonSerializer.class.getName());
        kafkaProperties.put(SaslConfigs.SASL_MECHANISM, kafkaCoreConfiguration.getSaslMechanism());
        kafkaProperties.put(SaslConfigs.SASL_JAAS_CONFIG, kafkaConfiguration.getSaslJaasString(
                kafkaCoreConfiguration.getLoginModule(), kafkaCoreConfiguration.getFlagValue(),
                streamsProperty.getApiKey(), streamsProperty.getApiSecret()));
        kafkaProperties.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, kafkaCoreConfiguration.getSecurityProtocol());

        return kafkaProperties;

    }
}
