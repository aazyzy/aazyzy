package ca.bnc.wealth.common.kafka.core.config.util;

import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.support.DefaultPropertySourceFactory;
import org.springframework.core.io.support.EncodedResource;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * Custom PropertySourceFactory that can be passed to @PropertySource to load a YAML file
 * <p>
 * Usage:
 * Create a configuration class with @Configuration (and @ConfigurationProperties)
 * Add the @PropertySource annotation to your configuration class:
 * <code><b>@PropertySource(value = "classpath:<yml_file_name>.yml", factory = YamlPropertySourceFactory.class)</b></code>
 */
public class YamlPropertySourceFactory extends DefaultPropertySourceFactory {
    @Override
    public PropertySource<?> createPropertySource(String name, EncodedResource resource) throws IOException {
        Properties yamlProperties = loadYaml(resource);
        String sourceName = name != null ? name : resource.getResource().getFilename();
        return new PropertiesPropertySource(sourceName, yamlProperties);
    }

    private Properties loadYaml(EncodedResource resource) throws FileNotFoundException {
        try {
            YamlPropertiesFactoryBean factory = new YamlPropertiesFactoryBean();
            factory.setResources(resource.getResource());
            factory.afterPropertiesSet();
            return factory.getObject();
        } catch (IllegalStateException e) {
            Throwable cause = e.getCause();
            if (cause instanceof FileNotFoundException)
                throw (FileNotFoundException) e.getCause();
            throw e;
        }
    }
}