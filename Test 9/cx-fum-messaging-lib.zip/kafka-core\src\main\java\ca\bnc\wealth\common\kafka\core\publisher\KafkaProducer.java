package ca.bnc.wealth.common.kafka.core.publisher;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.CollectionUtils;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Slf4j
public class KafkaProducer<K, V> {

    private final long kafkaSyncSendTimeout;

    private final KafkaTemplate<K, V> kafkaTemplate;

    public KafkaProducer(KafkaTemplate<K, V> kafkaTemplate, long kafkaSyncSendTimeout) {
        this.kafkaSyncSendTimeout = kafkaSyncSendTimeout;
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendMessageAsync(String topic, V message) {
        CompletableFuture<SendResult<K, V>> listenableFuture = this.kafkaTemplate.send(topic, message);
        handleCallback(message, listenableFuture);
    }

    public void sendMessageAsync(String topic, K key, V message) {
        CompletableFuture<SendResult<K, V>> listenableFuture = this.kafkaTemplate.send(topic, key, message);
        handleCallback(message, listenableFuture);
    }

    private void handleCallback(V message, CompletableFuture<SendResult<K, V>> completableFuture) {
        completableFuture.whenComplete((result, throwable) -> {
            if (throwable != null) {
                handleFailure(throwable);
            }
            if (throwable == null && result != null) {
                handleSuccess(message, result);
            }
        });
    }

    public Optional<SendResult<K, V>> sendMessageSync(String topic, V message) throws ExecutionException, TimeoutException {
        return sendMessageSync(topic, message, kafkaSyncSendTimeout);
    }

    public Optional<SendResult<K, V>> sendMessageSync(String topic, K key, V message) throws ExecutionException, TimeoutException {
        return sendMessageSync(topic, key, message, kafkaSyncSendTimeout);
    }

    public Optional<SendResult<K, V>> sendMessageSync(String topic, int partitionId, K key, V message) throws ExecutionException, TimeoutException {
        return sendMessageSync(topic, partitionId, key, message, kafkaSyncSendTimeout);
    }


    /**
     * Publishes the given message to the given topic synchronously
     * If timeout is null or 0, there won't be any timeout for the operation and the operation will be blocking indefinitely
     *
     * @param topic - topic name
     * @param message - message to be published
     * @param timeout - timeout for the operation
     * @return result of the operation {@link Optional<SendResult<K, V>>}
     */
    public Optional<SendResult<K, V>> sendMessageSync(String topic, V message, Long timeout) throws ExecutionException, TimeoutException {
        ProducerRecord<K, V> producerRecord = new ProducerRecord<>(topic, message);
        if(timeout == null || timeout <= 0)
            return sendMessageGetSendResult(producerRecord);
        return sendMessageGetSendResult(producerRecord, timeout);
    }

    /**
     * Publishes the given key, and message to the given topic synchronously
     * If timeout is null or 0, there won't be any timeout for the operation and the operation will be blocking indefinitely
     *
     * @param topic - topic name
     * @param key - Kafka message key
     * @param message - message to be published
     * @param timeout - timeout for the operation
     * @return result of the operation {@link Optional<SendResult<K, V>>}
     */
    public Optional<SendResult<K, V>> sendMessageSync(String topic, K key, V message, Long timeout) throws ExecutionException, TimeoutException {
        ProducerRecord<K, V> producerRecord = new ProducerRecord<>(topic, key, message);
        if(timeout == null || timeout <= 0)
            return sendMessageGetSendResult(producerRecord);
        return sendMessageGetSendResult(producerRecord, timeout);
    }

    /**
     * Publishes the given key, and message to the given topic partition synchronously
     * If timeout is null or 0, there won't be any timeout for the operation and the operation will be blocking indefinitely
     *
     * @param topic - topic name
     * @param partitionId - partition number
     * @param key - Kafka message key
     * @param message - message to be published
     * @param timeout - timeout for the operation
     * @return result of the operation {@link Optional<SendResult<K, V>>}
     */
    public Optional<SendResult<K, V>> sendMessageSync(String topic, int partitionId, K key, V message, Long timeout) throws ExecutionException, TimeoutException {
        ProducerRecord<K, V> producerRecord = new ProducerRecord<>(topic, partitionId, key, message);
        if(timeout == null || timeout <= 0)
            return sendMessageGetSendResult(producerRecord);
        return sendMessageGetSendResult(producerRecord, timeout);
    }

    public Optional<SendResult<K, V>> sendMessageSync(String topic, V message, Map<String, String> headerTags) throws ExecutionException, TimeoutException {
        return sendMessageSync(topic, message, headerTags, kafkaSyncSendTimeout);
    }

    public Optional<SendResult<K, V>> sendMessageSync(String topic,K key, V message, Map<String, String> headerTags) throws ExecutionException, TimeoutException {
        return sendMessageSync(topic,key, message, headerTags, kafkaSyncSendTimeout);
    }

    public Optional<SendResult<K, V>> sendMessageSync(String topic, int partitionId, K key, V message, Map<String, String> headerTags) throws ExecutionException, TimeoutException {
        return sendMessageSync(topic, partitionId, key, message, headerTags, kafkaSyncSendTimeout);
    }


    /**
     * Adds the header tags to the producer record and then publishes the given message to the given topic synchronously
     * If timeout is null or 0, there won't be any timeout for the operation and the operation will be blocking indefinitely
     *
     * @param topic - topic name
     * @param message - message to be published
     * @param headerTags - Kafka message header tags
     * @param timeout - timeout for the operation
     * @return result of the operation {@link Optional<SendResult<K, V>>}
     */
    public Optional<SendResult<K, V>> sendMessageSync(String topic, V message, Map<String, String> headerTags, Long timeout) throws ExecutionException, TimeoutException {
      ProducerRecord<K, V> producerRecord = new ProducerRecord<>(topic, message);
      addHeader(producerRecord, headerTags);
        if(timeout == null || timeout <= 0)
            return sendMessageGetSendResult(producerRecord);
        return sendMessageGetSendResult(producerRecord, timeout);
    }

    /**
     * Adds the header tags to the producer record and then publishes the given key and message to the given topic synchronously
     * If timeout is null or 0, there won't be any timeout for the operation and the operation will be blocking indefinitely
     *
     * @param topic - topic name
     * @param key - Kafka message key
     * @param message - message to be published
     * @param headerTags - Kafka message header tags
     * @param timeout - timeout for the operation
     * @return result of the operation {@link Optional<SendResult<K, V>>}
     */
    public Optional<SendResult<K, V>> sendMessageSync(String topic,K key, V message, Map<String, String> headerTags, Long timeout) throws ExecutionException, TimeoutException {
        ProducerRecord<K, V> producerRecord = new ProducerRecord<>(topic, key, message);
        addHeader(producerRecord, headerTags);
        if(timeout == null || timeout <= 0)
            return sendMessageGetSendResult(producerRecord);
        return sendMessageGetSendResult(producerRecord, timeout);
    }

    /**
     * Adds the header tags to the producer records and then publishes the given key and message to the given topic partition synchronously
     * If timeout is null or 0, there won't be any timeout for the operation and the operation will be blocking indefinitely
     *
     * @param topic - topic name
     * @param partitionId - partition number
     * @param key - Kafka message key
     * @param message - message to be published
     * @param headerTags - Kafka message header tags
     * @param timeout - timeout for the operation
     * @return result of the operation {@link Optional<SendResult<K, V>>}
     */
    public Optional<SendResult<K, V>> sendMessageSync(String topic, int partitionId, K key, V message, Map<String, String> headerTags, Long timeout) throws ExecutionException, TimeoutException {
        ProducerRecord<K, V> producerRecord = new ProducerRecord<>(topic, partitionId, key, message);
        addHeader(producerRecord, headerTags);
        if(timeout == null || timeout <= 0)
            return sendMessageGetSendResult(producerRecord);
        return sendMessageGetSendResult(producerRecord, timeout);
    }

    private Optional<SendResult<K, V>> sendMessageGetSendResult(ProducerRecord<K, V> producerRecord, Long kafkaSyncSendTimeout) throws ExecutionException, TimeoutException {
        Optional<SendResult<K,V>>  sendResult;
        try {
            sendResult = Optional.ofNullable(kafkaTemplate.send(producerRecord).get(kafkaSyncSendTimeout, TimeUnit.SECONDS));
        }  catch (InterruptedException ex){
            Thread.currentThread().interrupt();
            log.error("Problem publishing message: ", ex);
            return Optional.empty();
        }
        return sendResult;
    }

    private Optional<SendResult<K, V>> sendMessageGetSendResult(ProducerRecord<K, V> producerRecord) throws ExecutionException {
        Optional<SendResult<K,V>>  sendResult;
        try {
            sendResult = Optional.ofNullable(kafkaTemplate.send(producerRecord).get());
        }  catch (InterruptedException ex){
            Thread.currentThread().interrupt();
            log.error("Problem publishing message: ", ex);
            return Optional.empty();
        }
        return sendResult;
    }
    
    private void addHeader(ProducerRecord<K, V> producerRecord, Map<String, String> headerTags) {
      if(!CollectionUtils.isEmpty(headerTags)) {
        headerTags.forEach((key, value) -> producerRecord.headers().add(key, value.getBytes(StandardCharsets.UTF_8)));
      }
    }
    private void handleFailure(Throwable throwable) {
        log.error("Problem publishing message: ", throwable);
    }

    private void handleSuccess(V message, SendResult<K, V> result) {
        log.info("Record: {} , published successfully", result.getProducerRecord());
    }

}
