package ca.bnc.wealth.common.kafka.core.publisher;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProducerProperty {
    private String keySerializer;
    private String valueSerializer;
    private String apiKey;
    private String apiSecret;
    private String topic;
}
