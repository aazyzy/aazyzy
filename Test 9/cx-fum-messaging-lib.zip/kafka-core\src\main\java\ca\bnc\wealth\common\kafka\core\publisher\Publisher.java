package ca.bnc.wealth.common.kafka.core.publisher;

import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.support.SendResult;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;


@Slf4j
public class Publisher<K, V> {

    private String topic;
    private KafkaProducer<K, V> kafkaProducer;

    public Publisher(String topic, KafkaProducer<K, V> kafkaProducer) {
        this.topic = topic;
        this.kafkaProducer = kafkaProducer;
    }

    public void publish(V message) {
        kafkaProducer.sendMessageAsync(topic, message);
    }

    public void publish(K key, V message) {
        kafkaProducer.sendMessageAsync(topic, key, message);
    }

    public Optional<SendResult<K, V>> publishSynchronous(V message) throws ExecutionException, TimeoutException {
        long startTime = System.nanoTime();
        try {
            return kafkaProducer.sendMessageSync(topic, message);
        } finally {
            log.debug("Time inside publishSynchronous(V message) method in nano seconds - " + (System.nanoTime() - startTime));
        }
    }

    /**
     * Publish message synchronously with timeout
     * If timout is null or <= 0, there won't be any timeout for the operation
     *
     * @param message
     * @param timeout
     * @return
     * @throws ExecutionException
     * @throws TimeoutException
     */
    public Optional<SendResult<K, V>> publishSynchronous(V message, Long timeout) throws ExecutionException, TimeoutException {
        long startTime = System.nanoTime();
        try {
            return kafkaProducer.sendMessageSync(topic, message, timeout);
        } finally {
            log.debug("Time inside publishSynchronous(V message) method in nano seconds - " + (System.nanoTime() - startTime));
        }
    }

    public Optional<SendResult<K, V>> publishSynchronous(V message, Map<String, String> headerTags) throws ExecutionException, TimeoutException {
        long startTime = System.nanoTime();
        try {
            return kafkaProducer.sendMessageSync(topic, message, headerTags);
        } finally {
            log.debug("Time inside publishSynchronous(V message, Map<String, String> headerTags) method in nano seconds - " + (System.nanoTime() - startTime));
        }
    }

    public Optional<SendResult<K, V>> publishSynchronous(K key, V message, Map<String, String> headerTags) throws ExecutionException, TimeoutException {
        long startTime = System.nanoTime();
        try {
            return kafkaProducer.sendMessageSync(topic, key, message, headerTags);
        } finally {
            log.debug("Time inside publishSynchronous(K key,V message, Map<String, String> headerTags) method in nano seconds - " + (System.nanoTime() - startTime));
        }
    }

    /**
     * Publish Given Key, message synchronously with timeout
     * If timout is null or <= 0, there won't be any timeout for the operation
     *
     * @param key
     * @param message
     * @param headerTags
     * @param timeout
     * @return
     * @throws ExecutionException
     * @throws TimeoutException
     */
    public Optional<SendResult<K, V>> publishSynchronous(K key, V message, Map<String, String> headerTags, Long timeout) throws ExecutionException, TimeoutException {
        long startTime = System.nanoTime();
        try {
            return kafkaProducer.sendMessageSync(topic, key, message, headerTags, timeout);
        } finally {
            log.debug("Time inside publishSynchronous(K key,V message, Map<String, String> headerTags) method in nano seconds - " + (System.nanoTime() - startTime));
        }
    }

    public Optional<SendResult<K, V>> publishSynchronous(K key, V message) throws ExecutionException, TimeoutException {
        long startTime = System.nanoTime();
        try {
            return kafkaProducer.sendMessageSync(topic, key, message);
        } finally {
            log.debug("Time inside publishSynchronous(K key, V message) method in nano seconds - " + (System.nanoTime() - startTime));
        }
    }

    public Optional<SendResult<K, V>> publishSynchronous(K key, V message, Long timeout) throws ExecutionException, TimeoutException {
        return kafkaProducer.sendMessageSync(topic, key, message, timeout);
    }

    /**
     * Publishes the given key, message and headerTags to the specified partition
     *
     * @param partition - partition number
     * @param key - Kafka message key
     * @param message - message to be published
     * @param headerTags - Kafka message header tags
     * @return result of the operation {@link Optional<SendResult<K, V>>}
     */
    public Optional<SendResult<K, V>> publishSynchronous(int partition, K key, V message, Map<String, String> headerTags) throws ExecutionException, TimeoutException {
        long startTime = System.nanoTime();
        try {
            return kafkaProducer.sendMessageSync(topic, partition, key, message, headerTags);
        } finally {
            log.debug("Time taken for publishing message in milliseconds - "
                    + TimeUnit.MILLISECONDS.convert(System.nanoTime() - startTime, TimeUnit.NANOSECONDS));
        }
    }

    /**
     * Publishes the given key, message and headerTags to the specified partition
     * If timout is null or <= 0, there won't be any timeout for the operation
     *
     * @param partition - partition number
     * @param key - Kafka message key
     * @param message - message to be published
     * @param headerTags - Kafka message header tags
     * @param timeout - timeout in seconds
     * @return result of the operation {@link Optional<SendResult<K, V>>}
     */
    public Optional<SendResult<K, V>> publishSynchronous(int partition, K key, V message, Map<String, String> headerTags, Long timeout) throws ExecutionException, TimeoutException {
        long startTime = System.nanoTime();
        try {
            return kafkaProducer.sendMessageSync(topic, partition, key, message, headerTags, timeout);
        } finally {
            log.debug("Time taken for publishing message in milliseconds - "
                    + TimeUnit.MILLISECONDS.convert(System.nanoTime() - startTime, TimeUnit.NANOSECONDS));
        }
    }

    /**
     * Publishes the given key and message to the specified partition
     *
     * @param partition - partition number
     * @param key - Kafka message key
     * @param message - message to be published
     * @return result of the operation {@link Optional<SendResult<K, V>>}
     */
    public Optional<SendResult<K, V>> publishSynchronous(int partition, K key, V message) throws ExecutionException, TimeoutException {
        long startTime = System.nanoTime();
        try {
            return kafkaProducer.sendMessageSync(topic, partition, key, message);
        } finally {
            log.debug("Time taken for publishing message in milliseconds - "
                    + TimeUnit.MILLISECONDS.convert(System.nanoTime() - startTime, TimeUnit.NANOSECONDS));
        }
    }

    /**
     * Publishes the given key and message to the specified partition
     * If timout is null or <= 0, there won't be any timeout for the operation
     *
     * @param partition - partition number
     * @param key - Kafka message key
     * @param message - message to be published
     * @param timeout - timeout in seconds
     * @return result of the operation {@link Optional<SendResult<K, V>>}
     */
    public Optional<SendResult<K, V>> publishSynchronous(int partition, K key, V message, Long timeout) throws ExecutionException, TimeoutException {
        long startTime = System.nanoTime();
        try {
            return kafkaProducer.sendMessageSync(topic, partition, key, message, timeout);
        } finally {
            log.debug("Time taken for publishing message in milliseconds - "
                    + TimeUnit.MILLISECONDS.convert(System.nanoTime() - startTime, TimeUnit.NANOSECONDS));
        }
    }

}
