package ca.bnc.wealth.common.kafka.core.publisher;

import ca.bnc.wealth.common.kafka.core.config.KafkaConfiguration;
import ca.bnc.wealth.common.kafka.core.config.KafkaCoreConfiguration;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import java.util.HashMap;
import java.util.Map;

public class PublisherFactory {

    @Autowired
    private KafkaCoreConfiguration kafkaCoreConfiguration;

    @Autowired
    protected KafkaConfiguration kafkaConfiguration;

    public <K, V> Publisher<K, V> createNewPublisher(String publisherName) {
        ProducerProperty producerProperty = kafkaConfiguration.getProducers().get(publisherName);
        return new Publisher<>(producerProperty.getTopic(), createNewKafkaProducer(producerProperty));
    }

    protected  <K, V> KafkaProducer<K, V> createNewKafkaProducer(ProducerProperty producerProperty) {
        KafkaTemplate<K, V> kafkaTemplate = new KafkaTemplate<>(producerFactory(producerProperty));
        return new KafkaProducer<>(kafkaTemplate, kafkaConfiguration.getSyncSendTimeout());
    }

    private <K, V> ProducerFactory<K, V> producerFactory(ProducerProperty producerProperty) {
        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaCoreConfiguration.getBootstrapServer());
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, producerProperty.getKeySerializer());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, producerProperty.getValueSerializer());
        props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, kafkaCoreConfiguration.getIdempotence());
        props.put(ProducerConfig.ACKS_CONFIG, kafkaCoreConfiguration.getAcks());
        props.put(SaslConfigs.SASL_JAAS_CONFIG, kafkaConfiguration.getSaslJaasString(kafkaCoreConfiguration.getLoginModule(), kafkaCoreConfiguration.getFlagValue(), producerProperty.getApiKey(), producerProperty.getApiSecret()));
        props.put(SaslConfigs.SASL_MECHANISM, kafkaCoreConfiguration.getSaslMechanism());
        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, kafkaCoreConfiguration.getSecurityProtocol());
        return new DefaultKafkaProducerFactory<>(props);
    }
}
