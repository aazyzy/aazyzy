package ca.bnc.wealth.common.kafka.core.streams;
import lombok.Data;

@Data
public class StreamsProperty {
    private String keySerde;
    private String valueSerde;
    private String apiKey;
    private String apiSecret;
    private String inputTopic;
    private String outputTopic;
    private String groupId;
}
