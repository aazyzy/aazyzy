package ca.bnc.wealth.common.kafka.core.subscriber;

import lombok.Data;
import org.springframework.kafka.listener.BatchAcknowledgingMessageListener;
import org.springframework.kafka.listener.BatchMessageListener;

@Data
public class BatchSubscriber<K,V> {
    private KafkaConsumer<K,V> kafkaConsumer;
    private BatchMessageListener<K,V> messageListener;

    public BatchSubscriber(KafkaConsumer<K,V> kafkaConsumer, BatchAcknowledgingMessageListener<K,V> messageListener){
        this.kafkaConsumer=kafkaConsumer;
        this.messageListener=messageListener;
        kafkaConsumer.addListener(messageListener);
    }

    public void subscribe(){
        kafkaConsumer.start();
    }
    
    public void unsubscribe(){
      kafkaConsumer.stop();
    }
}
