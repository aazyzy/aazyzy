package ca.bnc.wealth.common.kafka.core.subscriber;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConsumerProperty {
    private String groupId;
    private String topic;
    private String apiKey;
    private String apiSecret;
    private String keyDeserializer;
    private String valueDeserializer;
    private boolean autoCommit;
    private long interval;
    private long maxAttempts;
    private int maxPollRecords;
    private int concurrency;
}

