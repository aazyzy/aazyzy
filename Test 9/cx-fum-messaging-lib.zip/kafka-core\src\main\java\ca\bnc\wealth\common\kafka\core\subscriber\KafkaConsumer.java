package ca.bnc.wealth.common.kafka.core.subscriber;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.listener.BatchMessageListener;
import org.springframework.kafka.listener.CommonErrorHandler;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.MessageListener;

import java.util.Arrays;

@Data
@Slf4j
public class KafkaConsumer<K, V> {
    private ConcurrentMessageListenerContainer<K, V> concurrentMessageListenerContainer;
    private MessageListener<String, String> messageListener;

    public KafkaConsumer(ConcurrentMessageListenerContainer<K, V> concurrentMessageListenerContainer) {
        this.concurrentMessageListenerContainer = concurrentMessageListenerContainer;
        concurrentMessageListenerContainer.setAutoStartup(false);
        log.debug("Consumer created with topic: {}", Arrays.toString(concurrentMessageListenerContainer.getContainerProperties().getTopics()));
    }

    public void addListener(MessageListener<K, V> messageListener) {
        concurrentMessageListenerContainer.setupMessageListener(messageListener);
    }
    public void addListener(BatchMessageListener<K, V> messageListener) {
        concurrentMessageListenerContainer.setupMessageListener(messageListener);
    }
    public void addErrorHandler(CommonErrorHandler commonErrorHandler) {
        concurrentMessageListenerContainer.setCommonErrorHandler(commonErrorHandler);
    }

    public void start() {
        concurrentMessageListenerContainer.start();
    }
    
    public void stop() {
        concurrentMessageListenerContainer.stop();
  }
}
