package ca.bnc.wealth.common.kafka.core.subscriber;

import lombok.Data;
import org.springframework.kafka.listener.MessageListener;

@Data
public class Subscriber<K,V> {
    private KafkaConsumer<K,V> kafkaConsumer;
    private MessageListener<K,V> messageListener;

    public Subscriber(KafkaConsumer<K,V> kafkaConsumer, MessageListener<K,V>  messageListener){
        this.kafkaConsumer=kafkaConsumer;
        this.messageListener=messageListener;
        kafkaConsumer.addListener(messageListener);
    }

    public void subscribe(){
        kafkaConsumer.start();
    }
    
    public void unsubscribe(){
      kafkaConsumer.stop();
    }
}
