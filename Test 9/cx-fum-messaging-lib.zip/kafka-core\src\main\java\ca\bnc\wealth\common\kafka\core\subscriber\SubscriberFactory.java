package ca.bnc.wealth.common.kafka.core.subscriber;

import ca.bnc.wealth.common.kafka.core.config.KafkaConfiguration;
import ca.bnc.wealth.common.kafka.core.config.KafkaCoreConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.header.Header;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.*;
import org.springframework.kafka.listener.adapter.FilteringMessageListenerAdapter;
import org.springframework.kafka.listener.adapter.RecordFilterStrategy;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.util.backoff.FixedBackOff;

import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;

@Slf4j
public class SubscriberFactory {

    @Autowired
    private KafkaCoreConfiguration kafkaCoreConfiguration;

    @Autowired
    protected KafkaConfiguration kafkaConfiguration;

    /**
     * @deprecated Kafka auto commit is disabled by default thus requires consumer commit manual acknowledgement.
     * It can be achieved using method createNewSubscriber(String consumerName, String groupId, BiConsumer<V, Integer> messageListener,
     *                                                        ConsumerRecordRecoverer recordRecoverer)
     * If auto commit is not enabled, same message will be redelivered when kafka rebalanced or consumer restarts
     */
    @Deprecated
    protected <K, V> Subscriber<K, V> createNewFilteredSubscriber(String consumerName, String groupId, MessageListener<K, V> messageListener,
        RecordFilterStrategy<K, V> recordFilterStrategy) {
      return new Subscriber<>(createNewKafkaConsumer(consumerName, groupId), 
          new FilteringMessageListenerAdapter<>(messageListener, recordFilterStrategy, true));
    }

    protected <K, V> Subscriber<K, V> createNewFilteredSubscriber(String consumerName, String groupId, BiConsumer<V, Integer> messageListener,
                                                                  RecordFilterStrategy<K, V> recordFilterStrategy) {
        return new Subscriber<>(createNewKafkaConsumer(consumerName, groupId),
                new FilteringMessageListenerAdapter<>(messageHandler(messageListener), recordFilterStrategy, true));
    }

    protected <K, V> Subscriber<K, V> createNewFilteredSubscriber(String consumerName, String groupId, BiConsumer<V, Integer> messageListener,
                                                                  RecordFilterStrategy<K, V> recordFilterStrategy, ConsumerRecordRecoverer recordRecoverer) {
        KafkaConsumer<K,V> kafkaConsumer = createNewKafkaConsumer(consumerName, groupId);
        ConsumerProperty consumerProperty = kafkaConfiguration.getConsumers().get(consumerName);
        if(recordRecoverer != null) {
            kafkaConsumer.addErrorHandler(new DefaultErrorHandler(recordRecoverer, new FixedBackOff(consumerProperty.getInterval(), consumerProperty.getMaxAttempts())));
        }
        return new Subscriber<>(kafkaConsumer,
                new FilteringMessageListenerAdapter<>(messageHandler(messageListener), recordFilterStrategy, true));
    }

    /**
     * Creates new subscriber for the given consumerProperty, group id and adds RecordFilterStrategy.
     *
     * @param consumerProperty - consumer details {@link ConsumerProperty}
     * @param groupId - consumer group id.
     * @param messageListener - BiConsumer implementation with consumerRecord value and deliveryAttempt
     * @param recordFilterStrategy - Add filtering strategy for the subscriber. Records will be filtered based kafka record headers
     * @return Subscriber to start the consumer
     */
    protected <K, V> Subscriber<K, V> createNewFilteredSubscriber(ConsumerProperty consumerProperty, String groupId, BiConsumer<V, Integer> messageListener,
                                                                  RecordFilterStrategy<K, V> recordFilterStrategy) {
        return new Subscriber<>(createNewKafkaConsumer(consumerProperty, groupId),
                new FilteringMessageListenerAdapter<>(messageHandler(messageListener), recordFilterStrategy, true));
    }

    /**
     * @deprecated Kafka auto commit is disabled by default thus requires consumer commit manual acknowledgement.
     * It can be achieved using method createNewSubscriber(String consumerName, String groupId, BiConsumer<V, Integer> messageListener,
     *                                                        ConsumerRecordRecoverer recordRecoverer)
     * If auto commit is not enabled, same message will be redelivered when kafka rebalanced or consumer restarts
     */
    @Deprecated
    public <K, V> Subscriber<K, V> createNewSubscriber(String consumerName, String groupId, MessageListener<K, V> messageListener) {
        return new Subscriber<>(createNewKafkaConsumer(consumerName, groupId), messageListener);
    }

    public <K, V> BatchSubscriber<K, V> createNewSubscriber(String consumerName, String groupId, BatchAcknowledgingMessageListener<K, V> messageListener) {
        return new BatchSubscriber<>(createNewKafkaConsumer(consumerName, groupId), messageListener);
    }

    /**
     * Creates new subscriber for the given consumer name and group id and registers error handler
     *
     * @param consumerName - consumer name
     * @param groupId - consumer group id.
     * @param messageListener - BiConsumer implementation with consumerRecord value and deliveryAttempt
     * @param recordRecoverer - Implementation of {@link ConsumerRecordRecoverer} which will be invoked when all retry exhausted.
     *                        null if no recovery process required
     * @return Subscriber to start the consumer
     */
    public <K, V> Subscriber<K, V> createNewSubscriber(String consumerName, String groupId, BiConsumer<V, Integer> messageListener,
                                                       ConsumerRecordRecoverer recordRecoverer) {
        KafkaConsumer<K,V> kafkaConsumer = createNewKafkaConsumer(consumerName, groupId);
        ConsumerProperty consumerProperty = kafkaConfiguration.getConsumers().get(consumerName);
        if(recordRecoverer != null) {
            kafkaConsumer.addErrorHandler(new DefaultErrorHandler(recordRecoverer, new FixedBackOff(consumerProperty.getInterval(), consumerProperty.getMaxAttempts())));
        }
        return new Subscriber<>(kafkaConsumer, messageHandler(messageListener));
    }

    /**
     * Creates new subscriber for the given consumerProperty and group id and registers error handler
     *
     * @param consumerProperty - consumer details {@link ConsumerProperty}
     * @param groupId - consumer group id.
     * @param messageListener - BiConsumer implementation with consumerRecord value and deliveryAttempt
     * @param recordRecoverer - Implementation of {@link ConsumerRecordRecoverer} which will be invoked when all retry exhausted.
     *                        null if no recovery process required
     * @return Subscriber to start the consumer
     */
    public <K, V> Subscriber<K, V> createNewSubscriber(ConsumerProperty consumerProperty, String groupId, BiConsumer<V, Integer> messageListener,
                                                       ConsumerRecordRecoverer recordRecoverer) {
        KafkaConsumer<K,V> kafkaConsumer = createNewKafkaConsumer(consumerProperty, groupId);
        if(recordRecoverer != null) {
            kafkaConsumer.addErrorHandler(new DefaultErrorHandler(recordRecoverer, new FixedBackOff(consumerProperty.getInterval(), consumerProperty.getMaxAttempts())));
        }
        return new Subscriber<>(kafkaConsumer, messageHandler(messageListener));
    }

    protected <K, V> KafkaConsumer<K, V> createNewKafkaConsumer(String consumerName, String groupId) {
        ConsumerProperty consumerProperty = kafkaConfiguration.getConsumers().get(consumerName);
        return createNewKafkaConsumer(consumerProperty, groupId);
    }

    protected <K, V> KafkaConsumer<K, V> createNewKafkaConsumer(ConsumerProperty consumerProperty, String groupId) {
        ConsumerFactory<K, V> consumerFactory = consumerFactory(groupId, consumerProperty);
        ContainerProperties containerProperties = new ContainerProperties(consumerProperty.getTopic());
        containerProperties.setDeliveryAttemptHeader(true);
        if(!consumerProperty.isAutoCommit()) {
            containerProperties.setAckMode(ContainerProperties.AckMode.MANUAL);
        }
        ConcurrentMessageListenerContainer<K, V> concurrentMessageListenerContainer = new ConcurrentMessageListenerContainer<>(consumerFactory, containerProperties);
        if(consumerProperty.getConcurrency() > 0) {
            concurrentMessageListenerContainer.setConcurrency(consumerProperty.getConcurrency());
        }

        return new KafkaConsumer<>(concurrentMessageListenerContainer);
    }

    private <K, V> ConsumerFactory<K, V> consumerFactory(String groupId, ConsumerProperty consumerProperty) {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaCoreConfiguration.getBootstrapServer());
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, consumerProperty.getKeyDeserializer());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, consumerProperty.getValueDeserializer());
        props.put(SaslConfigs.SASL_JAAS_CONFIG, kafkaConfiguration.getSaslJaasString(kafkaCoreConfiguration.getLoginModule(), kafkaCoreConfiguration.getFlagValue(), consumerProperty.getApiKey(), consumerProperty.getApiSecret()));
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        props.put(SaslConfigs.SASL_MECHANISM, kafkaCoreConfiguration.getSaslMechanism());
        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, kafkaCoreConfiguration.getSecurityProtocol());
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, consumerProperty.isAutoCommit());
        if(consumerProperty.getMaxPollRecords()>0) {
            props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, consumerProperty.getMaxPollRecords());
        }


        return new DefaultKafkaConsumerFactory<>(props);
    }

    protected <K, V> AcknowledgingMessageListener<K,V> messageHandler(BiConsumer<V, Integer> messageListener){
        return (consumerRecord, acknowledgment) -> {
            int deliveryAttempt = getDeliveryAttempt(consumerRecord);
            log.info("Delivery attempt {}, consumerRecord offset {} and  partition {}", deliveryAttempt,
                    consumerRecord.offset(), consumerRecord.partition());
            messageListener.accept(consumerRecord.value(), deliveryAttempt);
            if(acknowledgment != null) {
                acknowledgment.acknowledge();
                log.info("Acknowledged, consumerRecord offset {} and  partition {}", consumerRecord.offset(),
                        consumerRecord.partition());
            }

        };
    }

    private <K, V> int getDeliveryAttempt(ConsumerRecord<K, V> consumerRecord){
        Iterable<Header> headers = consumerRecord.headers().headers(KafkaHeaders.DELIVERY_ATTEMPT);
        int deliveryAttempt = 1;
        if (headers != null) {
            for (Header header : headers) {
                deliveryAttempt = header.value() != null ?  ByteBuffer.wrap(header.value()).getInt() : 1;
            }
        }
        return deliveryAttempt;
    }
}
