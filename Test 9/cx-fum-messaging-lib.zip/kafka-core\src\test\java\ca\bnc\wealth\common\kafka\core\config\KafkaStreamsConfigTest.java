package ca.bnc.wealth.common.kafka.core.config;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.kafka.common.serialization.Serde;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Locale;

import static org.assertj.core.api.Assertions.assertThat;

class KafkaStreamsConfigTest {

    // What the Spring Boot 3 line (spring-kafka's Jackson 2 JsonSerializer) writes for a new Message()
    private static final String SB3_JSON = "{\"zeta\":\"z\",\"alpha\":null,\"path\":\"/wm/orders\",\"status\":\"ACTIVE\","
            + "\"delay\":90.000000000,\"time\":[2026,10,2,9,30,15,123456789]}";

    private final Serde<Message> serde = new KafkaStreamsConfig().messageValueSerde(Message.class);

    @Test
    void shouldWriteTheSameJsonAsTheSpringBoot3Line() {
        byte[] actual = serde.serializer().serialize("topic", new Message());

        assertThat(new String(actual, StandardCharsets.UTF_8)).isEqualTo(SB3_JSON);
    }

    @Test
    void shouldReadSpringBoot3JsonAndIgnoreUnknownProperties() {
        String json = "{\"zeta\":\"y\",\"unknown\":1,\"status\":\"INACTIVE\",\"delay\":30.000000000,"
                + "\"time\":[2026,1,2,3,4,5,6]}";

        Message actual = serde.deserializer().deserialize("topic", json.getBytes(StandardCharsets.UTF_8));

        assertThat(actual.getZeta()).isEqualTo("y");
        assertThat(actual.getStatus()).isEqualTo(Status.INACTIVE);
        assertThat(actual.getDelay()).isEqualTo(Duration.ofSeconds(30));
        assertThat(actual.getTime()).isEqualTo(LocalDateTime.of(2026, 1, 2, 3, 4, 5, 6));
    }

    public enum Status {
        ACTIVE, INACTIVE;

        @Override
        public String toString() {
            return name().toLowerCase(Locale.ROOT);
        }
    }

    @Getter
    @Setter
    @NoArgsConstructor
    public static class Message {
        private String zeta = "z";
        private String alpha;
        private String path = "/wm/orders";
        private Status status = Status.ACTIVE;
        private Duration delay = Duration.ofSeconds(90);
        private LocalDateTime time = LocalDateTime.of(2026, 10, 2, 9, 30, 15, 123456789);
    }
}
