package ca.bnc.wealth.common.kafka.core.config;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

import ca.bnc.wealth.common.kafka.core.publisher.ProducerProperty;
import ca.bnc.wealth.common.kafka.core.subscriber.ConsumerProperty;

@RunWith(SpringRunner.class)
public class TestKafkaConfiguration {

	@TestConfiguration
	static class KafkaConfigurationTestConfiguration {
		@Bean
		public KafkaConfiguration kafkaConfiguration() {
			KafkaConfiguration kafkaConfiguration = new KafkaConfiguration();
			Map<String, ConsumerProperty> consumers = new HashMap<>();
		    Map<String, ProducerProperty> producers = new HashMap<>();
			kafkaConfiguration.setConsumers(consumers);
			kafkaConfiguration.setProducers(producers);
			
			consumers.put("OrderEvents", new ConsumerProperty(null, "events.data.orders", null,
                    null, null, null, true, 0, 0, 0, 5));
			producers.put("NewOrders", new ProducerProperty(null, null, null, null, "messages.data.orders"));
			return kafkaConfiguration;
		}
	}
	
    @Autowired
    private KafkaConfiguration kafkaConfiguration;
    
    @MockitoBean
    private KafkaCoreConfiguration kafkaCoreConfiguration;

    @Test
    public void testConsumersConfig() {
        Map<String, ConsumerProperty> consumers = kafkaConfiguration.getConsumers();
        assertThat(consumers).isNotNull();
        ConsumerProperty consumerProperty = consumers.get("OrderEvents");
        assertThat(consumerProperty).isNotNull();
        assertThat(consumerProperty.getTopic()).isEqualTo("events.data.orders");
    }

    @Test
    public void testProducersConfig() {
        Map<String, ProducerProperty> producers = kafkaConfiguration.getProducers();
        assertThat(producers).isNotNull();
        ProducerProperty producerProperty = producers.get("NewOrders");
        assertThat(producerProperty).isNotNull();
        assertThat(producerProperty.getTopic()).isEqualTo("messages.data.orders");
    }

    @Test
    public void testSaslJaasString() {
        String expected = "loginModule:org.apache.kafka.common.security.plain.PlainLoginModule   required username='key'   password='value';";
        String actual = kafkaConfiguration.getSaslJaasString("loginModule:org.apache.kafka.common.security.plain.PlainLoginModule", "required", "key", "value");
        assertThat(actual).isEqualTo(expected);
    }


}
