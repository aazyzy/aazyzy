package ca.bnc.wealth.common.kafka.integration.test;

import ca.bnc.wealth.common.kafka.core.publisher.Publisher;
import ca.bnc.wealth.common.kafka.core.publisher.PublisherFactory;
import ca.bnc.wealth.common.kafka.core.subscriber.Subscriber;
import ca.bnc.wealth.common.kafka.core.subscriber.SubscriberFactory;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.listener.MessageListener;
import org.springframework.kafka.support.SendResult;

import java.util.Optional;
import java.util.concurrent.*;

//@DirtiesContext
//@SpringBootTest(classes = {KafkaConfiguration.class, KafkaCoreConfiguration.class})
//@RunWith(SpringRunner.class)
//@TestPropertySource(locations = {"file:./src/test/resources/kafka-core.yml", "file:./src/test/resources/kafka-lib.yml"})
//@EnableAutoConfiguration
@Slf4j
public class KafkaTest {

    @Autowired
    private SubscriberFactory subscriberFactory;

    @Autowired
    private PublisherFactory publisherFactory;

//    @Test
    public void givenASpecificPublisherAndConsumerReceiveMessage()
            throws Exception {
        final BlockingQueue<String> blockingQueue = new ArrayBlockingQueue<>(10);
        produceMessage();
        consumeMessage(blockingQueue);
        Assert.assertEquals("TestMessage", blockingQueue.poll(6000, TimeUnit.MILLISECONDS));
    }

    private void produceMessage() throws ExecutionException, InterruptedException, TimeoutException {
        Publisher<String, String> p = publisherFactory.createNewPublisher("NewOrders");
        Optional<SendResult<String, String>> x = p.publishSynchronous("TestMessage");
        x.ifPresent((SendResult<String, String> a) ->log.info("Message produced: {}",a.getProducerRecord()));
    }

    private void consumeMessage(BlockingQueue<String> blockingQueue) {
        Subscriber<String, String> s = subscriberFactory.createNewSubscriber("NewOrders", "group-id", (MessageListener<String, String>)  data -> {
            try {
                log.info("Message received: {}", data);
                blockingQueue.put(data.value());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        s.subscribe();
    }
}
