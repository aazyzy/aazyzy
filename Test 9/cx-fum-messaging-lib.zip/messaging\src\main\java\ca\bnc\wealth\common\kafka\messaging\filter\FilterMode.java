package ca.bnc.wealth.common.kafka.messaging.filter;

public  enum FilterMode {
  MATCH_ALL, MATCH_ANY
}

