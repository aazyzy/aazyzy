package ca.bnc.wealth.common.kafka.messaging.filter;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Header;
import org.springframework.kafka.listener.adapter.RecordFilterStrategy;
import org.springframework.util.CollectionUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class HeaderTagRecordFilterStrategy<K, V> implements RecordFilterStrategy<K, V> {

  private FilterMode mode;
  private Map<String, String> headerTags;

  public HeaderTagRecordFilterStrategy(Map<String, String> headerTags, FilterMode filterMode) {
    this.mode = filterMode;
    this.headerTags = headerTags;
  }

  @Override
  public boolean filter(ConsumerRecord<K, V> consumerRecord) {

    if (CollectionUtils.isEmpty(headerTags)) {
      return false; // No filter defined
    }
    if (FilterMode.MATCH_ALL.equals(this.mode)) {
      boolean result = headerTags.entrySet().stream().allMatch(entry -> searchHeader(consumerRecord, entry));
      return processResult(consumerRecord, result);
    } else {
      boolean result = headerTags.entrySet().stream().anyMatch(entry -> searchHeader(consumerRecord, entry));
      return processResult(consumerRecord, result);
    }
  }

  private boolean processResult(ConsumerRecord<K, V> consumerRecord, boolean result) {
    if (result) {
      return false;// search criteria is passed, hence should not be filtered
    } else {
      // All predicates executed and not matches with the record header, hence should be filtered
      log.info("Search criteria(s) not matching with header, hence record : {} is filtered ",
          consumerRecord);
      return true;
    }
  }

  private boolean searchHeader(ConsumerRecord<K, V> consumerRecord, Entry<String, String> entry) {
    Iterable<Header> headers = consumerRecord.headers().headers(entry.getKey());
    boolean result = false;
    if (headers != null) {
      for (Header header : headers) {
        result = header.value() != null && entry.getValue().equals(new String(header.value(), StandardCharsets.UTF_8));
        if (result)
          break;
      }
    }

    log.debug("Executed HeaderTagPredicate, input key: {}, value: {}, headers: {} and result {}",
        entry.getKey(), entry.getValue(), headers, result);
    return result;
  }

}
