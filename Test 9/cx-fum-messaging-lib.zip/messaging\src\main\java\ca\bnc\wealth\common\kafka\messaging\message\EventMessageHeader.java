package ca.bnc.wealth.common.kafka.messaging.message;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.jackson.Jacksonized;

import java.util.Map;

/**
 * Event Message Header
 * The metadata or information about the message that allows consumers to "peek" and understand the type of message
 */
@Jacksonized
@Getter
@Builder
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EventMessageHeader {
    /**
     * A universally unique identifier (UUID) is a 128-bit number used to identify information in computer systems.
     * The term globally unique identifier (GUID) is also used, typically in software created by Microsoft.
     * When generated according to the standard methods, UUIDs are unique.
     */
    private String id;

    /**
     * A reference id to tie different events together. e.g. An order booked might create a reference id, however CDB and PrimeOE might create their own IDs.
     */
    private String refId;

    /**
     * Specifies the action, due to which the message is generated.
     */
    private String action;

    /**
     * The trigger for event generation. A verb related to the data's lifecycle.
     * E.g. PENDING
     */
    private String state;

    /**
     * The reason for the event
     * This allows for better troubleshooting by indicating where the data is currently at or where the event occurred
     * E.g Booking inserted in CDB vs Booking received by Fundsoegw vs Booking transmitted to PrimeOE vs Booking received at FundServ
     */
    private String reason;

    /**
     * The event message version
     */
    private String version;

    /**
     * key-value map used by consumers to subscribe to more specific events
     * Tags can be used by consumers to filter events that they're only interested in
     */
    private Map<String, String> tags;
}
