package ca.bnc.wealth.common.kafka.messaging.message;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.jackson.Jacksonized;

import java.util.List;
import java.util.Map;

/**
 * Event Message Payload
 * The data which can be basic attributes only (just type and ID)
 * Note - Currently, the payload does NOT contain the actual full data. This is due to a security requirement. The system consuming the event message will need to query for the full data, given the type and ID.
 */
@Jacksonized
@Getter
@Builder
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EventMessagePayload {
    /**
     *  The type of data domain that generated the event. Ideally, as a hierarchy
     */
    private String type;

    /**
     * Data specific ID used for correlation. e.g. the order ID
     */
    private String id;
    private String rrCode;
}
