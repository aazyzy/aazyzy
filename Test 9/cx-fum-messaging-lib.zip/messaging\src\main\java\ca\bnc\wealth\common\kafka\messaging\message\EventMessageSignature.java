package ca.bnc.wealth.common.kafka.messaging.message;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.jackson.Jacksonized;

/**
 * Event Message Signature
 * A digital signature that can be used verify the authenticity of the message
 */
@Jacksonized
@Getter
@Builder
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EventMessageSignature {

    /**
     * Digital signature key id
     */
    // Jackson 2 named getKId() "kid"; Jackson 3 would write "KId"
    @Getter(onMethod_ = @JsonProperty("kid"))
    private String kId;

    /**
     *  The Digital signature (header + source + payload)
     */
    private String value;
}
