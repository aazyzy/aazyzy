package ca.bnc.wealth.common.kafka.messaging.message;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.jackson.Jacksonized;

/**
 * Event Message Source
 * Info about the source system that generated the event
 */
@Jacksonized
@Getter
@Builder
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EventMessageSource {
    /**
     * The source system where the event originated from
     */
    private EventMessageSourceSystem origin;

    /**
     * The source system that created or generated the event
     */
    private EventMessageSourceSystem publisher;
}
