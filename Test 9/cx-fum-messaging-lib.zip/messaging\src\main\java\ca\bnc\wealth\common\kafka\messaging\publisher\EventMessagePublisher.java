package ca.bnc.wealth.common.kafka.messaging.publisher;

import ca.bnc.wealth.common.kafka.core.publisher.KafkaProducer;
import ca.bnc.wealth.common.kafka.core.publisher.Publisher;
import ca.bnc.wealth.common.kafka.messaging.message.EventMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.support.SendResult;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

@Slf4j
public class EventMessagePublisher extends Publisher<String, String> {
    private final ObjectMapper objectMapper;

    public EventMessagePublisher(String topic, KafkaProducer<String, String> kafkaProducer) {
        super(topic, kafkaProducer);
        // Jackson 2 defaults keep the message bytes identical to what the Spring Boot 3 line publishes
        this.objectMapper = JsonMapper.builderWithJackson2Defaults().build();
    }

    public Optional<SendResult<String, String>> publishEventMessage(EventMessage eventMessage) throws JacksonException, ExecutionException, TimeoutException {
      //All header tags are pushed to kafka message header for now  
      return publishSynchronous(eventMessage.getPayload().getId(),objectMapper.writeValueAsString(eventMessage), eventMessage.getHeader().getTags());
    }

    /**
     * Publishes the given eventMessage with a defined timeout.
     * If timout is null or <= 0, there won't be any timeout for the operation and the operation will be blocking indefinitely
     *
     * @param eventMessage - event message to be published {@link EventMessage}
     * @param timeout - timeout for the operation
     * @return result of the operation {@link Optional<SendResult<String, String>>}
     */
    public Optional<SendResult<String, String>> publishEventMessage(EventMessage eventMessage, Long timeout) throws JacksonException, ExecutionException, TimeoutException {
        //All header tags are pushed to kafka message header for now
        return publishSynchronous(eventMessage.getPayload().getId(), objectMapper.writeValueAsString(eventMessage), eventMessage.getHeader().getTags(), timeout);
    }

    /**
     * Publishes the given eventMessage to the specified partition
     *
     * @param partition - partition number
     * @param eventMessage - event message to be published {@link EventMessage}
     * @return result of the operation {@link Optional<SendResult<String, String>>}
     */
    public Optional<SendResult<String, String>> publishEventMessage(int partition, EventMessage eventMessage) throws JacksonException, ExecutionException, TimeoutException {
        //All header tags are pushed to kafka message header for now
        return publishSynchronous(partition, eventMessage.getPayload().getId(), objectMapper.writeValueAsString(eventMessage), eventMessage.getHeader().getTags());
    }

    /**
     * Publishes the given eventMessage to the specified partition with a defined timeout.
     * If timout is null or <= 0, there won't be any timeout for the operation and the operation will be blocking indefinitely
     *
     * @param partition - partition number
     * @param eventMessage - event message to be published {@link EventMessage}
     * @param timeout - timeout for the operation
     * @return result of the operation {@link Optional<SendResult<String, String>>}
     */
    public Optional<SendResult<String, String>> publishEventMessage(int partition, EventMessage eventMessage, Long timeout) throws JacksonException, ExecutionException, TimeoutException {
        //All header tags are pushed to kafka message header for now
        return publishSynchronous(partition, eventMessage.getPayload().getId(), objectMapper.writeValueAsString(eventMessage), eventMessage.getHeader().getTags(), timeout);
    }
}
