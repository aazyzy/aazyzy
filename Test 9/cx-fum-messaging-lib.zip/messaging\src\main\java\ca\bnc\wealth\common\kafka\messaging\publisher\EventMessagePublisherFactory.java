package ca.bnc.wealth.common.kafka.messaging.publisher;

import ca.bnc.wealth.common.kafka.core.publisher.ProducerProperty;
import ca.bnc.wealth.common.kafka.core.publisher.PublisherFactory;
import org.springframework.stereotype.Component;

@Component
public class EventMessagePublisherFactory extends PublisherFactory {

    public EventMessagePublisher createNewEventMessagePublisher(String publisherName) {
        ProducerProperty producerProperty = kafkaConfiguration.getProducers().get(publisherName);
        return new EventMessagePublisher(producerProperty.getTopic(), createNewKafkaProducer(producerProperty));
    }
}
