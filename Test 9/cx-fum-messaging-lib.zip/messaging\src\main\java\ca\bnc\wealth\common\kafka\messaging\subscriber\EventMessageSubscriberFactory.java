package ca.bnc.wealth.common.kafka.messaging.subscriber;

import ca.bnc.wealth.common.kafka.core.subscriber.ConsumerProperty;
import ca.bnc.wealth.common.kafka.core.subscriber.Subscriber;
import ca.bnc.wealth.common.kafka.core.subscriber.SubscriberFactory;
import ca.bnc.wealth.common.kafka.messaging.filter.FilterMode;
import ca.bnc.wealth.common.kafka.messaging.filter.HeaderTagRecordFilterStrategy;
import org.springframework.kafka.listener.ConsumerRecordRecoverer;
import org.springframework.kafka.listener.MessageListener;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.function.BiConsumer;


@Component
public class EventMessageSubscriberFactory extends SubscriberFactory {

  /**
   * Creates subscriber with filter rules passed in header tags and uses MATCH_ANY filter mode for
   * filtering
   * 
   * @param consumerName - consumer name
   * @param groupId - consumer group id.
   * @param headerTags - header tags used to filter the messages before consuming
   * @param messageListener - listener to be called on message
   * @return Subscriber to start the consumer
   */
  @Deprecated
  public <K, V> Subscriber<K, V> createNewFilteredSubscriber(String consumerName, String groupId,
      Map<String, String> headerTags, MessageListener<K, V> messageListener) {
    return createNewFilteredSubscriber(consumerName, groupId, headerTags, FilterMode.MATCH_ANY,
        messageListener);
  }

  /**
   * Creates subscriber with filter rules passed in header tags and uses filter mode
   * 
   * @param consumerName - consumer name
   * @param groupId - consumer group id.
   * @param headerTags - header tag used to filter the messages before consuming
   * @param mode - specify filter mode ca.bnc.wealth.common.kafka.messaging.filter.FilterMode
   * @param messageListener - listener to be called on message
   * @return Subscriber to start the consumer
   */
  @Deprecated
  public <K, V> Subscriber<K, V>  createNewFilteredSubscriber(String consumerName, String groupId,
      Map<String, String> headerTags, FilterMode mode, MessageListener<K, V> messageListener) {
    return createNewFilteredSubscriber(consumerName, groupId, messageListener,
        new HeaderTagRecordFilterStrategy<>(headerTags, mode));
  }

  /**
   * Creates subscriber with filter rules passed in header tags and uses MATCH_ANY filter mode for
   * filtering
   *
   * @param consumerName - consumer name
   * @param groupId - consumer group id.
   * @param headerTags - header tags used to filter the messages before consuming
   * @param messageHandler - BiConsumer to be called on message
   * @return Subscriber to start the consumer
   */
  public <K, V> Subscriber<K, V> createNewFilteredSubscriber(String consumerName, String groupId,
                                                             Map<String, String> headerTags, BiConsumer<V, Integer> messageHandler) {
    return createNewFilteredSubscriber(consumerName, groupId, headerTags, FilterMode.MATCH_ANY, messageHandler);
  }

  /**
   * Creates subscriber with recovery and filter rules passed in header tags and uses MATCH_ANY filter mode for
   * filtering
   *
   * @param consumerName - consumer name
   * @param groupId - consumer group id.
   * @param headerTags - header tags used to filter the messages before consuming
   * @param messageHandler - BiConsumer to be called on message
   * @return Subscriber to start the consumer
   */
  public <K, V> Subscriber<K, V> createNewFilteredSubscriber(String consumerName, String groupId,
                                                             Map<String, String> headerTags, BiConsumer<V, Integer> messageHandler, ConsumerRecordRecoverer recordRecoverer) {
    return createNewFilteredSubscriber(consumerName, groupId, headerTags, FilterMode.MATCH_ANY, messageHandler, recordRecoverer);
  }

  /**
   * Creates subscriber with filter rules passed in header tags and uses filter mode
   *
   * @param consumerName - consumer name
   * @param groupId - consumer group id.
   * @param headerTags - header tag used to filter the messages before consuming
   * @param mode - specify filter mode ca.bnc.wealth.common.kafka.messaging.filter.FilterMode
   * @param messageHandler - BiConsumer to be called on message
   * @return Subscriber to start the consumer
   */
  public <K, V> Subscriber<K, V> createNewFilteredSubscriber(String consumerName, String groupId,
                                                             Map<String, String> headerTags, FilterMode mode, BiConsumer<V, Integer> messageHandler) {
    return createNewFilteredSubscriber(consumerName, groupId, messageHandler,
            new HeaderTagRecordFilterStrategy<>(headerTags, mode));
  }

  /**
   * Creates subscriber with recovery and filter rules passed in header tags and uses filter mode
   *
   * @param consumerName - consumer name
   * @param groupId - consumer group id.
   * @param headerTags - header tag used to filter the messages before consuming
   * @param mode - specify filter mode ca.bnc.wealth.common.kafka.messaging.filter.FilterMode
   * @param messageHandler - BiConsumer to be called on message
   * @return Subscriber to start the consumer
   */
  public <K, V> Subscriber<K, V> createNewFilteredSubscriber(String consumerName, String groupId,
                                                             Map<String, String> headerTags, FilterMode mode, BiConsumer<V, Integer> messageHandler, ConsumerRecordRecoverer recordRecoverer) {
    return createNewFilteredSubscriber(consumerName, groupId, messageHandler,
            new HeaderTagRecordFilterStrategy<>(headerTags, mode), recordRecoverer);
  }

  /**
   * Creates subscriber with filter rules passed in header tags and uses MATCH_ANY filter mode for
   * filtering
   *
   * @param consumerProperty - consumer property {@link ConsumerProperty}
   * @param groupId - consumer group id.
   * @param headerTags - header tags used to filter the messages before consuming
   * @param messageHandler - BiConsumer to be called on message
   * @return Subscriber to start the consumer
   */
  public <K, V> Subscriber<K, V> createNewFilteredSubscriber(ConsumerProperty consumerProperty, String groupId,
                                                             Map<String, String> headerTags, BiConsumer<V, Integer> messageHandler) {
    return createNewFilteredSubscriber(consumerProperty, groupId, headerTags, FilterMode.MATCH_ANY, messageHandler);
  }

  /**
   * Creates subscriber with filter rules passed in header tags and uses filter mode
   *
   * @param consumerProperty - consumer property {@link ConsumerProperty}
   * @param groupId - consumer group id.
   * @param headerTags - header tag used to filter the messages before consuming
   * @param mode - specify filter mode ca.bnc.wealth.common.kafka.messaging.filter.FilterMode
   * @param messageHandler - BiConsumer to be called on message
   * @return Subscriber to start the consumer
   */
  public <K, V> Subscriber<K, V> createNewFilteredSubscriber(ConsumerProperty consumerProperty, String groupId,
                                                             Map<String, String> headerTags, FilterMode mode, BiConsumer<V, Integer> messageHandler) {
    return createNewFilteredSubscriber(consumerProperty, groupId, messageHandler,
            new HeaderTagRecordFilterStrategy<>(headerTags, mode));
  }

}
