package ca.bnc.wealth.common.kafka.messaging.transformer;

import ca.bnc.wealth.common.kafka.messaging.message.EventMessage;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.kstream.Transformer;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.nio.charset.StandardCharsets;

@Component
public class EventMessageTransformer implements Transformer<String,EventMessage, KeyValue<String,EventMessage>> {

    private ProcessorContext context;

    @Override
    public void init(ProcessorContext processorContext) {
        this.context=processorContext;
    }

    /**
     * header tags are pushed to kafka message header
     *
     * @param key - message key
     * @param eventMessage - Event message
     * @return message after setting the headers
     */
    @Override
    public KeyValue<String, EventMessage> transform(String key, EventMessage eventMessage) {
        if(eventMessage.getHeader()!=null && !CollectionUtils.isEmpty(eventMessage.getHeader().getTags())) {
            eventMessage.getHeader().getTags().forEach((mapKey, value) -> this.context.headers().add(mapKey,
                    value.getBytes(StandardCharsets.UTF_8)));

        }
       return KeyValue.pair(key,eventMessage);
    }

    @Override
    public void close() {
        //do nothing
    }
}
