package ca.bnc.wealth.common.kafka.messaging.message;

import ca.bnc.wealth.common.kafka.core.config.KafkaStreamsConfig;
import ca.bnc.wealth.common.kafka.core.publisher.KafkaProducer;
import ca.bnc.wealth.common.kafka.messaging.publisher.EventMessagePublisher;
import org.apache.kafka.common.serialization.Serde;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class EventMessageJsonTest {

    private static final Map<String, String> TAGS = Map.of("cdb-id", "123456789");
    private static final LocalDateTime ORIGIN_TIME = LocalDateTime.of(2021, 3, 22, 16, 5, 2, 123456789);

    // What the Spring Boot 3 line (Jackson 2) writes for eventMessage()
    private static final String SB3_JSON = "{\"header\":{\"id\":\"123e4567-e89b-12d3-a456-426614174000\",\"refId\":\"MF-123\","
            + "\"action\":\"Booking\",\"state\":\"Pending\",\"reason\":\"Booking transmitted to PrimeOE\",\"version\":\"1.0\","
            + "\"tags\":{\"cdb-id\":\"123456789\"}},"
            + "\"source\":{\"origin\":{\"system\":\"primeOE\",\"nbcId\":\"0605\",\"time\":[2021,3,22,16,5,2,123456789]},"
            + "\"publisher\":{\"system\":\"nbin.cx-trading.mutual-fund-order-api\",\"nbcId\":\"6588\",\"time\":[2021,3,22,16,5,3]}},"
            + "\"payload\":{\"type\":\"/wm/orders/mutual-fund\",\"id\":\"MF-123\",\"rrCode\":\"MF01\"},"
            + "\"signature\":{\"value\":\"c2lnbmF0dXJl\",\"kid\":\"key-1\"}}";

    @Mock
    private KafkaProducer<String, String> kafkaProducer;

    private final Serde<EventMessage> serde = new KafkaStreamsConfig().messageValueSerde(EventMessage.class);

    @Test
    void shouldPublishTheSameJsonAsTheSpringBoot3Line() throws Exception {
        new EventMessagePublisher("topic", kafkaProducer).publishEventMessage(eventMessage());

        ArgumentCaptor<String> json = ArgumentCaptor.forClass(String.class);
        verify(kafkaProducer).sendMessageSync(eq("topic"), eq("MF-123"), json.capture(), eq(TAGS));
        assertThat(json.getValue()).isEqualTo(SB3_JSON);
    }

    @Test
    void shouldSerializeWithTheStreamsSerdeLikeTheSpringBoot3Line() {
        byte[] actual = serde.serializer().serialize("topic", eventMessage());

        assertThat(new String(actual, StandardCharsets.UTF_8)).isEqualTo(SB3_JSON);
    }

    @Test
    void shouldReadSpringBoot3JsonThroughTheJacksonizedBuilder() {
        EventMessage actual = serde.deserializer().deserialize("topic", SB3_JSON.getBytes(StandardCharsets.UTF_8));

        assertThat(actual.getHeader().getRefId()).isEqualTo("MF-123");
        assertThat(actual.getHeader().getTags()).isEqualTo(TAGS);
        assertThat(actual.getSource().getOrigin().getTime()).isEqualTo(ORIGIN_TIME);
        assertThat(actual.getPayload().getType()).isEqualTo("/wm/orders/mutual-fund");
        assertThat(actual.getSignature().getValue()).isEqualTo("c2lnbmF0dXJl");
        // the Spring Boot 3 line drops it too: the getter writes "kid", the builder reads "kId"
        assertThat(actual.getSignature().getKId()).isNull();
    }

    private static EventMessage eventMessage() {
        return EventMessage.builder()
                .header(EventMessageHeader.builder()
                        .id("123e4567-e89b-12d3-a456-426614174000")
                        .refId("MF-123")
                        .action("Booking")
                        .state("Pending")
                        .reason("Booking transmitted to PrimeOE")
                        .version("1.0")
                        .tags(TAGS)
                        .build())
                .source(EventMessageSource.builder()
                        .origin(new EventMessageSourceSystem("primeOE", "0605", ORIGIN_TIME))
                        .publisher(new EventMessageSourceSystem("nbin.cx-trading.mutual-fund-order-api", "6588",
                                LocalDateTime.of(2021, 3, 22, 16, 5, 3)))
                        .build())
                .payload(EventMessagePayload.builder()
                        .type("/wm/orders/mutual-fund")
                        .id("MF-123")
                        .rrCode("MF01")
                        .build())
                .signature(EventMessageSignature.builder()
                        .kId("key-1")
                        .value("c2lnbmF0dXJl")
                        .build())
                .build();
    }
}
