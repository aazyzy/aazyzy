package ca.bnc.wealth.common.kafka.messaging.subscriber;

import ca.bnc.wealth.common.kafka.core.config.KafkaConfiguration;
import ca.bnc.wealth.common.kafka.core.config.KafkaCoreConfiguration;
import ca.bnc.wealth.common.kafka.core.publisher.Publisher;
import ca.bnc.wealth.common.kafka.core.subscriber.Subscriber;
import ca.bnc.wealth.common.kafka.messaging.filter.FilterMode;
import ca.bnc.wealth.common.kafka.messaging.message.EventMessage;
import ca.bnc.wealth.common.kafka.messaging.message.EventMessageHeader;
import ca.bnc.wealth.common.kafka.messaging.message.EventMessagePayload;
import ca.bnc.wealth.common.kafka.messaging.message.EventMessageSource;
import ca.bnc.wealth.common.kafka.messaging.message.EventMessageSourceSystem;
import ca.bnc.wealth.common.kafka.messaging.publisher.EventMessagePublisherFactory;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.support.SendResult;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.*;

@DirtiesContext
@SpringBootTest(classes = {KafkaConfiguration.class, KafkaCoreConfiguration.class,
    EventMessageSubscriberFactory.class, EventMessagePublisherFactory.class})
@RunWith(SpringRunner.class)
@TestPropertySource(locations = {"file:./src/test/resources/kafka-core.yml",
    "file:./src/test/resources/kafka-lib.yml"})
@EnableAutoConfiguration
@Slf4j
@Ignore ("Ignore test for dev build due to dev Kafka unavailability")
public class EventMessageSubscriberFactoryTest {

  @Autowired
  private EventMessageSubscriberFactory subscriberFactory;

  @Autowired
  private EventMessagePublisherFactory publisherFactory;

  Publisher<String, String> publisher;

  ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().build();

  private static final String SOME_HEADER_ID = "123e4567-e89b-12d3-a456-426614174000";
  private static final String SOME_HEADER_REF_ID = "MF-123";
  private static final String SOME_HEADER_STATE = "Pending";
  private static final String SOME_HEADER_ACTION = "Booking";
  private static final String SOME_HEADER_REASON = "Booking transmitted to PrimeOE";
  private static final String SOME_HEADER_VERSION = "1.0";
  private static final Map<String, String> SOME_HEADER_TAGS = Map.of("originatingBookingSystem",
      "cx-trading", "cdb-id", "123456789", "primeoe-id", "123123");
  private static final String SOME_ORIGIN_SOURCE_SYSTEM = "primeOE";
  private static final String SOME_ORIGIN_SOURCE_NBC_ID = "0605";
  private static final LocalDateTime SOME_ORIGIN_SOURCE_TIME =
      LocalDateTime.of(2021, 03, 22, 16, 05, 02);
  private static final String SOME_PUBLISHER_SOURCE_SYSTEM =
      "nbin.cx-trading.mutual-fund-order-api";
  private static final String SOME_PUBLISHER_SOURCE_NBC_ID = "6588";
  private static final LocalDateTime SOME_PUBLISHER_SOURCE_TIME =
      LocalDateTime.of(2021, 03, 22, 16, 05, 03);
  private static final String SOME_PAYLOAD_TYPE = "/wm/orders/mutual-fund";
  private static final String SOME_PAYLOAD_ID = "MF-123";


  private static final Map<String, String> MATCH_ALL_HEADER_TAGS = Map
      .of("originatingBookingSystem", "cx-trading", "cdb-id", "123456789", "primeoe-id", "123123");

  private static final Map<String, String> MATCH_ANY_HEADER_TAGS = Map.of(
      "originatingBookingSystem", "cx-trading", "cdb-id", "123456789", "primeoe-id", "something");

  private static final Map<String, String> MATCH_ANY_HEADER_TAGS_2 =
      Map.of("originatingBookingSystem", "no-cx-trading", "cdb-id", "something", "primeoe-id",
          "something");

  private static final Map<String, String> MATCH_HEADER_TAGS_3 =
      Map.of("originatingBookingSystem", "cx-trading");

  private static final Map<String, String> MATCH_HEADER_TAGS_4 = Map.of("InvalidKey", "cx-trading");

  private static final Map<String, String> MATCH_HEADER_TAGS_5 =
      Map.of("originatingBookingSystem", "no-cx-trading");

  @Before
  public void setUp() {
    publisher = publisherFactory.createNewPublisher("OrderEventsMF");
  }


  private EventMessage prepareEventMessage() {

    EventMessage eventMessage = EventMessage.builder()
        .header(EventMessageHeader.builder().id(SOME_HEADER_ID).refId(SOME_HEADER_REF_ID)
            .state(SOME_HEADER_STATE).action(SOME_HEADER_ACTION).reason(SOME_HEADER_REASON).version(SOME_HEADER_VERSION).tags(SOME_HEADER_TAGS).build())
        .source(EventMessageSource.builder()
            .origin(EventMessageSourceSystem.builder().system(SOME_ORIGIN_SOURCE_SYSTEM)
                .nbcId(SOME_ORIGIN_SOURCE_NBC_ID).time(SOME_ORIGIN_SOURCE_TIME).build())
            .publisher(EventMessageSourceSystem.builder().system(SOME_PUBLISHER_SOURCE_SYSTEM)
                .nbcId(SOME_PUBLISHER_SOURCE_NBC_ID).time(SOME_PUBLISHER_SOURCE_TIME).build())
            .build())
        .payload(EventMessagePayload.builder().type(SOME_PAYLOAD_TYPE).id(SOME_PAYLOAD_ID).build())
        .build();

    return eventMessage;
  }


  @Test
  public void testMessageFilter_sucess() throws Exception {
    final BlockingQueue<String> blockingQueue = new ArrayBlockingQueue<>(10);
    produceMessage();
    // Valid key and matches with value, so record should not be filtered
    Subscriber<String, String> s = consumeMessage(blockingQueue, MATCH_HEADER_TAGS_3, "group1");
    Assert.assertNotEquals(null, blockingQueue.poll(6000, TimeUnit.MILLISECONDS));
    s.unsubscribe();

  }

  @Test
  public void testMessageFilter_filtered() throws Exception {
    final BlockingQueue<String> blockingQueue = new ArrayBlockingQueue<>(10);
    produceMessage();
    // Valid key and not matches with value, so record should be filtered
    Subscriber<String, String> s = consumeMessage(blockingQueue, MATCH_HEADER_TAGS_5, "group1");
    Assert.assertEquals(null, blockingQueue.poll(6000, TimeUnit.MILLISECONDS));
    s.unsubscribe();
  }

  @Test
  public void testMessageFilter_multiKeys_filtered() throws Exception {
    final BlockingQueue<String> blockingQueue = new ArrayBlockingQueue<>(10);
    produceMessage();
    // Valid key and not matches with all, so record should be filtered
    Subscriber<String, String> s = consumeMessage(blockingQueue, MATCH_ANY_HEADER_TAGS_2, "group1");
    Assert.assertEquals(null, blockingQueue.poll(6000, TimeUnit.MILLISECONDS));
    s.unsubscribe();
  }

  @Test
  public void testMessageFilter_multiKeys_success() throws Exception {
    final BlockingQueue<String> blockingQueue = new ArrayBlockingQueue<>(10);
    produceMessage();
    // Valid key and one or more matches the value, so record should not be filtered
    Subscriber<String, String> s = consumeMessage(blockingQueue, MATCH_ANY_HEADER_TAGS, "group1");
    Assert.assertNotEquals(null, blockingQueue.poll(6000, TimeUnit.MILLISECONDS));
    s.unsubscribe();
  }

  @Test
  public void testMessageFilter_multiKeys_matchAll_failed() throws Exception {
    final BlockingQueue<String> blockingQueue = new ArrayBlockingQueue<>(10);
    produceMessage();
    // Valid key and one or more matches the value, so record should be filtered
    Subscriber<String, String> s =
        consumeMessage(blockingQueue, MATCH_ANY_HEADER_TAGS, FilterMode.MATCH_ALL, "group1");
    Assert.assertEquals(null, blockingQueue.poll(6000, TimeUnit.MILLISECONDS));
    s.unsubscribe();
  }

  @Test
  public void testMessageFilter_multiKeys_matchAll_success() throws Exception {
    final BlockingQueue<String> blockingQueue = new ArrayBlockingQueue<>(10);
    produceMessage();
    // Valid key and one or more matches the value, so record should not be filtered
    Subscriber<String, String> s =
        consumeMessage(blockingQueue, MATCH_ALL_HEADER_TAGS, FilterMode.MATCH_ALL, "group1");
    Assert.assertNotEquals(null, blockingQueue.poll(6000, TimeUnit.MILLISECONDS));
    s.unsubscribe();
  }

  @Test
  public void testMessageFilter_invalidKey_filtered() throws Exception {
    final BlockingQueue<String> blockingQueue = new ArrayBlockingQueue<>(10);
    produceMessage();
    // Invalid key, so record should be filtered
    Subscriber<String, String> s = consumeMessage(blockingQueue, MATCH_HEADER_TAGS_4, "group1");
    Assert.assertEquals(null, blockingQueue.poll(6000, TimeUnit.MILLISECONDS));
    s.unsubscribe();
  }

  @Test
  public void testMessageFilter_noFilter() throws Exception {
    final BlockingQueue<String> blockingQueue = new ArrayBlockingQueue<>(10);
    produceMessage();
    // Invalid key, so record should be filtered
    Subscriber<String, String> s = consumeMessage(blockingQueue, null, "group1");
    Assert.assertNotEquals(null, blockingQueue.poll(6000, TimeUnit.MILLISECONDS));
    s.unsubscribe();
  }

  private void produceMessage()
      throws ExecutionException, InterruptedException, TimeoutException {
    EventMessage eventMessage = prepareEventMessage();
    Optional<SendResult<String, String>> x = publisher.publishSynchronous(
        objectMapper.writeValueAsString(eventMessage), eventMessage.getHeader().getTags());
    x.ifPresent(
        (SendResult<String, String> a) -> log.info("Message produced: {}", a.getProducerRecord()));
  }

  private Subscriber<String, String> consumeMessage(BlockingQueue<String> blockingQueue,
      Map<String, String> filterMap, String group) {
    Subscriber<String, String> s =
        subscriberFactory.createNewFilteredSubscriber("OrderEventsMF", group, filterMap, data -> {
          try {
            log.info("Message received: {}", data);
            blockingQueue.put(data.value());
          } catch (InterruptedException e) {
            e.printStackTrace();
          }
        });
    s.subscribe();
    return s;
  }

  private Subscriber<String, String> consumeMessage(BlockingQueue<String> blockingQueue,
      Map<String, String> filterMap, FilterMode mode, String group) {
    Subscriber<String, String> s = subscriberFactory.createNewFilteredSubscriber("OrderEventsMF",
        group, filterMap, mode, data -> {
          try {
            log.info("Message received: {}", data);
            blockingQueue.put(data.value());
          } catch (InterruptedException e) {
            e.printStackTrace();
          }
        });
    s.subscribe();
    return s;
  }

}
