# Changelog

## [1.14.0](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/compare/v1.13.3...v1.14.0) (2026-06-15)


### Features

* test new workflow ([7b8e1fa](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/7b8e1fa7996e2697ca82282e686cf40a50e3524f))

## [1.13.3](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/compare/v1.13.2...v1.13.3) (2026-06-15)


### Bug Fixes

* first new workflwo release ([a4b87ae](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/a4b87ae7c80bab68dacdc1b4945c9bdca631a1e7))

## [1.13.2](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/compare/v1.13.1...v1.13.2) (2026-06-15)


### Bug Fixes

* retest release ([1f57e5d](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/1f57e5d712cf542a7f5389fd69f65e5d49d7cac1))
* testing workflows ([c976711](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/c976711d69f929367a0c4d4cd0cf0e4e64365c02))

## [1.13.1](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/compare/v1.13.0...v1.13.1) (2026-06-13)


### Bug Fixes

* demo using reusable workflows ([872cf9f](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/872cf9fc88c6d3684e7e570f4f4f2a3f51629f70))

## [1.13.0](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/compare/v1.12.2...v1.13.0) (2026-06-13)


### Features

* test release ([89f387b](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/89f387beeb9cf080d8f9c64950d2af7a9848d985))

## [1.12.2](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/compare/v1.12.1...v1.12.2) (2026-06-13)


### Bug Fixes

* first demo after resuable workflow ([f005e96](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/f005e96933af314bd2321239411e0020a27dee4d))

## [1.12.1](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/compare/v1.12.0...v1.12.1) (2026-06-13)


### Bug Fixes

* demo release of fix after feat release ([cdd216a](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/cdd216a1122b4f708f5bc9cf6b39cd19c037ec61))

## [1.12.0](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/compare/v1.11.58...v1.12.0) (2026-06-13)


### Features

* demo feat release ([18882ca](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/18882cae2ddaee02f7f4d33f654635750d5ea921))
* test synchronized minor release ([921f0a3](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/921f0a3b5a4f6f25d22f9338f179dffc96328d28))
* test synchronized minor release ([e3b0da0](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/e3b0da0fca9352553a6e75bc67c390e323a97345))
* test synchronized minor release ([2b1f836](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/2b1f836c7fbfb863af0ff909f7989003a4b770f4))
* test synchronized minor release ([b89f64d](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/b89f64d0596412ca2523e5dc47fb2f32567a63ad))

## [1.11.58](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/compare/v1.11.57...v1.11.58) (2026-06-13)


### Bug Fixes

* demo release 5 ([a4eac14](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/a4eac1429065b58e4909c77ffa58f6687f701130))

## [1.11.57](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/compare/v1.11.56...v1.11.57) (2026-06-13)


### Bug Fixes

* adjusting release trigger workflow ([0366843](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/036684337df94270e4166ad6b47071b6fcb7da54))
* demo release 3 ([af46123](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/af461237d79391f9f4ed84d80b515bf1889666eb))

## [1.11.56](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/compare/v1.11.55...v1.11.56) (2026-06-13)


### Bug Fixes

* demo release-1 ([10c6557](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/10c6557d1c176aa2623f750961832598b8bb384d))

## [1.11.55](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/compare/v1.11.54...v1.11.55) (2026-06-13)


### Bug Fixes

* create release trigger for new prs ([b6c21c0](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/b6c21c04e5d7a9b98046dbe6995c8fd80cb93aac))
* release trigger workflows before testing bump to snapshot ([a77c447](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/a77c447595eaaaf981a01f2af50a47473c8097e1))
* test release to try auto bump child versions ([bd36d5e](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/bd36d5e72f7c99683913e880a42c2b3334254881))

## [1.11.54](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/compare/v1.11.53...v1.11.54) (2026-06-13)


### Bug Fixes

* first multi-module release test ([d0b0b02](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/d0b0b0209478060c667e0ccf5d1a2f432267a76c))
* regenerate release PR with module version correction ([74e7f36](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/74e7f36e24f0715ae6deeca345c637aa72ccb2e7))
* regenerate release PR with module version correction ([d7ae22a](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/d7ae22a6160ec5a7eb8d1d7a4509f1225d132bd8))
* restore child module versions from main and strip snapshots ([72cb79c](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/72cb79ca55ee87a994427521a8fb58d301ef7726))
* retry push of module snapshot cleanup commit ([6198b40](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/6198b40095740c20a84a098a895b01df204b85b7))
* retry release with corrected version script ([cb81592](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/cb81592dea338207bf71dea6a761614c60a64d15))
* retyring the release logic ([28c208a](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/28c208aa2845f79db97d0092e7f9e380337d0f52))
* to include both parent and child ([6dd2747](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/6dd27478aecc2fa53c3c3ebb6a444363f49c2f75))
* to include both parent and child ([832243c](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/832243c7c251b75e760e561eec2c70d379bed8de))
* trigger workflow to refresh release PR child versions ([9624569](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/9624569d58d5889200ec3847a85ea0854e80d06c))
* update release PR branch directly for module version correction ([214b144](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/214b14485da5c8baf3279f02f61d83dc66f99e37))
* use release-please outputs to correct child module versions ([26b6ce9](https://github.com/NBC-GPMF/cx-fum-mutimodule-test/commit/26b6ce96398f8e6061ee001cfb2d67bec55897a7))
