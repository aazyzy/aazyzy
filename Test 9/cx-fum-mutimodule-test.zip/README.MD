# api-schemas-wealth ##

OpenAPI 3.0.3 specifications and schemas for shared BNC Wealth Platform APIs (App 6900).

## Overview

This is a **contract-first, design-first** API schema project. It defines REST API contracts as OpenAPI YAML specifications and generates Java interfaces and DTOs at build time using the `openapi-generator-maven-plugin`. Downstream microservices consume the generated JAR artifacts and implement the interfaces.

**There is no hand-written Java source code** in this project.

## Architecture

```
OpenAPI YAML Specs (source of truth)
        |
        v
openapi-generator-maven-plugin (Spring generator)
        |
        v
Generated Java Interfaces + DTOs (JAR artifacts)
        |
        v
Downstream microservices implement the interfaces
```

## Technology Stack

| Component | Technology |
|---|---|
| Specification | OpenAPI 3.0.3 |
| Code Generator | openapi-generator-maven-plugin 6.4.0 |
| Runtime | Spring Boot 3, Jakarta EE |
| Java | 17 |
| Build | Maven |
| CI | Jenkins (`wealthPipeline()`) |

## Modules

| Module | Version | Description |
|---|---|---|
| [firm-data-schema](firm-data-schema/) | 1.10.64-SNAPSHOT | Firm data queries, search, and attestation management |
| [attestation-schema](attestation-schema/) | 0.0.1-SNAPSHOT | Attestation labels, source data, and workflows |
| [firm-management-schema](firm-management-schema/) | 1.12.36-SNAPSHOT | Firm lifecycle CRUD and whitelabel/branding |
| [user-configuration-schema](user-configuration-schema/) | 1.10.66-SNAPSHOT | User configuration, assignments, Okta, and NBX users |
| [user-management-schema](user-management-schema/) | 1.0.12-SNAPSHOT | User attestation generation, RR code validation, IIQ |
| [authorization-schema](authorization-schema/) | 1.13.29-SNAPSHOT | RBAC: capabilities, roles, permissions, groups, feature packages |
| [audit-management-schema](audit-management-schema/) | 1.0.22-SNAPSHOT | Audit record CRUD and user audit log retrieval |
| [bulk-user-config-schema](bulk-user-config-schema/) | 1.0.36-SNAPSHOT | Bulk CSV upload for user configurations |
| [bulk-user-migration-schema](bulk-user-migration-schema/) | 1.0.20-SNAPSHOT | Bulk user migration templates, forms, and reports |
| [bulk-management-schema](bulk-management-schema/) | 1.0.13-SNAPSHOT | Generic bulk operations: templates, batches, export |
| [user-policy-store-schema](user-policy-store-schema/) | 0.0.10-SNAPSHOT | User policy DTOs (identity, feature, data policies, provisioning) |

## Quick Start

### Prerequisites

- Java 17
- Maven 3.8+

### Build

```bash
# Build all modules
mvn clean install

# Build a specific module
mvn clean install -pl firm-data-schema
```

### Usage

Add the desired schema module as a dependency in your service project:

```xml
<dependency>
    <groupId>ca.nbc.gpmf.cx-fum-mutimodule-test</groupId>
    <artifactId>firm-data-schema</artifactId>
    <version>1.10.64-SNAPSHOT</version>
</dependency>
```

Then implement the generated interface in your Spring Boot controller:

```java
@RestController
public class FirmController implements FirmApi {
    @Override
    public ResponseEntity<Firm> getFirm(...) {
        // Your implementation
    }
}
```

## Project Structure

```
api-schemas-wealth/
├── .github/                           # Copilot design-first scaffolding
│   ├── copilot-instructions.md        # Workspace-wide project guidelines
│   ├── instructions/                  # File-specific instructions (auto-attached)
│   ├── prompts/                       # Reusable task templates (/add-endpoint, etc.)
│   ├── agents/                        # Custom agent modes (explorer, developer)
│   └── skills/                        # Multi-step workflows (/document-module)
├── firm-data-schema/                  # Firm data + attestation APIs
├── attestation-schema/                # Attestation APIs (standalone)
├── firm-management-schema/            # Firm management + whitelabel APIs
├── user-configuration-schema/         # User config + NBX + bulk user APIs
├── user-management-schema/            # User management + IIQ APIs
├── authorization-schema/              # Authorization/RBAC APIs
├── audit-management-schema/           # Audit + user audit log APIs
├── bulk-user-config-schema/           # Bulk user CSV upload API
├── bulk-user-migration-schema/        # Bulk migration APIs
├── bulk-management-schema/            # Generic bulk operation APIs
├── user-policy-store-schema/          # Policy store DTOs
├── pom.xml                            # Root aggregator POM
├── Jenkinsfile                        # CI pipeline
└── pipeline-config.yml                # Pipeline configuration
```

Each module follows the same internal structure:

```
<module>/
├── pom.xml
├── README.md
└── src/main/resources/
    ├── api/
    │   └── <name>-api.yaml            # OpenAPI specification (source of truth)
    └── schemas/
        ├── <Model>.yaml               # Data model definitions
        └── Responses.yaml             # Common response models
```

## Downstream Consumers (App 6900)

| Service | Schema Dependencies |
|---|---|
| user-configuration-api | authorization-schema, user-configuration-schema |
| authorization-api | authorization-schema |
| user-management-api | user-management-schema, authorization-schema |
| firm-api | firm-data-schema |
| attestation-api | attestation-schema |
| firm-management-api | firm-management-schema |
| audit-log-management-api | audit-management-schema |
| bulk-management-api | bulk-management-schema |
| bulk-user-migration-api | bulk-user-migration-schema, user-configuration-schema, audit-management-schema |
| commons-lib / commons-core | user-configuration-schema |
| fum-commons-lib | user-configuration-schema, bulk-management-schema |

## Copilot Integration

This project uses a `.github/` design-first scaffolding for Copilot:

| Type | Location | Purpose |
|---|---|---|
| Workspace Instructions | `.github/copilot-instructions.md` | Project-wide conventions (auto-loaded) |
| File Instructions | `.github/instructions/` | Auto-attached when editing YAML specs, schemas, POMs |
| Prompts | `.github/prompts/` | `/add-endpoint`, `/add-schema`, `/new-module`, `/review-spec` |
| Agents | `.github/agents/` | `schema-explorer` (read-only), `schema-developer` (edit + build) |
| Skills | `.github/skills/` | `/document-module` — generate/refresh module docs |

## Maven Coordinates

```xml
<groupId>ca.nbc.gpmf.cx-fum-mutimodule-test</groupId>
<artifactId>api-schemas-wealth</artifactId>
<version>1.11.52-SNAPSHOT</version>
```

Parent POM: `ca.bnc.wealth.maven.pom:root:3.0.3`
BOM: `ca.bnc.wealth.core:parent-pom-core:2.1.28`
