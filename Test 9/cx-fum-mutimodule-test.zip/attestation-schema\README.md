# attestation-schema

Attestation API Schema for the BNC Wealth Platform. Defines attestation label management, source data, firm attestation workflows, and file operations.

## Module Identity

| Property | Value |
|---|---|
| **ArtifactId** | `attestation-schema` |
| **Version** | `1.0.0-SNAPSHOT` |
| **GroupId** | `ca.bnc.wealth.common` |
| **Description** | Attestation API Schema |

## API Specifications

This module generates Java interfaces and DTOs from **1 OpenAPI spec**:

### Firm Attestation API (`attestation-api.yaml`)

Tag: `FirmAttestation` | Package: `ca.bnc.wealth.common.attestation`

| Method | Path | Summary |
|--------|------|---------|
| GET | `/attestations` | Get Attestation Labels |
| POST | `/attestations` | Create a new Attestation |
| GET | `/attestations/{attestation-id}` | Get Attestation by ID |
| PUT | `/attestations/{attestation-id}` | Update Attestation |
| DELETE | `/attestations/{attestation-id}` | Delete Attestation |
| GET | `/attestations/source/types` | Get Source Types |
| GET | `/attestations/files/{file-id}` | Get Source File |
| GET | `/attestations/source/files` | Get Source Files |
| GET | `/attestations/{attestation-id}/source/data` | Get Source Data by Attestation ID |
| GET | `/attestations/firms` | Get attestation by stage |
| PATCH | `/attestations/firms/{firm-attestation-id}` | Patch Firm Attestation |
| DELETE | `/attestations/firms/{firm-attestation-id}` | Delete Firm Attestation |
| GET | `/attestations/files` | Get attestation firm file |

## Schema Files

| File | Purpose |
|---|---|
| `Attestation.yaml` | Attestation models (labels, source data, firm attestation, create/update/patch requests) |
| `Responses.yaml` | Common response models (apiError, apiMessage, validationResult) |

## Code Generation Notes

- Generates with Lombok annotations: `@Builder`, `@NoArgsConstructor`, `@AllArgsConstructor`
- Includes Jackson annotations: `@JsonIgnoreProperties(ignoreUnknown = true)`, `@JsonInclude(NON_NULL)`
- Generated interface: `FirmAttestationApi.java`

## Downstream Consumers

- `attestation-api` (planned) — Future API service for attestation management

> **Note:** The same endpoints are also available in `firm-data-schema` for backward compatibility with the existing `firm-api` service.

## Usage

```xml
<dependency>
    <groupId>ca.nbc.gpmf.cx-fum-mutimodule-test</groupId>
    <artifactId>attestation-schema</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>
```

## Build

```bash
mvn clean install -pl attestation-schema
```
