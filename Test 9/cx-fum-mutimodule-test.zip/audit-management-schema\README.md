# audit-management-schema

Audit Management API Schema for the BNC Wealth Platform.

## Module Identity

| Property | Value |
|---|---|
| **ArtifactId** | `audit-management-schema` |
| **Version** | `1.0.23` |
| **GroupId** | `ca.bnc.wealth.common` |
| **Description** | Audit Management API Schema - NON CDM Model |

## API Specifications

This module generates Java interfaces and DTOs from **2 OpenAPI specs**:

### Audit Management API (`audit-management-api.yaml`)

Tag: `AuditManagement` | Package: `ca.bnc.wealth.common.audit_management`

| Method | Path | Summary |
|--------|------|---------|
| POST | `/audits` | Upload a new audit |
| GET | `/audits/{audit-id}` | Download audit contents |
| PUT | `/audits/{audit-id}` | Update audit contents |
| DELETE | `/audits/{audit-id}` | Delete audit record |
| HEAD | `/audits/{audit-id}` | Get audit metadata |
| GET | `/audits/{audit-id}/metadata` | Download audit metadata |

### User Audit Log Management API (`user-audit-management-api.yaml`)

Tag: `UserAuditLogManagement` | Package: `ca.bnc.wealth.common.user.audit_log`

| Method | Path | Summary |
|--------|------|---------|
| POST | `/user/audits` | Create user audit |
| GET | `/user/audits/{idp-subject}` | Get user audit by IDP Subject |
| GET | `/user/auditsDetails/{idp-subject}/{audit-details-type}` | Get user audit details |
| GET | `/user/auditHistory/{idp-subject}` | Get user audit history by IDP Subject |

## Schema Files

| File | Models | Purpose |
|---|---|---|
| `Audit.yaml` | `Audit` | Audit record model |
| `AuditEventDetails.yaml` | `AuditEventDetails` | Audit event details (property changed, old/new value) |
| `AuditHistory.yaml` | `AuditHistory` | User audit history record |
| `AuditHistoryDetails.yaml` | `AuditHistoryDetails` | Audit event detail history including type, attribute, and old/new values |
| `AuditLogEvent.yaml` | `AuditLogEvent`, `AuditLogEventSearchCriteria`, `AuditLogEventPage` | Audit log event model, search criteria, and paginated response |
| `AuditLogEventDetails.yaml` | `AuditLogEventDetails` | Detailed audit log event with nested event details |
| `Responses.yaml` | `ApiError`, `ApiMessage`, `ApiMessages` | Common response models |

## Downstream Consumers

- `audit-log-management-api` (`ca.bnc.wealth.api:audit-log-management-api`) - API to manage FUM audits
- `bulk-user-migration-api` (`ca.bnc.wealth.api:bulk-user-migration-api`) - API to support bulk user migration

## Usage

```xml
<dependency>
    <groupId>ca.nbc.gpmf.cx-fum-mutimodule-test</groupId>
    <artifactId>audit-management-schema</artifactId>
    <version>1.0.23</version>
</dependency>
```

## Build

```bash
mvn clean install -pl audit-management-schema
```
