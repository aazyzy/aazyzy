# authorization-schema

Authorization (RBAC) API Schema for the BNC Wealth Platform.

## Module Identity

| Property | Value |
|---|---|
| **ArtifactId** | `authorization-schema` |
| **Version** | `1.13.29-SNAPSHOT` |
| **GroupId** | `ca.bnc.wealth.common` |
| **Description** | Authorization API Schema - NON CDM Model |

## API Specification

This module generates Java interfaces and DTOs from **1 OpenAPI spec** with **6 API tags**:

### Authorization API (`authorization-api.yaml`)

Package: `ca.bnc.wealth.common.authorization`

#### Capability

| Method | Path | Summary |
|--------|------|---------|
| GET | `/access-control/capabilities` | Get all capabilities |
| POST | `/access-control/capabilities` | Create new capability |
| DELETE | `/access-control/capabilities/{capability}` | Delete capability |
| GET | `/access-control/capabilities/{capability}/scopes/me` | Get user's scopes |
| GET | `/access-control/capabilities/{capability}/roles/assignments/users/me` | Get user's roles |
| GET | `/access-control/capabilities/{capability}/permissions/assignments/users/me` | Get user's permissions |
| GET | `/access-control/capabilities/{capability}/permissions/assignments/users/me/{permission}` | Check specific permission |

#### RolePermission

| Method | Path | Summary |
|--------|------|---------|
| GET | `/access-control/capabilities/{capability}/roles` | Get all roles |
| POST | `/access-control/capabilities/{capability}/roles` | Create role |
| DELETE | `/access-control/capabilities/{capability}/roles/{role}` | Delete role |
| POST | `/access-control/capabilities/{capability}/roles/{role}/assignments/permission` | Add permission to role |
| DELETE | `/access-control/capabilities/{capability}/roles/{role}/assignments/permission` | Remove permission from role |
| POST | `/access-control/capabilities/{capability}/permissions` | Create permission |
| GET | `/access-control/capabilities/{capability}/permissions/{permission}` | Get permission |
| PATCH | `/access-control/capabilities/{capability}/permissions/{permission}` | Toggle permission |
| DELETE | `/access-control/capabilities/{capability}/permissions/{permission}` | Delete permission |

#### Resource

| Method | Path | Summary |
|--------|------|---------|
| GET | `/access-control/resources/{resource-type}/assignments/users/me` | Get user's resources |
| GET/DELETE/PATCH | `/access-control/resources/{resource-type}/{resource}` | CRUD resource |
| GET/POST | `/access-control/resources/{resource-type}` | List/Create resources |
| GET | `/access-control/resources/{resource-type}/assignments/firm/{rr-code}` | Get resources by firm |

#### Group

| Method | Path | Summary |
|--------|------|---------|
| GET/POST | `/access-control/groups` | List/Create groups |
| GET | `/access-control/groups/me` | Get my groups |
| DELETE/PUT | `/access-control/groups/{group}` | Delete/Update group |
| POST/DELETE | `/access-control/groups/{group}/assignments/role` | Assign/Remove role |

#### FeaturePackageTemplate

| Method | Path | Summary |
|--------|------|---------|
| GET/POST | `/access-control/features/packages/template` | List/Create templates |
| PATCH/DELETE | `/access-control/features/packages/template/{template}` | Update/Delete template |
| PUT | `/access-control/features/packages/template/{template}/resource` | Update template resources |

#### FeaturePackage

| Method | Path | Summary |
|--------|------|---------|
| POST | `/access-control/features/packages/package` | Create package |
| GET/DELETE/PATCH/PUT | `/access-control/features/packages/package/{package-id}` | CRUD package |

## Schema Files

| File | Purpose |
|---|---|
| `Authorization.yaml` | Core authorization models (Role, UserGroup, Resource, etc.) |
| `Enums.yaml` | ActionType, TemplateType enumerations |
| `FeaturePackage.yaml` | Feature package and template models |
| `Responses.yaml` | Common response models |

## Code Generation Notes

- Generates with Lombok annotations: `@Builder`, `@NoArgsConstructor`, `@AllArgsConstructor`
- Includes Jackson annotations: `@JsonIgnoreProperties(ignoreUnknown = true)`, `@JsonInclude(NON_NULL)`

## Downstream Consumers

- `user-configuration-api` - User configuration API
- `authorization-api` - Authorization API (validates roles and permissions)
- `user-management-api` - User management API

## Release Notes

### v1.8.0-SNAPSHOT
- Moved Authorization.User to common-lib/common-auth module

## Usage

```xml
<dependency>
    <groupId>ca.nbc.gpmf.cx-fum-mutimodule-test</groupId>
    <artifactId>authorization-schema</artifactId>
    <version>1.13.29-SNAPSHOT</version>
</dependency>
```

## Build

```bash
mvn clean install -pl authorization-schema
```
