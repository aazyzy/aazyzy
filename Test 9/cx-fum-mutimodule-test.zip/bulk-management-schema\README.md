# bulk-management-schema

Bulk Management API Schema for the BNC Wealth Platform.

## Module Identity

| Property | Value |
|---|---|
| **ArtifactId** | `bulk-management-schema` |
| **Version** | `1.0.13-SNAPSHOT` |
| **GroupId** | `ca.bnc.wealth.common` |
| **Description** | Bulk Management API Schema - NON CDM Model |

## API Specification

This module generates Java interfaces and DTOs from **1 OpenAPI spec**:

### Bulk Management API (`bulk-management-api.yaml`)

Tag: `BulkManagement` | Package: `ca.bnc.wealth.common.bulk_management`

| Method | Path | Summary |
|--------|------|---------|
| GET | `/templates/{name}` | Download template |
| POST | `/files/{template-name}` | Upload bulk file |
| POST | `/batches/trigger/{batch-id}` | Trigger bulk process |
| POST | `/batches/trigger/export/{template-name}` | Trigger export process |
| GET | `/batches/{batch-id}/status` | Get batch status |
| GET | `/batches/{batch-id}/file` | Download batch file |
| GET | `/batches/{batch-id}/results` | Download batch results |
| POST | `/batches/search` | Search batches |
| POST | `/update/status` | Update batch status |

## Schema Files

| File | Purpose |
|---|---|
| `BulkManagement.yaml` | Batch models (BatchesSearchRequest/Response, ExportRequest, Filter, etc.) |
| `Responses.yaml` | Common response models (ApiError, ApiMessage, ApiMessages) |

## Generated Models

- `BatchStatus` - Batch operation status
- `BatchesSearchRequest` / `BatchesSearchResponse` / `BatchesSearchResponseRecord` - Batch search
- `ExportRequest` - Data export request
- `Filter` - Filter criteria for batch queries
- `UpdateStatusRequest` - Batch status update

## Downstream Consumers

- `bulk-management-api` (`ca.bnc.wealth.api:bulk-management-api`) - API to support bulk management
- `fum-commons-lib / commons-bma` (`ca.bnc.wealth.common:commons-bma`) - Bulk Management Abstraction library

## Usage

```xml
<dependency>
    <groupId>ca.nbc.gpmf.cx-fum-mutimodule-test</groupId>
    <artifactId>bulk-management-schema</artifactId>
    <version>1.0.13-SNAPSHOT</version>
</dependency>
```

## Build

```bash
mvn clean install -pl bulk-management-schema
```
