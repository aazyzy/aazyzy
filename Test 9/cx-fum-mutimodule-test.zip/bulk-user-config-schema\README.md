# bulk-user-config-schema

Bulk User Configuration API Schema for the BNC Wealth Platform.

## Module Identity

| Property | Value |
|---|---|
| **ArtifactId** | `bulk-user-config-schema` |
| **Version** | `1.0.36-SNAPSHOT` |
| **GroupId** | `ca.bnc.wealth.common` |
| **Description** | Bulk User Configuration API Schema - NON CDM Model |

## API Specification

This module generates Java interfaces and DTOs from **1 OpenAPI spec**:

### Bulk User Configuration API (`bulk-user-config-api.yaml`)

Tag: `BulkUserConfiguration`
- API Package: `ca.bnc.wealth.common.user.upload.api`
- Model Package: `ca.bnc.wealth.common.bulk.userconfig.model`

| Method | Path | Summary |
|--------|------|---------|
| POST | `/bulk/upload/{forTemplate}` | Upload bulk user CSV file |
| POST | `/bulk/operation/{uploadId}` | Execute bulk upload action |
| GET | `/bulk/operation/status/{bulkOperationId}` | Get bulk operation status |
| GET | `/bulk/upload/status/{bulkUploadId}` | Get bulk upload status |
| GET | `/bulk/status/download/{bulkUploadId}` | Download status for uploaded file |
| POST | `/bulk/upload/{forTemplate}/history` | Get bulk history by template |

## Schema Files

| File | Purpose |
|---|---|
| `BulkHistory.yaml` | Bulk history and upload models (BulkHistoryRequest/Response, BulkUpload, BulkActionRequest) |
| `Responses.yaml` | Common response models (ApiError, ApiMessage, ApiMessages) |

## Generated Models

- `BulkActionRequest` - Request for a bulk action
- `BulkHistoryRequest` / `BulkHistoryResponse` - Bulk operation history
- `BulkUpload` - Bulk upload data model

## Downstream Consumers

No external consumers found in the local codebase.

## Release Notes

### v1.0.0-SNAPSHOT
- Added bulk user config

## Usage

```xml
<dependency>
    <groupId>ca.nbc.gpmf.cx-fum-mutimodule-test</groupId>
    <artifactId>bulk-user-config-schema</artifactId>
    <version>1.0.36-SNAPSHOT</version>
</dependency>
```

## Build

```bash
mvn clean install -pl bulk-user-config-schema
```
