# bulk-user-migration-schema

Bulk User Migration API Schema for the BNC Wealth Platform.

## Module Identity

| Property | Value |
|---|---|
| **ArtifactId** | `bulk-user-migration-schema` |
| **Version** | `1.0.20-SNAPSHOT` |
| **GroupId** | `ca.bnc.wealth.common` |
| **Description** | Bulk User Migration API Schema - NON CDM Model |

## API Specification

This module generates Java interfaces and DTOs from **1 OpenAPI spec**:

### Bulk User Migration API (`bulk-user-migration-api.yaml`)

Tag: `BulkUserMigration` | Package: `ca.bnc.wealth.common.bulk_user_migration`

| Method | Path | Summary |
|--------|------|---------|
| GET | `/templates/{template-format}` | Download migration template |
| POST | `/templates/{template-format}` | Upload filled migration template |
| GET | `/forms/{form-id}` | Download migration form |
| POST | `/migrations` | Trigger migration process |
| GET | `/migrations/{migration-id}` | Get migration progress |
| GET | `/reports` | Download migration reports list |
| GET | `/reports/{migration-id}` | Download migration report |
| GET | `/reports/{migration-id}/metadata` | Download report metadata |
| GET | `/user/report` | Download user report |
| POST | `/user/report` | Download user report (POST) |

## Schema Files

| File | Purpose |
|---|---|
| `BulkUserMigration.yaml` | Migration report models |
| `DownloadUserReport.yaml` | User report download request model |
| `Responses.yaml` | Common response models (ApiError, ApiMessage, ApiMessages) |

## Generated Models

- `DownloadUserReportRequest` - Request to download a user migration report
- `MigrationReportMetadataResponse` - Metadata about a migration report
- `MigrationReportResponse` - Migration report response

## Downstream Consumers

- `bulk-user-migration-api` (`ca.bnc.wealth.api:bulk-user-migration-api`) - API to support bulk user migration

## Usage

```xml
<dependency>
    <groupId>ca.nbc.gpmf.cx-fum-mutimodule-test</groupId>
    <artifactId>bulk-user-migration-schema</artifactId>
    <version>1.0.20-SNAPSHOT</version>
</dependency>
```

## Build

```bash
mvn clean install -pl bulk-user-migration-schema
```
