# firm-data-schema

Firm Data API Schema for the BNC Wealth Platform. Defines firm data queries, search, and assignments.

## Module Identity

| Property | Value |
|---|---|
| **ArtifactId** | `firm-data-schema` |
| **Version** | `1.10.64-SNAPSHOT` |
| **GroupId** | `ca.bnc.wealth.common` |
| **Description** | Firm API Schema - NON CDM Model |

## API Specifications

This module generates Java interfaces and DTOs from **1 OpenAPI spec**:

### Firm API (`firm-api.yaml`)

Tag: `Firm` | Package: `ca.bnc.wealth.common.firm`

| Method | Path | Summary |
|--------|------|---------|
| GET | `/firms/assignments/users/me` | Get the firm associated to the user |
| POST | `/firms/firmSearch` | Get firm details by search text |
| POST | `/firms/search` | Search for a firm |
| POST | `/firms/genericSearch` | Get firm details by search text |
| POST | `/firms/genericSearchWithPagination` | Get firm details (paginated) |
| PUT | `/firms/{firm-id}/assignments/feature-package` | Assign Feature Package to firm |
| PUT | `/firms/{firm-id}/assignments/rr-range` | Assign RR codes to a firm |
| GET | `/firms/{firm-id}/assignments` | Get assignments by firm ID |
| DELETE | `/firms/{firm-id}/assignments/{assignment-type}/{assignee-id}` | Delete firm assignment |

## Schema Files

| File | Purpose |
|---|---|
| `Firm.yaml` | Core firm data model |
| `Enums.yaml` | FirmType, AssignmentType, FirmAssignmentType enumerations |
| `AssignedResource.yaml` | Assigned resource model |
| `FeaturePackageAssignment.yaml` | Feature package assignment to firm |
| `FirmSearch.yaml` | Firm search criteria model |
| `FirmUpdate.yaml` | Firm update model |
| `Responses.yaml` | Common response models |
| `RRCodeRange.yaml` | RR code range model |
| `SearchPayload.yaml` | Generic search payload model |
| `UpdateRRCodeRange.yaml` | RR code range update request |

## Code Generation Notes

- Generates with Lombok annotations: `@Builder`, `@NoArgsConstructor`, `@AllArgsConstructor`
- Includes Jackson annotations: `@JsonIgnoreProperties(ignoreUnknown = true)`, `@JsonInclude(NON_NULL)`

## Downstream Consumers

- `firm-api` (`ca.bnc.wealth.api:firm-conf-api`) - API to get Firm configuration details related to User

## Release Notes

### v1.8.0-SNAPSHOT
- Renamed fields in Firm Response
- Renamed From/To B36 to B10

## Usage

```xml
<dependency>
    <groupId>ca.nbc.gpmf.cx-fum-mutimodule-test</groupId>
    <artifactId>firm-data-schema</artifactId>
    <version>1.10.64-SNAPSHOT</version>
</dependency>
```

## Build

```bash
mvn clean install -pl firm-data-schema
```
