# firm-management-schema

Firm Management API Schema for the BNC Wealth Platform. Defines firm lifecycle CRUD and whitelabel/branding operations.

## Module Identity

| Property | Value |
|---|---|
| **ArtifactId** | `firm-management-schema` |
| **Version** | `1.12.36-SNAPSHOT` |
| **GroupId** | `ca.bnc.wealth.common` |
| **Description** | Firm API Schema - NON CDM Model |

## API Specifications

This module generates Java interfaces and DTOs from **2 OpenAPI specs**:

### Firm Management API (`firm-management-api.yaml`)

Tag: `FirmManagement` | Package: `ca.bnc.wealth.common.firm`

| Method | Path | Summary |
|--------|------|---------|
| POST | `/firms` | Create a new firm |
| GET | `/firms/{firm-id}` | Get firm details |
| PUT | `/firms/{firm-id}` | Update an existing firm |
| PATCH | `/firms/{firm-id}` | Update firm active status |
| DELETE | `/firms/{firm-id}` | Decommission firm |
| GET | `/firms/{firm-id}/featurePackage/update/status` | Get feature package update status |
| POST | `/firms/{firm-id}/validate/rr-codes` | Validate RR codes by firm id |
| POST | `/firms/search` | Fetch firms by rep codes |

### Firm Whitelabel API (`firm-whitelabel-api.yaml`)

Tag: `FirmWhitelabel` | Package: `ca.bnc.wealth.common.firm`

| Method | Path | Summary |
|--------|------|---------|
| POST | `/upload/{firmId}/image` | Upload image for firm |
| POST | `/download/{firmId}/image` | Download image for firm |
| GET | `/platform/{firmId}/config` | Get whitelabel config |
| POST | `/platform/{firmId}/config` | Add whitelabel config |
| PUT | `/platform/{firmId}/config` | Update whitelabel config |
| DELETE | `/platform/{firmId}/config` | Delete whitelabel config |

## Schema Files

| File | Purpose |
|---|---|
| `Firm.yaml` | Firm details and management models |
| `FirmInput.yaml` | Firm creation/update input model |
| `Enums.yaml` | FirmType enumeration |
| `FeaturePackage.yaml` | Feature package model |
| `FeaturePackageUpdateStatus.yaml` | Feature package update status |
| `FirmResource.yaml` | Whitelabel resource models (Brand, LogoUrl) |
| `Responses.yaml` | Common response models |
| `RRCode.yaml` | Individual RR code model |
| `RRCodeRange.yaml` | RR code range model |

## Code Generation Notes

- Generates with Lombok annotations: `@Builder`, `@NoArgsConstructor`, `@AllArgsConstructor`
- Includes Jackson annotations: `@JsonIgnoreProperties(ignoreUnknown = true)`, `@JsonInclude(NON_NULL)`
- Two separate generator executions share the same Java package

## Downstream Consumers

- `firm-management-api` (`ca.bnc.wealth.api:firm-management-api`) - API to manage firms

## Usage

```xml
<dependency>
    <groupId>ca.nbc.gpmf.cx-fum-mutimodule-test</groupId>
    <artifactId>firm-management-schema</artifactId>
    <version>1.12.36-SNAPSHOT</version>
</dependency>
```

## Build

```bash
mvn clean install -pl firm-management-schema
```
