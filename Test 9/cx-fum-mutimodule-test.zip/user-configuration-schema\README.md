# user-configuration-schema

User Configuration API Schema for the BNC Wealth Platform. The largest module by scope, covering user configuration, assignments, Okta integration, NBX users, and bulk user operations.

## Module Identity

| Property | Value |
|---|---|
| **ArtifactId** | `user-configuration-schema` |
| **Version** | `1.10.67-SNAPSHOT` |
| **GroupId** | `ca.bnc.wealth.common` |
| **Description** | User Configuration API Schema - NON CDM Model |

## API Specifications

This module generates Java interfaces and DTOs from **4 OpenAPI specs** (most of any module):

### User Configuration API (`user-configuration-api.yaml`)

Tags: `UserConfiguration`, `Validation` | Package: `ca.bnc.wealth.common.userconfiguration`

Key endpoints (45 total):

| Method | Path | Summary |
|--------|------|---------|
| GET | `/users/me` | Get current user configuration |
| POST | `/users` | Create new user configuration |
| GET | `/users/{userConfigurationId}` | Get user by id |
| PUT | `/users/{userConfigurationId}` | Update user configuration |
| PATCH | `/users/{userConfigurationId}` | Activate/Deactivate user |
| DELETE | `/users/{userConfigurationId}` | Delete user configuration |
| POST | `/users/search` | Search user configurations |
| POST | `/users/genericSearchWithPagination` | Paginated user search |
| PUT | `/users/{userConfigurationId}/assignments/rr-range` | Assign RR Ranges |
| PUT | `/users/{userConfigurationId}/assignments/feature-package` | Assign feature package |
| PUT | `/users/{userConfigurationId}/assignments/firm` | Assign firm |
| PUT | `/users/{userConfigurationId}/assignments/user-group` | Assign user group |
| POST | `/users/{userConfigurationId}` | Update user configuration (POST) |
| POST | `/users/list` | Get user configurations by user IDs |
| GET | `/users/{userId}/oktaProfile` | Get Okta profile |
| PUT | `/users/{userId}/suspend` | Suspend user |
| PUT | `/users/{userId}/unsuspend` | Unsuspend user |
| POST | `/users/oktaStatusSync` | Sync Okta status |
| POST | `/validate/generate/userCredentials` | Generate credentials |
| GET | `/users/download` | Download user data |

### UAMA User Configuration API (`uama-user-configuration-api.yaml`)

Tag: `UamaUserConfiguration` | Package: `ca.bnc.wealth.common.userconfiguration`

| Method | Path | Summary |
|--------|------|---------|
| PUT | `/uama/{idp-subject}/groups/{group-name}` | Update user group by IDP subject |
| DELETE | `/uama/{idp-subject}/groups/{group-name}` | Delete user group by IDP subject |
| GET | `/uama/{external-system-id}/{external-user-id}` | Get user by external system/user ID |
| GET | `/uama/{idp-subject}/{external-system-id}` | Get users by IDP subject and external system ID |
| PUT | `/uama/{idp-subject}/{external-system-id}` | Update external system config by IDP subject |

### NBX User Configuration API (`nbx-user-configuration-api.yaml`)

Tag: `NbxUserConfiguration` | Package: `ca.bnc.wealth.common.userconfiguration`

| Method | Path | Summary |
|--------|------|---------|
| POST | `/nbx-users` | Create NBX user |
| PUT | `/nbx-users/{userId}` | Update NBX user |
| POST | `/nbx-users/search` | Search NBX users |

### Bulk User Configuration API (`bulk-user-configuration-api.yaml`)

Tag: `BulkUserConfiguration` | Package: `ca.bnc.wealth.common.userconfiguration`

| Method | Path | Summary |
|--------|------|---------|
| PUT | `/upload/update` | Create bulk user configuration |

## Schema Files

| File | Purpose |
|---|---|
| `UserConfiguration.yaml` | Core user configuration model |
| `UserListResponse.yaml` | Paginated user list response |
| `UserAssignment.yaml` | User assignment model |
| `AssignRequest.yaml` | Assignment request model |
| `NbxUserConfiguration.yaml` | NBX-specific user configuration model |
| `FeaturePackage.yaml` | Feature package model in user context |
| `GenericSearch.yaml` | Generic search request/filter/response models |
| `BulkActionResponse.yaml` | Bulk action response |
| `MessageDetail.yaml` | Message detail model |
| `OktaStatusSyncRequest.yaml` | Okta sync request |
| `UamaUserConfiguration.yaml` | UAMA user configuration and external ID models |
| `Page.yaml` | Pagination model |
| `Responses.yaml` | Common response models |
| `RRCodeRange.yaml` | RR code range |
| `RRRange.yaml` | RR range definition |

## Code Generation Notes

- Generates with Lombok annotations: `@Builder`, `@NoArgsConstructor`, `@AllArgsConstructor`
- Includes Jackson annotations: `@JsonIgnoreProperties(ignoreUnknown = true)`, `@JsonInclude(NON_NULL)`
- Four separate generator executions share the same Java package

## Downstream Consumers

- `user-configuration-api` (`ca.bnc.wealth.api:user-configuration-api`) - User configuration API
- `commons-lib / commons-core` (`ca.bnc.wealth.core:commons-core`) - Commons library
- `bulk-user-migration-api` (`ca.bnc.wealth.api:bulk-user-migration-api`) - Bulk migration API
- `fum-commons-lib` parent + `commons-fum-utils` + `commons-r2` - FUM utility libraries

## Release Notes

### v1.8.0-SNAPSHOT
- Renamed fields in Firm Response
- Renamed From/To B36 to B10

### v1.8.1-SNAPSHOT
- Added search by userConfigurationId endpoint

## Usage

```xml
<dependency>
    <groupId>ca.nbc.gpmf.cx-fum-mutimodule-test</groupId>
    <artifactId>user-configuration-schema</artifactId>
    <version>1.10.67-SNAPSHOT</version>
</dependency>
```

## Build

```bash
mvn clean install -pl user-configuration-schema
```
