# user-management-schema

User Management API Schema for the BNC Wealth Platform. Defines user attestation generation, RR code validation, and IIQ (Identity IQ) integration.

## Module Identity

| Property | Value |
|---|---|
| **ArtifactId** | `user-management-schema` |
| **Version** | `1.0.12-SNAPSHOT` |
| **GroupId** | `ca.bnc.wealth.common` |
| **Description** | User Management API Schema - NON CDM Model |

## API Specifications

This module generates Java interfaces and DTOs from **2 OpenAPI specs**:

### User Management API (`user-management-api.yaml`)

Tag: `UserManagement`
- API Package: `ca.bnc.wealth.common.user_management.api`
- Model Package: `ca.bnc.wealth.common.user_management.model`

| Method | Path | Summary |
|--------|------|---------|
| POST | `/attestation/{attestationId}/{firmId}` | Generate attestation file for firm |
| POST | `/attestation/{attestationId}` | Generate attestation file |
| POST | `/users/checkAccess` | Validate RR code access |

### IIQ User Management API (`user-management-iiq-api.yaml`)

Tag: `IiqUserManagement`
- API Package: `ca.bnc.wealth.common.user_management.api`
- Model Package: `ca.bnc.wealth.common.user.user_management.model`

| Method | Path | Summary |
|--------|------|---------|
| GET | `/iiq/users` | Get IIQ Users (paginated) |
| POST | `/iiq/users` | Create IIQ User |
| GET | `/iiq/users/{userId}` | Get IIQ User by id |
| PUT | `/iiq/users/{userId}` | Update IIQ User |
| GET | `/iiq/users/accessGroups` | Get IIQ User Access Groups |

## Schema Files

| File | Purpose |
|---|---|
| `UserManagement.yaml` | User management models |
| `Attestation.yaml` | Attestation-related models |
| `IiqUserConfiguration.yaml` | IIQ user configuration and access group models |
| `Responses.yaml` | Common response models |
| `RRCode.yaml` | RR code model |
| `RRCodeRange.yaml` | RR code range model |

## Generated Models

- `RRCodeAccess` - RR code access validation result
- `ValidateRRCodeRequest` - RR code validation request
- `AccessGroup` - IIQ access group definition
- `IiqUserConfiguration` - IIQ user configuration
- `IiqUserAccessGroups` - IIQ user access groups
- `IiqGenericSearchResponse` - IIQ paginated search response

## Downstream Consumers

- `user-management-api` (`ca.bnc.wealth.api:user-management-api`) - API to manage users

## Usage

```xml
<dependency>
    <groupId>ca.nbc.gpmf.cx-fum-mutimodule-test</groupId>
    <artifactId>user-management-schema</artifactId>
    <version>1.0.12-SNAPSHOT</version>
</dependency>
```

## Build

```bash
mvn clean install -pl user-management-schema
```
