# user-policy-store-schema

User Policy Store Schema for the BNC Wealth Platform. Defines DTOs for user policies including identity profiles, feature policies, data policies, and provisioning.

## Module Identity

| Property | Value |
|---|---|
| **ArtifactId** | `user-policy-store-schema` |
| **Version** | `0.0.10-SNAPSHOT` |
| **GroupId** | `ca.bnc.wealth.common` |
| **Description** | User Policy API Schema - NON CDM Model |

## API Specification

This module generates Java DTOs from **1 OpenAPI spec**:

### User Policy Store API (`user-policy-store-api.yaml`)

Package: `ca.bnc.wealth.common.policystore`

This module uses a `/dummy` POST endpoint solely to trigger OpenAPI model generation. It is primarily a **DTO library** -- the API interface is not intended to be implemented directly.

## Schema Files

| File | Purpose |
|---|---|
| `application-preferences.yaml` | Application-level user preferences model |
| `components.yaml` | Shared component definitions |
| `data-policy.yaml` | Data access policy model |
| `feature-policy.yaml` | Feature access policy model |
| `identity-profile.yaml` | User identity profile model |
| `provisioning-request.yaml` | User provisioning request model |
| `provisioning-response.yaml` | Provisioning result model |
| `system-settings.yaml` | System settings models (Okta, OSS, R2, SZ, CX) |

## Generated Models

- `ApplicationPreferences` - Application-level preferences for a user
- `DataPolicy` - Data access policy definition
- `FeaturePolicy` - Feature access policy definition
- `IdentityProfile` - User identity profile
- `ProvisioningRequest` / `ProvisioningResponse` - User provisioning
- `StoreRequest` - Composite request to store policy data
- `SystemSettings` - System-level settings
- `SystemSettingsCx` - CompassX-specific settings
- `SystemSettingsOkta` - Okta-specific settings
- `SystemSettingsOss` - OSS-specific settings
- `SystemSettingsR2` - R2-specific settings
- `SystemSettingsSz` - SZ-specific settings
- `RrCodeRange` - RR code range for policy store

## Code Generation Notes

- Generates with Lombok annotations: `@Builder`, `@NoArgsConstructor`, `@AllArgsConstructor`
- Includes Jackson annotations: `@JsonIgnoreProperties(ignoreUnknown = true)`, `@JsonInclude(NON_NULL)`
- No security schemes defined (unlike other modules)

## Downstream Consumers

No external consumers found in the local codebase.

## Usage

```xml
<dependency>
    <groupId>ca.nbc.gpmf.cx-fum-mutimodule-test</groupId>
    <artifactId>user-policy-store-schema</artifactId>
    <version>0.0.10-SNAPSHOT</version>
</dependency>
```

## Build

```bash
mvn clean install -pl user-policy-store-schema
```
