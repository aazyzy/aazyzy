# Changelog

## [5.0.2](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/compare/v5.0.1...v5.0.2) (2026-11-20)


### Bug Fixes

* trigger 5.0.2 release ([d1c3733](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/d1c3733e8cd31afcb6f357ae6d659625a1ea82db))

## [5.0.1](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/compare/v5.0.0...v5.0.1) (2026-11-02)


### Miscellaneous Chores

* move to parent-pom-core 3.0.1, which fixes the Snyk findings of the 5.0.0 release: Tomcat 11.0.27, Jackson 3.2.4 and 2.22.4, Hibernate Validator 9.1.6.Final and java-jwt 4.6.2

## [5.0.0](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/compare/v4.0.3...v5.0.0) (2026-10-29)


### Miscellaneous Chores

* align develop versions with main after the 4.0.1 release ([#96](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/pull/96)) ([0f5d525](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/0f5d5257147e4f0663cf3e27a0c6ff6a4a7f89cc))
* move user-configuration-api to Spring Boot 4.1.1 in develop ([#100](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/pull/100)) ([1704c70](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/1704c7026cba274cd11e8d58df179dc7b9175a45))
* NBINEN-12500 Skip compass R2 id lookup when isSzOnly is true ([#98](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/pull/98)) ([9304fd8](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/9304fd8c26ee0e5e64e24299dea28551d3e87d23))
* NWPI-15023: Adding secondary user group to Okta ([#105](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/pull/105)) ([a7a01bd](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/a7a01bd0b244da79081c750a4dd31843b07cece7))
* skip Sonar in the release workflow and declare the parent first ([#114](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/pull/114)) ([98dbcbe](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/98dbcbe2c224398338124242e3096a81dc11bba4))
* skip the SonarQube analysis for now ([#112](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/pull/112)) ([90cbe0b](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/90cbe0b95d18336c15223953714cfbf6f1453c20))
* stop returning and logging user creation passwords and the CIAM token ([#97](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/pull/97)) ([e3eaf29](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/e3eaf29c1bc022d8ee56cfa572ef4962ffa5aa54))
* sync 6900 dependency versions to develop SNAPSHOTs ([#113](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/pull/113)) ([b2b2d69](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/b2b2d699898b2c0ca41076e20d9d1ce98298af13))
* Test branch ([#110](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/pull/110)) ([bc67aaf](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/bc67aafae85d08b3f755b2c5bff6005c2f624a63))
* testing jira ticket link ([#111](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/pull/111)) ([69b9158](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/69b91580eead2d1e0c05feafc74265290837097c))

## [4.0.3](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/compare/v4.0.2...v4.0.3) (2026-10-20)


### Miscellaneous Chores

* use fum-commons-lib 1.0.81 so Feign clients log at BASIC ([#106](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/issues/106)) ([e555120](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/e5551201aeb9e35c553848b71c603f8fb4979068))

## [4.0.2](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/compare/v4.0.1...v4.0.2) (2026-10-19)


### Miscellaneous Chores

* stop returning and logging user creation passwords and the CIAM token ([#101](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/issues/101)) ([f7d3ba1](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/f7d3ba1b85d002f688b5e7e4786965082a7df360))

## [4.0.1](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/compare/v4.0.0...v4.0.1) (2026-10-14)


### Miscellaneous Chores

* remediate Snyk vulnerabilities on the 4.0 release line ([#93](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/issues/93)) ([13274ba](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/13274ba29da1da1527ff8c4ee1da1dbbeb09e3b8))

## [4.0.0](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/compare/v3.2.5...v4.0.0) (2026-10-14)


### Miscellaneous Chores

* gate UAMA SecureZone calls behind userConfiguration.uama.enable ([0fcfcd4](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/0fcfcd42d2da2a48fb6e7bc44ba149204e3b3f48))
* NWPI-14844 restore calling UAMA when updating user sz ([624aa6c](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/624aa6cd3d16a09f74826826b5a4d4b8900039d6))
* NWPI-15087 hide decommissioned accounts from the user-admin search ([c0b28a0](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/c0b28a0600008d2a813b813e30f8a1b763826a87))
* NWPI-15118 validate the Compass R2 id ([1b8170a](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/1b8170a97d781d182de5818fba8dd875eeaaeb3d))
* NWPI-15023 external-account creation refactor, without the special user-group assignment ([145a55c](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/145a55cc20fb41be69706fcd4806144621cda227), [7ca425a](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/7ca425a476ca22a8e373aabc1e5f8617a4397d79))
* pin released 6900 dependency versions for release 4.0.0: commons-lib 2.1.42 (NWPI-15097), api-schemas-wealth 1.11.58 ([5c6c4a7](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/5c6c4a7d3f146e38f35970c01085ed5bcd4b3869))

## [3.2.5](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/compare/v3.2.4...v3.2.5) (2026-09-29)


### Miscellaneous Chores

* NWPI-15118 skip R2 validation for a blank Compass R2 id ([5dec078](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/5dec078e6269da7f1e1aa59611416735079e61a1))

## [3.2.4](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/compare/v3.2.3...v3.2.4) (2026-09-27)


### Miscellaneous Chores

* only decommission on a terminal okta status, and make the lifecycle calls idempotent ([9e4e0ff](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/9e4e0ffd5f0d2fc1b5b78c398bd522e6def2d0d8))

## [3.2.3](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/compare/v3.2.2...v3.2.3) (2026-09-26)


### Miscellaneous Chores

* keep decommissioned accounts out of the okta state sync ([a64f8c7](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/a64f8c79c924b00ce86d6c3b7a6b89e0a2be96b7))

## [3.2.2](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/compare/v3.2.1...v3.2.2) (2026-09-25)


### Miscellaneous Chores

* release 3.2.2 ([f1ae9dd](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/f1ae9dd7b95563d0df55b1020d001a9990258a68))

## [3.2.1](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/compare/v3.2.0...v3.2.1) (2026-09-22)


### Miscellaneous Chores

* release 3.2.1 ([#63](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/issues/63)) ([096e1c5](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/096e1c56f385820a1bb8e07934a3eaff7310921a))

## [3.2.0](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/compare/v3.0.0...v3.2.0) (2026-09-16)


### Bug Fixes

* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([e39f8fc](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/e39f8fc852ab6b56190d2cab74b01a8c8963d6a0))
* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([2d9977a](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/2d9977ac71f9c8eb4e9ceae8e95e8846b760b0f9))
* remediate Snyk vulnerabilities (run 2026-09-15) ([b7c9e66](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/b7c9e669cd3cdc1626f937f9fa6ef06724f72b4d))


### Miscellaneous Chores

* pin released 6900 dependency versions for release 3.2.0 ([b346e21](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/b346e214dc9e5b3511230d65761805896011ddc8))

## [3.0.0](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/compare/v2.2.3...v3.0.0) (2026-08-19)


### Miscellaneous Chores

* release 3.0.0 ([ebaf660](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/ebaf660e91960011c632eec20023fedc23c66f51))

## [2.2.3](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/compare/v2.2.2...v2.2.3) (2026-08-19)


### Bug Fixes

* **deps:** pin at.yawk.lz4:lz4-java 1.11.1 for CVE-2026-59949 ([#34](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/issues/34)) ([07f9128](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/07f9128b6d061e5d9bd62b995ec756bcfd3d82b6))
* **deps:** pin at.yawk.lz4:lz4-java 1.11.1 for CVE-2026-59949 ([#35](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/issues/35)) ([f417bb9](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/f417bb95d7ee80e08f8545319ed452d7336c0b0d))
* **deps:** pin tomcat-embed 10.1.56 and logback-core 1.5.36 (Snyk HIGH) ([#22](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/issues/22)) ([ae60761](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/ae60761f7c301a493b6ab5fdc4bf307f4532447e))
* **deps:** pin vulnerable transitive dependencies for Snyk remediation ([a7fbfdd](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/a7fbfddffd754090937d13dbd904faf5a15c68ee))

## [2.2.2](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/compare/v2.2.1...v2.2.2) (2026-06-29)


### Bug Fixes

* release 2.2.1. ([826bcda](https://github.com/NBC-GPMF/cx-fum-user-configuration-api/commit/826bcda11c731992d7162ac74505a0b0d3c40ce1))
