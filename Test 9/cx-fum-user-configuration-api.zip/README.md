# User Configuration API ###

Spring Boot service for CompassX user configuration management, assignment workflows, identity synchronization, and user-related eventing.

## Service Summary

- Artifact: `user-configuration-api`
- Group: `ca.nbc.gpmf.cx-fum-user-configuration-api`
- Java: `17`
- Runtime context path: `/user-conf`
- Default server port: `8081`
- Main class: `ca.bnc.wealth.api.userconfiguration.Application`

## Key Capabilities

- User configuration create, read, update, and delete flows
- Assignment management (firm, package/role, group, resource, RR range)
- User preference and language updates
- User state transitions and identity status synchronization
- Okta integration (profile read/update, suspend/unsuspend, reset password, 2FA reset)
- R2 integration and profile consistency checks
- NBX-specific create/update/search workflows
- Bulk user update processing
- Generic and materialized-view-backed user search
- CSV extract generation for user data
- Kafka-based user configuration and audit event handling

## API Layer

Controllers implement generated shared interfaces from schema modules:

- `UserConfigurationController` -> `UserConfigurationApi`
- `NbxUserConfigurationController` -> `NbxUserConfigurationApi`
- `BulkUserConfigurationController` -> `BulkUserConfigurationApi`
- `UserValidationController` -> `ValidationApi`

This keeps endpoint contracts aligned with common schema libraries and reduces controller/API drift.

## Architecture Notes

- Validation: business and field-level checks are centralized in `UserConfigValidationService`.
- Persistence: the service uses both Spring Data JPA and JDBC template queries for high-traffic or specialized paths.
- Search: many read/search operations rely on a materialized view for performance.
- Refresh: write operations commonly trigger materialized view refresh through `UserConfigSearchMaterializedRefreshService`.
- Audit: critical create/update/delete flows are wrapped with audit publication logic.
- Eventing: Kafka producers and consumers are used for user-config and sync-ack processing.

## Configuration

Primary config file:

- `src/main/resources/application.yml`

Notable runtime config from `application.yml`:

- `server.servlet.context-path=/user-conf`
- `server.port=8081`
- Management endpoints under `/manage` (health, info)
- Kafka producer/consumer topics parameterized by environment

### Required Environment Variables

At minimum, set these for local execution:

- `KAFKA_API_KEY`
- `KAFKA_API_SECRET`
- `KAFKA_ENV`

If your environment requires additional secrets (database, OAuth/JWT, Feign targets, Redis, etc.), provide them through your local config source or platform secret manager.

## Build, Test, Run

From repository root:

```bash
./mvnw clean verify
```

Run locally:

```bash
./mvnw spring-boot:run \
	-Dspring-boot.run.jvmArguments="-Dspring.config.additional-location=/absolute/path/to/application-local.yml"
```

Run unit tests only:

```bash
./mvnw test
```

Package executable jar:

```bash
./mvnw clean package
```

## Project Layout

- `src/main/java/.../controller`: API controllers
- `src/main/java/.../service`: business logic and integrations
- `src/main/java/.../dao` and `.../jpa`: query and persistence layers
- `src/main/java/.../kafka`: producers and consumers
- `src/main/resources/application.yml`: service configuration
- `.github/workflows`: CI/CD pipelines

## Operational Guidance

- Prefer updating shared schema contracts first when endpoint signatures change.
- Keep NBIN and external SSO user flows isolated; they have different validation and state behaviors.
- Review audit behavior when adding new mutation endpoints.
- Re-check materialized-view refresh implications for any write-path optimization.
- Keep secrets out of committed config files.

## CI/CD Files

- `Jenkinsfile`
- `pipeline-config.yml`
- `.github/workflows/ci.yaml`
- `.github/workflows/build-deploy.yaml`
- `.github/workflows/staging-release.yaml`
- `.github/workflows/release-trigger.yaml`