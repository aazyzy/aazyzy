# Branch Cleanup Report: user-configuration-api

Generated: 2026-06-08 19:27:24
Default Branch: develop
Total Branches: 69

---

## Summary

- Total Branches: 69
- Excluded from Deletion: 2
- Marked for Deletion: 67

---

## All Branches

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `master` | 2021-11-25 14:50:40 -0500 | 2021-11-25 14:50:40 -0500 | MERGED |
| `feature/NWPI-10303` | 2023-12-15 15:07:45 -0500 | 2023-12-15 15:07:45 -0500 | MERGED |
| `task/add-sonar-coverage` | 2023-12-21 14:51:35 -0500 | 2023-12-21 14:51:35 -0500 | MERGED |
| `release/1.14` | 2024-01-18 09:48:31 -0500 | 2024-01-18 09:48:31 -0500 | MERGED |
| `release/1.14.2` | 2024-01-25 11:15:48 -0500 | 2024-01-25 11:15:48 -0500 | MERGED |
| `snyk-fix-ce97a0e717243999f1a30629a558b0b7` | 2024-02-22 10:35:53 -0500 | 2024-02-22 10:35:53 -0500 | MERGED |
| `release/1.15` | 2024-02-27 15:23:08 -0500 | 2024-02-27 15:23:08 -0500 | MERGED |
| `feature/NBINPS-49` | 2024-04-01 10:27:33 -0400 | 2024-04-01 10:27:33 -0400 | MERGED |
| `release/1.16` | 2024-04-01 11:58:33 -0400 | 2024-04-01 11:58:33 -0400 | MERGED |
| `feature/NBINPS-49-new` | 2024-04-16 16:35:45 -0400 | 2024-04-16 16:35:45 -0400 | MERGED |
| `feature/NBINPS-49-put` | 2024-04-16 16:35:45 -0400 | 2024-04-16 16:35:45 -0400 | MERGED |
| `feature/NBINPS-128` | 2024-04-19 08:18:49 -0400 | 2024-04-19 08:18:49 -0400 | MERGED |
| `feature/NBINPS-77` | 2024-04-24 12:13:22 -0400 | 2024-04-24 12:13:22 -0400 | MERGED |
| `release/1.16.2` | 2024-05-05 00:08:48 -0400 | 2024-05-05 00:08:48 -0400 | MERGED |
| `feature/NBINPS-110-revert` | 2024-05-10 15:16:03 -0400 | 2024-05-10 15:16:03 -0400 | MERGED |
| `feature/NBINPS-110-fix` | 2024-05-10 16:53:11 -0400 | 2024-05-10 16:53:11 -0400 | MERGED |
| `feature/NWPI-11380` | 2024-05-16 16:35:21 -0400 | 2024-05-16 16:35:21 -0400 | MERGED |
| `feature/NBINPS-110-fix1` | 2024-05-28 18:41:43 -0400 | 2024-05-28 18:41:43 -0400 | MERGED |
| `release/1.17` | 2024-05-29 10:57:17 -0400 | 2024-05-29 10:57:17 -0400 | MERGED |
| `NWPI-11633` | 2024-06-20 17:38:00 -0400 | 2024-06-20 17:38:00 -0400 | MERGED |
| `NWPI-11740_V1_18` | 2024-07-09 13:03:07 -0400 | 2024-07-09 13:03:07 -0400 | MERGED |
| `NWPI-11740` | 2024-07-09 13:03:07 -0400 | 2024-07-09 13:03:07 -0400 | MERGED |
| `release/1.18` | 2024-07-09 15:41:08 -0400 | 2024-07-09 15:41:08 -0400 | MERGED |
| `feature/NBINPS-248` | 2024-07-11 11:16:27 -0400 | 2024-07-11 11:16:27 -0400 | MERGED |
| `release/1.18.1` | 2024-08-09 12:56:13 -0400 | 2024-08-09 12:56:13 -0400 | MERGED |
| `scopePermissionInIstio` | 2024-08-16 10:34:51 -0400 | 2024-08-16 10:34:51 -0400 | MERGED |
| `feature/scopePermissionInIstio` | 2024-08-16 11:02:35 -0400 | 2024-08-16 11:02:35 -0400 | MERGED |
| `release/1.19` | 2024-08-26 16:55:57 -0400 | 2024-08-26 16:55:57 -0400 | MERGED |
| `release/1.18.2` | 2024-08-26 16:56:04 -0400 | 2024-08-26 16:56:04 -0400 | MERGED |
| `task/NWPI-12028` | 2024-08-30 15:28:32 -0400 | 2024-08-30 15:28:32 -0400 | MERGED |
| `feature/NWPI-12040-integrate-ciam-suspend-into-cx-profile-management` | 2024-09-13 22:12:46 -0400 | 2024-09-13 22:12:46 -0400 | MERGED |
| `feature/NWPI-11936-sync-okta-call-sso-users-fails` | 2024-09-20 19:55:53 -0400 | 2024-09-20 19:55:53 -0400 | MERGED |
| `task/NWPI-12114` | 2024-09-26 16:37:10 -0400 | 2024-09-26 16:37:10 -0400 | MERGED |
| `fix/NWPI-12340-hotfix` | 2024-10-25 15:42:23 -0400 | 2024-10-25 15:42:23 -0400 | MERGED |
| `release/1.19.4` | 2024-10-25 16:18:06 -0400 | 2024-10-25 16:18:06 -0400 | MERGED |
| `release/1.20` | 2024-10-31 14:10:12 -0400 | 2024-10-31 14:10:12 -0400 | MERGED |
| `release/1.20.1` | 2024-11-25 14:35:17 -0500 | 2024-11-25 14:35:17 -0500 | MERGED |
| `release/1.21` | 2024-12-15 23:01:41 -0500 | 2024-12-15 23:01:41 -0500 | MERGED |
| `release/1.21.1` | 2025-01-07 16:06:04 -0500 | 2025-01-07 16:06:04 -0500 | MERGED |
| `release/1.21.2` | 2025-01-27 22:47:03 -0500 | 2025-01-27 22:47:03 -0500 | MERGED |
| `release/1.21.3` | 2025-01-28 14:13:43 -0500 | 2025-01-28 14:13:43 -0500 | MERGED |
| `feature/NWPI-12926_2` | 2025-02-13 15:00:35 -0500 | 2025-02-13 15:00:35 -0500 | MERGED |
| `feature/NWPI-13026-implement-update-okta-user-id-in-a-new-controller` | 2025-02-24 13:56:20 -0500 | 2025-02-24 13:56:20 -0500 | MERGED |
| `feature/NWPI-12926_4` | 2025-02-24 16:28:18 -0500 | 2025-02-24 16:28:18 -0500 | MERGED |
| `feature/NWPI-13085` | 2025-03-10 09:36:57 -0400 | 2025-03-10 09:36:57 -0400 | MERGED |
| `release/1.21.4` | 2025-03-11 15:40:17 -0400 | 2025-03-11 15:40:17 -0400 | MERGED |
| `feature/NWPI-12927` | 2025-03-14 14:01:39 -0400 | 2025-03-14 14:01:39 -0400 | MERGED |
| `NWPI-12971` | 2025-03-23 08:26:12 -0400 | 2025-03-23 08:26:12 -0400 | MERGED |
| `feature/NWPI-12886` | 2025-04-01 15:46:32 -0400 | 2025-04-01 15:46:32 -0400 | MERGED |
| `feature/NWPI-13167-1uf6-user-config-endpoint-should-support-multiple-assignment-types` | 2025-04-08 14:26:01 -0400 | 2025-04-08 14:26:01 -0400 | MERGED |
| `feature/NWPI-13116` | 2025-04-10 14:56:23 -0400 | 2025-04-10 14:56:23 -0400 | MERGED |
| `release/1.23.0` | 2025-04-20 08:02:54 -0400 | 2025-04-20 08:02:54 -0400 | MERGED |
| `feature/NWPI-13354-uf5-uf6-user-config-endpoints-add-parameters-validation` | 2025-04-23 10:10:56 -0400 | 2025-04-23 10:10:56 -0400 | MERGED |
| `NWPI-13136-1-define-kafka-message-for-audit-notification-analysis` | 2025-05-10 17:11:03 -0400 | 2025-05-10 17:11:03 -0400 | MERGED |
| `release/1.24.0` | 2025-05-20 09:11:03 -0400 | 2025-05-20 09:11:03 -0400 | MERGED |
| `feature/NWPI-13645-prod-update-user-email-address-updates-have-not-been-updating-in-okta` | 2025-06-23 11:12:27 -0400 | 2025-06-23 11:12:27 -0400 | MERGED |
| `feature/NWPI-13171` | 2025-06-30 15:31:57 -0400 | 2025-06-30 15:31:57 -0400 | MERGED |
| `feature/NWPI-13777-user-onboarding-user-skips-sms-authentication-backend` | 2025-07-22 12:49:33 -0400 | 2025-07-22 12:49:33 -0400 | MERGED |
| `release/1.26.0` | 2025-08-19 13:34:02 -0400 | 2025-08-19 13:34:02 -0400 | MERGED |
| `release/1.28.0` | 2025-11-15 09:51:27 -0500 | 2025-11-15 09:51:27 -0500 | MERGED |
| `feature/NWPI-14158-move-info-messages-to-debug-in-commons-auth-library` | 2025-11-19 14:57:20 -0500 | 2025-11-19 14:57:20 -0500 | MERGED |
| `release/2.1.0` | 2026-01-23 13:43:58 -0500 | 2026-01-23 13:43:58 -0500 | MERGED |
| `release/2.1.1` | 2026-03-06 13:29:08 -0500 | 2026-03-06 13:29:08 -0500 | MERGED |
| `feature/adding-securezne-certs-java` | 2026-03-18 14:12:46 -0400 | 2026-03-18 14:12:46 -0400 | MERGED |
| `feature/NWPI-14497` | 2026-04-30 13:58:25 -0400 | 2026-04-30 13:58:25 -0400 | MERGED |
| `feature/temp` | 2026-05-15 13:29:50 -0400 | 2026-05-15 13:29:50 -0400 | MERGED |
| `release/2.2.0` | 2026-05-23 10:18:35 -0400 | 2026-05-23 10:18:35 -0400 | MERGED |
| `feature/feature/audit-log-create-event-ordering` | 2026-06-04 10:33:50 -0400 | 2026-06-04 10:33:50 -0400 | UNMERGED |
| `fix/audit-log-create-event-ordering` | 2026-06-04 10:33:50 -0400 | 2026-06-04 10:33:50 -0400 | UNMERGED |

---

## Excluded from Deletion

Criteria: Unmerged branches with last commit less than 2 months old
Count: 2

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `fix/audit-log-create-event-ordering` | 2026-06-04 10:33:50 -0400 | 2026-06-04 10:33:50 -0400 | UNMERGED |
| `feature/feature/audit-log-create-event-ordering` | 2026-06-04 10:33:50 -0400 | 2026-06-04 10:33:50 -0400 | UNMERGED |

---

## Marked for Deletion

Criteria: All merged branches + unmerged branches with last commit older than 2 months
Count: 67

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `master` | 2021-11-25 14:50:40 -0500 | 2021-11-25 14:50:40 -0500 | MERGED |
| `feature/NWPI-10303` | 2023-12-15 15:07:45 -0500 | 2023-12-15 15:07:45 -0500 | MERGED |
| `task/add-sonar-coverage` | 2023-12-21 14:51:35 -0500 | 2023-12-21 14:51:35 -0500 | MERGED |
| `release/1.14` | 2024-01-18 09:48:31 -0500 | 2024-01-18 09:48:31 -0500 | MERGED |
| `release/1.14.2` | 2024-01-25 11:15:48 -0500 | 2024-01-25 11:15:48 -0500 | MERGED |
| `snyk-fix-ce97a0e717243999f1a30629a558b0b7` | 2024-02-22 10:35:53 -0500 | 2024-02-22 10:35:53 -0500 | MERGED |
| `release/1.15` | 2024-02-27 15:23:08 -0500 | 2024-02-27 15:23:08 -0500 | MERGED |
| `feature/NBINPS-49` | 2024-04-01 10:27:33 -0400 | 2024-04-01 10:27:33 -0400 | MERGED |
| `release/1.16` | 2024-04-01 11:58:33 -0400 | 2024-04-01 11:58:33 -0400 | MERGED |
| `feature/NBINPS-49-new` | 2024-04-16 16:35:45 -0400 | 2024-04-16 16:35:45 -0400 | MERGED |
| `feature/NBINPS-49-put` | 2024-04-16 16:35:45 -0400 | 2024-04-16 16:35:45 -0400 | MERGED |
| `feature/NBINPS-128` | 2024-04-19 08:18:49 -0400 | 2024-04-19 08:18:49 -0400 | MERGED |
| `feature/NBINPS-77` | 2024-04-24 12:13:22 -0400 | 2024-04-24 12:13:22 -0400 | MERGED |
| `release/1.16.2` | 2024-05-05 00:08:48 -0400 | 2024-05-05 00:08:48 -0400 | MERGED |
| `feature/NBINPS-110-revert` | 2024-05-10 15:16:03 -0400 | 2024-05-10 15:16:03 -0400 | MERGED |
| `feature/NBINPS-110-fix` | 2024-05-10 16:53:11 -0400 | 2024-05-10 16:53:11 -0400 | MERGED |
| `feature/NWPI-11380` | 2024-05-16 16:35:21 -0400 | 2024-05-16 16:35:21 -0400 | MERGED |
| `feature/NBINPS-110-fix1` | 2024-05-28 18:41:43 -0400 | 2024-05-28 18:41:43 -0400 | MERGED |
| `release/1.17` | 2024-05-29 10:57:17 -0400 | 2024-05-29 10:57:17 -0400 | MERGED |
| `NWPI-11633` | 2024-06-20 17:38:00 -0400 | 2024-06-20 17:38:00 -0400 | MERGED |
| `NWPI-11740_V1_18` | 2024-07-09 13:03:07 -0400 | 2024-07-09 13:03:07 -0400 | MERGED |
| `NWPI-11740` | 2024-07-09 13:03:07 -0400 | 2024-07-09 13:03:07 -0400 | MERGED |
| `release/1.18` | 2024-07-09 15:41:08 -0400 | 2024-07-09 15:41:08 -0400 | MERGED |
| `feature/NBINPS-248` | 2024-07-11 11:16:27 -0400 | 2024-07-11 11:16:27 -0400 | MERGED |
| `release/1.18.1` | 2024-08-09 12:56:13 -0400 | 2024-08-09 12:56:13 -0400 | MERGED |
| `scopePermissionInIstio` | 2024-08-16 10:34:51 -0400 | 2024-08-16 10:34:51 -0400 | MERGED |
| `feature/scopePermissionInIstio` | 2024-08-16 11:02:35 -0400 | 2024-08-16 11:02:35 -0400 | MERGED |
| `release/1.19` | 2024-08-26 16:55:57 -0400 | 2024-08-26 16:55:57 -0400 | MERGED |
| `release/1.18.2` | 2024-08-26 16:56:04 -0400 | 2024-08-26 16:56:04 -0400 | MERGED |
| `task/NWPI-12028` | 2024-08-30 15:28:32 -0400 | 2024-08-30 15:28:32 -0400 | MERGED |
| `feature/NWPI-12040-integrate-ciam-suspend-into-cx-profile-management` | 2024-09-13 22:12:46 -0400 | 2024-09-13 22:12:46 -0400 | MERGED |
| `feature/NWPI-11936-sync-okta-call-sso-users-fails` | 2024-09-20 19:55:53 -0400 | 2024-09-20 19:55:53 -0400 | MERGED |
| `task/NWPI-12114` | 2024-09-26 16:37:10 -0400 | 2024-09-26 16:37:10 -0400 | MERGED |
| `fix/NWPI-12340-hotfix` | 2024-10-25 15:42:23 -0400 | 2024-10-25 15:42:23 -0400 | MERGED |
| `release/1.19.4` | 2024-10-25 16:18:06 -0400 | 2024-10-25 16:18:06 -0400 | MERGED |
| `release/1.20` | 2024-10-31 14:10:12 -0400 | 2024-10-31 14:10:12 -0400 | MERGED |
| `release/1.20.1` | 2024-11-25 14:35:17 -0500 | 2024-11-25 14:35:17 -0500 | MERGED |
| `release/1.21` | 2024-12-15 23:01:41 -0500 | 2024-12-15 23:01:41 -0500 | MERGED |
| `release/1.21.1` | 2025-01-07 16:06:04 -0500 | 2025-01-07 16:06:04 -0500 | MERGED |
| `release/1.21.2` | 2025-01-27 22:47:03 -0500 | 2025-01-27 22:47:03 -0500 | MERGED |
| `release/1.21.3` | 2025-01-28 14:13:43 -0500 | 2025-01-28 14:13:43 -0500 | MERGED |
| `feature/NWPI-12926_2` | 2025-02-13 15:00:35 -0500 | 2025-02-13 15:00:35 -0500 | MERGED |
| `feature/NWPI-13026-implement-update-okta-user-id-in-a-new-controller` | 2025-02-24 13:56:20 -0500 | 2025-02-24 13:56:20 -0500 | MERGED |
| `feature/NWPI-12926_4` | 2025-02-24 16:28:18 -0500 | 2025-02-24 16:28:18 -0500 | MERGED |
| `feature/NWPI-13085` | 2025-03-10 09:36:57 -0400 | 2025-03-10 09:36:57 -0400 | MERGED |
| `release/1.21.4` | 2025-03-11 15:40:17 -0400 | 2025-03-11 15:40:17 -0400 | MERGED |
| `feature/NWPI-12927` | 2025-03-14 14:01:39 -0400 | 2025-03-14 14:01:39 -0400 | MERGED |
| `NWPI-12971` | 2025-03-23 08:26:12 -0400 | 2025-03-23 08:26:12 -0400 | MERGED |
| `feature/NWPI-12886` | 2025-04-01 15:46:32 -0400 | 2025-04-01 15:46:32 -0400 | MERGED |
| `feature/NWPI-13167-1uf6-user-config-endpoint-should-support-multiple-assignment-types` | 2025-04-08 14:26:01 -0400 | 2025-04-08 14:26:01 -0400 | MERGED |
| `feature/NWPI-13116` | 2025-04-10 14:56:23 -0400 | 2025-04-10 14:56:23 -0400 | MERGED |
| `release/1.23.0` | 2025-04-20 08:02:54 -0400 | 2025-04-20 08:02:54 -0400 | MERGED |
| `feature/NWPI-13354-uf5-uf6-user-config-endpoints-add-parameters-validation` | 2025-04-23 10:10:56 -0400 | 2025-04-23 10:10:56 -0400 | MERGED |
| `NWPI-13136-1-define-kafka-message-for-audit-notification-analysis` | 2025-05-10 17:11:03 -0400 | 2025-05-10 17:11:03 -0400 | MERGED |
| `release/1.24.0` | 2025-05-20 09:11:03 -0400 | 2025-05-20 09:11:03 -0400 | MERGED |
| `feature/NWPI-13645-prod-update-user-email-address-updates-have-not-been-updating-in-okta` | 2025-06-23 11:12:27 -0400 | 2025-06-23 11:12:27 -0400 | MERGED |
| `feature/NWPI-13171` | 2025-06-30 15:31:57 -0400 | 2025-06-30 15:31:57 -0400 | MERGED |
| `feature/NWPI-13777-user-onboarding-user-skips-sms-authentication-backend` | 2025-07-22 12:49:33 -0400 | 2025-07-22 12:49:33 -0400 | MERGED |
| `release/1.26.0` | 2025-08-19 13:34:02 -0400 | 2025-08-19 13:34:02 -0400 | MERGED |
| `release/1.28.0` | 2025-11-15 09:51:27 -0500 | 2025-11-15 09:51:27 -0500 | MERGED |
| `feature/NWPI-14158-move-info-messages-to-debug-in-commons-auth-library` | 2025-11-19 14:57:20 -0500 | 2025-11-19 14:57:20 -0500 | MERGED |
| `release/2.1.0` | 2026-01-23 13:43:58 -0500 | 2026-01-23 13:43:58 -0500 | MERGED |
| `release/2.1.1` | 2026-03-06 13:29:08 -0500 | 2026-03-06 13:29:08 -0500 | MERGED |
| `feature/adding-securezne-certs-java` | 2026-03-18 14:12:46 -0400 | 2026-03-18 14:12:46 -0400 | MERGED |
| `feature/NWPI-14497` | 2026-04-30 13:58:25 -0400 | 2026-04-30 13:58:25 -0400 | MERGED |
| `feature/temp` | 2026-05-15 13:29:50 -0400 | 2026-05-15 13:29:50 -0400 | MERGED |
| `release/2.2.0` | 2026-05-23 10:18:35 -0400 | 2026-05-23 10:18:35 -0400 | MERGED |

---

## Deletion Results

Total Attempted: 67
Successfully Deleted: 66
Failed: 1
Skipped (Excluded Safety Gate): 0

### Failed Deletions

| Branch Name | Error |
|-------------|-------|
| `feature/temp` | You cannot delete this branch since it has at least one open pull request associated with it |
