package ca.bnc.wealth.api.userconfiguration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.jdbc.autoconfigure.DataSourceAutoConfiguration;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication(
    exclude = DataSourceAutoConfiguration.class,
    scanBasePackages = {
      "ca.bnc.wealth.api.*",
      "ca.bnc.wealth.common.jpa.*",
      "ca.bnc.wealth.common.ciam.*",
      "ca.bnc.wealth.common.kafka.*",
      "ca.bnc.wealth.common.exception.*",
      "ca.bnc.wealth.common.system.token.*",
      "ca.bnc.wealth.common.r2.*",
      "ca.bnc.wealth.common.extract.*",
      "ca.bnc.wealth.common.fum.service",
      "ca.bnc.wealth.common.core.cors",
      "ca.bnc.wealth.common.health.*",
      "ca.bnc.wealth.common.sz.*",
    })
@EnableJpaRepositories({"ca.bnc.wealth.common.jpa.repo"})
@EntityScan(basePackages = {"ca.bnc.wealth.common.jpa.entity"})
@EnableScheduling
public class Application {

  public static void main(String[] args) {
    SpringApplication.run(Application.class, args);
  }
}
