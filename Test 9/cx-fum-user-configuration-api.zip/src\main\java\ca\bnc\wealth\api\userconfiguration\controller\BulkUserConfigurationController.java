package ca.bnc.wealth.api.userconfiguration.controller;

import ca.bnc.wealth.api.userconfiguration.service.BulkUserConfigurationService;
import ca.bnc.wealth.common.userconfiguration.api.BulkUserConfigurationApi;
import ca.bnc.wealth.common.userconfiguration.model.Response;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class BulkUserConfigurationController implements BulkUserConfigurationApi {

  private final BulkUserConfigurationService bulkUserConfigurationService;

  @Override
  public ResponseEntity<List<Response>> updateUserConfiguration(List<Map<String, String>> requestBody) {
    List<Response> response = requestBody.stream().map(bulkUserConfigurationService::updateUser).toList();
    return ResponseEntity.ok(response);
  }

}
