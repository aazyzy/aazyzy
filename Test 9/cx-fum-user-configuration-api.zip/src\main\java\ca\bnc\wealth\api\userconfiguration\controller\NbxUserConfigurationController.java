package ca.bnc.wealth.api.userconfiguration.controller;

import ca.bnc.wealth.api.userconfiguration.model.UserConfigurationConstants;
import ca.bnc.wealth.api.userconfiguration.service.AuditLogService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigSearchMaterializedRefreshService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigValidationService;
import ca.bnc.wealth.api.userconfiguration.service.UserService;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.MapperUtils;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.jpa.entity.enums.AuditEventType;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.userconfiguration.api.NbxUserConfigurationApi;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearch;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearchResponse;
import ca.bnc.wealth.common.userconfiguration.model.NbxUserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.util.Map;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class NbxUserConfigurationController implements NbxUserConfigurationApi {

  private final UserConfigValidationService userConfigValidationService;
  private final UserService userService;
  private final UserConfigSearchMaterializedRefreshService userConfigSearchMaterializedRefreshService;
  private final AuditLogService auditLogService;

  @Override
  public ResponseEntity<UserConfiguration> createNbxUserConfiguration(
      NbxUserConfiguration nbxUserConfiguration) {
    UserConfiguration userConfiguration = UserConfiguration.builder()
        .firstName(nbxUserConfiguration.getFirstName())
        .lastName(nbxUserConfiguration.getLastName())
        .email(nbxUserConfiguration.getEmail())
        .preferredLanguage(Objects.toString(nbxUserConfiguration.getPreferredLanguage(), null))
        .source(UserConfigurationConstants.NBX_SOURCE)
        .build();

    userConfigValidationService.validateCreateNbxUserConfiguration(userConfiguration);

    Map<String, String> validationError = userConfigValidationService.validateUserConfigurationCreation(userConfiguration, true);
    if (!validationError.isEmpty()) {
      String errorCode =
          validationError.entrySet().stream().findFirst().map(Map.Entry::getValue).orElse("");
      throw new FumServiceException(errorCode, Constants.ERROR_DEFAULTMESSAGE_CREATE_USER_VALIDATION);
    }

    UserConfiguration uc = auditLogService.publishAuditLog(null, false, AuditEventType.CREATE, () -> {
      IamUserConfiguration iamUserConfiguration = userService.saveNewUserConfiguration(userConfiguration, null);
      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
      return MapperUtils.toDto(iamUserConfiguration);
    });

    return new ResponseEntity<>(uc, HttpStatus.CREATED);
  }

  @Override
  public ResponseEntity<UserConfiguration> updateNbxUserConfigurationByUserId(
      String userId, NbxUserConfiguration nbxUserConfiguration) {

    userConfigValidationService.validateUpdateNbxUserConfiguration(userId, nbxUserConfiguration);
    UserConfiguration uc = userService.getUserConfiguration(userId);
    uc = auditLogService.publishAuditLog(uc.getUserConfigurationId(), false, AuditEventType.UPDATE, () -> {
      IamUserConfiguration iamUserConfiguration = userService.updateNbxUserConfiguration(userId, nbxUserConfiguration);
      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
      return MapperUtils.toDto(iamUserConfiguration);
    });


    return new ResponseEntity<>(uc, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<GenericSearchResponse> nbxGenericSearchWithPagination(GenericSearch genericSearch) {
    GenericSearchResponse response;
    try {
      response = userService.genericNbxUserSearchWithPagination(genericSearch);
    } catch (Exception e) {
      log.error("ERROR_IN_SEARCH", e.getMessage());
      throw new FumServiceException(Constants.ERROR_CODE_GENERIC_SEARCH_USER, Constants.ERROR_DEFAULTMESSAGE_GENERIC_SEARCH_USER);
    }
    return new ResponseEntity<>(response, HttpStatus.OK);
  }
}
