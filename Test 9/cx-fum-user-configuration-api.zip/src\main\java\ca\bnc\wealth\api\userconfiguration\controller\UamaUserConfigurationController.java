package ca.bnc.wealth.api.userconfiguration.controller;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigValidationService;
import ca.bnc.wealth.api.userconfiguration.service.UserService;
import ca.bnc.wealth.common.userconfiguration.api.UamaUserConfigurationApi;
import ca.bnc.wealth.common.userconfiguration.model.UamaUpdateUserExternalId;
import ca.bnc.wealth.common.userconfiguration.model.UamaUser;
import ca.bnc.wealth.common.userconfiguration.model.UamaUserSearchResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class UamaUserConfigurationController implements UamaUserConfigurationApi {

  private final UserService userService;
  private final UserConfigValidationService userConfigValidationService;

  @Override
  public ResponseEntity<Void> updateUserExternalSystemConfigurationByIdpSubject(String idpSubject, String externalSystemId, UamaUpdateUserExternalId updateUserExternalId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("updateUserExternalSystemConfigurationByIdpSubject : # Start : idpSubject: {}, providedIdpSubject: {}, externalSystemId: {}, updateUserExternalId: {} ",
        user.getIdpSubject(), idpSubject, externalSystemId, updateUserExternalId);
    userConfigValidationService.validateUpdateUserExternalId(updateUserExternalId);
    userService.updateExternalUserIds(idpSubject, externalSystemId, updateUserExternalId.getExternalUserId());
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Void> updateUserGroupByIdpSubject(String idpSubject, String groupName) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("updateUserGroupByIdpSubject : # Start : idpSubject: {}, providedIdpSubject: {}, groupName: {} ",
        user.getIdpSubject(), idpSubject, groupName);
    userService.updateUserGroupByIdpSubject(idpSubject, groupName);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Void> deleteUserGroupByIdpSubject(String idpSubject, String groupName) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("deleteUserGroupByIdpSubject : # Start : idpSubject: {}, providedIdpSubject: {}, groupName: {} ",
        user.getIdpSubject(), idpSubject, groupName);
    userService.deleteUserGroupByIdpSubject(idpSubject, groupName);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<UamaUser> getUserExternalSystemConfigurationByExternalUserId(String externalSystemId, String externalUserId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getUserExternalSystemConfigurationByExternalUserId # Start: idpSubject: {}, externalSystemId: {}, externalUserId: {}",
        user.getIdpSubject(), externalSystemId, externalUserId);
    return new ResponseEntity<>(userService.getUserConfigurationByExternalUserId(externalSystemId, externalUserId), HttpStatus.OK);
  }

  @Override
  public ResponseEntity<UamaUserSearchResponse> getUamaUsersByIdpSubjectAndExternalSystemId(String idpSubject, String externalSystemId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getUamaUsersByIdpSubjectAndExternalSystemId # Start: idpSubject: {}, providedIdpSubject: {}, externalSystemId: {}",
        user.getIdpSubject(), idpSubject, externalSystemId);
    return new ResponseEntity<>(userService.getUserConfigurationByIdpSubjectAndExternalSystemId(idpSubject, externalSystemId), HttpStatus.OK);
  }
}
