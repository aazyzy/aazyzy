package ca.bnc.wealth.api.userconfiguration.controller;

import static ca.bnc.wealth.api.userconfiguration.model.state.UserStateActionEnum.SUSPENDED;

import ca.bnc.wealth.api.authorization.enums.IdTokenEnum;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.util.DisablePermissionCheck;
import ca.bnc.wealth.api.userconfiguration.service.AuditLogService;
import ca.bnc.wealth.api.userconfiguration.service.FirmBmaGuardService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigSearchMaterializedRefreshService;
import ca.bnc.wealth.api.userconfiguration.util.BulkUserConstants;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigValidationService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigurationDataSyncService;
import ca.bnc.wealth.api.userconfiguration.service.TokenRevocationService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigurationService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigurationServiceJpa;
import ca.bnc.wealth.api.userconfiguration.service.UserExtractService;
import ca.bnc.wealth.api.userconfiguration.service.UserService;
import ca.bnc.wealth.api.userconfiguration.service.UserStateService;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.fum.model.AssignmentTypeEnum;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.jpa.entity.enums.AuditEventType;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.userconfiguration.api.UserConfigurationApi;
import ca.bnc.wealth.common.userconfiguration.model.AssignRequest;
import ca.bnc.wealth.common.userconfiguration.model.CompassR2IdLink;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearch;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearchResponse;
import ca.bnc.wealth.common.userconfiguration.model.OktaStatusSyncRequest;
import ca.bnc.wealth.common.userconfiguration.model.PageInfo;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.RRRange;
import ca.bnc.wealth.common.userconfiguration.model.ResourceName;
import ca.bnc.wealth.common.userconfiguration.model.UpdateUserPreferenceRequest;
import ca.bnc.wealth.common.userconfiguration.model.UpdateUserStatus;
import ca.bnc.wealth.common.userconfiguration.model.UserAssignment;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.RevokeJwtRequest;
import ca.bnc.wealth.common.userconfiguration.model.UserCredentials;
import ca.bnc.wealth.common.userconfiguration.model.UserExternalSystemConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserGroupName;
import ca.bnc.wealth.common.userconfiguration.model.UserIdentity;
import ca.bnc.wealth.common.userconfiguration.model.UserListResponse;
import ca.bnc.wealth.common.userconfiguration.model.UserOktaProfile;
import ca.bnc.wealth.common.userconfiguration.model.UserPreferredLanguage;
import ca.bnc.wealth.common.userconfiguration.model.UserSearch;
import ca.bnc.wealth.common.userconfiguration.model.UserTempCredentials;
import ca.bnc.wealth.common.userconfiguration.model.Users;
import jakarta.validation.constraints.NotNull;
import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class UserConfigurationController implements UserConfigurationApi {


  private static final String SEARCH_USERS_INITIATED_BY_START_IDP_SUBJECT =
      "Search Users initiated by # Start: idpSubject: {}";
  private static final String ERROR_IN_SEARCH = "Error in search: {}";
  private static final String USER_DATA_CSV_DOWNLOAD_FILE = "userdata.csv";

  private final TokenRevocationService tokenRevocationService;
  private final UserConfigurationService userConfigurationService;
  private final UserConfigurationServiceJpa userConfigurationServiceJpa;
  private final UserConfigValidationService userConfigValidationService;
  private final UserConfigurationDataSyncService userConfigurationDataSyncService;
  private final UserExtractService userExtractService;
  private final UserService userService;
  private final UserStateService userStateService;
  private final RedisCacheOperationService redisCacheOperationService;
  private final UserAssignmentService userAssignmentService;
  private final UserConfigSearchMaterializedRefreshService userConfigSearchMaterializedRefreshService;
  private final AuditLogService auditLogService;
  private final FirmBmaGuardService firmBmaGuardService;

  @Override
  public ResponseEntity<List<RRCodeRange>> getRRCodes(String authorization, Boolean active) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getRRCodes # Start: idpSubject: {}", user.getIdpSubject());

    List<RRCodeRange> rrCodeList =
        userService.getRRCodeListByIdpSubject(user.getIdpSubject(), active);
    return new ResponseEntity<>(rrCodeList, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<List<RRCodeRange>> getRRCodesByUserId(
      Integer userConfigurationId, Boolean active) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info(
        "getRRCodesByUserId for {} : # Start : idpSubject {}",
        userConfigurationId,
        user.getIdpSubject());

    List<RRCodeRange> rrCodeList =
        userService.getRRCodeListByIdpSubject(
            userService.getUserIdpSubjectById(userConfigurationId), active);

    return new ResponseEntity<>(rrCodeList, HttpStatus.OK);
  }

  @Override
  @DisablePermissionCheck
  public ResponseEntity<UserConfiguration> getUserConfiguration(Boolean isGetExternalId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.trace("getUserConfiguration # Start: idpSubject: {}", user.getIdpSubject());
    UserConfiguration userConfiguration;
    try {
      userConfiguration = userService.getUserConfiguration(user.getIdpSubject());
    } catch (EmptyResultDataAccessException e) {
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    if (isGetExternalId != null && isGetExternalId) {
      userConfiguration.setSecureZoneIds(user.getSecureZoneIds());
      userConfiguration.setCompassR2Id(
          userService.getCompassR2Id(userConfiguration.getIdpSubject()));
    }
    return new ResponseEntity<>(userConfiguration, HttpStatus.OK);
  }

  @Override
  @DisablePermissionCheck
  public ResponseEntity<UserConfiguration> createUserIdentity(UserIdentity userIdentity) {

    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("createUserIdentity # Start: idpSubject: {}", user.getIdpSubject());

    UserConfiguration userConfiguration = new UserConfiguration();
    // Extracting claims from ID token
    Map<String, Object> idTokenClaims =
        userConfigurationService.validateAndFetchIdTokenClaims(userIdentity);
    if (MapUtils.isEmpty(idTokenClaims)) {
      log.error("CRITICAL: Error occurred while parsing the ID token");
      redisCacheOperationService.deleteUserConfigurationCacheNoException(userConfiguration);
      return new ResponseEntity<>(userConfiguration, HttpStatus.BAD_REQUEST);
    }

    // Verifying whether uid in Access token and sub in Id token are same.
    // The Id token issuer and signature are already validated in
    // validateAndFetchIdTokenClaims(); here we enforce an exact, case-sensitive match of the
    // subject identifier to prevent token-substitution via case manipulation.
    if (idTokenClaims.get(IdTokenEnum.SUB.tokenValue) == null
        || !StringUtils.equals(
            user.getIdpUserId(), idTokenClaims.get(IdTokenEnum.SUB.tokenValue).toString())) {
      log.warn(
          "TOKEN_SUBSTITUTION_ATTEMPT: accessTokenUser={}, idTokenSub={}",
          user.getIdpUserId(),
          idTokenClaims.get(IdTokenEnum.SUB.tokenValue));
      log.error("CRITICAL: IdpSubject in Access token and Id token is different");
      return new ResponseEntity<>(userConfiguration, HttpStatus.BAD_REQUEST);
    }

    // Internal/employee ID tokens (issued by the corporate Okta) carry no firm identity
    // source. Such users are already provisioned and have no external SSO identity to link,
    // so the external-SSO identity mapping below does not apply. Return the existing
    // configuration unchanged.
    if (StringUtils.isBlank(
        (String) idTokenClaims.get(IdTokenEnum.BNGFIDENTITYSOURCE.tokenValue))) {
      log.info(
          "createUserIdentity # Internal/employee token (no identity source); "
              + "returning existing configuration for {}",
          user.getIdpSubject());
      return new ResponseEntity<>(
          userService.getUserConfiguration(user.getIdpSubject()), HttpStatus.OK);
    }

    userConfigurationService.mapIdTokenClaimsToUserConfiguration(idTokenClaims, userConfiguration);
    try {
      UserConfiguration existingConf =
          userService.getUserConfiguration(
              idTokenClaims.get(IdTokenEnum.BNGFREFERENCEID.tokenValue).toString());
      userConfiguration.setAccessProfileSet(existingConf.getAccessProfileSet());
      userConfiguration.setState(existingConf.getState());

      UserConfiguration finalUserConfiguration = userConfiguration;
      userConfiguration = auditLogService.publishAuditLog(existingConf.getUserConfigurationId(), false, AuditEventType.UPDATE, () -> {
        userConfigurationService.updateUserConfigIdentityForExternalSSOUsers(
            finalUserConfiguration.getIdpSubject(),
            existingConf.getUserConfigurationId(),
            finalUserConfiguration);
        if (user.getGroups() != null
            && !user.getGroups().contains(Constants.SSO_NOMFA_USER_GROUP)) {
          /**
           * Assigns the NoMfa group if not already available on the user's access token sourced from the
           * context. The userConfigurationService.updateUserConfigIdentityForExternalSSOUsers is not managing
           * that since getting the user groups from Okta for every update will have performance hits
           */
          userService.assignSsoNoMfaUserGroup(finalUserConfiguration);
        }
        log.info("IDP User Configuration updated successfully for {}", user.getIdpSubject());
        return finalUserConfiguration;
      });

    } catch (FumNotFoundException exception) { // create flow
      UserConfiguration finalUserConfiguration = userConfiguration;
      userConfiguration = auditLogService.publishAuditLog(null, false, AuditEventType.CREATE, () -> {
        userConfigValidationService.validateUserCreationForNonNbin(finalUserConfiguration);
        finalUserConfiguration.setState("active");
        finalUserConfiguration.setAccessProfileSet(Boolean.FALSE);
        UserConfiguration uc =
            userService.createUserForNonNbin(
                finalUserConfiguration, finalUserConfiguration.getIdpSubject());
        log.info("IDP User Configuration created successfully for {}", user.getIdpSubject());
        return uc;
      });

    }
    userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
    return new ResponseEntity<>(userConfiguration, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<UserExternalSystemConfiguration> getUserExternalSystemConfiguration(
      @NotNull String authorization, String externalSystemId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    String idpSubject = user.getIdpSubject();
    log.info("getUserExternalSystemConfiguration # Start: idpSubject: {}", idpSubject);
    return new ResponseEntity<>(
        userService.getUserExternalSystemConfiguration(idpSubject, externalSystemId),
        HttpStatus.OK);
  }

  @Override
  public ResponseEntity<UserExternalSystemConfiguration> getUserExternalSystemConfigurationByUserId(
      @NotNull String authorization, Integer userId, String externalSystemId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    String idpSubject = user.getIdpSubject();
    log.info("getUserExternalSystemConfigurationByUserId # Start: idpSubject: {}", idpSubject);
    return new ResponseEntity<>(
        userService.getUserExternalSystemConfiguration(userId, externalSystemId), HttpStatus.OK);
  }

  @Override
  public ResponseEntity<List<UserConfiguration>> getUserConfigurationsByFirmId(
      String authorization, String firmId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info(
        "getUserConfigurationsByFirmId # Start: idpUserSubject: {} firmId {}",
        user.getIdpSubject(),
        firmId);
    List<UserConfiguration> userConfigurations = null;
    userConfigurations =
        userService.getUserConfigurationsByFirmId(user.getIdpSubject(), firmId, null).getUsers();
    return new ResponseEntity<>(userConfigurations, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Users> getUserConfigurationWithPaginationByFirmId(
      String authorization, String firmId, PageInfo page) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info(
        "getUserConfigurationWithPaginationByFirmId # Start: idpUserSubject: {} firmId {} PageInfo {}",
        user.getIdpSubject(),
        firmId,
        page);
    Users response = userService.getUserConfigurationsByFirmId(user.getIdpSubject(), firmId, page);
    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<List<UserConfiguration>> searchUsers(
      String authorization, UserSearch userSearch, String cxUserToken) {
    String idpSubject = userService.getIdpSubjectFromPrincipalOrUserToken(cxUserToken);
    if (idpSubject == null)
      return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);

    log.info(SEARCH_USERS_INITIATED_BY_START_IDP_SUBJECT, idpSubject);
    List<UserConfiguration> userConfigurations = Collections.emptyList();
    try {
      userConfigurations = userService.searchUsers(idpSubject, userSearch);
    } catch (IntrospectionException | InvocationTargetException | IllegalAccessException e) {
      log.error(ERROR_IN_SEARCH, e.getMessage());
      throw new FumServiceException(Constants.ERROR_CODE_SEARCH_USER, Constants.ERROR_DEFALUTMESSAGE_SEARCH_USER);
    }
    return new ResponseEntity<>(userConfigurations, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<GenericSearchResponse> genericSearchWithPagination(
      String authorization, GenericSearch genericSearch) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info(SEARCH_USERS_INITIATED_BY_START_IDP_SUBJECT, user.getIdpSubject());
    GenericSearchResponse responses = null;
    try {
      responses = userService.materializedViewSearch(user.getIdpSubject(), genericSearch);
    } catch (Exception e) {
      log.error(ERROR_IN_SEARCH, e.getMessage());
      throw new FumServiceException(Constants.ERROR_CODE_GENERIC_SEARCH_USER, Constants.ERROR_DEFAULTMESSAGE_GENERIC_SEARCH_USER);
    }
    return new ResponseEntity<>(responses, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Void> refreshUserSearchMaterializedView() {
    userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(true);
    return new ResponseEntity<>(HttpStatus.OK);
  }

  @Override
  public ResponseEntity<UserConfiguration> getUserConfigurationByUserId(
      String userConfigurationId, Boolean isGetExternalId, Boolean isSzOnly) {
    log.info("getUserConfigurationByUserId # Start: userConfigurationId: {}", userConfigurationId);
    UserConfiguration userConfiguration =
        userService.getUserConfigurationWithRrCodeById(
            userService
                .getUserConfigurationByIdOrName(userConfigurationId)
                .getUserConfigurationId());
    if (isGetExternalId != null && isGetExternalId) {
      if (!Boolean.TRUE.equals(isSzOnly)) {
        userConfiguration.setCompassR2Id(
            userService.getCompassR2Id(userConfiguration.getIdpSubject()));
      }
      Optional.ofNullable(userService.getSecureZoneId(userConfiguration.getIdpUserId()))
          .ifPresent(a -> userConfiguration.setSecureZoneIds(Arrays.asList(a)));
    }
    return new ResponseEntity<>(userConfiguration, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<UserConfiguration> updateUserConfigurationByUserIdPost(
      String authorization, String userConfigurationId, UserConfiguration newUserConfiguration) {
    return updateUserConfigurationByUserId(
        authorization, userConfigurationId, newUserConfiguration);
  }

  @Override
  public ResponseEntity<UserConfiguration> updateUserConfigurationByUserId(
      String authorization, String userConfigurationId, UserConfiguration newUserConfiguration) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("updateUserConfigurationByUserId # Start: idpUserId: {}", user.getIdpSubject());
    UserConfiguration currentUserConfiguration =
        userService.getUserConfigurationByIdOrName(String.valueOf(userConfigurationId));
    if (currentUserConfiguration == null) {
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    userConfigurationService.auditUpdateUserConfiguration(
        currentUserConfiguration.getUserConfigurationId(), newUserConfiguration, currentUserConfiguration.getIdp(), user.getIdpSubject());
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<UserConfiguration> createUserConfiguration(
      String authorization, UserConfiguration userConfiguration, String idp) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("createUserConfiguration # Start: idpUserId: {}", user.getIdpSubject());

    if (firmBmaGuardService.isFirmBmaInProgress(userConfiguration.getFirmId())) {
      log.warn("CREATE_USER_BLOCKED: firm={} has an active feature package assignment batch", userConfiguration.getFirmId());
      throw new FumServiceException(BulkUserConstants.ERROR_FIRM_BMA_IN_PROGRESS,
          BulkUserConstants.ERROR_FIRM_BMA_IN_PROGRESS_MESSAGE);
    }

    UserConfiguration finalUserConfiguration = userConfiguration;
    String sentPassword = userConfiguration.getPassword();

    // Phase 1: Create user in DB and submit CREATE audit event.
    // The audit event is submitted to the async executor BEFORE the OKTA call,
    // ensuring the CREATE event is published before any UPDATE callback from OKTA.
    userConfiguration = auditLogService.publishAuditLog(null, true, AuditEventType.CREATE, () -> createUserInDb(user,
        finalUserConfiguration, idp));

    // Phase 2: OKTA profile setup — runs after the CREATE audit event is submitted.
    completeUserCreation(userConfiguration, idp);

    // Never echo the caller's credentials; only a password generated here is returned.
    if (userConfiguration != null) {
      userConfiguration.setHashedPassword(null);
      if (Objects.equals(sentPassword, userConfiguration.getPassword())) {
        userConfiguration.setPassword(null);
      }
    }
    return new ResponseEntity<>(userConfiguration, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Void> deleteUserConfigurationByUserId(
      String authorization, Integer userConfigurationId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    auditLogService.publishAuditLog(userConfigurationId, false, AuditEventType.UPDATE, () -> {
      log.info(
          "deleteUserConfigurationByUserId for {} : # Start : idpSubject {}",
          userConfigurationId,
          user.getIdpSubject());
      userService.deleteUserConfigurationByUserId(user.getIdpSubject(), userConfigurationId);
      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
      return UserConfiguration.builder().userConfigurationId(userConfigurationId).build();
    });

    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Void> linkCompassR2Id(
      String userConfigurationId, CompassR2IdLink compassR2IdLink) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info(
        "linkCompassR2Id # Start: userConfigurationId: {}, requestedBy: {}",
        userConfigurationId,
        user.getIdpSubject());
    userConfigurationService.linkCompassR2Id(
        userConfigurationId, compassR2IdLink.getCompassR2Id());
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Void> unlinkCompassR2Id(String userConfigurationId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info(
        "unlinkCompassR2Id # Start: userConfigurationId: {}, requestedBy: {}",
        userConfigurationId,
        user.getIdpSubject());
    userConfigurationService.unlinkCompassR2Id(userConfigurationId);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Map<String, String>> getRecoveryQuestions(
      String authorization, String acceptLanguage) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getRecoveryQuestions : # Start : ");
    return new ResponseEntity<>(userService.getRecoveryQuestions(acceptLanguage, user.getIdpSubject()), HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Void> deleteUser2FA(String authorization, String userId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("deleteUser2FA for {} # Start: idpUserId: {}", userId, user.getIdpSubject());
    userService.deleteUser2FA(userId);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<UserTempCredentials> resetPassword(
      String authorization, String userId, UserCredentials userCredentials) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("resetPassword for {} # Start: idpUserId: {}", userId, user.getIdpSubject());
    String tempPassword = userService.resetPassword(userId, userCredentials);
    auditLogService.publishAuditLog(Integer.valueOf(userId), false, AuditEventType.PASSWORD_RESET, () -> {
      userService.updateLastUpdatedBy(Integer.valueOf(userId), user.getIdpSubject());
      userStateService.savePasswordReset(Integer.valueOf(userId));
      return UserConfiguration.builder().userConfigurationId(Integer.valueOf(userId)).build();
    });
    UserTempCredentials userCredential = new UserTempCredentials();
    userCredential.setTempPassword(tempPassword);
    return new ResponseEntity<>(userCredential, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<UserOktaProfile> getOktaProfile(String authorization, String userId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getOktaProfile for {} # Start: idpUserId: {}", userId, user.getIdpSubject());
    return new ResponseEntity<>(userService.getOktaProfileOrEmpty(userId), HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Void> suspendUserOktaProfile(String authorization, String userId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("suspendOktaProfile for {} # Start: idpUserId: {}", userId, user.getIdpSubject());
    UserConfiguration userConfiguration = userService.getUserConfigurationByIdOrName(userId);

    auditLogService.publishAuditLog(userConfiguration.getUserConfigurationId(), false, AuditEventType.UPDATE, () ->{
      userService.updateLastUpdatedBy(userConfiguration.getUserConfigurationId(), user.getIdpSubject());
      userService.suspendUserOktaProfile(userConfiguration);
      userConfigurationServiceJpa.updateUserConfigState(userConfiguration.getUserConfigurationId(), SUSPENDED);
      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
      return userConfiguration;
    });
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Void> unsuspendUserOktaProfile(String authorization, String userId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("unsuspendOktaProfile for {} # Start: idpUserId: {}", userId, user.getIdpSubject());
    UserConfiguration userConfiguration = userService.getUserConfigurationByIdOrName(userId);

    auditLogService.publishAuditLog(userConfiguration.getUserConfigurationId(), false, AuditEventType.UPDATE, () ->{
      userService.updateLastUpdatedBy(userConfiguration.getUserConfigurationId(), user.getIdpSubject());
      userService.unsuspendUserOktaProfile(userConfiguration);
      userService.getOktaProfile(userId);
      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
      return userConfiguration;
    });
    userService.validateIsUserSuspended(userConfiguration);

    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Object> downloadUserData(String authorization) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("downloadUserData # Start: idpUserId: {}", user.getIdpSubject());

    byte[] userDataInCsvByteArray;
    ByteArrayResource userDataCSV = null;

    try {
      userDataInCsvByteArray = userExtractService.getUserDataInCsvByteArray(user.getIdpSubject());
      userDataCSV =
          userDataInCsvByteArray != null ? new ByteArrayResource(userDataInCsvByteArray) : null;
    } catch (FumServiceException e) {
      log.error(
          "Error generating User Data: idpUserId: {} error: {}",
          user.getIdpSubject(),
          e.getMessage());
      return ResponseEntity.internalServerError()
          .body("The file failed to generate. Please try again later.");
    }

    if (userDataCSV == null) {
      return ResponseEntity.accepted()
          .body("The user extract request is in progress. Please try again later.");
    }

    return ResponseEntity.ok()
        .header(
            HttpHeaders.CONTENT_DISPOSITION,
            "attachment; filename=\"" + USER_DATA_CSV_DOWNLOAD_FILE + "\"")
        .body(userDataCSV);
  }

  @Override
  public ResponseEntity<Void> updatePreferredLanguage(UserPreferredLanguage userPreferredLanguage) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("updatePreferredLanguage # Start: idpUserId: {}", user.getIdpSubject());

    userConfigValidationService.validateUserPreferredLanguage(userPreferredLanguage);

    String idpSubject = user.getIdpSubject();
    String preferredLanguage = userPreferredLanguage.getPreferredLanguage().getValue();

    UserConfiguration uc = userService.getUserConfiguration(idpSubject);
    auditLogService.publishAuditLog(uc.getUserConfigurationId(), false, AuditEventType.UPDATE, () -> {
      UserConfiguration userConfiguration = userService.updateUserLanguage(idpSubject, PreferredLanguageType.valueOf(preferredLanguage));
      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(() -> userConfigurationDataSyncService.asyncOktaUserProfile(user.getIdpUserId(), userConfiguration), false);
      // commenting out as it deletes r2ID from the user profile
      // userConfigurationService.publishUserUpdateMessage(userConfigurationId, userConfiguration);
      return uc;
    });

    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<String> getUserLastUpdatedDate(String userId) {
    String lastUpdatedDate = userService.getUserLastUpdatedDateByIdpSubject(userId);
    return new ResponseEntity<>(lastUpdatedDate, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Void> updateUserStatus(
      Integer userConfigurationId, UpdateUserStatus updateUserStatus) {
    auditLogService.publishAuditLog(userConfigurationId, false, AuditEventType.UPDATE, () -> {
      log.info(
          "updateUserStatus # Start: userId: {} updateUserStatus {}",
          userConfigurationId,
          updateUserStatus);
      userConfigValidationService.validateUpdateUserStatus(updateUserStatus);
      userConfigurationServiceJpa.updateUserStatus(userConfigurationId, updateUserStatus.getStatus());
      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
      return UserConfiguration.builder().userConfigurationId(userConfigurationId).build();
    });

    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Void> refreshAssignment(
      String authorization, String firmId, String assignmentType) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    userAssignmentService.refreshUserAssignment(assignmentType, firmId, user.getIdpSubject());
    userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
    return new ResponseEntity<>(HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Void> assignFeaturePackage(
      Integer userConfigurationId, AssignRequest assignRequest) {
    User user = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal());
    UserConfiguration uc = userService.getUserConfigurationById(userConfigurationId);
    auditLogService.publishAuditLog(userConfigurationId, false, AuditEventType.UPDATE, () -> {
      userAssignmentService.assignFeaturePackageToUser(
          userConfigurationId,
          uc.getIdpSubject(),
          assignRequest.getAssigneeId().longValue(),
          user.getIdpSubject());

      userConfigurationService.setAccessProfileSet(userConfigurationId, true);

      // firm access level logics
      userAssignmentService.applyFirmAccessLevelCheckSp(userConfigurationId, user.getIdpSubject());

      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
      return uc;
    });
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Void> assignFirm(Integer userConfigurationId, AssignRequest assignRequest) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    userConfigValidationService.validateAssignRequest(assignRequest);
    UserConfiguration uc = userService.getUserConfigurationById(userConfigurationId);
    auditLogService.publishAuditLog(userConfigurationId, false, AuditEventType.UPDATE, () -> {
      userAssignmentService.assignFirmToUser(
          userConfigurationId,
          uc.getIdpSubject(),
          assignRequest.getAssigneeId().longValue(),
          user.getIdpSubject());

      userAssignmentService.applyFirmAccessLevelCheckSp(userConfigurationId, user.getIdpSubject());

      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
      return uc;
    });
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Void> assignUserGroup(
      Integer userConfigurationId, AssignRequest assignRequest) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    userConfigValidationService.validateAssignRequest(assignRequest);
    UserConfiguration uc = userService.getUserConfigurationById(userConfigurationId);
    auditLogService.publishAuditLog(userConfigurationId, false, AuditEventType.UPDATE, () -> {
      userAssignmentService.assignUserGroupToUser(
          userConfigurationId,
          uc.getIdpSubject(),
          assignRequest.getAssigneeId().longValue(),
          user.getIdpSubject());
      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
      return uc;
    });
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Void> assignResource(
      Integer userConfigurationId, AssignRequest assignRequest) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    userConfigValidationService.validateAssignRequest(assignRequest);
    UserConfiguration uc = userService.getUserConfigurationById(userConfigurationId);
    auditLogService.publishAuditLog(userConfigurationId, false, AuditEventType.UPDATE, () -> {
      userAssignmentService.assignResourceToUser(
          userConfigurationId,
          uc.getIdpSubject(),
          assignRequest.getAssigneeId().longValue(),
          user.getIdpSubject());
      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
      redisCacheOperationService.deleteUserConfigurationCache(uc);
      redisCacheOperationService.deleteCacheByCacheNameAndPattern(
          Constants.REDIS_USER_RESOURCE_ASSIGNMENTS_BY_RESOURCE_TYPE, uc.getIdpSubject());
      return uc;
    });

    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Void> assignByUserGroupName(
      String idpSubject, UserGroupName userGroupNameRequest) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    userConfigValidationService.validateUserGroupName(userGroupNameRequest);
    UserConfiguration uc = userService.getUserConfiguration(idpSubject);
    auditLogService.publishAuditLog(uc.getUserConfigurationId(), false, AuditEventType.UPDATE, () -> {
      userAssignmentService.assignUserGroupNameToUser(
          uc.getUserConfigurationId(),
          uc.getIdpSubject(),
          userGroupNameRequest.getUserGroupName(),
          user.getIdpSubject());
      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
      redisCacheOperationService.deleteUserConfigurationCacheNoException(uc);
      return uc;
    });
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Void> assignByResourceName(
      String idpSubject, ResourceName resourceNameRequest) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    userConfigValidationService.validateResourceName(resourceNameRequest);
    UserConfiguration uc = userService.getUserConfiguration(idpSubject);
    auditLogService.publishAuditLog(uc.getUserConfigurationId(), false, AuditEventType.UPDATE, () -> {
      userAssignmentService.assignResourceNameToUser(
          uc.getUserConfigurationId(),
          uc.getIdpSubject(),
          resourceNameRequest.getResourceName(),
          user.getIdpSubject());
      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
      redisCacheOperationService.deleteUserConfigurationCacheNoException(uc);
      redisCacheOperationService.deleteCacheByCacheNameAndPattern(
          Constants.REDIS_USER_RESOURCE_ASSIGNMENTS_BY_RESOURCE_TYPE, uc.getIdpSubject());
      return uc;
    });

    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Void> assignByResourceNameDwh(
      String idpSubject, ResourceName resourceNameRequest) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    userConfigValidationService.validateDwhResourceName(resourceNameRequest);
    UserConfiguration uc = userService.getUserConfiguration(idpSubject);
    auditLogService.publishAuditLog(uc.getUserConfigurationId(), false, AuditEventType.UPDATE, () -> {
      userAssignmentService.assignResourceNameToUser(
          uc.getUserConfigurationId(),
          uc.getIdpSubject(),
          resourceNameRequest.getResourceName(),
          user.getIdpSubject());
      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
      redisCacheOperationService.deleteUserConfigurationCacheNoException(uc);
      redisCacheOperationService.deleteCacheByCacheNameAndPattern(
          Constants.REDIS_USER_RESOURCE_ASSIGNMENTS_BY_RESOURCE_TYPE, uc.getIdpSubject());
      return uc;
    });

    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Void> assignRrRange(Integer userConfigurationId, List<RRRange> rrRanges) {
    userConfigValidationService.validateRrRanges(rrRanges);
    UserConfiguration userConfiguration =
        userService.getUserConfigurationWithRrCodeById(userConfigurationId);
    auditLogService.publishAuditLog(userConfigurationId, false, AuditEventType.UPDATE, () -> {
      userAssignmentService.assignRrRangesSp(
          userConfigurationId,
          userConfiguration.getIdpSubject(),
          rrRanges.stream()
              .map(
                  rr -> RRCodeRange.builder()
                      .fromRRCode(rr.getFromRrCode())
                      .toRRCode(rr.getToRrCode())
                      .build())
              .toList(),
          ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
              .getIdpSubject());
      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
      return userConfiguration;
    });

    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Void> deleteUserAssignment(
      Integer userConfigurationId, String assignmentType, Integer assigneeId) {
    userConfigValidationService.validateAssigneeId(assigneeId);
    auditLogService.publishAuditLog(userConfigurationId,false, AuditEventType.UPDATE, () ->{
      userAssignmentService.deleteUserAssignment(
          userService.getUserIdpSubjectById(userConfigurationId), assignmentType, assigneeId);

      UserConfiguration currentUserConfiguration =
          userService.getUserConfigurationByIdOrName(String.valueOf(userConfigurationId));
      User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
      userConfigurationServiceJpa.applyFirmAccessLevelCheck(
          currentUserConfiguration, user.getUsername());

      if (UserAssignmentType.P.equals(UserAssignmentType.valueOf(assignmentType))) {
        userConfigurationService.setAccessProfileSet(userConfigurationId, false);
      }

      redisCacheOperationService.deleteUserConfigurationCacheEnrichUserMeUsersId(
          currentUserConfiguration.getIdpSubject(),
          currentUserConfiguration.getUserConfigurationId());
      redisCacheOperationService.deleteCacheByCacheNameAndPattern(
          Constants.REDIS_USER_RESOURCE_ASSIGNMENTS_BY_RESOURCE_TYPE,
          currentUserConfiguration.getIdpSubject());
      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
      return currentUserConfiguration;
    });

    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<List<UserAssignment>> getUserAssignments(
      Integer userConfigurationId, List<String> assignmentTypes, Boolean active) {
    if (assignmentTypes == null || assignmentTypes.isEmpty()) {
      return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }
    if (!isAssignmentTypeValid(assignmentTypes)) {
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    return new ResponseEntity<>(
        userAssignmentService.getUserAssignments(
            userService.getUserIdpSubjectById(userConfigurationId),
            assignmentTypes,
            active == null || active),
        HttpStatus.OK);
  }

  private boolean isAssignmentTypeValid(List<String> assignmentTypes) {
    if(assignmentTypes == null || assignmentTypes.isEmpty()) {
      return false;
    }
    return assignmentTypes.stream()
      .allMatch(type -> AssignmentTypeEnum.findByCode(type) != null);
  }

  @Override
  public ResponseEntity<List<UserAssignment>> getUserAssignmentsMy(List<String> assignmentTypes, Boolean active) {
    if (assignmentTypes == null || assignmentTypes.isEmpty()) {
      return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }
    if (!isAssignmentTypeValid(assignmentTypes)) {
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    return new ResponseEntity<>(
        userAssignmentService.getUserAssignmentsSp(
            ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
                .getIdpSubject(),
            assignmentTypes,
            active == null || active),
        HttpStatus.OK);
  }

  @Override
  public ResponseEntity<List<UserAssignment>> getUserDwhAssignmentsResources(
      Integer userConfigurationId) {
    log.debug("getUserDwhAssignmentsResources # Start: userConfigurationId: {}", userConfigurationId);
    return new ResponseEntity<>(
        userConfigurationService.getUserDwhAssignmentsResources(userConfigurationId),
        HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Void> clearRedisCache(String cacheName, String key) {
    if (StringUtils.isNoneBlank(cacheName) && StringUtils.isNoneBlank(key)) {
      redisCacheOperationService.deleteCacheByCacheNameAndKey(cacheName, key);
    } else if (StringUtils.isNoneBlank(cacheName)) {
      redisCacheOperationService.deleteCacheByCacheName(cacheName);
    } else {
      redisCacheOperationService.deleteAllUserCache();
    }

    return new ResponseEntity<>(HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Map<String, UserListResponse>> getUserConfigurationByUserIds(
      List<String> idpSubjets) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    Map<String, UserListResponse> response = new HashMap<>();
    List<UserConfiguration> userConfigurations =
        userService.getUserConfigurationByUserIds(idpSubjets, user.getIdpSubject());
    userConfigurations.forEach(
        uc -> response.put(
            uc.getIdpSubject(),
            UserListResponse.builder()
                .firstName(uc.getFirstName())
                .lastName(uc.getLastName())
                .preferredLanguage(uc.getPreferredLanguage())
                .build()));
    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<Void> updateLastLoginDate() {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    userService.updateLastLoginDate(user.getIdpSubject());
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Void> userOktaStatusSync(OktaStatusSyncRequest oktaStatusSyncRequest) {
    userConfigurationDataSyncService.userOktaStatusSync(oktaStatusSyncRequest);
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  /**
   * Phase 1: Creates the user record in the database (DB insert + assignments).
   * This is called inside the CREATE audit wrapper so the CREATE audit event
   * is submitted before any OKTA callback can trigger an UPDATE event.
   */
  private UserConfiguration createUserInDb(User user, UserConfiguration userConfiguration, String idp) {
    if (StringUtils.isBlank(idp) || idp.equalsIgnoreCase("nbin")) {
      userConfiguration.setIdp("nbin");
      if (userConfiguration.getSourceIdpSubject() != null) {
        userConfigurationService.cloneProfile(userConfiguration);
      }
      userConfigValidationService.validateUserCreationMandatoryFields(userConfiguration);
      userConfiguration =
          userConfigurationService.createUserConfigInDatabase(userConfiguration, user.getIdpSubject());
    } else {
      userConfiguration.setIdp(idp);
      userConfigValidationService.validateUserCreationForNonNbin(userConfiguration);
      userConfiguration = userService.createUserForNonNbin(userConfiguration, user.getIdpSubject());
    }

    userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
    return userConfiguration;
  }

  /**
   * Phase 2: Sets up the OKTA profile and publishes the Kafka creation event.
   * Called after the CREATE audit event has been submitted to the async executor.
   * Only applies to NBIN users (non-NBIN users do not have a separate OKTA phase).
   */
  private void completeUserCreation(UserConfiguration userConfiguration, String idp) {
    if (StringUtils.isBlank(idp) || idp.equalsIgnoreCase("nbin")) {
      userConfigurationService.completeUserCreationWithOkta(userConfiguration);
    }
  }

  @Override
  public ResponseEntity<String> getUserPreference(String preferenceId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    String idpSubject = user.getIdpSubject();
    return Optional.ofNullable(userService.getUserConfiguration(idpSubject).getUserPreferences())
        .map(preferences -> preferences.get(preferenceId))
        .map(value -> new ResponseEntity<>(value, HttpStatus.OK))
        .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
  }

  @Override
  public ResponseEntity<Void> updateUserPreference(String preferenceId, UpdateUserPreferenceRequest updateUserPreferenceRequest) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    String idpSubject = user.getIdpSubject();
    String preferencedValue = updateUserPreferenceRequest.getValue();
    UserConfiguration userConfiguration = userService.getUserConfiguration(idpSubject);
    auditLogService.publishAuditLog(userConfiguration.getUserConfigurationId(), false, AuditEventType.UPDATE, () -> {
      // The search-view refresh is handled inside updateUserPreference via a change-aware gate
      // (NWPI-14771 Stage 3); a preference change no longer touches a search-view column.
      userService.updateUserPreference(idpSubject, preferenceId, preferencedValue);
      return userConfiguration;
    });

    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  public ResponseEntity<Void> revokeToken(RevokeJwtRequest revokeJwtRequest) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    List<String> tokens = revokeJwtRequest.getTokens();
    log.info("revokeToken # Start: idpSubject: {}, tokenCount: {}", user.getIdpSubject(), tokens.size());

    for (String token : tokens) {
      if (StringUtils.isBlank(token)) {
        continue;
      }
      tokenRevocationService.revokeToken(token);
    }
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }
}
