package ca.bnc.wealth.api.userconfiguration.controller;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigValidationService;
import ca.bnc.wealth.api.userconfiguration.service.UserService;
import ca.bnc.wealth.common.userconfiguration.api.ValidationApi;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserCredentials;
import ca.bnc.wealth.common.userconfiguration.model.UserDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class UserValidationController implements ValidationApi {

  private final UserConfigValidationService userConfigValidationService;

  private final UserService userService;

  @Autowired
  public UserValidationController(UserConfigValidationService userConfigValidationService, UserService userService) {
    this.userConfigValidationService = userConfigValidationService;
    this.userService = userService;
  }

  @Override
  public ResponseEntity<UserCredentials> getUsernameAndTempPassword(
      String authorization, UserDetails userDetails) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("getUsernameAndTempPassword for {} # Start: UserDetails: {}", user.getIdpSubject(),
        userDetails);
    UserConfiguration uc = userService.getUserConfiguration(user.getIdpSubject());
    if (!"nbin".equals(uc.getIdp())) {
      return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }
    userConfigValidationService.validateUserDetailsMandatoryFields(userDetails);
    return new ResponseEntity<>(userConfigValidationService.getUsernameAndTempPassword(userDetails),
        HttpStatus.OK);
  }
  
}
