package ca.bnc.wealth.api.userconfiguration.dao;

import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.common.ciam.feign.client.*;
import ca.bnc.wealth.common.ciam.model.OktaDeleteMfaFactor;
import ca.bnc.wealth.common.ciam.model.OktaFactorType;
import ca.bnc.wealth.common.ciam.model.OktaNewPassword;
import ca.bnc.wealth.common.ciam.model.OktaSecureZoneId;
import ca.bnc.wealth.common.ciam.model.OktaUserEmail;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.ciam.model.OktaUserRequest;
import ca.bnc.wealth.common.ciam.model.OktaUserWithHashedPasswordRequest;
import ca.bnc.wealth.common.ciam.security.CiamSystemToken;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ErrorSeverity;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ServiceException;
import feign.FeignException;
import java.util.HashMap;
import java.util.List;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

@Slf4j
@Repository
@Setter
public class CiamOktaDao {

  @Autowired CiamSystemToken ciamSystemToken;
  @Autowired DeleteOktaUserGroupClient deleteOktaUserGroupClient;
  @Autowired GetOktaUserGroupsClient getOktaUserGroupsClient;
  @Autowired AddOktaUserGroupClient addOktaUserGroupClient;
  @Autowired CreateOktaUserClient createOktaUserClient;
  @Autowired CreateActiveOktaUserClient createActiveOktaUserClient;
  @Autowired CreateOktaUserWithHashedPasswordClient createOktaUserWithHashedPasswordClient;
  @Autowired CreateActiveOktaUserWithHashedPasswordClient createActiveOktaUserWithHashedPasswordClient;
  @Autowired DeleteOktaUserClient deleteOktaUserClient;
  @Autowired UnlockOktaUserClient unlockOktaUserClient;
  @Autowired GetOktaUserProfileClient userOktaProfileClient;
  @Autowired SetOktaUserTempPasswordClient oktaUserTempPasswordClient;
  @Autowired DeleteOktaUserMfaFactorClient deleteOktaUserMfaFactorClient;
  @Autowired SetOktaUserTempPasswordClient setOktaUserTempPasswordClient;
  @Autowired SuspendOktaUserProfileClient suspendOktaUserProfileClient;
  @Autowired UnsuspendOktaUserProfileClient unsuspendOktaUserProfileClient;
  @Autowired UpdateOktaSecureZoneIdClient updateOktaSecureZoneIdClient;
  @Autowired SyncOktaUserProfileClient syncOktaUserProfileClient;
  @Autowired UpdateOktaUserEmailClient updateOktaUserEmailClient;

  @Value("${feign.ciamApi.context}")
  private String ciamContext;

  public OktaUserProfile getOktaUserProfile(String idpUserId) {
    log.info("Getting okta profile of user {}", idpUserId);
    OktaUserProfile oktaUserProfile = null;
    try {
      String bearerToken = ciamSystemToken.getBearerToken();
      oktaUserProfile =
          userOktaProfileClient.getOktaUserProfile(bearerToken, ciamContext, idpUserId);
    } catch (FeignException.NotFound e) {
      log.error("Okta profile {} not found", idpUserId);
      return null;
    } catch (Exception e) {
      log.error("Error getting {} profile from Okta with error: {}", idpUserId, e.getMessage());
      throw new ServiceException(
          ErrorSeverity.ERROR, "Error getting user profile from Okta for " + idpUserId);
    }
    log.info("Okta profile {} ", oktaUserProfile);
    return oktaUserProfile;
  }

  public void createOktaUser(OktaUserRequest oktaUserRequest) {
    log.info("Creating okta profile of user {}", oktaUserRequest.getAccessProfile().getUsername());
    String bearerToken = ciamSystemToken.getBearerToken();
    try {
      createOktaUserClient.createOktaUser(bearerToken, ciamContext, oktaUserRequest);
    } catch (Exception e) {
      log.error("Error creating user in Okta with error: {}", e.getMessage());
      throw new FumServiceException(Constants.ERROR_OKTA_PROFILE_CREATION, "Error creating user in Okta");
    }
  }

  public void createActiveOktaUser(OktaUserRequest oktaUserRequest) {
    log.info(
        "Creating active okta profile of user {}",
        oktaUserRequest.getAccessProfile().getUsername());
    String bearerToken = ciamSystemToken.getBearerToken();
    try {
      createActiveOktaUserClient.createOktaUser(bearerToken, ciamContext, oktaUserRequest);
    } catch (Exception e) {
      log.error("Error creating active user in Okta with error: {}", e.getMessage());
      throw new FumServiceException(Constants.ERROR_OKTA_PROFILE_CREATION, "Error creating active user in Okta");
    }
  }

  public void createOktaUserWithHashedPassword(OktaUserWithHashedPasswordRequest oktaUserRequest) {
    log.info("Creating okta profile with hashed password of user {}", usernameOf(oktaUserRequest));
    String bearerToken = ciamSystemToken.getBearerToken();
    try {
      createOktaUserWithHashedPasswordClient.createOktaUserWithHashedPassword(
          bearerToken, ciamContext, oktaUserRequest);
    } catch (Exception e) {
      log.error("Error creating user with hashed password in Okta with error: {}", e.getMessage());
      throw new FumServiceException(Constants.ERROR_OKTA_PROFILE_CREATION, Constants.ERROR_OKTA_PROFILE_HASH_CREATION_MESSAGE);
    }
  }

  public void createActiveOktaUserWithHashedPassword(OktaUserWithHashedPasswordRequest oktaUserRequest) {
    log.info("Creating active okta profile with hashed password of user {}", usernameOf(oktaUserRequest));
    String bearerToken = ciamSystemToken.getBearerToken();
    try {
      createActiveOktaUserWithHashedPasswordClient.createOktaUserWithHashedPassword(
          bearerToken, ciamContext, oktaUserRequest);
    } catch (Exception e) {
      log.error(Constants.ERROR_OKTA_PROFILE_HASH_CREATION_MESSAGE, e);
      throw new FumServiceException(Constants.ERROR_OKTA_PROFILE_CREATION, Constants.ERROR_OKTA_PROFILE_HASH_CREATION_MESSAGE);
    }
  }

  private static String usernameOf(OktaUserWithHashedPasswordRequest oktaUserRequest) {
    return oktaUserRequest.getAccessProfile() == null ? null : oktaUserRequest.getAccessProfile().getUsername();
  }

  public void deleteOktaUser(String idpUserId) {
    log.info("Deleting okta profile of user {}", idpUserId);
    String bearerToken = ciamSystemToken.getBearerToken();
    try {
      deleteOktaUserClient.deleteOktaUser(bearerToken, ciamContext, idpUserId);
    } catch (Exception e) {
      log.error("Error deleting user in Okta with error: {}", e.getMessage());
      throw new ServiceException(ErrorSeverity.ERROR, "Error deleting user in Okta");
    }
  }

  public void unlockOktaUser(String idpUserId) {
    log.info("Unlocking okta profile of user {}", idpUserId);
    String bearerToken = ciamSystemToken.getBearerToken();
    try {
      unlockOktaUserClient.unlockOktaUser(bearerToken, ciamContext, idpUserId);
    } catch (Exception e) {
      log.error("Error unlocking user in Okta with error: {}", e.getMessage());
      throw new ServiceException(ErrorSeverity.ERROR, "Error unlocking user in Okta");
    }
  }

  public void setOktaTempPassword(String idpUserId, OktaNewPassword tempPassword) {
    log.info("Setting temporary password for okta profile of user {}", idpUserId);
    String bearerToken = ciamSystemToken.getBearerToken();
    try {
      oktaUserTempPasswordClient.setOktaUserTempPassword(
          bearerToken, ciamContext, idpUserId, tempPassword);
    } catch (Exception e) {
      log.error("Error setting temp password for {} in Okta with error: {}", idpUserId, e.getMessage());
      throw new ServiceException(ErrorSeverity.ERROR, "Error setting temp password in Okta");
    }
  }

  public List<String> getUserOktaGroups(String idpUserId) {
    log.info("Getting user group of user {} from Okta", idpUserId);
    String bearerToken = ciamSystemToken.getBearerToken();
    List<String> groupsInOkta = null;
    ResponseEntity<Object> responseEntity = null;
    try {
      responseEntity =
          getOktaUserGroupsClient.getOktaUserGroups(bearerToken, ciamContext, idpUserId);
      HashMap responseBody = (HashMap) responseEntity.getBody();
      if (responseBody != null) {
        groupsInOkta = (List<String>) responseBody.get("groupNames");
      }
    } catch (Exception e) {
      log.error("Error getting groups from Okta with error: {}", e.getMessage());
      throw new ServiceException(ErrorSeverity.ERROR, "Error get user groups from Okta");
    }

    return groupsInOkta;
  }

  public void addOktaUserGroup(String idpUserId, String groupName) {
    log.info("Adding user group for user {} in Okta", idpUserId);
    String bearerToken = ciamSystemToken.getBearerToken();
    try {
      addOktaUserGroupClient.addUserGroup(bearerToken, ciamContext, groupName, idpUserId);
    } catch (Exception e) {
      log.error("Error adding {} group to Okta for {} with error: {}", groupName, idpUserId, e.getMessage());
      throw new ServiceException(ErrorSeverity.ERROR, "Error adding user group to Okta");
    }
  }

  public void deleteOktaUserGroup(String idpUserId, String groupName) {
    log.info("Deleting user group from user's Okta profile for {}", idpUserId);
    String bearerToken = ciamSystemToken.getBearerToken();
    try {
      deleteOktaUserGroupClient.deleteOktaUserGroup(bearerToken, ciamContext, groupName, idpUserId);
    } catch (Exception e) {
      log.error("Error deleting {} group from Okta for {} with error: {}", groupName, idpUserId, e.getMessage());
      throw new ServiceException(ErrorSeverity.ERROR, "Error deleting user group from Okta");
    }
  }

  public void deleteOktaUser2fa(String idpUserId) {
    log.info("Deleting User mfa factor (sms) from user's Okta profile for {}", idpUserId);
    String bearerToken = ciamSystemToken.getBearerToken();
    try {
      OktaDeleteMfaFactor oktaDeleteMfaFactor =
          OktaDeleteMfaFactor.builder().factorType(OktaFactorType.SMS.getFactorType()).build();
      deleteOktaUserMfaFactorClient.deleteOktaUserMfaFactor(
          bearerToken, ciamContext, idpUserId, oktaDeleteMfaFactor);
    } catch (Exception e) {
      log.error("Error deleting user mfa factor (sms) in Okta with error: {}", e.getMessage());
      throw new ServiceException(
          ErrorSeverity.ERROR, "Error deleting user mfa factor (sms) in Okta");
    }
  }

  public void resetPassword(String userId, OktaNewPassword newPassword) {
    log.info("Resetting password for user's Okta profile for {}", userId);
    String bearerToken = ciamSystemToken.getBearerToken();
    setOktaUserTempPasswordClient.setOktaUserTempPassword(
        bearerToken, ciamContext, userId, newPassword);
  }

  public void suspendUserOktaProfile(String idpUserId) {
    log.info("Suspending user's Okta profile for {}", idpUserId);
    String bearerToken = ciamSystemToken.getBearerToken();
    try {
      suspendOktaUserProfileClient.suspendOktaUserProfile(bearerToken, ciamContext, idpUserId);
    } catch (Exception e) {
      log.error("Error suspending user's Okta profile for {} with error: {}", idpUserId, e.getMessage());
      throw new ServiceException(ErrorSeverity.ERROR, "Error suspending user Okta profile");
    }
  }

  public void unsuspendUserOktaProfile(String idpUserId) {
    log.info("Unsuspending user's Okta profile for {}", idpUserId);
    String bearerToken = ciamSystemToken.getBearerToken();
    try {
      unsuspendOktaUserProfileClient.unsuspendOktaUserProfile(bearerToken, ciamContext, idpUserId);
    } catch (Exception e) {
      log.error("Error unsuspending user's Okta profile for {} with error: {}", idpUserId, e.getMessage());
      throw new ServiceException(ErrorSeverity.ERROR, "Error unsuspending user Okta profile");
    }
  }

  public void updateOktaSecureZoneId(String idpUserId, String[] secureZoneIds) {
    log.info("Updating secureZoneId for user's Okta profile for {}", idpUserId);
    String bearerToken = ciamSystemToken.getBearerToken();
    try {
      OktaSecureZoneId oktaSecureZoneId = new OktaSecureZoneId();
      oktaSecureZoneId.setSecureZoneId(secureZoneIds);
      updateOktaSecureZoneIdClient.updateOktaSecureZoneId(
          bearerToken, ciamContext, idpUserId, oktaSecureZoneId);
    } catch (Exception e) {
      log.error("Error updating secureZoneId for user's Okta profile for {} with error: {}", idpUserId, e.getMessage());
      throw new ServiceException(
          ErrorSeverity.ERROR, "Error updating secureZoneId for user's Okta profile");
    }
  }

  public void syncOktaUserProfile(String idpUserId) {
    log.info("Syncing user's Okta profile for {}", idpUserId);
    String bearerToken = ciamSystemToken.getBearerToken();
    try {
      syncOktaUserProfileClient.syncOktaUserProfile(bearerToken, ciamContext, idpUserId);
    } catch (Exception e) {
      log.error("Error syncing user's Okta profile for {} with error: {}", idpUserId, e.getMessage());
      throw new ServiceException(ErrorSeverity.ERROR, "Error syncing user Okta profile");
    }
  }

  public void updateOktaUserEmail(String idpUserId, OktaUserEmail oktaUserEmail) {
    log.info("Updating user's Okta email for {}", idpUserId);
    String bearerToken = ciamSystemToken.getBearerToken();
    try {
      updateOktaUserEmailClient.updateOktaUserEmail(
          bearerToken, ciamContext, idpUserId, oktaUserEmail, true);
    } catch (Exception e) {
      log.error("Error updating user's Okta email for {} with error: {}", idpUserId, e.getMessage());
      throw new ServiceException(ErrorSeverity.ERROR, "Error updating user's Okta email");
    }
  }
}
