package ca.bnc.wealth.api.userconfiguration.dao;

public class Querys {

  public static final String SP_ASSIGN_RR_CODE_TO_USER =
      "CALL \"PLATFORM\".SP_ASSIGN_RR_CODE_TO_USER(:rrCode,:userConfigurationId,:updatedBy)";
  public static final String SP_ASSIGN_RR_RANGE_TO_USER =
      "CALL \"PLATFORM\".SP_ASSIGN_RR_RANGE_TO_USER(:fromRRCode,:toRRCode,:userConfigurationId, :updatedBy)";
  public static final String DELETE_USER_RR_RANGE_ASSIGNMENT =
      "delete from \"PLATFORM\".\"RR_CODE_RANGE_ASSIGNMENT\" where \"RR_CODE_RANGE_ENTITY_ID\" = :userConfigurationId and \"RR_ASSIGNMENT_TYPE_CODE_ID\" = (select \"CODE_VALUE_MAPPING_ID\" from \"PLATFORM\".\"CODE_VALUE_MAPPING\" where \"CODE_TYPE\" = 'RRCODE_ASSIGNMENT_TYPE' and \"CODE_VALUE\" = 'U')";

  private Querys() {
    throw new IllegalStateException("Utility class");
  }
}
