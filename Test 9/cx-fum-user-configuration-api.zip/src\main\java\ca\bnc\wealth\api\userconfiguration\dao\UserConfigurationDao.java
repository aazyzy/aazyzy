package ca.bnc.wealth.api.userconfiguration.dao;

import ca.bnc.wealth.api.userconfiguration.model.UserConfigurationConstants;
import ca.bnc.wealth.api.userconfiguration.util.UserUpdateQueryBuilder;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

@Slf4j
@Repository
public class UserConfigurationDao {

  private final NamedParameterJdbcTemplate template;

  public UserConfigurationDao(
      @Qualifier("postgresJdbcTemplate") NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
    this.template = namedParameterJdbcTemplate;
  }

  public void deleteUserRRCodesByUserConfigurationId(Integer userConfigurationId) {
    log.info("deleteUserRRCodesByUserConfigurationId: userConfigurationId:{}", userConfigurationId);
    SqlParameterSource parameters =
        new MapSqlParameterSource()
            .addValue(UserConfigurationConstants.USER_CONFIGURATION_ID, userConfigurationId);
    template.update(Querys.DELETE_USER_RR_RANGE_ASSIGNMENT, parameters);
  }

  public void updateUserLastUpdateDate(Integer userConfigurationId, String idpSubject) {
    UserUpdateQueryBuilder userUpdateQueryBuilder = new UserUpdateQueryBuilder(userConfigurationId);
    userUpdateQueryBuilder.updateLastUpdatedBy(idpSubject);

    String queryString = userUpdateQueryBuilder.getUserUpdateQuery().userUpdateQuery.toString();
    template.update(queryString, userUpdateQueryBuilder.getUserUpdateQuery().parameters);
  }

  public void updateUserRRRange(
      RRCodeRange rrCodeRange, Integer userConfigurationId, String updatedBy) {
    log.info("Assigning rr range {} to user {}", rrCodeRange, userConfigurationId);
    SqlParameterSource params =
        new MapSqlParameterSource()
            .addValue(UserConfigurationConstants.FROM_RR_CODE, rrCodeRange.getFromRRCode())
            .addValue(UserConfigurationConstants.TO_RR_CODE, rrCodeRange.getToRRCode())
            .addValue(UserConfigurationConstants.USER_CONFIGURATION_ID, userConfigurationId)
            .addValue(UserConfigurationConstants.UPDATED_BY, updatedBy);
    template.update(Querys.SP_ASSIGN_RR_RANGE_TO_USER, params);
  }

}
