package ca.bnc.wealth.api.userconfiguration.jpa;

import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.jpa.utils.GenericQuery;
import jakarta.persistence.criteria.JoinType;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum UserSearchCriteria implements GenericQuery {
  userConfigurationId(EnumQueryCriteria.EQUALS, "userConfigurationId", null, null),
  idpSubject(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "idpSubject", null, null),
  idpUserId(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "idpUserIdentifier", null, null),
  username(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "username", null, null),
  firstName(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "firstName", null, null),
  lastName(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "lastName", null, null),
  email(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "email", null, null),
  ossId(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "ossUserId", null, null), //TODO Will be deprecated
  ossProxyId(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "ossGroupId", null,
      null), //TODO Will be deprecated
  ossUserId(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "ossUserId", null, null),
  ossGroupId(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "ossGroupId", null, null),
  statusCode(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "state", null, null),
  userAssignmentGroup(EnumQueryCriteria.EQUALS_CHARACTER, "userAssignmentUserGroups.assignmentType",
      UserAssignmentType.G.name(), new JoinType[]{JoinType.LEFT}),
  userGroup(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "userAssignmentUserGroups.userGroup.name",
      null, new JoinType[]{JoinType.LEFT, JoinType.LEFT}),
  isFirmScope(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "userAssignmentUserGroups.userGroup.isFirmScope",
      null, new JoinType[]{JoinType.LEFT, JoinType.LEFT}),
  userAssignmentRrCode(EnumQueryCriteria.EQUALS_CHARACTER, "userAssignmentRrCodeRanges.assignmentType", UserAssignmentType.R.name(), new JoinType[]{JoinType.LEFT}),
  fromRRCode(EnumQueryCriteria.IGNORE_CASE_CONTAINS,
      "userAssignmentRrCodeRanges.iamRrCodeRange.fromRrCode", null,
      new JoinType[]{JoinType.LEFT, JoinType.LEFT}),
  toRRCode(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "userAssignmentRrCodeRanges.iamRrCodeRange.toRrCode",
      null, new JoinType[]{JoinType.LEFT, JoinType.LEFT}),
  rRCodeLessThanOrEqual(EnumQueryCriteria.LESS_THAN_OR_EQUAL,
      "userAssignmentRrCodeRanges.iamRrCodeRange.fromRrCodeB10", null,
      new JoinType[]{JoinType.LEFT, JoinType.LEFT}),
  rRCodeGreaterThanOrEqual(EnumQueryCriteria.GREATER_THEN_OR_EQUAL,
      "userAssignmentRrCodeRanges.iamRrCodeRange.toRrCodeB10", null,
      new JoinType[]{JoinType.LEFT, JoinType.LEFT}),
  userAssignmentFirm(EnumQueryCriteria.EQUALS_CHARACTER, "userAssignmentFirms.assignmentType",
      UserAssignmentType.F.name(), null),
  firmEntityIdsIN(EnumQueryCriteria.IN,
      "userAssignmentFirms.firm.firmEntityId", null, null);


  private EnumQueryCriteria criteria;
  private String field;
  private Object defaultValue;
  private JoinType[] joinTypes;

  @Override
  public EnumQueryCriteria getCriteria() {
    return this.criteria;
  }

  @Override
  public String getEntityField() {
    return this.field;
  }

  @Override
  public Object getDefaultValue() {
    return this.defaultValue;
  }

  @Override
  public JoinType[] getJoinTypes() {
    return this.joinTypes;
  }
}