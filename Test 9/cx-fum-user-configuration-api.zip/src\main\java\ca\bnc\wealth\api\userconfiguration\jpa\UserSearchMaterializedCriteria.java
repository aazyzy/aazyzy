package ca.bnc.wealth.api.userconfiguration.jpa;

import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.jpa.utils.GenericQuery;
import jakarta.persistence.criteria.JoinType;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum UserSearchMaterializedCriteria implements GenericQuery {
  USER_CONFIGURATION_ID(EnumQueryCriteria.EQUALS, "userConfigurationId", null, null),
  IDP_SUBJECT(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "idpSubject", null, null),
  IDP_USER_ID(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "idpUserIdentifier", null, null),
  IDP(EnumQueryCriteria.IGNORE_CASE_EQUALS, "idp", null, null),
  ACCESS_PROFILE_SET(EnumQueryCriteria.EQUALS, "accessProfileSet", null, null),
  USERNAME(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "username", null, null),
  FIRST_NAME(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "firstName", null, null),
  LAST_NAME(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "lastName", null, null),
  EMAIL(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "email", null, null),
  ACTIVE(EnumQueryCriteria.EQUALS, "active", null, null),
  OSS_ID(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "ossUserId", null, null), //TODO Will be deprecated
  OSS_PROXY_ID(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "ossGroupId", null, null),//TODO Will be deprecated
  OSS_USER_ID(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "ossUserId", null, null),
  OSS_GROUP_ID(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "ossGroupId", null, null),
  STATE(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "state", null, null),
  STATE_ACTION(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "stateAction", null, null),
  STATE_DESCRIPTIION(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "stateDescription", null, null),
  USER_GROUP(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "userGroupName", null, null),
  RR_RANGES(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "rrRanges", null, null),
  FIRM_ENTITY_IDS_IN(EnumQueryCriteria.IN,Constants.FIRM_ENTITY_ID, null, null),

  //used for primary firm search
  FIRM_ID_EQUALS(EnumQueryCriteria.EQUALS, Constants.FIRM_ENTITY_ID, null, null),

  //used for not primary firm search
  FIRM_ID_NOT_EQUALS(EnumQueryCriteria.NOT_EQUALS, Constants.FIRM_ENTITY_ID, null, null),

  SOURCE_NBX(EnumQueryCriteria.IGNORE_CASE_EQUALS, "source", null, null),
  SOURCE_NOT_NBX(EnumQueryCriteria.IGNORE_CASE_NOT_EQUALS, "source", null, null),
  SOURCE_CX(EnumQueryCriteria.NOT_EQUALS, "source", null, null);

  private EnumQueryCriteria criteria;
  private String field;
  private Object defaultValue;
  private JoinType[] joinTypes;

  @Override
  public EnumQueryCriteria getCriteria() {
    return criteria;
  }

  @Override
  public String getEntityField() {
    return field;
  }

  @Override
  public Object getDefaultValue() {
    return defaultValue;
  }

  @Override
  public JoinType[] getJoinTypes() {
    return this.joinTypes;
  }
}
