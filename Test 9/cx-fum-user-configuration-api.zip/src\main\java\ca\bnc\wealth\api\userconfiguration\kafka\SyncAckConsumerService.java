package ca.bnc.wealth.api.userconfiguration.kafka;

import ca.bnc.wealth.common.kafka.core.subscriber.Subscriber;
import ca.bnc.wealth.common.kafka.core.subscriber.SubscriberFactory;
import tools.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class SyncAckConsumerService {

  private final SubscriberFactory subscriberFactory;

  private final ObjectMapper objectMapper;

  @Value("${kafka.consumer.sync-ack-group-id}")
  private String consumerGroupId;

  @Value("${kafka.consumer.sync-ack-config}")
  private String consumerName;

  @Value("${kafka.consumers.SyncAckConfigMF.topic}")
  private String topicName;

  @Autowired
  public SyncAckConsumerService(SubscriberFactory subscriberFactory, ObjectMapper objectMapper) {
    this.subscriberFactory = subscriberFactory;
    this.objectMapper = objectMapper;
  }

  @PostConstruct
  public void init() {
    subscribeToSyncAckConfig();
  }

  private void subscribeToSyncAckConfig() {
    Subscriber<String, String> subscriber = subscriberFactory.createNewSubscriber(consumerName,
        consumerGroupId, consumerRecord -> processMessage(consumerRecord.value()));
    subscriber.subscribe();
  }

  @SneakyThrows
  public void processMessage(Object syncAckMessage) {
    log.info("Message received from topic {}: {}", topicName,
        objectMapper.writeValueAsString(syncAckMessage));
  }
}
