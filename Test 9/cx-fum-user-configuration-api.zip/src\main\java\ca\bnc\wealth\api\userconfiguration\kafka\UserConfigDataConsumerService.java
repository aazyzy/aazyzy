package ca.bnc.wealth.api.userconfiguration.kafka;

import ca.bnc.wealth.api.userconfiguration.model.UserConfigurationConstants;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigurationService;
import ca.bnc.wealth.api.userconfiguration.util.MapperUtils;
import ca.bnc.wealth.common.kafka.core.subscriber.Subscriber;
import ca.bnc.wealth.common.kafka.core.subscriber.SubscriberFactory;
import ca.bnc.wealth.common.kafka.model.EventMessages;
import ca.bnc.wealth.common.kafka.model.Header;
import ca.bnc.wealth.common.kafka.model.user.UserConfigDataPayLoad;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ErrorSeverity;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ServiceException;
import tools.jackson.databind.JavaType;
import tools.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import tools.jackson.core.JacksonException;

@Slf4j
@Service
public class UserConfigDataConsumerService {

  private final SubscriberFactory subscriberFactory;
  private final UserConfigurationService userConfigurationService;
  private final ObjectMapper objectMapper;

  @Value("${kafka.consumer.group-id}")
  private String consumerGroupId;

  @Value("${kafka.consumer.userconfig}")
  private String consumerName;


  @Autowired
  public UserConfigDataConsumerService(SubscriberFactory subscriberFactory,
      UserConfigurationService userConfigurationService, ObjectMapper objectMapper) {
    this.subscriberFactory = subscriberFactory;
    this.userConfigurationService = userConfigurationService;
    this.objectMapper = objectMapper;
  }

  @PostConstruct
  public void init() {
    subscribeToUserConfig();
  }

  public void subscribeToUserConfig() {
    Subscriber<String, String> subscriber = subscriberFactory.createNewSubscriber(consumerName,
        consumerGroupId, consumerRecord -> processMessage(consumerRecord.value()));
    subscriber.subscribe();
  }

  public void processMessage(String message) {
    try {
      if (StringUtils.isEmpty(message)) {
        throw new ServiceException(ErrorSeverity.ERROR, "User config message is empty!");
      }

      log.info("User config message received : messageSize={}", message.length());
      Optional<EventMessages<UserConfigDataPayLoad>> optional = parseJson(message);
      if (optional.isEmpty()) {
        throw new ServiceException(ErrorSeverity.ERROR,
            "Unable to deserialize the user config message");
      }

      EventMessages<UserConfigDataPayLoad> eventMessages = optional.get();
      Optional<String> operation = Optional.ofNullable(eventMessages.getHeader())
          .map(Header::getAction);
      if (operation.isEmpty()) {
        log.error("Action in the Header is empty");
        throw new ServiceException(ErrorSeverity.ERROR, "Action in the Header is empty");
      }

      Optional<String> idpSubject = Optional.ofNullable(eventMessages.getHeader())
          .map(Header::getRefId);
      if (idpSubject.isEmpty()) {
        log.error("Ref ID in the Header is empty");
        throw new ServiceException(ErrorSeverity.ERROR, "Ref ID in the Header is empty");
      }

      if (operation.get().equals(UserConfigurationConstants.UPDATE_USERCONFIG_API)) {
        userConfigurationService.updateUserRrCodeRangesBySubjectId(idpSubject.get(),
            MapperUtils.toDto(eventMessages.getPayload().getRrCodeRanges()));
        log.info("User {} has been updated successfully", idpSubject.get());
      }
    } catch (Exception e) {
      log.error("KAFKA_DESERIALIZATION_FAILED: messageSize={}, error={}",
          message == null ? 0 : message.length(), e.getMessage());
    }
  }

  private <T> Optional<T> parseJson(String jsonString) {
    try {
      JavaType type = objectMapper.getTypeFactory()
          .constructParametricType(EventMessages.class, UserConfigDataPayLoad.class);
      return Optional.ofNullable(objectMapper.readValue(jsonString, type));
    } catch (IllegalArgumentException | JacksonException e) {
      log.error("KAFKA_DESERIALIZATION_FAILED: messageSize={}, error={}",
          jsonString == null ? 0 : jsonString.length(), e.getMessage());
      return Optional.empty();
    }
  }
}
