package ca.bnc.wealth.api.userconfiguration.kafka;

import ca.bnc.wealth.common.kafka.core.config.KafkaConfiguration;
import ca.bnc.wealth.common.kafka.core.publisher.ProducerProperty;
import ca.bnc.wealth.common.kafka.core.publisher.Publisher;
import ca.bnc.wealth.common.kafka.messaging.publisher.EventMessagePublisherFactory;
import ca.bnc.wealth.common.kafka.model.EventMessages;
import ca.bnc.wealth.common.kafka.model.user.UserConfigEventPayLoad;
import tools.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import tools.jackson.core.JacksonException;

@Service
@Slf4j
public class UserConfigEventProducerService {

  private final EventMessagePublisherFactory publisherFactory;
  private final ObjectMapper objectMapper;
  private final KafkaConfiguration kafkaConfiguration;

  protected Publisher<String, String> eventPublisher;

  @Value("${kafka.producer.eventUserconfig}")
  private String producerName;

  @Autowired
  public UserConfigEventProducerService(EventMessagePublisherFactory publisherFactory,
      ObjectMapper objectMapper, KafkaConfiguration kafkaConfiguration) {
    this.publisherFactory = publisherFactory;
    this.objectMapper = objectMapper;
    this.kafkaConfiguration = kafkaConfiguration;
  }

  @PostConstruct
  public void init() {
    ProducerProperty producerProperty = (ProducerProperty)this.kafkaConfiguration.getProducers().get(producerName);
    log.info("property info::" + producerProperty);
    this.eventPublisher = publisherFactory.createNewPublisher(producerName);

  }

  public void publishMessage(EventMessages<UserConfigEventPayLoad> eventMessages) {
    try {
      log.info("Publishing message to Kafka:{}", objectMapper.writeValueAsString(eventMessages));
      Optional<SendResult<String, String>> sendResult = eventPublisher.publishSynchronous(
          objectMapper.writeValueAsString(eventMessages));
      log.info("Published message successfully to Kafka:{} ", sendResult.toString());
    } catch (ExecutionException | TimeoutException | JacksonException e) {
      // TODO: In the future we will introduce a better mechanism to handle Kafka errors
      log.error("Failed to publish message to Kafka with error: {}", e.getMessage());
    }
  }
}
