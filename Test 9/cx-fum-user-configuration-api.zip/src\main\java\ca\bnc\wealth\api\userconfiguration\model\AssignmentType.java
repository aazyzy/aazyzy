package ca.bnc.wealth.api.userconfiguration.model;

import java.util.Arrays;
import java.util.Optional;
import lombok.Getter;

@Getter
public enum AssignmentType {
  R("rr-range"),
  P("feature-package"),
  F("firm"),
  S("resource"),
  G("user-group"),
  Ro("role"),
  Pe("permission");

  private final String description;

  AssignmentType(String description) {
    this.description = description;
  }

  public static Optional<AssignmentType> createInstance(String stringValue) {
    Optional<AssignmentType> type = Arrays.stream(AssignmentType.values())
        .filter(value -> value.description.equals(stringValue))
        .findFirst();
    if (type.isPresent()) {
      return type;
    }
    return Arrays.stream(AssignmentType.values())
        .filter(value -> value.name().equalsIgnoreCase(stringValue))
        .findFirst();
  }
}
