package ca.bnc.wealth.api.userconfiguration.model;

public enum EnumCxpStatus {
  Active("Active"),Inactive("Inactive"),Pending_Activation("Pending Activation"),
  Locked_Out("Locked Out"),New("New"),Onboarding("Onboarding"),Update_Pending("Update Pending");

  private String cxpStatus;
  EnumCxpStatus(String cxpStatus) {
    this.cxpStatus = cxpStatus;
  }

  public String getCxpStatus() {
    return  this.cxpStatus;
  }
}
