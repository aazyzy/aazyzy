package ca.bnc.wealth.api.userconfiguration.model;

public enum EnumCxpSubStatus {
  Active("Active"),RecoveryQuestionPending("RecoveryQuestionPending"),LockedOut("LockedOut"), PasswordExpired("PasswordExpired"),PasswordReset("PasswordReset"),
  RRCodeUpdated("RRCodeUpdated"),UserGroupUpdated("UserGroupUpdated"),SZIdUpdated("SZIdUpdated"),Submitted("Submitted"), Rejected("Rejected"), Created("Created"),
  FAPending("2FAPending"), FAActive("2FAActive"),FAReset("2FAReset"),Suspended("Suspended"),Disabled("Disabled");

    private String cxpSubStatus;

  EnumCxpSubStatus(String cxpSubStatus) {
    this.cxpSubStatus = cxpSubStatus;
  }

  public String getCxpSubStatus() {
    return this.cxpSubStatus;
  }
}
