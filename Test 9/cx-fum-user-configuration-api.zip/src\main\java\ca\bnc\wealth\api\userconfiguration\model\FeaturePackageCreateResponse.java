package ca.bnc.wealth.api.userconfiguration.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class FeaturePackageCreateResponse {
    private Long featurePackageId;
}
