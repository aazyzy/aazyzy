package ca.bnc.wealth.api.userconfiguration.model;

public enum R2userStatus {
  NOT_FOUND, WITH_CPX_SUB, WITHOUT_CPX_SUB
}
