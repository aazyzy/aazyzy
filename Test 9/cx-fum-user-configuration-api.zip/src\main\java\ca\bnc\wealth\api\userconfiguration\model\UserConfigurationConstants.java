package ca.bnc.wealth.api.userconfiguration.model;

public class UserConfigurationConstants {

  public static final String USERNAME_PREFIX_ERROR = "Username prefix can't be greater than 999";
  public static final String USERNAME_MAX_LENGTH_ERROR = "Username can't be more than 255 char";
  public static final String TEMP_PASSWORD_GENERATION_ERROR =
      "Unable to generage temp password please try again";
  public static final String EMAIL_ID_NOT_UNIQUE = "Email Id is not Unique";
  public static final int USERNAME_MAX_LENGTH = 255;
  public static final int FIELD_MAX_LENGTH = 100;
  public static final int TEMP_PASSWORD_GENERATION_ATTEMPTS = 100;
  public static final int PREFIX_MAX = 999;
  public static final String IDP_USER_SUB = "idpSubject";
  public static final String USER_CONFIGURATION_ID = "userConfigurationId";
  public static final String GROUP_NAME_LIST = "groupNameList";
  public static final String USER_GROUP = "userGroup";
  public static final String RR_CODE = "rrCode";
  public static final String FROM_RR_CODE = "fromRRCode";
  public static final String TO_RR_CODE = "toRRCode";
  public static final String UPDATED_BY = "updatedBy";
  public static final String CREATED_BY = "createdBy";
  public static final String FIRM_ID = "firmId";
  public static final String IDP_USER_ID = "idpUserId";
  public static final String IDP = "idp";
  public static final String USER_NAME = "userName";
  public static final String OSS_USER_ID = "ossUserId";
  public static final String OSS_GROUP_ID = "ossGroupId";
  public static final String FIRST_NAME = "firstName";
  public static final String LAST_NAME = "lastName";
  public static final String PREFERRED_LANGUAGE_CODE_ID = "preferredLanguageCodeId";
  public static final String EMAIL = "email";
  public static final String ACTIVE = "active";
  public static final String CREATION_DATE = "creationDate";
  public static final String LAST_UPDATED_BY = "lastUpdatedBy";
  public static final String LAST_UPDATED_DATE = "lastUpdatedDate";
  public static final String BNGF_IDENTITY_SOURCE = "CPX";
  public static final String ACTIVE_Y =
      "Y"; // TODO Change we switch to Enums for tracking various status
  public static final String ACTIVE_N = "N";
  public static final String FACTOR_MFA_SMS = "sms";
  public static final String STATUS = "status";
  public static final String STATE = "state";
  public static final String USERROLETYPE = "userRoleType";
  public static final String UPDATE_USERCONFIG_API = "update";
  public static final String CREATE_USERCONFIG_API = "create";
  public static final String KAFKA_HEADER_STATE = "complete";
  public static final String KAFKA_HEADER_REASON_UPDATE = "data-update";
  public static final String KAFKA_HEADER_VERSION = "1.1";
  public static final String KAFKA_HEADER_TAGS_CHANGESET_DATAACCESS = "data-access";
  public static final String KAFKA_HEADER_REASON_STATETRANSITION = "state-transition";
  public static final String KAFKA_PAYLOAD_EVENT_TYPE = "/wm/access-control/compass-x/user-conf";
  public static final String KAFKA_MSG_ORIGIN_SYSTEM = "nbin.cx.user-management";
  public static final String KAFKA_MSG_ORIGIN_SYSTEM_ID = "6588";
  public static final String KAFKA_MSG_PUBLISHER_SYSTEM = "nbin.cx.user-management";
  public static final String KAFKA_MSG_PUBLISHER_SYSTEM_ID = "6588";
  public static final String NBX_SOURCE = "nbx";
  public static String CHARACTER_ALLOWED =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~`!@#$%^&*()-_=+[{]}\\|;:'\",<.>/?";

  private UserConfigurationConstants() {
    throw new IllegalStateException("Utility class");
  }
}
