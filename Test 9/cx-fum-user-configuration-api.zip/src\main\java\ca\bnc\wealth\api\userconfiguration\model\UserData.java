package ca.bnc.wealth.api.userconfiguration.model;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserData {

  private String firmId;

  private String firmName;

  private String firmType;

  private String idpUserIdentifier;

  private String idpSubject;

  private String username;

  private List<String> secureZoneIds = null;

  private String ossUserId;

  private String ossGroupId;

  private String firstName;

  private String lastName;

  private String email;

  private String compassR2Id;

  private List<String> rrCodes = null;

  private String userGroup;

  private String RoleScopeType;

}