package ca.bnc.wealth.api.userconfiguration.model.state;

public enum UserStateDescriptionEnum {
  STAGED("Staged"),
  PENDING_USER_ACTION("Pending User Action"),
  ACTIVE("Active"),
  PASSWORD_RESET("Password Reset"),
  PASSWORD_EXPIRED("Password Expired"),
  LOCKED("Locked"),
  SUSPENDED("Suspended"),
  DELETED("Deleted");

  public final String dbValue;

  UserStateDescriptionEnum(String dbValue) {
    this.dbValue = dbValue;
  }
}
