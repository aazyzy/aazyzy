package ca.bnc.wealth.api.userconfiguration.model.state;

public enum UserStateEnum {
  ONBOARDING("onboarding"),
  PROVISIONED("provisioned"),
  ACTIVE("active"),
  RECOVERY("recovery"),
  INACTIVE("inactive"),
  DECOMMISSIONED("decommissioned");

  public final String dbValue;

  UserStateEnum(String dbValue) {
    this.dbValue = dbValue;
  }
}
