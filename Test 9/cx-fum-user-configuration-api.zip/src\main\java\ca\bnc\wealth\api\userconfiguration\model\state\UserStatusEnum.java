package ca.bnc.wealth.api.userconfiguration.model.state;

public enum UserStatusEnum {
  ACTIVE("active"),
  INACTIVE("inactive");

  public final String dbValue;

  UserStatusEnum(String dbValue) {
    this.dbValue = dbValue;
  }
}
