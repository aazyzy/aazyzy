package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.userconfiguration.kafka.AuditLogEventPublisher;
import ca.bnc.wealth.common.jpa.entity.enums.AuditEventType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.kafka.model.EventMessages;
import ca.bnc.wealth.common.kafka.model.Header;
import ca.bnc.wealth.common.kafka.model.audit.AuditUserConfigPayLoad;
import ca.bnc.wealth.common.userconfiguration.model.FeaturePackage;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Supplier;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AuditLogService {

  public static final String GET_MODULE_OVERRIDES_QUERY = """
      select * from "IAM_V2".fn_getFirmLevelAccess_moduleOverride_features(CAST(STRING_TO_ARRAY((:idpSubjects),',') AS VARCHAR[]))
  """;

  @Autowired
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @Autowired
  private ResourceRepository resourceRepository;

  @Autowired
  private AuditLogEventPublisher auditLogEventPublisher;

  @Autowired
  private UserService userService;

  @Autowired
  private R2Service r2Service;

  @Value("${userConfiguration.audit.enable:true}")
  private boolean enableUserConfigAudit;

  private ExecutorService executorService = Executors.newFixedThreadPool(2);

  public UserConfiguration publishAuditLog(Integer userConfigurationId, Boolean getR2IdFromInput, AuditEventType auditEventType, Supplier<UserConfiguration> supplier) {
    try {
      UserConfiguration userConfigurationBefore = enableUserConfigAudit && userConfigurationId != null ? getUserConfiguration(userConfigurationId, false) : null;

      UserConfiguration userConfiguration = supplier.get();

      if(enableUserConfigAudit) {
        executorService.submit(() -> {
          if(userConfiguration == null) {
            log.info("User configuration is null, skipping audit log publication.");
            return;
          }
          UserConfiguration userConfigurationAfter = getUserConfiguration(userConfiguration.getUserConfigurationId(), true);
          // r2Id update is async so we need to set it manually
          if (userConfigurationAfter != null && getR2IdFromInput != null && getR2IdFromInput) {
            userConfigurationAfter.setCompassR2Id(userConfiguration.getCompassR2Id());
          }
          EventMessages<AuditUserConfigPayLoad> messages = getEventMessage(auditEventType.name(),  userConfigurationBefore, userConfigurationAfter);
          publishMessages(messages);
        });
      }

      return userConfiguration;
    } catch (Exception exception) {
      log.warn("Failed to publish audit log, details: " +  exception.getMessage());
      throw exception;
    }
  }

  private void publishMessages(EventMessages<AuditUserConfigPayLoad> messages) {
    log.info("Publishing audit log message: {}", messages);
    if(messages.getPayload().getUserConfigurationAfter() != null)
      auditLogEventPublisher.publish(messages);
  }

  private UserConfiguration getUserConfiguration(Integer userConfigurationId, boolean getFromTable) {
    try {
      // Always read the base snapshot from the USER_CONFIGURATION table so the audit
      // "before" and "after" snapshots are built through the identical mapping path
      // (toDtoWithUserGroupAndFirmId). Reading "before" from the materialized view
      // populated preferredLanguage / userPreferences differently (raw MV columns vs.
      // the live firm-preference merge), which made an unchanged save look like an
      // app-preferences change and produced a spurious "preferences" History record
      // for users whose firm has firm-level preferences (NWPI-14590). The getFromTable
      // flag now only selects cached (before) vs. live (after) R2 / SecureZone enrichment.
      UserConfiguration userConfiguration = userService.getUserConfigurationWithRrCodeByIdFromTable(userConfigurationId);

      if(userConfiguration.getIdpUserId() == null) {
        log.warn("User configuration with id {} does not have idpUserId set, skipping further audit process for okta update.", userConfigurationId);
        return userConfiguration;
      }

      // get date from external system for latest data than the one from cache
      if(getFromTable) {
        String compassR2Id = Optional.ofNullable(r2Service.getCxUserProfile(userConfiguration.getIdpSubject())).map(Pair::getValue).orElse(null);
        userConfiguration.setCompassR2Id(compassR2Id);
        userService.getSecureZoneIdOptional(userConfiguration.getIdpUserId())
            .ifPresent(a -> userConfiguration.setSecureZoneIds(Arrays.asList(a)));
      } else {
        userConfiguration.setCompassR2Id(userService.getCompassR2Id(userConfiguration.getIdpSubject()));
        Optional.ofNullable(userService.getSecureZoneId(userConfiguration.getIdpUserId()))
            .ifPresent(a -> userConfiguration.setSecureZoneIds(Arrays.asList(a)));
      }

      log.info("from table: {}, idp_subject: {}, idpUserId: {}, compassR2Id: {}, secureZoneIds: {}", getFromTable, userConfiguration.getIdpSubject(), userConfiguration.getIdpUserId(), userConfiguration.getCompassR2Id(), userConfiguration.getSecureZoneIds());

      FeaturePackage featurePackage = new FeaturePackage();
      featurePackage.setPackageName(userConfiguration.getUserRole());

      userConfiguration.setFeaturePackage(featurePackage);

      updateModuleOverridesAndFeatures(userConfiguration);
      updateUserResources(userConfiguration);
      return userConfiguration;
    } catch (Exception e) {
      log.warn("getUserConfiguration failed for userConfigurationId: {}, getFromTable: {}", userConfigurationId, getFromTable, e);
    }
    return null;
  }

  private void updateModuleOverridesAndFeatures(UserConfiguration userConfiguration) {
    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("idpSubjects", userConfiguration.getIdpSubject());
    String idpFlaMoFs = namedParameterJdbcTemplate.queryForObject(GET_MODULE_OVERRIDES_QUERY,parameters, String.class);
    log.info("idpFlaMoFs: {}", idpFlaMoFs);

    if(StringUtils.isNotBlank(idpFlaMoFs)) {
      Arrays.stream(idpFlaMoFs.split("#")).forEach(idpFlaMoF -> {
        String[] idpFlaMoFArray = idpFlaMoF.split("\\|");
        if(idpFlaMoFArray.length == 4) {
          List<String> moduleOverrides = StringUtils.isNotBlank(idpFlaMoFArray[2]) ? Arrays.asList(idpFlaMoFArray[2].split(",")) : new ArrayList<>();
          List<String> features = StringUtils.isNotBlank(idpFlaMoFArray[3]) ? new ArrayList<>(Arrays.asList(idpFlaMoFArray[3].split(","))) : new ArrayList<>();
          if(idpFlaMoFArray[1].trim().equalsIgnoreCase("true")) {
            features.add("firm_level_access");
          }
          userConfiguration.getFeaturePackage().setModuleOverrides(moduleOverrides);
          userConfiguration.getFeaturePackage().setFeatures(features);
        }
      });
    }
  }

  private void updateUserResources(UserConfiguration userConfiguration) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("userAssignmentResources.userConfiguration.idpSubject", Pair.of(EnumQueryCriteria.EQUALS, userConfiguration.getIdpSubject()));
    fieldValueMap.put("userAssignmentResources.assignmentType", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER,
        UserAssignmentType.S.name()));

    Specification<Resource> spec = new Specification<>(fieldValueMap);
    List<Resource> resources = this.resourceRepository.findAll(spec);
    List<String> resourceNames = new ArrayList<>();
    List<String> restructedResourceNames = new ArrayList<>();
    resources.forEach(r -> {
      if(r.getRestriction()!= null && r.getRestriction())
        restructedResourceNames.add(r.getName());
      else
        resourceNames.add(r.getName());
    });
    userConfiguration.setResources(resourceNames);
    userConfiguration.setRestrictedResources(restructedResourceNames);
  }

  private EventMessages<AuditUserConfigPayLoad> getEventMessage(String auditEventType, UserConfiguration userConfigurationBefore, UserConfiguration userConfigurationAfter) {
    EventMessages<AuditUserConfigPayLoad> messages = new EventMessages<>();

    Header header = new Header();
    header.setId(UUID.randomUUID().toString());
    messages.setHeader(header);

    AuditUserConfigPayLoad payload = new AuditUserConfigPayLoad();
    payload.setType(auditEventType);
    payload.setUserConfigurationBefore(userConfigurationBefore);
    payload.setUserConfigurationAfter(userConfigurationAfter);

    messages.setPayload(payload);

    return messages;
  }
}
