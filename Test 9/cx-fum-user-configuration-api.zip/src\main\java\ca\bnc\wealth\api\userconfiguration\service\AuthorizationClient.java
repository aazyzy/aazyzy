package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.userconfiguration.model.FeaturePackageCreateResponse;
import ca.bnc.wealth.common.authorization.model.GetFeaturePackage;
import ca.bnc.wealth.common.userconfiguration.model.FeaturePackage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

@FeignClient(url = "${feign.iamApi.url}")
public interface AuthorizationClient {

  @RequestMapping(path = "access-control/features/packages/package", method = RequestMethod.POST)
  FeaturePackageCreateResponse createFeaturePackage(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestBody FeaturePackage featurePackage);

  @RequestMapping(
      path = "access-control/features/packages/package/{featurePackageId}?details=true",
      method = RequestMethod.GET)
  GetFeaturePackage getFeaturePackage(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @PathVariable(value = "featurePackageId") Integer featurePackageId);
}
