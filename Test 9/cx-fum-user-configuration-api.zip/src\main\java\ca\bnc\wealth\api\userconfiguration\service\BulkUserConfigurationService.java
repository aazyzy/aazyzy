package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.userconfiguration.util.BulkUserConstants;
import ca.bnc.wealth.common.fum.model.FirmPreferencesEnum;
import ca.bnc.wealth.common.fum.model.UserPreferencesEnum;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentFirm;
import ca.bnc.wealth.common.userconfiguration.model.FeaturePackage;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.Response;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BulkUserConfigurationService {

  @Autowired
  private UserService userService;

  @Autowired
  private UserConfigurationService userConfigurationService;

  @Autowired
  private UserAssignmentService userAssignmentService;

  @Autowired
  private BulkUserValidationService bulkUserValidationService;

  @Autowired
  private FirmBmaGuardService firmBmaGuardService;

  public Response updateUser(Map<String,String> requestMap) {
    String userName = requestMap.get(BulkUserConstants.USER_NAME);
    String requestId = requestMap.get(BulkUserConstants.REQUEST_ID);
    String requestedBy = requestMap.get(BulkUserConstants.CURRENT_USER);

    try {
      Optional<UserConfiguration> optionalUserConfiguration = getUserConfiguration(userName);
      if(optionalUserConfiguration.isEmpty()) {
        return createResponse(requestId, BulkUploadStatus.FAILED, null, String.format(BulkUserConstants.USER_NAME_NOT_FOUND, userName), BulkUserConstants.USER_NAME_NOT_FOUND_ERROR_CODE);
      }
      UserConfiguration userConfiguration = optionalUserConfiguration.get();

      // Reject update if a feature package assignment batch is in progress for this firm
      String targetFirmId = userConfiguration.getFirmId();
      if (firmBmaGuardService.isFirmBmaInProgress(targetFirmId)) {
        log.warn("BULK_UPDATE_BLOCKED: firm={} has an active feature package assignment batch", targetFirmId);
        return createResponse(requestId, BulkUploadStatus.FAILED, null,
            BulkUserConstants.ERROR_FIRM_BMA_IN_PROGRESS_MESSAGE, BulkUserConstants.ERROR_FIRM_BMA_IN_PROGRESS);
      }

      // F5: Enforce firm isolation. A bulk update must never move a user to a different firm,
      String requestedFirmId = requestMap.get(BulkUserConstants.FIRM_ID);

      if (StringUtils.isNotBlank(requestedFirmId) && StringUtils.isNotBlank(targetFirmId)
          && !requestedFirmId.equals(targetFirmId)) {
        log.warn("CROSS_FIRM_UPDATE_ATTEMPT: requester={}, targetUser={}, currentFirm={}, requestedFirm={}",
            requestedBy, userName, targetFirmId, requestedFirmId);
        return createResponse(requestId, BulkUploadStatus.FAILED, null,
            BulkUserConstants.ERROR_CROSS_FIRM_UPDATE_MESSAGE, BulkUserConstants.ERROR_CROSS_FIRM_UPDATE);
      }

      updateUserConfiguration(userConfiguration, requestMap);

      List<Pair<String, String>> validationList = bulkUserValidationService.userUpdateValidation(userConfiguration);
      if(!validationList.isEmpty()) {
        String errorCode = validationList.stream().map(Pair::getLeft).collect(Collectors.joining(","));
        String errorMessage = validationList.stream().map(Pair::getRight).collect(Collectors.joining(","));
        return createResponse(requestId, BulkUploadStatus.FAILED, null, errorMessage, errorCode);
      }

      userConfigurationService.auditUpdateUserConfiguration(userConfiguration.getUserConfigurationId(), userConfiguration, userConfiguration.getIdp(), requestedBy);
    } catch (Exception e) {
      log.warn("Error while updating user configuration", e);
      return createResponse(requestId, BulkUploadStatus.FAILED, null, e.getMessage(), BulkUserConstants.USER_UPDATE_ERROR);
    }
    return createResponse(requestId, BulkUploadStatus.SUCCESS, null, null, null);
  }

  private void updateUserConfiguration(UserConfiguration userConfiguration, Map<String,String> requestMap) {
    // F5: never allow the firm to be changed via bulk update; preserve the user's existing firm.
    // Any cross-firm change is already rejected in updateUser() before reaching this point.
    String requestedFirmId = requestMap.get(BulkUserConstants.FIRM_ID);
    if (StringUtils.isNotBlank(requestedFirmId)) {
      userConfiguration.setFirmId(requestedFirmId);
    }
    userConfiguration.setFirstName(requestMap.get(BulkUserConstants.FIRST_NAME));
    userConfiguration.setLastName(requestMap.get(BulkUserConstants.LAST_NAME));
    userConfiguration.setEmail(requestMap.get(BulkUserConstants.EMAIL_ADDRESS));
    userConfiguration.setPreferredLanguage(requestMap.get(BulkUserConstants.PREFERRED_LANGUAGE));


    if(StringUtils.isNotBlank(requestMap.get(BulkUserConstants.DEFAULT_MODULE))) {
      List<UserAssignmentFirm> userAssignmentFirms = userAssignmentService.getUserAssignment(userConfiguration.getIdpSubject(),
          UserAssignmentType.F);
      if(userAssignmentFirms.size() == 1 && userAssignmentFirms.get(0).getFirm() != null) {
        Firm firm = userAssignmentFirms.get(0).getFirm();
        if (firm.getFirmPreferences() !=null && requestMap.get(BulkUserConstants.DEFAULT_MODULE).equalsIgnoreCase(
            firm.getFirmPreferences().get(FirmPreferencesEnum.defaultModule.name()))) {
          Optional.ofNullable(userConfiguration.getUserPreferences()).ifPresent(map -> map.remove(UserPreferencesEnum.defaultModule.name()));
        } else {
          Optional.ofNullable(userConfiguration.getUserPreferences())
              .ifPresentOrElse(map -> map.put(UserPreferencesEnum.defaultModule.name(), requestMap.get(BulkUserConstants.DEFAULT_MODULE)),
                  () -> {
                  Map<String, String> userPreferences = new HashMap<>();
                  userPreferences.put(UserPreferencesEnum.defaultModule.name(), requestMap.get(BulkUserConstants.DEFAULT_MODULE));
                  userConfiguration.setUserPreferences(userPreferences);
              });
        }
      }
    } else {
      Optional.ofNullable(userConfiguration.getUserPreferences()).ifPresent(map ->
          userConfiguration.getUserPreferences().remove(UserPreferencesEnum.defaultModule.name()));
    }

    if(StringUtils.isNotBlank(requestMap.get(BulkUserConstants.SECURE_ZONE_ID))) {
      userConfiguration.setSecureZoneIds(Arrays.asList(requestMap.get(BulkUserConstants.SECURE_ZONE_ID).split(",")));
    } else {
      userConfiguration.setSecureZoneIds(new ArrayList<>());
    }

    Optional.ofNullable(requestMap.get(BulkUserConstants.OSS_USER_ID)).ifPresentOrElse(
        ossUserId -> {
          userConfiguration.setOssUserId(ossUserId);
          userConfiguration.setOssId(ossUserId);
        }, () -> {
          userConfiguration.setOssUserId(null);
          userConfiguration.setOssId(null);
        });
    Optional.ofNullable(requestMap.get(BulkUserConstants.COMPASS_R2_ID)).ifPresentOrElse(userConfiguration::setCompassR2Id, () -> userConfiguration.setCompassR2Id(null));
    Optional.ofNullable(requestMap.get(BulkUserConstants.EXTERNAL_CLIENT_ID)).ifPresentOrElse(userConfiguration::setExternalClientId, () -> userConfiguration.setExternalClientId(null));

    List<String> features = new ArrayList<>();
    List<String> moduleOverrides = new ArrayList<>();
    if(Boolean.parseBoolean(requestMap.get(BulkUserConstants.FIRM_LEVEL_ACCESS))) {
      features.add("firm_level_access");
    }
    Optional.ofNullable(requestMap.get(BulkUserConstants.MODULE_OVERRIDES)).ifPresent(a -> moduleOverrides.addAll(Arrays.asList(a.split(","))));
    Optional.ofNullable(requestMap.get(BulkUserConstants.FEATURES)).ifPresent(a -> features.addAll(Arrays.asList(a.split(","))));

    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setPackageName(requestMap.get(BulkUserConstants.ROLES));
    featurePackage.setModuleOverrides(moduleOverrides);
    featurePackage.setFeatures(features);
    userConfiguration.setFeaturePackage(featurePackage);


    if(StringUtils.isNotBlank(requestMap.get(BulkUserConstants.RR_CODES))) {
      List<RRCodeRange> lst = Arrays.stream(requestMap.get(BulkUserConstants.RR_CODES).split(","))
          .map(String::trim)
          .filter(rr -> !rr.equals("-"))
          .map(rr -> {
            String[] array = rr.split("-");
            return array.length == 2 ? new RRCodeRange().fromRRCode(array[0].trim()).toRRCode(array[1].trim())
                : new RRCodeRange().fromRRCode(array[0].trim()).toRRCode(array[0].trim());
          })
          .toList();
      userConfiguration.setRrCodeRanges(lst);
    } else {
      userConfiguration.setRrCodeRanges(new ArrayList<>());
    }
  }

  private Optional<UserConfiguration> getUserConfiguration(String userName) {
    try {
      UserConfiguration userConfiguration = userService.getUserConfigurationByIdOrName(userName);
      userConfiguration.setCompassR2Id(userService.getCompassR2Id(userConfiguration.getIdpSubject()));
      Optional.ofNullable(userService.getSecureZoneId(userConfiguration.getIdpUserId()))
          .ifPresent(a -> userConfiguration.setSecureZoneIds(Arrays.asList(a)));
      return Optional.of(userConfiguration);
    } catch (Exception e) {
      log.error("Error while fetching user configuration for user: {}", userName, e);
      return Optional.empty();
    }
  }

  private Response createResponse(String requestId, BulkUploadStatus status, String data, String errorMessage, String errorCode) {
    Response response = new Response();
    response.setId(requestId);
    response.setStatus(status.name());
    response.setData(data);
    response.setErrorMessage(errorMessage);
    response.setErrorCode(errorCode);
    return response;
  }
}
