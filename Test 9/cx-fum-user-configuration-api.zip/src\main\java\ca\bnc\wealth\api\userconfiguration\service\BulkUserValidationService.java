package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.userconfiguration.util.BulkUserConstants;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.UserConfigUtils;
import ca.bnc.wealth.common.fum.service.FeaturePackageServiceHelper;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BulkUserValidationService {

  @Autowired
  private UserService userService;

  @Autowired
  private R2Service r2Service;

  @Autowired
  private FeaturePackageServiceHelper featurePackageServiceHelper;

  public List<Pair<String, String>> userUpdateValidation(UserConfiguration userConfiguration) {
    List<Pair<String,String>> validationList = new ArrayList<>();

    String email = userConfiguration.getEmail();
    if (StringUtils.isNotBlank(email) && !UserConfigUtils.validateEmail(email)) {
      validationList.add(Pair.of(BulkUserConstants.ERROR_EMAIL_INVALID_FORMAT,BulkUserConstants.ERROR_EMAIL_INVALID_FORMAT_MESSAGE));
    }

    if (!userService.validRrCodeRangeForFirmId(
        userConfiguration.getFirmId(),
        userConfiguration.getRrCodes(),
        userConfiguration.getRrCodeRanges())) {
      log.warn("Some of provided user rrcode are not in firm rrcode range");
      validationList.add(Pair.of(BulkUserConstants.ERROR_RRCODE_INVALID,BulkUserConstants.ERROR_RRCODE_INVALID_MESSAGE ));
    }

    if (StringUtils.isNotBlank(userConfiguration.getCompassR2Id())) {
      Pair<Boolean, String> r2validation = r2Service.r2ValidationForUpdateUser(userConfiguration.getCompassR2Id(), userConfiguration.getIdpSubject());
      if (!r2validation.getKey()) {
        validationList.add(Pair.of(BulkUserConstants.ERROR_R2_NOT_FOUND, BulkUserConstants.ERROR_R2_NOT_FOUND_MESSAGE));
      }
    }
    return validationList;
  }
}
