package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.userconfiguration.dao.CiamOktaDao;
import ca.bnc.wealth.api.userconfiguration.model.UserConfigurationConstants;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.UserConfigUtils;
import ca.bnc.wealth.common.ciam.model.OktaAccessProfile;
import ca.bnc.wealth.common.ciam.model.OktaNewPassword;
import ca.bnc.wealth.common.ciam.model.OktaUserEmail;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.ciam.model.OktaUserRequest;
import ca.bnc.wealth.common.ciam.model.OktaUserWithHashedPasswordRequest;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ErrorSeverity;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ServiceException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CiamService {

  private static final String LOG_CHECK_USER_OKTA_PROFILE =
      "Checking if user {} has a okta profile";
  @Autowired CiamOktaDao ciamOktaDao;

  public CiamService(CiamOktaDao ciamOktaDao) {
    this.ciamOktaDao = ciamOktaDao;
  }

  /**
   * Employee (internal) users have no Okta/CIAM profile, so their idpUserId is blank. CIAM must
   * not be called for them. Returns true (and logs) when the Okta call should be skipped.
   */
  private boolean shouldSkipOktaCall(String idpUserId, String operation) {
    if (StringUtils.isBlank(idpUserId)) {
      log.debug("Skipping Okta {} - user has no idpUserId (non-Okta/employee user)", operation);
      return true;
    }
    return false;
  }

  public OktaUserProfile getOktaUserProfile(String idpUserId) {
    if (StringUtils.isBlank(idpUserId)) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_OKTA_USER_NOT_FOUND_MESSAGE, idpUserId));
    }
    return Optional.ofNullable(ciamOktaDao.getOktaUserProfile(idpUserId))
        .orElseThrow(
            () -> new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
                String.format(Constants.ERROR_OKTA_USER_NOT_FOUND_MESSAGE, idpUserId)));
  }

  public Optional<OktaUserProfile> getOktaUserProfile(String idpUserId, int retry) {
    if (StringUtils.isBlank(idpUserId)) {
      return Optional.empty();
    }
    for (int i = 1; i <= retry; i++) {
      try {
        OktaUserProfile oktaUserProfile = getOktaUserProfile(idpUserId);
        return Optional.of(oktaUserProfile);
      } catch (Exception exception) {
        log.info(i + " attempt for getting okta user profile failed");
      }
    }
    return Optional.empty();
  }

  public void createOktaUser(OktaUserRequest oktaUserRequest) {
    ciamOktaDao.createOktaUser(oktaUserRequest);
  }

  public void createActiveOktaUser(OktaUserRequest oktaUserRequest) {
    ciamOktaDao.createActiveOktaUser(oktaUserRequest);
  }

  public void createOktaUserWithHashedPassword(OktaUserWithHashedPasswordRequest oktaUserRequest) {
    ciamOktaDao.createOktaUserWithHashedPassword(oktaUserRequest);
  }

  public void createActiveOktaUserWithHashedPassword(OktaUserWithHashedPasswordRequest oktaUserRequest) {
    ciamOktaDao.createActiveOktaUserWithHashedPassword(oktaUserRequest);
  }

  public void updateOktaUserGroups(String idpUserId, String groupName) {
    if (shouldSkipOktaCall(idpUserId, "group update")) {
      return;
    }

    List<String> groupsInOkta = ciamOktaDao.getUserOktaGroups(idpUserId);
    // TODO We cannot delete groups that are custom to Okta.
    List<String> oktaGroupNames =
        groupsInOkta.stream()
            .filter(oktaGroupName -> oktaGroupName.startsWith("Wealth.CompassX."))
            .toList();
    log.info("Updating user groups to {} for {}", oktaGroupNames, idpUserId);
    /**
     * To keep CompassX and Okta groups in sync, check if the requested groups match Okta and adjust
     * accordingly
     */
    try {
      if (!oktaGroupNames.contains(groupName)) {
        // Delete existing user groups associated to the profile
        oktaGroupNames.forEach(group -> ciamOktaDao.deleteOktaUserGroup(idpUserId, group));
        ciamOktaDao.addOktaUserGroup(idpUserId, groupName);
      }
    } catch (Exception e) {
      log.info("Error updating groups in Okta with error: {}", e.getMessage());
      throw new ServiceException(ErrorSeverity.ERROR, "Error updating groups in Okta");
    }
  }

  /** Assigns a user group to a user in Okta if not already assigned */
  public void assignOktaUserGroup(String idpUserId, String groupName) {
    if (shouldSkipOktaCall(idpUserId, "group assignment")) {
      return;
    }
    List<String> groupsInOkta = ciamOktaDao.getUserOktaGroups(idpUserId);
    log.info(
        "Adding user group {} to existing list of user groups to {} for {}",
        groupName,
        groupsInOkta,
        idpUserId);
    try {
      if (!groupsInOkta.contains(groupName)) {
        ciamOktaDao.addOktaUserGroup(idpUserId, groupName);
      }
    } catch (Exception e) {
      log.info("Error updating groups in Okta with error: {}", e.getMessage());
      throw new ServiceException(ErrorSeverity.ERROR, "Error updating groups in Okta");
    }
  }

  @SneakyThrows
  public void deleteOktaUserGroup(String idpUserId, String groupName) {
    if (shouldSkipOktaCall(idpUserId, "group removal")) {
      return;
    }
    List<String> groupsInOkta = ciamOktaDao.getUserOktaGroups(idpUserId);
    log.info("Removing user group {} from existing list of user groups to {} for {}",
        groupName, groupsInOkta, idpUserId);
    try {
      if (groupsInOkta.contains(groupName)) {
        ciamOktaDao.deleteOktaUserGroup(idpUserId, groupName);
      } else {
        throw new FumValidationException("error.groupName.notFound",
            String.format("Group %s not found in Okta for user %s", groupName, idpUserId));
      }
    } catch (FumValidationException e) {
      throw e;
    } catch (Exception e) {
      log.info("Error removing groups in Okta with error: {}", e.getMessage());
      throw new ServiceException(ErrorSeverity.ERROR, "Error updating groups in Okta");
    }
  }

  public void deleteOktaUser2fa(String idpUserId) {
    if (shouldSkipOktaCall(idpUserId, "2FA delete")) {
      return;
    }
    log.info("Checking if user {} has a sms mfa assigned to their okta profile", idpUserId);
    OktaUserProfile oktaUserProfile = getOktaUserProfile(idpUserId);
    boolean userSms2faPresent =
        Arrays.stream(oktaUserProfile.getFactors())
            .anyMatch(
                factor ->
                    factor
                        .getFactorType()
                        .equalsIgnoreCase(UserConfigurationConstants.FACTOR_MFA_SMS));
    if (userSms2faPresent) {
      log.info("Deleting SMS 2fa for {}", idpUserId);
      ciamOktaDao.deleteOktaUser2fa(idpUserId);
    }
  }

  public void deleteOktaUserProfile(String idpUserId) {
    if (shouldSkipOktaCall(idpUserId, "profile delete")) {
      return;
    }
    log.info(LOG_CHECK_USER_OKTA_PROFILE, idpUserId);
    getOktaUserProfile(idpUserId);
    log.info("Deleting user's okta profile {}", idpUserId);
    ciamOktaDao.deleteOktaUser(idpUserId);
  }

  public void resetPassword(String userId, OktaNewPassword newPassword) {
    if (shouldSkipOktaCall(userId, "password reset")) {
      return;
    }
    ciamOktaDao.resetPassword(userId, newPassword);
  }

  public void suspendUserOktaProfile(String idpUserId) {
    if (shouldSkipOktaCall(idpUserId, "suspend")) {
      return;
    }
    log.info(LOG_CHECK_USER_OKTA_PROFILE, idpUserId);
    OktaUserProfile oktaUserProfile = getOktaUserProfile(idpUserId);
    // NWPI-15109: Okta rejects a lifecycle call that is already satisfied. The employee migration's
    // sunset step retries a row whose suspend succeeded but whose DB decommission then failed, so
    // without this the retry errors and strands the row.
    if (Constants.IDP_STATUS_SUSPENDED.equalsIgnoreCase(oktaUserProfile.getStatus())) {
      log.info("User's okta profile {} is already suspended", idpUserId);
      return;
    }
    log.info("Suspending user's okta profile {}", idpUserId);
    ciamOktaDao.suspendUserOktaProfile(idpUserId);
  }

  public void unsuspendUserOktaProfile(String idpUserId) {
    if (shouldSkipOktaCall(idpUserId, "unsuspend")) {
      return;
    }
    log.info(LOG_CHECK_USER_OKTA_PROFILE, idpUserId);
    OktaUserProfile oktaUserProfile = getOktaUserProfile(idpUserId);
    // Same reasoning in reverse: a migration rollback re-runs unsuspend over accounts that may
    // already be active.
    if (!Constants.IDP_STATUS_SUSPENDED.equalsIgnoreCase(oktaUserProfile.getStatus())) {
      log.info("User's okta profile {} is not suspended", idpUserId);
      return;
    }
    log.info("Unsuspending user's okta profile {}", idpUserId);
    ciamOktaDao.unsuspendUserOktaProfile(idpUserId);
  }

  public void updateOktaSecureZoneId(String idpUserId, String[] secureZoneIds) {
    if (shouldSkipOktaCall(idpUserId, "SecureZone id update")) {
      return;
    }
    log.info(LOG_CHECK_USER_OKTA_PROFILE, idpUserId);
    OktaUserProfile oktaUserProfile = getOktaUserProfile(idpUserId);
    if (!isSecureZoneIdsAlreadyExistInOkta(oktaUserProfile.getAccessProfile(), secureZoneIds)) {
      log.info("Updating secureZoneId of user's okta profile {}", idpUserId);
      ciamOktaDao.updateOktaSecureZoneId(idpUserId, secureZoneIds);
    }
  }

  public void syncOktaUserProfile(String idpUserId, int retry) {
    if (shouldSkipOktaCall(idpUserId, "profile sync")) {
      return;
    }
    log.info(LOG_CHECK_USER_OKTA_PROFILE, idpUserId);
    getOktaUserProfile(idpUserId);

    log.info("Syncing user's Okta profile {}", idpUserId);
    for (int i = 1; i <= retry; i++) {
      try {
        ciamOktaDao.syncOktaUserProfile(idpUserId);
        return;
      } catch (Exception exception) {
        log.warn("Attempt {} for syncing Okta user profile failed {}", i, idpUserId);
      }
    }
    log.error("Syncing user's Okta profile {} has failed", idpUserId);
    throw new FumServiceException(Constants.ERROR_OKTA_PROFILE_SYNC, "Error syncing user's Okta profile");
  }

  private boolean isSecureZoneIdsAlreadyExistInOkta(
      OktaAccessProfile accessProfile, String[] secureZoneIds) {
    if (accessProfile != null) {
      return UserConfigUtils.isTwoArraysEqual(accessProfile.getBngfSecureZoneId(), secureZoneIds);
    }
    return false;
  }

  public void updateOktaUserEmail(String idpUserId, OktaUserEmail oktaUserEmail) {
    if (shouldSkipOktaCall(idpUserId, "email update")) {
      return;
    }
    log.info("Updating user's okta email {}", idpUserId);
    ciamOktaDao.updateOktaUserEmail(idpUserId, oktaUserEmail);
  }
}
