package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.userconfiguration.model.UserData;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.List;

@Service
@Slf4j
public class CsvConverterService {

  private static final String[] COLUMN_HEADERS =
      new String[] {
        "Firm ID",
        "Firm Name",
        "Firm Type",
        "Username",
        "First Name",
        "Last Name",
        "IdpUserIdentifier",
        "SecureZone ID",
        "OSS User ID",
        "OSS Group ID",
        "Email",
        "Compass R2 ID*",
        "IdpSubject",
        "RR Codes",
        "User Group",
        "Role Scope Type"
      };

  @SneakyThrows
  public ByteArrayResource convertToCsv(List<UserData> userDataList) {
    CSVFormat format = CSVFormat.DEFAULT.builder().setHeader(COLUMN_HEADERS).build();
    StringWriter stringWriter = new StringWriter();
    try (CSVPrinter csvPrinter = new CSVPrinter(stringWriter, format)) {
      for (UserData userData : userDataList) {
        List<String> data =
            Arrays.asList(
                userData.getFirmId(),
                userData.getFirmName(),
                userData.getFirmType(),
                userData.getUsername(),
                userData.getFirstName(),
                userData.getLastName(),
                userData.getIdpUserIdentifier(),
                convertListToSingleString(userData.getSecureZoneIds()),
                userData.getOssUserId(),
                userData.getOssGroupId(),
                userData.getEmail(),
                userData.getCompassR2Id(),
                userData.getIdpSubject(),
                convertListToSingleString(userData.getRrCodes()),
                userData.getUserGroup(),
                userData.getRoleScopeType());
        csvPrinter.printRecord(data);
      }
      csvPrinter.flush();
      return new ByteArrayResource(stringWriter.toString().getBytes(), "User Data");
    } catch (IOException e) {
      log.error("Failed to import data to CSV file: " + e.getMessage());
      throw e;
    }
  }

  private String convertListToSingleString(List<String> list) {
    return list != null ? String.join(":", list) : null;
  }
}
