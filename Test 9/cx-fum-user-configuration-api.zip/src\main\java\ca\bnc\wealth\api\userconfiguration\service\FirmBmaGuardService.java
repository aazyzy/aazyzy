package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.userconfiguration.util.BulkUserConstants;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class FirmBmaGuardService {

  private final FirmRepository firmRepository;

  /**
   * Returns true if a feature package assignment batch is in progress for the given firm,
   * indicated by the presence of FEATURE_PACKAGE_ASSIGNMENT_BATCH_ID in firm preferences.
   */
  public boolean isFirmBmaInProgress(String firmId) {
    if (StringUtils.isBlank(firmId)) {
      return false;
    }
    Firm firm = firmRepository.findByFirmId(firmId);
    if (firm == null || firm.getFirmPreferences() == null) {
      return false;
    }
    return StringUtils.isNotBlank(
        firm.getFirmPreferences().get(BulkUserConstants.FIRM_FEATURE_PACKAGE_ASSIGNMENT_BATCH_ID));
  }
}
