package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.Person;
import ca.bnc.wealth.common.jpa.entity.iam.PersonAssignment;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PersonAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PersonRepository;
import java.sql.Timestamp;
import java.util.Objects;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Limit;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class PersonService {

  @Autowired
  private PersonRepository personRepository;

  @Autowired
  private PersonAssignmentRepository personAssignmentRepository;

  @Autowired
  private IamUserConfigurationRepository iamUserConfigurationRepository;

  public void syncPersonFromUserConfiguration(IamUserConfiguration iamUserConfiguration) {
    if (iamUserConfiguration == null || iamUserConfiguration.getUserConfigurationId() == null) {
      return;
    }

    try {
      Integer userId = iamUserConfiguration.getUserConfigurationId().intValue();

      // A PERSON_USER link is established once and never re-pointed, so an already-linked
      // configuration keeps its person regardless of any later email change (NWPI-14875).
      Optional<PersonAssignment> existingAssignment =
          personAssignmentRepository.findFirstByUserId(userId);
      if (existingAssignment.isPresent()) {
        updatePerson(existingAssignment.get().getPerson(), iamUserConfiguration);
        return;
      }

      String email = iamUserConfiguration.getEmail();
      if (email == null) {
        log.debug("syncPersonFromUserConfiguration: skipping — email is null for userConfigId={}",
            userId);
        return;
      }

      Person person = personRepository.findFirstByEmailIgnoreCase(email)
          .map(existingPerson -> updatePerson(existingPerson, iamUserConfiguration))
          .orElseGet(() -> createPerson(iamUserConfiguration));

      createPersonAssignment(person, iamUserConfiguration);
    } catch (Exception e) {
      log.info("syncPersonFromUserConfiguration failed for userConfigId={}: {}",
          iamUserConfiguration.getUserConfigurationId(), e.getMessage(), e);
    }
  }

  /**
   * Removes the PERSON_USER link for a user configuration so its USER_CONFIGURATION row can be
   * deleted without violating fk_person_user_user_configuration. If the linked Person is left with
   * no remaining assignments (it was created solely for this user), it is removed as well.
   */
  public void removePersonLink(IamUserConfiguration iamUserConfiguration) {
    if (iamUserConfiguration == null || iamUserConfiguration.getUserConfigurationId() == null) {
      return;
    }

    Integer userId = iamUserConfiguration.getUserConfigurationId().intValue();
    personAssignmentRepository.findFirstByUserId(userId).ifPresent(assignment -> {
      Person person = assignment.getPerson();
      personAssignmentRepository.delete(assignment);
      log.info("removePersonLink: removed personAssignment for userConfigId={}", userId);

      if (person != null
          && personAssignmentRepository.findAllByPersonPersonId(person.getPersonId()).isEmpty()) {
        personRepository.delete(person);
        log.info("removePersonLink: removed orphaned personId={}", person.getPersonId());
      }
    });
  }

  private Person createPerson(IamUserConfiguration iamUserConfiguration) {
    Person person = Person.builder()
        .firstName(iamUserConfiguration.getFirstName())
        .lastName(iamUserConfiguration.getLastName())
        .language(Optional.ofNullable(iamUserConfiguration.getPreferredLanguageType())
            .orElse(PreferredLanguageType.EN))
        .email(iamUserConfiguration.getEmail())
        .organization(iamUserConfiguration.getIdp())
        .createdBy(iamUserConfiguration.getCreatedBy())
        .createdDt(new Timestamp(System.currentTimeMillis()))
        .build();

    person = personRepository.save(person);
    log.info("syncPersonFromUserConfiguration: created personId={} for userConfigId={}",
        person.getPersonId(), iamUserConfiguration.getUserConfigurationId());
    return person;
  }

  private Person updatePerson(Person person, IamUserConfiguration iamUserConfiguration) {
    person.setFirstName(iamUserConfiguration.getFirstName());
    person.setLastName(iamUserConfiguration.getLastName());
    person.setLanguage(Optional.ofNullable(iamUserConfiguration.getPreferredLanguageType())
        .orElse(PreferredLanguageType.EN));
    person.setOrganization(iamUserConfiguration.getIdp());
    person.setUpdatedBy(iamUserConfiguration.getLastUpdatedBy());
    person.setUpdatedDt(new Timestamp(System.currentTimeMillis()));

    person = personRepository.save(person);
    log.info("syncPersonFromUserConfiguration: updated personId={} for userConfigId={}",
        person.getPersonId(), iamUserConfiguration.getUserConfigurationId());
    return person;
  }

  private void createPersonAssignment(Person person, IamUserConfiguration iamUserConfiguration) {
    Integer assigneeId = iamUserConfiguration.getUserConfigurationId().intValue();

    PersonAssignment assignment = PersonAssignment.builder()
        .person(person)
        .userId(assigneeId)
        .createdBy(iamUserConfiguration.getCreatedBy())
        .createdDt(new Timestamp(System.currentTimeMillis()))
        .build();

    personAssignmentRepository.save(assignment);
    log.info("syncPersonFromUserConfiguration: created personAssignment personId={} -> userConfigId={}",
        person.getPersonId(), assigneeId);
  }

  public boolean isSecondaryAccount(IamUserConfiguration user) {
    if (user == null || StringUtils.isBlank(user.getEmail())) {
      return false;
    }

    // An employee account is the primary of the pair, never the secondary.
    if (Constants.EMPLOYEE_IDP.equalsIgnoreCase(user.getIdp())) {
      return false;
    }

    Long userId = user.getUserConfigurationId();

    // Checking if user with email exists with idp = IAMi
    return iamUserConfigurationRepository
        .findByEmailIgnoreCase(user.getEmail(), Limit.unlimited())
        .stream()
        .filter(match -> !Objects.equals(match.getUserConfigurationId(), userId))
        .anyMatch(match -> Constants.EMPLOYEE_IDP.equalsIgnoreCase(match.getIdp()));
  }
}
