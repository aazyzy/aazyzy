package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.userconfiguration.model.R2userStatus;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.common.r2.feign.client.CxUserProfileClient;
import ca.bnc.wealth.common.r2.feign.client.R2UserProfileClient;
import ca.bnc.wealth.common.r2.model.R2UserProfile;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class R2Service {

  @Autowired R2UserProfileClient r2UserProfileClient;
  @Autowired CxUserProfileClient cxUserProfileClient;
  @Autowired SystemTokenFactory systemTokenFactory;

  @Value("${feign.r2Api.businessViewId}")
  private String businessViewId;

  public R2UserProfile getR2UserProfile(String r2UserId) {
    String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);
    return r2UserProfileClient.getR2UserProfile(token, businessViewId, r2UserId);
  }

  public Pair<R2userStatus, R2UserProfile> getR2UserProfileWithStatus(String r2UserId) {
    R2UserProfile profile = getR2UserProfile(r2UserId);
    if (StringUtils.isNotBlank(profile.getError())) {
      return Pair.of(R2userStatus.NOT_FOUND, profile);
    } else if (StringUtils.isNotBlank(profile.getCxUserId())) {
      return Pair.of(R2userStatus.WITH_CPX_SUB, profile);
    } else {
      return Pair.of(R2userStatus.WITHOUT_CPX_SUB, profile);
    }
  }

  public Pair<HttpStatusCode, String> getCxUserProfile(String cxUserId) {
    try {
      String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);
      ResponseEntity<String> response =
          cxUserProfileClient.getR2UserProfile(token, businessViewId, cxUserId);
      return Pair.of(response.getStatusCode(), response.getBody());
    } catch (Exception exception) {
      log.error("CRITICAL: Failed to get R2 ID: {}", exception.getMessage());
    }
    return null;
  }

  public Pair<Boolean, String> r2ValidationForUpdateUser(String  r2UserId, String idpSubject) {
    Pair<R2userStatus, R2UserProfile> r2Profile = getR2UserProfileWithStatus(r2UserId);
    switch (r2Profile.getKey()) {
      case WITH_CPX_SUB:
        if (r2Profile
            .getValue()
            .getCxUserId()
            .equalsIgnoreCase(idpSubject)) {
          return Pair.of(true, null);
        } else {
          return Pair.of(false, Constants.ERROR_R2_NOT_MATCHED);
        }
      case WITHOUT_CPX_SUB:
        return Pair.of(true, null);
      case NOT_FOUND:
        return Pair.of(false, Constants.ERROR_R2_NOT_FOUND);
      default:
        return Pair.of(false, Constants.ERROR_R2_EXCEPTION);
    }
  }
}
