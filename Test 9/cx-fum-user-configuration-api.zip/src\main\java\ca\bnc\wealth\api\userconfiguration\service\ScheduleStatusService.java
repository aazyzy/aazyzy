package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.common.jpa.entity.platform.SchedulerStatus;
import ca.bnc.wealth.common.jpa.repo.platform.SchedulerStatusRepository;
import java.sql.Timestamp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class ScheduleStatusService {

  private final SchedulerStatusRepository schedulerStatusRepository;

  @Autowired
  public ScheduleStatusService(SchedulerStatusRepository schedulerStatusRepository) {
    this.schedulerStatusRepository = schedulerStatusRepository;
  }

  @Transactional
  public boolean canRunSchedule(String scheduleName, long durationInMin) {
    SchedulerStatus schedulerStatus = this.schedulerStatusRepository.findFirstBySchedulerName(
        scheduleName);

    if (schedulerStatus == null) {
      schedulerStatus = new SchedulerStatus();
      schedulerStatus.setSchedulerName(scheduleName);
    } else if (!canRunSchedule(schedulerStatus.getSchedulerStart(),
        schedulerStatus.getSchedulerEnd(), durationInMin)) {
      return false;
    }
    schedulerStatus.setSchedulerStart(new Timestamp(System.currentTimeMillis()));
    schedulerStatus.setSchedulerEnd(null);
    this.schedulerStatusRepository.save(schedulerStatus);
    return true;
  }

  @Transactional
  public void updateStatusToFinish(String scheduleName) {
    SchedulerStatus schedulerStatus = this.schedulerStatusRepository.findFirstBySchedulerName(
        scheduleName);
    schedulerStatus.setSchedulerEnd(new Timestamp(System.currentTimeMillis()));
    this.schedulerStatusRepository.save(schedulerStatus);
  }

  private boolean canRunSchedule(Timestamp start, Timestamp end, long durationInMin) {
    long currentTime = System.currentTimeMillis();
    long durationInMillisec = durationInMin * 60000;
    if (start == null) {
      return true;
    } else if (end == null) {
      durationInMillisec = durationInMillisec * 2;
      return start.getTime() + durationInMillisec < currentTime;
    }
    return end.getTime() + durationInMillisec < currentTime;
  }
}
