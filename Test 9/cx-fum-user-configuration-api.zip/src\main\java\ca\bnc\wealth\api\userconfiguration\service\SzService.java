package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.sz.feign.client.SzClientUAMA;
import ca.bnc.wealth.common.sz.model.SzUser;
import ca.bnc.wealth.common.sz.model.SzUserSearch;
import feign.FeignException;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class SzService {

  @Autowired SzClientUAMA szClientUAMA;
  @Autowired SystemTokenFactory systemTokenFactory;

  @SneakyThrows
  public void assignExternalIdToUsername(String szId, String idpSubject, String userType) {
    try {
      String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);

      ResponseEntity<String> response =
          szClientUAMA.assignUsernameToSzId(token, szId, idpSubject, userType);

      log.info("SecureZone response for assignUsernameToSzId: szId {} idpSubject {} userType {}: {} {}",
          szId, idpSubject, userType, response.getStatusCode(), response.getBody());

      if (response.getStatusCode().is4xxClientError()) {
        throw new FumValidationException(Constants.ERROR_SZ_ASSIGN_CALL_4xx, String.format(Constants.ERROR_SZ_ASSIGN_CALL_4xx_MESSAGE, szId));
      }

      if (response.getStatusCode().is5xxServerError()) {
        throw new FumServiceException(Constants.ERROR_SZ_ASSIGN_CALL_5xx, String.format(Constants.ERROR_SZ_ASSIGN_CALL_5xx_MESSAGE, szId, idpSubject));
      }
    } catch (Exception e) {
      log.info("Failed to assign szId {} to idpSubject {}: {}", szId, idpSubject, e.getMessage());
      if (e instanceof FumServiceException ||  e instanceof FumValidationException) {
        throw e;
      }
      throw new FumServiceException(Constants.ERROR_SZ_ASSIGN_CALL_5xx, String.format(Constants.ERROR_SZ_ASSIGN_CALL_5xx_MESSAGE, szId, idpSubject));
    }
  }

  @SneakyThrows
  public void updateUserActiveStatus(String szId, SzUser szUser) {
    try {
      String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);

      ResponseEntity<String> response = szClientUAMA.updateUser(token, szId, szUser);

      log.info("SecureZone response for updateUser: szId {} active {}: {} {}",
          szId, szUser.isActive(), response.getStatusCode(), response.getBody());

      if (response.getStatusCode().is4xxClientError()) {
        throw new FumValidationException(Constants.ERROR_SZ_UPDATE_CALL_4xx, String.format(Constants.ERROR_SZ_UPDATE_CALL_4xx_MESSAGE, szId));
      }

      if (response.getStatusCode().is5xxServerError()) {
        throw new FumServiceException(Constants.ERROR_SZ_UPDATE_CALL_5xx, String.format(Constants.ERROR_SZ_UPDATE_CALL_5xx_MESSAGE, szId));
      }
    } catch (Exception e) {
      log.info("Failed to update szId {} active status: {}", szId, e.getMessage());
      if (e instanceof FumServiceException ||  e instanceof FumValidationException) {
        throw e;
      }
      throw new FumServiceException(Constants.ERROR_SZ_UPDATE_CALL_5xx, String.format(Constants.ERROR_SZ_UPDATE_CALL_5xx_MESSAGE, szId));
    }
  }

  @SneakyThrows
  public SzUser getExternalUser(String szId) {
    try {
      String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);

      ResponseEntity<SzUser> response = szClientUAMA.getUser(token, szId);

      log.info("SecureZone response for getUser: szId {}: {} {}", szId, response.getStatusCode(), response.getBody());

      if (response.getStatusCode().is4xxClientError()) {
        throw new FumValidationException(Constants.ERROR_SZ_GET_USER_CALL_4xx, String.format(Constants.ERROR_SZ_GET_USER_CALL_4xx_MESSAGE, szId));
      }

      if (response.getStatusCode().is5xxServerError()) {
        throw new FumServiceException(Constants.ERROR_SZ_GET_USER_CALL_5xx, String.format(Constants.ERROR_SZ_GET_USER_CALL_5xx_MESSAGE, szId));
      }

      return response.getBody();
    } catch (Exception e) {
      log.info("Failed to get szId {}: {}", szId, e.getMessage());
      if (e instanceof FumServiceException ||  e instanceof FumValidationException) {
        throw e;
      }
      throw new FumServiceException(Constants.ERROR_SZ_GET_USER_CALL_5xx, String.format(Constants.ERROR_SZ_GET_USER_CALL_5xx_MESSAGE, szId));
    }
  }

  @SneakyThrows
  public SzUserSearch getExternalUserByIdpSubject(String idpSubject) {
    try {
      String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);
      String filter = String.format("username sw %s", idpSubject);

      ResponseEntity<SzUserSearch> response = szClientUAMA.searchUsers(token, filter);

      log.info("SecureZone response for searchUsers: idpSubject {}: {} {}", idpSubject, response.getStatusCode(), response.getBody());

      if (response.getStatusCode().is4xxClientError()) {
        throw new FumValidationException(Constants.ERROR_SZ_GET_USER_CALL_4xx, String.format(Constants.ERROR_SZ_GET_USER_SEARCH_CALL_4xx_MESSAGE, idpSubject));
      }

      if (response.getStatusCode().is5xxServerError()) {
        throw new FumServiceException(Constants.ERROR_SZ_GET_USER_CALL_5xx, String.format(Constants.ERROR_SZ_GET_USER_SEARCH_CALL_5xx_MESSAGE, idpSubject));
      }

      return response.getBody();
    } catch (Exception e) {
      log.info("Failed to get user with idpSubject {}: {}", idpSubject, e.getMessage());
      if (e instanceof FumServiceException ||  e instanceof FumValidationException) {
        throw e;
      }
      throw new FumServiceException(Constants.ERROR_SZ_GET_USER_CALL_5xx, String.format(Constants.ERROR_SZ_GET_USER_SEARCH_CALL_5xx_MESSAGE, idpSubject));
    }
  }
}
