package ca.bnc.wealth.api.userconfiguration.service;

import java.time.Duration;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

/**
 * Manages JWT token revocation by storing revoked tokens in Redis.
 * Tokens are stored with a fixed 30-minute TTL, after which they auto-expire.
 *
 * <p>Key format: {@code revoked-token:{token}} where token is the raw JWT string.
 * A future commons-lib validation filter will check this Redis store and
 * return 401 for any token found here.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class TokenRevocationService {

  private static final String REVOKED_TOKEN_PREFIX = "revoked-token:";
  private static final String REVOKED_VALUE = "revoked";
  private static final Duration TTL = Duration.ofMinutes(30);

  private final RedisTemplate<String, Object> redisTemplate;

  /**
   * Revokes a JWT token by adding it to the Redis blocklist with a 30-minute TTL.
   *
   * @param token the raw JWT token string (without "Bearer " prefix)
   * @throws IllegalArgumentException if the token is blank
   */
  public void revokeToken(String token) {
    if (StringUtils.isBlank(token)) {
      throw new IllegalArgumentException("Token must not be blank");
    }

    String key = REVOKED_TOKEN_PREFIX + token;
    redisTemplate.opsForValue().set(key, REVOKED_VALUE, TTL);
    log.info("Token revoked successfully. ttl={}s", TTL.getSeconds());
  }
}