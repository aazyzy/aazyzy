package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.common.fum.service.UserSearchViewRefreshService;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Thin facade over the shared {@link UserSearchViewRefreshService}. Retained so the existing call
 * sites and bean wiring in user-configuration-api stay unchanged while all refreshes are routed
 * through the single, coalescing (1 running + 1 waiting) refresh service in the common library.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class UserConfigSearchMaterializedRefreshService {

  private final UserSearchViewRefreshService userSearchViewRefreshService;

  public void refreshUserSearchMaterializedView(boolean throwException) {
    userSearchViewRefreshService.refreshAsync(throwException);
  }

  public void refreshUserSearchMaterializedView(Runnable updateAfterRefresh, boolean throwException) {
    userSearchViewRefreshService.refreshAsync(updateAfterRefresh, throwException);
  }

  /**
   * Refresh only if a search-relevant field of the user configuration changed between {@code before}
   * and {@code after}. Use for non-composite write paths that do not change firm / user-group /
   * RR-code assignments (see
   * {@link UserSearchViewRefreshService#refreshAsyncIfSearchFieldChanged}).
   */
  public void refreshUserSearchMaterializedViewIfChanged(
      IamUserConfiguration before, IamUserConfiguration after, boolean throwException) {
    userSearchViewRefreshService.refreshAsyncIfSearchFieldChanged(before, after, throwException);
  }
}
