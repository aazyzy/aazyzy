package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.userconfiguration.model.AssignmentType;
import ca.bnc.wealth.api.userconfiguration.model.R2userStatus;
import ca.bnc.wealth.api.userconfiguration.model.UserConfigurationConstants;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.UserConfigUtils;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.service.FeaturePackageServiceHelper;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.r2.model.R2UserProfile;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ErrorSeverity;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ServiceException;
import ca.bnc.wealth.common.userconfiguration.model.*;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import static ca.bnc.wealth.api.userconfiguration.util.Constants.CXP_IDENTITY_SOURCE;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserConfigValidationService {

  private static final String ERROR_COMPASS_R2 =
      "Failed to get compass R2 Id or compass R2 Id not provided: {}";

  private static final String DWH_UI_MODULE_TYPE = "dwh_ui_module";

  private final UserConfigurationServiceJpa userConfigurationServiceJpa;
  private final R2Service r2Service;
  private final CiamService ciamService;
  private final UserValidationService userValidationService;
  private final UserService userService;
  private final FeaturePackageServiceHelper featurePackageServiceHelper;
  private final ResourceRepository resourceRepository;

  @Value("${platform.env:#{null}}")
  protected String env;

  @Value("${userConfiguration.employee.idp:" + Constants.EMPLOYEE_IDP + "}")
  private String employeeIdp;

  public void checkForUpdatingIdpUserId(
      UserConfiguration currentUserConfiguration, UserConfiguration newUserConfiguration) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    /*Only system user allow to update the idpuserId */

    if (!user.isSystemToken()
        && newUserConfiguration.getIdpUserId() != null
        && !newUserConfiguration.getIdpUserId().equals(currentUserConfiguration.getIdpUserId())) {
      throw new FumServiceException(Constants.ERROR_CODE_UPDATE_USER, Constants.ERROR_UPDATE_IDPUSERIDENTIFIER_NOT_SYSTEMTOKEN);
    }

    if (user.isSystemToken()
        && newUserConfiguration.getIdpUserId() != null
        && currentUserConfiguration.getIdpUserId() != null
        && !newUserConfiguration.getIdpUserId().equals(currentUserConfiguration.getIdpUserId())) {
      OktaUserProfile oktaUserProfile = null;
      try {
        oktaUserProfile = ciamService.getOktaUserProfile(newUserConfiguration.getIdpUserId());
      } catch (Exception e) {
        log.error("can't find IdpUserId {} in okta", newUserConfiguration.getIdpUserId());
      }

      if ((oktaUserProfile == null)
          || (!currentUserConfiguration
              .getUsername()
              .equals(oktaUserProfile.getAccessProfile().getLogin()))) {

        throw new FumServiceException(Constants.ERROR_CODE_UPDATE_USER, Constants.ERROR_UPDATE_IDPUSERIDENTIFIER_WRONG_USERNAME);
      }
    }
  }

  public Map<String, String> validateUserConfigurationCreation(
      UserConfiguration userConfiguration, boolean isNbxUser) {

    //sso user
    if(!UserConfigUtils.isEmpty(userConfiguration.getExternalClientId())) {
      //update the username if it has invalid username
      userConfiguration.setUsername(userService.generateUserNameForSSO(userConfiguration.getFirmId(), userConfiguration.getExternalClientId()));
      //Removing hashed password as ciam call is not working with hashed password
      userConfiguration.setHashedPassword(null);
    }

    // An imported hash becomes the Okta password, so a temporary one would never be used.
    boolean needsTempPassword = UserConfigUtils.isEmpty(userConfiguration.getPassword())
        && UserConfigUtils.isEmpty(userConfiguration.getHashedPassword());

    /** If username and password is not provided then generate */
    if (UserConfigUtils.isEmpty(userConfiguration.getUsername()) || needsTempPassword) {
      /** Generate a temporary username and password */
      UserDetails userDetails =
          new UserDetails()
              .email(userConfiguration.getEmail())
              .firstName(userConfiguration.getFirstName())
              .lastName(userConfiguration.getLastName());
      UserCredentials credentials = this.getUsernameAndTempPassword(userDetails);
      if (UserConfigUtils.isEmpty(userConfiguration.getUsername())) {
        log.info("Generated username {}", credentials.getUsername());
        userConfiguration.setUsername(credentials.getUsername());
      }
      if (needsTempPassword) {
        userConfiguration.setPassword(credentials.getTempPassword());
      }
    }

    /**
     * Suffix the username with the platform environment variable for all non-production
     * environments. This is not applicable if this is a cloned profile or the externalClientId is
     * set
     */
    if (env != null
        && !StringUtils.endsWithIgnoreCase(userConfiguration.getUsername(), "." + env)
        && userConfiguration.getSourceIdpSubject() == null
        && userConfiguration.getExternalClientId() == null) {
      log.info("Username env suffix : ${platform.env}:" + env);
      userConfiguration.setUsername(userConfiguration.getUsername() + "." + env);
    }

    Map<String, String> validationMap = userValidationService.validateUser(userConfiguration);

    /** Checking R2 User Profile */
    if (StringUtils.isNotBlank(userConfiguration.getCompassR2Id())) {
      try {
        Pair<Boolean, String> r2validation = r2ValidationForCreateUser(userConfiguration);
        if (!r2validation.getKey()) {
          validationMap.put(Constants.COMPASS_R2_ID, r2validation.getValue());
        }
      } catch (Exception e) {
        log.error(ERROR_COMPASS_R2, e.getMessage());
        validationMap.put(Constants.COMPASS_R2_ID, Constants.ERROR_R2_NOT_FOUND);
      }
    }

    // Skipping Okta call for NBX users
    if (!isNbxUser) {
      // Checking for Okta Profile
      Optional<OktaUserProfile> oktaProfile =
          ciamService.getOktaUserProfile(userConfiguration.getUsername(), 1);
      if (oktaProfile.isPresent()) {
        validationMap.put(Constants.OKTA_PROFILE, Constants.ERROR_OKTA_PROFILE_FOUND);
      }
    }

    /** If externalClientId is set and associated firm is not SSO enabled */
    if (userConfiguration.getExternalClientId() != null
        && !userValidationService.isExternalSSOEnabled(userConfiguration)) {
      validationMap.put(Constants.EXTERNAL_CLIENT_ID, Constants.ERROR_NOT_SSO_ENABLED_FIRM);
    }

    if(!UserConfigUtils.validUserPreferences(userConfiguration.getUserPreferences())) {
      validationMap.put(Constants.USER_PREFERENCES, Constants.ERROR_USER_PREFERENCES_INVALID);
    }

    return validationMap;
  }

  public UserCredentials getUsernameAndTempPassword(UserDetails userDetails) {
    UserCredentials userCredentials = new UserCredentials();
    userCredentials.username(getUserName(userDetails.getFirstName(), userDetails.getLastName()));
    userCredentials.setTempPassword(
        UserConfigUtils.getTempPassword(userDetails.getFirstName(), userDetails.getLastName()));
    /**
     * Suffix the username with the platform environment variable for all non-production
     * environments
     */
    if (env != null) {
      log.info("Username env suffix : ${platform.env}:" + env);
      userCredentials.setUsername(userCredentials.getUsername() + "." + env);
    }
    return userCredentials;
  }

  private String getUserName(String firstName, String lastName) {
    return Stream.of(firstName + "." + lastName)
        .map(StringUtils::stripAccents)
        .map(userName -> userName.replaceAll("[^a-zA-Z0-9.]", ""))
        .map(String::toLowerCase)
        .map(
            userName -> Pair.of(userName, userConfigurationServiceJpa.getMatchedUserName(userName)))
        .map(username -> Pair.of(username.getKey(), username.getValue().stream().map(String::toLowerCase).toList()))
        .map(username -> UserConfigUtils.getUserName(username, env))
        .filter(username -> username.length() <= UserConfigurationConstants.USERNAME_MAX_LENGTH)
        .findFirst()
        .orElseThrow(
            () ->
                new ServiceException(
                    ErrorSeverity.ERROR, UserConfigurationConstants.USERNAME_MAX_LENGTH_ERROR));
  }

  private Pair<Boolean, String> r2ValidationForCreateUser(UserConfiguration userConfiguration) {
    Pair<R2userStatus, R2UserProfile> r2Profile =
        r2Service.getR2UserProfileWithStatus(userConfiguration.getCompassR2Id());
    switch (r2Profile.getKey()) {
      case WITHOUT_CPX_SUB:
        return Pair.of(true, null);
      case NOT_FOUND:
        return Pair.of(false, Constants.ERROR_R2_NOT_FOUND);
      case WITH_CPX_SUB:
        return Pair.of(false, Constants.ERROR_R2_WITH_CPX_SUB);
      default:
        return Pair.of(false, Constants.ERROR_R2_EXCEPTION);
    }
  }

  private Pair<Boolean, String> r2ValidationForUpdateUser(UserConfiguration userConfiguration) {
    Pair<R2userStatus, R2UserProfile> r2Profile =
        r2Service.getR2UserProfileWithStatus(userConfiguration.getCompassR2Id());
    switch (r2Profile.getKey()) {
      case WITH_CPX_SUB:
        if (r2Profile
            .getValue()
            .getCxUserId()
            .equalsIgnoreCase(userConfiguration.getIdpSubject())) {
          return Pair.of(true, null);
        } else {
          return Pair.of(false, Constants.ERROR_R2_NOT_MATCHED);
        }
      case WITHOUT_CPX_SUB:
        return Pair.of(true, null);
      case NOT_FOUND:
        return Pair.of(false, Constants.ERROR_R2_NOT_FOUND);
      default:
        return Pair.of(false, Constants.ERROR_R2_EXCEPTION);
    }
  }

  public void validateUserUpdateForNonNbin(UserConfiguration userConfiguration) {
    validateFieldsForNonNbin(userConfiguration);
    if (StringUtils.isNotBlank(userConfiguration.getCompassR2Id())) {
      try {
        Pair<Boolean, String> r2validation = r2ValidationForUpdateUser(userConfiguration);
        if (!r2validation.getKey()) {
          log.error("R2 Validation failed with error:" + r2validation.getValue());
          throw new FumServiceException(Constants.ERROR_R2_NOT_FOUND, r2validation.getValue());
        }
      } catch (Exception e) {
        log.error(ERROR_COMPASS_R2, e.getMessage());
        throw new IllegalArgumentException(Constants.ERROR_R2_NOT_FOUND);
      }
    }
  }

  /**
   * validates whether the BngfIdentitySource in okta profile and BngfIdentitySource(idp) in Id token are same.
   * throws critical error when there is mismatch
   *
   * @param userConfiguration userConfiguration mapped from Id Token
   */
  public void validateIdp(UserConfiguration userConfiguration) {
    UserOktaProfile oktaProfile = userService.getOktaProfile(userConfiguration.getUsername());
    if (!CXP_IDENTITY_SOURCE.equalsIgnoreCase(oktaProfile.getAccessProfile().getBngfIdentitySource()) &&
            !StringUtils.equals(oktaProfile.getAccessProfile().getBngfIdentitySource(), userConfiguration.getIdp())) {
      log.error("CRITICAL: Firm mismatch");
      throw new IllegalArgumentException("CRITICAL: Firm mismatch");
    }
  }

  public void validateUserCreationForNonNbin(UserConfiguration userConfiguration) {
    validateFieldsForNonNbin(userConfiguration);
    validateAndSetActivationDate(userConfiguration);
    Map<String, String> errorMap = userValidationService.validateUser(userConfiguration);
    if (!errorMap.isEmpty()) {
      throw new IllegalArgumentException(String.join(",", errorMap.values()));
    }

    if (StringUtils.isNotBlank(userConfiguration.getCompassR2Id())) {
      try {
        Pair<Boolean, String> r2validation = r2ValidationForCreateUser(userConfiguration);
        if (!r2validation.getKey()) {
          throw new IllegalArgumentException(r2validation.getValue());
        }
      } catch (Exception e) {
        log.error(ERROR_COMPASS_R2, e.getMessage());
        throw new IllegalArgumentException(Constants.ERROR_R2_NOT_FOUND);
      }
    }
  }

  public void validateFieldsForNonNbin(UserConfiguration userConfiguration) {
    validateUserCreationMandatoryFieldsCommon(userConfiguration);
    if (StringUtils.isBlank(userConfiguration.getIdpSubject())) {
      throw new IllegalArgumentException(Constants.ERROR_IDP_SUBJECT_NULL);
    }
    // Employee (internal) users authenticate via the IAMi tenant and have no Okta/CIAM profile,
    // so their idpUserId is legitimately blank. Require idpUserId only for external (SSO) non-Nbin
    // users, which do have an Okta profile.
    if (!isEmployeeIdp(userConfiguration.getIdp())
        && StringUtils.isBlank(userConfiguration.getIdpUserId())) {
      throw new IllegalArgumentException(Constants.ERROR_IDP_USER_ID_NULL);
    }
    if (StringUtils.isBlank(userConfiguration.getUsername())) {
      throw new IllegalArgumentException(Constants.ERROR_IDP_USER_NAME_NULL);
    }
  }

  private boolean isEmployeeIdp(String idp) {
    return StringUtils.isNotBlank(employeeIdp) && employeeIdp.equalsIgnoreCase(idp);
  }

  public void validateUserCreationMandatoryFields(UserConfiguration userConfiguration) {
    validateUserCreationMandatoryFieldsCommon(userConfiguration);
    validateAndSetActivationDate(userConfiguration);
    if (userConfiguration.getFeaturePackage() == null) {
      throw new IllegalArgumentException(Constants.ERROR_FEATURE_PACKAGE_NULL);
    }
  }

  public void validateAndSetActivationDate(UserConfiguration userConfiguration) {
    if (userConfiguration.getActivationDate() == null) {
      log.info(
          String.format(
              "validateUserCreationMandatoryFields: %s : Activation date is null, setting it to default date",
              userConfiguration.getUsername()));
      userConfiguration.setActivationDate(LocalDateTime.parse(Constants.DEFAULT_ACTIVATION_DATE));
    }
  }

  public void validateUserCreationMandatoryFieldsCommon(UserConfiguration userConfiguration) {
    if (StringUtils.isBlank(userConfiguration.getFirstName())) {
      throw new IllegalArgumentException(Constants.ERROR_FIRSTNAME_NULL);
    }

    if(!(UserConfigUtils.validateFieldLength(userConfiguration.getFirstName()))) {
      throw new IllegalArgumentException(Constants.ERROR_FIRSTNAME_INVALID);
    }

    if (StringUtils.isBlank(userConfiguration.getLastName())) {
      throw new IllegalArgumentException(Constants.ERROR_LASTNAME_NULL);
    }

    if(!(UserConfigUtils.validateFieldLength(userConfiguration.getLastName()))) {
      throw new IllegalArgumentException(Constants.ERROR_LASTNAME_INVALID);
    }

    if (StringUtils.isBlank(userConfiguration.getEmail())) {
      throw new IllegalArgumentException(Constants.ERROR_EMAIL_NULL);
    }

    if (!UserConfigUtils.validateEmail(userConfiguration.getEmail())) {
      throw new IllegalArgumentException(Constants.ERROR_EMAIL_INVALID_FORMAT);
    }

    if (StringUtils.isBlank(userConfiguration.getPreferredLanguage())) {
      throw new IllegalArgumentException(Constants.ERROR_PREFERREDLANGUAGE_NULL);
    }
  }

  public void validateUserDetailsMandatoryFields(UserDetails userDetails) {
    if (UserConfigUtils.isEmpty(userDetails.getFirstName())
        || UserConfigUtils.isEmpty(userDetails.getLastName())
        || UserConfigUtils.isEmpty(userDetails.getEmail())) {
      throw new ServiceException(
          ErrorSeverity.ERROR, "First Name or Last Name or email cannot be empty strings");
    }
  }

  public void validateUserPreferredLanguage(UserPreferredLanguage userPreferredLanguage) {
    if (userPreferredLanguage == null || userPreferredLanguage.getPreferredLanguage() == null) {
      throw new IllegalArgumentException(Constants.ERROR_PREFERREDLANGUAGE_NULL);
    }
  }

  public void validateUpdateUserStatus(UpdateUserStatus updateUserStatus) {
    if (updateUserStatus == null || updateUserStatus.getStatus() == null) {
      throw new FumValidationException(
          Constants.ERROR_UPDATE_USER_STATUS_INPUT_CODE,
          Constants.ERROR_UPDATE_USER_STATUS_INPUT_MESSAGE);
    }
  }

  public void validateAssignRequest(AssignRequest assignRequest) {
    Optional.ofNullable(assignRequest)
        .ifPresentOrElse(
            request -> validateAssigneeId(request.getAssigneeId()),
            () -> {
              throw new IllegalArgumentException(Constants.ERROR_ASSIGNEE_NULL);
            });
  }

  public void validateResourceName(ResourceName resourceNameRequest) {
    if (resourceNameRequest == null || resourceNameRequest.getResourceName() == null) {
      throw new IllegalArgumentException(Constants.ERROR_INVALID_RESOURCE_NAME);
    }
  }

  public void validateDwhResourceName(ResourceName resourceNameRequest) {
    validateResourceName(resourceNameRequest);
    resourceRepository.findFirstByTypeAndName(DWH_UI_MODULE_TYPE, resourceNameRequest.getResourceName())
        .orElseThrow(() -> new FumValidationException(
            Constants.ERROR_INVALID_RESOURCE_NAME,
            String.format("Resource '%s' is not a valid DWH resource", resourceNameRequest.getResourceName())));
  }

  public Set<String> getDwhResourceNames() {
    return resourceRepository.findByType(DWH_UI_MODULE_TYPE).stream()
        .map(Resource::getName)
        .collect(Collectors.toSet());
  }

  public void validateUserGroupName(UserGroupName userGroupNameRequest) {
    if (userGroupNameRequest == null || userGroupNameRequest.getUserGroupName() == null) {
      throw new IllegalArgumentException(Constants.ERROR_INVALID_RESOURCE_NAME);
    }
  }

  public void validateRrRanges(List<RRRange> rrRanges) {
    Optional.ofNullable(rrRanges)
        .ifPresentOrElse(
            ranges -> {
              if (ranges.isEmpty()) {
                throw new IllegalArgumentException(Constants.ERROR_RR_RANGES_INVALID);
              }
            },
            () -> {
              throw new IllegalArgumentException(Constants.ERROR_RR_RANGES_NULL);
            });
  }

  public void validateAssigneeId(Integer assigneeId) {
    if (Integer.valueOf(0).compareTo(assigneeId) >= 0) {
      throw new IllegalArgumentException(Constants.ERROR_ASSIGNEE_ID_INVALID);
    }
  }

  public AssignmentType getAssignmentTypeInstance(String assignmentType) {
    return Optional.ofNullable(assignmentType)
        .map(
            type ->
                AssignmentType.createInstance(type)
                    .orElseThrow(
                        () ->
                            new IllegalArgumentException(Constants.ERROR_ASSIGNMENT_TYPE_INVALID)))
        .orElseThrow(() -> new IllegalArgumentException(Constants.ERROR_ASSIGNMENT_TYPE_NULL));
  }

  public void validateAssignFeaturePackageRequest(AssignRequest assignRequest) {
    validateAssignRequest(assignRequest);
    userConfigurationServiceJpa
        .findFeaturePackage(assignRequest.getAssigneeId())
        .ifPresentOrElse(
            featurePackage -> {
              if (!featurePackage.isActive()) {
                throw new IllegalArgumentException(Constants.ERROR_INVALID_FEATURE_PACKAGE);
              }
            },
            () -> {
              throw new IllegalArgumentException(Constants.ERROR_INVALID_FEATURE_PACKAGE);
            });
  }

  public void validateCreateNbxUserConfiguration(UserConfiguration userConfiguration) {
    validateUserCreationMandatoryFieldsCommon(userConfiguration);
    validateAndSetActivationDate(userConfiguration);

    Map<String, String> errorMap = userValidationService.validateUser(userConfiguration);
    if (!errorMap.isEmpty()) {
      throw new IllegalArgumentException(String.join(",", errorMap.values()));
    }

    validateIfUserExistWithUniqueEmail(userConfiguration.getEmail());
  }

  public void validateUpdateNbxUserConfiguration(String userId, NbxUserConfiguration nbxUserConfiguration) {

    if (nbxUserConfiguration == null) {
      throw new IllegalArgumentException(Constants.ERROR_NBXUSERCONFIGURATION_NULL);
    }

    if(nbxUserConfiguration.getFirstName() == null &&
        nbxUserConfiguration.getLastName() == null &&
        nbxUserConfiguration.getEmail() == null &&
        nbxUserConfiguration.getPreferredLanguage() == null) {
      throw new IllegalArgumentException(Constants.ERROR_NBXUSERCONFIGURATION_NULL);
    }

    IamUserConfiguration iamUserConfiguration = userConfigurationServiceJpa.getUserByIdpSubject(userId).orElse(null);
    if (iamUserConfiguration == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userId));
    }

    if(!isNbxUser(iamUserConfiguration)) {
      throw new FumValidationException(Constants.ERROR_NOT_NBX_USER_CODE,
          String.format(Constants.ERROR_NOT_NBX_USER_MESSAGE, userId));
    }

    NbxUserConfiguration updateNbxUserConfigurationToValidate =
        getUserInfoForUpdateUserValidation(nbxUserConfiguration, iamUserConfiguration);
    validateIfUserExistWithUniqueEmail(updateNbxUserConfigurationToValidate.getEmail());

  }

  private void validateIfUserExistWithUniqueEmail(String email) {
    Optional<IamUserConfiguration> user = userConfigurationServiceJpa.getUserByEmail(email);
    if (user.isPresent()) {
      throw new FumValidationException(Constants.ERROR_USERNAME_EXIST, Constants.ERROR_USER_ALREADY_EXISTS + " " + user.get().getUsername());
    }
  }

  private boolean isNbxUser(IamUserConfiguration iamUserConfiguration) {
    return iamUserConfiguration.getSource() != null && iamUserConfiguration.getSource().equals(
        UserConfigurationConstants.NBX_SOURCE);
  }

  private NbxUserConfiguration getUserInfoForUpdateUserValidation(NbxUserConfiguration dto,
      IamUserConfiguration user) {
    NbxUserConfiguration updateNbxUserConfiguration = new NbxUserConfiguration();
    updateNbxUserConfiguration.setFirstName(dto.getFirstName() != null ? dto.getFirstName() :
        user.getFirstName());
    updateNbxUserConfiguration.setLastName(dto.getLastName() != null ? dto.getLastName() :
        user.getLastName());
    updateNbxUserConfiguration.setEmail(dto.getEmail() != null ? dto.getEmail() :
        user.getEmail());

    return updateNbxUserConfiguration;
  }

  public void validateUpdateUserExternalId(UamaUpdateUserExternalId updateUserExternalId) {
    if (updateUserExternalId == null || updateUserExternalId.getExternalUserId() == null) {
      throw new FumValidationException(Constants.ERROR_EXTERNAL_ID_EMPTY, Constants.ERROR_EXTERNAL_ID_EMPTY_MESSAGE);
    }
  }
}
