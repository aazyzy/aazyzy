package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.UserConfigUtils;
import ca.bnc.wealth.common.fum.service.CustomThreadPoolExecutor;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.service.IamScheduleService;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.jpa.utils.RepositoryUtils;
import ca.bnc.wealth.common.userconfiguration.model.OktaStatusSyncRequest;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.LongStream;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserConfigurationDataSyncService {

  private static final String SCHEDULER_NAME = "IDP_USER_UPDATE";
  private final IamUserConfigurationRepository iamUserConfigurationRepository;
  private final CiamService ciamService;
  private final UserStateService userStateService;
  private final RedisCacheOperationService redisCacheOperationService;
  private final UserService userService;

  @Value("${userConfiguration.idpUserStatus.schedule.query.retry:2}")
  private int retryCountForGetOktaUserProfile;
  @Value("${userConfiguration.idpUserStatus.chunkSize:50}")
  private int chunkSize;
  @Value("${userConfiguration.idpUserStatus.timeBetweenChunkExec:60000}")
  private int timeBetweenChunkExec;
  @Value("${userConfiguration.idpUserStatus.disableDelay:true}")
  private boolean disableDelay;

  @CustomThreadPoolExecutor(isBlockingQueue = false)
  public void userOktaStatusSync(OktaStatusSyncRequest oktaStatusSyncRequest) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldMap = new HashMap<>();
    if(CollectionUtils.isNotEmpty(oktaStatusSyncRequest.getIdpSubjects())) {
      fieldMap.put("idpSubject", Pair.of(EnumQueryCriteria.IN, oktaStatusSyncRequest.getIdpSubjects()));
    }
    if(CollectionUtils.isNotEmpty(oktaStatusSyncRequest.getFirmIds())) {
      fieldMap.put("userAssignmentFirms.assignmentType", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.F.name()));
      fieldMap.put("userAssignmentFirms.firm.firmId", Pair.of(EnumQueryCriteria.IN, oktaStatusSyncRequest.getFirmIds()));
    }
    Specification<IamUserConfiguration> spec = new Specification<>(fieldMap);
    List<IamUserConfiguration> userConfigurationList = iamUserConfigurationRepository.findAll(spec);

    log.info("Total user configurations found for okta status sync: {}", userConfigurationList.size());
    idpStatusUpdateSchedule(userConfigurationList);
  }

  public void idpStatusUpdateSchedule(List<IamUserConfiguration> iamUserConfigurations) {
    ListUtils.partition(iamUserConfigurations, chunkSize).stream()
        .peek(lst -> this.waitForNextExec())
        .flatMap(Collection::stream)
        .forEach(iamUserConfiguration -> {
          getOktaProfileAndUpdate(iamUserConfiguration);
          redisCacheOperationService.deleteUserConfigurationCache(iamUserConfiguration.getIdpSubject(), Integer.valueOf(iamUserConfiguration.getUserConfigurationId().intValue()),
              iamUserConfiguration.getIdpUserIdentifier());
          // caching r2Id and security zone id
          userService.getCompassR2Id(iamUserConfiguration.getIdpSubject());
          userService.getSecureZoneId(iamUserConfiguration.getIdpUserIdentifier());
        });
  }

  private void getOktaProfileAndUpdate(IamUserConfiguration iamUserConfiguration) {
    ciamService.getOktaUserProfile(iamUserConfiguration.getIdpUserIdentifier(), retryCountForGetOktaUserProfile)
        .ifPresent(
            oktaUserProfile -> userStateService.updateStateFromOktaProfile(iamUserConfiguration, oktaUserProfile)
        );
  }

  @Async
  public void asyncOktaUserProfile(String idpUserId,
      ca.bnc.wealth.common.userconfiguration.model.UserConfiguration userConfiguration) {
    syncOktaUserProfile(idpUserId, userConfiguration);
  }

  public void syncOktaUserProfile(String idpUserId,
      ca.bnc.wealth.common.userconfiguration.model.UserConfiguration userConfiguration) {
    if (isSyncOktaUserProfileRequired(userConfiguration)) {
      ciamService.syncOktaUserProfile(idpUserId, retryCountForGetOktaUserProfile);
    }
  }

  @SneakyThrows
  private void shutdownAndAwait(ExecutorService executorService) {
    executorService.shutdown();
    try {
      executorService.awaitTermination(20, TimeUnit.MINUTES);
    } catch (InterruptedException e) {
      executorService.shutdownNow();
      log.error("Error in executor service: {}", e.getMessage());
      throw e;
    }
  }

  boolean isSyncOktaUserProfileRequired(
      ca.bnc.wealth.common.userconfiguration.model.UserConfiguration userConfiguration) {
    return
      Constants.CPX_IDP.equalsIgnoreCase(userConfiguration.getIdp())
      && !(UserConfigUtils.isEmpty(userConfiguration.getFirstName()) 
        && UserConfigUtils.isEmpty(userConfiguration.getLastName()) 
        && UserConfigUtils.isEmpty(userConfiguration.getPreferredLanguage()));
  }

  @SneakyThrows
  private void waitForNextExec() {
    if( disableDelay ) {
      return;
    }
    log.info("Waiting for " + timeBetweenChunkExec + " millsecond before starting next chunk");
    Thread.sleep(timeBetweenChunkExec);
    log.info("will start the next chunk of records");
  }
}
