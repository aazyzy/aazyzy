package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.userconfiguration.jpa.GenericUserSearchCriteria;
import ca.bnc.wealth.api.userconfiguration.jpa.UserSearchCriteria;
import ca.bnc.wealth.api.userconfiguration.jpa.UserSearchMaterializedCriteria;
import ca.bnc.wealth.api.userconfiguration.model.state.UserStateEnum;
import ca.bnc.wealth.api.userconfiguration.util.MapperUtils;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import ca.bnc.wealth.common.jpa.entity.iam.UserGroup;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserConfigSearchMaterializedViewRepository;
import ca.bnc.wealth.common.jpa.specification.SpecificationWithQueryAndFilter;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.jpa.utils.EnumSpecificationOperation;
import ca.bnc.wealth.common.jpa.utils.Filter;
import ca.bnc.wealth.common.jpa.utils.QueryParameterCombination;
import ca.bnc.wealth.common.jpa.utils.QueryParameters;
import ca.bnc.wealth.common.jpa.utils.RepositoryUtils;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearch;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearchFilter;
import ca.bnc.wealth.common.userconfiguration.model.GroupByResponse;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserSearch;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import jakarta.persistence.criteria.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

@Service
@Slf4j
public class UserConfigurationSearchService {

  @Autowired
  private FirmRepository firmConfigurationRepository;

  @Autowired
  private IamUserConfigurationRepository userConfigurationRepository;

  @Autowired
  private UserAssignmentService userAssignmentService;

  @Autowired
  private UserConfigSearchMaterializedViewRepository userConfigSearchMaterializedViewRepository;


  @Async
  public Future<Pair<Integer, List<GroupByResponse>>> searchUserView(String idpSubject, GenericSearch userSearch,
      Firm primaryFirm, Firm searchFirm, boolean isPrimaryFirmSearch) {
    SpecificationWithQueryAndFilter spec = this.getViewSpecification(idpSubject, userSearch,
        primaryFirm,
        searchFirm, isPrimaryFirmSearch);
    PageRequest pageRequest = this.getPageRequest(userSearch, isPrimaryFirmSearch);

    Page<UserConfigSearchMaterializedView> jpaResponse = this.userConfigSearchMaterializedViewRepository.findAll(
        spec.and(notDecommissioned()), pageRequest);

    List<UserConfiguration> lst = jpaResponse.toList().stream()
        .map(MapperUtils::toDto).toList();

    return CompletableFuture.completedFuture(Pair.of((int) jpaResponse.getTotalElements(),
        this.groupBy(lst, userSearch.getGroupBy())));
  }

  // NWPI-15087: a decommissioned account stays readable by id but is never listed; null-safe, case-insensitive.
  static Specification<UserConfigSearchMaterializedView> notDecommissioned() {
    return (root, query, cb) -> {
      Path<String> state = root.get("state");
      return cb.or(cb.isNull(state), cb.notEqual(cb.lower(state), UserStateEnum.DECOMMISSIONED.dbValue));
    };
  }

  @Transactional
  public Pair<Integer, List<GroupByResponse>> search(String idpSubject, GenericSearch userSearch,
      Firm primaryFirm, Firm searchFirm, boolean isPrimaryFirmSearch) {
    SpecificationWithQueryAndFilter spec = this.getSpecification(idpSubject, userSearch,
        primaryFirm,
        searchFirm, isPrimaryFirmSearch);
    PageRequest pageRequest = this.getPageRequest(userSearch, isPrimaryFirmSearch);

    Page<IamUserConfiguration> jpaResponse = this.userConfigurationRepository.findAll(
        spec, pageRequest);

    List<UserConfiguration> lst = jpaResponse.toList().stream()
        .map(MapperUtils::toDto).toList();
    List<String> idpSubjects = lst.stream().map(UserConfiguration::getIdpSubject).toList();
    updateUserGroup(idpSubjects, lst);
    updateFirm(idpSubjects, lst);
    return Pair.of((int) jpaResponse.getTotalElements(),
        this.groupBy(lst, userSearch.getGroupBy()));
  }


   SpecificationWithQueryAndFilter getSpecification(String idpSubject,
      GenericSearch userSearch,
      Firm primaryFirm, Firm searchFirm, boolean isActiveFirmSearch) {
    Map<String, Object> derivedFieldValueMap = new HashMap<>();

    if (StringUtils.isNotBlank(userSearch.getSearchText())) {
      if (isNumber(userSearch.getSearchText())) {
        derivedFieldValueMap.put(GenericUserSearchCriteria.userConfigurationId.name(),
            userSearch.getSearchText());
      }
      derivedFieldValueMap.put(GenericUserSearchCriteria.idpSubject.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(GenericUserSearchCriteria.idpUserId.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(GenericUserSearchCriteria.username.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(GenericUserSearchCriteria.firstName.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(GenericUserSearchCriteria.lastName.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(GenericUserSearchCriteria.email.name(), userSearch.getSearchText());
      if(userSearch.getSearchText().equalsIgnoreCase("true")) {
        derivedFieldValueMap.put(GenericUserSearchCriteria.active.name(), true );
      } else if( userSearch.getSearchText().equalsIgnoreCase("false")) {
        derivedFieldValueMap.put(GenericUserSearchCriteria.active.name(), false);
      }
      derivedFieldValueMap.put(GenericUserSearchCriteria.ossId.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(GenericUserSearchCriteria.ossProxyId.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(GenericUserSearchCriteria.ossUserId.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(GenericUserSearchCriteria.ossGroupId.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(GenericUserSearchCriteria.state.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(GenericUserSearchCriteria.stateAction.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(GenericUserSearchCriteria.stateDescription.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(GenericUserSearchCriteria.userGroup.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(GenericUserSearchCriteria.fromRRCode.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(GenericUserSearchCriteria.toRRCode.name(), userSearch.getSearchText());
    }

    if (isActiveFirmSearch) {
      derivedFieldValueMap.put(GenericUserSearchCriteria.firmIdEquals.name(),
          searchFirm.getFirmEntityId());
    } else {
      if (primaryFirm.getFirmId().equalsIgnoreCase("NBIN")) {
        derivedFieldValueMap.put(GenericUserSearchCriteria.firmIdNotEquals.name(),
            searchFirm.getFirmEntityId());
      } else {
        List<Long> firmIdList = firmConfigurationRepository.getAllFirmsByIdpSubject(idpSubject)
            .stream()
            .filter(id -> !(id.equals(searchFirm.getFirmEntityId())))
            .toList();
        derivedFieldValueMap.put(
            GenericUserSearchCriteria.firmEntityIdsIN.name(), firmIdList);
      }
    }

    // Ignore fields from the search query
    Optional.ofNullable(userSearch.getIgnoreFields()).stream()
        .flatMap(Collection::stream)
        .forEach(derivedFieldValueMap::remove);

    QueryParameterCombination query = new QueryParameterCombination();
    query.setOperation(EnumSpecificationOperation.AND);

    QueryParameters leftChild = new QueryParameters();
    leftChild.setOperation(EnumSpecificationOperation.AND);
    List<String> firmCondetionIds = Arrays.asList(
        GenericUserSearchCriteria.userAssignmentFirm.name(),
        GenericUserSearchCriteria.firmEntityIdsIN.name(),
        GenericUserSearchCriteria.firmIdEquals.name(),
        GenericUserSearchCriteria.firmIdNotEquals.name());
    // only one condition is add to the final sql query because other 2 are removed from derivedFieldValueMap
    leftChild.setParameter(firmCondetionIds);

    QueryParameterCombination rightChild = new QueryParameterCombination();
    rightChild.setOperation(EnumSpecificationOperation.OR);

    QueryParameters rightChild1 = new QueryParameters();
    rightChild1.setOperation(EnumSpecificationOperation.OR);
    rightChild1.setParameter(Arrays.asList(
        GenericUserSearchCriteria.userConfigurationId.name(),
        GenericUserSearchCriteria.idpSubject.name(),
        GenericUserSearchCriteria.idpUserId.name(),
        GenericUserSearchCriteria.username.name(),
        GenericUserSearchCriteria.firstName.name(),
        GenericUserSearchCriteria.lastName.name(),
        GenericUserSearchCriteria.email.name(),
        GenericUserSearchCriteria.active.name(),
        GenericUserSearchCriteria.ossId.name(),
        GenericUserSearchCriteria.ossProxyId.name(),
        GenericUserSearchCriteria.ossUserId.name(),
        GenericUserSearchCriteria.ossGroupId.name(),
        GenericUserSearchCriteria.state.name(),
        GenericUserSearchCriteria.stateAction.name(),
        GenericUserSearchCriteria.stateDescription.name()
    ));

    QueryParameterCombination rightChild2 = new QueryParameterCombination();
    rightChild2.setOperation(EnumSpecificationOperation.OR);

    QueryParameters usergroup = new QueryParameters();
    usergroup.setOperation(EnumSpecificationOperation.AND);
    usergroup.setParameter(Arrays.asList(GenericUserSearchCriteria.userAssignmentGroup.name(),
        GenericUserSearchCriteria.userGroup.name()));

    QueryParameterCombination rrCode = new QueryParameterCombination();
    rrCode.setOperation(EnumSpecificationOperation.OR);
    QueryParameters fromRR = new QueryParameters();
    fromRR.setOperation(EnumSpecificationOperation.AND);
    fromRR.setParameter(Arrays.asList(GenericUserSearchCriteria.userAssignmentRrCode.name(),
        GenericUserSearchCriteria.fromRRCode.name()));
    QueryParameters toRR = new QueryParameters();
    toRR.setOperation(EnumSpecificationOperation.AND);
    toRR.setParameter(Arrays.asList(GenericUserSearchCriteria.userAssignmentRrCode.name(),
        GenericUserSearchCriteria.toRRCode.name()));
    rrCode.setSubQueryRight(fromRR);
    rrCode.setSubQueryLeft(toRR);

    rightChild2.setSubQueryLeft(rrCode);
    rightChild2.setSubQueryRight(usergroup);

    rightChild.setSubQueryRight(rightChild1);
    rightChild.setSubQueryLeft(rightChild2);

    query.setSubQueryLeft(leftChild);
    query.setSubQueryRight(rightChild);

    List<Filter> filters = getFilter(userSearch.getFilter());

    return new SpecificationWithQueryAndFilter<IamUserConfiguration, UserSearch, GenericUserSearchCriteria>(
        null, GenericUserSearchCriteria.class, derivedFieldValueMap, query, filters, true);
  }
   SpecificationWithQueryAndFilter getViewSpecification(String idpSubject,
      GenericSearch userSearch,
      Firm primaryFirm, Firm searchFirm, boolean isActiveFirmSearch) {
    Map<String, Object> derivedFieldValueMap = new HashMap<>();

    if (StringUtils.isNotBlank(userSearch.getSearchText())) {
      if (isNumber(userSearch.getSearchText())) {
        derivedFieldValueMap.put(UserSearchMaterializedCriteria.USER_CONFIGURATION_ID.name(),
            userSearch.getSearchText());
      }
      derivedFieldValueMap.put(UserSearchMaterializedCriteria.IDP_SUBJECT.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(UserSearchMaterializedCriteria.IDP_USER_ID.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(UserSearchMaterializedCriteria.USERNAME.name(), userSearch.getSearchText());

      String[] userSearchTexts = userSearch.getSearchText().replaceAll("\\s+", " ").split(" ");
      for (String userSearchText : userSearchTexts) {
        derivedFieldValueMap.put(UserSearchMaterializedCriteria.FIRST_NAME.name(), userSearchText);
        derivedFieldValueMap.put(UserSearchMaterializedCriteria.LAST_NAME.name(), userSearchText);
      }
      derivedFieldValueMap.put(UserSearchMaterializedCriteria.EMAIL.name(), userSearch.getSearchText());
      if(userSearch.getSearchText().equalsIgnoreCase("true")) {
        derivedFieldValueMap.put(UserSearchMaterializedCriteria.ACTIVE.name(), true );
      } else if( userSearch.getSearchText().equalsIgnoreCase("false")) {
        derivedFieldValueMap.put(UserSearchMaterializedCriteria.ACTIVE.name(), false);
      }
      derivedFieldValueMap.put(UserSearchMaterializedCriteria.OSS_ID.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(UserSearchMaterializedCriteria.OSS_PROXY_ID.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(UserSearchMaterializedCriteria.OSS_USER_ID.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(UserSearchMaterializedCriteria.OSS_GROUP_ID.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(UserSearchMaterializedCriteria.STATE.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(UserSearchMaterializedCriteria.STATE_ACTION.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(UserSearchMaterializedCriteria.STATE_DESCRIPTIION.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(UserSearchMaterializedCriteria.USER_GROUP.name(), userSearch.getSearchText());
      derivedFieldValueMap.put(UserSearchMaterializedCriteria.RR_RANGES.name(), userSearch.getSearchText());
    }

    if (isActiveFirmSearch) {
      derivedFieldValueMap.put(UserSearchMaterializedCriteria.FIRM_ID_EQUALS.name(),
          searchFirm.getFirmEntityId());
    } else {
      if (primaryFirm != null) {
        if (primaryFirm.getFirmId().equalsIgnoreCase("NBIN")) {
          derivedFieldValueMap.put(UserSearchMaterializedCriteria.FIRM_ID_NOT_EQUALS.name(),
              searchFirm.getFirmEntityId());
        } else {
          List<Long> firmIdList = firmConfigurationRepository.getAllFirmsByIdpSubject(idpSubject)
              .stream()
              .filter(id -> !(id.equals(searchFirm.getFirmEntityId())))
              .collect(Collectors.toList());
          derivedFieldValueMap.put(
              UserSearchMaterializedCriteria.FIRM_ENTITY_IDS_IN.name(), firmIdList);
        }
      }
    }

    // Ignore fields from the search query
    Optional.ofNullable(userSearch.getIgnoreFields()).stream()
        .flatMap(Collection::stream)
        .forEach(derivedFieldValueMap::remove);

    QueryParameterCombination query = new QueryParameterCombination();
    query.setOperation(EnumSpecificationOperation.AND);

    QueryParameters leftChild = new QueryParameters();
    leftChild.setOperation(EnumSpecificationOperation.AND);
    List<String> firmCondetionIds = Arrays.asList(
        UserSearchMaterializedCriteria.FIRM_ENTITY_IDS_IN.name(),
        UserSearchMaterializedCriteria.FIRM_ID_EQUALS.name(),
        UserSearchMaterializedCriteria.FIRM_ID_NOT_EQUALS.name());
    // only one condition is add to the final sql query because other 2 are removed from derivedFieldValueMap
    leftChild.setParameter(firmCondetionIds);

    QueryParameters rightChild = new QueryParameters();
    rightChild.setOperation(EnumSpecificationOperation.OR);

    rightChild.setParameter(Arrays.asList(
        UserSearchMaterializedCriteria.USER_CONFIGURATION_ID.name(),
        UserSearchMaterializedCriteria.IDP_SUBJECT.name(),
        UserSearchMaterializedCriteria.IDP_USER_ID.name(),
        UserSearchMaterializedCriteria.IDP.name(),
        UserSearchMaterializedCriteria.USERNAME.name(),
        UserSearchMaterializedCriteria.FIRST_NAME.name(),
        UserSearchMaterializedCriteria.LAST_NAME.name(),
        UserSearchMaterializedCriteria.EMAIL.name(),
        UserSearchMaterializedCriteria.ACTIVE.name(),
        UserSearchMaterializedCriteria.OSS_ID.name(),
        UserSearchMaterializedCriteria.OSS_PROXY_ID.name(),
        UserSearchMaterializedCriteria.OSS_USER_ID.name(),
        UserSearchMaterializedCriteria.OSS_GROUP_ID.name(),
        UserSearchMaterializedCriteria.STATE.name(),
        UserSearchMaterializedCriteria.STATE_ACTION.name(),
        UserSearchMaterializedCriteria.STATE_DESCRIPTIION.name(),
        UserSearchMaterializedCriteria.USER_GROUP.name(),
        UserSearchMaterializedCriteria.RR_RANGES.name()
    ));
    query.setSubQueryLeft(leftChild);
    query.setSubQueryRight(rightChild);

    List<Filter> filters = getFilter(userSearch.getFilter());

    return new SpecificationWithQueryAndFilter<>(
            null, UserSearchMaterializedCriteria.class, derivedFieldValueMap, query, filters, true);

  }

  public SpecificationWithQueryAndFilter getSpecification(String idpSubject,
      UserSearch userSearch, long rrCodeBase10, List<Long> firmIdList) {
    Map<String, Object> derivedFieldValueMap = new HashMap<>();

    Optional.ofNullable(userSearch.getUserConfigurationId()).ifPresent(v -> derivedFieldValueMap.put(
        UserSearchCriteria.userConfigurationId.name(), v));
    Optional.ofNullable(userSearch.getIdpSubject()).ifPresent(v -> derivedFieldValueMap.put(
        UserSearchCriteria.idpSubject.name(), v));
    Optional.ofNullable(userSearch.getIdpUserId()).ifPresent(v -> derivedFieldValueMap.put(
        UserSearchCriteria.idpUserId.name(), v));
    Optional.ofNullable(userSearch.getUsername()).ifPresent(v -> derivedFieldValueMap.put(
        UserSearchCriteria.username.name(), v));
    Optional.ofNullable(userSearch.getFirstName()).ifPresent(v -> derivedFieldValueMap.put(
        UserSearchCriteria.firstName.name(), v));
    Optional.ofNullable(userSearch.getLastName()).ifPresent(v -> derivedFieldValueMap.put(
        UserSearchCriteria.lastName.name(), v));
    Optional.ofNullable(userSearch.getEmail()).ifPresent(v -> derivedFieldValueMap.put(
        UserSearchCriteria.email.name(), v));
    Optional.ofNullable(userSearch.getOssId()).ifPresent(v -> derivedFieldValueMap.put(
        UserSearchCriteria.ossId.name(), v));
    Optional.ofNullable(userSearch.getOssProxyId()).ifPresent(v -> derivedFieldValueMap.put(
        UserSearchCriteria.ossProxyId.name(), v));
    Optional.ofNullable(userSearch.getOssUserId()).ifPresent(v -> derivedFieldValueMap.put(
        UserSearchCriteria.ossUserId.name(), v));
    Optional.ofNullable(userSearch.getOssGroupId()).ifPresent(v -> derivedFieldValueMap.put(
        UserSearchCriteria.ossGroupId.name(), v));
    Optional.ofNullable(userSearch.getStatus()).ifPresent(v -> derivedFieldValueMap.put(
        UserSearchCriteria.statusCode.name(), v));
    Optional.ofNullable(userSearch.getUserGroup()).ifPresent(v -> derivedFieldValueMap.put(
        UserSearchCriteria.userGroup.name(), v));
    Optional.ofNullable(userSearch.getFromRRCode()).ifPresent(v -> derivedFieldValueMap.put(
        UserSearchCriteria.fromRRCode.name(), v));
    Optional.ofNullable(userSearch.getToRRCode()).ifPresent(v -> derivedFieldValueMap.put(
        UserSearchCriteria.toRRCode.name(), v));

    if(rrCodeBase10 != 0) {
      derivedFieldValueMap.put(UserSearchCriteria.rRCodeGreaterThanOrEqual.name(), rrCodeBase10);
      derivedFieldValueMap.put(UserSearchCriteria.rRCodeLessThanOrEqual.name(), rrCodeBase10);
    }
    if(userSearch.getRoleScopeType() != null && userSearch.getRoleScopeType().equalsIgnoreCase("FirmScope"))
      derivedFieldValueMap.put(UserSearchCriteria.isFirmScope.name(), true);
    if(firmIdList != null && firmIdList.size() > 0) {
      derivedFieldValueMap.put(UserSearchCriteria.firmEntityIdsIN.name(),
          firmIdList);
    }

    QueryParameterCombination query = new QueryParameterCombination();
    query.setOperation(EnumSpecificationOperation.AND);

    QueryParameters leftChild = new QueryParameters();
    leftChild.setOperation(EnumSpecificationOperation.AND);
    List<String> firmCondetionIds = Arrays.asList(
        UserSearchCriteria.userAssignmentFirm.name(),
        UserSearchCriteria.firmEntityIdsIN.name());
    // only one condition is add to the final sql query because other 2 are removed from derivedFieldValueMap
    leftChild.setParameter(firmCondetionIds);

    QueryParameterCombination rightChild = new QueryParameterCombination();
    rightChild.setOperation(EnumSpecificationOperation.OR);

    QueryParameters rightChild1 = new QueryParameters();
    rightChild1.setOperation(EnumSpecificationOperation.OR);
    rightChild1.setParameter(Arrays.asList(
        UserSearchCriteria.userConfigurationId.name(),
        UserSearchCriteria.idpSubject.name(),
        UserSearchCriteria.idpUserId.name(),
        UserSearchCriteria.username.name(),
        UserSearchCriteria.firstName.name(),
        UserSearchCriteria.lastName.name(),
        UserSearchCriteria.email.name(),
        UserSearchCriteria.ossId.name(),
        UserSearchCriteria.ossProxyId.name(),
        UserSearchCriteria.ossUserId.name(),
        UserSearchCriteria.ossGroupId.name(),
        UserSearchCriteria.statusCode.name()
    ));

    QueryParameterCombination rightChild2 = new QueryParameterCombination();
    rightChild2.setOperation(EnumSpecificationOperation.OR);

    QueryParameters usergroup = new QueryParameters();
    usergroup.setOperation(EnumSpecificationOperation.AND);
    usergroup.setParameter(Arrays.asList(UserSearchCriteria.userAssignmentGroup.name(),
        UserSearchCriteria.userGroup.name(),
        UserSearchCriteria.isFirmScope.name()));

    QueryParameterCombination rrCode = new QueryParameterCombination();
    rrCode.setOperation(EnumSpecificationOperation.OR);


    QueryParameterCombination rrCodeHx = new QueryParameterCombination();
    rrCodeHx.setOperation(EnumSpecificationOperation.OR);
    QueryParameters fromRR = new QueryParameters();
    fromRR.setOperation(EnumSpecificationOperation.AND);
    fromRR.setParameter(Arrays.asList(UserSearchCriteria.userAssignmentRrCode.name(),
        UserSearchCriteria.fromRRCode.name()));
    QueryParameters toRR = new QueryParameters();
    toRR.setOperation(EnumSpecificationOperation.AND);
    toRR.setParameter(Arrays.asList(UserSearchCriteria.userAssignmentRrCode.name(),
        UserSearchCriteria.toRRCode.name()));

    if(userSearch.getFromRRCode() != null)
      rrCodeHx.setSubQueryRight(fromRR);
    if(userSearch.getToRRCode() != null)
      rrCodeHx.setSubQueryLeft(toRR);

    QueryParameterCombination rrCodeB10 = new QueryParameterCombination();
    rrCodeB10.setOperation(EnumSpecificationOperation.AND);
    QueryParameters fromRRB10 = new QueryParameters();
    fromRRB10.setOperation(EnumSpecificationOperation.AND);
    fromRRB10.setParameter(Arrays.asList(UserSearchCriteria.userAssignmentRrCode.name(),
        UserSearchCriteria.rRCodeGreaterThanOrEqual.name()));
    QueryParameters toRRB10 = new QueryParameters();
    toRRB10.setOperation(EnumSpecificationOperation.AND);
    toRRB10.setParameter(Arrays.asList(UserSearchCriteria.userAssignmentRrCode.name(),
        UserSearchCriteria.rRCodeLessThanOrEqual.name()));

    rrCode.setSubQueryLeft(rrCodeHx);
    if(rrCodeBase10 != 0)
      rrCode.setSubQueryRight(rrCodeB10);

    rightChild2.setSubQueryLeft(rrCode);
    if(userSearch.getUserGroup() != null)
      rightChild2.setSubQueryRight(usergroup);

    rightChild.setSubQueryRight(rightChild1);
    rightChild.setSubQueryLeft(rightChild2);

    if(firmIdList != null && firmIdList.size() > 0)
      query.setSubQueryLeft(leftChild);

    query.setSubQueryRight(rightChild);

    SpecificationWithQueryAndFilter<IamUserConfiguration,
        UserSearch,
        GenericUserSearchCriteria>
        spec =
        new SpecificationWithQueryAndFilter<>(
            null, GenericUserSearchCriteria.class, derivedFieldValueMap, query, null, true);

    return spec;
  }

  private PageRequest getPageRequest(GenericSearch userSearch, boolean isPrimaryFirmSearch) {
    List<String> field = CollectionUtils.isEmpty(userSearch.getSortBy()) ? List.of("firstName")
        : userSearch.getSortBy();
    String direction = userSearch.getSortOrder() != null ? userSearch.getSortOrder().name() : null;

    return isPrimaryFirmSearch ? RepositoryUtils.getPageRequest(userSearch.getPageNumber(), userSearch.getPageSize(),
        field, direction, false) : RepositoryUtils.getPageRequest(1, userSearch.getPageSize(),
        field, direction, false);
  }

  private List<GroupByResponse> groupBy(
      List<ca.bnc.wealth.common.userconfiguration.model.UserConfiguration> users,
      GenericSearch.GroupByEnum groupBy) {
    final List<GroupByResponse> response = new ArrayList<>();
    final Map<String, List<ca.bnc.wealth.common.userconfiguration.model.UserConfiguration>> groupMaps = new HashMap<>();

    users.forEach(
        user -> groupMaps.computeIfAbsent(this.getGroupBy(user, groupBy), k -> new ArrayList<>())
            .add(user));
    groupMaps.forEach((k, v) -> response.add(new GroupByResponse().groupKey(k).groupData(v)));
    return response;
  }

  private String getGroupBy(
      ca.bnc.wealth.common.userconfiguration.model.UserConfiguration userConfiguration,
      GenericSearch.GroupByEnum groupBy) {
    if (groupBy == null) {
      return userConfiguration.getFirmId();
    }

    switch (groupBy) {
      case FIRM_ID:
        return userConfiguration.getFirmId();
      case PREFERRED_LANGUAGE:
        return userConfiguration.getPreferredLanguage();
      case ROLE_SCOPE_TYPE:
        return userConfiguration.getRoleScopeType() != null
            ? userConfiguration.getRoleScopeType().getValue() : null;
      case ACTIVE:
        return userConfiguration.getActive();
      case USER_GROUPS:
        return userConfiguration.getUserGroup();
      default:
        return userConfiguration.getFirmId();
    }
  }

  public boolean isNumber(String input) {
    try {
      Integer.parseInt(input);
    } catch (NumberFormatException e) {
      return false;
    }
    return true;
  }

  private List<Filter> getFilter(List<GenericSearchFilter> lst) {
    return Optional.ofNullable(lst).stream()
        .flatMap(Collection::stream)
        .map(this::toDto)
        .toList();
  }

  private Filter toDto(GenericSearchFilter genericSearchFilter) {
    Filter filter = new Filter();
    filter.setFieldName(genericSearchFilter.getFieldName());
    filter.setCriteria(EnumQueryCriteria.valueOf(genericSearchFilter.getFilterCondition().name()));
    filter.setFieldValue(filter.getCriteria() == EnumQueryCriteria.IN ? getList(
        genericSearchFilter.getFieldValue()) : genericSearchFilter.getFieldValue());
    return filter;
  }

  @SneakyThrows
  private static List<Object> getList(String listString) {
    ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().build();
    return objectMapper.readValue(listString, List.class);
  }

  public void updateFirm(List<String> idpSubjects, List<UserConfiguration> lst) {
    //  batch approach
    /*Map<String, List<Firm>> userAssignments =  Flux.fromStream(idpSubjects.stream())
        .buffer(50)
        .toStream()
        .map(ids -> {
          Map<String, List<Firm>> map =  userAssignmentService.getUserAssignmentType(ids, UserAssignmentType.F);
          return map;
        })
        .flatMap(map -> map.entrySet().stream())
        .collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue()));*/
   Map<String, List<Firm>> userAssignments = userAssignmentService.getUserAssignmentType(idpSubjects, UserAssignmentType.F);
    lst.stream()
        .filter(uc -> userAssignments.containsKey(uc.getIdpSubject()) && userAssignments.get(uc.getIdpSubject()).size() == 1)
        .forEach(uc -> uc.setFirmId(userAssignments.get(uc.getIdpSubject()).get(0).getFirmId()));
  }

  public void updateUserGroup(List<String> idpSubjects, List<UserConfiguration> lst) {
    //  batch approach
    /*Map<String, List<UserGroup>> userAssignments =  Flux.fromStream(idpSubjects.stream())
        .buffer(50)
        .toStream()
        .map(ids -> {
          Map<String, List<UserGroup>> map =  userAssignmentService.getUserAssignmentType(ids, UserAssignmentType.G);
          return map;
        })
        .flatMap(map -> map.entrySet().stream())
        .collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue()));*/
    Map<String, List<UserGroup>> userAssignments = userAssignmentService.getUserAssignmentType(idpSubjects, UserAssignmentType.G);
    lst.stream()
        .filter(uc -> userAssignments.containsKey(uc.getIdpSubject()) && userAssignments.get(uc.getIdpSubject()).size() == 1)
        .forEach(uc -> {
          uc.setUserGroup(userAssignments.get(uc.getIdpSubject()).get(0).getName());
          uc.setUserGroupDescription(userAssignments.get(uc.getIdpSubject()).get(0).getDescription());
        });
  }

  public void updateRrCode(List<String> idpSubjects, List<UserConfiguration> lst) {
    //  batch approach
    /*Map<String, List<IamRrCodeRange>> userAssignments =  Flux.fromStream(idpSubjects.stream())
        .buffer(50)
        .toStream()
        .map(ids -> {
          Map<String, List<IamRrCodeRange>> map =  userAssignmentService.getUserAssignmentType(ids, UserAssignmentType.R);
          return map;
        })
        .flatMap(map -> map.entrySet().stream())
        .collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue()));*/
    Map<String, List<IamRrCodeRange>> userAssignments = userAssignmentService.getUserAssignmentType(idpSubjects, UserAssignmentType.R);
    lst.stream()
        .filter(uc -> userAssignments.containsKey(uc.getIdpSubject()) && userAssignments.get(uc.getIdpSubject()) != null)
        .forEach(uc -> {
          uc.setRrCodeRanges(new ArrayList<>());
          userAssignments.get(uc.getIdpSubject()).forEach(rr ->
              uc.getRrCodeRanges().add(RRCodeRange.builder()
                  .fromRRCode(rr.getFromRrCode())
                  .fromRRCodeB10((int)rr.getFromRrCodeB10())
                  .toRRCode(rr.getToRrCode())
                  .toRRCodeB10((int)rr.getToRrCodeB10())
                  .build()));
        });
  }

}
