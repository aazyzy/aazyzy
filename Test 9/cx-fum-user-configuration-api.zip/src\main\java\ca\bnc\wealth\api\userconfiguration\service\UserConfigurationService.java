package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.authorization.enums.IdTokenEnum;
import ca.bnc.wealth.api.authorization.security.TokenDecoder;
import ca.bnc.wealth.api.authorization.security.impl.TokenDecoderImpl;
import ca.bnc.wealth.api.authorization.security.token.TokenValidatorConfigLoader;
import ca.bnc.wealth.api.authorization.security.token.TokenValidatorProperty;
import ca.bnc.wealth.api.authorization.security.util.JwtUtil;
import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.userconfiguration.dao.UserConfigurationDao;
import ca.bnc.wealth.api.userconfiguration.kafka.UserConfigEventProducerService;
import ca.bnc.wealth.api.userconfiguration.model.FeaturePackageCreateResponse;
import ca.bnc.wealth.api.userconfiguration.model.UserConfigurationConstants;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.UserConfigUtils;
import ca.bnc.wealth.common.authorization.model.FeaturePackageDetails;
import ca.bnc.wealth.common.authorization.model.GetFeaturePackage;
import ca.bnc.wealth.common.ciam.model.OktaAccessProfile;
import ca.bnc.wealth.common.ciam.model.OktaCredentials;
import ca.bnc.wealth.common.ciam.model.OktaCredentialsWithHashedPassword;
import ca.bnc.wealth.common.ciam.model.OktaHash;
import ca.bnc.wealth.common.ciam.model.OktaHashedPassword;
import ca.bnc.wealth.common.ciam.model.OktaUserRequest;
import ca.bnc.wealth.common.ciam.model.OktaUserWithHashedPasswordRequest;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.jpa.entity.enums.AuditEventType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.kafka.model.EventMessages;
import ca.bnc.wealth.common.kafka.model.Header;
import ca.bnc.wealth.common.kafka.model.Source;
import ca.bnc.wealth.common.kafka.model.Tags;
import ca.bnc.wealth.common.kafka.model.user.UserConfigEventPayLoad;
import ca.bnc.wealth.common.userconfiguration.model.*;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static ca.bnc.wealth.api.userconfiguration.util.Constants.CXP_IDENTITY_SOURCE;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserConfigurationService {
  public static final List<String> SSO_ACCOUNTS = List.of("indall", "sunlif");
  private final UserConfigurationDao userConfigurationDao;
  private final CiamService ciamService;
  private final UserConfigurationServiceJpa userConfigurationServiceJpa;
  private final UserConfigEventProducerService userConfigEventProducerService;
  private final UserConfigValidationService userConfigValidationService;
  private final FirmRepository firmRepository;
  private final SystemTokenFactory systemTokenFactory;
  private final AuthorizationClient authorizationClient;
  private final UserService userService;
  private final UserStateService userStateService;
  private final UserValidationService userValidationService;
  private final RedisCacheOperationService redisCacheOperationService;
  private final UserConfigurationDataSyncService userConfigurationDataSyncService;
  private final UserAssignmentService userAssignmentService;
  private final TokenValidatorConfigLoader tokenConfig;
  private final UserConfigSearchMaterializedRefreshService userConfigSearchMaterializedRefreshService;
  private final AuditLogService auditLogService;
  private final JwtUtil jwtUtil;
  private static final String SOURCE_PROFILE_NOT_FOUND = "Source user profile not found : ";

  @Value("${platform.env:#{null}}")
  protected String env;

  public void auditUpdateUserConfiguration(Integer userConfigurationId, UserConfiguration newUserConfiguration, String idp, String updateRequestedBy) {
    auditLogService.publishAuditLog(userConfigurationId, true, AuditEventType.UPDATE, () ->{
      this.updateUserConfiguration(userConfigurationId, newUserConfiguration, idp, updateRequestedBy);
      return newUserConfiguration;
    });

  }

  public void updateUserConfiguration(Integer userConfigurationId, UserConfiguration newUserConfiguration, String idp, String updateRequestedBy) {
    if (StringUtils.isNotEmpty(idp) && SSO_ACCOUNTS.contains(idp)) {
      updateUserConfigAccessForExternalSSOUsers(
          updateRequestedBy,
          userConfigurationId,
          newUserConfiguration);
    } else {
      updateUserConfigurationByUserId(
          updateRequestedBy,
          userConfigurationId,
          newUserConfiguration);
    }
    redisCacheOperationService.deleteUserConfigurationCacheNoException(newUserConfiguration);
  }

  // Quite a lot of code duplication here to isolate the flow for SSO users, it has become clear
  // that there are multiple separate independent flows.
  // Current implementation does not recoginize user identity and access as multiple separate
  // pieces.
  // This extends from user config service->user service -> user mapper.
  // This must be done to minimize impact to existing create/update scenarios
  public void updateUserConfigIdentityForExternalSSOUsers(
      String idpSubject, Integer userConfigurationId, UserConfiguration newUserConfiguration) {
    log.info("updateUserConfigIdentityForExternalSSOUsers # Start: idpUserId: {}", idpSubject);
    newUserConfiguration.setUserConfigurationId(userConfigurationId);

    UserConfiguration currentUserConfiguration =
        userService.getUserConfigurationByIdOrName(String.valueOf(userConfigurationId));
    if (currentUserConfiguration == null) {
      return;
    }

    userConfigValidationService.validateIdp(newUserConfiguration);

    if (StringUtils.isNotBlank(newUserConfiguration.getIdp())
        && !newUserConfiguration.getIdp().equalsIgnoreCase(Constants.CPX_IDP)) {
      userConfigValidationService.validateUserUpdateForNonNbin(newUserConfiguration);
      userService.updateUserIdentityForExternalSSOUsers(
          newUserConfiguration, userConfigurationId, idpSubject);
      redisCacheOperationService.deleteUserConfigurationCache(newUserConfiguration);
      //commenting out as it deletes r2ID from the user profile
      //publishUserUpdateMessage(userConfigurationId, newUserConfiguration);
      //Suspending the source okta profile on successful update.
      userService.suspendOktaProfileByIdpSubject(currentUserConfiguration.getSourceIdpSubject());
      return;
    }
    /*get the current firm id. Current code Not allow to change the firm id in update userconfig*/
    newUserConfiguration.setFirmId(currentUserConfiguration.getFirmId());
    /* get the current user group*/

    UserConfiguration savedUserConfiguration =
        userService.getUserConfigurationByIdOrName(String.valueOf(userConfigurationId));
    userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(() -> {
      redisCacheOperationService.deleteUserConfigurationCache(savedUserConfiguration);
      updateUserConfigCache(savedUserConfiguration);
    },false);

  }

  // Same issue as above method.
  public void updateUserConfigAccessForExternalSSOUsers(
      String idpSubject, Integer userConfigurationId, UserConfiguration newUserConfiguration) {
    log.info("updateUserConfigAccessForExternalSSOUsers # Start: idpUserId: {}", idpSubject);
    newUserConfiguration.setUserConfigurationId(userConfigurationId);

    UserConfiguration currentUserConfiguration =
        userService.getUserConfigurationByIdOrName(String.valueOf(userConfigurationId));
    if (currentUserConfiguration == null) {
      return;
    }

    // Assign and validate activationDate for user updates
    if (newUserConfiguration.getActivationDate() == null
        && currentUserConfiguration.getActivationDate() != null) {
      newUserConfiguration.setActivationDate(currentUserConfiguration.getActivationDate());
    }
    userConfigValidationService.validateAndSetActivationDate(newUserConfiguration);

    /* get the current user group*/
    if (userService.requestHasFeaturePackage(newUserConfiguration)) {
      if(newUserConfiguration.getFeaturePackage().getPackageTemplateId() != null) {
        String ug =
            userService.getUserGroupNameFromPackageTemplate(
                newUserConfiguration.getFeaturePackage().getPackageTemplateId().longValue());
        newUserConfiguration.setUserGroup(ug);
      } else if(newUserConfiguration.getFeaturePackage().getPackageName() != null) {
        String ug =
            userService.getUserGroupNameFromPackageTemplate(
                newUserConfiguration.getFeaturePackage().getPackageName());
        newUserConfiguration.setUserGroup(ug);
      }
    }

    userValidationService.validateUserConfigurationUpdate(
        currentUserConfiguration, newUserConfiguration);
    userConfigValidationService.checkForUpdatingIdpUserId(currentUserConfiguration, newUserConfiguration);

    FeaturePackageCreateResponse featurePackageCreateResponse = null;
    if (userService.requestHasFeaturePackage(newUserConfiguration)) {
      String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);
      featurePackageCreateResponse =
          authorizationClient.createFeaturePackage(token, newUserConfiguration.getFeaturePackage());
      newUserConfiguration.setAccessProfileSet(true);
    }

    userService.updateUserAccessForExternalSSOUsers(
        userConfigurationId, idpSubject, newUserConfiguration, featurePackageCreateResponse);
    UserConfiguration savedUserConfiguration =
        userService.getUserConfigurationByIdOrName(String.valueOf(userConfigurationId));
    userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(() ->{
      redisCacheOperationService.deleteUserConfigurationCache(savedUserConfiguration);
      updateUserConfigCache(savedUserConfiguration);
    },false);

    publishUserUpdateMessage(userConfigurationId, newUserConfiguration);

  }

  public void updateUserConfigurationByUserId(
      String idpSubject, Integer userConfigurationId, UserConfiguration newUserConfiguration) {
    log.info("updateUserConfigurationByUserId # Start: idpUserId: {}", idpSubject);
    newUserConfiguration.setUserConfigurationId(userConfigurationId);

    UserConfiguration currentUserConfiguration =
        userService.getUserConfigurationByIdOrName(String.valueOf(userConfigurationId));
    if (currentUserConfiguration == null) {
      return;
    }

    // Assign and validate activationDate for user updates
    if (newUserConfiguration.getActivationDate() == null
        && currentUserConfiguration.getActivationDate() != null) {
      newUserConfiguration.setActivationDate(currentUserConfiguration.getActivationDate());
    }
    userConfigValidationService.validateAndSetActivationDate(newUserConfiguration);

    // seems like this is only for idp = NBC now, will have to confirm and update
    if (StringUtils.isNotBlank(currentUserConfiguration.getIdp())
        && !currentUserConfiguration.getIdp().equalsIgnoreCase("nbin")) {
      // The validator identifies employee (non-Okta) users by idp. idp does not change on update,
      // so always use the authoritative idp from the current configuration and ignore whatever the
      // request body carries. This accepts employee users (whose idpUserId is legitimately blank)
      // while preventing an external user from bypassing the idpUserId check by spoofing the
      // employee idp in the request body.
      newUserConfiguration.setIdp(currentUserConfiguration.getIdp());
      userConfigValidationService.validateUserUpdateForNonNbin(newUserConfiguration);

      // Employee/non-NBIN users have no Okta profile, but their features and resources (feature
      // package) are still managed by the authorization service. Create the feature package and
      // hand it to the update so it is (re)assigned in the same transaction as the identity update.
      // createFeaturePackage targets the authorization service (not Okta), so it is safe for users
      // whose idpUserId is legitimately blank.
      FeaturePackageCreateResponse featurePackageCreateResponse = null;
      if (userService.requestHasFeaturePackage(newUserConfiguration)) {
        String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);
        featurePackageCreateResponse =
            authorizationClient.createFeaturePackage(token, newUserConfiguration.getFeaturePackage());
        newUserConfiguration.setAccessProfileSet(true);
      }

      userService.updateUserForNonNbin(
          newUserConfiguration, userConfigurationId, idpSubject, featurePackageCreateResponse);
      publishUserUpdateMessage(userConfigurationId, newUserConfiguration);
      return;
    }
    /*get the current firm id. Current code Not allow to change the firm id in update userconfig*/
    newUserConfiguration.setFirmId(currentUserConfiguration.getFirmId());
    /* get the current user group*/
    if (userService.requestHasFeaturePackage(newUserConfiguration)) {
      if(newUserConfiguration.getFeaturePackage().getPackageTemplateId() != null) {
        String ug =
            userService.getUserGroupNameFromPackageTemplate(
                newUserConfiguration.getFeaturePackage().getPackageTemplateId().longValue());
        newUserConfiguration.setUserGroup(ug);
      } else if(newUserConfiguration.getFeaturePackage().getPackageName() != null) {
        String ug =
            userService.getUserGroupNameFromPackageTemplate(
                newUserConfiguration.getFeaturePackage().getPackageName());
        newUserConfiguration.setUserGroup(ug);
      }
    }

    userValidationService.validateUserConfigurationUpdate(
        currentUserConfiguration, newUserConfiguration);
    userConfigValidationService.checkForUpdatingIdpUserId(currentUserConfiguration, newUserConfiguration);

    FeaturePackageCreateResponse featurePackageCreateResponse = null;
    if (userService.requestHasFeaturePackage(newUserConfiguration)) {
      String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);
      featurePackageCreateResponse =
          authorizationClient.createFeaturePackage(token, newUserConfiguration.getFeaturePackage());
      newUserConfiguration.setAccessProfileSet(true);
    }

    userService.updateUserConfigurationByUserId(
        userConfigurationId, idpSubject, newUserConfiguration, featurePackageCreateResponse);
    UserConfiguration savedUserConfiguration =
        userService.getUserConfigurationByIdOrName(String.valueOf(userConfigurationId));
    userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(() -> {
      redisCacheOperationService.deleteUserConfigurationCache(savedUserConfiguration);
      updateUserConfigCache(savedUserConfiguration);

      userConfigurationDataSyncService.asyncOktaUserProfile(
          savedUserConfiguration.getIdpUserId(), newUserConfiguration);
    }, false);

    
    publishUserUpdateMessage(userConfigurationId, newUserConfiguration);

  }

  private void updateUserConfigCache(UserConfiguration userConfiguration) {
    try {
      userService.getUserConfiguration(userConfiguration.getIdpSubject());
      userService.getUserConfigurationWithRrCodeById(userConfiguration.getUserConfigurationId());
    } catch (Exception exception) {
      log.error("Error updating the cache: {}", exception.getMessage());
    }
  }

  public UserConfiguration createUserConfig(
      UserConfiguration userConfiguration, String idpSubject) {
    createUserConfigInDatabase(userConfiguration, idpSubject);
    completeUserCreationWithOkta(userConfiguration);
    return userConfiguration;
  }

  /**
   * Phase 1 of user creation: validates input and persists the user record with
   * firm / feature-package assignments. Does NOT create the OKTA profile.
   * This method is called inside the CREATE audit wrapper so the audit event is
   * submitted before the OKTA call (which may trigger an UPDATE callback).
   */
  public UserConfiguration createUserConfigInDatabase(
      UserConfiguration userConfiguration, String idpSubject) {
    Map<String, String> validationError = null;
    try {
      validationError =
          userConfigValidationService.validateUserConfigurationCreation(userConfiguration, false);
    } catch (Exception e) {
      log.error("Validation exception: {}", e.getMessage());
      throw new FumServiceException(Constants.ERROR_CODE_CREATE_USER_VALIDATION, Constants.ERROR_DEFAULTMESSAGE_CREATE_USER_VALIDATION);
    }
    if (!validationError.isEmpty()) {
      String errorCode =
          validationError.entrySet().stream().findFirst().map(Map.Entry::getValue).orElse("");
      throw new FumServiceException(errorCode, Constants.ERROR_DEFAULTMESSAGE_CREATE_USER_VALIDATION);
    }
    log.info("Validation is done!");

    createUserInDatabase(userConfiguration, idpSubject);
    return userConfiguration;
  }

  /**
   * Phase 2 of user creation: creates the OKTA profile, assigns groups,
   * updates state, and publishes the Kafka creation event.
   * Called AFTER the CREATE audit event has been submitted.
   */
  public void completeUserCreationWithOkta(UserConfiguration userConfiguration) {
    setupUserOktaProfile(userConfiguration);
    userService.publishUserCreationMessage(userConfiguration);
  }

  public void publishUserUpdateMessage(
      Integer userConfigurationId, UserConfiguration userConfiguration) {
    Header header = new Header();
    header.setId(UUID.randomUUID().toString());
    header.setRefId(userConfiguration.getIdpSubject());
    header.setAction(UserConfigurationConstants.UPDATE_USERCONFIG_API);
    header.setState(UserConfigurationConstants.KAFKA_HEADER_STATE);
    header.setReason(UserConfigurationConstants.KAFKA_HEADER_REASON_UPDATE);
    header.setVersion(UserConfigurationConstants.KAFKA_HEADER_VERSION);

    Tags tags = new Tags();
    tags.setChangeSet(UserConfigurationConstants.KAFKA_HEADER_TAGS_CHANGESET_DATAACCESS);
    tags.setCompassR2Id(StringUtils.isBlank(userConfiguration.getCompassR2Id()) ? "" : userConfiguration.getCompassR2Id());
    header.setTags(tags);

    Source source = UserConfigUtils.getSource();

    UserConfigEventPayLoad payload = new UserConfigEventPayLoad();
    payload.setId(userConfiguration.getIdpSubject());
    payload.setType(UserConfigurationConstants.KAFKA_PAYLOAD_EVENT_TYPE);
    payload.setActivationDate(
        userConfiguration.getActivationDate() != null
            ? java.sql.Timestamp.valueOf(userConfiguration.getActivationDate())
            : null);
    EventMessages<UserConfigEventPayLoad> eventMessages = new EventMessages<>();
    eventMessages.setHeader(header);
    eventMessages.setSource(source);
    eventMessages.setPayload(payload);
    userConfigEventProducerService.publishMessage(eventMessages);
  }

  /**
   * Links a Compass R2 id to the given user by publishing a user-config update event carrying
   * the id. The downstream CX-R2 user-config adaptor consumes the event and links the R2
   * cross-reference. This method performs no direct R2 access.
   *
   * @param userConfigurationId the id of the user to link
   * @param compassR2Id the Compass R2 id to link (must not be blank)
   * @throws FumValidationException if {@code compassR2Id} is blank (a blank value would be
   *     interpreted downstream as an unlink; use {@link #unlinkCompassR2Id(String)} instead)
   */
  public void linkCompassR2Id(String userConfigurationId, String compassR2Id) {
    if (StringUtils.isBlank(compassR2Id)) {
      throw new FumValidationException(
          Constants.ERROR_R2_ID_REQUIRED_CODE, Constants.ERROR_R2_ID_REQUIRED_MESSAGE);
    }
    publishCompassR2IdChange(userConfigurationId, compassR2Id);
  }

  /**
   * Unlinks the Compass R2 id from the given user by publishing a user-config update event with
   * a blank Compass R2 id. The downstream CX-R2 user-config adaptor consumes the event and
   * removes the R2 cross-reference. This method performs no direct R2 access.
   *
   * @param userConfigurationId the id of the user to unlink
   */
  public void unlinkCompassR2Id(String userConfigurationId) {
    publishCompassR2IdChange(userConfigurationId, null);
  }

  private void publishCompassR2IdChange(String userConfigurationId, String compassR2Id) {
    UserConfiguration userConfiguration =
        userService.getUserConfigurationByIdOrName(userConfigurationId);
    if (userConfiguration == null) {
      throw new FumNotFoundException(
          Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userConfigurationId));
    }
    userConfiguration.setCompassR2Id(compassR2Id);
    publishUserUpdateMessage(userConfiguration.getUserConfigurationId(), userConfiguration);
    // getCompassR2Id caches with unless="#result == null", so a later null can never overwrite a
    // cached id: without this eviction an unlinked user keeps reporting its old r2 id indefinitely.
    // NoException variant: the change is already published, so a Redis blip must not fail the call.
    redisCacheOperationService.deleteUserConfigurationCacheNoException(userConfiguration);
  }

  /**
   * Phase 1: Creates the user record in the database and assigns firm / feature package.
   * On failure, the partially-created user is deleted and a {@link FumServiceException} is thrown.
   */
  IamUserConfiguration createUserInDatabase(UserConfiguration userConfiguration, String requestedBy) {
    IamUserConfiguration iamUserConfiguration = null;
    try {
      /* Set the OssProxyId to OssId if ProxyId is null */
      if (UserConfigUtils.isEmpty(userConfiguration.getOssProxyId())
          && !UserConfigUtils.isEmpty(userConfiguration.getOssId())) {
        userConfiguration.setOssProxyId(userConfiguration.getOssId());
      }
      /* Create the user in USER_CONFIGURATION */
      iamUserConfiguration = userService.saveNewUserConfiguration(userConfiguration, requestedBy);

      Integer userConfigurationId = iamUserConfiguration.getUserConfigurationId().intValue();
      String idpSubject = iamUserConfiguration.getIdpSubject();

      userConfiguration.setUserConfigurationId(userConfigurationId);
      userConfiguration.setIdpSubject(idpSubject);

      /* Assign User Firm */
      Optional.ofNullable(userConfiguration.getFirmId())
          .flatMap(this::findFirm)
          .ifPresent(
              firm ->
                  userAssignmentService.assignFirmToUser(
                      userConfigurationId, idpSubject, firm.getId().intValue(), requestedBy));

      /* Assign Feature Package */
      Optional.ofNullable(userConfiguration.getFeaturePackage())
          .ifPresentOrElse(
              featurePackage -> {
                Optional.ofNullable(
                        authorizationClient.createFeaturePackage(
                            systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM),
                            featurePackage))
                    .ifPresentOrElse(
                        featurePackageCreateResponse -> {
                          userAssignmentService.assignFeaturePackageToUser(
                              userConfigurationId,
                              idpSubject,
                              featurePackageCreateResponse.getFeaturePackageId().intValue(),
                              requestedBy);
                          setAccessProfileSet(userConfigurationId, true);
                          addRrCode(userConfiguration, idpSubject, requestedBy);
                        },
                        () -> {
                          throw new FumServiceException(Constants.ERROR_CODE_CREATE_USER, Constants.ERROR_FEATURE_PACKAGE_CREATE_FAILED);
                        });
              },
              () -> {
                throw new FumServiceException(Constants.ERROR_CODE_CREATE_USER, Constants.ERROR_FEATURE_PACKAGE_NULL);
              });
    } catch (Exception e) {
      log.info("Error creating user configuration profile: {}", e.getMessage());
      Optional.ofNullable(iamUserConfiguration)
          .ifPresent(userConfigurationServiceJpa::deleteUserConfiguration);
      if (!(e instanceof FumServiceException)) {
        throw new FumServiceException(Constants.ERROR_PROFILE_CREATION, "Error creating user configuration profile");
      }
      throw e;
    }
    return iamUserConfiguration;
  }

  /**
   * Phase 2: Creates the OKTA profile, assigns user groups and secure-zone ID,
   * and updates the user state to PROVISIONED / PENDING_USER_ACTION.
   * Looks up the {@link IamUserConfiguration} entity by {@code userConfigurationId}
   * from the current {@code UserConfiguration} DTO.
   * On failure, the user record is deleted and a {@link FumServiceException} is thrown.
   */
  void setupUserOktaProfile(UserConfiguration userConfiguration) {
    IamUserConfiguration iamUserConfiguration = userConfigurationServiceJpa
        .getIamUserConfiguration(userConfiguration.getUserConfigurationId());

    /* CREATE OKTA PROFILE */
    try {
      /* Now setup the Okta profile */
      log.info("Creating user profile in Okta");
      if (userConfiguration.getIdp() != null
          && userConfiguration.getExternalClientId() != null) {
        Optional.ofNullable(userConfiguration.getFirmId())
            .flatMap(this::findFirm)
            .filter(
                firm ->
                    firm.getIdentitySource() != null
                        && !firm.getIdentitySource()
                            .equalsIgnoreCase(CXP_IDENTITY_SOURCE))
            .ifPresent(
                f -> {
                  log.info("Started creating okta profile for sso");
                  if(!UserConfigUtils.isEmpty(userConfiguration.getHashedPassword())) {
                    ciamService.createActiveOktaUserWithHashedPassword(
                        createOktaProfileWithHashedPasswordFromUserConf(userConfiguration));
                  } else {
                    ciamService.createActiveOktaUser(
                        createOktaProfileFromUserConf(userConfiguration));
                  }
                });

      } else if (!UserConfigUtils.isEmpty(userConfiguration.getHashedPassword())) {
        ciamService.createOktaUserWithHashedPassword(
            createOktaProfileWithHashedPasswordFromUserConf(userConfiguration));
      } else {
        ciamService.createOktaUser(createOktaProfileFromUserConf(userConfiguration));
      }
      String idpUserId = userService.getUserIdpUserIdentifierWithRefresh(iamUserConfiguration);
      userConfiguration.setIdpUserId(idpUserId);

      log.info("Assigning user groups {} in Okta", userConfiguration.getUserGroup());
      List<UserAssignmentUserGroup> userAssignmentUserGroups =
          userAssignmentService.getUserAssignment(
              userConfiguration.getIdpSubject(), UserAssignmentType.G);
      ciamService.updateOktaUserGroups(
          idpUserId, userAssignmentUserGroups.get(0).getUserGroup().getName());

      // Assign no mfa group to users if applicable
      userService.assignSsoNoMfaUserGroup(userConfiguration);
      userService.assignEmployeeExternalUserGroup(idpUserId, iamUserConfiguration);
      userService.updateUserSecureZoneIds(userConfiguration, iamUserConfiguration);
    } catch (Exception e) {
      log.info("Error creating Okta profile: {}", e.getMessage());
      userConfigurationServiceJpa.deleteUserConfiguration(iamUserConfiguration);
      if (!(e instanceof FumServiceException)) {
        throw new FumServiceException(Constants.ERROR_OKTA_PROFILE_CREATION, "Error creating Okta profile");
      }
      throw e;
    }
    userStateService.saveStateOnboardingPendingUser(iamUserConfiguration);
    userConfiguration.setActive("true");
  }

  public void setAccessProfileSet(Integer userConfigurationId, boolean accessProfileSet) {
    UserConfiguration existingUserConf = userService.getUserConfigurationFromTableByUserId(userConfigurationId);
    existingUserConf.setAccessProfileSet(accessProfileSet);
    log.info(
        "Setting access profile set status for {} to {}",
        existingUserConf.getIdpSubject(),
        accessProfileSet);
    userService.updateAccessProfileSetStatus(
        existingUserConf.getUserConfigurationId(), accessProfileSet);
  }

  private Optional<Firm> findFirm(String firmId) {
    return Optional.of(firmRepository.findByFirmId(firmId));
  }

  public OktaUserRequest createOktaProfileFromUserConf(UserConfiguration userConfiguration) {
    OktaUserRequest oktaUserProfile = new OktaUserRequest();
    OktaAccessProfile oktaAccessProfile = getOktaAccessProfile(userConfiguration);
    OktaCredentials oktaCredentials = new OktaCredentials();
    oktaCredentials.setPassword(userConfiguration.getPassword());
    oktaUserProfile.setAccessProfile(oktaAccessProfile);
    oktaUserProfile.setCredentials(oktaCredentials);
    return oktaUserProfile;
  }

  private OktaUserWithHashedPasswordRequest createOktaProfileWithHashedPasswordFromUserConf(
      UserConfiguration userConfiguration) {
    OktaUserWithHashedPasswordRequest oktaUserWithHashedPasswordRequest =
        new OktaUserWithHashedPasswordRequest();
    OktaAccessProfile oktaAccessProfile = getOktaAccessProfile(userConfiguration);
    OktaCredentialsWithHashedPassword oktaCredentials = new OktaCredentialsWithHashedPassword();

    Matcher matcher =
        Pattern.compile(Constants.BCRYPT_HASH_REGEX).matcher(userConfiguration.getHashedPassword());
    matcher.matches();

    OktaHash oktaHash = new OktaHash();
    oktaHash.setAlgorithm(Constants.HASH_ALGORITHM);
    oktaHash.setWorkFactor(Integer.valueOf(matcher.group(2)));
    oktaHash.setSalt(matcher.group(3));
    oktaHash.setValue(matcher.group(4));
    oktaHash.setSaltOrder(Constants.HASH_SALT_ORDER);

    OktaHashedPassword oktaHashedPassword = new OktaHashedPassword();
    oktaHashedPassword.setHash(oktaHash);

    oktaCredentials.setPassword(oktaHashedPassword);

    oktaUserWithHashedPasswordRequest.setAccessProfile(oktaAccessProfile);
    oktaUserWithHashedPasswordRequest.setCredentials(oktaCredentials);
    return oktaUserWithHashedPasswordRequest;
  }

  private OktaAccessProfile getOktaAccessProfile(UserConfiguration userConfiguration) {
    OktaAccessProfile oktaAccessProfile = new OktaAccessProfile();
    oktaAccessProfile.setUsername(userConfiguration.getUsername());
    oktaAccessProfile.setEmail(userConfiguration.getEmail());
    oktaAccessProfile.setBngfIdentitySource(UserConfigurationConstants.BNGF_IDENTITY_SOURCE);
    oktaAccessProfile.setBngfReferenceId(userConfiguration.getIdpSubject());
    return oktaAccessProfile;
  }

  public void updateUserRRRanges(
      Integer userConfigurationId,
      String updatingUserIdpSubject,
      UserConfiguration userConfiguration) {

    if (userConfiguration.getRrCodeRanges() != null
        && !userConfiguration.getRrCodeRanges().isEmpty()) {
      userConfiguration
          .getRrCodeRanges()
          .forEach(
              rrCodeRange ->
                  userConfigurationDao.updateUserRRRange(
                      rrCodeRange, userConfigurationId, updatingUserIdpSubject));
    }
  }


  @Transactional(rollbackFor = Exception.class)
  public void updateUserRrCodeRangesBySubjectId(String idpSubject, List<RRCodeRange> rrCodeRanges) {
    UserConfiguration userConfiguration = userService.getUserConfiguration(idpSubject);
    userConfiguration.setRrCodeRanges(rrCodeRanges);

    Integer userConfigurationId = userConfiguration.getUserConfigurationId();

    userConfigurationDao.deleteUserRRCodesByUserConfigurationId(userConfigurationId);
    updateUserRRRanges(userConfigurationId, idpSubject, userConfiguration);
    userConfigurationDao.updateUserLastUpdateDate(userConfigurationId, idpSubject);

    publishUserUpdateMessage(userConfigurationId, userConfiguration);
  }

  public void addRrCode(
      UserConfiguration userConfiguration, String idpSubject, String requestedBy) {
    userService.validateRestrictClientDataAccess(idpSubject, userConfiguration);
    boolean hasFirmLevelAccess =
        userAssignmentService.hasUserAssignment(
            idpSubject, Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S);
    if (hasFirmLevelAccess) {
      userAssignmentService.assignRrRangesSp(
          userConfiguration.getUserConfigurationId(),
          userConfiguration.getIdpSubject(),
          userService.getRRCodeListByFirmId(userConfiguration.getFirmId(), true),
          requestedBy);
    } else {
      Optional.ofNullable(userConfiguration.getRrCodeRanges())
          .ifPresent(
              rrCodeRanges ->
                  userAssignmentService.assignRrRangesSp(
                      userConfiguration.getUserConfigurationId(),
                      userConfiguration.getIdpSubject(),
                      rrCodeRanges,
                      requestedBy));
      Optional.ofNullable(userConfiguration.getRrCodes())
          .ifPresent(
              rrCodes -> {
                List<RRCodeRange> rrCodeRanges =
                    rrCodes.stream()
                        .map(rr -> RRCodeRange.builder().fromRRCode(rr).toRRCode(rr).build())
                        .toList();
                userAssignmentService.assignRrRangesSp(
                    userConfiguration.getUserConfigurationId(),
                    userConfiguration.getIdpSubject(),
                    rrCodeRanges,
                    requestedBy);
              });
    }
  }

  public String getExternalClientId(String bngfReferenceId, String bngfIdentitySource) {
    return bngfReferenceId.replace(bngfIdentitySource + Constants.IDP_SUBJECT_SEPARATOR, "");
  }

  public void mapIdTokenClaimsToUserConfiguration(
      Map<String, Object> idTokenClaims, UserConfiguration userConfiguration) {
    userConfiguration.setIdpUserId((String) idTokenClaims.get(IdTokenEnum.SUB.tokenValue));
    userConfiguration.setIdp((String) idTokenClaims.get(IdTokenEnum.BNGFIDENTITYSOURCE.tokenValue));
    userConfiguration.setIdpSubject(
        (String) idTokenClaims.get(IdTokenEnum.BNGFREFERENCEID.tokenValue));
    userConfiguration.setBngfReferenceId(
        (String) idTokenClaims.get(IdTokenEnum.BNGFREFERENCEID.tokenValue));
    userConfiguration.setExternalClientId(
        getExternalClientId(
            (String) idTokenClaims.get(IdTokenEnum.BNGFREFERENCEID.tokenValue),
            (String) idTokenClaims.get(IdTokenEnum.BNGFIDENTITYSOURCE.tokenValue)));
    userConfiguration.setUsername((String) idTokenClaims.get(IdTokenEnum.LOGIN.tokenValue));
    userConfiguration.setFirstName((String) idTokenClaims.get(IdTokenEnum.FIRSTNAME.tokenValue));
    userConfiguration.setLastName((String) idTokenClaims.get(IdTokenEnum.LASTNAME.tokenValue));
    userConfiguration.setEmail((String) idTokenClaims.get(IdTokenEnum.EMAIL.tokenValue));
    userConfiguration.setPreferredLanguage(
        ((String) idTokenClaims.get(IdTokenEnum.PREFERREDLANGUAGE.tokenValue)).toUpperCase());
    if (idTokenClaims.get(IdTokenEnum.UPDATEAT.tokenValue) != null) {
      Instant updateAtInstant =
              Instant.ofEpochSecond(
                      Long.parseLong(idTokenClaims.get(IdTokenEnum.UPDATEAT.tokenValue).toString()));
      userConfiguration.setIdentityLastUpdatedDate(
              LocalDateTime.ofInstant(updateAtInstant, ZoneId.systemDefault()));
    }
    Firm firm =
        firmRepository.findByIdentitySource(
            (String) idTokenClaims.get(IdTokenEnum.BNGFIDENTITYSOURCE.tokenValue));
    if (firm == null) {
      log.error("CRITICAL: Firm not found for identity source: "
                      + idTokenClaims.get(IdTokenEnum.BNGFIDENTITYSOURCE.tokenValue));
      throw new IllegalArgumentException(
          "Firm not found for identity source: "
              + idTokenClaims.get(IdTokenEnum.BNGFIDENTITYSOURCE.tokenValue));
    }
    userConfiguration.setFirmId(firm.getFirmId());
    userConfigValidationService.validateAndSetActivationDate(userConfiguration);
  }

  public Map<String, Object> validateAndFetchIdTokenClaims(UserIdentity userIdentity) {
    // Read the Id Token's issuer claim up front. A failure here means the Id Token itself is
    // unreadable/malformed, so collapse it into the generic decode-failure message rather than
    // exposing low-level parsing details.
    String idTokenIssuer;
    try {
      idTokenIssuer = jwtUtil.getIssuer(userIdentity.getIdToken());
    } catch (Exception exception) {
      log.error("Unable to read the Id Token issuer: {}", exception.getMessage());
      throw new IllegalArgumentException("Unable to decode the Id Token");
    }

    // Select the token validator dynamically based on the Id Token's issuer claim so that an
    // Id Token from any configured authorization server (okta, employee, system, ...) is decoded
    // against its matching JWKS endpoint, instead of assuming the "okta" issuer. A readable issuer
    // with no configured validator surfaces its own specific reason (not the generic message).
    TokenValidatorProperty tokenValidatorProperty =
        tokenConfig.getTokenValidators().values().stream()
            .filter(
                validator ->
                    validator.getIssuer() != null
                        && validator.getIssuer().equals(idTokenIssuer))
            .findFirst()
            .orElseThrow(
                () ->
                    new IllegalArgumentException(
                        String.format(
                            "No token validator configured for the Id Token issuer: %s",
                            idTokenIssuer)));

    // Extracting claims from ID token
    Map<String, Object> idTokenClaims;
    try {
      TokenDecoder tokenDecoder =
          new TokenDecoderImpl(
              tokenValidatorProperty.getKeyUrl(),
              tokenConfig.getJwksCacheLifeSpanSeconds(),
              tokenConfig.getJwksRefreshTimeSeconds(),
              jwtUtil.getJwksRetryPolicy(),
              tokenValidatorProperty.getDefaultKey(),
              tokenConfig.getJwksConnectTimeoutSeconds(),
              tokenConfig.getJwksReadTimeoutSeconds());
      idTokenClaims = tokenDecoder.getDecoder().decode(userIdentity.getIdToken()).getClaims();
    } catch (JwtException jwtException) {
      // This will handle Malformed Payload, Expired Jwt, Malformed Jwk set
      log.error("An error occurred while attempting to decode the Id Token: {}", jwtException.getMessage());
      throw new IllegalArgumentException(jwtException.getMessage());
    } catch (Exception exception) {
      // Handling with generic exception here to catch all exceptions
      log.error("Unable to decode the Id Token with error: {}", exception.getMessage());
      throw new IllegalArgumentException("Unable to decode the Id Token");
    }
    return idTokenClaims;
  }

  /** Clones an existing profile to a new user. */
  public void cloneProfile(UserConfiguration user) {
    log.info("Cloning user configuration for user: {}", user.getSourceIdpSubject());
    String sourceIdpSubject = user.getSourceIdpSubject();
    UserConfiguration sourceUserConfiguration = null;
    try {
      sourceUserConfiguration =
          userService.getUserConfigurationWithRrCodeById(
              userService
                  .getUserConfigurationByIdOrName(sourceIdpSubject)
                  .getUserConfigurationId());
    } catch (NullPointerException e) {
      log.error(SOURCE_PROFILE_NOT_FOUND + sourceIdpSubject);
      throw new IllegalArgumentException(SOURCE_PROFILE_NOT_FOUND + sourceIdpSubject);
    } catch (Exception e) {
      log.error("Error sourcing original profile {}: {}", sourceIdpSubject, e.getMessage());
      throw new IllegalArgumentException(SOURCE_PROFILE_NOT_FOUND + sourceIdpSubject);
    }
    // Copy existing user configuration to the new user
    UserConfigUtils.cloneProperties(sourceUserConfiguration, user, Constants.SKIP_CLONE_FIELDS);

    // Assign a temporary password
    user.setPassword(UserConfigUtils.getTempPassword(user.getFirstName(), user.getLastName()));

    if (user.getExternalClientId() != null) {
      Optional.ofNullable(firmRepository.findByFirmId(user.getFirmId()))
          .ifPresent(
              firm -> {
                if (firm.getIdentitySource() == null
                    || CXP_IDENTITY_SOURCE.equalsIgnoreCase(firm.getIdentitySource())) {
                  log.error(
                      "CRITICAL: The {} is not enabled for SSO account linking.", user.getFirmId());
                  throw new IllegalArgumentException(
                      "The firm is not enabled for SSO account linking. External client id should not be sent in the request");
                }
              });
    }

    // Assign the source user's R2 id if it is not already set
    if (user.getCompassR2Id() == null) {
      log.info("Getting compass R2 ID from source user profile {}", sourceIdpSubject);
      user.setCompassR2Id(userService.getCompassR2Id(sourceUserConfiguration.getIdpSubject()));
    }
    // Assign the source user's SZ id if it is not already set
    if (user.getSecureZoneIds() == null) {
      Optional.ofNullable(userService.getSecureZoneId(sourceUserConfiguration.getIdpUserId()))
          .ifPresent(a -> user.setSecureZoneIds(Arrays.asList(a)));
    }

    /**
     * If the source config has a feature package assigned, then the feature package will be applied
     * to the cloned user profile We first need to find the assigned feature package to the source
     * user, gets it details and then apply those to the cloned user
     */
    if (user.getFeaturePackage() == null) {
      log.info("Getting feature package assignments from source user profile {}", sourceIdpSubject);
      // Get the assigned feature package
      List<UserAssignment> sourceUserFeatureAssignments =
          userAssignmentService.getUserAssignments(
              sourceIdpSubject, List.of(Constants.ASSIGNMENT_TYPE_FEATURE_PACKAGE), true);
      if (sourceUserFeatureAssignments.isEmpty()) {
        throw new IllegalArgumentException(
            "Source user does not have any feature packages assigned. Please assign feature to the user before cloning the profile.");
      }
      // Fetch the feature package details
      String systemToken = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);
      Integer sourceUserFeaturePackageId = sourceUserFeatureAssignments.get(0).getAssigneeId();
      // Get the feature package details to apply to the cloned profile
      GetFeaturePackage sourceUserFeaturePackage =
          authorizationClient.getFeaturePackage(systemToken, sourceUserFeaturePackageId);
      if (sourceUserFeaturePackage == null) {
        throw new IllegalArgumentException(
            String.format(
                "Assigned feature package %d not found. Please check the user package assignment.",
                sourceUserFeaturePackageId));
      }
      log.info(
          "Assigning feature package {} to clone user {}",
          sourceUserFeaturePackage.getName(),
          user.getIdpSubject());

      // Generate the feature package details in the form the create user profile expects
      FeaturePackage targetUserFeaturePackage = new FeaturePackage();
      targetUserFeaturePackage.setPackageTemplateId(
          sourceUserFeaturePackage.getPackageTemplateId().intValue());
      targetUserFeaturePackage.setPackageName(sourceUserFeaturePackage.getName());
      // Assign the module overrides
      List<String> moduleOverrides =
          sourceUserFeaturePackage.getDetails().stream()
              .filter(
                  detail ->
                      detail.getResource() != null
                          && detail.getResource().getRestriction()
                          && detail.getSelected())
              .map(detail -> detail.getResource().getName())
              .collect(Collectors.toList());
      // Assign the firm level data access restriction if it is set
      for (FeaturePackageDetails dtl : sourceUserFeaturePackage.getDetails()) {
        if (dtl.getResource() != null
            && dtl.getResource().getName().equals(Constants.FIRM_LEVEL_ACCESS_RESOURCE)
            && !dtl.getSelected()) {
          log.info(
              "Assigning firm level access restriction to clone user {}", user.getIdpSubject());
          moduleOverrides.add(Constants.FIRM_LEVEL_ACCESS_RESOURCE);
        }
      }
      targetUserFeaturePackage.setModuleOverrides(moduleOverrides);
      user.setFeaturePackage(targetUserFeaturePackage);
    }
    // Assign the rr codes if they are not already set
    if (user.getRrCodeRanges() == null) {
      log.info("Assigning RR code assignments from source user profile {}", sourceIdpSubject);
      user.setRrCodeRanges(sourceUserConfiguration.getRrCodeRanges());
    }

    // Assign defaults for the user
    user.setAccessProfileSet(true);
    user.setIdentityLastUpdatedDate(
        LocalDateTime.parse(Constants.DEFAULT_IDENTIFY_LAST_UPDATED_DATE));
    user.setSourceIdpSubject(sourceIdpSubject);
    log.info("User configuration cloned successfully");
  }

  public List<UserAssignment> getUserDwhAssignmentsResources(Integer userConfigurationId) {
    Set<String> dwhResourceNames = userConfigValidationService.getDwhResourceNames();
    List<UserAssignment> resourceAssignments = userAssignmentService.getUserAssignments(
        userService.getUserIdpSubjectById(userConfigurationId),
        List.of("resource"),
        true);
    return resourceAssignments.stream()
        .filter(resource -> dwhResourceNames.contains(resource.getResourceName()))
        .collect(Collectors.toList());
  }
}
