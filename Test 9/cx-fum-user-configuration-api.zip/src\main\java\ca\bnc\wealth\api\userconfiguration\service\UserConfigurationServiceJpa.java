package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.userconfiguration.model.state.UserStateActionEnum;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.fum.service.ResourceServiceHelper;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackageAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.userconfiguration.model.UpdateUserStatus.StatusEnum;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserConfigurationServiceJpa {

  private final IamUserConfigurationRepository iamUserConfigurationRepository;

  private final FeaturePackageRepository featurePackageRepository;

  private final CiamService ciamService;

  private final FeaturePackageAssignmentResourceRepository featurePackageAssignmentResourceRepository;

  private final ResourceServiceHelper resourceServiceHelper;
  private final UserService userService;
  private final UserAssignmentService userAssignmentService;

  private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;
  private final RedisCacheOperationService redisCacheOperationService;

  private final UserStateService userStateService;

  private final PersonService personService;

  public List<String> getMatchedUserName(String userName) {
    SqlParameterSource userParameters = new MapSqlParameterSource()
        .addValue("username", userName.toLowerCase() + "%");
    List<Map<String, Object>> userMapList =
        namedParameterJdbcTemplate.queryForList(Constants.GET_USER_BY_USERNAME_QUERY, userParameters);
    return userMapList.stream().map(o -> String.valueOf(o.get("USERNAME"))).toList();
  }

  public void updateUserStatus(Integer userConfigurationId, StatusEnum userStatus) {
    IamUserConfiguration iamUserConfiguration = iamUserConfigurationRepository.findById(Long.valueOf(userConfigurationId)).orElse(null);
    if (iamUserConfiguration == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userConfigurationId));
    }

    boolean isActive = userStatus == StatusEnum.ACTIVE;

    if (iamUserConfiguration.getActive() != null && iamUserConfiguration.getActive() == isActive) {
      return;
    }

    iamUserConfiguration.setActive(isActive);
    iamUserConfigurationRepository.save(iamUserConfiguration);

    if (isActive) {
      ciamService.unsuspendUserOktaProfile(iamUserConfiguration.getIdpUserIdentifier());
    } else {
      ciamService.suspendUserOktaProfile(iamUserConfiguration.getIdpUserIdentifier());
    }
    redisCacheOperationService.deleteUserConfigurationCache(userService.toDtoWithUserGroupAndFirmId(iamUserConfiguration));
  }

  public void updateUserConfigState(Integer userConfigurationId, UserStateActionEnum userState) {
    IamUserConfiguration iamUserConfiguration = iamUserConfigurationRepository.findById(Long.valueOf(userConfigurationId)).orElse(null);
    if (iamUserConfiguration == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userConfigurationId));
    }
    switch (userState) {
      case SUSPENDED:
        userStateService.setStateSuspended(iamUserConfiguration);
        iamUserConfigurationRepository.save(iamUserConfiguration);
        redisCacheOperationService.deleteUserConfigurationCache(userService.toDtoWithUserGroupAndFirmId(iamUserConfiguration));
        break;
      case ACTIVE:
        userStateService.setStateActive(iamUserConfiguration);
        iamUserConfigurationRepository.save(iamUserConfiguration);
        redisCacheOperationService.deleteUserConfigurationCache(userService.toDtoWithUserGroupAndFirmId(iamUserConfiguration));
        break;
      default:
      throw new FumValidationException(Constants.ERROR_USER_STATE_UPDATE_NOT_IMPLEMENTED_CODE,
          String.format(Constants.ERROR_USER_STATE_UPDATE_NOT_IMPLEMENTED_MESSAGE, userState));
    }    
  }


  public Optional<FeaturePackage> findFeaturePackage(Integer assigneeId) {
    return featurePackageRepository.findById(Long.valueOf(assigneeId));
  }

  public void deleteUserConfiguration(IamUserConfiguration iamUserConfiguration) {
    personService.removePersonLink(iamUserConfiguration);
    userAssignmentService.deleteUserAssignments(iamUserConfiguration);
    iamUserConfigurationRepository.delete(iamUserConfiguration);
  }

  public IamUserConfiguration getIamUserConfiguration(Integer userConfigurationId) {
    return iamUserConfigurationRepository.findById(Long.valueOf(userConfigurationId))
        .orElseThrow(() -> new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
            String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userConfigurationId)));
  }

  public List<Resource> getResourcesByPackageTemplateId(Long packageTemplateId) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("packageTemplateAssignmentResource.assignmentType",
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, PackageAssignmentType.S.name()));
    fieldValueMap.put("featurePackage.packageTemplate.packageTemplateId",
        Pair.of(EnumQueryCriteria.EQUALS, packageTemplateId));

    Specification<FeaturePackageAssignmentResource> spec = new Specification<>(
        fieldValueMap);
    List<FeaturePackageAssignmentResource> list=featurePackageAssignmentResourceRepository.findAll(spec);
    return list.stream().map(resource ->resource.getPackageTemplateAssignmentResource().getResource()).collect(
        Collectors.toList());

  }
  public boolean isDataAccessResourceTypeSharedWithPackageTemplate(Integer packageTemplateId, String firmId) {
    boolean isShared = false;
    if (packageTemplateId == null || firmId == null) {
      return isShared;
    }

    List<Resource> userResources = getResourcesByPackageTemplateId(Long.valueOf(packageTemplateId));
    List<Resource> firmResources= resourceServiceHelper.getFirmResources(firmId, true);

    List<Resource> users=userResources.stream().filter(resource -> Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS.equalsIgnoreCase(resource.getName()) && Constants.RESOURCE_TYPE_DATA_ACCESS.equalsIgnoreCase(resource.getType())).collect(
        Collectors.toList());
    List<Resource> firms=firmResources.stream().filter(resource -> Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS.equalsIgnoreCase(resource.getName()) && Constants.RESOURCE_TYPE_DATA_ACCESS.equalsIgnoreCase(resource.getType())).collect(
        Collectors.toList());
    if (!CollectionUtils.isEmpty(users) && !CollectionUtils.isEmpty(firms)) {
      isShared=true;
    }
    return isShared;
  }

  public boolean isDataAccessResourceTypeSharedBetweenUserAndFirm(String idpSubject, String firmId) {
    List<Resource> userResources= resourceServiceHelper.getUserResources(idpSubject);

    List<Resource> firmResources= resourceServiceHelper.getFirmResources(firmId, true);
    boolean isShared=false;
    List<Resource> users=userResources.stream().filter(resource -> Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS.equalsIgnoreCase(resource.getName()) && Constants.RESOURCE_TYPE_DATA_ACCESS.equalsIgnoreCase(resource.getType())).collect(
        Collectors.toList());
    List<Resource> firms=firmResources.stream().filter(resource -> Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS.equalsIgnoreCase(resource.getName()) && Constants.RESOURCE_TYPE_DATA_ACCESS.equalsIgnoreCase(resource.getType())).collect(
        Collectors.toList());
    if (!CollectionUtils.isEmpty(users) && !CollectionUtils.isEmpty(firms)) {
      isShared=true;
    }
    return isShared;
  }

  public void applyFirmAccessLevelCheck(UserConfiguration currentUserConfiguration,String requestBy){
    String idpSubject = currentUserConfiguration.getIdpSubject();
    String firmId = currentUserConfiguration.getFirmId();
    if (isDataAccessResourceTypeSharedBetweenUserAndFirm(idpSubject, firmId)) {
      userAssignmentService.assignRrRangesSp(
          currentUserConfiguration.getUserConfigurationId(),
          currentUserConfiguration.getIdpSubject(),
          userService.getRRCodeListByFirmId(
              firmId, true),
          requestBy);
    }
  }

  public Optional<IamUserConfiguration> getUserByEmail(String email) {
    return iamUserConfigurationRepository.findFirstByEmailIgnoreCase(email);
  }

  public Optional<IamUserConfiguration> getUserByIdpSubject(String userId) {
    return iamUserConfigurationRepository.findFirstByIdpSubject(userId);
  }
}
