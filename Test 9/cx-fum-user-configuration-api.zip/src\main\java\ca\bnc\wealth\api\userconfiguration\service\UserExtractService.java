package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.userconfiguration.model.UserData;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.extract.api.ExtractType;
import ca.bnc.wealth.common.extract.service.ExtractInterface;
import ca.bnc.wealth.common.extract.service.ExtractService;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class UserExtractService implements ExtractInterface {

  @Value("${executor.timeout}")
  private static final int TIMEOUT = 1000;

  private final UserService userService;

  private final CsvConverterService csvConverterService;

  private final R2Service r2Service;

  private final CiamService ciamService;

  private final ExtractService extractService;

  @Autowired
  public UserExtractService(UserService userService,
      CsvConverterService csvConverterService,
      R2Service r2Service,
      CiamService ciamService,
      ExtractService extractService) {
    this.userService = userService;
    this.csvConverterService = csvConverterService;
    this.r2Service = r2Service;
    this.ciamService = ciamService;
    this.extractService = extractService;
  }

  @SneakyThrows
  public static void shutdownAndAwait(ExecutorService executorService) {
    executorService.shutdown();
    try {
      executorService.awaitTermination(TIMEOUT, TimeUnit.SECONDS);
    } catch (InterruptedException e) {
      executorService.shutdownNow();
      log.error("Error in executor service: {}", e.getMessage());
      throw e;
    }
  }

  @Override
  public String getExtractType() {
    return ExtractType.USER.name();
  }

  @Override
  @Transactional
  public byte[] getExtract(long userConfigurationId) {
    UserConfiguration userConfiguration = userService.getUserConfigurationById((int)userConfigurationId);
    List<UserData> userDataList = userService.getAllUserDataAssociatedToFirmAndChildFirms(
        userConfiguration.getIdpSubject());

    ExecutorService executorServiceOkta = asyncCallToGetSecureZoneId(userDataList);
    ExecutorService executorServiceR2 = asyncCallToGetCompassR2Id(userDataList);
    ExecutorService executorServiceRrCode = asyncRrCode(userDataList);

    shutdownAndAwait(executorServiceOkta);
    shutdownAndAwait(executorServiceR2);
    shutdownAndAwait(executorServiceRrCode);
    ByteArrayResource userDataCsv = csvConverterService.convertToCsv(userDataList);

    return userDataCsv.getByteArray();
  }

  public byte[] getUserDataInCsvByteArray(String idpSubject) throws FumServiceException {
    UserConfiguration userConfiguration = userService.getUserConfiguration(idpSubject);
    byte[] userExtractDataInCsvByteArray = extractService.getExtract(
        userConfiguration.getUserConfigurationId(), ExtractType.USER);

      return userExtractDataInCsvByteArray;
  }

  private ExecutorService asyncCallToGetSecureZoneId(List<UserData> userDataList) {
    ExecutorService executorService = Executors.newFixedThreadPool(2);
    userDataList.forEach(userData -> {
      executorService.submit(() -> {
        OktaUserProfile oktaUserProfile = ciamService.getOktaUserProfile(
            userData.getIdpUserIdentifier());
        userData.setSecureZoneIds(oktaUserProfile.getAccessProfile() != null ? Arrays.asList(
            oktaUserProfile.getAccessProfile().getBngfSecureZoneId()) : null);
      });
    });
    return executorService;
  }

  private ExecutorService asyncCallToGetCompassR2Id(List<UserData> userDataList) {

    ExecutorService executorService = Executors.newFixedThreadPool(2);

    userDataList.forEach(userData -> {
      executorService.submit(() -> {
        Optional.ofNullable(r2Service.getCxUserProfile(userData.getIdpSubject()))
            .ifPresent(pair -> userData.setCompassR2Id(pair.getValue()));
      });
    });
    return executorService;
  }

  private ExecutorService asyncRrCode(List<UserData> userDataList) {

    ExecutorService executorService = Executors.newFixedThreadPool(2);

    userDataList.forEach(userData -> {
      executorService.submit(() -> {
        List<RRCodeRange> rrCodeRanges = userService.getRRCodeListByIdpSubject(
            userData.getIdpSubject(), true);
        List<String> rrCodes = new ArrayList<>();
        for (RRCodeRange rrCodeRange : rrCodeRanges) {
          rrCodes.add(rrCodeRange.getFromRRCode() + "-" + rrCodeRange.getToRRCode());
        }
        userData.setRrCodes(rrCodes);
      });
    });
    return executorService;
  }
}
