package ca.bnc.wealth.api.userconfiguration.service;

import static ca.bnc.wealth.api.userconfiguration.model.state.UserStateActionEnum.SUSPENDED;
import static ca.bnc.wealth.api.userconfiguration.util.Constants.CPX_IDP;
import static ca.bnc.wealth.api.userconfiguration.util.Constants.DWH_IDP;
import static ca.bnc.wealth.api.userconfiguration.util.Constants.ERROR_EXTERNAL_ID_NOT_SUPPORTED;
import static ca.bnc.wealth.api.userconfiguration.util.Constants.ERROR_EXTERNAL_ID_NOT_SUPPORTED_MESSAGE;
import static ca.bnc.wealth.api.userconfiguration.util.Constants.ERROR_USER_TYPE_NOT_SUPPORTED;
import static ca.bnc.wealth.api.userconfiguration.util.Constants.ERROR_USER_TYPE_NOT_SUPPORTED_MESSAGE;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.userconfiguration.jpa.UserSearchMaterializedCriteria;
import ca.bnc.wealth.api.userconfiguration.kafka.UserConfigEventProducerService;
import ca.bnc.wealth.api.userconfiguration.model.FeaturePackageCreateResponse;
import ca.bnc.wealth.api.userconfiguration.model.UserConfigurationConstants;
import ca.bnc.wealth.api.userconfiguration.model.UserData;
import ca.bnc.wealth.api.userconfiguration.model.state.UserStatusEnum;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.MapperUtils;
import ca.bnc.wealth.api.userconfiguration.util.UserConfigUtils;
import ca.bnc.wealth.common.ciam.model.OktaAccessProfile;
import ca.bnc.wealth.common.ciam.model.OktaNewPassword;
import ca.bnc.wealth.common.ciam.model.OktaUserEmail;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.exception.Entity.FumConflictException;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.service.FirmServiceHelper;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamContentTranslation;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentFeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentFirm;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.UserGroup;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentFeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserGroupRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.ShortIdUtils;
import ca.bnc.wealth.common.jpa.specification.SpecificationWithQueryAndFilter;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.kafka.model.EventMessages;
import ca.bnc.wealth.common.kafka.model.Header;
import ca.bnc.wealth.common.kafka.model.Source;
import ca.bnc.wealth.common.kafka.model.Tags;
import ca.bnc.wealth.common.kafka.model.user.UserConfigEventPayLoad;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ErrorSeverity;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ServiceException;
import ca.bnc.wealth.common.sz.model.SzUser;
import ca.bnc.wealth.common.sz.model.SzUserSearch;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearch;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearchFilter;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearchFilter.FilterConditionEnum;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearchResponse;
import ca.bnc.wealth.common.userconfiguration.model.GroupByResponse;
import ca.bnc.wealth.common.userconfiguration.model.NbxUserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.OSS;
import ca.bnc.wealth.common.userconfiguration.model.PageInfo;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.UamaUser;
import ca.bnc.wealth.common.userconfiguration.model.UamaUserSearchResponse;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserCredentials;
import ca.bnc.wealth.common.userconfiguration.model.UserExternalSystemConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserOktaProfile;
import ca.bnc.wealth.common.userconfiguration.model.UserSearch;
import ca.bnc.wealth.common.userconfiguration.model.Users;
import tools.jackson.databind.ObjectMapper;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTParser;
import jakarta.persistence.EntityManager;
import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tools.jackson.core.JacksonException;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserService {

  private static final String USER_CONFIGURATION_ID = "userConfigurationId";
  private static final String IDP_SUBJECT = "idpSubject";
  private static final String ASSIGNMENT_TYPE = "assignmentType";
  private static final String FIRM_ID = "firmId";
  private static final String COMPASS_R_2 = "compass-r2";
  private static final String SECURE_ZONE = "secure-zone";
  private static final String OSS = "oss";
  private static final String USER_ASSIGNMENT_FIRMS_TYPE = "userAssignmentFirms.assignmentType";

  @Autowired
  private IamUserConfigurationRepository iamUserConfigurationRepository;

  @Autowired
  private UserAssignmentUserGroupRepository userAssignmentUserGroupRepository;

  @Autowired
  private UserAssignmentRrCodeRangeRepository userAssignmentRrCodeRangeRepository;

  @Autowired
  private UserAssignmentFeaturePackageRepository userAssignmentFeaturePackageRepository;

  @Autowired
  private IamRrCodeRangeRepository iamRrCodeRangeRepository;

  @Autowired
  private FeaturePackageRepository featurePackageRepository;

  @Autowired
  private PackageTemplateAssignmentUserGroupRepository packageTemplateAssignmentUserGroupRepository;

  @Autowired
  private UserGroupRepository userGroupRepository;

  @Autowired
  private FirmRepository firmRepository;

  @Autowired
  private CiamService ciamService;

  @Autowired
  private R2Service r2Service;

  @Autowired
  private SzService szService;

  @Autowired
  private UserConfigurationSearchService userConfigurationSearchService;

  @Autowired
  private UserConfigSearchMaterializedRefreshService userConfigSearchMaterializedRefreshService;

  @Autowired
  private EntityManager entityManager;

  @Autowired
  private UserStateService userStateService;

  @Autowired
  UserConfigEventProducerService userConfigEventProducerService;

  @Qualifier("postgresJdbcTemplate")
  @Autowired
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @Autowired
  private RedisCacheOperationService redisCacheOperationService;

  @Autowired
  private UserAssignmentService userAssignmentService;

  @Autowired
  private FirmServiceHelper firmServiceHelper;

  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  private PersonService personService;

  @Value("${redis.cache.enable:false}")
  private boolean enableCache;
  @Value("${userConfiguration.uama.enable:false}")
  private boolean isUamaEnabled;
  @Value("${userConfiguration.idpUserStatus.schedule.duration:30}")
  private int retryCountForGetOktaUserProfile;
  @Value("${userConfiguration.employee.idp:" + Constants.EMPLOYEE_IDP + "}")
  private String employeeIdp;

  @Cacheable(value = "UserConfiguration-UsersMe", key = "#idpSubject", cacheManager = "redisCacheManager", condition = "#root.getTarget().redisCacheEnabled()")
  public UserConfiguration getUserConfiguration(String idpSubject) {
    SqlParameterSource parameters = new MapSqlParameterSource().addValue(IDP_SUBJECT, idpSubject);
    List<Map<String, Object>> userMapList = namedParameterJdbcTemplate.queryForList(Constants.GET_USER_FROM_MV_BY_IDP_SUBJECT_QUERY, parameters);

    if (!userMapList.isEmpty()) {
      return toDto(userMapList.get(0));
    }

    IamUserConfiguration iamUserConfiguration = iamUserConfigurationRepository.findFirstByIdpSubject(idpSubject)
        .orElseThrow(() -> new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
        String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, idpSubject)));

    return toDtoWithUserGroupAndFirmId(iamUserConfiguration);
  }

  // This method is not used in get from DB instead of using me USER_CONFIGURATION_MATERIALIZED
  public UserConfiguration getUserConfigurationFromTableByUserId(long userConfigurationId) {
    return this.toDtoWithUserGroupAndFirmId(iamUserConfigurationRepository.getReferenceById(userConfigurationId));
  }
  public UserConfiguration getUserConfigurationById(Integer userConfigurationId) {
    return toDto(getUserConfigurationByIdUsingJdbc(userConfigurationId));
  }

  public Map<String, Object> getUserConfigurationByIdUsingJdbc(Integer userConfigurationId) {
    SqlParameterSource userParameters = new MapSqlParameterSource()
        .addValue(USER_CONFIGURATION_ID,userConfigurationId);
    List<Map<String, Object>> userMapList =
        namedParameterJdbcTemplate.queryForList(Constants.GET_USER_FROM_MV_BY_CONF_ID_QUERY, userParameters);

    if (userMapList.isEmpty()) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userConfigurationId));
    }

    return userMapList.get(0);
  }

  @Cacheable(value = "UserConfiguration-UsersId", key = "#userConfigurationId", cacheManager = "redisCacheManager", condition = "false")
  public UserConfiguration getUserConfigurationWithRrCodeById(Integer userConfigurationId) {
    UserConfiguration uc = null;
    try{
      Map<String, Object> userMap = getUserConfigurationByIdUsingJdbc(userConfigurationId);
      validateIfOktaProfileExists(MapperUtils.toIamUserConfigurationEntity(userMap));
      uc = toDto(userMap);
    } catch (Exception e) {
      log.info("Unable to find userConfiguration in USER_CONFIGURATION_LIVE, so using USER_CONFIGURATION table");
      uc = toDtoWithUserGroupAndFirmId(iamUserConfigurationRepository.getReferenceById(userConfigurationId.longValue()));
      if(uc == null) {
        throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
            String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userConfigurationId));
      }
      log.info("Found in USER_CONFIGURATION table: " + uc.getIdpSubject());
    }
    uc.setRrCodeRanges(getRRCodeListByIdpSubject(uc.getIdpSubject(), true));
    return uc;
  }

  public UserConfiguration getUserConfigurationWithRrCodeByIdFromTable(Integer userConfigurationId) {
    UserConfiguration uc = iamUserConfigurationRepository.findById(userConfigurationId.longValue())
        .map(this::toDtoWithUserGroupAndFirmId).orElse(null);
    if(uc == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userConfigurationId));
    }
    uc.setRrCodeRanges(getRRCodeListByIdpSubject(uc.getIdpSubject(), true));

    List<UserAssignmentFeaturePackage> userAssignmentFeaturePackages =userAssignmentService.getUserAssignment(uc.getIdpSubject(), UserAssignmentType.P);
    if (userAssignmentFeaturePackages.size() == 1 && userAssignmentFeaturePackages.get(0).getFeaturePackage() != null) {
      FeaturePackage featurePackage = userAssignmentFeaturePackages.get(0).getFeaturePackage();
      if(featurePackage.getPackageTemplate() != null) {
        uc.setUserRole(featurePackage.getPackageTemplate().getName());
      }
    }
    return uc;
  }

  private void validateIfOktaProfileExists(IamUserConfiguration iamUserConfiguration) {
    try {
      if(StringUtils.isNotEmpty(iamUserConfiguration.getIdpUserIdentifier()) && "nbin".equalsIgnoreCase(iamUserConfiguration.getIdp())) {
        OktaUserProfile oktaUserProfile = ciamService.getOktaUserProfile(iamUserConfiguration.getIdpUserIdentifier());
        userStateService.updateStateFromOktaProfile(iamUserConfiguration, oktaUserProfile);
      }
    } catch (FumNotFoundException e) {
      IamUserConfiguration iamUserConfigurationJpa = iamUserConfigurationRepository.getReferenceById(iamUserConfiguration.getUserConfigurationId());
      userStateService.updateStateForDeletedOktaProfile(iamUserConfigurationJpa);
      redisCacheOperationService.deleteUserConfigurationCache(iamUserConfiguration.getIdpSubject(),
          iamUserConfiguration.getUserConfigurationId().intValue(),
          iamUserConfiguration.getIdpUserIdentifier());
    }
  }

  @Transactional
  public String getUserIdpUserIdentifierWithRefresh(IamUserConfiguration userConfiguration) {
    entityManager.refresh(userConfiguration);

    return iamUserConfigurationRepository.findById(userConfiguration.getUserConfigurationId())
        .map(IamUserConfiguration::getIdpUserIdentifier)
        .orElseThrow(() -> {
          throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
              String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userConfiguration.getUserConfigurationId()));
        });
  }

  public String getUserIdpSubjectById(Integer userConfigurationId) {
    return toDto(getUserConfigurationByIdUsingJdbc(userConfigurationId)).getIdpSubject();
  }

  public UserConfiguration getUserConfigurationByIdOrName(String userId) {
    if (UserConfigUtils.isNumber(userId)) {
      return iamUserConfigurationRepository.findById(Long.valueOf(userId))
          .map(this::toDtoWithUserGroupAndFirmId).orElse(null);
    }
    // Employee Short IDs reach us in whatever case the caller used (NWPI-14901).
    return iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(userId)
            .map(this::toDtoWithUserGroupAndFirmId).orElseGet(()->
               iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(userId)
                      .map(this::toDtoWithUserGroupAndFirmId).orElseThrow(()-> {
                        throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
                            String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userId));
                      })
            );
  }

  public UserGroup getUserGroupByGroupName(String groupName) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("name", Pair.of(EnumQueryCriteria.IGNORE_CASE_EQUALS, groupName));
    Specification<UserGroup> spec = new Specification<>(fieldValueMap);
    Optional<UserGroup> userGroup = userGroupRepository.findOne(spec);
    if (!userGroup.isPresent()) {
      throw new ServiceException(
          ErrorSeverity.ERROR, String.format("No user group found by group name %s", groupName));
    }
    return userGroup.get();
  }

  public List<RRCodeRange> getRRCodeListByIdpSubject(String idpSubject, Boolean active) {
    if (active == null) { // By default CompassX UI requires active to be true
      active = true;
    }

    SqlParameterSource rrCodeParameters = new MapSqlParameterSource()
        .addValue(ASSIGNMENT_TYPE, UserAssignmentType.R.name())
        .addValue(IDP_SUBJECT, idpSubject)

        .addValue(UserStatusEnum.ACTIVE.dbValue, Boolean.TRUE.equals(active));

    List<Map<String, Object>> rrCodeMapList =
        namedParameterJdbcTemplate.queryForList(Constants.GET_RRCODE_BY_USER_QUERY, rrCodeParameters);

    List<RRCodeRange> rrCodeRanges = rrCodeMapList.stream().map(MapperUtils::toRRCodeRangeDto).toList();
    rrCodeRanges = removeDuplicates(rrCodeRanges);
    return removeSubsetRanges(rrCodeRanges);
  }

  private List<RRCodeRange> removeDuplicates(List<RRCodeRange> rrCodeRanges) {
    Map<String, RRCodeRange> rangeMap = new HashMap<>();

    for (RRCodeRange rrCodeRange : rrCodeRanges) {
      String key = rrCodeRange.getFromRRCode() + "-" + rrCodeRange.getToRRCode();
      rangeMap.putIfAbsent(key, rrCodeRange);
    }

    return new ArrayList<>(rangeMap.values());
  }

  private List<RRCodeRange> removeSubsetRanges(List<RRCodeRange> rrCodeRanges) {
    return rrCodeRanges.stream()
        .filter(currentRrCodeRange -> rrCodeRanges.stream()
            .noneMatch(nextRrCodeRange -> nextRrCodeRange != currentRrCodeRange &&
                nextRrCodeRange.getFromRRCodeB10() <= currentRrCodeRange.getFromRRCodeB10() &&
                nextRrCodeRange.getToRRCodeB10() >= currentRrCodeRange.getToRRCodeB10()))
        .toList();
  }

  public List<RRCodeRange> getRRCodeListByFirmId(String firmId, Boolean active) {

    return MapperUtils.toDtos(getIamRRCodeListByFirmId(firmId, active));
  }

  public List<IamRrCodeRange> getIamRRCodeListByFirmId(String firmId, Boolean active) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    if (active != null) {
      fieldValueMap.put(UserStatusEnum.ACTIVE.dbValue, Pair.of(EnumQueryCriteria.EQUALS, active));
    }
    fieldValueMap.put("firmAssignmentRrCodeRanges.assignmentType",
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.R.name()));
    fieldValueMap.put("firmAssignmentRrCodeRanges.firm.firmId",
        Pair.of(EnumQueryCriteria.EQUALS, firmId));
    Specification<IamRrCodeRange> spec = new Specification<>(fieldValueMap);
    return iamRrCodeRangeRepository.findAll(spec);
  }

  public boolean validRrCodeRangeForFirmId(String firmId, List<String> rrCodes,
      List<RRCodeRange> rrCodeRanges) {
    List<RRCodeRange> temp =
        Optional.ofNullable(rrCodes)
            .map(codes -> codes.stream().map(r -> new RRCodeRange().fromRRCode(r).toRRCode(r))
                .toList())
            .orElse(new ArrayList<>());
    Optional.ofNullable(rrCodeRanges).ifPresent(temp::addAll);

    return temp.stream()
        .allMatch(rrCodeRange -> this.firmRepository.validRrCodeRangeForFirmId(firmId,
            rrCodeRange.getFromRRCode(), rrCodeRange.getToRRCode()));
  }

  public boolean isValidFirmId(String firmId) {
    if (UserConfigUtils.isEmpty(firmId)) {
      return true;
    }
    try {
      long id = Integer.parseInt(firmId);
      return firmRepository.existsById(id);
    } catch (NumberFormatException e) {
      Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
      fieldValueMap.put(FIRM_ID, Pair.of(EnumQueryCriteria.EQUALS, firmId));
      Specification<Firm> specification = new Specification<>(fieldValueMap);
      return firmRepository.exists(specification);
    }
  }

  public List<UserData> getAllUserDataAssociatedToFirmAndChildFirms(String idpSubject) {
    Optional<Firm> optional = firmServiceHelper.getPrimaryFirm(idpSubject, null);
    if (optional.isEmpty()) {
      throw new ServiceException(
          ErrorSeverity.ERROR, String.format(Constants.ERROR_USER_NO_FIRM, idpSubject));
    }

    Firm primaryFirm = optional.get();
    if (primaryFirm.getFirmId().equalsIgnoreCase("NBIN")) {
      return iamUserConfigurationRepository.findAll().stream()
          .map(this::toDtoWithUserGroupAndFirmId)
          .map(MapperUtils::toUserDataDto)
          .toList();
    } else {
      List<Long> firmIdList = firmRepository.getAllFirmsByIdpSubject(idpSubject);
      Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
      fieldValueMap.put("userAssignmentFirms.firm.firmEntityId", Pair.of(EnumQueryCriteria.IN, firmIdList));
      fieldValueMap.put(USER_ASSIGNMENT_FIRMS_TYPE, Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.F.name()));
      Specification<IamUserConfiguration> spec = new Specification<>(fieldValueMap);
      return iamUserConfigurationRepository.findAll(spec).stream()
          .map(this::toDtoWithUserGroupAndFirmId)
          .map(MapperUtils::toUserDataDto)
          .toList();
    }
  }

  public List<UserConfiguration> searchUsers(String idpSubject, UserSearch userSearch)
      throws IntrospectionException, InvocationTargetException, IllegalAccessException {
    Optional<Firm> optionalFirm = firmServiceHelper.getPrimaryFirm(idpSubject, null);
    if (optionalFirm.isEmpty()) {
      throw new ServiceException(
          ErrorSeverity.ERROR, String.format(Constants.ERROR_USER_NO_FIRM, idpSubject));
    }

    List<Long> firmIdList = new ArrayList<>();
    long userFirms = firmRepository.getAllFirmsByIdpSubject(idpSubject).size();
    long numberOfFirms = firmRepository.count();
    if (numberOfFirms != userFirms) {
      firmIdList.add(optionalFirm.get().getFirmEntityId());
      optionalFirm.get().getChildFirms()
          .forEach(firm -> firmIdList.add(firm.getFirmEntityId()));
    }

    AtomicLong rrCodeBase10 = new AtomicLong();
    if(userSearch.getRrCode() != null){
      rrCodeBase10.set(iamRrCodeRangeRepository.rrCodeDecoder(userSearch.getRrCode()));
    }


    SpecificationWithQueryAndFilter spec = userConfigurationSearchService.getSpecification(idpSubject, userSearch,
        rrCodeBase10.get(), firmIdList);

    List<IamUserConfiguration> lst = iamUserConfigurationRepository.findAll(spec);
    List<UserConfiguration> response = lst.stream()
        .map(MapperUtils::toDto)
        .toList();
    List<String> idpSubjects = response.stream().map(UserConfiguration::getIdpSubject).toList();

    userConfigurationSearchService.updateUserGroup(idpSubjects, response);
    userConfigurationSearchService.updateFirm(idpSubjects, response);
    userConfigurationSearchService.updateRrCode(idpSubjects, response);

    return response;
  }

  @SneakyThrows
  public GenericSearchResponse materializedViewSearch(String idpSubject, GenericSearch userSearch) {
    GenericSearchResponse response = new GenericSearchResponse();
    Optional<Firm> optionalFirm = firmServiceHelper.getPrimaryFirm(idpSubject, null);
    if (optionalFirm.isEmpty() && StringUtils.isBlank(userSearch.getFirmId())) {
      throw new ServiceException(
          ErrorSeverity.ERROR, String.format(Constants.ERROR_USER_NO_FIRM, idpSubject));
    }
    Firm primaryFirm = optionalFirm.orElse(null);

    addingNbxUserFilter(userSearch);

    Firm searchFirm = StringUtils.isNotBlank(userSearch.getFirmId())
        ? this.firmRepository.findByFirmId(userSearch.getFirmId()) : primaryFirm;

    Future<Pair<Integer, List<GroupByResponse>>> currentFuture = userConfigurationSearchService.searchUserView(
        idpSubject, userSearch, primaryFirm, searchFirm, true);

    if (StringUtils.isNotBlank(userSearch.getSearchText())) {
      Future<Pair<Integer, List<GroupByResponse>>> otherFuture = userConfigurationSearchService.searchUserView(
          idpSubject, userSearch, primaryFirm, searchFirm, false);
      Pair<Integer, List<GroupByResponse>> otherPair = otherFuture.get();
      response.setOtherFirmUserCount(otherPair.getLeft());
      if (userSearch.getPageSize() != null && userSearch.getPageSize() > 0) {
        response.setOtherFirmUserPages(
            response.getOtherFirmUserCount() / userSearch.getPageSize() + (
                response.getOtherFirmUserCount() % userSearch.getPageSize() == 0 ? 0 : 1));
      }
      response.setOtherFirmUsers(otherPair.getRight());
    } else {
      response.setOtherFirmUserCount(0);
      response.setOtherFirmUsers(new ArrayList<>());
    }

    Pair<Integer, List<GroupByResponse>> currentPair = currentFuture.get();
        response.setCurrentFirmUserCount(currentPair.getLeft());
    if (userSearch.getPageSize() != null && userSearch.getPageSize() > 0) {
      response.setCurrentFirmUserPages(
          response.getCurrentFirmUserCount() / userSearch.getPageSize() + (
              response.getCurrentFirmUserCount() % userSearch.getPageSize() == 0 ? 0 : 1));
    }
    response.setCurrentFirmUsers(currentPair.getRight());
    return response;
  }

  private void addingNbxUserFilter(GenericSearch userSearch) {
    GenericSearchFilter sourceFilter = new GenericSearchFilter();
    sourceFilter.setFieldName(UserSearchMaterializedCriteria.SOURCE_NOT_NBX.name());
    sourceFilter.setFilterCondition(FilterConditionEnum.IS_NULL);

    userSearch.setFilter(Objects.requireNonNullElseGet(userSearch.getFilter(), ArrayList::new));
    userSearch.getFilter().add(sourceFilter);
  }


  public GenericSearchResponse genericUserSearchWithPagination(String idpSubject,
      GenericSearch userSearch) {
    ExecutorService executorService = Executors.newFixedThreadPool(2);
    GenericSearchResponse response = new GenericSearchResponse();

    Optional<Firm> optionalFirm = firmServiceHelper.getPrimaryFirm(idpSubject, null);
    if (optionalFirm.isEmpty() && StringUtils.isBlank(userSearch.getFirmId())) {
      throw new ServiceException(
          ErrorSeverity.ERROR, String.format(Constants.ERROR_USER_NO_FIRM, idpSubject));
    }

    Firm primaryFirm = optionalFirm.orElse(null);

    Firm searchFirm = StringUtils.isNotBlank(userSearch.getFirmId())
        ? this.firmRepository.findByFirmId(userSearch.getFirmId()) : primaryFirm;

    executorService.submit(() -> {
      Pair<Integer, List<GroupByResponse>> currentPair = userConfigurationSearchService.search(
          idpSubject, userSearch, primaryFirm, searchFirm, true);

      response.setCurrentFirmUserCount(currentPair.getLeft());
      if (userSearch.getPageSize() != null && userSearch.getPageSize() > 0) {
        response.setCurrentFirmUserPages(
            response.getCurrentFirmUserCount() / userSearch.getPageSize() + (
                response.getCurrentFirmUserCount() % userSearch.getPageSize() == 0 ? 0 : 1));
      }
      response.setCurrentFirmUsers(currentPair.getRight());
    });

    executorService.submit(() -> {
      if (StringUtils.isNotBlank(userSearch.getSearchText())) {
        Pair<Integer, List<GroupByResponse>> otherPair = userConfigurationSearchService.search(
            idpSubject, userSearch, primaryFirm, searchFirm, false);
        response.setOtherFirmUserCount(otherPair.getLeft());
        if (userSearch.getPageSize() != null && userSearch.getPageSize() > 0) {
          response.setOtherFirmUserPages(
              response.getOtherFirmUserCount() / userSearch.getPageSize() + (
                  response.getOtherFirmUserCount() % userSearch.getPageSize() == 0 ? 0 : 1));
        }
        response.setOtherFirmUsers(otherPair.getRight());
      } else {
        response.setOtherFirmUserCount(0);
        response.setOtherFirmUsers(new ArrayList<>());
      }
    });
    shutdownAndAwait(executorService);

    return response;
  }

  @SneakyThrows
  public GenericSearchResponse genericNbxUserSearchWithPagination(GenericSearch userSearch) {
    Firm searchFirm = null;
    if (StringUtils.isNotBlank(userSearch.getFirmId())) {
      GenericSearchFilter firmFilter = new GenericSearchFilter();
      firmFilter.setFieldName(UserSearchMaterializedCriteria.FIRM_ID_EQUALS.name());
      firmFilter.setFilterCondition(FilterConditionEnum.IGNORE_CASE_EQUALS);
      firmFilter.setFieldValue(userSearch.getFirmId());
      userSearch.setFilter(Objects.requireNonNullElseGet(userSearch.getFilter(), ArrayList::new));
      userSearch.getFilter().add(firmFilter);
      searchFirm = firmRepository.findByFirmId(userSearch.getFirmId());
    }

    GenericSearchResponse response = new GenericSearchResponse();
    Future<Pair<Integer, List<GroupByResponse>>> otherFuture = userConfigurationSearchService.searchUserView(
        null, userSearch, null, searchFirm, false);
    Pair<Integer, List<GroupByResponse>> otherPair = otherFuture.get();
    response.setOtherFirmUserCount(otherPair.getLeft());
    if (userSearch.getPageSize() != null && userSearch.getPageSize() > 0) {
      response.setOtherFirmUserPages(
          response.getOtherFirmUserCount() / userSearch.getPageSize() + (
              response.getOtherFirmUserCount() % userSearch.getPageSize() == 0 ? 0 : 1));
    }
    response.setOtherFirmUsers(otherPair.getRight());

    return response;
  }

  @Transactional
  public UserConfiguration createUserForNonNbin(UserConfiguration userConfiguration, String requestedBy) {
    /* Set the OssProxyId to OssId if ProxyId is null */
    if (UserConfigUtils.isEmpty(userConfiguration.getOssProxyId()) && !UserConfigUtils.isEmpty(userConfiguration.getOssId())) {
      userConfiguration.setOssProxyId(userConfiguration.getOssId());
    }

    if (Constants.SSO_ACCOUNTS.contains(userConfiguration.getIdp())) {
      Firm firm = firmRepository.findByIdentitySource(userConfiguration.getIdp());
      if (firm != null && firm.getFirmId() != null) {
        userConfiguration.setFirmId(firm.getFirmId());
        userConfiguration.setFirmName(firm.getName());
        userConfiguration.setFirmType(firm.getFirmType().name());
      }
    }
    /**
     * Assign to NoMfa group if applicable
     */
    assignSsoNoMfaUserGroup(userConfiguration);

    /* Create the user in USER_CONFIGURATION */
    IamUserConfiguration iamUserConfiguration = saveNewUserConfiguration(userConfiguration, requestedBy);

    Integer userConfigurationId = iamUserConfiguration.getUserConfigurationId().intValue();
    String idpSubject = iamUserConfiguration.getIdpSubject();

    userConfiguration.setUserConfigurationId(userConfigurationId);
    userConfiguration.setIdpSubject(idpSubject);

    /* Assign User Firm */
    Optional.ofNullable(userConfiguration.getFirmId())
        .flatMap(this::findFirm).ifPresent(
            firm -> userAssignmentService.assignFirmToUser(userConfigurationId, idpSubject, firm.getId().intValue(), requestedBy)
        );

    addRrCode(userConfiguration, requestedBy);

    userStateService.setStateActive(iamUserConfiguration);
    iamUserConfigurationRepository.save(iamUserConfiguration);
    personService.syncPersonFromUserConfiguration(iamUserConfiguration);
    assignEmployeeExternalUserGroup(iamUserConfiguration.getIdpUserIdentifier(), iamUserConfiguration);
    userConfiguration.setActive("true");

    publishUserCreationMessage(userConfiguration);
    return userConfiguration;
  }

  @Transactional
  public void updateUserForNonNbin(UserConfiguration newUserConfiguration, Integer userConfigurationId, String requestedBy, FeaturePackageCreateResponse featurePackageCreateResponse) {
    IamUserConfiguration iamUserConfiguration = iamUserConfigurationRepository.findById(Long.valueOf(userConfigurationId)).orElse(null);
    if (iamUserConfiguration == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userConfigurationId));
    }
    if(!iamUserConfiguration.getIdpSubject().equalsIgnoreCase(newUserConfiguration.getIdpSubject())) {
      throw new FumValidationException(Constants.ERROR_USER_UPDATE_CODE,  Constants.ERROR_USER_UPDATE_MESSAGE);
    }
    if(!validRrCodeRangeForFirmId(newUserConfiguration.getFirmId(), newUserConfiguration.getRrCodes(), newUserConfiguration.getRrCodeRanges())) {
      log.error("Some of provided user rrcode are not in firm rrcode range");
      throw new FumNotFoundException(Constants.RR_CODES, Constants.ERROR_RRCODE_INVALID);
    }

    MapperUtils.updateEntity(iamUserConfiguration, newUserConfiguration);
    iamUserConfiguration.setLastUpdatedBy(requestedBy);
    iamUserConfiguration.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
    iamUserConfiguration.setProfileLastUpdated(new Timestamp(System.currentTimeMillis()));
    iamUserConfiguration = iamUserConfigurationRepository.save(iamUserConfiguration);
    personService.syncPersonFromUserConfiguration(iamUserConfiguration);
    assignEmployeeExternalUserGroup(iamUserConfiguration.getIdpUserIdentifier(), iamUserConfiguration);
    deleteUserRRCodesByIdpSubject(iamUserConfiguration.getIdpSubject());
    addRrCode(newUserConfiguration, requestedBy);

    // Employee/non-NBIN users have no Okta profile, but their feature package (features and
    // resources) is managed by the authorization service, not Okta, so it must still be
    // (re)assigned on update. Without this the user's selected features/resources were silently
    // dropped on every update.
    if (featurePackageCreateResponse != null) {
      deleteFeaturePackage(iamUserConfiguration);
      userAssignmentService.assignFeaturePackageToUser(
          iamUserConfiguration.getUserConfigurationId(),
          iamUserConfiguration.getIdpSubject(),
          featurePackageCreateResponse.getFeaturePackageId().intValue(),
          requestedBy);
    }
  }

  @Transactional
  public void updateUserIdentityForExternalSSOUsers(UserConfiguration newUserConfiguration, Integer userConfigurationId, String requestedBy) {
    IamUserConfiguration iamUserConfiguration = iamUserConfigurationRepository.findById(Long.valueOf(userConfigurationId)).orElse(null);
    if (iamUserConfiguration == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
              String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userConfigurationId));
    }
    if(!iamUserConfiguration.getIdpSubject().equalsIgnoreCase(newUserConfiguration.getIdpSubject())) {
      throw new FumValidationException(Constants.ERROR_USER_UPDATE_CODE,  Constants.ERROR_USER_UPDATE_MESSAGE);
    }
    MapperUtils.updateEntityForIdentity(iamUserConfiguration, newUserConfiguration);
    userStateService.setStateActive(iamUserConfiguration);
    iamUserConfiguration.setLastUpdatedBy(requestedBy);
    iamUserConfiguration.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
    iamUserConfiguration.setProfileLastUpdated(new Timestamp(System.currentTimeMillis()));
    iamUserConfigurationRepository.save(iamUserConfiguration);
    personService.syncPersonFromUserConfiguration(iamUserConfiguration);
    assignEmployeeExternalUserGroup(iamUserConfiguration.getIdpUserIdentifier(), iamUserConfiguration);
  }


  @Transactional(rollbackFor = Exception.class)
  public UserConfiguration updateUserAccessForExternalSSOUsers(Integer userConfigurationId, String idpSubject, UserConfiguration userConfiguration, FeaturePackageCreateResponse featurePackageCreateResponse) {
    // Get the user's current configuration to determine the idpSubject
    IamUserConfiguration iamUserConfiguration = iamUserConfigurationRepository.findById(Long.valueOf(userConfigurationId)).orElse(null);
    if (iamUserConfiguration == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
              String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userConfigurationId));
    }
    /** 2. update user configuration */
    MapperUtils.updateEntityForAccessOnly(iamUserConfiguration, userConfiguration);// this needs to only allow Identity Updates
    iamUserConfiguration.setLastUpdatedBy(idpSubject);
    iamUserConfiguration.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
    iamUserConfiguration.setProfileLastUpdated(new Timestamp(System.currentTimeMillis()));
    iamUserConfiguration = iamUserConfigurationRepository.save(iamUserConfiguration);
    personService.syncPersonFromUserConfiguration(iamUserConfiguration);

    /**
     * 3. if the provided user group names is not blank,remove all the existing user group
     * assignments and apply new assignments
     */
    assignUserGroups(idpSubject, userConfiguration, iamUserConfiguration);
    assignEmployeeExternalUserGroup(iamUserConfiguration.getIdpUserIdentifier(), iamUserConfiguration);

    userStateService.setStateActive(iamUserConfiguration);

    updateUserSecureZoneIds(userConfiguration, iamUserConfiguration);
    if (featurePackageCreateResponse != null) {
      deleteFeaturePackage(iamUserConfiguration);
      userAssignmentService.assignFeaturePackageToUser(iamUserConfiguration.getUserConfigurationId(), iamUserConfiguration.getIdpSubject(), featurePackageCreateResponse.getFeaturePackageId().intValue(), idpSubject);
    }
    // Handle RR codes and RR Range updates
    this.updateRRCode(iamUserConfiguration, userConfiguration, featurePackageCreateResponse, idpSubject);
    return toDtoWithUserGroupAndFirmId(iamUserConfiguration);
  }

  @Transactional(rollbackFor = Exception.class)
  public UserConfiguration updateUserConfigurationByUserId(Integer userConfigurationId, String idpSubject, UserConfiguration userConfiguration, FeaturePackageCreateResponse featurePackageCreateResponse) {
    // Get the user's current configuration to determine the idpSubject
    IamUserConfiguration iamUserConfiguration = iamUserConfigurationRepository.findById(Long.valueOf(userConfigurationId)).orElse(null);
    if (iamUserConfiguration == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userConfigurationId));
    }

    boolean isEmailChanged = !UserConfigUtils.isEmpty(userConfiguration.getEmail()) &&
            !userConfiguration.getEmail().equals(iamUserConfiguration.getEmail());

    /** 2. update user configuration */
    MapperUtils.updateEntity(iamUserConfiguration, userConfiguration);
    iamUserConfiguration.setLastUpdatedBy(idpSubject);
    iamUserConfiguration.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
    iamUserConfiguration.setProfileLastUpdated(new Timestamp(System.currentTimeMillis()));
    iamUserConfiguration = iamUserConfigurationRepository.save(iamUserConfiguration);
    personService.syncPersonFromUserConfiguration(iamUserConfiguration);

    /**
     * 3. if the provided user group names is not blank,remove all the existing user group
     * assignments and apply new assignments
     */
    assignUserGroups(idpSubject, userConfiguration, iamUserConfiguration);
    assignEmployeeExternalUserGroup(iamUserConfiguration.getIdpUserIdentifier(), iamUserConfiguration);

    // Update the okta status
    idpStatusUpdateSchedule(userConfigurationId);

    updateUserSecureZoneIds(userConfiguration, iamUserConfiguration);

    // Update user email in Okta if email has changed
    if(isEmailChanged) {
      updateEmailConfigurationInOkta(iamUserConfiguration);
    }

    if (featurePackageCreateResponse != null) {
      deleteFeaturePackage(iamUserConfiguration);
      userAssignmentService.assignFeaturePackageToUser(iamUserConfiguration.getUserConfigurationId(), iamUserConfiguration.getIdpSubject(), featurePackageCreateResponse.getFeaturePackageId().intValue(), idpSubject);
    }

    // Handle RR codes and RR Range updates
    this.updateRRCode(iamUserConfiguration, userConfiguration, featurePackageCreateResponse, idpSubject);

    return toDtoWithUserGroupAndFirmId(iamUserConfiguration);
  }



  private void assignUserGroups(String idpSubject, UserConfiguration userConfiguration, IamUserConfiguration iamUserConfiguration) {
    if (userConfiguration.getUserGroup() != null) {
      log.info(
          "Assigning user groups {} to {}",
          userConfiguration.getUserGroup(),
          iamUserConfiguration.getIdpSubject());
      ciamService.updateOktaUserGroups(iamUserConfiguration.getIdpUserIdentifier(), userConfiguration.getUserGroup());
      assignSsoNoMfaUserGroup(userConfiguration);
      assignEmployeeExternalUserGroup(iamUserConfiguration.getIdpUserIdentifier(), iamUserConfiguration);
      deleteUserGroupsByIdpSubject(iamUserConfiguration.getIdpSubject());
      assignUserGroups(iamUserConfiguration, userConfiguration.getUserGroup(), idpSubject);
    }
  }

  /**
   * Assigns EMPLOYEE_EXTERNAL_USER_GROUP in Okta when the account is secondary to an employee
   * (IAMi) account, i.e. another user configuration holds the same email with idp = IAMi.
   *
   * <p>Must be called after {@code updateOktaUserGroups}, which deletes every Wealth.CompassX.*
   * group the profile holds when the requested group is not already present.
   */
  public void assignEmployeeExternalUserGroup(String idpUserId, IamUserConfiguration user) {
    try {
      if (personService.isSecondaryAccount(user)) {
        ciamService.assignOktaUserGroup(idpUserId, Constants.EMPLOYEE_EXTERNAL_USER_GROUP);
      }
    } catch (Exception e) {
      log.error("Error in assigning {} to user: {}", Constants.EMPLOYEE_EXTERNAL_USER_GROUP, e.getMessage());
    }
  }

  /**
   * Assign SSO_NOMFA_USER_GROUP to user if user is from external IDP and has externalClientId in the request
   */
  public void assignSsoNoMfaUserGroup(UserConfiguration user) {
    try{
      Firm firm = firmRepository.findByFirmId(user.getFirmId());
      if (StringUtils.isNotBlank(user.getExternalClientId())  && !Constants.CXP_IDENTITY_SOURCE.equalsIgnoreCase(firm.getIdentitySource()) ) {
        ciamService.assignOktaUserGroup(user.getIdpUserId(), Constants.SSO_NOMFA_USER_GROUP);
      }
    }catch(Exception e){
      log.error("Error in assigning {} to user: {}", Constants.SSO_NOMFA_USER_GROUP, e.getMessage());
    }
  }

  private void updateEmailConfigurationInOkta(IamUserConfiguration iamUserConfiguration) {
    String email = iamUserConfiguration.getEmail();
    boolean isEmailNeedsUpdatingInOkta = !UserConfigUtils.isEmpty(email);

    if (isEmailNeedsUpdatingInOkta) {
      try{
        OktaUserEmail oktaUserEmail = new OktaUserEmail();
        oktaUserEmail.setNewEmail(email);
        ciamService.updateOktaUserEmail(iamUserConfiguration.getIdpUserIdentifier(), oktaUserEmail);
        log.info("Updating email on Okta successful for {}.", iamUserConfiguration.getIdpSubject());
      } catch(ServiceException e) {
        log.error("Error in updating email on Okta: {}", e.getMessage());
      }
    }
  }

  public void updateRRCode(IamUserConfiguration iamUserConfiguration, UserConfiguration userConfiguration, FeaturePackageCreateResponse featurePackageCreateResponse, String idpSubject) {
    boolean hasFirmLevelAccess = userAssignmentService.hasUserAssignment(userConfiguration.getIdpSubject(), Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S);
    validateRestrictClientDataAccess(userConfiguration.getIdpSubject(), userConfiguration);

    if(featurePackageCreateResponse != null && hasFirmLevelAccess) {
      List<RRCodeRange> rrCodeRanges = getRRCodeListByFirmId(userConfiguration.getFirmId(), true);
      userConfiguration.setRrCodeRanges(rrCodeRanges);
      userConfiguration.setRrCodes(null);
      // Delete the existing RR Codes
      deleteUserRRCodesByIdpSubject(iamUserConfiguration.getIdpSubject());
      addRRCodeRangeToUser(iamUserConfiguration, userConfiguration, idpSubject);
    } else if(userConfiguration.getRrCodes() != null || userConfiguration.getRrCodeRanges() != null) {
      // Delete the existing RR Codes
      deleteUserRRCodesByIdpSubject(iamUserConfiguration.getIdpSubject());
      addRRCodeRangeToUser(iamUserConfiguration, userConfiguration, idpSubject);
    }
  }

  public Users getUserConfigurationsByFirmId(
      String idpUserSubject, String firmId, PageInfo page) {
    Firm firmConfiguration = getFirm(idpUserSubject, firmId);

    Page<IamUserConfiguration> jpaResponse = this.userAssignmentService.getUserConfigByAssignment(UserAssignmentType.F, firmConfiguration.getFirmId(), page);

    Users response = new Users();
    response.setTotalCount((int) jpaResponse.getTotalElements());
    List<UserConfiguration> lst = jpaResponse.stream()
        .map(MapperUtils::toDto)
        .toList();
    response.users(lst);

    return response;
  }

  Firm getFirm(String idpUserSubject, String firmId) {
    try {
      SqlParameterSource userAssignmentParameters = new MapSqlParameterSource()
          .addValue(IDP_SUBJECT, idpUserSubject)
          .addValue(ASSIGNMENT_TYPE, UserAssignmentType.F.name());
      Map<String, Object> firmMap = namedParameterJdbcTemplate.queryForMap(
          Constants.GET_FIRM_BY_USER_QUERY, userAssignmentParameters);
      Firm firm = MapperUtils.toEntity(firmMap);

      if ("NBIN".equalsIgnoreCase(firm.getFirmId()) && !"NBIN".equalsIgnoreCase(firmId)) {
        SqlParameterSource firmParameters = new MapSqlParameterSource()
            .addValue(FIRM_ID, firmId);
        return MapperUtils.toEntity(namedParameterJdbcTemplate.queryForMap(
            Constants.GET_FIRM_BY_ID_QUERY, firmParameters));
      }
      return firm;
    } catch (EmptyResultDataAccessException ex) {
      throw new FumNotFoundException(Constants.ERROR_FIRM_NOT_FOUND_CODE,
          String.format(Constants.ERROR_FIRM_NOT_FOUND_MESSAGE, firmId));
    }
  }

  public UserExternalSystemConfiguration getUserExternalSystemConfiguration(String idpSubject,
      String externalSystemId) {
    UserExternalSystemConfiguration response =  new UserExternalSystemConfiguration();
    switch (externalSystemId) {
      case COMPASS_R_2 ->
        Optional.ofNullable(r2Service.getCxUserProfile(idpSubject))
            .ifPresent(pair -> response.setCompassR2Id(pair.getValue()));
      case SECURE_ZONE -> {
        UserConfiguration userConfiguration = getUserConfiguration(idpSubject);
        getSecureZoneIdOptional(userConfiguration.getIdpUserId())
            .ifPresent(secureZoneIds -> response.setSecureZoneId(Arrays.asList(secureZoneIds)));
      }
      case OSS -> {
        UserConfiguration userConfiguration = getUserConfiguration(idpSubject);
        response.setOss(getOss(userConfiguration));
      }
    }
    return response;
  }

  private OSS getOss(UserConfiguration userConfiguration) {
    OSS oss = new OSS();
    oss.setOssId(userConfiguration.getOssId());
    oss.setOssUserId(userConfiguration.getOssUserId());
    oss.setOssProxyId(userConfiguration.getOssProxyId());
    oss.ossGroupId(userConfiguration.getOssGroupId());
    return oss;
  }

  public UserExternalSystemConfiguration getUserExternalSystemConfiguration(Integer userConfigurationId,
      String externalSystemId) {
    return getUserExternalSystemConfiguration(getUserIdpSubjectById(userConfigurationId), externalSystemId);
  }

  public void updateExternalUserIds(String idpSubject, String externalSystemId, List<String> externalIds) {
    IamUserConfiguration iamUserConfiguration = iamUserConfigurationRepository.findByIdpSubject(idpSubject);
    if (iamUserConfiguration == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, idpSubject));
    }

    String userType = getUserType(iamUserConfiguration.getIdp());
    if (SECURE_ZONE.equalsIgnoreCase(externalSystemId)) {
      for (String szId : externalIds) {
        szService.assignExternalIdToUsername(szId, iamUserConfiguration.getIdpSubject(), userType);
      }
    } else {
      throw new FumValidationException(ERROR_EXTERNAL_ID_NOT_SUPPORTED,
          String.format(ERROR_EXTERNAL_ID_NOT_SUPPORTED_MESSAGE, externalSystemId));
    }
  }

  public UamaUser getUserConfigurationByExternalUserId(String externalSystemId, String externalUserId) {
    if (SECURE_ZONE.equalsIgnoreCase(externalSystemId)) {
      return MapperUtils.toDto(szService.getExternalUser(externalUserId));
    } else {
      throw new FumValidationException(ERROR_EXTERNAL_ID_NOT_SUPPORTED,
          String.format(ERROR_EXTERNAL_ID_NOT_SUPPORTED_MESSAGE, externalSystemId));
    }
  }

  public UamaUserSearchResponse getUserConfigurationByIdpSubjectAndExternalSystemId(String idpSubject, String externalSystemId) {
    IamUserConfiguration iamUserConfiguration = iamUserConfigurationRepository.findByIdpSubject(idpSubject);
    if (iamUserConfiguration == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, idpSubject));
    }

    if (SECURE_ZONE.equalsIgnoreCase(externalSystemId)) {
      return MapperUtils.toDto(szService.getExternalUserByIdpSubject(idpSubject));
    } else {
      throw new FumValidationException(ERROR_EXTERNAL_ID_NOT_SUPPORTED,
          String.format(ERROR_EXTERNAL_ID_NOT_SUPPORTED_MESSAGE, externalSystemId));
    }
  }

  String getUserType(String idp) {
    if (CPX_IDP.equalsIgnoreCase(idp)) {
      return CPX_IDP.toUpperCase();
    }

    if (DWH_IDP.equalsIgnoreCase(idp)) {
      return DWH_IDP.toUpperCase();
    }

    if (isEmployeeIdp(idp)) {
      return employeeIdp.toUpperCase();
    }

    throw new FumValidationException(ERROR_USER_TYPE_NOT_SUPPORTED,
        String.format(ERROR_USER_TYPE_NOT_SUPPORTED_MESSAGE, idp));
  }

  public String getUserLastUpdatedDateByIdpSubject(String idpSubject) {
    SqlParameterSource userParameters = new MapSqlParameterSource().addValue(IDP_SUBJECT, idpSubject);
    List<Map<String, Object>> userLastUpdateList =
        namedParameterJdbcTemplate.queryForList(Constants.GET_USER_LAST_UPDATE_DATE_BY_IDP_SUBJECT_QUERY, userParameters);

    if (userLastUpdateList.isEmpty()) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, idpSubject));
    }

    return Optional.ofNullable(userLastUpdateList.get(0).get("LAST_UPDATE_DATE"))
        .map(date -> Timestamp.valueOf(String.valueOf(date)).toLocalDateTime().toString())
        .orElse(null);
  }

  public UserConfiguration updateUserLanguage(String idpSubject, PreferredLanguageType preferredLanguageType) {
    IamUserConfiguration user = iamUserConfigurationRepository.findByIdpSubject(idpSubject);
    user.setPreferredLanguageType(preferredLanguageType);
    user.setLastUpdatedBy(idpSubject);
    user.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
    IamUserConfiguration iamUserConfiguration = iamUserConfigurationRepository.save(user);
    personService.syncPersonFromUserConfiguration(iamUserConfiguration);
    redisCacheOperationService.deleteUserConfigurationCacheEnrichUserMeUsersId(idpSubject, user.getUserConfigurationId().intValue());
    return toDtoWithUserGroup(iamUserConfiguration);
  }

  public Map<String, String> getRecoveryQuestions(String acceptLanguage, String idpSubject) {
    UserConfiguration userConfiguration = this.getUserConfiguration(idpSubject);
    throwExceptionForNonNbin(userConfiguration);

    if(StringUtils.isEmpty(acceptLanguage) || !acceptLanguage.equalsIgnoreCase("FR"))
      acceptLanguage = "EN";

    SqlParameterSource parameters = new MapSqlParameterSource().addValue("language", acceptLanguage.toUpperCase());
    List<Map<String, Object>> recoveryQuestions =
        namedParameterJdbcTemplate.queryForList(Constants.GET_RECOVERY_QUESTIONS_BY_LANGUAGE_QUERY, parameters);

    if (recoveryQuestions.isEmpty()) {
      throw new FumNotFoundException(Constants.ERROR_RECOVERY_QUESTIONS_NOT_FOUND_CODE,
          String.format(Constants.ERROR_RECOVERY_QUESTIONS_NOT_FOUND_MESSAGE, acceptLanguage));
    }

    return recoveryQuestions.stream()
        .map(MapperUtils::toIamContentTranslationEntity)
        .collect(Collectors.toMap(IamContentTranslation::getTranslationKey,
            IamContentTranslation::getTranslationValue));
  }

  public void deleteUser2FA(String userId) {
    UserConfiguration userConfiguration = this.getUserConfigurationByIdOrName(userId);
    throwExceptionForNonNbin(userConfiguration);
    ciamService.deleteOktaUser2fa(userConfiguration.getIdpUserId());
  }

  public String resetPassword(String userId, UserCredentials userCredentials) {
    String tempPass = null;
    String encodedTempPass = null;
    UserConfiguration userConfiguration = this.getUserConfigurationByIdOrName(userId);
    throwExceptionForNonNbin(userConfiguration);
    /** If a temporary password is provided, use that else generate a new one */
    try {
      tempPass =
          userCredentials.getTempPassword() == null
              ? UserConfigUtils.getTempPassword(
              userConfiguration.getFirstName(), userConfiguration.getLastName())
              : userCredentials.getTempPassword();
      encodedTempPass = tempPass;
    } catch (Exception e) {
      log.error("Error in generating tempPass: {}", e.getMessage());
      throw new ServiceException(ErrorSeverity.ERROR, "Error generating temporary password");
    }
    OktaNewPassword oktaNewPassword = new OktaNewPassword();
    oktaNewPassword.setNewPassword(encodedTempPass);
    ciamService.resetPassword(userConfiguration.getIdpUserId(), oktaNewPassword);
    log.info("Okta temp password reset call done!");
    return tempPass;
  }

  @Transactional(rollbackFor = Exception.class)
  public void deleteUserConfigurationByUserId(String deletedBy, Integer userConfigurationId) {
    IamUserConfiguration userConfiguration = iamUserConfigurationRepository.getReferenceById(userConfigurationId.longValue());
    userConfiguration.setActive(false);
    userConfiguration.setState(Constants.IDP_STATUS_DECOMMISSIONED);
    userConfiguration.setLastUpdatedBy(deletedBy);
    userConfiguration.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
    iamUserConfigurationRepository.save(userConfiguration);
    updateSecureZoneUserActiveStatus(userConfiguration, false);
    ciamService.suspendUserOktaProfile(userConfiguration.getIdpUserIdentifier());
    redisCacheOperationService.deleteUserConfigurationCache(userConfiguration.getIdpSubject(), userConfigurationId, userConfiguration.getIdpUserIdentifier());
  }

  public void suspendUserOktaProfile(UserConfiguration userConfiguration) {
    ciamService.suspendUserOktaProfile(userConfiguration.getIdpUserId());
    redisCacheOperationService.deleteUserConfigurationCache(userConfiguration);
  }

  public void suspendOktaProfileByIdpSubject(String idpSubject) {
    if (StringUtils.isNotEmpty(idpSubject)) {
      UserConfiguration sourceConfiguration = getUserConfiguration(idpSubject);
      UserOktaProfile userOktaProfile = getOktaProfile(sourceConfiguration.getUsername());
      if (userOktaProfile != null && !StringUtils.equalsIgnoreCase(userOktaProfile.getStatus(), SUSPENDED.dbValue)) {
        suspendUserOktaProfile(sourceConfiguration);
      }
    }
  }

  public void unsuspendUserOktaProfile(UserConfiguration userConfiguration) {
    ciamService.unsuspendUserOktaProfile(userConfiguration.getIdpUserId());
    redisCacheOperationService.deleteUserConfigurationCache(userConfiguration);
  }

  public void validateIsUserSuspended(UserConfiguration userConfiguration) {
    if(!userConfiguration.getStatus().equals(UserStatusEnum.INACTIVE.dbValue) ||
        !userConfiguration.getState().equals(UserStatusEnum.INACTIVE.dbValue) ||
        !userConfiguration.getStateDescription().equals(SUSPENDED.dbValue)) {
      throw new FumValidationException(Constants.ERROR_USER_NOT_SUSPENDED_CODE,
          String.format(Constants.ERROR_USER_NOT_SUSPENDED_MESSAGE, userConfiguration.getIdpSubject()));
    }
  }

  public UserOktaProfile getOktaProfile(String userId) {
    IamUserConfiguration iamUserConfiguration = findUserConfigurationForOktaProfile(userId);

    // Employee (non-Okta) users have no idpUserId and therefore no Okta profile. Report
    // not-found without calling CIAM and without flagging the profile as deleted.
    if (StringUtils.isBlank(iamUserConfiguration.getIdpUserIdentifier())) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_OKTA_USER_NOT_FOUND_MESSAGE, userId));
    }

    return fetchAndMapOktaProfile(iamUserConfiguration);
  }

  /**
   * Endpoint-facing variant of {@link #getOktaProfile(String)} used by the
   * GET /users/{userId}/oktaProfile endpoint. Employee (non-Okta) users have no Okta profile,
   * so an empty {@link UserOktaProfile} is returned instead of a 404.
   */
  public UserOktaProfile getOktaProfileOrEmpty(String userId) {
    IamUserConfiguration iamUserConfiguration = findUserConfigurationForOktaProfile(userId);

    // Employee (non-Okta) users have no idpUserId and therefore no Okta profile. Return an
    // empty profile without calling CIAM and without flagging the profile as deleted.
    if (StringUtils.isBlank(iamUserConfiguration.getIdpUserIdentifier())) {
      return new UserOktaProfile();
    }

    return fetchAndMapOktaProfile(iamUserConfiguration);
  }

  private IamUserConfiguration findUserConfigurationForOktaProfile(String userId) {
    IamUserConfiguration iamUserConfiguration;
    if (UserConfigUtils.isNumber(userId)) {
      iamUserConfiguration = iamUserConfigurationRepository.findById(Long.valueOf(userId)).orElse(null);
    } else {
      iamUserConfiguration = iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(userId).orElse(null);
    }

    if (iamUserConfiguration == null) {
      iamUserConfiguration = iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(userId).orElseThrow(() -> new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userId)));
    }
    return iamUserConfiguration;
  }

  private UserOktaProfile fetchAndMapOktaProfile(IamUserConfiguration iamUserConfiguration) {
    OktaUserProfile oktaUserProfile;
    try {
      oktaUserProfile = ciamService.getOktaUserProfile(iamUserConfiguration.getIdpUserIdentifier());
    } catch (FumNotFoundException e) {
      userStateService.updateStateForDeletedOktaProfile(iamUserConfiguration);
      redisCacheOperationService.deleteUserConfigurationCache(iamUserConfiguration.getIdpSubject(),
          iamUserConfiguration.getUserConfigurationId().intValue(),
          iamUserConfiguration.getIdpUserIdentifier());
      throw e;
    }

    UserOktaProfile userOktaProfile;
    try {
      userStateService.updateStateFromOktaProfile(iamUserConfiguration, oktaUserProfile);
      redisCacheOperationService.deleteUserConfigurationCache(iamUserConfiguration.getIdpSubject(),
          iamUserConfiguration.getUserConfigurationId().intValue(),
          iamUserConfiguration.getIdpUserIdentifier());
      userOktaProfile =
          objectMapper.readValue(objectMapper.writeValueAsString(oktaUserProfile), UserOktaProfile.class);
    } catch (JacksonException e) {
      log.error("Error mapping OktaUserProfile to UserOktaProfile obj: {}", e.getMessage());
      throw new ServiceException(
          ErrorSeverity.ERROR, "Error mapping OktaUserProfile to UserOktaProfile obj");
    }
    return userOktaProfile;
  }

  private void deleteUserRRCodesByIdpSubject(String idpSubject) {
    List<UserAssignmentRrCodeRange> lst = userAssignmentService.getUserAssignment(idpSubject, UserAssignmentType.R);
    lst.forEach(userAssignmentRrCodeRangeRepository::delete);
  }

  private void addRRCodeRangeToUser(IamUserConfiguration savedUser, UserConfiguration userConfiguration, String updateUseridpSubject) {
    List<IamRrCodeRange> firmList = getIamRRCodeListByFirmId(userConfiguration.getFirmId(), true);
    Optional.ofNullable(userConfiguration.getRrCodes())
        .ifPresent(rs -> rs.forEach(rr -> addRRCodeRangeToUser(savedUser, firmList, rr, rr, updateUseridpSubject)));
    Optional.ofNullable(userConfiguration.getRrCodeRanges())
        .ifPresent(rs -> rs.forEach(rr -> addRRCodeRangeToUser(savedUser, firmList, rr.getFromRRCode(), rr.getToRRCode(), updateUseridpSubject)));
  }

  private void addRRCodeRangeToUser(IamUserConfiguration user, List<IamRrCodeRange> firmLst, String from, String to, String updateUseridpSubject) {
    IamRrCodeRange saved = firmLst.stream()
        .filter(rr -> rr.getFromRrCode().equalsIgnoreCase(from) && rr.getToRrCode().equalsIgnoreCase(to))
        .findFirst()
        .orElseGet(() -> createRRCodeIfNotAvailable(from, to, updateUseridpSubject));

    UserAssignmentRrCodeRange userAssignmentRrCodeRange = new UserAssignmentRrCodeRange();
    userAssignmentRrCodeRange.setAssignmentType(UserAssignmentType.R);
    userAssignmentRrCodeRange.setIamRrCodeRange(saved);
    userAssignmentRrCodeRange.setUserConfiguration(user);
    userAssignmentRrCodeRange.setCreatedBy(updateUseridpSubject);
    userAssignmentRrCodeRange.setCreationDate(new Timestamp(System.currentTimeMillis()));
    userAssignmentRrCodeRangeRepository.save(userAssignmentRrCodeRange);
  }

  private IamRrCodeRange createRRCodeIfNotAvailable(String from, String to, String updateUseridpSubject) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("fromRrCode",
        Pair.of(EnumQueryCriteria.EQUALS, from));
    fieldValueMap.put("toRrCode",
        Pair.of(EnumQueryCriteria.EQUALS, to));
    Specification<IamRrCodeRange> spec = new Specification<>(fieldValueMap);
    List<IamRrCodeRange> lst = iamRrCodeRangeRepository.findAll(spec);
    if(lst.size() > 0) {
      return lst.get(0);
    }
    IamRrCodeRange iamRrCodeRange = new IamRrCodeRange();
    iamRrCodeRange.setFromRrCode(from);
    iamRrCodeRange.setToRrCode(to);
    iamRrCodeRange.setActive(true);
    iamRrCodeRange.setCreatedBy(updateUseridpSubject);
    iamRrCodeRange.setCreationDate(new Timestamp(System.currentTimeMillis()));
    return iamRrCodeRangeRepository.save(iamRrCodeRange);
  }

  private void deleteUserGroupsByIdpSubject(String idpSubject) {
    List<UserAssignmentUserGroup> lst = userAssignmentService.getUserAssignment(idpSubject, UserAssignmentType.G);
    lst.forEach(userAssignmentUserGroupRepository::delete);
  }

  private void assignUserGroups(IamUserConfiguration iamUserConfiguration, String userGroup, String idpSubject) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("name", Pair.of(EnumQueryCriteria.IGNORE_CASE_EQUALS, userGroup));

    Specification<UserGroup> spec = new Specification<>(fieldValueMap);
    List<UserGroup> lst = this.userGroupRepository.findAll(spec);
    UserAssignmentUserGroup userAssignmentUserGroup = new UserAssignmentUserGroup();
    userAssignmentUserGroup.setAssignmentType(UserAssignmentType.G);
    userAssignmentUserGroup.setUserGroup(lst.get(0));
    userAssignmentUserGroup.setUserConfiguration(iamUserConfiguration);
    userAssignmentUserGroup.setCreatedBy(idpSubject);
    userAssignmentUserGroup.setCreationDate(new Timestamp(System.currentTimeMillis()));

    userAssignmentUserGroupRepository.save(userAssignmentUserGroup);
  }

  public void updateUserSecureZoneIds(UserConfiguration userConfiguration,
      IamUserConfiguration iamUserConfiguration) {
    List<String> secureZoneIds = userConfiguration.getSecureZoneIds();

    if (secureZoneIds == null || secureZoneIds.isEmpty()) {
      unassignUserSecureZoneIds(iamUserConfiguration);
      return;
    }

    if (isUamaEnabled) {
      // Resolved only once UAMA is actually reached: getUserType rejects any idp other than
      // nbin / nbc / IAMi, so resolving it up-front would fail every update of an external-SSO
      // (indall, sunlif) or blank-idp user, even when no SecureZone id is involved.
      String userType = getUserType(iamUserConfiguration.getIdp());

      // 1) UAMA first - fail-fast; a 4xx (incl. 404) throws FumValidationException => rollback.
      for (String szId : secureZoneIds) {
        szService.assignExternalIdToUsername(szId, iamUserConfiguration.getIdpSubject(), userType);
      }
    } else {
      log.info(
          "UAMA is disabled (userConfiguration.uama.enable=false); skipping SecureZone id assignment for user {}",
          iamUserConfiguration.getIdpSubject());
    }

    // 2) Okta - reached only if every UAMA assignment succeeded, or if UAMA is disabled.
    ciamService.updateOktaSecureZoneId(
        iamUserConfiguration.getIdpUserIdentifier(), secureZoneIds.toArray(new String[0]));
  }

  // No SecureZone ids in the payload = the link is being removed. UAMA exposes no delete
  // operation, so the existing assignment is released by PATCHing the szId with the literal
  // "null" username: PATCH /user-access-management/Users/{szId}/null/{userType}.
  // Fail-fast on purpose: a UAMA failure must fail the whole user update (rollback).
  void unassignUserSecureZoneIds(IamUserConfiguration iamUserConfiguration) {
    String idpSubject = iamUserConfiguration.getIdpSubject();

    if (isUamaEnabled) {
      List<String> assignedSzIds = getAssignedSecureZoneIds(idpSubject);

      if (assignedSzIds.isEmpty()) {
        log.debug("No SecureZone id assigned to user {} in UAMA; clearing Okta only", idpSubject);
      } else {
        String userType = getUserType(iamUserConfiguration.getIdp());
        log.info("No SecureZone ids provided for user {}; unassigning existing SecureZone id(s) {}",
            idpSubject, assignedSzIds);
        for (String szId : assignedSzIds) {
          szService.assignExternalIdToUsername(szId, Constants.SZ_UNASSIGNED_IDP_SUBJECT, userType);
        }
      }
    } else {
      log.info(
          "UAMA is disabled (userConfiguration.uama.enable=false); skipping SecureZone id release for user {}",
          idpSubject);
    }

    // Cleared unconditionally: even with nothing assigned in UAMA, Okta can still carry a stale
    // bngfSecureZoneId - and that attribute is what GET user-external-system-configuration
    // returns to the UI. Okta and UAMA reconcile in the background.
    ciamService.updateOktaSecureZoneId(iamUserConfiguration.getIdpUserIdentifier(), new String[0]);
  }

  private List<String> getAssignedSecureZoneIds(String idpSubject) {
    // The UAMA filter is "username sw <idpSubject>" (starts-with), so the response can include
    // users whose username merely shares the prefix. Match the username before releasing an
    // szId, otherwise another user's SecureZone link could be removed.
    return Optional.ofNullable(szService.getExternalUserByIdpSubject(idpSubject))
        .map(SzUserSearch::getResources)
        .orElseGet(List::of)
        .stream()
        .filter(szUser -> idpSubject.equalsIgnoreCase(szUser.getUserName()))
        .map(SzUser::getId)
        .filter(StringUtils::isNotBlank)
        .collect(Collectors.toList());
  }

  public void updateSecureZoneUserActiveStatus(IamUserConfiguration iamUserConfiguration, boolean active) {
    // Gated before getSecureZoneId: with UAMA unreachable every szId costs a full Feign retry
    // cycle, and SzFeignClientConfigUAMA hand-builds its client so the configured timeouts and
    // NEVER_RETRY do not apply. Returning here also skips the now-pointless Okta lookup.
    if (!isUamaEnabled) {
      log.info(
          "UAMA is disabled (userConfiguration.uama.enable=false); skipping SecureZone active-status update for user {}",
          iamUserConfiguration.getIdpSubject());
      return;
    }

    String[] secureZoneIds = getSecureZoneId(iamUserConfiguration.getIdpUserIdentifier());
    if (secureZoneIds == null || secureZoneIds.length == 0) {
      return;
    }

    for (String szId : secureZoneIds) {
      try {
        // 1) GET current SecureZone user - preserves userName, names, userType, groups, etc.
        SzUser szUser = szService.getExternalUser(szId);
        // 2) Flip only the active flag.
        szUser.setActive(active);
        // 3) PUT it back.
        szService.updateUserActiveStatus(szId, szUser);
      } catch (Exception e) {
        // Skip this szId - do not fail the overall (de)activation.
        log.warn("Skipping SecureZone active-status update for szId {}: {}", szId, e.getMessage());
      }
    }
  }

  private void deleteFeaturePackage(IamUserConfiguration savedUser) {
    List<UserAssignmentFeaturePackage> lst = userAssignmentService.getUserAssignment(savedUser.getIdpSubject(), UserAssignmentType.P);
    lst.forEach(userAssignmentFeaturePackageRepository::delete);
  }

  public List<FeaturePackage> getUserFeaturePackage(String idpSubject, Boolean active) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    if (active != null) {
      fieldValueMap.put(UserStatusEnum.ACTIVE.dbValue, Pair.of(EnumQueryCriteria.EQUALS, active));
    }
    fieldValueMap.put("userAssignmentFeaturePackages.assignmentType",
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.P.name()));
    fieldValueMap.put("userAssignmentFeaturePackages.userConfiguration.idpSubject",
        Pair.of(EnumQueryCriteria.EQUALS, idpSubject));
    Specification<FeaturePackage> spec = new Specification<>(fieldValueMap);
    return featurePackageRepository.findAll(spec);
  }

  public String getUserGroupNameFromPackageTemplate(Long packageTemplateId) {
    return getPackageTemplateAssignmentUserGroup(packageTemplateId)
        .stream()
        .findFirst().
        map(PackageTemplateAssignmentUserGroup::getUserGroup)
        .map(UserGroup::getName)
        .orElse(null);

  }

  public String getUserGroupNameFromPackageTemplate(String packageTemplateName) {
    return getPackageTemplateAssignmentUserGroup(packageTemplateName)
        .stream()
        .findFirst().
        map(PackageTemplateAssignmentUserGroup::getUserGroup)
        .map(UserGroup::getName)
        .orElse(null);

  }

  public List<PackageTemplateAssignmentUserGroup> getPackageTemplateAssignmentUserGroup(
      Long packageTemplateId) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("packageTemplate.packageTemplateId",
        Pair.of(EnumQueryCriteria.EQUALS, packageTemplateId));
    fieldValueMap.put(ASSIGNMENT_TYPE,
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER,
            PackageAssignmentType.G.name()));
    Specification<PackageTemplateAssignmentUserGroup> spec = new Specification<>(fieldValueMap);
    return packageTemplateAssignmentUserGroupRepository.findAll(spec);
  }

  public List<PackageTemplateAssignmentUserGroup> getPackageTemplateAssignmentUserGroup(String packageTemplateName) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("packageTemplate.name",
        Pair.of(EnumQueryCriteria.EQUALS, packageTemplateName));
    fieldValueMap.put(ASSIGNMENT_TYPE,
        Pair.of(EnumQueryCriteria.EQUALS_CHARACTER,
            PackageAssignmentType.G.name()));
    Specification<PackageTemplateAssignmentUserGroup> spec = new Specification<>(fieldValueMap);
    return packageTemplateAssignmentUserGroupRepository.findAll(spec);
  }

  public boolean requestHasFeaturePackage(UserConfiguration userConfiguration) {
    ca.bnc.wealth.common.userconfiguration.model.FeaturePackage featurePackage = userConfiguration.getFeaturePackage();
    if(featurePackage != null && (StringUtils.isNotBlank(featurePackage.getPackageName()) || featurePackage.getAssignments() != null && featurePackage.getAssignments().size() > 0)) {
      return true;
    }
    return false;
  }

  public UserConfiguration toDtoWithUserGroupAndFirmId(IamUserConfiguration entity) {
    UserConfiguration userConfiguration = toDtoWithUserGroup(entity);
    List<UserAssignmentFirm> userAssignmentFirms = userAssignmentService.getUserAssignment(entity.getIdpSubject(),
        UserAssignmentType.F);
    if (userAssignmentFirms.size() == 1) {
      if (userAssignmentFirms.get(0).getFirm() != null) {
        Firm firm = userAssignmentFirms.get(0).getFirm();
        userConfiguration.setFirmId(firm.getFirmId());
        userConfiguration.setFirmName(firm.getName());
        userConfiguration.setFirmType(firm.getFirmType().name());
        userConfiguration.setUserPreferences(getUserPreferences(userConfiguration.getUserPreferences(), firm.getFirmPreferences()));
      }
    }
    return userConfiguration;
  }

  private UserConfiguration toDtoWithUserGroup(IamUserConfiguration entity) {
    UserConfiguration userConfiguration = MapperUtils.toDto(entity);
    List<UserAssignmentUserGroup> userAssignmentUserGroups = userAssignmentService.getUserAssignment(
        entity.getIdpSubject(), UserAssignmentType.G);
    if (userAssignmentUserGroups.size() == 1) {
      if (userAssignmentUserGroups.get(0).getUserGroup() != null) {
        userConfiguration.setUserGroup(userAssignmentUserGroups.get(0).getUserGroup().getName());
        userConfiguration.setUserGroupDescription(
            userAssignmentUserGroups.get(0).getUserGroup().getDescription());
      }
    }
    //Get user firm scope
    userConfiguration.setIsFirmScope(userAssignmentService.hasUserAssignment(entity.getIdpSubject(), Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS,UserAssignmentType.S));
    return userConfiguration;
  }

  @Cacheable(value = "UserConfiguration-CompassR2Id", key = "#idpSubject", cacheManager = "redisCacheManager", unless="#result == null", condition = "#root.getTarget().redisCacheEnabled()")
  public String getCompassR2Id(String idpSubject) {
    return Optional.ofNullable(r2Service.getCxUserProfile(idpSubject)).map(Pair::getValue).orElse(null);
  }

  // Employee (non-Okta) users have a null/blank idpUserId. Skip the cache entirely for them so
  // Spring never tries to build a null cache key (which throws "Null key returned for cache
  // operation"); the method body then returns null and callers handle the absent SecureZone id.
  @Cacheable(value = "UserConfiguration-SecurityZoneId", key = "#idpUserId", cacheManager = "redisCacheManager", unless="#result == null", condition = "#idpUserId != null and !#idpUserId.isBlank() and #root.getTarget().redisCacheEnabled()")
  public String[] getSecureZoneId(String idpUserId) {
    return getSecureZoneIdOptional(idpUserId).orElse(null);
  }

  public Optional<String[]> getSecureZoneIdOptional(String idpUserId) {
    // Employee (non-Okta) users have no idpUserId, so there is no SecureZone profile to read.
    if (StringUtils.isBlank(idpUserId)) {
      return Optional.empty();
    }
    OktaUserProfile oktaUserProfile = ciamService.getOktaUserProfile(idpUserId);

    return Optional.ofNullable(oktaUserProfile)
        .map(OktaUserProfile::getAccessProfile)
        .map(OktaAccessProfile::getBngfSecureZoneId);
  }

  public void idpStatusUpdateSchedule(Integer userConfigurationId) {
    iamUserConfigurationRepository.findById(Long.valueOf(userConfigurationId))
        .ifPresent(
            iamUserConfiguration ->
                ciamService.getOktaUserProfile(iamUserConfiguration.getIdpUserIdentifier(), retryCountForGetOktaUserProfile )
                    .ifPresent(
                        oktaUserProfile -> userStateService.updateStateFromOktaProfile(iamUserConfiguration, oktaUserProfile)
                    )
        );
  }

  @SneakyThrows
  public static void shutdownAndAwait(ExecutorService executorService) {
    executorService.shutdown();
    try {
      executorService.awaitTermination(100000, TimeUnit.MILLISECONDS);
    } catch (InterruptedException e) {
      executorService.shutdownNow();
      log.error("Error in executor service", e);
      throw e;
    }
  }

  private UserConfiguration toDto(Map<String, Object> map) {
    UserConfiguration dto = new UserConfiguration();
    dto.setUserConfigurationId(getIntegerValue(map.get("USER_CONFIGURATION_ID")));
    dto.setIdpUserId(getStringValue(map.get("IDP_USER_ID")));
    dto.setIdpSubject(getStringValue(map.get("IDP_SUBJECT")));
    dto.setIdp(getStringValue(map.get("IDP")));
    dto.setUsername(getStringValue(map.get("USERNAME")));
    dto.setOssId(getStringValue(map.get("OSS_USER_ID")));
    dto.setOssProxyId(getStringValue(map.get("OSS_GROUP_ID")));
    dto.setOssUserId(getStringValue(map.get("OSS_USER_ID")));
    dto.setOssGroupId(getStringValue(map.get("OSS_GROUP_ID")));
    dto.setFirstName(getStringValue(map.get("FIRST_NAME")));
    dto.setLastName(getStringValue(map.get("LAST_NAME")));
    dto.setEmail(getStringValue(map.get("EMAIL")));

    dto.setStatus(getBooleanValue(map.get("ACTIVE")) ? UserStatusEnum.ACTIVE.dbValue : UserStatusEnum.INACTIVE.dbValue);
    dto.setState(getStringValue(map.get("STATE")));
    dto.setStateDescription(getStringValue(map.get("STATE_DESCRIPTION")));
    dto.setStateAction(getStringValue(map.get("STATE_ACTION")));

    dto.setPreferredLanguage(getStringValue(map.get("PREFERRED_LANGUAGE")));
    dto.setActive(getBooleanValue(map.get("ACTIVE"))  ? "Active" : "Inactive");
    dto.setCreatedBy(getStringValue(map.get("CREATED_BY")));
    dto.setLastUpdatedBy(getStringValue(map.get("LAST_UPDATED_BY")));
    dto.setCreationDate(getLocalDateTimeValue(map.get("CREATION_DATE")));
    dto.setLastUpdatedDate(getLocalDateTimeValue(map.get("LAST_UPDATE_DATE")));
    dto.setIdentityLastUpdatedDate(getLocalDateTimeValue(map.get("IDENTITY_LAST_UPDATED")));
    dto.setAccessProfileSet(getBooleanValue(map.get("ACCESS_PROFILE_SET")));
    dto.setUserGroup(getStringValue(map.get("USER_GROUP_NAME")));
    dto.setUserGroupDescription(getStringValue(map.get("USER_GROUP_DESCRIPTION")));
    dto.setIsFirmScope(getBooleanValue(map.get("IS_FIRM_SCOPE")));

    dto.setFirmId(getStringValue(map.get("FIRM_ID")));
    dto.setFirmName(getStringValue(map.get("FIRM_NAME")));
    dto.setFirmType(getStringValue(map.get("FIRM_TYPE")));
    dto.setActivationDate(getLocalDateTimeValue(map.get("ACTIVATION_DATE")));
    dto.setSourceIdpSubject(getStringValue(map.get("SOURCE_IDP_SUBJECT")));
    dto.setBngfReferenceId(getStringValue(map.get("BNGF_REFERENCE_ID")));
    dto.setIdentityLastUpdatedDate(getLocalDateTimeValue(map.get("IDENTITY_LAST_UPDATED")));
    dto.setUserRole(getStringValue(map.get("USER_ROLE")));
    dto.setUserRoleDescription(getStringValue(map.get("USER_ROLE_DESCRIPTION")));

    Map<String, String> userPreferences = Optional.ofNullable(map.get("USER_PREFERENCES"))
        .map(String::valueOf)
        .map(MapperUtils::getMap)
        .orElse(new HashMap<>());

    Map<String, String> firmPreferences = Optional.ofNullable(map.get("FIRM_PREFERENCES"))
        .map(String::valueOf)
        .map(MapperUtils::getMap)
        .orElse(new HashMap<>());

    dto.setUserPreferences(getUserPreferences(userPreferences, firmPreferences));
    return dto;
  }

  private static Map<String, String> getUserPreferences(Map<String, String> userPreferences, Map<String, String> firmPreferences) {
    Map<String, String> preferences = new HashMap<>();
    Optional.ofNullable(firmPreferences)
        .ifPresent(prefs -> prefs.entrySet().stream()
            .filter(entry -> entry.getValue() != null)
            .forEach(entry -> preferences.put(entry.getKey(), entry.getValue())));
    Optional.ofNullable(userPreferences)
        .ifPresent(prefs -> prefs.entrySet().stream()     
            .filter(entry -> entry.getValue() != null)
            .forEach(entry -> preferences.put(entry.getKey(), entry.getValue())));
    return preferences;
  }

  private String getStringValue(Object object) {
    return object != null ? object.toString() : null;
  }

  private Boolean getBooleanValue(Object object) {
    return object != null ? Boolean.valueOf(getStringValue(object)) : false;
  }

  private Integer getIntegerValue(Object object) {
    return object != null ? Integer.valueOf(getStringValue(object)) : null;
  }
  private LocalDateTime getLocalDateTimeValue(Object object) {
    return object != null ? ((Timestamp)object).toLocalDateTime(): null;
  }

  private Optional<Firm> findFirm(String firmId) {
    return Optional.of(firmRepository.findByFirmId(firmId));
  }

  public IamUserConfiguration saveNewUserConfiguration(UserConfiguration userConfiguration, String requestedBy) {
    // Employee Short IDs are stored upper case (NWPI-14901). Canonicalising here rather than relying
    // on trg_normalise_employee_short_id is mandatory: that trigger is BEFORE INSERT only, and the
    // second save() below is a full UPDATE (no @DynamicUpdate) that would write the stale pre-trigger
    // USERNAME held in the persistence context straight back over the normalised row.
    boolean isEmployee = isEmployeeIdp(userConfiguration.getIdp());
    IamUserConfiguration iamUserConfiguration = IamUserConfiguration.builder()
        .idpUserIdentifier(userConfiguration.getIdpUserId())
        .idpSubject(canonicalizeIfEmployee(userConfiguration.getIdpSubject(), isEmployee))
        .username(canonicalizeIfEmployee(userConfiguration.getUsername(), isEmployee))
        .idp(userConfiguration.getIdp())
        .ossUserId(Optional.ofNullable(userConfiguration.getOssUserId()).orElse(userConfiguration.getOssId()))
        .ossGroupId(Optional.ofNullable(userConfiguration.getOssGroupId()).orElse(userConfiguration.getOssProxyId()))
        .firstName(userConfiguration.getFirstName())
        .lastName(userConfiguration.getLastName())
        .email(userConfiguration.getEmail())
        .preferredLanguageType(Optional.ofNullable(userConfiguration.getPreferredLanguage()).map(PreferredLanguageType::valueOf).orElse(PreferredLanguageType.EN))
        .createdBy(requestedBy)
        .creationDate(new Timestamp(System.currentTimeMillis()))
        .profileLastUpdated(new Timestamp(System.currentTimeMillis()))
        .activationDate(userConfiguration.getActivationDate()!=null ? Timestamp.valueOf(userConfiguration.getActivationDate()) : null)
        //For NCE users the active profile will always be set to true. For non-nbin users, this will be set case by case basis in the incoming request
        .accessProfileSet(getAccessProfileStatus(userConfiguration))
        .identityLastUpdated(userConfiguration.getIdentityLastUpdatedDate() != null ? Timestamp.valueOf(userConfiguration.getIdentityLastUpdatedDate()) : null)
        .sourceIdpSubject(userConfiguration.getSourceIdpSubject())
            .bngfReferenceId(canonicalizeIfEmployee(userConfiguration.getBngfReferenceId(), isEmployee))
        .userPreferences(userConfiguration.getUserPreferences())
        .source(userConfiguration.getSource())
        .build();
    if (userConfiguration.getIdentityLastUpdatedDate() != null) {
      iamUserConfiguration.setIdentityLastUpdated(Timestamp.valueOf(userConfiguration.getIdentityLastUpdatedDate()));
    }
    userStateService.setStateOnboardingStaged(iamUserConfiguration);

    try {
      iamUserConfiguration = iamUserConfigurationRepository.save(iamUserConfiguration);

      /**
       * For NCE(nbin) users, the bngf reference id will be the same as the user configuration id generated by the system.
       * For external systems, the bngf reference id will be the identitySource + externalClientId where the external clientId is the unique identifier for the user in the external IDP system.
       * For employee tenants, the bngf reference id will be the employee id and no prefix will be added.
       * The idpSubject will be a combination of the firm's identitySource value and the bngf reference id. If the identitySource is null, then the default value will be used which is cpx for now.
       */
      if ((userConfiguration.getIdp() == null || userConfiguration.getIdp()
          .equalsIgnoreCase(Constants.CPX_IDP))
          && userConfiguration.getExternalClientId() == null) {
        String bngfReferenceid = generateBngfReferenceId(userConfiguration.getFirmId(),
            String.valueOf(iamUserConfiguration.getUserConfigurationId()));
        iamUserConfiguration.setIdpSubject(bngfReferenceid);
        iamUserConfiguration.setBngfReferenceId(bngfReferenceid);
        iamUserConfiguration = iamUserConfigurationRepository.save(iamUserConfiguration);
      } else {
        if (userConfiguration.getIdp().equalsIgnoreCase(Constants.DWH_IDP)) {
          iamUserConfiguration.setIdpSubject(userConfiguration.getExternalClientId());
          iamUserConfiguration.setBngfReferenceId(userConfiguration.getExternalClientId());
        } else if (isEmployee) {
          // As the contract above states, an employee tenant's reference IS the Short ID, with no
          // identity-source prefix — the same shape EmployeeAccessManagementService.createEmployee
          // writes. Re-deriving it below would replace the canonical value with
          // "<identitySource>_<externalClientId>" (or "cpx_null"), undoing the upper-casing and
          // leaving IDP_SUBJECT — the USER_ASSIGNMENT foreign key target — non-canonical.
          iamUserConfiguration.setIdpSubject(iamUserConfiguration.getUsername());
          iamUserConfiguration.setBngfReferenceId(iamUserConfiguration.getUsername());
          iamUserConfiguration.setIdentityLastUpdated(
              Timestamp.valueOf(LocalDateTime.parse(Constants.DEFAULT_IDENTIFY_LAST_UPDATED_DATE)));
        } else {
          String bngfReferenceId = generateBngfReferenceId(userConfiguration.getFirmId(),
              userConfiguration.getExternalClientId());
          iamUserConfiguration.setBngfReferenceId(bngfReferenceId);
          iamUserConfiguration.setIdpSubject(bngfReferenceId);
          iamUserConfiguration.setIdentityLastUpdated(
              Timestamp.valueOf(LocalDateTime.parse(Constants.DEFAULT_IDENTIFY_LAST_UPDATED_DATE)));
        }
        iamUserConfiguration = iamUserConfigurationRepository.save(iamUserConfiguration);
      }
    } catch (Exception e) {
      log.info("Error saving user configuration: {}", e.getMessage());
      if (e instanceof DataIntegrityViolationException) {
        // Username, idpSubject and bngfReferenceId are all uniquely indexed — the clash is the
        // caller's to resolve, so surface it as 409 rather than 500 (NWPI-14901).
        throw new FumConflictException(Constants.ERROR_CODE_CREATE_USER, Constants.ERROR_USER_ALREADY_EXISTS);
      }
      throw new FumServiceException(Constants.ERROR_CODE_CREATE_USER, Constants.ERROR_DEFAULTMESSAGE_CREATE_USER_VALIDATION);
    }
    personService.syncPersonFromUserConfiguration(iamUserConfiguration);
    return iamUserConfiguration;
  }

  private static String canonicalizeIfEmployee(String value, boolean isEmployee) {
    return isEmployee ? ShortIdUtils.canonicalize(value) : value;
  }

  /** An arriving Short ID is identified solely by the request's idp, per ${userConfiguration.employee.idp}. */
  boolean isEmployeeIdp(String idp) {
    return StringUtils.isNotBlank(employeeIdp) && employeeIdp.equalsIgnoreCase(idp);
  }

  public IamUserConfiguration updateNbxUserConfiguration(String userId,
      NbxUserConfiguration nbxUserConfiguration) {
    IamUserConfiguration iamUserConfiguration = iamUserConfigurationRepository
        .findFirstByIdpSubject(userId).orElse(null);
    if (iamUserConfiguration == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userId));
    }

    if (nbxUserConfiguration.getFirstName() != null) {
      iamUserConfiguration.setFirstName(nbxUserConfiguration.getFirstName());
    }
    if (nbxUserConfiguration.getLastName() != null) {
      iamUserConfiguration.setLastName(nbxUserConfiguration.getLastName());
    }
    if (nbxUserConfiguration.getEmail() != null) {
      iamUserConfiguration.setEmail(nbxUserConfiguration.getEmail());
    }
    if (nbxUserConfiguration.getPreferredLanguage() != null) {
      iamUserConfiguration.setPreferredLanguageType(
          PreferredLanguageType.valueOf(nbxUserConfiguration.getPreferredLanguage().getValue()));
    }

    User principal = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    iamUserConfiguration.setLastUpdatedBy(principal.getIdpSubject());
    iamUserConfiguration.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
    iamUserConfiguration.setProfileLastUpdated(new Timestamp(System.currentTimeMillis()));
    iamUserConfiguration = iamUserConfigurationRepository.save(iamUserConfiguration);
    personService.syncPersonFromUserConfiguration(iamUserConfiguration);

    return iamUserConfiguration;
  }
  
  public boolean getAccessProfileStatus(UserConfiguration userConfiguration){
    if(userConfiguration.getIdp() == null || userConfiguration.getIdp().equalsIgnoreCase(Constants.CPX_IDP)){
      return true;
    }else if(userConfiguration.getAccessProfileSet() == null){
      return false;
      }else{
      return userConfiguration.getAccessProfileSet();
    }
  }

  public void updateAccessProfileSetStatus(Integer userConfigurationId, boolean accessProfileSet) {
    IamUserConfiguration userConfiguration = iamUserConfigurationRepository.findById(Long.valueOf(userConfigurationId)).orElse(null);
    if (userConfiguration == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
              String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userConfigurationId));
    }
    userConfiguration.setAccessProfileSet(accessProfileSet);
    userConfiguration.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
    iamUserConfigurationRepository.save(userConfiguration);
  }

  public String generateBngfReferenceId(String firmId, String externalClientId) {
    // Firm is null for NBX user creation
    if (firmId == null) {
      return Constants.CXP_IDENTITY_SOURCE + Constants.IDP_SUBJECT_SEPARATOR + externalClientId;
    }
    Firm firm = firmRepository.findByFirmId(firmId);
    return firm.getIdentitySource()!= null ? firm.getIdentitySource() + Constants.IDP_SUBJECT_SEPARATOR + externalClientId : Constants.CXP_IDENTITY_SOURCE + Constants.IDP_SUBJECT_SEPARATOR + externalClientId;
  }

  public String generateUserNameForSSO(String firmId, String externalClientId) {
    Firm firm = firmRepository.findByFirmId(firmId);
    return firm.getIdentitySource()!= null ? firm.getIdentitySource() + Constants.IDP_SUBJECT_SEPARATOR + externalClientId : Constants.CXP_IDENTITY_SOURCE + Constants.IDP_SUBJECT_SEPARATOR + externalClientId;
  }

  public void addRrCode(UserConfiguration userConfiguration, String requestedBy) {
    validateRestrictClientDataAccess(userConfiguration.getIdpSubject(), userConfiguration);

    Optional.ofNullable(userConfiguration.getRrCodeRanges()).ifPresent(
        rrCodeRanges -> userAssignmentService.assignRrRangesSp(userConfiguration.getUserConfigurationId(),
            userConfiguration.getIdpSubject(),
            rrCodeRanges,
            requestedBy)
    );
    Optional.ofNullable(userConfiguration.getRrCodes()).ifPresent(
        rrCodes -> {
          List<RRCodeRange>rrCodeRanges = rrCodes.stream()
              .map(rr -> RRCodeRange.builder().fromRRCode(rr).toRRCode(rr).build())
              .toList();
          userAssignmentService.assignRrRangesSp(userConfiguration.getUserConfigurationId(), userConfiguration.getIdpSubject(), rrCodeRanges, requestedBy);
        }
    );
  }

  public void validateRestrictClientDataAccess(String idpSubject, UserConfiguration userConfiguration) {
    boolean hasRestrictClientDataAccess = userAssignmentService.hasUserAssignment(
        idpSubject, Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S);
    if (!hasRestrictClientDataAccess) {
      return;
    }
    boolean hasFirmLevelAccess = userAssignmentService.hasUserAssignment(
        idpSubject, Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S);
    if (hasFirmLevelAccess) {
      throw new FumValidationException(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS,
          Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS_MESSAGE);
    }
    boolean hasRrCodeInput = (userConfiguration.getRrCodeRanges() != null && !userConfiguration.getRrCodeRanges().isEmpty())
        || (userConfiguration.getRrCodes() != null && !userConfiguration.getRrCodes().isEmpty());
    if (hasRrCodeInput) {
      throw new FumValidationException(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE,
          Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE_MESSAGE);
    }
  }

  void publishUserCreationMessage(UserConfiguration userConfiguration) {
    Tags tags = new Tags();
    tags.setCompassR2Id(StringUtils.isBlank(userConfiguration.getCompassR2Id()) ? "" : userConfiguration.getCompassR2Id());

    Header header = new Header();
    header.setId(UUID.randomUUID().toString());
    header.setRefId(userConfiguration.getIdpSubject());
    header.setAction(UserConfigurationConstants.CREATE_USERCONFIG_API);
    header.setState(UserConfigurationConstants.KAFKA_HEADER_STATE);
    header.setReason(UserConfigurationConstants.KAFKA_HEADER_REASON_STATETRANSITION);
    header.setVersion(UserConfigurationConstants.KAFKA_HEADER_VERSION);
    header.setTags(tags);

    Source source = UserConfigUtils.getSource();

    UserConfigEventPayLoad payload = new UserConfigEventPayLoad();
    payload.setId(userConfiguration.getIdpSubject());
    payload.setType(UserConfigurationConstants.KAFKA_PAYLOAD_EVENT_TYPE);
    payload.setActivationDate(userConfiguration.getActivationDate()!= null?java.sql.Timestamp.valueOf(userConfiguration.getActivationDate()): null);

    EventMessages<UserConfigEventPayLoad> eventMessages = new EventMessages<>();
    eventMessages.setHeader(header);
    eventMessages.setSource(source);
    eventMessages.setPayload(payload);
    userConfigEventProducerService.publishMessage(eventMessages);
  }

  public boolean redisCacheEnabled() {
    return enableCache;
  }

  public List<UserConfiguration> getUserConfigurationByUserIds(List<String> idpSubjects, String requestedBy) {
    List<UserConfiguration> users = new ArrayList<>();
    List<Long> firms = firmRepository.getAllFirmsByIdpSubject(requestedBy);
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(IDP_SUBJECT, Pair.of(EnumQueryCriteria.IN, idpSubjects));
    fieldValueMap.put("userAssignmentFirms.assignmentType", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.F.name()));
    fieldValueMap.put("userAssignmentFirms.firm.firmEntityId", Pair.of(EnumQueryCriteria.IN, firms));
    Specification<IamUserConfiguration> spec = new Specification<>(fieldValueMap);
    iamUserConfigurationRepository.findAll(spec).forEach(uc -> users.add(MapperUtils.toDto(uc)));
    return users;
  }

  public void updateLastLoginDate(String idbSubject) {
    IamUserConfiguration userConfiguration = iamUserConfigurationRepository.findByIdpSubject(idbSubject);
    if (userConfiguration == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, idbSubject));
    }
    userConfiguration.setLastLoginDate(new Timestamp(System.currentTimeMillis()));
    iamUserConfigurationRepository.save(userConfiguration);
  }

  public void updateLastUpdatedBy(Integer userConfigurationId,String idpSubject){
    IamUserConfiguration iamUserConfiguration = iamUserConfigurationRepository.findById(Long.valueOf(userConfigurationId)).orElse(null);
    if (iamUserConfiguration == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
              String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, userConfigurationId));
    }
    iamUserConfiguration.setLastUpdatedBy(idpSubject);
    iamUserConfiguration.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
    iamUserConfigurationRepository.save(iamUserConfiguration);
  }

  private void throwExceptionForNonNbin(UserConfiguration userConfiguration) {
    if (!CPX_IDP.equalsIgnoreCase(userConfiguration.getIdp())) {
      throw new IllegalArgumentException(Constants.OPERATION_NOT_SUPPORTED);
    }
  }

  public String getIdpSubjectFromPrincipalOrUserToken(String cxUserToken) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    if(user.isSystemToken()) {
      try {
        JWT jwt = JWTParser.parse(cxUserToken);
        return jwt.getJWTClaimsSet().getClaims().get("sub").toString();
      } catch (Exception e) {
        return null;
      }
    }
    return user.getIdpSubject();

  }

  public void updateUserPreference(String idpSubject, String preferenceId, String preferenceValue) {
    IamUserConfiguration user = iamUserConfigurationRepository.findByIdpSubject(idpSubject);
    if (user == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, idpSubject));
    }
    if (user.getUserPreferences() == null) {
      user.setUserPreferences(new HashMap<>());
    }
    IamUserConfiguration userBeforeUpdate = new IamUserConfiguration();
    BeanUtils.copyProperties(user, userBeforeUpdate);
    Map<String, String> userPreferences = user.getUserPreferences();
    userPreferences.put(preferenceId, preferenceValue);
    user.setUserPreferences(userPreferences);
    User principal = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    user.setLastUpdatedBy(principal.getIdpSubject());
    user.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
    iamUserConfigurationRepository.save(user);
    redisCacheOperationService.deleteUserConfigurationCacheEnrichUserMeUsersId(idpSubject, user.getUserConfigurationId().intValue());
    // Change-aware refresh (NWPI-14771 Stage 3): a preference update changes only USER_PREFERENCES
    // (no longer in the trimmed search view) plus audit timestamps, so the gate finds no
    // search-relevant change and skips the refresh. Kept as a gate rather than removed so any future
    // search-relevant change on this path still triggers a refresh.
    userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedViewIfChanged(
        userBeforeUpdate, user, false);
  }

  public void updateUserGroupByIdpSubject(String idpSubject, String groupName) {
    IamUserConfiguration iamUserConfiguration = iamUserConfigurationRepository.findByIdpSubject(idpSubject);
    if (iamUserConfiguration == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, idpSubject));
    }
    ciamService.updateOktaUserGroups(iamUserConfiguration.getIdpUserIdentifier(), groupName);
    assignSsoNoMfaUserGroup(toDtoWithUserGroup(iamUserConfiguration));
    assignEmployeeExternalUserGroup(iamUserConfiguration.getIdpUserIdentifier(), iamUserConfiguration);
    deleteUserGroupsByIdpSubject(idpSubject);
    assignUserGroups(iamUserConfiguration, groupName, idpSubject);
  }

  public void deleteUserGroupByIdpSubject(String idpSubject, String groupName) {
    IamUserConfiguration iamUserConfiguration = iamUserConfigurationRepository.findByIdpSubject(idpSubject);
    if (iamUserConfiguration == null) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, idpSubject));
    }
    ciamService.deleteOktaUserGroup(iamUserConfiguration.getIdpUserIdentifier(), groupName);
    userAssignmentUserGroupRepository.deleteByUserConfigurationIdpSubjectAndAssignmentTypeAndUserGroupName(
        idpSubject, UserAssignmentType.G, groupName);
  }
}
