package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.userconfiguration.model.state.UserStateActionEnum;
import ca.bnc.wealth.api.userconfiguration.model.state.UserStateDescriptionEnum;
import ca.bnc.wealth.api.userconfiguration.model.state.UserStateEnum;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.common.ciam.model.OktaFactor;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import java.sql.Timestamp;
import java.util.Arrays;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserStateService {

  private final IamUserConfigurationRepository iamUserConfigurationRepository;
  private final UserConfigSearchMaterializedRefreshService userConfigSearchMaterializedRefreshService;

  public void setStateOnboardingStaged(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.ONBOARDING.dbValue);
    iamUserConfiguration.setActive(false);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.STAGED.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.ONBOARDING.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  public void setStateOnboardingPendingUser(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.PROVISIONED.dbValue);
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.PENDING_USER_ACTION.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.ONBOARDING.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  public void setState2FaPendingUser(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.PROVISIONED.dbValue);
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.PENDING_USER_ACTION.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.SET_2FA.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  public void setStatePasswordPendingUser(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.PROVISIONED.dbValue);
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.PENDING_USER_ACTION.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.SET_PASSWORD.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  public void setStatePasswordExpired(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.RECOVERY.dbValue);
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.PASSWORD_EXPIRED.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.PASSWORD_EXPIRED.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  public void setStateActive(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.ACTIVE.dbValue);
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.ACTIVE.dbValue);
    iamUserConfiguration.setStateAction("");
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  public void setStateReset(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.RECOVERY.dbValue);
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.PASSWORD_RESET.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.PASSWORD_RESET.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  public void setStateSuspended(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.INACTIVE.dbValue);
    iamUserConfiguration.setActive(false);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.SUSPENDED.dbValue);
    iamUserConfiguration.setStateAction("");
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  public void setStateLockedOut(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.INACTIVE.dbValue);
    iamUserConfiguration.setActive(false);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.LOCKED.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.LOCKED.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  public void setStateDecommissioned(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.DECOMMISSIONED.dbValue);
    iamUserConfiguration.setActive(false);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.SUSPENDED.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.SUSPENDED.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  public void saveStateOnboardingPendingUser(IamUserConfiguration iamUserConfiguration) {
    setStateOnboardingPendingUser(iamUserConfiguration);
    iamUserConfigurationRepository.save(iamUserConfiguration);
  }

  public void savePasswordReset(Integer userId) {
    iamUserConfigurationRepository.findById(userId.longValue()).ifPresent(
        iamUserConfiguration -> {
          setStateReset(iamUserConfiguration);
          iamUserConfigurationRepository.save(iamUserConfiguration);
        }
    );
  }

  public void updateStateForDeletedOktaProfile(IamUserConfiguration iamUserConfiguration) {
    // NWPI-15109: same reasoning as updateStateFromOktaProfile - a retired account must keep its
    // 'decommissioned' state. This path runs when Okta returns 404, which is if anything further
    // confirmation the account is gone, so downgrading it to 'inactive'/Deleted only loses the fact
    // that the retirement was deliberate (and breaks the migration's sign-off check).
    if (UserStateEnum.DECOMMISSIONED.dbValue.equalsIgnoreCase(iamUserConfiguration.getState())) {
      return;
    }
    iamUserConfiguration.setState(UserStateEnum.INACTIVE.dbValue);
    iamUserConfiguration.setActive(false);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.DELETED.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.DELETED.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
    iamUserConfigurationRepository.save(iamUserConfiguration);
  }

  public void updateStateFromOktaProfile(IamUserConfiguration iamUserConfiguration, OktaUserProfile oktaUserProfile) {
    // NWPI-15109: a decommissioned account was deliberately retired (the employee migration's sunset
    // step). Okta can still report it ACTIVE, and both branches below then map that back to an
    // enabled state, so syncing would silently resurrect a retired account on any read. Only
    // setStateDecommissioned writes this state - suspended and locked-out users are 'inactive' - so
    // this cannot swallow a legitimate status change. Re-activation must go through an explicit
    // re-provisioning flow, not an Okta sync.
    if (UserStateEnum.DECOMMISSIONED.dbValue.equalsIgnoreCase(iamUserConfiguration.getState())) {
      log.info("Skipping okta state sync for decommissioned user {}: okta status {}",
          iamUserConfiguration.getIdpSubject(), oktaUserProfile.getStatus());
      return;
    }
    IamUserConfiguration iamUserConfigurationOriginal = IamUserConfiguration.builder().build();
    BeanUtils.copyProperties(iamUserConfiguration, iamUserConfigurationOriginal);
    if(iamUserConfiguration.getIdp()!=null && !iamUserConfiguration.getIdp().equalsIgnoreCase(Constants.CPX_IDP)){
      // Temporary fix for sso users
      log.info("sso user idpSubject: {} oktastatus: {}",iamUserConfiguration.getIdpSubject(), oktaUserProfile.getStatus());
      if( Constants.IDP_STATUS_ACTIVE.equals(oktaUserProfile.getStatus())) {
        setStateActive(iamUserConfiguration);
      } else {
        setStateSuspended(iamUserConfiguration);
      }
    } else {
      log.info("Syncing okta profile for user : {} : {} ", iamUserConfiguration.getIdpSubject(), iamUserConfiguration.getIdpUserIdentifier());

      switch (oktaUserProfile.getStatus()) {
        case Constants.IDP_STATUS_PASSWORD_EXPIRED -> {  // PASSWORD_EXPIRED
          if (oktaUserProfile.getCredentials().getRecoveryQuestion() == null) { // Recovery question is null, so user has not completed onboarding
            OktaFactor[] factors = oktaUserProfile.getFactors();
            if (isEmptyFactor(factors)) { // No factors set so, temporary password is active
              setStateOnboardingStaged(iamUserConfiguration);
            } else if (hasSmsInactive(factors)) { // Has added a 2fa, but not activated it
              setState2FaPendingUser(iamUserConfiguration);
            } else if (hasSmsActive(factors)) { // Has activated the 2fa, but has not reset the temporary password
              setStatePasswordPendingUser(iamUserConfiguration);
            } else { // Should not arrive here
              log.warn("WARNING: Unknown user profile status detected! Setting into 'onboarding'");
              setStateOnboardingStaged(iamUserConfiguration);
            }
          } else { // Recovery question has been set which means user has completed onboarding. Password has expired due to non use
            setStatePasswordExpired(iamUserConfiguration);
          }
        }
        case Constants.IDP_STATUS_ACTIVE -> { // ACTIVE in IDP
          // Recovery question is null but status is active, so user has reset temporary password but
          // not completed onboarding
          if (oktaUserProfile.getCredentials().getRecoveryQuestion() == null) {
            setStateOnboardingPendingUser(iamUserConfiguration);
          } else { // Recovery question is set
            OktaFactor[] factors = oktaUserProfile.getFactors();
            if (isEmptyFactor(factors) || hasSmsInactive(factors)) { // User's sms is reset
              setStateReset(iamUserConfiguration);
            } else { // User is fully active
              setStateActive(iamUserConfiguration);
            }
          }
        }
        case Constants.IDP_STATUS_SUSPENDED -> // Suspended profile in IDP
            setStateSuspended(iamUserConfiguration);
        case Constants.IDP_STATUS_LOCKED_OUT -> // User has been locked out
            setStateLockedOut(iamUserConfiguration);
        case Constants.IDP_STATUS_DEPROVISIONED, Constants.IDP_STATUS_DECOMMISSIONED ->
            // The only genuinely terminal Okta statuses.
            setStateDecommissioned(iamUserConfiguration);
        default ->
            // Okta also reports STAGED / PROVISIONED / RECOVERY, which are transient - RECOVERY is
            // simply a password reset in progress. Decommissioning on those used to self-heal on the
            // next sync, but decommissioned is now sticky (NWPI-15109), so it would brick a live
            // user. Leave the state alone and let the next sync classify it.
            log.warn("Unhandled okta status {} for user {} - leaving state {} unchanged",
                oktaUserProfile.getStatus(), iamUserConfiguration.getIdpSubject(),
                iamUserConfiguration.getState());
      }
    }
    if (isStateChanged(iamUserConfigurationOriginal, iamUserConfiguration)) {
      iamUserConfigurationRepository.save(iamUserConfiguration);
      userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(false);
    }
  }

  private boolean isStateChanged(IamUserConfiguration before, IamUserConfiguration after) {
    return
        !before.getState().equals(after.getState()) ||
            !before.getActive().equals(after.getActive()) ||
            !before.getStateDescription().equals(after.getStateDescription()) ||
            !before.getStateAction().equals(after.getStateAction());
  }

  boolean hasSmsInactive(OktaFactor[] oktaFactors) {
    if (isEmptyFactor(oktaFactors)) {
      return true;
    }
    return
        Arrays.stream(oktaFactors)
            .anyMatch(oktaFactor ->
                Constants.SMS.equals(oktaFactor.getFactorType())
                    && !(Constants.IDP_STATUS_ACTIVE.equals(oktaFactor.getStatus())
                    || Constants.IDP_STATUS_PENDING_ACTIVATION.equals(oktaFactor.getStatus()))
            );
  }

  private boolean hasSmsActive(OktaFactor[] oktaFactors) {
    if (isEmptyFactor(oktaFactors)) {
      return true;
    }
    return
        Arrays.stream(oktaFactors)
            .anyMatch(oktaFactor ->
                Constants.SMS.equals(oktaFactor.getFactorType())
                    && Constants.IDP_STATUS_ACTIVE.equals(oktaFactor.getStatus())
            );
  }

  public boolean isEmptyFactor(OktaFactor[] factors) {
    return factors == null || factors.length < 1;
  }
}
