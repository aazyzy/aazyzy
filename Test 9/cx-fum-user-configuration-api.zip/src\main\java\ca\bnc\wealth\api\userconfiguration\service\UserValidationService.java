package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.UserConfigUtils;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.fum.service.FeaturePackageServiceHelper;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserValidationService {

  @Value("${platform.env:#{null}}")
  protected String env;

  private final R2Service r2Service;
  private final UserService userService;
  private final IamUserConfigurationRepository iamUserConfigurationRepository;
  private final FirmRepository firmRepository;
  private final FeaturePackageServiceHelper featurePackageServiceHelper;

  public void validateUserConfigurationUpdate(
      UserConfiguration currentUserConfiguration, UserConfiguration newUserConfiguration) {
    // Avoiding email already exist check if email is the same
    if (currentUserConfiguration.getEmail().equalsIgnoreCase(newUserConfiguration.getEmail())) {
      newUserConfiguration.setEmail(null);
    }
    // Avoiding username already exist check if username is the same
    if (currentUserConfiguration
        .getUsername()
        .equalsIgnoreCase(newUserConfiguration.getUsername())) {
      newUserConfiguration.setUsername(null);
    }
    Map<String, String> validationError = validateUser(newUserConfiguration);

    String email = newUserConfiguration.getEmail();
    if (StringUtils.isNotBlank(email) && !UserConfigUtils.validateEmail(email)) {
      validationError.put(Constants.EMAIL, Constants.ERROR_EMAIL_INVALID_FORMAT);
    }

    if (!validationError.isEmpty()) {
      String errorCode =
          validationError.entrySet().stream().findFirst().map(Map.Entry::getValue).orElse("");
      throw new FumServiceException(errorCode, Constants.ERROR_DEFAULTMESSAGE_UPDATE_USER);
    }

    if (StringUtils.isNotBlank(newUserConfiguration.getCompassR2Id())) {
      Pair<Boolean, String> r2validation = r2Service.r2ValidationForUpdateUser(newUserConfiguration.getCompassR2Id(), newUserConfiguration.getIdpSubject());
      if (!r2validation.getKey()) {
        log.error("R2 Validation failed with error:" + r2validation.getValue());
        throw new FumServiceException(Constants.ERROR_R2_NOT_FOUND, r2validation.getValue());
      }
    }


  }

  public void validateBngfReferenceId(
      UserConfiguration userConfiguration, Map<String, String> response) {
    if (userConfiguration.getExternalClientId() != null) {
      String bngfReferenceId =
          userService.generateBngfReferenceId(
              userConfiguration.getFirmId(), userConfiguration.getExternalClientId());
      Optional.of(bngfReferenceId)
          .flatMap(iamUserConfigurationRepository::findFirstByBngfReferenceId)
          .ifPresent(
              username -> { // If the new user profile is not same as the existing user profile but
                // their bngfRef ids match, then throw error
                if (username.getIdpUserIdentifier() != null
                    && !username.getIdpUserIdentifier().equals(userConfiguration.getIdpUserId())) {
                  response.put(
                      Constants.BNGF_REFERENCE_ID, Constants.ERROR_BNGF_REFERENCE_ID_EXIST);
                } else if (userConfiguration.getIdpUserId()
                    == null) { // It's a new user with a duplicated bngfRef id, throw error
                  response.put(
                      Constants.BNGF_REFERENCE_ID, Constants.ERROR_BNGF_REFERENCE_ID_EXIST);
                }
              });
    }
  }

  public Map<String, String> validateUser(UserConfiguration userConfiguration) {
    Map<String, String> response = new HashMap<>();
    validateBngfReferenceId(userConfiguration, response);

    Optional.ofNullable(userConfiguration.getUsername())
        .flatMap(iamUserConfigurationRepository::findFirstByUsernameIgnoreCase)
        .ifPresent(username -> response.put(Constants.USERNAME, Constants.ERROR_USERNAME_EXIST));

    Optional.ofNullable(userConfiguration.getFeaturePackage())
        .ifPresent(
            featurePackage -> {
              if (StringUtils.isNotBlank(featurePackage.getPackageName())) {
                return;
              }
              Optional.ofNullable(featurePackage.getPackageTemplateId())
                  .ifPresentOrElse(
                      packageTemplateId -> {
                        if (packageTemplateId < 1) {
                          response.put(
                              Constants.FEATURE_PACKAGE, Constants.ERROR_INVALID_FEATURE_PACKAGE);
                        }
                      },
                      () ->
                          response.put(
                              Constants.FEATURE_PACKAGE, Constants.ERROR_INVALID_FEATURE_PACKAGE));
            });

    if (!userService.isValidFirmId(userConfiguration.getFirmId())) {
      log.error("Firm Id provided is not valid");
      response.put(Constants.FIRM_ID, Constants.ERROR_FIRMID_INVALID);
    }

    if (!userService.validRrCodeRangeForFirmId(
        userConfiguration.getFirmId(),
        userConfiguration.getRrCodes(),
        userConfiguration.getRrCodeRanges())) {
      log.error("Some of provided user rrcode are not in firm rrcode range");
      response.put(Constants.RR_CODES, Constants.ERROR_RRCODE_INVALID); // "RR code are invalid"
    }

    String hashedPassword = userConfiguration.getHashedPassword();
    if (StringUtils.isNotBlank(hashedPassword)
        && !Pattern.matches(Constants.BCRYPT_HASH_REGEX, hashedPassword)) {
      log.error("Hashed password provided is not in the correct format");
      response.put(Constants.HASHED_PASSWORD, Constants.ERROR_HASHED_PASSWORD_INVALID);
    }

    if (StringUtils.isNotBlank(userConfiguration.getPreferredLanguage())
        && !isSupportedLanguage(userConfiguration.getPreferredLanguage())) {
      log.error("Preferred language provided is not valid");
      response.put(Constants.PREFERRED_LANGUAGE, Constants.ERROR_PREFERREDLANGUAGE_INVALID);
    }

    if(!UserConfigUtils.validUserPreferences(userConfiguration.getUserPreferences())) {
      response.put(Constants.USER_PREFERENCES, Constants.ERROR_USER_PREFERENCES_INVALID);
    }

    return response;
  }

  private boolean isSupportedLanguage(String lang) {
    for (PreferredLanguageType languageType : PreferredLanguageType.values()) {
      if (languageType.name().equalsIgnoreCase(lang)) {
        return true;
      }
    }
    return false;
  }


  public boolean isExternalSSOEnabled(UserConfiguration userConfiguration) {
    // If externalClientId is not set, no need to check for SSO
    if (userConfiguration.getExternalClientId() == null) {
      return true;
    }

    return Optional.of(firmRepository.findByFirmId(userConfiguration.getFirmId()))
        .map(
            firm -> {
              if (firm.getIdentitySource() == null
                  || Constants.CXP_IDENTITY_SOURCE.equals(firm.getIdentitySource())) {
                log.info("SSO is not enabled for the firm {}", userConfiguration.getFirmId());
                return false;
              }
              return true;
            })
        .orElse(false);
  }
}
