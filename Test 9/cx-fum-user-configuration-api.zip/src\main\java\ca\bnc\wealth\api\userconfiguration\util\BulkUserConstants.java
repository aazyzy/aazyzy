package ca.bnc.wealth.api.userconfiguration.util;

public class BulkUserConstants {

  public static final String ROW_NUMBER = "row-number";
  public static final String CURRENT_FIRM = "current-firm";
  public static final String CURRENT_USER = "current-user";
  public static final String REQUEST_ID = "requestedId";
  public static final String FIRM_ID = "Firm*";
  public static final String FIRST_NAME = "First Name*";
  public static final String LAST_NAME = "Last Name*";
  public static final String EMAIL_ADDRESS = "Email Address*";
  public static final String PREFERRED_LANGUAGE = "Preferred Language*";
  public static final String DEFAULT_MODULE =  "Default Module";
  public static final String USER_NAME = "User ID*";
  public static final String SECURE_ZONE_ID ="SecureZone ID";
  public static final String OSS_USER_ID = "OSS User ID";
  public static final String COMPASS_R2_ID ="CR2 User ID";
  public static final String EXTERNAL_CLIENT_ID ="SSO User ID";
  public static final String ROLES = "Role*";
  public static final String FIRM_LEVEL_ACCESS = "Firm Level Access*";
  public static final String RR_CODES = "RR Code Assignment";
  public static final String MODULE_OVERRIDES = "Module Overrides";
  public static final String FEATURES = "Features";


  public static final String USER_NAME_NOT_FOUND = "User ID*: %s not found";
  public static final String USER_NAME_NOT_FOUND_ERROR_CODE = "error.username.not.found";

  public static final String USER_UPDATE_ERROR = "error.update.user.configuration";

  public static final String ERROR_CROSS_FIRM_UPDATE = "error.cross.firm.update";
  public static final String ERROR_CROSS_FIRM_UPDATE_MESSAGE = "Cross-firm user modification is not permitted";

  public static final String ERROR_EMAIL_INVALID_FORMAT = "error.email.invalid.format";
  public static final String ERROR_EMAIL_INVALID_FORMAT_MESSAGE = "Email Address* is not in valid format";

  public static final String ERROR_RRCODE_INVALID = "error.rrcode.invalid";
  public static final String ERROR_RRCODE_INVALID_MESSAGE = "RR code are invalid";

  public static final String ERROR_R2_NOT_FOUND = "error.r2.notfound";
  public static final String ERROR_R2_NOT_FOUND_MESSAGE = "CR2 User ID not found";

  public static final String ERROR_OSS_ID_NULL = "error.ossId.null";
  public static final String ERROR_OSS_ID_NULL_MESSAGE = "OSS ID is required for CX Trading Product feature package";

  public static final String ERROR_FIRM_BMA_IN_PROGRESS = "error.firm.bma.in.progress";
  public static final String ERROR_FIRM_BMA_IN_PROGRESS_MESSAGE = "Bulk user update is not allowed while a feature package assignment is in progress for the firm";

  public static final String FIRM_FEATURE_PACKAGE_ASSIGNMENT_BATCH_ID = "FEATURE_PACKAGE_ASSIGNMENT_BATCH_ID";

  private BulkUserConstants() {
    throw new IllegalStateException("Utility class");
  }
}
