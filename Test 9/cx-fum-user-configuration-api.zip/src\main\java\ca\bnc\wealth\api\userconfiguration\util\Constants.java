package ca.bnc.wealth.api.userconfiguration.util;

import java.util.List;

public class Constants {

  public static final String EMAIL = "email";
  public static final String USERNAME = "username";
  public static final String BNGF_REFERENCE_ID = "bngfReferenceId";
  public static final String HASHED_PASSWORD = "hashedPassword";
  public static final String PREFERRED_LANGUAGE = "preferredLanguage";
  public static final String COMPASS_R2_ID = "compassR2Id";
  public static final String OSS_ID = "ossId";
  public static final String OKTA_PROFILE = "oktaProfile";
  public static final String EXTERNAL_CLIENT_ID = "externalClientId";
  public static final String FIRM_ID = "firmId";
  public static final String FIRM_ENTITY_ID = "firmEntityId";
  public static final String RR_CODES = "rrCodes";
  public static final String IDP_STATUS_PASSWORD_EXPIRED = "PASSWORD_EXPIRED";
  public static final String IDP_STATUS_ACTIVE = "ACTIVE";
  public static final String IDP_STATUS_LOCKED_OUT = "LOCKED_OUT";
  public static final String IDP_STATUS_SUSPENDED = "SUSPENDED";
  public static final String IDP_STATUS_DECOMMISSIONED = "DECOMMISSIONED";
  public static final String IDP_STATUS_DEPROVISIONED = "DEPROVISIONED";
  public static final String IDP_STATUS_PENDING_ACTIVATION = "PENDING_ACTIVATION";
  public static final String CXP_SUB_STATE_2FA_PENDING = "2FAPending";
  public static final String CXP_SUB_STATE_2FA_ACTIVE = "2FAActive";
  public static final String CXP_SUB_STATE_RECOVERY_QUESTION_PENDING = "RecoveryQuestionPending";
  public static final String CXP_SUB_STATE_CREATED = "Created";
  public static final String CXP_SUB_STATE_ACTIVE = "Active";
  public static final String CXP_SUB_STATE_DISABLED = "Disabled";
  public static final String CXP_SUB_STATE_2FA_RESET = "2FAReset";
  public static final String CXP_SUB_STATE_LOCKED_OUT = "LockedOut";
  public static final String CXP_SUB_STATE_PASSWORD_EXPIRED = "PasswordExpired";
  public static final String CXP_SUB_STATE_SUSPENDED = "Suspended";
  public static final String CXP_STATE_ONBOARDING = "Onboarding";
  public static final String CXP_STATE_ACTIVE = "Active";
  public static final String CXP_STATE_INACTIVE = "Inactive";
  public static final String CXP_STATE_LOCKED_OUT = "Locked Out";
  public static final String SMS = "sms";
  public static final String ASSIGNMENT_TYPE_FEATURE_PACKAGE = "P";
  public static final String SYSTEM_TOKEN_FUM = "fum";
  public static final String FIRM_LEVEL_ACCESS_RESOURCE = "firm_level_access";
  public static final String CXP_IDENTITY_SOURCE = "cpx";
  public static final String IDP_SUBJECT_SEPARATOR = "_";
  public static final String USER_PREFERENCES = "userPreferences";

  public static final String REDIS_USER_RESOURCE_ASSIGNMENTS_BY_RESOURCE_TYPE = "Authorization-API-GetResources-By-ResourceType-IdpSubject";

  public static final String DWH_IDP = "nbc";
  public static final String CPX_IDP = "nbin";
  // Employee (internal) users authenticate via the IAMi tenant and have no Okta/CIAM
  // profile, so their IDP_USER_ID is null and CIAM calls must be skipped for them.
  public static final String EMPLOYEE_IDP = "IAMi";
  public static final String SSO_NOMFA_USER_GROUP ="Wealth.ExternalUsers.NoMFA";
  // Granted in Okta to a secondary account whose email is also held by an employee (IAMi)
  // account. Employee accounts have no Okta profile, so the group only ever lands on the
  // secondary one.
  public static final String EMPLOYEE_EXTERNAL_USER_GROUP = "Wealth.CompassX.employee.external";
  public static final List<String> SKIP_CLONE_FIELDS =  List.of(
            "userConfigurationId",
                    "idpUserId",
                    "idpSubject",
                    "username",
                    "sourceIdpSubject",
                    "email",
                    "activationDate",
                    "bngfReferenceId");

  public static final String ERROR_CODE_SEARCH_USER = "error.search.user";
  public static final String ERROR_DEFALUTMESSAGE_SEARCH_USER = "Error in searching user.";
  public static final String ERROR_CODE_GENERIC_SEARCH_USER = "error.generic.search.user";
  public static final String ERROR_DEFAULTMESSAGE_GENERIC_SEARCH_USER = "Error in generic search user";
  public static final String ERROR_CODE_UPDATE_USER = "error.update.user";
  public static final String ERROR_DEFAULTMESSAGE_UPDATE_USER = "Error in updating user.";
  public static final String ERROR_CODE_CREATE_USER_VALIDATION = "error.create.user.validation";
  public static final String ERROR_CODE_CREATE_USER = "error.create.user";
  public static final String ERROR_DEFAULTMESSAGE_CREATE_USER_VALIDATION = "Error in create user validation";
  public static final String ERROR_USERNAME_EXIST = "error.username.exist";
  public static final String ERROR_USER_ALREADY_EXISTS = "User already exists";
  public static final String ERROR_BNGF_REFERENCE_ID_EXIST = "error.bngfReferenceId.exist";
  public static final String ERROR_USERGROUP_INVALID = "error.userGroup.role.invalid";
  public static final String ERROR_RRCODE_INVALID = "error.rrcode.invalid";
  public static final String ERROR_HASHED_PASSWORD_INVALID = "error.hashedPassword.invalid";
  public static final String ERROR_PREFERREDLANGUAGE_INVALID = "error.preferredLanguage.invalid";
  public static final String ERROR_PREFERREDLANGUAGE_NULL = "error.preferredLanguage.null";
  public static final String ERROR_NBXUSERCONFIGURATION_NULL = "error.nbxUserConfiguration.null";
  public static final String ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS = "error.restrictClientDataAccessAndFirmLevelAccess";
  public static final String ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS_MESSAGE = "This role does not allow access to client data ( Firm level access not allowed for this role)";
  public static final String ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE = "error.restrictClientDataAccessAndRRCode";
  public static final String ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE_MESSAGE = "This role does not allow access to client data ( RR Code assignments not allowed for this role)";
  public static final String ERROR_FIRSTNAME_INVALID = "error.firstName.invalid";
  public static final String ERROR_FIRSTNAME_NULL = "error.firstName.null";
  public static final String ERROR_LASTNAME_INVALID = "error.lastName.invalid";
  public static final String ERROR_LASTNAME_NULL = "error.lastName.null";
  public static final String ERROR_EMAIL_NULL = "error.email.null";
  public static final String ERROR_EMAIL_INVALID_FORMAT = "error.email.invalid.format";
  public static final String ERROR_FIRMID_INVALID = "error.firmId.invalid";
  public static final String ERROR_NOT_SSO_ENABLED_FIRM = "error.firmId.notSSOEnabled";
  public static final String ERROR_USER_PREFERENCES_INVALID = "error.userPreferences.invalid";
  public static final String ERROR_OSS_ID_NULL = "error.ossId.null";

  public static final String ERROR_UPDATE_IDPUSERIDENTIFIER_NOT_SYSTEMTOKEN = "Only system users can update IdpUserIdentifier.";
  public static final String ERROR_UPDATE_IDPUSERIDENTIFIER_WRONG_USERNAME = "New IdpUserIdentifier is wrong.";
  // BCRYPT hashed password format: $2<a/b/x/y>$[cost 1 to 20]$[22 character salt][31 character hash]
  // Group 1: Algorithm, Group 2: Work factor, Group 3: Salt, Group 4: Hash value
  public static final String BCRYPT_HASH_REGEX = "^([$]2[abxy][$])(0[1-9]|1[0-9]|20)[$]([.\\/A-Za-z0-9]{22})([.\\/A-Za-z0-9]{31})$";
  public static final String HASH_ALGORITHM = "BCRYPT";
  public static final String HASH_SALT_ORDER = "PREFIX";
  public static final String ERROR_R2_NOT_FOUND = "error.r2.notfound";
  public static final String ERROR_R2_WITH_CPX_SUB = "error.r2.withcpxsub";
  public static final String ERROR_R2_EXCEPTION = "error.r2.exception";
  public static final String ERROR_R2_NOT_MATCHED = "error.r2.notmatched";
  public static final String ERROR_R2_ID_REQUIRED_CODE = "error.r2.id.required";
  public static final String ERROR_R2_ID_REQUIRED_MESSAGE = "compassR2Id is required to link an R2 id";
  public static final String ERROR_OKTA_PROFILE_FOUND = "error.okta.profile.found";
  public static final String ERROR_PROFILE_CREATION = "error.profile.creation";
  public static final String ERROR_OKTA_PROFILE_CREATION = "error.okta.profile.creation";
  public static final String ERROR_OKTA_PROFILE_HASH_CREATION_MESSAGE = "Error creating user with hashed password in Okta";  public static final String ERROR_OKTA_PROFILE_SYNC = "error.okta.profile.sync";
  public static final String ERROR_UPDATE_USER_STATUS_INPUT_CODE = "error.updateUsrStatus.status.null";
  public static final String ERROR_UPDATE_USER_STATUS_INPUT_MESSAGE = "User status is not provided";
  public static final String ERROR_USER_NOT_FOUND_CODE = "error.user.notFound";
  public static final String ERROR_USER_NOT_FOUND_MESSAGE = "User %s was not found";
  public static final String ERROR_OKTA_USER_NOT_FOUND_MESSAGE = "User %s profile was not found in Okta";

  public static final String ERROR_USER_STATE_UPDATE_NOT_IMPLEMENTED_CODE = "error.user.state.update.notImplemented";
  public static final String ERROR_USER_STATE_UPDATE_NOT_IMPLEMENTED_MESSAGE = "User state %s update is not implemented";
  public static final String ERROR_USER_NO_FIRM = "No firms associated to user %s";
  public static final String ERROR_USER_UPDATE_CODE = "error.user.update";
  public static final String ERROR_USER_UPDATE_MESSAGE = "Can't update idpsubject for non nbin user";
  public static final String ERROR_USER_NOT_ACTIVE_CODE = "error.user.not.active";
  public static final String ERROR_USER_NOT_ACTIVE_MESSAGE = "User %s is not active";
  public static final String ERROR_USER_NOT_SUSPENDED_CODE = "error.user.not.suspended";
  public static final String ERROR_USER_NOT_SUSPENDED_MESSAGE = "User %s is not suspended/inactive";
  public static final String ERROR_ASSIGNEE_NULL = "error.assignee.null";
  public static final String ERROR_ASSIGNEE_ID_INVALID = "error.assigneeID.invalid";
  public static final String ERROR_RR_RANGES_NULL = "error.rr.ranges.null";
  public static final String ERROR_RR_RANGES_INVALID = "error.rr.ranges.invalid";
  public static final String ERROR_ASSIGNMENT_TYPE_INVALID = "error.assignment.type.invalid";
  public static final String ERROR_ASSIGNMENT_TYPE_NULL = "error.assignment.type.null";
  public static final String ERROR_FIRM_NOT_FOUND_CODE = "error.firm.notFound";
  public static final String ERROR_FIRM_NOT_FOUND_MESSAGE = "Firm %s was not found or not active";
  public static final String ERROR_INVALID_RESOURCE_NAME = "Invalid Resource Name";

  public static final String ERROR_INVALID_FEATURE_PACKAGE = "error.feature.package.invalid";
  public static final String FEATURE_PACKAGE = "featurePackage";
  public static final String ERROR_FEATURE_PACKAGE_NULL = "error.featurePackage.null";
  public static final String ERROR_FEATURE_PACKAGE_CREATE_FAILED = "Create feature package failed";
  public static final String ERROR_IDP_SUBJECT_NULL = "error.idpSubject.null";
  public static final String ERROR_IDP_USER_ID_NULL = "error.idpUserId.null";
  public static final String ERROR_IDP_USER_NAME_NULL = "error.username.null";
  public static final String ERROR_RECOVERY_QUESTIONS_NOT_FOUND_CODE = "error.recoveryQuestions.notFound";
  public static final String ERROR_RECOVERY_QUESTIONS_NOT_FOUND_MESSAGE = "Recovery questions not found for language %s";
  public static final String DEFAULT_ACTIVATION_DATE = "9999-09-09T00:00:00.000000";
  public static final String DEFAULT_IDENTIFY_LAST_UPDATED_DATE = "1970-01-01T00:00:00.000000";
  public static final String RESOURCE_TYPE_DATA_ACCESS="data_access";
  public static final String RESOURCE_NAME_FIRM_LEVEL_ACCESS="firm_level_access";
  public static final String RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS="restrict_client_data_access";
  public static final String ERROR_NOT_NBX_USER_CODE = "error.user.not.nbx.user";
  public static final String ERROR_NOT_NBX_USER_MESSAGE = "User %s is not an nbx user";
  public static final String ERROR_EXTERNAL_ID_EMPTY = "error.userExternalId.null";
  public static final String ERROR_EXTERNAL_ID_EMPTY_MESSAGE = "userExternalId is null or empty";
  public static final String ERROR_EXTERNAL_ID_NOT_SUPPORTED = "error.externalSystemId.notSupported";
  public static final String ERROR_EXTERNAL_ID_NOT_SUPPORTED_MESSAGE = "externalSystemId %s is not supported";
  public static final String ERROR_USER_TYPE_NOT_SUPPORTED =  "error.userType.notSupported";
  public static final String ERROR_USER_TYPE_NOT_SUPPORTED_MESSAGE = "userType %s is not supported";
  public static final String ERROR_SZ_ASSIGN_CALL_4xx =  "error.secureZone.externalSystemId";
  public static final String ERROR_SZ_ASSIGN_CALL_4xx_MESSAGE = "Invalid externalSystemId %s in SecureZone";
  public static final String ERROR_SZ_ASSIGN_CALL_5xx =  "error.secureZone.assign";
  public static final String ERROR_SZ_ASSIGN_CALL_5xx_MESSAGE = "Unable to assign szId %s to user %s in SecureZone";
  /** Sentinel username PATCHed to UAMA to release an szId from its current user. */
  public static final String SZ_UNASSIGNED_IDP_SUBJECT = "null";
  public static final String ERROR_SZ_GET_USER_CALL_4xx =  "error.secureZone.externalUserId";
  public static final String ERROR_SZ_GET_USER_CALL_4xx_MESSAGE = "Invalid externalUserId %s in SecureZone";
  public static final String ERROR_SZ_GET_USER_CALL_5xx =  "error.secureZone.getUser";
  public static final String ERROR_SZ_GET_USER_CALL_5xx_MESSAGE = "Unable to get user with szId %s in SecureZone";
  public static final String ERROR_SZ_GET_USER_SEARCH_CALL_4xx_MESSAGE = "Invalid username %s in SecureZone";
  public static final String ERROR_SZ_GET_USER_SEARCH_CALL_5xx_MESSAGE = "Unable to get user with username %s in SecureZone";
  public static final String ERROR_SZ_UPDATE_CALL_4xx =  "error.secureZone.update.externalUserId";
  public static final String ERROR_SZ_UPDATE_CALL_4xx_MESSAGE = "Invalid szId %s in SecureZone";
  public static final String ERROR_SZ_UPDATE_CALL_5xx =  "error.secureZone.update";
  public static final String ERROR_SZ_UPDATE_CALL_5xx_MESSAGE = "Unable to update user with szId %s in SecureZone";
  public static final String GET_FIRM_BY_USER_QUERY = """
  select
    distinct f1_0."FIRM_ENTITY_ID",
    f1_0."ACTIVE",
    f1_0."FIRM_ID",
    f1_0."CREATED_BY",
    f1_0."CREATION_DATE",
    f1_0."DESCRIPTION",
    f1_0."FINANCIAL_ENTITY_ID",
    f1_0."TYPE",
    f1_0."LAST_UPDATE_DATE",
    f1_0."LAST_UPDATED_BY",
    f1_0."NAME",
    f1_0."PARENT_FIRM_ID",
    f1_0."PREFERRED_LANGUAGE",
    f1_0."STATE",
    f1_0."STATUS_LAST_UPDATED"
  from
    "IAM_V2"."FIRM" f1_0
  join
    "IAM_V2"."USER_ASSIGNMENT" u1_0
        on f1_0."FIRM_ENTITY_ID"=u1_0."ASSIGNEE_ID"
  join
    "IAM_V2"."USER_CONFIGURATION" u2_0
        on u2_0."IDP_SUBJECT"=u1_0."IDP_SUBJECT"
  where
    u1_0."IDP_SUBJECT"= :idpSubject
    and cast(u1_0."ASSIGNMENT_TYPE" as text)= :assignmentType
  """;
  public static final String GET_FIRM_BY_ID_QUERY = """
  select
    distinct f1_0."FIRM_ENTITY_ID",
    f1_0."ACTIVE",
    f1_0."FIRM_ID",
    f1_0."CREATED_BY",
    f1_0."CREATION_DATE",
    f1_0."DESCRIPTION",
    f1_0."FINANCIAL_ENTITY_ID",
    f1_0."TYPE",
    f1_0."LAST_UPDATE_DATE",
    f1_0."LAST_UPDATED_BY",
    f1_0."NAME",
    f1_0."PARENT_FIRM_ID",
    f1_0."PREFERRED_LANGUAGE",
    f1_0."STATE",
    f1_0."STATUS_LAST_UPDATED"
  from
    "IAM_V2"."FIRM" f1_0
  where
    f1_0."FIRM_ID"= :firmId
  """;
  public static final String GET_RRCODE_BY_USER_QUERY = """
  select
    i1_0."RR_CODE_RANGE_ID",
    i1_0."ACTIVE",
    i1_0."CREATED_BY",
    i1_0."CREATION_DATE",
    i1_0."FROM_RR_CODE",
    i1_0."FROM_RR_CODE_B10",
    i1_0."LAST_UPDATE_DATE",
    i1_0."LAST_UPDATED_BY",
    i1_0."TO_RR_CODE",
    i1_0."TO_RR_CODE_B10"
  from
    "IAM_V2"."RR_CODE_RANGE" i1_0
  join
    "IAM_V2"."USER_ASSIGNMENT" u1_0
        on i1_0."RR_CODE_RANGE_ID"=u1_0."ASSIGNEE_ID"
  join
    "IAM_V2"."USER_CONFIGURATION" u2_0
        on u2_0."IDP_SUBJECT"=u1_0."IDP_SUBJECT"
  where
    i1_0."ACTIVE"= :active
    and u1_0."IDP_SUBJECT"= :idpSubject
    and cast(u1_0."ASSIGNMENT_TYPE" as text)= :assignmentType
  """;
  public static final String GET_USER_BY_USERNAME_QUERY = """
  select
    i1_0."USER_CONFIGURATION_ID",
    i1_0."ACTIVE",
    i1_0."CREATED_BY",
    i1_0."CREATION_DATE",
    i1_0."EMAIL",
    i1_0."FIRST_NAME",
    i1_0."IDP_SUBJECT",
    i1_0."IDP_USER_ID",
    i1_0."LAST_NAME",
    i1_0."LAST_UPDATE_DATE",
    i1_0."LAST_UPDATED_BY",
    i1_0."OSS_GROUP_ID",
    i1_0."OSS_USER_ID",
    i1_0."PREFERRED_CX_UI_MODULE",
    i1_0."PREFERRED_LANGUAGE",
    i1_0."PROFILE_LAST_UPDATED",
    i1_0."STATE",
    i1_0."STATE_ACTION",
    i1_0."STATE_DESCRIPTION",
    i1_0."STATUS_LAST_UPDATED",
    i1_0."USERNAME"
  from
    "IAM_V2"."USER_CONFIGURATION" i1_0
  where
    lower(cast(i1_0."USERNAME" as text)) like :username escape ''
  """;

  public static final String GET_RECOVERY_QUESTIONS_BY_LANGUAGE_QUERY = """
  select
    i1_0."CONTENT_TRANSLATION_ID",
    i1_0."CREATED_BY",
    i1_0."CREATED_DT",
    i1_0."UPDATED_DT",
    i1_0."UPDATED_BY",
    i1_0."LANGUAGE",
    i1_0."TRANSLATION_KEY",
    i1_0."TRANSLATION_VALUE"
  from
    "IAM_V2"."CONTENT_TRANSLATION" i1_0
  where
    cast(i1_0."LANGUAGE" as text) = :language
  """;

  public static final String GET_USER_LAST_UPDATE_DATE_BY_IDP_SUBJECT_QUERY = """
  select
    i1_0."LAST_UPDATE_DATE"
  from
    "IAM_V2"."USER_CONFIGURATION" i1_0
  where
    i1_0."IDP_SUBJECT" = :idpSubject
  """;

  public static final String GET_USER_FROM_MV_BY_IDP_SUBJECT_QUERY = """
  select *
  from
    "IAM_V2"."USER_CONFIGURATION_LIVE" ucm
  where
    ucm."IDP_SUBJECT" = :idpSubject
  """;

  public static final String GET_USER_FROM_MV_BY_CONF_ID_QUERY = """
  select *
  from
    "IAM_V2"."USER_CONFIGURATION_LIVE" ucm
  where
    ucm."USER_CONFIGURATION_ID" = :userConfigurationId
  """;

  public static final String OPERATION_NOT_SUPPORTED = "Operation not supported.";
  public static final List<String> SSO_ACCOUNTS = List.of("indall", "sunlif");

  private Constants() {
    throw new IllegalStateException("Utility class");
  }
}
