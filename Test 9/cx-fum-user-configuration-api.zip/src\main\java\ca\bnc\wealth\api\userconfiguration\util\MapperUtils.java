package ca.bnc.wealth.api.userconfiguration.util;

import ca.bnc.wealth.api.userconfiguration.model.UserData;
import ca.bnc.wealth.api.userconfiguration.model.state.UserStatusEnum;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamContentTranslation;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import ca.bnc.wealth.common.jpa.entity.iam.UserGroup;
import ca.bnc.wealth.common.jpa.entity.platform.RrCodeRange;
import ca.bnc.wealth.common.jpa.entity.platform.UserGroupAssignment;
import ca.bnc.wealth.common.kafka.model.RrCodeRanges;
import ca.bnc.wealth.common.sz.model.SzUser;
import ca.bnc.wealth.common.sz.model.SzUserSearch;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.UamaUser;
import ca.bnc.wealth.common.userconfiguration.model.UamaUserSearchResponse;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration.RoleScopeTypeEnum;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import tools.jackson.core.JacksonException;

@Slf4j
public class MapperUtils {

  private MapperUtils() {
    throw new IllegalStateException("Utility class");
  }

  // Has to replace this method with mapstruct
  public static RRCodeRange toDto(RrCodeRange rrCodeRange) {
    RRCodeRange dto = new RRCodeRange();
    dto.setRrCodeRangeId((int) rrCodeRange.getRrCodeRangeId());
    dto.setFromRRCode(rrCodeRange.getFromRrCode());
    dto.setToRRCode(rrCodeRange.getToRrCode());
    dto.setFromRRCodeB10((int) rrCodeRange.getFromRrCodeB10());
    dto.setToRRCodeB10((int) rrCodeRange.getToRrCodeB10());
    dto.setCreatedBy(rrCodeRange.getCreatedBy());
    dto.setLastUpdatedBy(rrCodeRange.getLastUpdatedBy());
    dto.setCreationDate(
        rrCodeRange.getCreationDate() != null
            ? rrCodeRange.getCreationDate().toLocalDateTime()
            : null);
    dto.setLastUpdatedDate(
        rrCodeRange.getLastUpdateDate() != null
            ? rrCodeRange.getLastUpdateDate().toLocalDateTime()
            : null);
    return dto;
  }

  public static List<RRCodeRange> toDto(List<RrCodeRanges> rrCodeRanges) {
    List<RRCodeRange> lst = new ArrayList<>();
    Optional.ofNullable(rrCodeRanges).ifPresent(list -> list.forEach(r -> lst.add(toDto(r))));
    return lst;
  }

  public static RRCodeRange toDto(RrCodeRanges rrCodeRange) {
    RRCodeRange rr = new RRCodeRange();
    rr.setFromRRCode(rrCodeRange.getFromRRCode());
    rr.setToRRCode(rrCodeRange.getToRRCode());
    return rr;
  }

  // Has to replace this method with mapstruct
  public static UserConfiguration toDto(
      ca.bnc.wealth.common.jpa.entity.platform.UserConfiguration entity) {
    UserConfiguration dto = new UserConfiguration();

    dto.setUserConfigurationId((int) entity.getUserConfigurationId());
    dto.setIdpUserId(entity.getIdpUserIdentifier());
    dto.setIdpSubject(entity.getIdpSubject());
    dto.setUsername(entity.getUsername());
    dto.setOssId(
        entity.getOssUserId()); // TODO To be removed after external dependencies are resolved
    dto.setOssProxyId(
        entity.getOssGroupId()); // TODO To be removed after external dependencies are resolved
    dto.setOssUserId(entity.getOssUserId());
    dto.setOssGroupId(entity.getOssGroupId());
    dto.setFirstName(entity.getFirstName());
    dto.setLastName(entity.getLastName());
    dto.setEmail(entity.getEmail());
    dto.setStatus(
        entity.getCodeValueMappingCxpStatusCode() != null
            ? entity.getCodeValueMappingCxpStatusCode().getCodeValue()
            : null);
    dto.setSubStatus(
        entity.getCodeValueMappingCxpSubStatusCode() != null
            ? entity.getCodeValueMappingCxpSubStatusCode().getCodeValue()
            : null);
    dto.setPreferredLanguage(
        entity.getCodeValueMapping() != null ? entity.getCodeValueMapping().getCodeValue() : null);
    dto.setActive(
        "Y".equalsIgnoreCase(entity.getActive())
            ? UserStatusEnum.ACTIVE.dbValue
            : UserStatusEnum.INACTIVE.dbValue);
    dto.setCreatedBy(entity.getCreatedBy());
    dto.setLastUpdatedBy(entity.getLastUpdatedBy());
    dto.setCreationDate(
        entity.getCreationDate() != null ? entity.getCreationDate().toLocalDateTime() : null);
    dto.setLastUpdatedDate(
        entity.getLastUpdateDate() != null ? entity.getLastUpdateDate().toLocalDateTime() : null);
    return dto;
  }

  public static UserConfiguration toDtoWithUserGroup(
      ca.bnc.wealth.common.jpa.entity.platform.UserConfiguration entity) {
    UserConfiguration dto = toDto(entity);
    if (entity.getUserGroupAssignments() != null && !entity.getUserGroupAssignments().isEmpty()) {
      UserGroupAssignment userGroupAssignment = entity.getUserGroupAssignments().get(0);
      if (userGroupAssignment != null) {
        UserGroup userGroup = userGroupAssignment.getUserGroupId();
        dto.setUserGroup(userGroup.getName());
        dto.setUserGroupDescription(userGroup.getDescription());
        dto.setRoleScopeType(
            userGroup.getIsFirmScope() != null ? getRoleScopeTypeEnum(userGroup) : null);
      }
    }
    return dto;
  }

  public static UserConfiguration toDtoWithUserGroupAndFirmId(
      ca.bnc.wealth.common.jpa.entity.platform.UserConfiguration entity) {
    UserConfiguration dto = toDtoWithUserGroup(entity);
    try {
      Optional.ofNullable(entity.getUserEntityAssignments())
          .filter(lst -> !lst.isEmpty())
          .ifPresent(
              set -> set.forEach(firm -> dto.setFirmId(firm.getResourceEntityId().getFirmId())));
    } catch (Exception e) {
      log.error("Unable to get firm Id for the user config id: " + dto.getUserConfigurationId());
    }
    return dto;
  }

  public static UserData toUserDataDto(UserConfiguration userConfiguration) {
    UserData userData = new UserData();
    userData.setFirstName(userConfiguration.getFirstName());
    userData.setLastName(userConfiguration.getLastName());
    userData.setUsername(userConfiguration.getUsername());
    userData.setIdpUserIdentifier(userConfiguration.getIdpUserId());
    userData.setIdpSubject(userConfiguration.getIdpSubject());
    userData.setOssUserId(userConfiguration.getOssUserId());
    userData.setOssGroupId(userConfiguration.getOssGroupId());
    userData.setEmail(userConfiguration.getEmail());
    userData.setUserGroup(userConfiguration.getUserGroup());
    if (userConfiguration.getIsFirmScope() != null) {
      userData.setRoleScopeType(
          userConfiguration.getIsFirmScope()
              ? RoleScopeTypeEnum.FIRM_SCOPE.getValue()
              : RoleScopeTypeEnum.RR_CODE_SCOPE.getValue());
    }
    userData.setFirmId(userConfiguration.getFirmId());
    userData.setFirmName(userConfiguration.getFirmName());
    userData.setFirmType(userConfiguration.getFirmType());
    return userData;
  }

  static Timestamp getTimeStamp(String time) {
    try {
      Date date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").parse(time);
      return new Timestamp(date.getTime());
    } catch (Exception exception) {
      return null;
    }
  }

  private static RoleScopeTypeEnum getRoleScopeTypeEnum(UserGroup userGroup) {
    if (userGroup.getIsFirmScope()) {
      return RoleScopeTypeEnum.FIRM_SCOPE;
    }
    return RoleScopeTypeEnum.RR_CODE_SCOPE;
  }

  public static UserConfiguration toDto(IamUserConfiguration entity) {
    UserConfiguration dto = new UserConfiguration();

    dto.setUserConfigurationId(entity.getUserConfigurationId().intValue());
    dto.setIdpUserId(entity.getIdpUserIdentifier());
    dto.setIdpSubject(entity.getIdpSubject());
    dto.setUsername(entity.getUsername());
    dto.setOssId(
        entity.getOssUserId()); // TODO To be removed after external dependencies are resolved
    dto.setOssProxyId(
        entity.getOssGroupId()); // TODO To be removed after external dependencies are resolved
    dto.setOssUserId(entity.getOssUserId());
    dto.setOssGroupId(entity.getOssGroupId());
    dto.setFirstName(entity.getFirstName());
    dto.setLastName(entity.getLastName());
    dto.setEmail(entity.getEmail());

    dto.setStatus(
        entity.getActive() ? UserStatusEnum.ACTIVE.dbValue : UserStatusEnum.INACTIVE.dbValue);
    dto.setState(entity.getState());
    dto.setStateDescription(entity.getStateDescription());
    dto.setStateAction(entity.getStateAction());

    dto.setPreferredLanguage(entity.getPreferredLanguageType().name());
    dto.setActive(
        entity.getActive()
            ? UserStatusEnum.ACTIVE.dbValue
            : UserStatusEnum.INACTIVE.dbValue); // deprecated
    dto.setCreatedBy(entity.getCreatedBy());
    dto.setLastUpdatedBy(entity.getLastUpdatedBy());
    dto.setCreationDate(
        entity.getCreationDate() != null ? entity.getCreationDate().toLocalDateTime() : null);
    dto.setLastUpdatedDate(
        entity.getLastUpdateDate() != null ? entity.getLastUpdateDate().toLocalDateTime() : null);
    dto.setIdp(entity.getIdp());
    dto.setActivationDate(
        entity.getActivationDate() != null ? entity.getActivationDate().toLocalDateTime() : null);
    dto.setSourceIdpSubject(entity.getSourceIdpSubject() != null ? entity.getSourceIdpSubject() : null);
    dto.identityLastUpdatedDate(entity.getIdentityLastUpdated() != null ? entity.getIdentityLastUpdated().toLocalDateTime() : null);
    dto.setAccessProfileSet(entity.getAccessProfileSet() != null ? entity.getAccessProfileSet() : null);
    dto.setBngfReferenceId(entity.getBngfReferenceId());
    dto.setUserPreferences(entity.getUserPreferences());
    dto.setSource(entity.getSource());
    return dto;
  }

  public static UserConfiguration toDto(UserConfigSearchMaterializedView viewEntity) {
    UserConfiguration userConfiguration = new UserConfiguration();

    userConfiguration.setUserConfigurationId(viewEntity.getUserConfigurationId().intValue());
    userConfiguration.setIdpUserId(viewEntity.getIdpUserIdentifier());
    userConfiguration.setIdpSubject(viewEntity.getIdpSubject());
    userConfiguration.setUsername(viewEntity.getUsername());
    userConfiguration.setOssId(
        viewEntity.getOssUserId()); // TODO To be removed after external dependencies are resolved
    userConfiguration.setOssProxyId(
        viewEntity.getOssGroupId()); // TODO To be removed after external dependencies are resolved
    userConfiguration.setOssUserId(viewEntity.getOssUserId());
    userConfiguration.setOssGroupId(viewEntity.getOssGroupId());
    userConfiguration.setFirstName(viewEntity.getFirstName());
    userConfiguration.setLastName(viewEntity.getLastName());
    userConfiguration.setEmail(viewEntity.getEmail());

    userConfiguration.setStatus(
        viewEntity.getActive() ? UserStatusEnum.ACTIVE.dbValue : UserStatusEnum.INACTIVE.dbValue);
    userConfiguration.setState(viewEntity.getState());
    userConfiguration.setStateDescription(viewEntity.getStateDescription());
    userConfiguration.setStateAction(viewEntity.getStateAction());

    userConfiguration.setPreferredLanguage(viewEntity.getPreferredLanguageType().name());
    userConfiguration.setActive(
        viewEntity.getActive()
            ? UserStatusEnum.ACTIVE.dbValue
            : UserStatusEnum.INACTIVE.dbValue); // deprecated
    userConfiguration.setCreatedBy(viewEntity.getCreatedBy());
    userConfiguration.setLastUpdatedBy(viewEntity.getLastUpdatedBy());
    userConfiguration.setCreationDate(
        viewEntity.getCreationDate() != null
            ? viewEntity.getCreationDate().toLocalDateTime()
            : null);
    userConfiguration.setLastUpdatedDate(
        viewEntity.getLastUpdateDate() != null
            ? viewEntity.getLastUpdateDate().toLocalDateTime()
            : null);
    userConfiguration.setIdp(viewEntity.getIdp());
    userConfiguration.setAccessProfileSet(viewEntity.getAccessProfileSet());
    userConfiguration.setFirmId(viewEntity.getFirmId());
    userConfiguration.setUserGroup(viewEntity.getUserGroupName());
    userConfiguration.setUserGroupDescription(viewEntity.getUserGroupDescription());
    userConfiguration.setSource(viewEntity.getSource());
    return userConfiguration;
  }

  public static IamUserConfiguration toIamUserConfigurationEntity(Map<String, Object> userMap) {
    IamUserConfiguration entity = new IamUserConfiguration();
    entity.setUserConfigurationId(((Integer) userMap.get("USER_CONFIGURATION_ID")).longValue());
    entity.setIdpUserIdentifier(String.valueOf(userMap.get("IDP_USER_ID")));
    entity.setIdpSubject(String.valueOf(userMap.get("IDP_SUBJECT")));
    entity.setIdp(String.valueOf(userMap.get("IDP")));
    entity.setUsername(String.valueOf(userMap.get("USERNAME")));
    Optional.ofNullable(userMap.get("OSS_USER_ID"))
            .map(String::valueOf)
            .ifPresent(entity::setOssUserId);
    Optional.ofNullable(userMap.get("OSS_GROUP_ID"))
            .map(String::valueOf)
            .ifPresent(entity::setOssGroupId);
    entity.setFirstName(String.valueOf(userMap.get("FIRST_NAME")));
    entity.setLastName(String.valueOf(userMap.get("LAST_NAME")));
    entity.setEmail(String.valueOf(userMap.get("EMAIL")));
    entity.setActive((Boolean) userMap.get("ACTIVE"));
    entity.setState(String.valueOf(userMap.get("STATE")));
    entity.setStateDescription(String.valueOf(userMap.get("STATE_DESCRIPTION")));
    entity.setStateAction(String.valueOf(userMap.get("STATE_ACTION")));
    entity.setPreferredLanguageType(
        PreferredLanguageType.valueOf(String.valueOf(userMap.get("PREFERRED_LANGUAGE"))));
    entity.setPreferredCxUtModule(String.valueOf(userMap.get("PREFERRED_CX_UI_MODULE")));
    entity.setCreatedBy(String.valueOf(userMap.get("CREATED_BY")));
    Optional.ofNullable(userMap.get("LAST_UPDATED_BY"))
        .map(String::valueOf)
        .ifPresent(entity::setLastUpdatedBy);
    entity.setCreationDate(Timestamp.valueOf(String.valueOf(userMap.get("CREATION_DATE"))));
    Optional.ofNullable(userMap.get("LAST_UPDATE_DATE"))
        .map(o -> Timestamp.valueOf(String.valueOf(o)))
        .ifPresent(entity::setLastUpdateDate);
    Optional.ofNullable(userMap.get("PROFILE_LAST_UPDATED"))
        .map(o -> Timestamp.valueOf(String.valueOf(o)))
        .ifPresent(entity::setProfileLastUpdated);
    Optional.ofNullable(userMap.get("STATUS_LAST_UPDATED"))
        .map(o -> Timestamp.valueOf(String.valueOf(o)))
        .ifPresent(entity::setStatusLastUpdated);
    Optional.ofNullable(userMap.get("ACTIVATION_DATE"))
        .map(o -> Timestamp.valueOf(String.valueOf(o)))
        .ifPresent(entity::setActivationDate);
    Optional.ofNullable(userMap.get("IDENTITY_LAST_UPDATED"))
        .map(o -> Timestamp.valueOf(String.valueOf(o)))
        .ifPresent(entity::setIdentityLastUpdated);
    entity.setAccessProfileSet((Boolean) userMap.get("ACCESS_PROFILE_SET"));
    Optional.ofNullable(userMap.get("SOURCE_IDP_SUBJECT"))
        .map(String::valueOf)
        .ifPresent(entity::setSourceIdpSubject);
    entity.setBngfReferenceId(String.valueOf(userMap.get("BNGF_REFERENCE_ID")));

    Optional.ofNullable(userMap.get("USER_PREFERENCES"))
        .map(String::valueOf)
        .ifPresent(up -> entity.setUserPreferences(getMap(up)));

    return entity;
  }

  public static Map<String,String> getMap(String mapString) {
    try {
      ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().build();
      return objectMapper.readValue(mapString, Map.class);
    } catch (JacksonException e) {
      return null;
    }
  }

  public static void updateEntityForAccessOnly(IamUserConfiguration entity, UserConfiguration dto) {

    Optional.ofNullable(dto.getOssId())
        .ifPresent(
            entity::setOssUserId); // TODO To be removed after external dependencies are resolved
    Optional.ofNullable(dto.getOssProxyId())
        .ifPresent(
            entity::setOssGroupId); // TODO To be removed after external dependencies are resolved
    Optional.ofNullable(dto.getOssUserId()).ifPresent(entity::setOssUserId);
    Optional.ofNullable(dto.getOssGroupId()).ifPresent(entity::setOssGroupId);
    Optional.ofNullable(dto.getStatus()).ifPresent(entity::setState);
    if (UserConfigUtils.isEmpty(dto.getOssProxyId()) && !UserConfigUtils.isEmpty(dto.getOssId())) {
      entity.setOssUserId(dto.getOssId());
    }

    Optional.ofNullable(dto.getOssId()).ifPresent(entity::setOssGroupId);
    Optional.ofNullable(dto.getActivationDate())
        .ifPresent(t -> entity.setActivationDate(Timestamp.valueOf(t)));
    Optional.ofNullable(dto.getAccessProfileSet()).ifPresent(entity::setAccessProfileSet);
    Optional.ofNullable(dto.getUserPreferences()).ifPresent(entity::setUserPreferences);
  }

  public static void updateEntityForIdentity(IamUserConfiguration entity, UserConfiguration dto) {
    Optional.ofNullable(dto.getIdp()).ifPresent(entity::setIdp);
    Optional.ofNullable(dto.getIdpUserId()).ifPresent(entity::setIdpUserIdentifier);
    Optional.ofNullable(dto.getIdpSubject()).ifPresent(entity::setIdpSubject);
    Optional.ofNullable(dto.getUsername()).ifPresent(entity::setUsername);
    Optional.ofNullable(dto.getFirstName()).ifPresent(entity::setFirstName);
    Optional.ofNullable(dto.getLastName()).ifPresent(entity::setLastName);
    // Update user email only if it's not blank
    if (!UserConfigUtils.isEmpty(dto.getEmail())) {
      entity.setEmail(dto.getEmail());
    }
    Optional.ofNullable(dto.getStatus()).ifPresent(entity::setState);
    Optional.ofNullable(dto.getPreferredLanguage())
        .ifPresent(l -> entity.setPreferredLanguageType(PreferredLanguageType.valueOf(l)));
    Optional.ofNullable(dto.getActivationDate())
        .ifPresent(t -> entity.setActivationDate(Timestamp.valueOf(t)));
    Optional.ofNullable(dto.getIdentityLastUpdatedDate())
        .map(Timestamp::valueOf)
        .ifPresent(entity::setIdentityLastUpdated);
  }

  public static void updateEntity(IamUserConfiguration entity, UserConfiguration dto) {

    Optional.ofNullable(dto.getIdpUserId()).ifPresent(entity::setIdpUserIdentifier);
    Optional.ofNullable(dto.getIdpSubject()).ifPresent(entity::setIdpSubject);
    Optional.ofNullable(dto.getUsername()).ifPresent(entity::setUsername);
    Optional.ofNullable(dto.getOssId())
        .ifPresent(
            entity::setOssUserId); // TODO To be removed after external dependencies are resolved
    Optional.ofNullable(dto.getOssProxyId())
        .ifPresent(
            entity::setOssGroupId); // TODO To be removed after external dependencies are resolved
    Optional.ofNullable(dto.getOssUserId()).ifPresent(entity::setOssUserId);
    Optional.ofNullable(dto.getOssGroupId()).ifPresent(entity::setOssGroupId);
    Optional.ofNullable(dto.getFirstName()).ifPresent(entity::setFirstName);
    Optional.ofNullable(dto.getLastName()).ifPresent(entity::setLastName);
    // Update user email only if it's not blank
    if (!UserConfigUtils.isEmpty(dto.getEmail())) {
      entity.setEmail(dto.getEmail());
    }
    Optional.ofNullable(dto.getStatus()).ifPresent(entity::setState);
    Optional.ofNullable(dto.getPreferredLanguage())
        .ifPresent(l -> entity.setPreferredLanguageType(PreferredLanguageType.valueOf(l)));
    if (UserConfigUtils.isEmpty(dto.getOssProxyId()) && !UserConfigUtils.isEmpty(dto.getOssId())) {
      entity.setOssUserId(dto.getOssId());
    }

    Optional.ofNullable(dto.getOssId()).ifPresent(entity::setOssGroupId);
    Optional.ofNullable(dto.getActivationDate())
        .ifPresent(t -> entity.setActivationDate(Timestamp.valueOf(t)));
    Optional.ofNullable(dto.getIdentityLastUpdatedDate())
        .map(Timestamp::valueOf)
        .ifPresent(entity::setIdentityLastUpdated);
    Optional.ofNullable(dto.getAccessProfileSet()).ifPresent(entity::setAccessProfileSet);
    Optional.ofNullable(dto.getBngfReferenceId()).ifPresent(entity::setBngfReferenceId);
    Optional.ofNullable(dto.getUserPreferences()).ifPresent(entity::setUserPreferences);
  }

  public static List<RRCodeRange> toDtos(List<IamRrCodeRange> lst) {
    if (lst == null) return Collections.emptyList();
    return lst.stream().map(MapperUtils::toDto).collect(Collectors.toList());
  }

  public static RRCodeRange toDto(IamRrCodeRange rrCodeRange) {
    RRCodeRange dto = new RRCodeRange();
    dto.setRrCodeRangeId((int) rrCodeRange.getRrCodeRangeId());
    dto.setFromRRCode(rrCodeRange.getFromRrCode());
    dto.setToRRCode(rrCodeRange.getToRrCode());
    dto.setFromRRCodeB10((int) rrCodeRange.getFromRrCodeB10());
    dto.setToRRCodeB10((int) rrCodeRange.getToRrCodeB10());
    dto.setCreatedBy(rrCodeRange.getCreatedBy());
    dto.setLastUpdatedBy(rrCodeRange.getLastUpdatedBy());
    dto.setCreationDate(
        rrCodeRange.getCreationDate() != null
            ? rrCodeRange.getCreationDate().toLocalDateTime()
            : null);
    dto.setLastUpdatedDate(
        rrCodeRange.getLastUpdateDate() != null
            ? rrCodeRange.getLastUpdateDate().toLocalDateTime()
            : null);
    return dto;
  }

  public static RRCodeRange toRRCodeRangeDto(Map<String, Object> rrCodeMap) {
    RRCodeRange dto = new RRCodeRange();
    dto.setRrCodeRangeId((Integer) rrCodeMap.get("RR_CODE_RANGE_ID"));
    dto.setFromRRCode(String.valueOf(rrCodeMap.get("FROM_RR_CODE")));
    dto.setFromRRCodeB10(((Long) rrCodeMap.get("FROM_RR_CODE_B10")).intValue());
    dto.setToRRCode(String.valueOf(rrCodeMap.get("TO_RR_CODE")));
    dto.setToRRCodeB10(((Long) rrCodeMap.get("TO_RR_CODE_B10")).intValue());
    dto.setCreatedBy(String.valueOf(rrCodeMap.get("CREATED_BY")));
    Optional.ofNullable(rrCodeMap.get("LAST_UPDATED_BY"))
        .map(String::valueOf)
        .ifPresent(dto::setLastUpdatedBy);
    Optional.ofNullable(rrCodeMap.get("CREATION_DATE"))
        .map(o -> Timestamp.valueOf(String.valueOf(o)).toLocalDateTime())
        .ifPresent(dto::setCreationDate);
    Optional.ofNullable(rrCodeMap.get("LAST_UPDATE_DATE"))
        .map(o -> Timestamp.valueOf(String.valueOf(o)).toLocalDateTime())
        .ifPresent(dto::setLastUpdatedDate);
    return dto;
  }

  public static Firm toEntity(Map<String, Object> firmMap) {
    Firm firm = new Firm();
    firm.setFirmEntityId(((Integer) firmMap.get("FIRM_ENTITY_ID")).longValue());
    firm.setFirmId(String.valueOf(firmMap.get("FIRM_ID")));
    firm.setFirmType(
        ca.bnc.wealth.common.jpa.entity.enums.FirmType.valueOf(
            String.valueOf(firmMap.get("TYPE"))));
    firm.setName(String.valueOf(firmMap.get("NAME")));
    firm.setActive((Boolean) firmMap.get("ACTIVE"));
    firm.setState(String.valueOf(firmMap.get("STATE")));
    firm.setPreferredLanguageType(
        PreferredLanguageType.valueOf(String.valueOf(firmMap.get("PREFERRED_LANGUAGE"))));
    firm.setCreatedBy(String.valueOf(firmMap.get("CREATED_BY")));
    Optional.ofNullable(firmMap.get("CREATION_DATE"))
        .map(o -> Timestamp.valueOf(String.valueOf(o)))
        .ifPresent(firm::setCreationDate);
    firm.setLastUpdatedBy(String.valueOf(firmMap.get("LAST_UPDATED_BY")));
    Optional.ofNullable(firmMap.get("LAST_UPDATE_DATE"))
        .map(o -> Timestamp.valueOf(String.valueOf(o)))
        .ifPresent(firm::setLastUpdateDate);
    return firm;
  }

  public static IamContentTranslation toIamContentTranslationEntity(
      Map<String, Object> contentMap) {
    IamContentTranslation contentTranslation = new IamContentTranslation();
    contentTranslation.setContentTranslationId(
        ((Integer) contentMap.get("CONTENT_TRANSLATION_ID")).longValue());
    contentTranslation.setTranslationKey(String.valueOf(contentMap.get("TRANSLATION_KEY")));
    contentTranslation.setTranslationValue(String.valueOf(contentMap.get("TRANSLATION_VALUE")));
    contentTranslation.setPreferredLanguage(
        PreferredLanguageType.valueOf(String.valueOf(contentMap.get("LANGUAGE"))));
    contentTranslation.setCreatedBy(String.valueOf(contentMap.get("CREATED_BY")));
    Optional.ofNullable(contentMap.get("CREATED_DT"))
        .map(o -> Timestamp.valueOf(String.valueOf(o)))
        .ifPresent(contentTranslation::setCreationDate);
    contentTranslation.setLastUpdatedBy(String.valueOf(contentMap.get("UPDATED_BY")));
    Optional.ofNullable(contentMap.get("UPDATED_DT"))
        .map(o -> Timestamp.valueOf(String.valueOf(o)))
        .ifPresent(contentTranslation::setLastUpdateDate);
    return contentTranslation;
  }

  public static UamaUser toDto(SzUser szUser) {
    if (szUser == null) {
      return null;
    }
    return UamaUser.builder()
        .active(szUser.isActive())
        .userName(szUser.getUserName())
        .familyName(szUser.getFamilyName())
        .givenName(szUser.getGivenName())
        .externalId(szUser.getExternalId())
        .userType(szUser.getUserType())
        .preferredLanguage(szUser.getPreferredLanguage())
        .groups(szUser.getGroups())
        .empId(szUser.getEmpId())
        .id(szUser.getId())
        .build();
  }

  public static UamaUserSearchResponse toDto(SzUserSearch szUserSearch) {
    if (szUserSearch == null) {
      return null;
    }
    return UamaUserSearchResponse.builder()
        .startIndex(szUserSearch.getStartIndex())
        .pageResults(szUserSearch.getPageResults())
        .totalResults(szUserSearch.getTotalResults())
        .users(szUserSearch.getResources() != null
            ? szUserSearch.getResources().stream().map(MapperUtils::toDto).collect(Collectors.toList())
            : null)
        .build();
  }

}
