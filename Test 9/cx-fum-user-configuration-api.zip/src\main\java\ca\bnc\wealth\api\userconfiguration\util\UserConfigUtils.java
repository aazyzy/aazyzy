package ca.bnc.wealth.api.userconfiguration.util;

import ca.bnc.wealth.api.userconfiguration.model.UserConfigurationConstants;
import ca.bnc.wealth.common.fum.model.UserPreferencesEnum;
import ca.bnc.wealth.common.kafka.model.Origin;
import ca.bnc.wealth.common.kafka.model.Publisher;
import ca.bnc.wealth.common.kafka.model.Source;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ErrorSeverity;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ServiceException;
import java.lang.reflect.Field;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.IntStream;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;

@Slf4j
public class UserConfigUtils {

  private UserConfigUtils() {
    throw new IllegalStateException("Utility class");
  }

  public static Source getSource() {
    Source source = new Source();
    Origin origin = new Origin();
    origin.setSystem(UserConfigurationConstants.KAFKA_MSG_ORIGIN_SYSTEM);
    origin.setNbcId(UserConfigurationConstants.KAFKA_MSG_ORIGIN_SYSTEM_ID);
    origin.setTime(new Date());
    source.setOrigin(origin);
    Publisher publisher = new Publisher();
    publisher.setSystem(UserConfigurationConstants.KAFKA_MSG_PUBLISHER_SYSTEM);
    publisher.setNbcId(UserConfigurationConstants.KAFKA_MSG_PUBLISHER_SYSTEM_ID);
    publisher.setTime(new Date());
    source.setPublisher(publisher);
    return source;
  }

  public static Integer getUserNamePrefix(String defaultUsername, String username, String env) {
    String prefix = username.replace(defaultUsername, "");
    if (env != null) {
      prefix = prefix.replace("." + env, "");
    }
    try {
      return Integer.parseInt(prefix);
    } catch (NumberFormatException e) {
      return 0;
    }
  }

  public static String generateTemporaryPassword(int len) {
    SecureRandom random = new SecureRandom();

    return IntStream.range(0, len)
        .mapToObj(iterator -> generateOneRandomCharacter(random))
        .reduce("", (init, character) -> init + character);
  }

  public static String generateOneRandomCharacter(SecureRandom random) {
    return String.valueOf(
        UserConfigurationConstants.CHARACTER_ALLOWED.charAt(
            random.nextInt(UserConfigurationConstants.CHARACTER_ALLOWED.length())));
  }

  public static String getTempPassword(String firstName, String lastName) {
    return IntStream.range(0, UserConfigurationConstants.TEMP_PASSWORD_GENERATION_ATTEMPTS)
        .mapToObj(iteration -> UserConfigUtils.generateTemporaryPassword(12))
        .filter(passwd -> !StringUtils.containsIgnoreCase(passwd, firstName))
        .filter(passwd -> !StringUtils.containsIgnoreCase(passwd, lastName))
        .filter(
            passwd -> Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*[\\d])").matcher(passwd).find())
        .filter(passwd -> StringUtils.containsAny(passwd, "~`!@#$%^&*()-_=+[{]}\\|;:'\",<.>/?"))
        .findFirst()
        .orElseThrow(
            () ->
                new ServiceException(
                    ErrorSeverity.ERROR,
                    UserConfigurationConstants.TEMP_PASSWORD_GENERATION_ERROR));
  }

  public static String getUserName(Pair<String, List<String>> pair, String env) {
    if (pair.getValue().isEmpty()) {
      return pair.getKey();
    }

    int prefix =
        pair.getValue().stream()
            .map(username -> getUserNamePrefix(pair.getKey(), username, env))
            .max(Comparator.comparing(Integer::valueOf))
            .map(num -> num + 1)
            .filter(num -> num <= UserConfigurationConstants.PREFIX_MAX)
            .orElseThrow(
                () ->
                    new ServiceException(
                        ErrorSeverity.ERROR, UserConfigurationConstants.USERNAME_PREFIX_ERROR));

    return pair.getKey() + prefix;
  }

  public static boolean isEmpty(String str) {
    return str == null || str.isBlank();
  }

  public static boolean isTwoArraysEqual(String[] ary1, String[] ary2) {
    if (ary1 != null && ary2 != null) {
      String[] newAry1 = ary1.clone();
      String[] newAry2 = ary2.clone();
      Arrays.sort(newAry1);
      Arrays.sort(newAry2);
      return Arrays.equals(newAry1, newAry2);
    }
    return false;
  }

  public static boolean validateEmail(String email) {
    String emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}";
    Pattern pat = Pattern.compile(emailRegex);
    return pat.matcher(email).matches() && email.length() <= UserConfigurationConstants.FIELD_MAX_LENGTH;
  }

  public static boolean validateFieldLength(String field) {
    return (field.length() <= UserConfigurationConstants.FIELD_MAX_LENGTH);
  }

  public static boolean isNumber(String id) {
    try {
      Integer.parseInt(id);
      return true;
    } catch (NumberFormatException e) {
      return false;
    }
  }

  @SneakyThrows
  public static void cloneProperties(Object source, Object target, List skipFields) {
    Class<?> sourceClass = source.getClass();
    Class<?> targetClass = target.getClass();
    // Apply restrictions on fields to be cloned
    Field[] sourceFields =
        Arrays.stream(sourceClass.getDeclaredFields())
            .filter(field -> !skipFields.contains(field.getName()))
            .toArray(Field[]::new);

    // Iteratively apply the fields from source to target
    for (Field sourceField : sourceFields) {
      sourceField.setAccessible(true);
      Field destinationField;
      try {
        destinationField = targetClass.getDeclaredField(sourceField.getName());
        destinationField.setAccessible(true);
        if (destinationField.get(target) == null) {
          log.info(
              "Cloning property {} from source {} to target {}",
              sourceField.getName(),
              sourceClass.getSimpleName(),
              targetClass.getSimpleName());
          destinationField.set(target, sourceField.get(source));
        } else {
          log.info(
              "Skipping property {} from source {} to target {}",
              sourceField.getName(),
              sourceClass.getSimpleName(),
              targetClass.getSimpleName());
        }
      } catch (NoSuchFieldException e) {
        // If the field doesn't exist in destination object, skip it
        log.warn(
            "Field {} does not exist in target object {}. Skipping cloning.",
            sourceField.getName(),
            targetClass.getSimpleName());
      }
    }
  }

  public static boolean validUserPreferences(Map<String, String> userPreferences) {
      return true;
  }
}
