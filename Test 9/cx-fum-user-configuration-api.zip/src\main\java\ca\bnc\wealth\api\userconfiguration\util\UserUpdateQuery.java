package ca.bnc.wealth.api.userconfiguration.util;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

public class UserUpdateQuery {

  public MapSqlParameterSource parameters;
  public StringBuilder userUpdateQuery;

  
  UserUpdateQuery() {
    this.userUpdateQuery =
        new StringBuilder(
            "update \"PLATFORM\".\"USER_CONFIGURATION\" set \"LAST_UPDATE_DATE\" = now()");
    this.parameters = new MapSqlParameterSource();
  }
  
}
