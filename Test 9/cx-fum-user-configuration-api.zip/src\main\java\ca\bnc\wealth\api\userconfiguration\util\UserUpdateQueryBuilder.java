package ca.bnc.wealth.api.userconfiguration.util;

import ca.bnc.wealth.api.userconfiguration.model.UserConfigurationConstants;
import java.sql.Timestamp;

public class UserUpdateQueryBuilder {

  UserUpdateQuery userUpdateQuery;
  Integer userConfigurationId;

  public UserUpdateQueryBuilder(Integer userConfigurationId) {
    this.userConfigurationId = userConfigurationId;
    this.userUpdateQuery = new UserUpdateQuery();
  }

  public void setStatusCode(String statusCode) {
    this.userUpdateQuery.userUpdateQuery.append(
        ", \"STATUS_CODE_ID\" = (SELECT \"CODE_VALUE_MAPPING_ID\" FROM \"PLATFORM\".\"CODE_VALUE_MAPPING\" WHERE \"CODE_TYPE\"='USER_PROFILE_STATUS' AND \"CODE_VALUE\"=:statusCode and \"ACTIVE\"='Y')");
    this.userUpdateQuery.parameters.addValue("statusCode", statusCode);
  }

  public void setIdpUserId(String idpUserId) {
    this.userUpdateQuery.userUpdateQuery.append(", \"IDP_USER_IDENTIFIER\" = :idpUserId ");
    this.userUpdateQuery.parameters.addValue("idpUserId", idpUserId);
  }

  public void setIdp(String idp) {
    this.userUpdateQuery.userUpdateQuery.append(", \"IDP\" = :idp ");
    this.userUpdateQuery.parameters.addValue("idp", idp);
  }

  public void setIdpSubject(String idpSubject) {
    this.userUpdateQuery.userUpdateQuery.append(", \"IDP_SUBJECT\" = :idpSubject ");
    this.userUpdateQuery.parameters.addValue("idpSubject", idpSubject);
  }

  public void setUsername(String userName) {
    this.userUpdateQuery.userUpdateQuery.append(", \"USERNAME\" = :username ");
    this.userUpdateQuery.parameters.addValue("username", userName);
  }

  //TODO Deprecate after external dependencies have been resolved
  public void setOssId(String ossId) {
    setOssUserId(ossId);
  }

  //TODO Deprecate after external dependencies have been resolved
  public void setOssProxyId(String ossProxyId) {
    setOssGroupId(ossProxyId);
  }

  public void setOssUserId(String ossUserId) {
    //TODO deprecate when ossId can be removed
    if (this.userUpdateQuery.userUpdateQuery.toString().contains("OSS_USER_ID")) {
      return;
    }
    this.userUpdateQuery.userUpdateQuery.append(", \"OSS_USER_ID\" = :ossUserId ");
    this.userUpdateQuery.parameters.addValue("ossUserId", ossUserId);
  }

  public void setOssGroupId(String ossGroupId) {
    //TODO deprecate when ossId can be removed
    if (this.userUpdateQuery.userUpdateQuery.toString().contains("OSS_GROUP_ID")) {
      return;
    }
    this.userUpdateQuery.userUpdateQuery.append(", \"OSS_GROUP_ID\" = :ossGroupId ");
    this.userUpdateQuery.parameters.addValue("ossGroupId", ossGroupId);
  }

  public void setFirstName(String firstName) {
    this.userUpdateQuery.userUpdateQuery.append(", \"FIRST_NAME\" = :firstName ");
    this.userUpdateQuery.parameters.addValue("firstName", firstName);
  }

  public void setLastName(String lastName) {
    this.userUpdateQuery.userUpdateQuery.append(", \"LAST_NAME\" = :lastName ");
    this.userUpdateQuery.parameters.addValue("lastName", lastName);
  }

  public void setActive(String active) {
    this.userUpdateQuery.userUpdateQuery.append(", \"ACTIVE\" = :active ");
    this.userUpdateQuery.parameters.addValue("active",
        UserConfigurationConstants.ACTIVE.equalsIgnoreCase(active)
            ? UserConfigurationConstants.ACTIVE_Y : UserConfigurationConstants.ACTIVE_N);
  }

  public void setPreferredLanguage(String languageCode) {
    this.userUpdateQuery.userUpdateQuery.append(
        ", \"PREFERRED_LANGUAGE_CODE_ID\"=(SELECT cvm.\"CODE_VALUE_MAPPING_ID\" FROM \"PLATFORM\".\"CODE_VALUE_MAPPING\" cvm where cvm.\"CODE_TYPE\" ='PREFERRED_LANGUAGE' and cvm.\"CODE_VALUE\" = :preferredLanguageCode)");
    this.userUpdateQuery.parameters.addValue("preferredLanguageCode", languageCode);
  }

  public void setEmail(String email) {
    this.userUpdateQuery.userUpdateQuery.append(", \"EMAIL\" = :email ");
    this.userUpdateQuery.parameters.addValue("email", email);
  }

  public void updateCreatedBy(String createdBy) {
    this.userUpdateQuery.userUpdateQuery.append(", \"CREATED_BY\" = :createdBy ");
    this.userUpdateQuery.parameters.addValue("createdBy", createdBy);
  }

  public void updateLastUpdatedBy(String lastUpdatedBy) {
    this.userUpdateQuery.userUpdateQuery.append(", \"LAST_UPDATED_BY\" = :lastUpdatedBy ");
    this.userUpdateQuery.parameters.addValue("lastUpdatedBy", lastUpdatedBy);
  }

  public void updateLastUpdateDate(Timestamp lastUpdateDate) {
    this.userUpdateQuery.userUpdateQuery.append(", \"LAST_UPDATE_DATE\" = :lastUpdateDate ");
    this.userUpdateQuery.parameters.addValue("lastUpdateDate", lastUpdateDate);
  }

  public UserUpdateQuery getUserUpdateQuery() {
    /* Apply where clause before the return */
    this.userUpdateQuery.userUpdateQuery.append(
        " where \"USER_CONFIGURATION_ID\" = :userConfigurationId ");
    this.userUpdateQuery.parameters.addValue("userConfigurationId", userConfigurationId);

    return this.userUpdateQuery;
  }
}
