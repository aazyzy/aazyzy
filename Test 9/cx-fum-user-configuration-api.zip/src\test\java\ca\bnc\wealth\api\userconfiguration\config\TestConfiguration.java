package ca.bnc.wealth.api.userconfiguration.config;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestConfiguration {

}