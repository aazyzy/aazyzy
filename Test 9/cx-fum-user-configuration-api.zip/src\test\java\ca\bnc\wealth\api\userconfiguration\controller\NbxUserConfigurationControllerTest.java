package ca.bnc.wealth.api.userconfiguration.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.userconfiguration.service.AuditLogService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigSearchMaterializedRefreshService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigValidationService;
import ca.bnc.wealth.api.userconfiguration.service.UserService;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearch;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearchResponse;
import ca.bnc.wealth.common.userconfiguration.model.NbxUserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.NbxUserConfiguration.PreferredLanguageEnum;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.util.HashMap;
import java.util.Map;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletWebRequest;

@RunWith(SpringRunner.class)
public class NbxUserConfigurationControllerTest {

  private NbxUserConfigurationController nbxUserConfigurationController;

  @MockitoBean private UserConfigValidationService userConfigValidationService;
  @MockitoBean private UserService userService;
  @MockitoBean private UserConfigSearchMaterializedRefreshService userConfigSearchMaterializedRefreshService;
  @MockitoBean private AuditLogService auditLogService;

  @Before
  public void setup() {
    nbxUserConfigurationController =
        new NbxUserConfigurationController(
            userConfigValidationService,
            userService,
            userConfigSearchMaterializedRefreshService,
            auditLogService);

    RequestAttributes mockRequest = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(mockRequest);
  }

  @Test
  public void nbxGenericSearchWithPagination_shouldReturnOk() {
    when(userService.genericNbxUserSearchWithPagination(any(GenericSearch.class)))
        .thenReturn(new GenericSearchResponse());

    assertEquals(
        HttpStatus.OK,
        nbxUserConfigurationController
            .nbxGenericSearchWithPagination(new GenericSearch())
            .getStatusCode());
    verify(userService, times(1)).genericNbxUserSearchWithPagination(any(GenericSearch.class));
  }

  @Test(expected = FumServiceException.class)
  public void nbxGenericSearchWithPagination_shouldThrowFumServiceException_whenSearchFails() {
    when(userService.genericNbxUserSearchWithPagination(any(GenericSearch.class)))
        .thenThrow(new RuntimeException("search failed"));

    nbxUserConfigurationController.nbxGenericSearchWithPagination(new GenericSearch());
  }

  @Test(expected = FumServiceException.class)
  public void createNbxUserConfiguration_shouldThrow_whenValidationMapHasErrors() {
    NbxUserConfiguration request = new NbxUserConfiguration();
    request.setFirstName("First");
    request.setLastName("Last");
    request.setEmail("first.last@test.com");
    request.setPreferredLanguage(PreferredLanguageEnum.EN);

    Map<String, String> validationError = new HashMap<>();
    validationError.put("email", "ERROR_CODE");
    when(userConfigValidationService.validateUserConfigurationCreation(any(UserConfiguration.class), any(Boolean.class)))
        .thenReturn(validationError);

    nbxUserConfigurationController.createNbxUserConfiguration(request);

    verify(auditLogService, never()).publishAuditLog(any(), any(), any(), any());
  }
}
