package ca.bnc.wealth.api.userconfiguration.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ca.bnc.wealth.api.authorization.security.SecurityConfigAdapter;
import ca.bnc.wealth.api.authorization.security.test.TestAuthConfiguration;
import ca.bnc.wealth.api.userconfiguration.model.UserConfigurationConstants;
import ca.bnc.wealth.api.userconfiguration.service.AuditLogService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigSearchMaterializedRefreshService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigValidationService;
import ca.bnc.wealth.api.userconfiguration.service.UserService;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.MapperUtils;
import ca.bnc.wealth.api.userconfiguration.util.MockData;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.ApiError;
import ca.bnc.wealth.common.userconfiguration.model.ApiMessage;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearch;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearchResponse;
import ca.bnc.wealth.common.userconfiguration.model.NbxUserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.NbxUserConfiguration.PreferredLanguageEnum;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import tools.jackson.databind.ObjectMapper;
import java.util.Map;
import java.util.function.Supplier;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc(addFilters = false)
@ContextConfiguration(
    classes = {
      SecurityConfigAdapter.class,
      TestAuthConfiguration.class,
      NbxUserConfigurationController.class,
      ca.bnc.wealth.common.exception.handler.ServiceExceptionHandler.class,
      ca.bnc.wealth.common.spring.microservice.starter.core.exception.GlobalDefaultExceptionHandler.class
    })
@WebMvcTest(properties = {"spring.profiles.active=test"})
@Slf4j
public class NbxUserConfigurationControllerTests {

  private final static String USER_ID = "userId";

  @Autowired private ObjectMapper objectMapper;
  @Autowired private WebApplicationContext webApplicationContext;
  @Autowired private MockMvc mockMvc;
  @MockitoBean private UserConfigValidationService userConfigValidationService;
  @MockitoBean private UserService userService;
  @MockitoBean private UserConfigSearchMaterializedRefreshService userConfigSearchMaterializedRefreshService;
  @MockitoBean private AuditLogService auditLogService;

  @Before
  public void setup() {
    mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).apply(springSecurity()).build();
    doNothing().when(userConfigSearchMaterializedRefreshService).refreshUserSearchMaterializedView(anyBoolean());
  }

  @Test
  public void test_createNbxUserConfiguration_shouldReturn201() throws Exception {
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    when(userService.saveNewUserConfiguration(any(UserConfiguration.class), any())).thenReturn(iamUserConfiguration);

    NbxUserConfiguration nbxUserConfigurationInput = new NbxUserConfiguration();
    nbxUserConfigurationInput.setFirstName(iamUserConfiguration.getFirstName());
    nbxUserConfigurationInput.setLastName(iamUserConfiguration.getLastName());
    nbxUserConfigurationInput.setEmail(iamUserConfiguration.getEmail());
    nbxUserConfigurationInput.setPreferredLanguage(PreferredLanguageEnum.valueOf(iamUserConfiguration.getPreferredLanguageType().name()));
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });


    MvcResult mvcResult =
        mockMvc
            .perform(
                post("/nbx-users")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(objectMapper.writeValueAsString(nbxUserConfigurationInput))
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isCreated())
            .andReturn();

    UserConfiguration response =
        objectMapper.readValue(
            mvcResult.getResponse().getContentAsString(), UserConfiguration.class);

    assertNotNull(response);
    assertEquals(iamUserConfiguration.getFirstName(), response.getFirstName());
    assertEquals(iamUserConfiguration.getLastName(), response.getLastName());
    assertEquals(iamUserConfiguration.getEmail(), response.getEmail());
    assertEquals(iamUserConfiguration.getPreferredLanguageType().name(), response.getPreferredLanguage());
  }

  @Test
  public void test_createNbxUserConfigurationWithValidationError_shouldReturn400() throws Exception {
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    when(userConfigValidationService.validateUserConfigurationCreation(any(UserConfiguration.class), anyBoolean())).thenReturn(
        Map.of("field", "errorCode"));

    NbxUserConfiguration nbxUserConfigurationInput = new NbxUserConfiguration();
    nbxUserConfigurationInput.setFirstName(iamUserConfiguration.getFirstName());
    nbxUserConfigurationInput.setLastName("");
    nbxUserConfigurationInput.setEmail(iamUserConfiguration.getEmail());
    nbxUserConfigurationInput.setPreferredLanguage(PreferredLanguageEnum.valueOf(iamUserConfiguration.getPreferredLanguageType().name()));

    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    MvcResult mvcResult =
        mockMvc
            .perform(
                post("/nbx-users")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(objectMapper.writeValueAsString(nbxUserConfigurationInput))
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isInternalServerError())
            .andReturn();

    ApiError apiError =
        objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ApiError.class);

    assertApiError(HttpStatus.INTERNAL_SERVER_ERROR, apiError, "errorCode", "Error in create user validation");
  }

  @Test
  public void test_updateNbxUserConfigurationByUserId_shouldReturn200() throws Exception {
    IamUserConfiguration mockIamUserConfiguration = MockData.getIamUserConfigurationEntity();
    mockIamUserConfiguration.setSource(UserConfigurationConstants.NBX_SOURCE);

    NbxUserConfiguration nbxUserConfigurationInput = new NbxUserConfiguration();
    nbxUserConfigurationInput.setFirstName(mockIamUserConfiguration.getFirstName());
    nbxUserConfigurationInput.setLastName(mockIamUserConfiguration.getLastName());
    nbxUserConfigurationInput.setEmail(mockIamUserConfiguration.getEmail());
    nbxUserConfigurationInput.setPreferredLanguage(PreferredLanguageEnum.valueOf(mockIamUserConfiguration.getPreferredLanguageType().name()));

    when(userService.updateNbxUserConfiguration(anyString(), any(NbxUserConfiguration.class))).thenReturn(mockIamUserConfiguration);
    doNothing().when(userConfigValidationService).validateUpdateNbxUserConfiguration(anyString(), any(NbxUserConfiguration.class));
    when(userService.getUserConfiguration(anyString())).thenReturn(MapperUtils.toDto(mockIamUserConfiguration));

    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });

    MvcResult mvcResult =
        mockMvc
            .perform(
                put("/nbx-users/" + USER_ID)
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(objectMapper.writeValueAsString(nbxUserConfigurationInput))
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();

    UserConfiguration response =
        objectMapper.readValue(
            mvcResult.getResponse().getContentAsString(), UserConfiguration.class);

    assertNotNull(response);
    assertEquals(nbxUserConfigurationInput.getFirstName(), response.getFirstName());
    assertEquals(nbxUserConfigurationInput.getLastName(), response.getLastName());
    assertEquals(nbxUserConfigurationInput.getEmail(), response.getEmail());
    assertEquals(nbxUserConfigurationInput.getPreferredLanguage().name(), response.getPreferredLanguage());
  }

  @Test
  public void test_updateNbxUserConfigurationByUserId_shouldReturn400_whenValidationFail() throws Exception {
    NbxUserConfiguration nbxUserConfigurationInput = new NbxUserConfiguration();
    nbxUserConfigurationInput.setFirstName("Firstname");
    nbxUserConfigurationInput.setLastName("Lastname");
    nbxUserConfigurationInput.setEmail("test@email.com");
    nbxUserConfigurationInput.setPreferredLanguage(PreferredLanguageEnum.EN);

    IamUserConfiguration mockIamUserConfiguration = MockData.getIamUserConfigurationEntity();

    String errorMessage = String.format(Constants.ERROR_NOT_NBX_USER_MESSAGE, MockData.IDP_USER_SUB);
    when(userService.updateNbxUserConfiguration(anyString(), any(NbxUserConfiguration.class))).thenReturn(mockIamUserConfiguration);
    doThrow(new FumValidationException(Constants.ERROR_NOT_NBX_USER_CODE,
        errorMessage)).when(userConfigValidationService)
        .validateUpdateNbxUserConfiguration(anyString(), any(NbxUserConfiguration.class));

    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });


    MvcResult mvcResult =
        mockMvc
            .perform(
                put("/nbx-users/" + USER_ID)
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(objectMapper.writeValueAsString(nbxUserConfigurationInput))
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().is4xxClientError())
            .andReturn();

    ApiError apiError =
        objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ApiError.class);

    assertApiError(HttpStatus.BAD_REQUEST, apiError, Constants.ERROR_NOT_NBX_USER_CODE, errorMessage);
  }

  @Test
  public void test_updateNbxUserConfigurationByUserId_shouldReturn404_whenUserNotExist() throws Exception {
    NbxUserConfiguration nbxUserConfigurationInput = new NbxUserConfiguration();
    nbxUserConfigurationInput.setFirstName("Firstname");
    nbxUserConfigurationInput.setLastName("Lastname");
    nbxUserConfigurationInput.setEmail("test@email.com");
    nbxUserConfigurationInput.setPreferredLanguage(PreferredLanguageEnum.EN);

    IamUserConfiguration mockIamUserConfiguration = MockData.getIamUserConfigurationEntity();
    mockIamUserConfiguration.setSource(UserConfigurationConstants.NBX_SOURCE);

    String errorMessage = String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, MockData.IDP_USER_SUB);
    when(userService.updateNbxUserConfiguration(anyString(), any(NbxUserConfiguration.class))).thenReturn(mockIamUserConfiguration);
    doThrow(new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
        errorMessage)).when(userConfigValidationService)
        .validateUpdateNbxUserConfiguration(anyString(), any(NbxUserConfiguration.class));

    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });

    MvcResult mvcResult =
        mockMvc
            .perform(
                put("/nbx-users/" + USER_ID)
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(objectMapper.writeValueAsString(nbxUserConfigurationInput))
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isNotFound())
            .andReturn();

    ApiError apiError =
        objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ApiError.class);

    assertApiError(HttpStatus.NOT_FOUND, apiError, Constants.ERROR_USER_NOT_FOUND_CODE, errorMessage);
  }

  @Test
  public void test_nbxGenericSearchWithPagination_shouldReturn200_whenUserSearchSuccessful() throws Exception {
    GenericSearch genericSearch = new GenericSearch();
    genericSearch.setSearchText("text");

    GenericSearchResponse expectedResponse = new GenericSearchResponse();
    expectedResponse.setOtherFirmUserCount(0);

    when(userService.genericNbxUserSearchWithPagination(any())).thenReturn(expectedResponse);

    MvcResult mvcResult =
        mockMvc
            .perform(
                post("/nbx-users/search")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(objectMapper.writeValueAsString(genericSearch))
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();

    GenericSearchResponse response =
        objectMapper.readValue(mvcResult.getResponse().getContentAsString(), GenericSearchResponse.class);

    assertEquals(expectedResponse.getOtherFirmUserCount(), response.getOtherFirmUserCount());
  }

  @Test
  public void test_nbxGenericSearchWithPagination_shouldReturn500_whenUserSearchUnsuccessful() throws Exception {
    GenericSearch genericSearch = new GenericSearch();
    genericSearch.setSearchText("text");

    doThrow(new RuntimeException("error")).when(userService).genericNbxUserSearchWithPagination(any());

    MvcResult mvcResult =
        mockMvc
            .perform(
                post("/nbx-users/search")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(objectMapper.writeValueAsString(genericSearch))
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isInternalServerError())
            .andReturn();

    ApiError apiError =
        objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ApiError.class);

    assertApiError(HttpStatus.INTERNAL_SERVER_ERROR, apiError, Constants.ERROR_CODE_GENERIC_SEARCH_USER, Constants.ERROR_DEFAULTMESSAGE_GENERIC_SEARCH_USER);
  }

  private void assertApiError(HttpStatus badRequest, ApiError apiError, String errorCode, String errorMessage) {
    assertEquals(badRequest.name(), apiError.getTitle());
    assertEquals(badRequest.getReasonPhrase(), apiError.getDescription());
    assertEquals(String.valueOf(badRequest.value()), apiError.getHttpCode());
    assertFalse(apiError.getMessages().getErrors().isEmpty());

    ApiMessage apiMessage = apiError.getMessages().getErrors().get(0);
    assertEquals(errorCode, apiMessage.getCode());
    assertNull(apiMessage.getField());
    assertEquals(errorMessage, apiMessage.getMessage());
  }
}
