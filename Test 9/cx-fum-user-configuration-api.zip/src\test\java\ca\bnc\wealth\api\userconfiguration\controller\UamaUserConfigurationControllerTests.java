package ca.bnc.wealth.api.userconfiguration.controller;

import static ca.bnc.wealth.api.userconfiguration.util.MockData.USER_EMAIL;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.USER_NAME_LABEL;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.getFeaturePackage;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.getUserGroupEntity;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.getUserGroupList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.SecurityConfigAdapter;
import ca.bnc.wealth.api.authorization.security.test.TestAuthConfiguration;
import ca.bnc.wealth.api.authorization.security.test.TestUserSingleton;
import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.userconfiguration.model.AssignmentType;
import ca.bnc.wealth.api.userconfiguration.service.AuditLogService;
import ca.bnc.wealth.api.userconfiguration.service.AuthorizationClient;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigSearchMaterializedRefreshService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigValidationService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigurationDataSyncService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigurationService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigurationServiceJpa;
import ca.bnc.wealth.api.userconfiguration.service.UserExtractService;
import ca.bnc.wealth.api.userconfiguration.service.UserService;
import ca.bnc.wealth.api.userconfiguration.service.UserStateService;
import ca.bnc.wealth.api.userconfiguration.service.UserValidationService;
import ca.bnc.wealth.api.userconfiguration.util.MockData;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ErrorSeverity;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.NoResultsFoundException;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ServiceException;
import ca.bnc.wealth.common.userconfiguration.model.ApiError;
import ca.bnc.wealth.common.userconfiguration.model.ApiMessage;
import ca.bnc.wealth.common.userconfiguration.model.AssignRequest;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearch;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearchResponse;
import ca.bnc.wealth.common.userconfiguration.model.GroupByResponse;
import ca.bnc.wealth.common.userconfiguration.model.PageInfo;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.RRRange;
import ca.bnc.wealth.common.userconfiguration.model.ResourceName;
import ca.bnc.wealth.common.userconfiguration.model.UamaUpdateUserExternalId;
import ca.bnc.wealth.common.userconfiguration.model.UamaUserSearchResponse;
import ca.bnc.wealth.common.userconfiguration.model.UpdateUserStatus;
import ca.bnc.wealth.common.userconfiguration.model.UpdateUserStatus.StatusEnum;
import ca.bnc.wealth.common.userconfiguration.model.UserAssignment;
import ca.bnc.wealth.common.userconfiguration.model.UamaUser;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserCredentials;
import ca.bnc.wealth.common.userconfiguration.model.UserExternalSystemConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserGroupName;
import ca.bnc.wealth.common.userconfiguration.model.UserIdentity;
import ca.bnc.wealth.common.userconfiguration.model.UserOktaProfile;
import ca.bnc.wealth.common.userconfiguration.model.UserPreferredLanguage;
import ca.bnc.wealth.common.userconfiguration.model.UserSearch;
import ca.bnc.wealth.common.userconfiguration.model.Users;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc(addFilters = false)
@ContextConfiguration(
    classes = {
      SecurityConfigAdapter.class,
      TestAuthConfiguration.class,
      UamaUserConfigurationController.class,
      ca.bnc.wealth.common.exception.handler.ServiceExceptionHandler.class,
      ca.bnc.wealth.common.spring.microservice.starter.core.exception.GlobalDefaultExceptionHandler
          .class
    })
@WebMvcTest(properties = {"spring.profiles.active=test"})
@Slf4j
public class UamaUserConfigurationControllerTests {

  private static final String USER_DATA = "User Data";
  @Autowired ObjectMapper objectMapper;
  String accessToken =
      "Bearer eyJraWQiOiJRdUZPcVhpYkwwYjc0emltbDNaYmU5NnNPWEpJMlNpRGR4ZThkZThlZG13IiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULjVfcTQwRlY2OHM3TlJSX1pQTERFLTdyemtNYmFIZnVLdjV1cnVGSVNDQjAiLCJpc3MiOiJodHRwczovL2F1dGgtcHAubmJpbi5jYS9vYXV0aDIvYXVzc2c0d3lkMkhaRUJHUjMwaDciLCJhdWQiOiJhcGk6Ly9kZWZhdWx0IiwiaWF0IjoxNjQ1MjgxMzc3LCJleHAiOjE2NDUyODE2NzcsImNpZCI6IjBvYTEwcmd6cThyTDNsQ1pHMGg4IiwidWlkIjoiMDB1MTRxa3BlZDNPSFZ5Qk0waDgiLCJzY3AiOlsiY2lhbTpwcm9maWxlczp3cml0ZSIsIndlYWx0aDphY2Nlc3MtY29udHJvbDp2aWV3ZXIiLCJvcGVuaWQiLCJjaWFtOnByb2ZpbGVzOnJlYWQiXSwic3ViIjoiMG9hMTByZ3pxOHJMM2xDWkcwaDgiLCJwcmVmZXJyZWRMYW5ndWFnZSI6ImVuIiwiYm5nZlNlY3VyZVpvbmVJZCI6WyJKT05FU01BIl0sImJuZ2ZJZGVudGl0eVNvdXJjZSI6IlNaIiwiYm5nZlBhcnRuZXJJZCI6IklBUyIsImdyb3VwcyI6WyJXZWFsdGguQ29tcGFzc1giLCJXZWFsdGguQ29tcGFzc1guVHJhZGVyIiwiV2VhbHRoIl19.dADByl5zkW4QP0WU3DhIdgPI9hipdYbDFnok8csB__a2_hqbHvFVWjD5BHEtNKOgSQVZ0L4sZazHPl0VlNOP8kArBWg80nx35ufYeXkrYGvT-1RK99KAZnhgnIQ77eSg-Ubb2ujbcx5cTiiFOKbeNLCK7UUSC7WHhzLMP39iXDhBIPfy3zI6NI-YfYgFVHzkbnNK-UpLZ09rq7hJMSJuef6P6xreooGXxenFIQHQAGhHTJPxBU85rG6cNLUbNrLG8mpQIgliDft5mZ7nNtZAq7o8DD0TGVNj4fUUyayb40WVmBOx0di6EHsfBnFQ8qtHGaT-hT7z8G-yX_V2NkmGbQ";
  @Autowired WebApplicationContext webApplicationContext;
  @Autowired private WebApplicationContext context;
  @Autowired private MockMvc mockMvc;
  @MockitoBean private UserConfigurationService userConfigurationService;
  @MockitoBean private UserConfigValidationService userConfigValidationService;
  @MockitoBean private UserConfigurationServiceJpa userConfigurationServiceJpa;
  @MockitoBean private UserConfigurationDataSyncService userConfigurationDataSyncService;
  @MockitoBean private UserExtractService userExtractService;
  @MockitoBean private UserAssignmentService userAssignmentService;
  @MockitoBean private UserService userService;
  @MockitoBean private UserValidationService userValidationService;
  @MockitoBean private AuthorizationClient authorizationClient;
  @MockitoBean private SystemTokenFactory systemTokenFactory;
  @MockitoBean private UserStateService userStateService;
  @MockitoBean private RedisCacheOperationService redisCacheOperationService;
  @MockitoBean private UserConfigSearchMaterializedRefreshService userConfigSearchMaterializedRefreshService;
  @MockitoBean private AuditLogService auditLogService;

  public static User getMockUser() {
    User testUser = new User();
    testUser.setRoles(List.of("Jedi"));
    testUser.setIdpSubject("Mando");
    testUser.setSecureZoneIds(Arrays.asList("Test12", "Test34"));
    testUser.setIdpUserId("00u20kwe9opbMxPM00h8");
    testUser.setGroups(List.of("Wealth.CommonX", "Wealth.Common.Trader"));
    return testUser;
  }

  @Before
  public void setup() {
    mockMvc = MockMvcBuilders.webAppContextSetup(context).apply(springSecurity()).build();
  }

  @AfterEach
  public void cleanUp() {
    TestUserSingleton.setTestUser(null);
    TestUserSingleton.USER_IS_UNAUTHORIZED = false;
  }

  @Test
  public void testUpdateUserExternalSystemConfigurationByUserId_shouldReturn204() throws Exception {
    UamaUpdateUserExternalId updateUserExternalId = new UamaUpdateUserExternalId();
    updateUserExternalId.setExternalUserId(new ArrayList<>());
    mockMvc
        .perform(
            put("/uama/{userId}/{externalId}", 12345, "secure-zone")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(updateUserExternalId))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNoContent());
  }

  @Test
  public void testUpdateUserGroupByIdpSubject_shouldReturn204() throws Exception {
    mockMvc
        .perform(
            put("/uama/{idpSubject}/groups/{groupName}", "testIdpSubject", "TestGroup")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNoContent());
  }

  @Test
  public void testUpdateUserGroupByIdpSubject_whenServiceThrows_shouldReturn500() throws Exception {
    doThrow(new FumNotFoundException("ERR", "User not found"))
        .when(userService).updateUserGroupByIdpSubject(anyString(), anyString());

    mockMvc
        .perform(
            put("/uama/{idpSubject}/groups/{groupName}", "unknownIdp", "TestGroup")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNotFound());
  }

  @Test
  public void testDeleteUserGroupByIdpSubject_shouldReturn204() throws Exception {
    mockMvc
        .perform(
            delete("/uama/{idpSubject}/groups/{groupName}", "testIdpSubject", "TestGroup")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNoContent());
  }

  @Test
  public void testGetUserExternalSystemConfigurationByExternalUserId_shouldReturn200() throws Exception {
    UamaUser uamaUser = UamaUser.builder()
        .id("123")
        .active(true)
        .userName("testUser")
        .familyName("Doe")
        .givenName("John")
        .externalId("ext123")
        .build();
    when(userService.getUserConfigurationByExternalUserId("secure-zone", "szId123"))
        .thenReturn(uamaUser);

    MvcResult result = mockMvc
        .perform(
            get("/uama/{externalSystemId}/{externalUserId}/profile", "secure-zone", "szId123")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andReturn();

    UamaUser responseUser = objectMapper.readValue(result.getResponse().getContentAsString(), UamaUser.class);
    assertEquals("123", responseUser.getId());
    assertEquals("testUser", responseUser.getUserName());
    assertTrue(responseUser.getActive());
  }

  @Test
  public void testGetUserExternalSystemConfigurationByExternalUserId_whenServiceThrows_shouldReturn400() throws Exception {
    doThrow(new ca.bnc.wealth.common.exception.Entity.FumValidationException("ERR", "Invalid external system"))
        .when(userService).getUserConfigurationByExternalUserId(anyString(), anyString());

    mockMvc
        .perform(
            get("/uama/{externalSystemId}/{externalUserId}/profile", "unsupported", "extId")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest());
  }

  @Test
  public void testGetUamaUsersByIdpSubjectAndExternalSystemId_shouldReturn200() throws Exception {
    UamaUser uamaUser = UamaUser.builder()
        .id("123")
        .active(true)
        .userName("testUser")
        .build();
    UamaUserSearchResponse searchResponse = UamaUserSearchResponse.builder()
        .startIndex(0)
        .pageResults(1)
        .totalResults(1)
        .users(List.of(uamaUser))
        .build();
    when(userService.getUserConfigurationByIdpSubjectAndExternalSystemId("testIdpSubject", "secure-zone"))
        .thenReturn(searchResponse);

    MvcResult result = mockMvc
        .perform(
            get("/uama/{idpSubject}/{externalSystemId}", "testIdpSubject", "secure-zone")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andReturn();

    UamaUserSearchResponse responseBody = objectMapper.readValue(result.getResponse().getContentAsString(), UamaUserSearchResponse.class);
    assertEquals(1, responseBody.getTotalResults().intValue());
    assertEquals(1, responseBody.getUsers().size());
    assertEquals("123", responseBody.getUsers().get(0).getId());
  }

  @Test
  public void testGetUamaUsersByIdpSubjectAndExternalSystemId_whenUserNotFound_shouldReturn404() throws Exception {
    doThrow(new FumNotFoundException("ERR", "User not found"))
        .when(userService).getUserConfigurationByIdpSubjectAndExternalSystemId(anyString(), anyString());

    mockMvc
        .perform(
            get("/uama/{idpSubject}/{externalSystemId}/profiles", "unknownIdp", "secure-zone")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNotFound());
  }

  @Test
  public void testGetUamaUsersByIdpSubjectAndExternalSystemId_whenUnsupportedSystem_shouldReturn400() throws Exception {
    doThrow(new FumValidationException("ERR", "Unsupported system"))
        .when(userService).getUserConfigurationByIdpSubjectAndExternalSystemId(anyString(), anyString());

    mockMvc
        .perform(
            get("/uama/{idpSubject}/{externalSystemId}", "testIdpSubject", "unsupported")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest());
  }
}
