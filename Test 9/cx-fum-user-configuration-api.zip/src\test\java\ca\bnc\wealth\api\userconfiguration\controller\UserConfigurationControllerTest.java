package ca.bnc.wealth.api.userconfiguration.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.userconfiguration.service.AuditLogService;
import ca.bnc.wealth.api.userconfiguration.service.FirmBmaGuardService;
import ca.bnc.wealth.api.userconfiguration.service.TokenRevocationService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigSearchMaterializedRefreshService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigValidationService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigurationDataSyncService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigurationService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigurationServiceJpa;
import ca.bnc.wealth.api.userconfiguration.service.UserExtractService;
import ca.bnc.wealth.api.userconfiguration.service.UserService;
import ca.bnc.wealth.api.userconfiguration.service.UserStateService;
import ca.bnc.wealth.api.userconfiguration.util.BulkUserConstants;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.userconfiguration.model.OktaStatusSyncRequest;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class UserConfigurationControllerTest {

  private UserConfigurationController userConfigurationController;

  @MockitoBean private UserConfigurationService userConfigurationService;
  @MockitoBean private UserConfigurationServiceJpa userConfigurationServiceJpa;
  @MockitoBean private UserConfigValidationService userConfigValidationService;
  @MockitoBean private UserConfigurationDataSyncService userConfigurationDataSyncService;
  @MockitoBean private UserExtractService userExtractService;
  @MockitoBean private UserService userService;
  @MockitoBean private UserStateService userStateService;
  @MockitoBean private RedisCacheOperationService redisCacheOperationService;
  @MockitoBean private UserAssignmentService userAssignmentService;
  @MockitoBean private UserConfigSearchMaterializedRefreshService userConfigSearchMaterializedRefreshService;
  @MockitoBean private AuditLogService auditLogService;
  @MockitoBean private TokenRevocationService tokenRevocationService;
  @MockitoBean private FirmBmaGuardService firmBmaGuardService;

  @Before
  public void setup() {
    userConfigurationController =
        new UserConfigurationController(
            tokenRevocationService,
            userConfigurationService,
            userConfigurationServiceJpa,
            userConfigValidationService,
            userConfigurationDataSyncService,
            userExtractService,
            userService,
            userStateService,
            redisCacheOperationService,
            userAssignmentService,
            userConfigSearchMaterializedRefreshService,
            auditLogService,
            firmBmaGuardService);
  }

  @Test
  public void getUserConfigurationByUserId_shouldSkipCompassR2Id_whenIsSzOnlyTrue() {
    UserConfiguration uc = stubUserConfiguration();

    userConfigurationController.getUserConfigurationByUserId("u1", true, true);

    verify(userService, never()).getCompassR2Id(any());
    verify(userService, times(1)).getSecureZoneId(any());
  }

  @Test
  public void getUserConfigurationByUserId_shouldFetchCompassR2Id_whenIsSzOnlyFalse() {
    stubUserConfiguration();

    userConfigurationController.getUserConfigurationByUserId("u1", true, false);

    verify(userService, times(1)).getCompassR2Id(any());
  }

  @Test
  public void getUserConfigurationByUserId_shouldNotFetchExternalIds_whenGetExternalIdFalse() {
    stubUserConfiguration();

    userConfigurationController.getUserConfigurationByUserId("u1", false, false);

    verify(userService, never()).getCompassR2Id(any());
  }

  private UserConfiguration stubUserConfiguration() {
    UserConfiguration uc = new UserConfiguration();
    uc.setUserConfigurationId(1);
    when(userService.getUserConfigurationByIdOrName("u1")).thenReturn(uc);
    when(userService.getUserConfigurationWithRrCodeById(1)).thenReturn(uc);
    return uc;
  }

  @Test
  public void refreshUserSearchMaterializedView_shouldReturnOk() {
    assertEquals(
        HttpStatus.OK,
        userConfigurationController.refreshUserSearchMaterializedView().getStatusCode());
    verify(userConfigSearchMaterializedRefreshService, times(1))
        .refreshUserSearchMaterializedView(true);
  }

  @Test
  public void clearRedisCache_shouldDeleteByNameAndKey_whenBothProvided() {
    assertEquals(
        HttpStatus.OK,
        userConfigurationController.clearRedisCache("cache-a", "key-a").getStatusCode());

    verify(redisCacheOperationService, times(1)).deleteCacheByCacheNameAndKey("cache-a", "key-a");
  }

  @Test
  public void clearRedisCache_shouldDeleteAll_whenCacheNameMissing() {
    clearInvocations(redisCacheOperationService);

    assertEquals(
        HttpStatus.OK,
        userConfigurationController.clearRedisCache(null, null).getStatusCode());

    verify(redisCacheOperationService, times(1)).deleteAllUserCache();
  }

  @Test
  public void clearRedisCache_shouldDeleteByName_whenOnlyCacheNameProvided() {
    clearInvocations(redisCacheOperationService);

    assertEquals(
        HttpStatus.OK,
        userConfigurationController.clearRedisCache("cache-only", null).getStatusCode());

    verify(redisCacheOperationService, times(1)).deleteCacheByCacheName("cache-only");
  }

  @Test
  public void userOktaStatusSync_shouldDelegate_andReturnNoContent() {
    OktaStatusSyncRequest request = new OktaStatusSyncRequest();

    assertEquals(HttpStatus.NO_CONTENT, userConfigurationController.userOktaStatusSync(request).getStatusCode());
    verify(userConfigurationDataSyncService, times(1)).userOktaStatusSync(request);
  }

  @Test(expected = FumServiceException.class)
  public void createUserConfiguration_shouldThrow_whenBmaInProgress() {
    User mockUser = new User();
    mockUser.setIdpSubject("testSubject");
    SecurityContextHolder.getContext().setAuthentication(
        new UsernamePasswordAuthenticationToken(mockUser, null));

    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setFirmId("FIRM001");

    when(firmBmaGuardService.isFirmBmaInProgress("FIRM001")).thenReturn(true);

    try {
      userConfigurationController.createUserConfiguration("Bearer token", userConfiguration, "nbin");
    } finally {
      SecurityContextHolder.clearContext();
    }
  }

  @Test
  public void createUserConfiguration_shouldNotThrow_whenBmaNotInProgress() {
    User mockUser = new User();
    mockUser.setIdpSubject("testSubject");
    SecurityContextHolder.getContext().setAuthentication(
        new UsernamePasswordAuthenticationToken(mockUser, null));

    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setFirmId("FIRM001");

    when(firmBmaGuardService.isFirmBmaInProgress("FIRM001")).thenReturn(false);
    when(auditLogService.publishAuditLog(any(), any(), any(), any())).thenReturn(userConfiguration);

    try {
      userConfigurationController.createUserConfiguration("Bearer token", userConfiguration, "nbin");
      // No exception means the BMA guard allowed the request through
    } catch (FumServiceException e) {
      // Should not be a BMA-related exception
      if (BulkUserConstants.ERROR_FIRM_BMA_IN_PROGRESS.equals(e.getCode())) {
        throw new AssertionError("BMA guard should not have blocked the request");
      }
    } catch (Exception e) {
      // Other exceptions (downstream mocks not configured) are expected — the BMA guard passed
    } finally {
      SecurityContextHolder.clearContext();
    }

    verify(firmBmaGuardService, times(1)).isFirmBmaInProgress("FIRM001");
  }
}
