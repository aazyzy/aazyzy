package ca.bnc.wealth.api.userconfiguration.controller;

import static ca.bnc.wealth.api.userconfiguration.util.MockData.USER_EMAIL;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.USER_NAME_LABEL;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.getFeaturePackage;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.getUserGroupEntity;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.getUserGroupList;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.authorization.security.SecurityConfigAdapter;
import ca.bnc.wealth.api.authorization.security.test.TestAuthConfiguration;
import ca.bnc.wealth.api.authorization.security.test.TestUserSingleton;
import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.userconfiguration.model.AssignmentType;
import ca.bnc.wealth.api.userconfiguration.service.AuditLogService;
import ca.bnc.wealth.api.userconfiguration.service.AuthorizationClient;
import ca.bnc.wealth.api.userconfiguration.service.FirmBmaGuardService;
import ca.bnc.wealth.api.userconfiguration.service.TokenRevocationService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigSearchMaterializedRefreshService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigValidationService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigurationDataSyncService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigurationService;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigurationServiceJpa;
import ca.bnc.wealth.api.userconfiguration.service.UserExtractService;
import ca.bnc.wealth.api.userconfiguration.service.UserService;
import ca.bnc.wealth.api.userconfiguration.service.UserStateService;
import ca.bnc.wealth.api.userconfiguration.service.UserValidationService;
import ca.bnc.wealth.api.userconfiguration.util.MockData;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ErrorSeverity;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.NoResultsFoundException;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ServiceException;
import ca.bnc.wealth.common.userconfiguration.model.ApiError;
import ca.bnc.wealth.common.userconfiguration.model.ApiMessage;
import ca.bnc.wealth.common.userconfiguration.model.AssignRequest;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearch;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearchResponse;
import ca.bnc.wealth.common.userconfiguration.model.GroupByResponse;
import ca.bnc.wealth.common.userconfiguration.model.PageInfo;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.RRRange;
import ca.bnc.wealth.common.userconfiguration.model.ResourceName;
import ca.bnc.wealth.common.userconfiguration.model.UamaUpdateUserExternalId;
import ca.bnc.wealth.common.userconfiguration.model.UpdateUserStatus;
import ca.bnc.wealth.common.userconfiguration.model.UpdateUserStatus.StatusEnum;
import ca.bnc.wealth.common.userconfiguration.model.UserAssignment;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserCredentials;
import ca.bnc.wealth.common.userconfiguration.model.UserExternalSystemConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserGroupName;
import ca.bnc.wealth.common.userconfiguration.model.UserIdentity;
import ca.bnc.wealth.common.userconfiguration.model.UserOktaProfile;
import ca.bnc.wealth.common.userconfiguration.model.UserPreferredLanguage;
import ca.bnc.wealth.common.userconfiguration.model.UserSearch;
import ca.bnc.wealth.common.userconfiguration.model.Users;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc(addFilters = false)
@ContextConfiguration(
    classes = {
      SecurityConfigAdapter.class,
      TestAuthConfiguration.class,
      UserConfigurationController.class,
      UserConfigurationController.class,
      ca.bnc.wealth.common.exception.handler.ServiceExceptionHandler.class,
      ca.bnc.wealth.common.spring.microservice.starter.core.exception.GlobalDefaultExceptionHandler
          .class
    })
@WebMvcTest(properties = {"spring.profiles.active=test"})
@Slf4j
public class UserConfigurationControllerTests {

  private static final String USER_DATA = "User Data";
  @Autowired ObjectMapper objectMapper;
  String accessToken =
      "Bearer eyJraWQiOiJRdUZPcVhpYkwwYjc0emltbDNaYmU5NnNPWEpJMlNpRGR4ZThkZThlZG13IiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULjVfcTQwRlY2OHM3TlJSX1pQTERFLTdyemtNYmFIZnVLdjV1cnVGSVNDQjAiLCJpc3MiOiJodHRwczovL2F1dGgtcHAubmJpbi5jYS9vYXV0aDIvYXVzc2c0d3lkMkhaRUJHUjMwaDciLCJhdWQiOiJhcGk6Ly9kZWZhdWx0IiwiaWF0IjoxNjQ1MjgxMzc3LCJleHAiOjE2NDUyODE2NzcsImNpZCI6IjBvYTEwcmd6cThyTDNsQ1pHMGg4IiwidWlkIjoiMDB1MTRxa3BlZDNPSFZ5Qk0waDgiLCJzY3AiOlsiY2lhbTpwcm9maWxlczp3cml0ZSIsIndlYWx0aDphY2Nlc3MtY29udHJvbDp2aWV3ZXIiLCJvcGVuaWQiLCJjaWFtOnByb2ZpbGVzOnJlYWQiXSwic3ViIjoiMG9hMTByZ3pxOHJMM2xDWkcwaDgiLCJwcmVmZXJyZWRMYW5ndWFnZSI6ImVuIiwiYm5nZlNlY3VyZVpvbmVJZCI6WyJKT05FU01BIl0sImJuZ2ZJZGVudGl0eVNvdXJjZSI6IlNaIiwiYm5nZlBhcnRuZXJJZCI6IklBUyIsImdyb3VwcyI6WyJXZWFsdGguQ29tcGFzc1giLCJXZWFsdGguQ29tcGFzc1guVHJhZGVyIiwiV2VhbHRoIl19.dADByl5zkW4QP0WU3DhIdgPI9hipdYbDFnok8csB__a2_hqbHvFVWjD5BHEtNKOgSQVZ0L4sZazHPl0VlNOP8kArBWg80nx35ufYeXkrYGvT-1RK99KAZnhgnIQ77eSg-Ubb2ujbcx5cTiiFOKbeNLCK7UUSC7WHhzLMP39iXDhBIPfy3zI6NI-YfYgFVHzkbnNK-UpLZ09rq7hJMSJuef6P6xreooGXxenFIQHQAGhHTJPxBU85rG6cNLUbNrLG8mpQIgliDft5mZ7nNtZAq7o8DD0TGVNj4fUUyayb40WVmBOx0di6EHsfBnFQ8qtHGaT-hT7z8G-yX_V2NkmGbQ";
  @Autowired WebApplicationContext webApplicationContext;
  @Autowired private WebApplicationContext context;
  @Autowired private MockMvc mockMvc;
  @MockitoBean private UserConfigurationService userConfigurationService;
  @MockitoBean private UserConfigValidationService userConfigValidationService;
  @MockitoBean private UserConfigurationServiceJpa userConfigurationServiceJpa;
  @MockitoBean private UserConfigurationDataSyncService userConfigurationDataSyncService;
  @MockitoBean private UserExtractService userExtractService;
  @MockitoBean private UserAssignmentService userAssignmentService;
  @MockitoBean private UserService userService;
  @MockitoBean private UserValidationService userValidationService;
  @MockitoBean private AuthorizationClient authorizationClient;
  @MockitoBean private SystemTokenFactory systemTokenFactory;
  @MockitoBean private UserStateService userStateService;
  @MockitoBean private RedisCacheOperationService redisCacheOperationService;
  @MockitoBean private UserConfigSearchMaterializedRefreshService userConfigSearchMaterializedRefreshService;
  @MockitoBean private AuditLogService auditLogService;
  @MockitoBean private TokenRevocationService tokenRevocationService;
  @MockitoBean private FirmBmaGuardService firmBmaGuardService;

  public static User getMockUser() {
    User testUser = new User();
    testUser.setRoles(List.of("Jedi"));
    testUser.setIdpSubject("Mando");
    testUser.setSecureZoneIds(Arrays.asList("Test12", "Test34"));
    testUser.setIdpUserId("00u20kwe9opbMxPM00h8");
    testUser.setGroups(List.of("Wealth.CommonX", "Wealth.Common.Trader"));
    return testUser;
  }

  @Before
  public void setup() {
    mockMvc = MockMvcBuilders.webAppContextSetup(context).apply(springSecurity()).build();
  }

  @AfterEach
  public void cleanUp() {
    TestUserSingleton.setTestUser(null);
    TestUserSingleton.USER_IS_UNAUTHORIZED = false;
  }

  @Test
  public void test_getRRCodes() throws Exception {
    List<RRCodeRange> rrCodeRanges = mock(List.class);
    when(userService.getRRCodeListByIdpSubject(anyString(), anyBoolean())).thenReturn(rrCodeRanges);
    TestUserSingleton.setTestUser(getMockUser());
    MvcResult mvcResult =
        this.mockMvc
            .perform(get("/users/me/rr-codes").header(HttpHeaders.AUTHORIZATION, ""))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_getUserExternalSystemConfiguration() {
    UserExternalSystemConfiguration userExternalSystemConfiguration =
        MockData.getUserExternalSystemConfiguration();
    when(userService.getUserExternalSystemConfiguration(anyString(), anyString()))
        .thenReturn(userExternalSystemConfiguration);

    try {
      MvcResult mvcResult =
          this.mockMvc
              .perform(
                  get("/users/me/{external-system-id}", "CompassR2")
                      .contentType(MediaType.APPLICATION_JSON)
                      .header(HttpHeaders.AUTHORIZATION, accessToken))
              .andExpect(status().isOk())
              .andReturn();

      UserExternalSystemConfiguration response =
          objectMapper.readValue(
              mvcResult.getResponse().getContentAsString(), UserExternalSystemConfiguration.class);
      assertEquals(userExternalSystemConfiguration.getCompassR2Id(), response.getCompassR2Id());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_getUserExternalSystemConfigurationByUserId() {
    UserExternalSystemConfiguration userExternalSystemConfiguration =
        MockData.getUserExternalSystemConfiguration();
    when(userService.getUserExternalSystemConfiguration(anyInt(), anyString()))
        .thenReturn(userExternalSystemConfiguration);

    try {
      MvcResult mvcResult =
          this.mockMvc
              .perform(
                  get("/users/{user-id}/{external-system-id}", 1234, "CompassR2")
                      .contentType(MediaType.APPLICATION_JSON)
                      .header(HttpHeaders.AUTHORIZATION, accessToken))
              .andExpect(status().isOk())
              .andReturn();

      UserExternalSystemConfiguration response =
          objectMapper.readValue(
              mvcResult.getResponse().getContentAsString(), UserExternalSystemConfiguration.class);
      assertEquals(userExternalSystemConfiguration.getCompassR2Id(), response.getCompassR2Id());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_getUserConfiguration_Valid() throws Exception {
    UserConfiguration userConf = new UserConfiguration();
    when(userService.getUserConfiguration(anyString())).thenReturn(userConf);
    MvcResult mvcResult =
        this.mockMvc
            .perform(get("/users/me").header(HttpHeaders.AUTHORIZATION, accessToken))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_getUserConfiguration_NotFound() throws Exception {
    UserConfiguration userConf = new UserConfiguration();
    when(userService.getUserConfiguration(anyString())).thenReturn(userConf);
    doThrow(new EmptyResultDataAccessException(0))
        .when(userService)
        .getUserConfiguration(anyString());
    MvcResult mvcResult =
        this.mockMvc
            .perform(get("/users/me").header(HttpHeaders.AUTHORIZATION, accessToken))
            .andExpect(status().isNotFound())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_getUserConfiguration_ValidWithExternalIds() throws Exception {
    UserConfiguration userConf = new UserConfiguration();
    userConf.setActive("username");
    when(userService.getUserConfiguration(any())).thenReturn(userConf);
    when(userService.getCompassR2Id(anyString())).thenReturn("r2");
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get("/users/me?getExternalId=true").header(HttpHeaders.AUTHORIZATION, accessToken))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_getUserConfiguration_whenExternalIdFalse_ValidWithExternalIds() throws Exception {
    UserConfiguration userConf = new UserConfiguration();
    userConf.setActive("username");
    when(userService.getUserConfiguration(any())).thenReturn(userConf);
    when(userService.getCompassR2Id(anyString())).thenReturn("r2");
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get("/users/me?getExternalId=false").header(HttpHeaders.AUTHORIZATION, accessToken))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_getUserConfiguration_whenExternalIdNull_ValidWithExternalIds() throws Exception {
    UserConfiguration userConf = new UserConfiguration();
    userConf.setActive("username");
    when(userService.getUserConfiguration(any())).thenReturn(userConf);
    when(userService.getCompassR2Id(anyString())).thenReturn("r2");
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get("/users/me").header(HttpHeaders.AUTHORIZATION, accessToken))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_getUserConfiguration_InValid() throws Exception {
    UserConfiguration userConf = mock(UserConfiguration.class);
    when(userService.getUserConfiguration(anyString())).thenReturn(userConf);
    TestUserSingleton.USER_IS_UNAUTHORIZED = true;
    MvcResult mvcResult =
        this.mockMvc.perform(get("/users/me")).andExpect(status().isUnauthorized()).andReturn();
    assert (mvcResult.getResponse().getContentLength() == 0);
  }

  @Test
  public void test_MockUserWithUserId() throws Exception {
    UserConfiguration userConf = new UserConfiguration();
    userConf.setActive("username");
    userConf.setIdpSubject("testIdpSubject");
    userConf.setUserConfigurationId(1);
    when(userService.getUserConfigurationWithRrCodeById(anyInt())).thenReturn(userConf);
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(userConf);
    ;
    when(userService.getUserConfiguration(anyString())).thenReturn(userConf);
    TestUserSingleton.setTestUser(getMockUser());
    MvcResult mvcResult =
        this.mockMvc
            .perform(get("/users/1234").header(HttpHeaders.AUTHORIZATION, ""))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_MockUserWithUserIdAndExternalId() throws Exception {
    UserConfiguration userConf = new UserConfiguration();
    userConf.setActive("username");
    userConf.setIdpSubject("testIdpSubject");
    userConf.setUserConfigurationId(1);
    when(userService.getUserConfigurationWithRrCodeById(anyInt())).thenReturn(userConf);
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(userConf);
    when(userService.getCompassR2Id(anyString())).thenReturn("r2");
    when(userService.getSecureZoneId(anyString())).thenReturn(new String[] {"szId"});
    TestUserSingleton.setTestUser(getMockUser());
    MvcResult mvcResult =
        this.mockMvc
            .perform(get("/users/1234?getExternalId=true").header(HttpHeaders.AUTHORIZATION, ""))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Ignore
  @Test
  public void test_MockUserNotFound() throws Exception {
    when(userService.getUserConfiguration(anyString()))
        .thenThrow(new NoResultsFoundException("No user exists"));
    MvcResult mvcResult =
        this.mockMvc
            .perform(get("/users/me").header(HttpHeaders.AUTHORIZATION, accessToken))
            .andExpect(status().is5xxServerError())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  @Ignore("Ignoring")
  public void test_MockUserWithUserIdNotFound() throws Exception {
    when(userService.getUserConfigurationById(anyInt()))
        .thenThrow(new NoResultsFoundException("No user exists"));
    MvcResult mvcResult =
        this.mockMvc
            .perform(get("/users/1234").header(HttpHeaders.AUTHORIZATION, accessToken))
            .andExpect(status().isNotFound())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_postUserSearch() throws Exception {
    UserSearch userSearch = MockData.createUserSearch();
    String json = objectMapper.writeValueAsString(userSearch);
    List<UserConfiguration> userConfList = new ArrayList<>();
    UserConfiguration userConf = mock(UserConfiguration.class);
    userConfList.add(userConf);
    when(userService.searchUsers(anyString(), any(UserSearch.class))).thenReturn(userConfList);
    when(userService.getIdpSubjectFromPrincipalOrUserToken(anyString())).thenReturn("idpSubject");
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                post("/users/search")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .header("cx-usr-access", "token")
                    .with(csrf())
                    .content(json)
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_postUserSearch_idpSubjectNull() throws Exception {
    UserSearch userSearch = MockData.createUserSearch();
    String json = objectMapper.writeValueAsString(userSearch);
    List<UserConfiguration> userConfList = new ArrayList<>();
    UserConfiguration userConf = mock(UserConfiguration.class);
    userConfList.add(userConf);
    when(userService.searchUsers(anyString(), any(UserSearch.class))).thenReturn(userConfList);
    when(userService.getIdpSubjectFromPrincipalOrUserToken(anyString())).thenReturn(null);
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                post("/users/search")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .header("cx-usr-access", "token")
                    .with(csrf())
                    .content(json)
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isUnauthorized())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_postUserSearch_withUserNameAndEmailAndRRCode() throws Exception {
    UserSearch userSearch = MockData.createUserSearch();
    String json = objectMapper.writeValueAsString(userSearch);
    TestUserSingleton.setTestUser(getMockUser());
    List<UserConfiguration> userConfList = new ArrayList<>();
    UserConfiguration userConf = new UserConfiguration();
    userConf.setEmail(USER_EMAIL);
    userConf.setUsername(USER_NAME_LABEL);
    userConfList.add(userConf);
    when(userService.searchUsers(getMockUser().getIdpSubject(), userSearch))
        .thenReturn(userConfList);
    when(userService.getIdpSubjectFromPrincipalOrUserToken(anyString()))
        .thenReturn(getMockUser().getIdpSubject());
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                post("/users/search")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .header("cx-usr-access", "token")
                    .with(csrf())
                    .content(json)
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(MockMvcResultMatchers.jsonPath("[0].username").value(USER_NAME_LABEL))
            .andReturn();
  }

  @Ignore
  @Test
  public void test_genericSearch_withGroupBy() throws Exception {
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("TEST");
    String json = objectMapper.writeValueAsString(userSearch);

    List<UserConfiguration> userConfList = new ArrayList<>();
    UserConfiguration userConf = new UserConfiguration();
    userConf.setEmail(USER_EMAIL);
    userConf.setUsername(USER_NAME_LABEL);
    userConf.setFirmId("NBIN");
    userConfList.add(userConf);

    List<GroupByResponse> responses = new ArrayList<>();
    responses.add(new GroupByResponse().groupKey("NBIN").groupData(userConfList));

    GenericSearchResponse genericSearchResponse = new GenericSearchResponse();
    genericSearchResponse.setCurrentFirmUsers(responses);

    responses.add(new GroupByResponse().groupKey("Firm2").groupData(userConfList));
    genericSearchResponse.setOtherFirmUsers(responses);
    when(userService.genericUserSearchWithPagination(any(), any()))
        .thenReturn(genericSearchResponse);

    mockMvc
        .perform(
            post("/users/genericSearch")
                .header(HttpHeaders.AUTHORIZATION, "")
                .param("groupBy", "FIRM_ID")
                .with(csrf())
                .content(json)
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andExpect(MockMvcResultMatchers.jsonPath("[0].groupKey").value("NBIN"))
        .andExpect(MockMvcResultMatchers.jsonPath("[1].groupKey").value("Firm2"))
        .andReturn();
  }

  @Ignore
  @Test
  public void test_genericSearch2() throws Exception {
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("TEST");
    String json = objectMapper.writeValueAsString(userSearch);
    TestUserSingleton.setTestUser(getMockUser());
    List<UserConfiguration> userConfList = new ArrayList<>();
    UserConfiguration userConf = new UserConfiguration();
    userConf.setEmail(USER_EMAIL);
    userConf.setUsername(USER_NAME_LABEL);
    userConf.setFirmId("NBIN");
    userConfList.add(userConf);
    List<GroupByResponse> responses = new ArrayList<>();
    responses.add(new GroupByResponse().groupKey("NBIN").groupData(userConfList));
    GenericSearchResponse genericSearchResponse = new GenericSearchResponse();
    genericSearchResponse.setCurrentFirmUsers(responses);
    genericSearchResponse.setOtherFirmUsers(new ArrayList<>());
    when(userService.genericUserSearchWithPagination(getMockUser().getIdpSubject(), userSearch))
        .thenReturn(genericSearchResponse);
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                post("/users/genericSearch")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(json)
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(MockMvcResultMatchers.jsonPath("[0].groupKey").value("NBIN"))
            .andReturn();
  }

  @Test
  public void test_genericSearchWithPagination() throws Exception {
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("TEST");
    String json = objectMapper.writeValueAsString(userSearch);

    when(userService.genericUserSearchWithPagination(any(), any()))
        .thenReturn(new GenericSearchResponse());
    mockMvc
        .perform(
            post("/users/genericSearchWithPagination")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(json)
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andReturn();
  }

  @Test
  public void test_refreshUserSearchMaterializedView() throws Exception {
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("TEST");
    String json = objectMapper.writeValueAsString(userSearch);

    mockMvc
        .perform(
            post("/users/refreshMaterializedView")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(json)
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andReturn();
  }

  @Test
  public void test_genericSearchWithIllegalAccessException() throws Exception {
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("TEST");
    String json = objectMapper.writeValueAsString(userSearch);

    when(userService.materializedViewSearch(any(), any())).thenThrow(RuntimeException.class);
    mockMvc
        .perform(
            post("/users/genericSearchWithPagination")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(json)
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isInternalServerError())
        .andReturn();
  }

  @Test
  public void test_createUserConfiguration() throws Exception {
    UserConfiguration userConf = MockData.getUserConfiguration();
    String json = objectMapper.writeValueAsString(userConf);
    doReturn(userConf)
        .when(userConfigurationService)
        .createUserConfigInDatabase(any(UserConfiguration.class), anyString());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                post("/users")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(json)
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_createUserConfigurationNonNbinUser() throws Exception {
    UserConfiguration userConf = MockData.getUserConfiguration();
    String json = objectMapper.writeValueAsString(userConf);
    doReturn(userConf)
        .when(userConfigurationService)
        .createUserConfigInDatabase(any(UserConfiguration.class), anyString());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                post("/users?idp=nbc")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(json)
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_createUserConfigurationWithHashedPassword() throws Exception {
    String hash = "$2a$12$oXag6QzQfCFxF13b7xv3mONFqtWJSqb7IYmQgizjOGG71leQFN6B2";
    UserConfiguration userConf = MockData.getUserConfiguration();
    userConf.setHashedPassword(hash);

    doReturn(userConf)
        .when(userConfigurationService)
        .createUserConfigInDatabase(any(UserConfiguration.class), any());
    String json = objectMapper.writeValueAsString(userConf);

    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    AtomicReference<String> hashSentToOkta = new AtomicReference<>();
    doAnswer(invocation -> {
          hashSentToOkta.set(invocation.<UserConfiguration>getArgument(0).getHashedPassword());
          return null;
        })
        .when(userConfigurationService)
        .completeUserCreationWithOkta(any(UserConfiguration.class));

    MvcResult mvcResult =
        mockMvc
            .perform(
                post("/users")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(json)
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.password").doesNotExist())
            .andExpect(jsonPath("$.hashedPassword").doesNotExist())
            .andReturn();
    assertNotNull(mvcResult);
    assertEquals(hash, hashSentToOkta.get());
  }

  @Test
  public void test_createUserConfiguration_shouldReturnServerGeneratedPassword() throws Exception {
    UserConfiguration request = MockData.getUserConfiguration();
    request.setPassword(null);
    UserConfiguration created = MockData.getUserConfiguration();
    created.setPassword("Generated#Pwd1");
    doReturn(created)
        .when(userConfigurationService)
        .createUserConfigInDatabase(any(UserConfiguration.class), any());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });

    mockMvc
        .perform(
            post("/users")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(request))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.password").value("Generated#Pwd1"));
  }

  @Test
  public void test_createUserConfiguration_withValidationErrors() throws Exception {
    UserConfiguration userConf = MockData.getUserConfiguration();
    String json = objectMapper.writeValueAsString(userConf);
    doReturn(userConf)
        .when(userConfigurationService)
        .createUserConfigInDatabase(any(UserConfiguration.class), anyString());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    mockMvc
        .perform(
            post("/users")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(json)
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andReturn();
  }

  @Test
  public void test_createUserConfigurationWithSourceIdpSubject_withValidationErrors() throws Exception {
    UserConfiguration userConf = MockData.getUserConfiguration();
    userConf.setSourceIdpSubject("sourceIdpSubject");
    String json = objectMapper.writeValueAsString(userConf);
    doReturn(userConf)
        .when(userConfigurationService)
        .createUserConfigInDatabase(any(UserConfiguration.class), anyString());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    mockMvc
        .perform(
            post("/users")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(json)
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andReturn();
  }

  @Test
  public void test_getOktaProfile() throws Exception {
    OktaUserProfile oktaUserProfile = MockData.getOktaUserProfile();
    ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().build();
    UserOktaProfile userOktaProfile =
        objectMapper.readValue(
            objectMapper.writeValueAsString(oktaUserProfile), UserOktaProfile.class);
    when(userService.getOktaProfileOrEmpty(anyString())).thenReturn(userOktaProfile);
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get("/users/testId/oktaProfile").header(HttpHeaders.AUTHORIZATION, accessToken))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_getOktaProfile_whenEmployeeHasNoOktaProfile_shouldReturnEmptyObjectWithOk()
      throws Exception {
    when(userService.getOktaProfileOrEmpty(anyString())).thenReturn(new UserOktaProfile());
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get("/users/employeeId/oktaProfile").header(HttpHeaders.AUTHORIZATION, accessToken))
            .andExpect(status().isOk())
            .andReturn();
    assertEquals("{}", mvcResult.getResponse().getContentAsString());
  }

  @Test
  public void test_getOktaProfile_whenUserNotFound_shouldReturn404() throws Exception {
    when(userService.getOktaProfileOrEmpty(anyString())).thenThrow(FumNotFoundException.class);
    this.mockMvc
        .perform(
            get("/users/unknownId/oktaProfile").header(HttpHeaders.AUTHORIZATION, accessToken))
        .andExpect(status().isNotFound());
  }

  @Test
  public void testDeleteUser2fa() throws Exception {
    doNothing().when(userService).deleteUser2FA(anyString());
    UserConfiguration userConfiguration = UserConfiguration.builder().idp("nbin").build();
    when(userService.getUserConfiguration(any())).thenReturn(userConfiguration);
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    MvcResult mvcResult =
        this.mockMvc
            .perform(delete("/users/1/sms2fa").header(HttpHeaders.AUTHORIZATION, accessToken))
            .andExpect(status().isNoContent())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_postUserSearch_throwException() throws Exception {
    UserSearch userSearch = mock(UserSearch.class);
    String json = objectMapper.writeValueAsString(userSearch);
    doThrow(new IllegalAccessException())
        .when(userService)
        .searchUsers(anyString(), any(UserSearch.class));
    when(userService.getIdpSubjectFromPrincipalOrUserToken(anyString())).thenReturn("idpSubject");
    try {
      MvcResult mvcResult =
          this.mockMvc
              .perform(
                  post("/users/search")
                      .header(HttpHeaders.AUTHORIZATION, "")
                      .header("cx-usr-access", "token")
                      .with(csrf())
                      .content(json)
                      .accept(MediaType.APPLICATION_JSON)
                      .contentType(MediaType.APPLICATION_JSON))
              .andReturn();
      assertEquals(mvcResult.getResponse().getStatus(), HttpStatus.INTERNAL_SERVER_ERROR.value());
    } catch (Exception e) {

    }
  }

  @Test
  public void test_getRecoveryQuestions() throws Exception {
    HashMap<String, String> map = new HashMap<>();
    map.put("question.1", "What is the food you least liked as a child?");
    when(userService.getRecoveryQuestions(anyString(), anyString())).thenReturn(map);
    TestUserSingleton.setTestUser(getMockUser());
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get("/users/recoveryQuestions")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .header(HttpHeaders.ACCEPT_LANGUAGE, "En"))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
    assertTrue(
        mvcResult
            .getResponse()
            .getContentAsString()
            .contains("What is the food you least liked as a child?"));
  }

  @Test
  public void test_whenSuspendUserIsSuccessful_shouldReturn204() throws Exception {
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(new UserConfiguration());
    doNothing().when(userService).validateIsUserSuspended(any());
    doNothing().when(userService).updateLastUpdatedBy(any(), any());
    doNothing().when(userConfigurationServiceJpa).updateUserConfigState(anyInt(), any());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    mockMvc
        .perform(put("/users/1234/suspend").header(HttpHeaders.AUTHORIZATION, accessToken))
        .andExpect(status().isNoContent());
  }

  @Test
  public void test_whenSuspendUserIsUnsuccessful_shouldThrowException() throws Exception {
    String errorMessage = "Error suspending user Okta profile";
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(new UserConfiguration());
    doNothing().when(userService).validateIsUserSuspended(any());
    doNothing().when(userService).updateLastUpdatedBy(any(), any());
    doNothing().when(userConfigurationServiceJpa).updateUserConfigState(anyInt(), any());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    doThrow(new ServiceException(ErrorSeverity.ERROR, errorMessage))
        .when(userService)
        .suspendUserOktaProfile(any());

    MvcResult mvcResult =
        mockMvc
            .perform(put("/users/1234/suspend").header(HttpHeaders.AUTHORIZATION, accessToken))
            .andExpect(status().isInternalServerError())
            .andReturn();

    ApiError apiError =
        objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ApiError.class);
    validateApiError(HttpStatus.INTERNAL_SERVER_ERROR, errorMessage, apiError);
  }

  @Test
  public void test_whenUnsuspendUserIsSuccessful_shouldReturn204() throws Exception {
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(new UserConfiguration());
    doNothing().when(userService).validateIsUserSuspended(any());
    doNothing().when(userService).updateLastUpdatedBy(any(), any());
    doNothing().when(userConfigurationServiceJpa).updateUserConfigState(anyInt(), any());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    mockMvc
        .perform(put("/users/1234/unsuspend").header(HttpHeaders.AUTHORIZATION, accessToken))
        .andExpect(status().isNoContent());
  }

  @Test
  public void test_whenUnsuspendUserIsUnsuccessful_shouldThrowException() throws Exception {
    String errorMessage = "Error suspending user Okta profile";
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(new UserConfiguration());
    doNothing().when(userService).validateIsUserSuspended(any());
    doNothing().when(userService).updateLastUpdatedBy(any(), any());
    doNothing().when(userConfigurationServiceJpa).updateUserConfigState(anyInt(), any());
    doThrow(new ServiceException(ErrorSeverity.ERROR, errorMessage))
        .when(userService)
        .unsuspendUserOktaProfile(any());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });

    MvcResult mvcResult =
        mockMvc
            .perform(put("/users/1234/unsuspend").header(HttpHeaders.AUTHORIZATION, accessToken))
            .andExpect(status().isInternalServerError())
            .andReturn();

    ApiError apiError =
        objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ApiError.class);
    validateApiError(HttpStatus.INTERNAL_SERVER_ERROR, errorMessage, apiError);
  }

  @Test
  public void test_createUserConfigurationException() throws Exception {

    UserConfiguration userConf = MockData.getUserConfiguration();
    String json = objectMapper.writeValueAsString(userConf);
    when(userConfigurationService.createUserConfigInDatabase(any(), any()))
        .thenThrow(new ServiceException(ErrorSeverity.ERROR, "error occurs"));
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                post("/users")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(json)
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isInternalServerError())
            .andReturn();
  }

  @Test
  public void test_updateUserConfigurationByUserIdPost() throws Exception {

    UserConfiguration userConf = MockData.getUserConfiguration();
    String json = objectMapper.writeValueAsString(userConf);
    UserConfiguration userConfigurationInput = MockData.getUserConfiguration();
    userConfigurationInput.setFeaturePackage(MockData.getFeaturePackage());
    UserConfiguration mockUserConfiguration = MockData.getUserConfiguration();
    mockUserConfiguration.setIdp("nbc");
    mockUserConfiguration.setFeaturePackage(getFeaturePackage());
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(mockUserConfiguration);
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                post("/users/123")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(json)
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().is2xxSuccessful())
            .andReturn();
  }

  @Ignore
  @Test
  public void test_GenericSearch_throwException() throws Exception {

    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("TEST");
    String json = objectMapper.writeValueAsString(userSearch);

    when(userService.genericUserSearchWithPagination(any(), any()))
        .thenThrow(new IllegalAccessException());
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                post("/users/genericSearch")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(json)
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isInternalServerError())
            .andReturn();
  }

  @Test
  public void test_whenGetRRCodesByUserIdIsSuccessful_shouldReturn200() throws Exception {
    List<RRCodeRange> rrCodeRangeListExpected = MockData.createMockRRCodeList();
    when(userService.getUserIdpSubjectById(anyInt())).thenReturn("1234");
    when(userService.getRRCodeListByIdpSubject(anyString(), anyBoolean()))
        .thenReturn(rrCodeRangeListExpected);

    MvcResult mvcResult =
        mockMvc
            .perform(
                get("/users/1234/assignments/rr-code?active=true")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf()))
            .andExpect(status().isOk())
            .andReturn();

    List<RRCodeRange> rrCodeRangeListActual =
        objectMapper.readValue(
            mvcResult.getResponse().getContentAsString(), new TypeReference<>() {});
    assertThat(rrCodeRangeListActual, is(rrCodeRangeListExpected));
  }

  @Test
  public void test_whenGetRRCodesByUserNameIsSuccessful_shouldReturn200() throws Exception {
    List<RRCodeRange> rrCodeRangeListExpected = MockData.createMockRRCodeList();
    when(userService.getUserIdpSubjectById(anyInt())).thenReturn("1234");
    when(userService.getRRCodeListByIdpSubject(anyString(), anyBoolean()))
        .thenReturn(rrCodeRangeListExpected);

    MvcResult mvcResult =
        mockMvc
            .perform(
                get("/users/1234/assignments/rr-code?active=false")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf()))
            .andExpect(status().isOk())
            .andReturn();

    List<RRCodeRange> rrCodeRangeListActual =
        objectMapper.readValue(
            mvcResult.getResponse().getContentAsString(), new TypeReference<>() {});
    assertThat(rrCodeRangeListActual, is(rrCodeRangeListExpected));
  }

  @Test
  public void test_whenGetRRCodesByUserIdNotFound_shouldReturn404() throws Exception {
    String errorMessage = "User userId not found";
    when(userService.getUserIdpSubjectById(anyInt()))
        .thenThrow(new NoResultsFoundException(errorMessage));

    MvcResult mvcResult =
        mockMvc
            .perform(
                get("/users/1234/assignments/rr-code")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf()))
            .andExpect(status().isNotFound())
            .andReturn();

    ApiError apiError =
        objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ApiError.class);
    validateApiError(HttpStatus.NOT_FOUND, errorMessage, apiError);
  }

  @Test
  public void test_whenGetRRCodesByUserIdCallFails_shouldReturn500() throws Exception {
    when(userService.getUserIdpSubjectById(anyInt())).thenReturn("123");
    when(userService.getRRCodeListByIdpSubject(anyString(), anyBoolean()))
        .thenThrow(new RuntimeException("Error"));

    MvcResult mvcResult =
        mockMvc
            .perform(
                get("/users/1234/assignments/rr-code?active=false")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf()))
            .andExpect(status().isInternalServerError())
            .andReturn();

    ApiError apiError =
        objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ApiError.class);
    validateApiError(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to execute request.", apiError);
  }

  @Test
  public void test_downloadUserData() throws Exception {
    when(userExtractService.getExtract(anyInt())).thenReturn(new byte[0]);
    when(userExtractService.getUserDataInCsvByteArray(any())).thenReturn(USER_DATA.getBytes());
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get("/users/download")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
    assertEquals(USER_DATA, mvcResult.getResponse().getContentAsString());
  }

  @Test
  public void test_downloadUserData_isInProgress() throws Exception {
    when(userExtractService.getExtract(anyInt())).thenReturn(null);
    when(userExtractService.getUserDataInCsvByteArray(any())).thenReturn(null);
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get("/users/download")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isAccepted())
            .andReturn();
    assertNotNull(mvcResult);
    assertEquals(
        "The user extract request is in progress. Please try again later.",
        mvcResult.getResponse().getContentAsString());
  }

  @Test
  public void test_downloadUserData_throwsFumServiceException() throws Exception {
    when(userExtractService.getUserDataInCsvByteArray(any())).thenThrow(FumServiceException.class);
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get("/users/download")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isInternalServerError())
            .andReturn();
    assertNotNull(mvcResult);
    assertEquals(
        "The file failed to generate. Please try again later.",
        mvcResult.getResponse().getContentAsString());
  }

  @Test
  public void test_getUserConfigurationsByFirmId() throws Exception {

    List<UserConfiguration> userConfigurations = MockData.getUserConfigurationList();

    Users users = new Users();
    users.setUsers(userConfigurations);
    when(userService.getUserConfigurationsByFirmId(any(), anyString(), any())).thenReturn(users);
    MvcResult mvcResult =
        this.mockMvc
            .perform(get("/users/123/assignments/users").header(HttpHeaders.AUTHORIZATION, ""))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_getUserConfigurationWithPaginationByFirmId() throws Exception {

    List<UserConfiguration> userConfigurations = MockData.getUserConfigurationList();

    Users users = new Users();
    users.setUsers(userConfigurations);
    PageInfo pageInfo = new PageInfo();
    pageInfo.setPageNumber(20);
    pageInfo.setPageSize(50);
    String json = objectMapper.writeValueAsString(pageInfo);
    when(userService.getUserConfigurationsByFirmId(any(), anyString(), any())).thenReturn(users);
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                post("/users/123/assignments/users")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(json)
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_updatePreferredLanguage_shouldReturn204() throws Exception {
    UserPreferredLanguage userPreferredLanguage = new UserPreferredLanguage();
    userPreferredLanguage.setPreferredLanguage(UserPreferredLanguage.PreferredLanguageEnum.EN);

    User user = getMockUser();
    user.setUserConfigurationId(1);
    TestUserSingleton.setTestUser(user);
    when(userService.getUserConfiguration(anyString())).thenReturn(MockData.getUserConfigurationList().get(0));
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    mockMvc
        .perform(
            put("/users/me/preferredLanguage")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(userPreferredLanguage))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNoContent());
  }

  @Test
  public void test_whenUpdatePreferredLanguagePayloadIsInvalid_shouldReturn400() throws Exception {
    String errorMessage = "Error";
    doThrow(new IllegalArgumentException(errorMessage))
        .when(userConfigValidationService)
        .validateUserPreferredLanguage(any(UserPreferredLanguage.class));
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    TestUserSingleton.setTestUser(getMockUser());
    MvcResult mvcResult =
        mockMvc
            .perform(
                put("/users/me/preferredLanguage")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(objectMapper.writeValueAsString(new UserPreferredLanguage()))
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isBadRequest())
            .andReturn();

    ApiError apiError =
        objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ApiError.class);
    validateApiError(HttpStatus.BAD_REQUEST, errorMessage, apiError);
  }

  @Test
  public void test_CreateUserIdentity_withoutIdToken() throws Exception {
    UserIdentity userIdentity = new UserIdentity();
    userIdentity.setIdToken("");

    TestUserSingleton.setTestUser(getMockUser());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    mockMvc
        .perform(
            put("/users/me/identity")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(userIdentity))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andReturn();
  }

  @Test
  public void test_CreateUserIdentity_withIdToken() throws Exception {
    UserIdentity userIdentity = new UserIdentity();
    userIdentity.setIdToken("test");
    Map<String, Object> idTokenMap =
        Map.of(
            "login",
            "indall_aradhya.kalva",
            "firstName",
            "Aradhya",
            "lastName",
            "Kalva",
            "preferredLanguage",
            "en",
            "bngfReferenceId",
            "indall_aradhya.kalva",
            "bngfIdentitySource",
            "indall",
            "updateAt",
            "1709750398",
            "sub",
            "00u20kwe9opbMxPM00h8",
            "email",
            "aradhya.kalva@bnc.ca");
    when(userConfigurationService.validateAndFetchIdTokenClaims(userIdentity))
        .thenReturn(idTokenMap);
    when(userService.getUserConfiguration(any())).thenReturn(new UserConfiguration());
    TestUserSingleton.setTestUser(getMockUser());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    mockMvc
        .perform(
            put("/users/me/identity?internalAPICall=true")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(userIdentity))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andReturn();
  }

  @Test
  public void test_CreateUserIdentity_withEmployeeToken_shortCircuitsAndReturnsExistingConfig()
      throws Exception {
    UserIdentity userIdentity = new UserIdentity();
    userIdentity.setIdToken("test");
    // Employee/internal ID tokens carry no firm identity source (and no preferredLanguage/login).
    Map<String, Object> idTokenMap =
        Map.of(
            "firstName",
            "Alexandre",
            "lastName",
            "Razmakhnine",
            "bngfReferenceId",
            "RAZA002",
            "sub",
            "00u20kwe9opbMxPM00h8",
            "email",
            "alexandre.razmakhnine@bnc.ca");
    UserConfiguration existingConfig = MockData.getUserConfiguration();
    when(userConfigurationService.validateAndFetchIdTokenClaims(userIdentity))
        .thenReturn(idTokenMap);
    when(userService.getUserConfiguration(getMockUser().getIdpSubject()))
        .thenReturn(existingConfig);
    TestUserSingleton.setTestUser(getMockUser());

    MvcResult mvcResult =
        mockMvc
            .perform(
                put("/users/me/identity")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(objectMapper.writeValueAsString(userIdentity))
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();

    // The response body must be the user's existing configuration, returned unchanged.
    UserConfiguration responseBody =
        objectMapper.readValue(
            mvcResult.getResponse().getContentAsString(), UserConfiguration.class);
    assertEquals(existingConfig.getUserConfigurationId(), responseBody.getUserConfigurationId());
    assertEquals(existingConfig.getIdpSubject(), responseBody.getIdpSubject());

    // Short-circuit: the external-SSO mapping/update must NOT run for employee tokens.
    verify(userService, times(1)).getUserConfiguration(getMockUser().getIdpSubject());
    verify(userConfigurationService, times(0)).mapIdTokenClaimsToUserConfiguration(any(), any());
    verify(userConfigurationService, times(0))
        .updateUserConfigIdentityForExternalSSOUsers(any(), any(), any());
  }

  @Test
  public void test_CreateUserIdentity_withEmployeeToken_whenConfigNotFound_shouldReturn404()
      throws Exception {
    UserIdentity userIdentity = new UserIdentity();
    userIdentity.setIdToken("test");
    Map<String, Object> idTokenMap =
        Map.of(
            "firstName",
            "Alexandre",
            "lastName",
            "Razmakhnine",
            "bngfReferenceId",
            "RAZA002",
            "sub",
            "00u20kwe9opbMxPM00h8",
            "email",
            "alexandre.razmakhnine@bnc.ca");
    when(userConfigurationService.validateAndFetchIdTokenClaims(userIdentity))
        .thenReturn(idTokenMap);
    when(userService.getUserConfiguration(getMockUser().getIdpSubject()))
        .thenThrow(new FumNotFoundException("", "User not found"));
    TestUserSingleton.setTestUser(getMockUser());

    mockMvc
        .perform(
            put("/users/me/identity")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(userIdentity))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNotFound())
        .andReturn();

    verify(userConfigurationService, times(0)).mapIdTokenClaimsToUserConfiguration(any(), any());
  }

  @Test
  public void test_CreateUserIdentity_withUserDoesNotExist() throws Exception {
    UserIdentity userIdentity = new UserIdentity();
    userIdentity.setIdToken("test");
    Map<String, Object> idTokenMap =
        Map.of(
            "login",
            "indall_aradhya.kalva",
            "firstName",
            "Aradhya",
            "lastName",
            "Kalva",
            "preferredLanguage",
            "en",
            "bngfReferenceId",
            "indall_aradhya.kalva",
            "bngfIdentitySource",
            "indall",
            "updateAt",
            "1709750398",
            "sub",
            "00u20kwe9opbMxPM00h8",
            "email",
            "aradhya.kalva@bnc.ca");
    when(userConfigurationService.validateAndFetchIdTokenClaims(userIdentity))
        .thenReturn(idTokenMap);
    doThrow(new FumNotFoundException("", "User not found")).when(userService).getUserConfiguration(any());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    TestUserSingleton.setTestUser(getMockUser());

    mockMvc
        .perform(
            put("/users/me/identity?internalAPICall=true")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(userIdentity))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andReturn();
  }

  @Test
  public void test_CreateUserIdentity_withNoSubIdToken() throws Exception {
    UserIdentity userIdentity = new UserIdentity();
    userIdentity.setIdToken("test");
    Map<String, Object> idTokenMap =
        Map.of(
            "login",
            "indall_aradhya.kalva",
            "firstName",
            "Aradhya",
            "lastName",
            "Kalva",
            "preferredLanguage",
            "en",
            "bngfReferenceId",
            "indall_aradhya.kalva",
            "bngfIdentitySource",
            "indall",
            "updateAt",
            "1709750398",
            "email",
            "aradhya.kalva@bnc.ca");
    when(userConfigurationService.validateAndFetchIdTokenClaims(userIdentity))
        .thenReturn(idTokenMap);
    when(userService.getUserConfiguration(any())).thenReturn(new UserConfiguration());
    TestUserSingleton.setTestUser(getMockUser());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    mockMvc
        .perform(
            put("/users/me/identity?internalAPICall=true")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(userIdentity))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().is4xxClientError())
        .andReturn();
  }

  @Test
  public void test_whenUnableToUpdatePreferredLanguage_shouldReturn500() throws Exception {
    UserPreferredLanguage userPreferredLanguage = new UserPreferredLanguage();
    userPreferredLanguage.setPreferredLanguage(UserPreferredLanguage.PreferredLanguageEnum.EN);

    when(userService.updateUserLanguage(any(), any())).thenReturn(MockData.getUserConfiguration());

    String errorMessage = "Error";
    doThrow(new RuntimeException(errorMessage))
        .when(userConfigSearchMaterializedRefreshService)
        .refreshUserSearchMaterializedView(any(Runnable.class), anyBoolean());

    User user = getMockUser();
    user.setIdpUserId("00u1hekn50wVfDWDK0h8");
    TestUserSingleton.setTestUser(user);
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    mockMvc
        .perform(
            put("/users/me/preferredLanguage")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(userPreferredLanguage))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isInternalServerError());
  }

  @Test
  public void test_getUserLastUpdatedDate_shouldReturn200() throws Exception {
    String expectedDate = "date";
    when(userService.getUserLastUpdatedDateByIdpSubject(anyString())).thenReturn(expectedDate);

    MvcResult mvcResult =
        mockMvc
            .perform(
                get("/users/1234/lastUpdatedDate")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();

    assertEquals(expectedDate, mvcResult.getResponse().getContentAsString());
  }

  @Test
  public void test_whenUnableToGetUserLastUpdatedDate_shouldReturn404() throws Exception {
    when(userService.getUserLastUpdatedDateByIdpSubject(anyString()))
        .thenThrow(FumNotFoundException.class);

    mockMvc
        .perform(
            get("/users/1234/lastUpdatedDate")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNotFound());
  }

  @Test
  public void test_updateUserConfigurationByUserId_withNoUserGroup() {
    UserConfiguration userConfigurationInput = MockData.getUserConfiguration();
    UserConfiguration mockUserConfiguration = MockData.getUserConfiguration();
    mockUserConfiguration.setUserGroup(null);
    userConfigurationInput.setUserGroup(null);
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(mockUserConfiguration);
    when(userService.requestHasFeaturePackage(any(UserConfiguration.class))).thenReturn(false);
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    try {
      MvcResult mvcResult =
          this.mockMvc
              .perform(
                  put("/users/1234")
                      .header(HttpHeaders.AUTHORIZATION, "")
                      .with(csrf())
                      .content(objectMapper.writeValueAsString(userConfigurationInput))
                      .accept(MediaType.APPLICATION_JSON)
                      .contentType(MediaType.APPLICATION_JSON))
              .andExpect(status().isNoContent())
              .andReturn();

      UserConfiguration response =
          objectMapper.readValue(
              mvcResult.getResponse().getContentAsString(), UserConfiguration.class);
      assertEquals(
          userConfigurationInput.getUserConfigurationId(), response.getUserConfigurationId());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_updateUserConfigurationByUserId_withUserGroupAndWithFeaturePackage() {
    UserConfiguration userConfigurationInput = MockData.getUserConfiguration();
    userConfigurationInput.setFeaturePackage(MockData.getFeaturePackage());
    UserConfiguration mockUserConfiguration = MockData.getUserConfiguration();
    mockUserConfiguration.setFeaturePackage(getFeaturePackage());
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(mockUserConfiguration);
    when(userService.requestHasFeaturePackage(any(UserConfiguration.class))).thenReturn(true);
    when(userService.getUserGroupNameFromPackageTemplate(anyLong()))
        .thenReturn(getUserGroupList().get(0));
    when(userConfigurationServiceJpa.isDataAccessResourceTypeSharedWithPackageTemplate(
            anyInt(), anyString()))
        .thenReturn(true);
    when(userService.getRRCodeListByFirmId(anyString(), anyBoolean()))
        .thenReturn(MockData.getRrCodeRangeList());
    when(userService.getUserGroupByGroupName(anyString())).thenReturn(getUserGroupEntity());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    try {
      MvcResult mvcResult =
          this.mockMvc
              .perform(
                  put("/users/1234")
                      .header(HttpHeaders.AUTHORIZATION, "")
                      .with(csrf())
                      .content(objectMapper.writeValueAsString(userConfigurationInput))
                      .accept(MediaType.APPLICATION_JSON)
                      .contentType(MediaType.APPLICATION_JSON))
              .andExpect(status().isNoContent())
              .andReturn();

      UserConfiguration response =
          objectMapper.readValue(
              mvcResult.getResponse().getContentAsString(), UserConfiguration.class);
      assertEquals(
          userConfigurationInput.getUserConfigurationId(), response.getUserConfigurationId());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_updateUserConfigurationByUserId_forNonNbin() {
    UserConfiguration userConfigurationInput = MockData.getUserConfiguration();
    userConfigurationInput.setFeaturePackage(MockData.getFeaturePackage());
    UserConfiguration mockUserConfiguration = MockData.getUserConfiguration();
    mockUserConfiguration.setIdp("nbc");
    mockUserConfiguration.setFeaturePackage(getFeaturePackage());
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(mockUserConfiguration);
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    try {
      MvcResult mvcResult =
          this.mockMvc
              .perform(
                  put("/users/1234")
                      .header(HttpHeaders.AUTHORIZATION, "")
                      .with(csrf())
                      .content(objectMapper.writeValueAsString(userConfigurationInput))
                      .accept(MediaType.APPLICATION_JSON)
                      .contentType(MediaType.APPLICATION_JSON))
              .andExpect(status().isNoContent())
              .andReturn();

      UserConfiguration response =
          objectMapper.readValue(
              mvcResult.getResponse().getContentAsString(), UserConfiguration.class);
      assertEquals(
          userConfigurationInput.getUserConfigurationId(), response.getUserConfigurationId());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_updateUserConfigurationByUserId_userNotFound() {
    UserConfiguration userConfigurationInput = MockData.getUserConfiguration();
    userConfigurationInput.setFeaturePackage(MockData.getFeaturePackage());
    UserConfiguration mockUserConfiguration = MockData.getUserConfiguration();
    mockUserConfiguration.setIdp("nbc");
    mockUserConfiguration.setFeaturePackage(getFeaturePackage());
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(null);
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    try {
      MvcResult mvcResult =
          this.mockMvc
              .perform(
                  put("/users/1234")
                      .header(HttpHeaders.AUTHORIZATION, "")
                      .with(csrf())
                      .content(objectMapper.writeValueAsString(userConfigurationInput))
                      .accept(MediaType.APPLICATION_JSON)
                      .contentType(MediaType.APPLICATION_JSON))
              .andExpect(status().isNotFound())
              .andReturn();

      UserConfiguration response =
          objectMapper.readValue(
              mvcResult.getResponse().getContentAsString(), UserConfiguration.class);
      assertEquals(
          userConfigurationInput.getUserConfigurationId(), response.getUserConfigurationId());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_deleteUserConfigurationByUserId() throws Exception {
    doNothing().when(userService).deleteUserConfigurationByUserId(anyString(), anyInt());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    MvcResult mvcResult =
        this.mockMvc
            .perform(delete("/users/1234").header(HttpHeaders.AUTHORIZATION, accessToken))
            .andExpect(status().isNoContent())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_resetPassword() {
    UserCredentials userCredentials = new UserCredentials();
    userCredentials.setTempPassword("password");
    userCredentials.setUsername(MockData.USER_NAME_LABEL);
    when(userService.resetPassword(anyString(), any(UserCredentials.class)))
        .thenReturn(userCredentials.getTempPassword());
    UserConfiguration userConfiguration = UserConfiguration.builder().idp("nbin").build();
    when(userService.getUserConfiguration(any())).thenReturn(userConfiguration);
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    try {
      MvcResult mvcResult =
          this.mockMvc
              .perform(
                  post("/users/1234/resetPassword")
                      .header(HttpHeaders.AUTHORIZATION, "")
                      .with(csrf())
                      .content(objectMapper.writeValueAsString(userCredentials))
                      .accept(MediaType.APPLICATION_JSON)
                      .contentType(MediaType.APPLICATION_JSON))
              .andExpect(status().isOk())
              .andReturn();

      UserCredentials response =
          objectMapper.readValue(
              mvcResult.getResponse().getContentAsString(), UserCredentials.class);
      assertEquals(userCredentials.getTempPassword(), response.getTempPassword());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_updateUserStatus() {
    UpdateUserStatus updateUserStatus = new UpdateUserStatus();
    updateUserStatus.setStatus(StatusEnum.ACTIVE);
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    try {
      this.mockMvc
          .perform(
              patch("/users/1234")
                  .header(HttpHeaders.AUTHORIZATION, "")
                  .with(csrf())
                  .content(objectMapper.writeValueAsString(updateUserStatus))
                  .accept(MediaType.APPLICATION_JSON)
                  .contentType(MediaType.APPLICATION_JSON))
          .andExpect(status().isNoContent());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_refreshAssignment() {
    try {
      this.mockMvc
          .perform(
              post("/users/firm/NBIN/assignments/assignmentType/refresh")
                  .header(HttpHeaders.AUTHORIZATION, "")
                  .with(csrf())
                  .accept(MediaType.APPLICATION_JSON)
                  .contentType(MediaType.APPLICATION_JSON))
          .andExpect(status().isOk());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_assignFeaturePackage() {
    AssignRequest assignRequest = new AssignRequest();
    assignRequest.setAssigneeId(123);
    when(userService.getUserConfigurationByIdOrName(anyString()))
        .thenReturn(MockData.getUserConfiguration());
    when(userService.getUserConfigurationById(anyInt()))
        .thenReturn(MockData.getUserConfiguration());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    try {
      this.mockMvc
          .perform(
              put("/users/1234/assignments/feature-package")
                  .header(HttpHeaders.AUTHORIZATION, "")
                  .with(csrf())
                  .content(objectMapper.writeValueAsString(assignRequest))
                  .accept(MediaType.APPLICATION_JSON)
                  .contentType(MediaType.APPLICATION_JSON))
          .andExpect(status().isNoContent());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_assignFirm() throws Exception {
    AssignRequest assignRequest = new AssignRequest();
    assignRequest.setAssigneeId(123);
    when(userService.getUserConfigurationById(anyInt()))
        .thenReturn(MockData.getUserConfiguration());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    mockMvc
        .perform(
            put("/users/1234/assignments/firm")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(assignRequest))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNoContent());
  }

  @Test
  public void test_assignUserGroup() throws Exception {
    AssignRequest assignRequest = new AssignRequest();
    assignRequest.setAssigneeId(123);
    when(userService.getUserConfigurationById(anyInt()))
        .thenReturn(MockData.getUserConfiguration());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    mockMvc
        .perform(
            put("/users/1234/assignments/user-group")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(assignRequest))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNoContent());
  }

  @Test
  public void test_assignByUserGroupName() throws Exception {
    UserGroupName assignRequest = new UserGroupName();
    assignRequest.setUserGroupName("Test Group");
    when(userService.getUserConfiguration(anyString())).thenReturn(MockData.getUserConfiguration());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    mockMvc
        .perform(
            put("/users/KALA007/assignments/user-group-name")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(assignRequest))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNoContent());
  }

  @Test
  public void test_assignResource() throws Exception {
    AssignRequest assignRequest = new AssignRequest();
    assignRequest.setAssigneeId(123);
    when(userService.getUserConfigurationById(anyInt()))
        .thenReturn(MockData.getUserConfiguration());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    mockMvc
        .perform(
            put("/users/1234/assignments/resource")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(assignRequest))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNoContent());
  }

  @Test
  public void test_assignByResourceName() throws Exception {
    ResourceName assignRequest = new ResourceName();
    assignRequest.setResourceName("Test resource");
    when(userService.getUserConfiguration(anyString())).thenReturn(MockData.getUserConfiguration());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    mockMvc
        .perform(
            put("/users/KALA007/assignments/resource-name")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(assignRequest))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNoContent());
  }

  @Test
  public void test_assignByResourceNameDwh() throws Exception {
    ResourceName assignRequest = new ResourceName();
    assignRequest.setResourceName("dwh-module-1");
    when(userService.getUserConfiguration(anyString())).thenReturn(MockData.getUserConfiguration());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    mockMvc
        .perform(
            put("/users/KALA007/dwh-assignments/resource-name")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(assignRequest))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNoContent());
  }

  @Test
  public void test_getUserDwhAssignmentsResources() throws Exception {
    UserAssignment dwhAssignment = new UserAssignment();
    dwhAssignment.setAssignmentType("S");
    dwhAssignment.setAssigneeId(1);
    dwhAssignment.setResourceName("dwh-module-1");

    when(userConfigurationService.getUserDwhAssignmentsResources(anyInt()))
        .thenReturn(Arrays.asList(dwhAssignment));
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                get("/users/1234/dwh-assignments/resources")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();
    List<UserAssignment> response =
        objectMapper.readValue(
            mvcResult.getResponse().getContentAsString(),
            new TypeReference<List<UserAssignment>>() {});
    assertEquals(1, response.size());
    assertEquals("dwh-module-1", response.get(0).getResourceName());
  }

  @Test
  public void test_assignRrRange() {
    UserConfiguration userConf = new UserConfiguration();
    userConf.setActive("username");
    when(userService.getUserConfigurationWithRrCodeById(anyInt())).thenReturn(userConf);
    List<RRRange> rrRanges = Arrays.asList(new RRRange());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    try {
      mockMvc
          .perform(
              put("/users/1234/assignments/rr-range")
                  .header(HttpHeaders.AUTHORIZATION, "")
                  .with(csrf())
                  .content(objectMapper.writeValueAsString(rrRanges))
                  .accept(MediaType.APPLICATION_JSON)
                  .contentType(MediaType.APPLICATION_JSON))
          .andExpect(status().isNoContent());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_deleteUserAssignment() {
    when(userService.getUserConfigurationByIdOrName(anyString()))
        .thenReturn(MockData.getUserConfiguration());
    when(userService.getUserConfiguration(anyString())).thenReturn(MockData.getUserConfiguration());
    when(auditLogService.publishAuditLog(any(), anyBoolean(), any(), any()))
        .thenAnswer(invocation -> {
          Supplier<UserConfiguration> supplier = invocation.getArgument(3);
          return supplier.get();
        });
    try {
      mockMvc
          .perform(
              delete("/users/1234/assignments/P/1234")
                  .header(HttpHeaders.AUTHORIZATION, "")
                  .with(csrf())
                  .accept(MediaType.APPLICATION_JSON)
                  .contentType(MediaType.APPLICATION_JSON))
          .andExpect(status().isNoContent());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_getUserAssignments() {
    UserAssignment mockUserAssignment = MockData.getUserAssignment();
    when(userConfigValidationService.getAssignmentTypeInstance(anyString()))
        .thenReturn(AssignmentType.F);
    when(userService.getUserIdpSubjectById(anyInt())).thenReturn("idpSubject");
    when(userAssignmentService.getUserAssignments(anyString(), anyList(), anyBoolean()))
        .thenReturn(Arrays.asList(mockUserAssignment));
    try {
      MvcResult mvcResult =
          this.mockMvc
              .perform(
                  get("/users/1234/assignments?assignment_type=firm&active=true")
                      .header(HttpHeaders.AUTHORIZATION, "")
                      .with(csrf())
                      .accept(MediaType.APPLICATION_JSON)
                      .contentType(MediaType.APPLICATION_JSON))
              .andExpect(status().isOk())
              .andReturn();
      List<UserAssignment> response =
          objectMapper.readValue(
              mvcResult.getResponse().getContentAsString(),
              new TypeReference<List<UserAssignment>>() {});
      assertEquals(mockUserAssignment.getAssigneeId(), response.get(0).getAssigneeId());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_getUserAssignments_whenAssignmentTypeInvalid_shouldThrowNotFound() {
    UserAssignment mockUserAssignment = MockData.getUserAssignment();
    when(userConfigValidationService.getAssignmentTypeInstance(anyString()))
        .thenReturn(AssignmentType.F);
    when(userService.getUserIdpSubjectById(anyInt())).thenReturn("idpSubject");
    when(userAssignmentService.getUserAssignments(anyString(), anyList(), anyBoolean()))
        .thenReturn(Arrays.asList(mockUserAssignment));
    try {
      MvcResult mvcResult =
          this.mockMvc
              .perform(
                  get("/users/1234/assignments?assignment_type=invalid&active=true")
                      .header(HttpHeaders.AUTHORIZATION, "")
                      .with(csrf())
                      .accept(MediaType.APPLICATION_JSON)
                      .contentType(MediaType.APPLICATION_JSON))
              .andExpect(status().isNotFound())
              .andReturn();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_getUserAssignments_whenAssignmentTypeEmpty_shouldThrowBadRequest() {
    UserAssignment mockUserAssignment = MockData.getUserAssignment();
    when(userConfigValidationService.getAssignmentTypeInstance(anyString()))
        .thenReturn(AssignmentType.F);
    when(userService.getUserIdpSubjectById(anyInt())).thenReturn("idpSubject");
    when(userAssignmentService.getUserAssignments(anyString(), anyList(), anyBoolean()))
        .thenReturn(Arrays.asList(mockUserAssignment));
    try {
      MvcResult mvcResult =
          this.mockMvc
              .perform(
                  get("/users/1234/assignments?assignment_type=&active=true")
                      .header(HttpHeaders.AUTHORIZATION, "")
                      .with(csrf())
                      .accept(MediaType.APPLICATION_JSON)
                      .contentType(MediaType.APPLICATION_JSON))
              .andExpect(status().isBadRequest())
              .andReturn();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_getUserAssignmentsMy() {
    UserAssignment mockUserAssignment = MockData.getUserAssignment();
    when(userConfigValidationService.getAssignmentTypeInstance(anyString()))
        .thenReturn(AssignmentType.F);
    when(userService.getUserIdpSubjectById(anyInt())).thenReturn("idpSubject");
    when(userAssignmentService.getUserAssignments(anyString(), anyList(), anyBoolean()))
        .thenReturn(Arrays.asList(mockUserAssignment));
    try {
      MvcResult mvcResult =
          this.mockMvc
              .perform(
                  get("/users/me/assignments?assignment_type=firm&active=true")
                      .header(HttpHeaders.AUTHORIZATION, "")
                      .with(csrf())
                      .accept(MediaType.APPLICATION_JSON)
                      .contentType(MediaType.APPLICATION_JSON))
              .andExpect(status().isOk())
              .andReturn();
      List<UserAssignment> response =
          objectMapper.readValue(
              mvcResult.getResponse().getContentAsString(),
              new TypeReference<List<UserAssignment>>() {});
      assertEquals(mockUserAssignment.getAssigneeId(), response.get(0).getAssigneeId());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_getUserAssignmentsMy_whenAssignmentTypesIsEmpty_shouldThrowBadRequest() {
    UserAssignment mockUserAssignment = MockData.getUserAssignment();
    when(userConfigValidationService.getAssignmentTypeInstance(anyString()))
        .thenReturn(AssignmentType.F);
    when(userService.getUserIdpSubjectById(anyInt())).thenReturn("idpSubject");
    when(userAssignmentService.getUserAssignments(anyString(), anyList(), anyBoolean()))
        .thenReturn(Arrays.asList(mockUserAssignment));
    try {
      MvcResult mvcResult =
          this.mockMvc
              .perform(
                  get("/users/me/assignments?assignment_type=&active=true")
                      .header(HttpHeaders.AUTHORIZATION, "")
                      .with(csrf())
                      .accept(MediaType.APPLICATION_JSON)
                      .contentType(MediaType.APPLICATION_JSON))
              .andExpect(status().isBadRequest())
              .andReturn();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_getUserAssignmentsMy_whenAssignmentTypesIsInvalid_shouldThrowNotFound() {
    UserAssignment mockUserAssignment = MockData.getUserAssignment();
    when(userConfigValidationService.getAssignmentTypeInstance(anyString()))
        .thenReturn(AssignmentType.F);
    when(userService.getUserIdpSubjectById(anyInt())).thenReturn("idpSubject");
    when(userAssignmentService.getUserAssignments(anyString(), anyList(), anyBoolean()))
        .thenReturn(Arrays.asList(mockUserAssignment));
    try {
      MvcResult mvcResult =
          this.mockMvc
              .perform(
                  get("/users/me/assignments?assignment_type=invalid&active=true")
                      .header(HttpHeaders.AUTHORIZATION, "")
                      .with(csrf())
                      .accept(MediaType.APPLICATION_JSON)
                      .contentType(MediaType.APPLICATION_JSON))
              .andExpect(status().isNotFound())
              .andReturn();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void test_clearRedisCache() throws Exception {
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                post("/users/clearRedisCache")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();
  }

  @Test
  public void test_clearRedisCache_withCacheName() throws Exception {
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                post("/users/clearRedisCache?cacheName=abcd")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();
  }

  @Test
  public void test_clearRedisCache_withCacheNameAndKey() throws Exception {
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                post("/users/clearRedisCache?cacheName=abcd&key=24")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();
  }

  @Test
  public void test_MockUserWithUserIds() throws Exception {
    List<String> userRequest = List.of("id1", "id2");
    String json = objectMapper.writeValueAsString(userRequest);
    UserConfiguration userConf = new UserConfiguration();
    userConf.setIdpSubject("idp");
    userConf.setFirmName("firstName");
    userConf.setLastName("lastname");
    userConf.setPreferredLanguage("EN");
    userConf.setActive("username");
    when(userService.getUserConfigurationByUserIds(any(List.class), anyString()))
        .thenReturn(List.of(userConf));
    TestUserSingleton.setTestUser(getMockUser());
    MvcResult mvcResult =
        this.mockMvc
            .perform(
                post("/users/list")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(json)
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();
    assertNotNull(mvcResult);
  }

  @Test
  public void test_updateLastLoginDate_shouldReturn204() throws Exception {
    User user = getMockUser();
    user.setUserConfigurationId(1);
    TestUserSingleton.setTestUser(user);

    mockMvc
        .perform(
            put("/users/me/lastLoginDate")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(objectMapper.writeValueAsString(""))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNoContent());
  }

  private void validateApiError(HttpStatus status, String errorMessage, ApiError apiError) {
    assertEquals(status.name(), apiError.getTitle());
    assertEquals(status.getReasonPhrase(), apiError.getDescription());
    assertEquals(String.valueOf(status.value()), apiError.getHttpCode());
    assertFalse(apiError.getMessages().getErrors().isEmpty());

    ApiMessage apiMessage = apiError.getMessages().getErrors().get(0);
    assertEquals(String.valueOf(status.value()), apiMessage.getCode());
    assertNull(apiMessage.getField());
    assertEquals(errorMessage, apiMessage.getMessage());
  }

  @Test
  public void test_revokeToken_Success() throws Exception {
    doNothing().when(tokenRevocationService).revokeToken(anyString());
    String body = objectMapper.writeValueAsString(
        java.util.Map.of("tokens", java.util.List.of("token1", "token2", "token3")));
    MvcResult mvcResult =
        this.mockMvc
            .perform(post("/users/revoke")
                .header(HttpHeaders.AUTHORIZATION, accessToken)
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
            .andExpect(status().isNoContent())
            .andReturn();
    assertNotNull(mvcResult);
    verify(tokenRevocationService, times(3)).revokeToken(anyString());
  }

  @Test
  public void test_revokeToken_EmptyList_RevokesNothing() throws Exception {
    doNothing().when(tokenRevocationService).revokeToken(anyString());
    String body = objectMapper.writeValueAsString(
        java.util.Map.of("tokens", java.util.List.of()));
    MvcResult mvcResult =
        this.mockMvc
            .perform(post("/users/revoke")
                .header(HttpHeaders.AUTHORIZATION, accessToken)
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
            .andExpect(status().isNoContent())
            .andReturn();
    assertNotNull(mvcResult);
    verify(tokenRevocationService, times(0)).revokeToken(anyString());
  }

  @Test
  public void test_createUserConfiguration_whenBmaInProgress_shouldReturn500() throws Exception {
    UserConfiguration userConf = MockData.getUserConfiguration();
    String json = objectMapper.writeValueAsString(userConf);

    when(firmBmaGuardService.isFirmBmaInProgress(anyString())).thenReturn(true);

    this.mockMvc
        .perform(
            post("/users")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(json)
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isInternalServerError());
  }
}
