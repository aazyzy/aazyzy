package ca.bnc.wealth.api.userconfiguration.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigValidationService;
import ca.bnc.wealth.api.userconfiguration.service.UserService;
import ca.bnc.wealth.api.userconfiguration.util.MockData;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserCredentials;
import ca.bnc.wealth.common.userconfiguration.model.UserDetails;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class UserValidationControllerTest {

  private UserValidationController userValidationController;

  @MockitoBean private UserConfigValidationService userConfigValidationService;
  @MockitoBean private UserService userService;

  @Before
  public void setup() {
    userValidationController = new UserValidationController(userConfigValidationService, userService);
  }

  @Test
  public void getUsernameAndTempPassword_shouldReturnBadRequest_forNonNbinUser() {
    User user = mock(User.class);
    when(user.getIdpSubject()).thenReturn("idp-subject");
    SecurityContextHolder.getContext().setAuthentication(
        new UsernamePasswordAuthenticationToken(user, null));

    UserConfiguration uc = new UserConfiguration();
    uc.setIdp("indall");
    when(userService.getUserConfiguration("idp-subject")).thenReturn(uc);

    assertEquals(
        HttpStatus.BAD_REQUEST,
        userValidationController
            .getUsernameAndTempPassword("token", new UserDetails())
            .getStatusCode());
  }

  @Test
  public void getUsernameAndTempPassword_shouldReturnOk_forNbinUser() {
    User user = mock(User.class);
    when(user.getIdpSubject()).thenReturn("idp-subject");
    SecurityContextHolder.getContext().setAuthentication(
        new UsernamePasswordAuthenticationToken(user, null));

    UserConfiguration uc = new UserConfiguration();
    uc.setIdp("nbin");
    when(userService.getUserConfiguration("idp-subject")).thenReturn(uc);

    UserDetails details = new UserDetails();
    details.setFirstName("First");
    details.setLastName("Last");
    details.setEmail("first.last@test.com");

    UserCredentials credentials = new UserCredentials();
    credentials.setUsername(MockData.USER_NAME_LABEL);
    credentials.setTempPassword("Temp123!");
    when(userConfigValidationService.getUsernameAndTempPassword(eq(details))).thenReturn(credentials);

    assertEquals(
        HttpStatus.OK,
        userValidationController.getUsernameAndTempPassword("token", details).getStatusCode());
    verify(userConfigValidationService, times(1)).validateUserDetailsMandatoryFields(any(UserDetails.class));
    verify(userConfigValidationService, times(1)).getUsernameAndTempPassword(eq(details));
  }
}
