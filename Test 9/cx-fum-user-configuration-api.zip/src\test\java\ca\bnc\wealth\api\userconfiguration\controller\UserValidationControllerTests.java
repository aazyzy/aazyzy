package ca.bnc.wealth.api.userconfiguration.controller;

import static ca.bnc.wealth.api.userconfiguration.util.MockData.USER_EMAIL;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.USER_FIRST_NAME;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.USER_LAST_NAME;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.USER_NAME_LABEL;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.USER_PASSWORD;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ca.bnc.wealth.api.authorization.security.SecurityConfigAdapter;
import ca.bnc.wealth.api.authorization.security.test.TestAuthConfiguration;
import ca.bnc.wealth.api.authorization.security.test.TestUserSingleton;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigValidationService;
import ca.bnc.wealth.api.userconfiguration.service.UserService;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserCredentials;
import ca.bnc.wealth.common.userconfiguration.model.UserDetails;
import tools.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc(addFilters = false)
@ContextConfiguration(
    classes = {
        SecurityConfigAdapter.class,
        TestAuthConfiguration.class,
        UserValidationController.class,
        ca.bnc.wealth.common.spring.microservice.starter.core.exception.GlobalDefaultExceptionHandler
            .class
    })
@WebMvcTest(properties = {"spring.profiles.active=test"})
@Slf4j
public class UserValidationControllerTests {

  @Autowired
  private ObjectMapper mapper;
  @Autowired
  private WebApplicationContext context;
  @Autowired
  private MockMvc mockMvc;
  @MockitoBean
  private UserConfigValidationService userConfigValidationService;

  @MockitoBean
  private UserService userService;

  @Before
  public void setup() {
    mockMvc = MockMvcBuilders.webAppContextSetup(context).apply(springSecurity()).build();
    UserConfiguration userConfiguration = UserConfiguration.builder().idp("nbin").build();
    when(userService.getUserConfiguration(any())).thenReturn(userConfiguration);
  }

  @AfterEach
  public void cleanUp() {
    TestUserSingleton.setTestUser(null);
    TestUserSingleton.USER_IS_UNAUTHORIZED = false;
  }

  @Test
  public void test_getUsernameAndTempPassword() throws Exception {
    UserDetails userName = new UserDetails();
    userName.setFirstName(USER_FIRST_NAME);
    userName.setLastName(USER_LAST_NAME);
    userName.setEmail(USER_EMAIL);

    UserCredentials userCredentials = new UserCredentials();
    userCredentials.setUsername(USER_NAME_LABEL);
    userCredentials.setTempPassword(USER_PASSWORD);
    when(userConfigValidationService.getUsernameAndTempPassword(any())).thenReturn(userCredentials);

    MvcResult mvcResult =
        mockMvc
            .perform(
                post("/validate/generate/userCredentials")
                    .header(HttpHeaders.AUTHORIZATION, "")
                    .with(csrf())
                    .content(mapper.writeValueAsString(userName))
                    .accept(MediaType.APPLICATION_JSON)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn();
    assertTrue(
        mvcResult
            .getResponse()
            .getContentAsString()
            .contains(USER_FIRST_NAME + "." + USER_LAST_NAME));
  }

  @Test
  public void test_getUsernameAndTempPassword_shouldReturn400IfEmailNotProvided() throws Exception {
    UserDetails userName = new UserDetails();
    userName.setFirstName(USER_FIRST_NAME);
    userName.setLastName(USER_LAST_NAME);
    userName.setEmail(null);


    mockMvc
        .perform(
            post("/validate/generate/userCredentials")
                .header(HttpHeaders.AUTHORIZATION, "")
                .with(csrf())
                .content(mapper.writeValueAsString(userName))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest());
  }


  @Test
  public void test_getUsernameAndTempPassword_shouldReturn400forNonNbin() throws Exception {
    UserDetails userDetails = new UserDetails();
    userDetails.setFirstName(USER_FIRST_NAME);
    userDetails.setLastName(USER_LAST_NAME);
    userDetails.setEmail(USER_EMAIL);

    UserCredentials userCredentials = new UserCredentials();
    userCredentials.setUsername(USER_NAME_LABEL);
    userCredentials.setTempPassword(USER_PASSWORD);
    when(userConfigValidationService.getUsernameAndTempPassword(any())).thenReturn(userCredentials);

    UserConfiguration userConfiguration = UserConfiguration.builder().idp("indall").build();
    when(userService.getUserConfiguration(any())).thenReturn(userConfiguration);

    mockMvc
            .perform(
                    post("/validate/generate/userCredentials")
                            .header(HttpHeaders.AUTHORIZATION, "")
                            .with(csrf())
                            .content(mapper.writeValueAsString(userDetails))
                            .accept(MediaType.APPLICATION_JSON)
                            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isBadRequest());
  }
}
