package ca.bnc.wealth.api.userconfiguration.dao;

import static ca.bnc.wealth.api.userconfiguration.util.MockData.IDP_USER_ID;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.USER_GROUP;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.userconfiguration.util.MockData;
import ca.bnc.wealth.common.ciam.feign.client.*;
import ca.bnc.wealth.common.ciam.model.OktaCredentials;
import ca.bnc.wealth.common.ciam.model.OktaCredentialsWithHashedPassword;
import ca.bnc.wealth.common.ciam.model.OktaDeleteMfaFactor;
import ca.bnc.wealth.common.ciam.model.OktaHash;
import ca.bnc.wealth.common.ciam.model.OktaHashedPassword;
import ca.bnc.wealth.common.ciam.model.OktaNewPassword;
import ca.bnc.wealth.common.ciam.model.OktaUserEmail;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.ciam.model.OktaUserRequest;
import ca.bnc.wealth.common.ciam.model.OktaUserWithHashedPasswordRequest;
import ca.bnc.wealth.common.ciam.security.CiamSystemToken;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ServiceException;
import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import feign.FeignException;
import java.util.List;
import java.util.stream.Collectors;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletWebRequest;

@RunWith(SpringRunner.class)
@ExtendWith(MockitoExtension.class)
public class CiamOktaDaoTests {

  private final CiamOktaDao ciamOktaDao = new CiamOktaDao();
  @MockitoBean private CiamSystemToken ciamSystemToken;
  @MockitoBean private GetOktaUserProfileClient userProfileClient;
  @MockitoBean private DeleteOktaUserGroupClient deleteOktaUserGroupClient;
  @MockitoBean private AddOktaUserGroupClient addOktaUserGroupClient;
  @MockitoBean private CreateOktaUserClient createOktaUserClient;
  @MockitoBean private CreateOktaUserWithHashedPasswordClient createOktaUserWithHashedPasswordClient;
  @MockitoBean private CreateActiveOktaUserWithHashedPasswordClient createActiveOktaUserWithHashedPasswordClient;
  @MockitoBean private DeleteOktaUserClient deleteOktaUserClient;
  @MockitoBean private UnlockOktaUserClient unlockOktaUserClient;
  @MockitoBean private GetOktaUserGroupsClient getOktaUserGroupsClient;
  @MockitoBean private SetOktaUserTempPasswordClient setOktaUserTempPasswordClient;
  @MockitoBean private DeleteOktaUserMfaFactorClient deleteOktaUserMfaFactorClient;
  @MockitoBean private SuspendOktaUserProfileClient suspendOktaUserProfileClient;
  @MockitoBean private UnsuspendOktaUserProfileClient unsuspendOktaUserProfileClient;
  @MockitoBean private UpdateOktaSecureZoneIdClient updateOktaSecureZoneIdClient;
  @MockitoBean private SyncOktaUserProfileClient syncOktaUserProfileClient;
  @MockitoBean private UpdateOktaUserEmailClient updateOktaUserEmailClient;
  @MockitoBean private CreateActiveOktaUserClient createActiveOktaUserClient;

  @Before
  public void setup() {
    when(ciamSystemToken.getBearerToken()).thenReturn("");

    ciamOktaDao.setAddOktaUserGroupClient(addOktaUserGroupClient);
    ciamOktaDao.setCreateOktaUserClient(createOktaUserClient);
    ciamOktaDao.setCreateActiveOktaUserClient(createActiveOktaUserClient);
    ciamOktaDao.setCiamSystemToken(ciamSystemToken);
    ciamOktaDao.setDeleteOktaUserClient(deleteOktaUserClient);
    ciamOktaDao.setDeleteOktaUserGroupClient(deleteOktaUserGroupClient);
    ciamOktaDao.setGetOktaUserGroupsClient(getOktaUserGroupsClient);
    ciamOktaDao.setOktaUserTempPasswordClient(setOktaUserTempPasswordClient);
    ciamOktaDao.setUnlockOktaUserClient(unlockOktaUserClient);
    ciamOktaDao.setUserOktaProfileClient(userProfileClient);
    ciamOktaDao.setDeleteOktaUserMfaFactorClient(deleteOktaUserMfaFactorClient);
    ciamOktaDao.setSetOktaUserTempPasswordClient(setOktaUserTempPasswordClient);
    ciamOktaDao.setSuspendOktaUserProfileClient(suspendOktaUserProfileClient);
    ciamOktaDao.setUnsuspendOktaUserProfileClient(unsuspendOktaUserProfileClient);
    ciamOktaDao.setUpdateOktaSecureZoneIdClient(updateOktaSecureZoneIdClient);
    ciamOktaDao.setSyncOktaUserProfileClient(syncOktaUserProfileClient);
    ciamOktaDao.setUpdateOktaUserEmailClient(updateOktaUserEmailClient);
    ciamOktaDao.setCreateOktaUserWithHashedPasswordClient(createOktaUserWithHashedPasswordClient);
    ciamOktaDao.setCreateActiveOktaUserWithHashedPasswordClient(createActiveOktaUserWithHashedPasswordClient);
  }

  @Test
  public void testGetOktaUserProfile() {
    OktaUserProfile mockOktaUserProfile = MockData.getOktaUserProfile();
    when(userProfileClient.getOktaUserProfile(anyString(), isNull(), anyString()))
        .thenReturn(mockOktaUserProfile);
    OktaUserProfile oktaUserProfile = ciamOktaDao.getOktaUserProfile("");
    assertEquals(
        mockOktaUserProfile.getAccessProfile().getUsername(),
        oktaUserProfile.getAccessProfile().getUsername());
  }

  @Test(expected = ServiceException.class)
  public void testGetOktaUserProfile_whenUnexpectedError_shouldThrowException() {
    when(userProfileClient.getOktaUserProfile(anyString(), isNull(), anyString()))
        .thenThrow(new RuntimeException());
    ciamOktaDao.getOktaUserProfile(IDP_USER_ID);
  }

  @Test
  public void testGetOktaUserProfile_whenOktaProfileNotFound_shouldReturnNull() {
    when(userProfileClient.getOktaUserProfile(anyString(), isNull(), anyString()))
        .thenThrow(FeignException.NotFound.class);
    assertNull(ciamOktaDao.getOktaUserProfile(IDP_USER_ID));
  }

  @Test
  public void testCreateOktaUser() {
    when(createOktaUserClient.createOktaUser(anyString(), isNull(), any(OktaUserRequest.class)))
        .thenReturn(new ResponseEntity<>(HttpStatus.NO_CONTENT));
    ciamOktaDao.createOktaUser(MockData.getOktaUserRequest());
    verify(createOktaUserClient, times(1))
        .createOktaUser(anyString(), isNull(), any(OktaUserRequest.class));
  }

  @Test
  public void testCreateOktaUserWithHashedPassword() {
    when(createOktaUserWithHashedPasswordClient.createOktaUserWithHashedPassword(
            anyString(), isNull(), any(OktaUserWithHashedPasswordRequest.class)))
        .thenReturn(new ResponseEntity<>(HttpStatus.NO_CONTENT));
    ciamOktaDao.createOktaUserWithHashedPassword(new OktaUserWithHashedPasswordRequest());
    verify(createOktaUserWithHashedPasswordClient, times(1))
        .createOktaUserWithHashedPassword(
            anyString(), isNull(), any(OktaUserWithHashedPasswordRequest.class));
  }

  @Test(expected = FumServiceException.class)
  public void testCreateOktaUserWithHashedPassword_throwException() {
    doThrow(new RuntimeException())
        .when(createOktaUserWithHashedPasswordClient)
        .createOktaUserWithHashedPassword(
            anyString(), isNull(), any(OktaUserWithHashedPasswordRequest.class));

    RequestAttributes mockRequest = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(mockRequest);
    ciamOktaDao.createOktaUserWithHashedPassword(new OktaUserWithHashedPasswordRequest());
  }

  @Test
  public void testCreateActiveOktaUserWithHashedPassword() {
    when(createActiveOktaUserWithHashedPasswordClient.createOktaUserWithHashedPassword(
        anyString(), isNull(), any(OktaUserWithHashedPasswordRequest.class)))
        .thenReturn(new ResponseEntity<>(HttpStatus.NO_CONTENT));
    ciamOktaDao.createActiveOktaUserWithHashedPassword(new OktaUserWithHashedPasswordRequest());
    verify(createActiveOktaUserWithHashedPasswordClient, times(1))
        .createOktaUserWithHashedPassword(
            anyString(), isNull(), any(OktaUserWithHashedPasswordRequest.class));
  }

  @Test(expected = FumServiceException.class)
  public void testCreateActiveOktaUserWithHashedPassword_throwException() {
    doThrow(new RuntimeException())
        .when(createActiveOktaUserWithHashedPasswordClient)
        .createOktaUserWithHashedPassword(
            anyString(), isNull(), any(OktaUserWithHashedPasswordRequest.class));

    RequestAttributes mockRequest = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(mockRequest);
    ciamOktaDao.createActiveOktaUserWithHashedPassword(new OktaUserWithHashedPasswordRequest());
  }

  @Test
  public void testCiamCalls_shouldNeverLogCredentialsOrToken() {
    when(ciamSystemToken.getBearerToken()).thenReturn("Bearer SECRET-CIAM-TOKEN");
    OktaHash oktaHash = new OktaHash();
    oktaHash.setValue("SECRET-HASH-VALUE");
    OktaHashedPassword hashedPassword = new OktaHashedPassword();
    hashedPassword.setHash(oktaHash);
    OktaCredentialsWithHashedPassword credentials = new OktaCredentialsWithHashedPassword();
    credentials.setPassword(hashedPassword);
    OktaUserWithHashedPasswordRequest hashedRequest = new OktaUserWithHashedPasswordRequest();
    hashedRequest.setCredentials(credentials);
    OktaCredentials clearCredentials = new OktaCredentials();
    clearCredentials.setPassword("SECRET-CLEAR-PASSWORD");
    OktaUserRequest clearRequest = MockData.getOktaUserRequest();
    clearRequest.setCredentials(clearCredentials);

    Logger logger = (Logger) LoggerFactory.getLogger(CiamOktaDao.class);
    ListAppender<ILoggingEvent> appender = new ListAppender<>();
    appender.start();
    logger.addAppender(appender);
    Level level = logger.getLevel();
    logger.setLevel(Level.DEBUG);
    try {
      ciamOktaDao.createOktaUser(clearRequest);
      ciamOktaDao.createActiveOktaUser(clearRequest);
      ciamOktaDao.createOktaUserWithHashedPassword(hashedRequest);
      ciamOktaDao.createActiveOktaUserWithHashedPassword(hashedRequest);
      ciamOktaDao.setOktaTempPassword(IDP_USER_ID, MockData.getOktaNewPassword());
      ciamOktaDao.resetPassword(IDP_USER_ID, MockData.getOktaNewPassword());
    } finally {
      logger.detachAppender(appender);
      logger.setLevel(level);
    }

    String logged = appender.list.stream()
        .map(ILoggingEvent::getFormattedMessage)
        .collect(Collectors.joining("\n"));
    assertFalse(logged.contains("SECRET-HASH-VALUE"));
    assertFalse(logged.contains("SECRET-CLEAR-PASSWORD"));
    assertFalse(logged.contains("SECRET-CIAM-TOKEN"));
  }

  @Test
  public void testDeleteOktaUser() {
    when(deleteOktaUserClient.deleteOktaUser(anyString(), isNull(), anyString()))
        .thenReturn(new ResponseEntity<>(HttpStatus.NO_CONTENT));
    ciamOktaDao.deleteOktaUser("");
    verify(deleteOktaUserClient, times(1)).deleteOktaUser(anyString(), isNull(), anyString());
  }

  @Test
  public void testUnlockOktaUser() {
    when(unlockOktaUserClient.unlockOktaUser(anyString(), isNull(), anyString()))
        .thenReturn(new ResponseEntity<>(HttpStatus.NO_CONTENT));
    ciamOktaDao.unlockOktaUser("");
    verify(unlockOktaUserClient, times(1)).unlockOktaUser(anyString(), isNull(), anyString());
  }

  @Test
  public void testSetOktaTempPassword() {
    when(setOktaUserTempPasswordClient.setOktaUserTempPassword(
            anyString(), isNull(), anyString(), any(OktaNewPassword.class)))
        .thenReturn(new ResponseEntity<>(HttpStatus.NO_CONTENT));
    ciamOktaDao.setOktaTempPassword("", new OktaNewPassword());
    verify(setOktaUserTempPasswordClient, times(1))
        .setOktaUserTempPassword(anyString(), isNull(), anyString(), any(OktaNewPassword.class));
  }

  @Test
  public void testGetOktaUserGroups() {
    ResponseEntity responseEntity = new ResponseEntity(MockData.getUserGroups(), HttpStatus.OK);
    when(getOktaUserGroupsClient.getOktaUserGroups(anyString(), isNull(), anyString()))
        .thenReturn(responseEntity);
    List<String> userGroupList = ciamOktaDao.getUserOktaGroups(IDP_USER_ID);
    assertEquals(2, userGroupList.size());
  }

  @Test
  public void testGetOktaUserGroups_whenResponseEntityBodyIsNull() {
    when(getOktaUserGroupsClient.getOktaUserGroups(anyString(), isNull(), anyString()))
        .thenReturn(new ResponseEntity<>(null, (HttpHeaders) null, HttpStatus.OK));
    assertNull(ciamOktaDao.getUserOktaGroups(IDP_USER_ID));
  }

  @Test
  public void testAddOktaUserGroup() {
    when(addOktaUserGroupClient.addUserGroup(anyString(), isNull(), anyString(), anyString()))
        .thenReturn(new ResponseEntity<>(HttpStatus.NO_CONTENT));
    ciamOktaDao.addOktaUserGroup(IDP_USER_ID, USER_GROUP);
    verify(addOktaUserGroupClient, times(1))
        .addUserGroup(anyString(), isNull(), anyString(), anyString());
  }

  @Test
  public void testDeleteAddOktaUserGroup() {
    when(deleteOktaUserGroupClient.deleteOktaUserGroup(
            anyString(), isNull(), anyString(), anyString()))
        .thenReturn(new ResponseEntity<>(HttpStatus.NO_CONTENT));
    ciamOktaDao.deleteOktaUserGroup(IDP_USER_ID, USER_GROUP);
    verify(deleteOktaUserGroupClient, times(1))
        .deleteOktaUserGroup(anyString(), isNull(), anyString(), anyString());
  }

  @Test
  public void testDeleteOktaUser2fa() {
    when(deleteOktaUserMfaFactorClient.deleteOktaUserMfaFactor(
            any(), any(), any(), any(OktaDeleteMfaFactor.class)))
        .thenReturn(new ResponseEntity<Void>(HttpStatus.OK));
    ciamOktaDao.deleteOktaUser2fa(IDP_USER_ID);
    verify(deleteOktaUserMfaFactorClient, times(1))
        .deleteOktaUserMfaFactor(any(), any(), any(), any(OktaDeleteMfaFactor.class));
  }

  @Test(expected = ServiceException.class)
  public void testDeleteOktaUser2fa_whenCallToOktaFails_shouldThrowServiceException() {
    when(deleteOktaUserMfaFactorClient.deleteOktaUserMfaFactor(
            any(), any(), any(), any(OktaDeleteMfaFactor.class)))
        .thenThrow(new RuntimeException());
    ciamOktaDao.deleteOktaUser2fa(IDP_USER_ID);
  }

  @Test
  public void testResetPassword() {
    when(setOktaUserTempPasswordClient.setOktaUserTempPassword(any(), any(), any(), any()))
        .thenReturn(new ResponseEntity<Void>(HttpStatus.OK));
    ciamOktaDao.resetPassword("123", MockData.getOktaNewPassword());
    verify(setOktaUserTempPasswordClient, times(1))
        .setOktaUserTempPassword(any(), any(), any(), any());
  }

  @Test(expected = ServiceException.class)
  public void testDeleteAddOktaUserGroup_ThrowException() {
    when(deleteOktaUserGroupClient.deleteOktaUserGroup(
            anyString(), isNull(), anyString(), anyString()))
        .thenThrow(new RuntimeException());
    ciamOktaDao.deleteOktaUserGroup(IDP_USER_ID, USER_GROUP);
  }

  @Test(expected = ServiceException.class)
  public void testAddOktaUserGroup_throwException() {
    when(addOktaUserGroupClient.addUserGroup(anyString(), isNull(), anyString(), anyString()))
        .thenThrow(new RuntimeException());
    ciamOktaDao.addOktaUserGroup(IDP_USER_ID, USER_GROUP);
  }

  @Test(expected = ServiceException.class)
  public void testGetOktaUserGroups_throwException() {
    when(getOktaUserGroupsClient.getOktaUserGroups(anyString(), isNull(), anyString()))
        .thenThrow(new RuntimeException());
    ciamOktaDao.getUserOktaGroups(IDP_USER_ID);
  }

  @Test(expected = ServiceException.class)
  public void testSetOktaTempPassword_throwException() {
    when(setOktaUserTempPasswordClient.setOktaUserTempPassword(
            anyString(), isNull(), anyString(), any(OktaNewPassword.class)))
        .thenThrow(new RuntimeException());
    ciamOktaDao.setOktaTempPassword(IDP_USER_ID, new OktaNewPassword());
  }

  @Test(expected = ServiceException.class)
  public void testUnlockOktaUser_throwException() {
    when(unlockOktaUserClient.unlockOktaUser(anyString(), isNull(), anyString()))
        .thenThrow(new RuntimeException());
    ciamOktaDao.unlockOktaUser(IDP_USER_ID);
  }

  @Test(expected = ServiceException.class)
  public void testDeleteOktaUser_throwException() {
    when(deleteOktaUserClient.deleteOktaUser(anyString(), isNull(), anyString()))
        .thenThrow(new RuntimeException());
    ciamOktaDao.deleteOktaUser(IDP_USER_ID);
  }

  @Test(expected = FumServiceException.class)
  public void testCreateOktaUser_throwException() {
    when(createOktaUserClient.createOktaUser(anyString(), isNull(), any(OktaUserRequest.class)))
        .thenThrow(new RuntimeException());

    RequestAttributes mockRequest = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(mockRequest);
    ciamOktaDao.createOktaUser(MockData.getOktaUserRequest());
  }

  @Test
  public void testSuspendOktaUserProfile() {
    ciamOktaDao.suspendUserOktaProfile(IDP_USER_ID);
    verify(suspendOktaUserProfileClient, times(1))
        .suspendOktaUserProfile(anyString(), isNull(), anyString());
  }

  @Test(expected = ServiceException.class)
  public void testSuspendOktaUserProfile_throwException() {
    doThrow(new RuntimeException())
        .when(suspendOktaUserProfileClient)
        .suspendOktaUserProfile(anyString(), isNull(), anyString());
    ciamOktaDao.suspendUserOktaProfile(IDP_USER_ID);
  }

  @Test
  public void testUnsuspendOktaUserProfile() {
    ciamOktaDao.unsuspendUserOktaProfile(IDP_USER_ID);
    verify(unsuspendOktaUserProfileClient, times(1))
        .unsuspendOktaUserProfile(anyString(), isNull(), anyString());
  }

  @Test(expected = ServiceException.class)
  public void testUnsuspendOktaUserProfile_throwException() {
    doThrow(new RuntimeException())
        .when(unsuspendOktaUserProfileClient)
        .unsuspendOktaUserProfile(anyString(), isNull(), anyString());
    ciamOktaDao.unsuspendUserOktaProfile(IDP_USER_ID);
  }

  @Test
  public void testUpdateOktaSecureZoneId() {
    ciamOktaDao.updateOktaSecureZoneId(IDP_USER_ID, new String[] {});
    verify(updateOktaSecureZoneIdClient, times(1))
        .updateOktaSecureZoneId(anyString(), isNull(), anyString(), any());
  }

  @Test(expected = ServiceException.class)
  public void testUpdateOktaSecureZoneId_throwException() {
    doThrow(new RuntimeException())
        .when(updateOktaSecureZoneIdClient)
        .updateOktaSecureZoneId(anyString(), isNull(), anyString(), any());
    ciamOktaDao.updateOktaSecureZoneId(IDP_USER_ID, new String[] {});
  }

  @Test
  public void testSyncOktaUserProfile() {
    ciamOktaDao.syncOktaUserProfile(IDP_USER_ID);
    verify(syncOktaUserProfileClient, times(1))
        .syncOktaUserProfile(anyString(), isNull(), anyString());
  }

  @Test(expected = ServiceException.class)
  public void testSyncOktaUserProfile_throwException() {
    doThrow(new RuntimeException())
        .when(syncOktaUserProfileClient)
        .syncOktaUserProfile(anyString(), isNull(), anyString());
    ciamOktaDao.syncOktaUserProfile(IDP_USER_ID);
  }

  @Test
  public void testUpdateOktaUserEmail() {
    ciamOktaDao.updateOktaUserEmail(IDP_USER_ID, new OktaUserEmail());
    verify(updateOktaUserEmailClient, times(1))
        .updateOktaUserEmail(
            anyString(), isNull(), anyString(), any(OktaUserEmail.class), anyBoolean());
  }

  @Test(expected = ServiceException.class)
  public void testUpdateOktaUserEmail_throwException() {
    doThrow(new RuntimeException())
        .when(updateOktaUserEmailClient)
        .updateOktaUserEmail(
            anyString(), isNull(), anyString(), any(OktaUserEmail.class), anyBoolean());
    ciamOktaDao.updateOktaUserEmail(IDP_USER_ID, new OktaUserEmail());
  }

  @Test
  public void testCreateActiveOktaUser() {
    when(createActiveOktaUserClient.createOktaUser(anyString(), isNull(), any(OktaUserRequest.class)))
        .thenReturn(new ResponseEntity<>(HttpStatus.NO_CONTENT));
    ciamOktaDao.createActiveOktaUser(MockData.getOktaUserRequest());
    verify(createActiveOktaUserClient, times(1))
        .createOktaUser(anyString(), isNull(), any(OktaUserRequest.class));
  }

  @Test(expected = FumServiceException.class)
  public void testCreateActiveOktaUser_throwException() {
    doThrow(new RuntimeException())
        .when(createActiveOktaUserClient)
        .createOktaUser(anyString(), isNull(), any(OktaUserRequest.class));
    ciamOktaDao.createActiveOktaUser(MockData.getOktaUserRequest());
  }
}
