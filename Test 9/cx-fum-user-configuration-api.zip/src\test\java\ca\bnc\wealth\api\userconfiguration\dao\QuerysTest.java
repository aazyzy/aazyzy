package ca.bnc.wealth.api.userconfiguration.dao;

import java.lang.reflect.Constructor;
import org.junit.Test;

public class QuerysTest {

  @Test(expected = IllegalStateException.class)
  public void testQuerysConstructor() throws Exception {
    Constructor<Querys> constructor = Querys.class.getDeclaredConstructor();
    constructor.setAccessible(true);
    try {
      constructor.newInstance();
    } catch (Exception e) {
      throw (IllegalStateException) e.getCause();
    }
  }
}
