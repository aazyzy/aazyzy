package ca.bnc.wealth.api.userconfiguration.dao;

import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.anyMap;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

@RunWith(MockitoJUnitRunner.Silent.class)
@ExtendWith(MockitoExtension.class)
public class UserConfigurationDaoTest {

  private UserConfigurationDao userConfigurationDao;
  @Mock private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @Before
  public void setup() {
    userConfigurationDao = new UserConfigurationDao(namedParameterJdbcTemplate);
  }

  @Test
  public void test_deleteUserRRCodesByUserConfigurationId() {
    try {
      Mockito.doAnswer(invocation -> 1234)
          .when(namedParameterJdbcTemplate)
          .update(anyString(), anyMap());
      userConfigurationDao.deleteUserRRCodesByUserConfigurationId(1);
    } catch (Exception e) {
      fail("Test should not fail");
    }
  }

  @Test
  public void test_updateUserLastUpdateDate() {
    try {
      Mockito.doAnswer(invocation -> 1234)
          .when(namedParameterJdbcTemplate)
          .update(anyString(), anyMap());
      userConfigurationDao.updateUserLastUpdateDate(1, "test");
    } catch (Exception e) {
      fail("Test should not fail");
    }
  }

  @Test
  public void test_updateUserRRRange() {
    RRCodeRange rrCodeRange = new RRCodeRange();
    rrCodeRange.setFromRRCode("from");
    rrCodeRange.setToRRCode("to");
    userConfigurationDao.updateUserRRRange(rrCodeRange, 1, "test");
    verify(namedParameterJdbcTemplate, times(1)).update(anyString(), any(SqlParameterSource.class));
  }
}
