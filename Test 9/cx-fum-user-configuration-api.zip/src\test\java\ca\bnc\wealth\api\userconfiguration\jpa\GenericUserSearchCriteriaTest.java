package ca.bnc.wealth.api.userconfiguration.jpa;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import org.junit.Test;

public class GenericUserSearchCriteriaTest {

  @Test
  public void testGenericUserSearchCriteria() {
    GenericUserSearchCriteria value = GenericUserSearchCriteria.userConfigurationId;
    assertEquals(EnumQueryCriteria.EQUALS, value.getCriteria());
    assertEquals("userConfigurationId", value.getEntityField());
    assertNull(value.getDefaultValue());
    assertNull(value.getJoinTypes());
  }
}
