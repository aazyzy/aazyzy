package ca.bnc.wealth.api.userconfiguration.jpa;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import org.junit.Test;

public class UserSearchCriteriaTest {

  @Test
  public void testUserSearchCriteria() {
    UserSearchCriteria value = UserSearchCriteria.idpSubject;
    assertEquals(EnumQueryCriteria.IGNORE_CASE_CONTAINS, value.getCriteria());
    assertEquals("idpSubject", value.getEntityField());
    assertNull(value.getDefaultValue());
    assertNull(value.getJoinTypes());
  }
}
