package ca.bnc.wealth.api.userconfiguration.kafka;

import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.kafka.model.EventMessages;
import ca.bnc.wealth.common.kafka.model.audit.AuditUserConfigPayLoad;
import ca.bnc.wealth.common.messenger.Messenger;
import tools.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class AuditLogEventPublisherTest {

  @Mock private ObjectMapper objectMapper;
  @Mock private Messenger messager;

  @Test
  public void publish_shouldNotThrow_whenPublisherIsNotInitialized() {
    AuditLogEventPublisher auditLogEventPublisher = new AuditLogEventPublisher();
    try {
      auditLogEventPublisher.publish(new EventMessages<AuditUserConfigPayLoad>());
    } catch (Exception ex) {
      fail("publish should not throw in smoke scenario");
    }
  }

  @Test
  public void publish_shouldInvokeMessengerProcess_whenSerializationSucceeds() throws Exception {
    AuditLogEventPublisher auditLogEventPublisher = new AuditLogEventPublisher();
    FieldUtils.writeField(auditLogEventPublisher, "objectMapper", objectMapper, true);
    FieldUtils.writeField(auditLogEventPublisher, "messager", messager, true);
    when(objectMapper.writeValueAsString(any())).thenReturn("{\"a\":\"b\"}");

    auditLogEventPublisher.publish(new EventMessages<AuditUserConfigPayLoad>());

    verify(messager, times(1)).process(any());
  }
}
