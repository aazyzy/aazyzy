package ca.bnc.wealth.api.userconfiguration.kafka;

import static org.junit.Assert.fail;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import tools.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import ca.bnc.wealth.common.kafka.core.subscriber.SubscriberFactory;

@RunWith(SpringRunner.class)
public class SyncAckConsumerServiceTest {

  private SyncAckConsumerService syncAckConsumerService;

  @MockitoBean private SubscriberFactory subscriberFactory;
  @MockitoBean private ObjectMapper objectMapper;

  @Before
  public void setup() {
    syncAckConsumerService = new SyncAckConsumerService(subscriberFactory, objectMapper);
  }

  @Test
  public void processMessage_shouldNotThrow_forSmokePayload() {
    try {
      when(objectMapper.writeValueAsString("sync-ack")).thenReturn("\"sync-ack\"");
      syncAckConsumerService.processMessage("sync-ack");
      verify(objectMapper, times(1)).writeValueAsString("sync-ack");
    } catch (Exception ex) {
      fail("processMessage should not throw for smoke payload");
    }
  }
}
