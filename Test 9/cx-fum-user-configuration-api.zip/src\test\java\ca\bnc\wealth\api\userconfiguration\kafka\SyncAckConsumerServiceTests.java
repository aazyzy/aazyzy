package ca.bnc.wealth.api.userconfiguration.kafka;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.kafka.core.subscriber.KafkaConsumer;
import ca.bnc.wealth.common.kafka.core.subscriber.Subscriber;
import ca.bnc.wealth.common.kafka.core.subscriber.SubscriberFactory;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.kafka.listener.MessageListener;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import tools.jackson.core.JacksonException;

@RunWith(SpringRunner.class)
public class SyncAckConsumerServiceTests {

  private SyncAckConsumerService syncAckConsumerService;

  private Subscriber subscriber;

  @MockitoBean
  private SubscriberFactory subscriberFactory;

  private final ObjectMapper objectMapper = spy(JsonMapper.builderWithJackson2Defaults().build());

  @MockitoBean
  private MessageListener messageListener;

  @MockitoBean
  private KafkaConsumer kafkaConsumer;

  @Before
  public void setup() {
    syncAckConsumerService = new SyncAckConsumerService(subscriberFactory, objectMapper);
    subscriber = new Subscriber(kafkaConsumer, messageListener);
  }

//  @Test
//  public void testSubscribeToSyncAckConfig() {
//    when(subscriberFactory.createNewSubscriber(any(), any(), any())).thenReturn(subscriber);
//
//    syncAckConsumerService.init();
//    verify(subscriberFactory, times(1)).createNewSubscriber(any(), any(), any());
//  }

  @Test
  public void testProcessMessage() throws Exception {
    String message = "test message";

    syncAckConsumerService.processMessage(message);
    verify(objectMapper, times(1)).writeValueAsString(eq(message));
  }

  @Test(expected = JacksonException.class)
  public void testProcessMessage_whenUnableToConvertObject_shouldThrowException() throws Exception {
    when(objectMapper.writeValueAsString(any())).thenThrow(JacksonException.class);

    syncAckConsumerService.processMessage("message");
  }
}
