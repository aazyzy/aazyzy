package ca.bnc.wealth.api.userconfiguration.kafka;

import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import ca.bnc.wealth.api.userconfiguration.model.UserConfigurationConstants;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigurationService;
import ca.bnc.wealth.common.kafka.core.subscriber.SubscriberFactory;
import ca.bnc.wealth.common.kafka.model.EventMessages;
import ca.bnc.wealth.common.kafka.model.Header;
import ca.bnc.wealth.common.kafka.model.user.UserConfigDataPayLoad;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import java.util.ArrayList;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class UserConfigDataConsumerServiceTest {

  private UserConfigDataConsumerService userConfigDataConsumerService;

  @Mock private SubscriberFactory subscriberFactory;
  @Mock private UserConfigurationService userConfigurationService;
  private ObjectMapper objectMapper;

  @Before
  public void setup() {
    objectMapper = JsonMapper.builderWithJackson2Defaults().build();
    userConfigDataConsumerService =
        new UserConfigDataConsumerService(subscriberFactory, userConfigurationService, objectMapper);
  }

  @Test
  public void processMessage_shouldNotThrow_onEmptyPayload() {
    try {
      userConfigDataConsumerService.processMessage("");
    } catch (Exception ex) {
      fail("processMessage should swallow processing exceptions and not throw");
    }
  }

  @Test
  public void processMessage_shouldRouteUpdateAction_toService() throws Exception {
    EventMessages<UserConfigDataPayLoad> event = new EventMessages<>();
    Header header = new Header();
    header.setAction(UserConfigurationConstants.UPDATE_USERCONFIG_API);
    header.setRefId("idp-subject-1");
    event.setHeader(header);
    UserConfigDataPayLoad payload = new UserConfigDataPayLoad();
    payload.setRrCodeRanges(new ArrayList<>());
    event.setPayload(payload);

    String message = JsonMapper.builderWithJackson2Defaults().build().writeValueAsString(event);
    userConfigDataConsumerService.processMessage(message);

    verify(userConfigurationService, times(1))
        .updateUserRrCodeRangesBySubjectId(eq("idp-subject-1"), anyList());
  }

  @Test
  public void processMessage_shouldNotInvokeService_forNonUpdateAction() throws Exception {
    EventMessages<UserConfigDataPayLoad> event = new EventMessages<>();
    Header header = new Header();
    header.setAction("OTHER_ACTION");
    header.setRefId("idp-subject-1");
    event.setHeader(header);
    event.setPayload(new UserConfigDataPayLoad());

    String message = JsonMapper.builderWithJackson2Defaults().build().writeValueAsString(event);
    userConfigDataConsumerService.processMessage(message);

    verify(userConfigurationService, never()).updateUserRrCodeRangesBySubjectId(eq("idp-subject-1"), anyList());
  }

  @Test
  public void processMessage_shouldNotInvokeService_forMalformedJson() {
    userConfigDataConsumerService.processMessage("{bad-json");

    verify(userConfigurationService, never()).updateUserRrCodeRangesBySubjectId(eq("idp-subject-1"), anyList());
  }
}
