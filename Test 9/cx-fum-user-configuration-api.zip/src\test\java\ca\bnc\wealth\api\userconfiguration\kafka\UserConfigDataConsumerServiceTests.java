package ca.bnc.wealth.api.userconfiguration.kafka;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.userconfiguration.model.UserConfigurationConstants;
import ca.bnc.wealth.api.userconfiguration.service.UserConfigurationService;
import ca.bnc.wealth.common.kafka.core.subscriber.KafkaConsumer;
import ca.bnc.wealth.common.kafka.core.subscriber.Subscriber;
import ca.bnc.wealth.common.kafka.core.subscriber.SubscriberFactory;
import ca.bnc.wealth.common.kafka.model.EventMessages;
import ca.bnc.wealth.common.kafka.model.Header;
import ca.bnc.wealth.common.kafka.model.Origin;
import ca.bnc.wealth.common.kafka.model.Publisher;
import ca.bnc.wealth.common.kafka.model.RrCodeRanges;
import ca.bnc.wealth.common.kafka.model.Source;
import ca.bnc.wealth.common.kafka.model.user.UserConfigDataPayLoad;
import tools.jackson.databind.JavaType;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.listener.MessageListener;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@ExtendWith(MockitoExtension.class)
public class UserConfigDataConsumerServiceTests {

  Subscriber subscriber;
  @MockitoBean
  KafkaConsumer KafkaConsumer;
  @MockitoBean
  MessageListener MessageListener;
  @MockitoBean
  KafkaConsumer<?, ?> kafkaConsumer;
  private UserConfigDataConsumerService userConfigDataConsumerService;
  @MockitoBean
  private SubscriberFactory subscriberFactory;
  @MockitoBean
  private UserConfigurationService userConfigurationService;
  private final ObjectMapper objectMapper = spy(JsonMapper.builderWithJackson2Defaults().build());

  @Before
  public void setup() {
    userConfigDataConsumerService =
        new UserConfigDataConsumerService(subscriberFactory, userConfigurationService,
            objectMapper);
    subscriber = new Subscriber(KafkaConsumer, MessageListener);
  }

  @Test
  public void testSubscribeToUserConfig() {
    subscriber = new Subscriber(KafkaConsumer, MessageListener);
    when(subscriberFactory.createNewSubscriber(any(), any(), any(MessageListener.class))).thenReturn(subscriber);
    doNothing().when(kafkaConsumer).start();
    userConfigDataConsumerService.init();

    verify(subscriberFactory, times(1)).createNewSubscriber(any(), any(), any(MessageListener.class));
  }

  @Test
  public void testProcessMessage_whenEmptyMessage_shouldNotInvokeUpdateCall() {
    userConfigDataConsumerService.processMessage("");
    verify(userConfigurationService, times(0))
        .updateUserRrCodeRangesBySubjectId(anyString(), any());
  }

  @Test
  public void testProcessMessage_whenValidUpdateMessage() throws Exception {
    userConfigDataConsumerService.processMessage(
        objectMapper.writeValueAsString(getEventMessages()));
    verify(userConfigurationService, times(1))
        .updateUserRrCodeRangesBySubjectId(anyString(), any());
  }

  @Test
  public void testProcessMessage_whenUnableToParseMessage_shouldNotInvokeUpdateCall()
      throws Exception {
    doThrow(IllegalArgumentException.class).when(objectMapper)
        .readValue(anyString(), any(JavaType.class));

    userConfigDataConsumerService.processMessage(
        objectMapper.writeValueAsString(getEventMessages()));
    verify(userConfigurationService, times(0))
        .updateUserRrCodeRangesBySubjectId(anyString(), any());
  }

  @Test
  public void testProcessMessage_whenMissingHeaderInUpdateMessage_shouldNotInvokeUpdateCall()
      throws Exception {
    EventMessages<UserConfigDataPayLoad> eventMessages = getEventMessages();
    eventMessages.setHeader(null);

    userConfigDataConsumerService.processMessage(objectMapper.writeValueAsString(eventMessages));
    verify(userConfigurationService, times(0))
        .updateUserRrCodeRangesBySubjectId(anyString(), any());
  }

  @Test
  public void testProcessMessage_whenMissingIdpSubjectInUpdateMessage_shouldNotInvokeUpdateCall()
      throws Exception {
    EventMessages<UserConfigDataPayLoad> eventMessages = getEventMessages();
    eventMessages.getHeader().setRefId(null);

    userConfigDataConsumerService.processMessage(objectMapper.writeValueAsString(eventMessages));
    verify(userConfigurationService, times(0))
        .updateUserRrCodeRangesBySubjectId(anyString(), any());
  }

  @Test
  public void testProcessMessage_whenCreateMessage() throws Exception {
    EventMessages<UserConfigDataPayLoad> eventMessages = getEventMessages();
    eventMessages.getHeader().setAction(UserConfigurationConstants.CREATE_USERCONFIG_API);

    userConfigDataConsumerService.processMessage(objectMapper.writeValueAsString(eventMessages));
    verify(userConfigurationService, times(0))
        .updateUserRrCodeRangesBySubjectId(anyString(), any());
  }

  private EventMessages<UserConfigDataPayLoad> getEventMessages() {
    EventMessages<UserConfigDataPayLoad> eventMessages = new EventMessages<>();
    Header header = new Header();
    header.setId(UUID.randomUUID().toString());
    header.setRefId("6110");
    header.setAction("update");
    header.setState("state");
    header.setReason("create-firm");
    header.setVersion("v1");
    eventMessages.setHeader(header);
    Source source = new Source();
    Origin origin = new Origin();
    origin.setSystem("system");
    origin.setNbcId("nbcId");
    source.setOrigin(origin);
    Publisher publisher = new Publisher();
    publisher.setNbcId("nbcId");
    source.setPublisher(publisher);
    eventMessages.setSource(source);

    UserConfigDataPayLoad userConfigDataPayLoad = new UserConfigDataPayLoad();
    userConfigDataPayLoad.setId("6110");
    userConfigDataPayLoad.setMessageType("Type");

    List<RrCodeRanges> rrCodeRanges = new ArrayList<>();
    RrCodeRanges r1 = new RrCodeRanges();
    r1.setFromRRCode("AZAA");
    r1.setToRRCode("R3GL");
    rrCodeRanges.add(r1);
    userConfigDataPayLoad.setRrCodeRanges(rrCodeRanges);

    eventMessages.setPayload(userConfigDataPayLoad);
    return eventMessages;
  }
}
