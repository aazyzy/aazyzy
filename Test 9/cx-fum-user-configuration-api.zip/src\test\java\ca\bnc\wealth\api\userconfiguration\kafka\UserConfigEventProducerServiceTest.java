package ca.bnc.wealth.api.userconfiguration.kafka;

import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.kafka.core.config.KafkaConfiguration;
import ca.bnc.wealth.common.kafka.core.publisher.Publisher;
import ca.bnc.wealth.common.kafka.messaging.publisher.EventMessagePublisherFactory;
import ca.bnc.wealth.common.kafka.model.EventMessages;
import tools.jackson.databind.ObjectMapper;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@ExtendWith(MockitoExtension.class)
public class UserConfigEventProducerServiceTest {

  @MockitoBean
  EventMessagePublisherFactory publisherFactory;
  @MockitoBean
  ObjectMapper objectMapper;
  @MockitoBean
  Publisher eventPublisher;
  @MockitoBean
  KafkaConfiguration kafkaConfiguration;
  private UserConfigEventProducerService userConfigEventProducerService;

  @Before
  public void setup() {
    userConfigEventProducerService =
        new UserConfigEventProducerService(publisherFactory, objectMapper, kafkaConfiguration);
  }

  @Test
  public void testPublishMessage() throws Exception {
    when(publisherFactory.createNewPublisher(any())).thenReturn(eventPublisher);
    when(eventPublisher.publishSynchronous(any())).thenReturn(Optional.empty());
    userConfigEventProducerService.init();
    userConfigEventProducerService.publishMessage(new EventMessages<>());

    verify(publisherFactory, times(1)).createNewPublisher(any());
  }

  @Test
  public void testPublishMessage_whenUnableToPublish_shouldLogAndNotThrowException()
      throws Exception {
    when(publisherFactory.createNewPublisher(any())).thenReturn(eventPublisher);
    when(eventPublisher.publishSynchronous(any())).thenThrow(ExecutionException.class);

    try {
      userConfigEventProducerService.init();
      userConfigEventProducerService.publishMessage(new EventMessages<>());
    } catch (Exception e) {
      fail("This test should not throw any exception");
    }
  }
}
