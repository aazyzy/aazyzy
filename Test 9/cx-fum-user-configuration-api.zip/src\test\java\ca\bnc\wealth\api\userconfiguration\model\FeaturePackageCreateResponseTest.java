package ca.bnc.wealth.api.userconfiguration.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class FeaturePackageCreateResponseTest {

  @Test
  public void testFeaturePackageCreateResponse() {
    Long value = 1L;
    FeaturePackageCreateResponse featurePackageCreateResponse = new FeaturePackageCreateResponse();
    featurePackageCreateResponse.setFeaturePackageId(value);
    assertEquals(value, featurePackageCreateResponse.getFeaturePackageId());
  }
}
