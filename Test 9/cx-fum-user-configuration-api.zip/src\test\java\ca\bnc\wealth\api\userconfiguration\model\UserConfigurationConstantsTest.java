package ca.bnc.wealth.api.userconfiguration.model;

import java.lang.reflect.Constructor;
import org.junit.Test;

public class UserConfigurationConstantsTest {

  @Test(expected = IllegalStateException.class)
  public void testUserConfigurationConstantsConstructor() throws Exception {
    Constructor<UserConfigurationConstants> constructor = UserConfigurationConstants.class.getDeclaredConstructor();
    constructor.setAccessible(true);
    try {
      constructor.newInstance();
    } catch (Exception e) {
      throw (IllegalStateException) e.getCause();
    }
  }
}
