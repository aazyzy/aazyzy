package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.mock;

import ca.bnc.wealth.api.userconfiguration.kafka.AuditLogEventPublisher;
import ca.bnc.wealth.common.jpa.entity.enums.AuditEventType;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class AuditLogServiceTest {

  @Test
  public void publishAuditLog_shouldReturnSupplierValue_whenAuditDisabled() throws Exception {
    AuditLogService auditLogService = new AuditLogService();
    AuditLogEventPublisher publisher = mock(AuditLogEventPublisher.class);
    FieldUtils.writeField(auditLogService, "auditLogEventPublisher", publisher, true);
    FieldUtils.writeField(auditLogService, "enableUserConfigAudit", false, true);

    UserConfiguration result =
        auditLogService.publishAuditLog(
            null,
            false,
            AuditEventType.CREATE,
            () -> UserConfiguration.builder().userConfigurationId(101).build());

    assertEquals(Integer.valueOf(101), result.getUserConfigurationId());
    verify(publisher, never()).publish(org.mockito.ArgumentMatchers.any());
  }

  @Test
  public void publishAuditLog_shouldPropagateSupplierException() {
    AuditLogService auditLogService = new AuditLogService();
    try {
      auditLogService.publishAuditLog(
          null,
          false,
          AuditEventType.UPDATE,
          () -> {
            throw new IllegalStateException("supplier failed");
          });
      fail("Expected supplier exception to propagate");
    } catch (IllegalStateException expected) {
      assertEquals("supplier failed", expected.getMessage());
    }
  }
}
