package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.notNull;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.userconfiguration.kafka.AuditLogEventPublisher;
import ca.bnc.wealth.common.jpa.entity.enums.AuditEventType;
import ca.bnc.wealth.common.kafka.model.EventMessages;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class AuditLogServiceTests {

  @MockitoBean private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @MockitoBean private AuditLogEventPublisher auditLogEventPublisher;

  @MockitoBean private UserService userService;
  private AuditLogService auditLogService;

  @SneakyThrows
  @Before
  public void setup() {
    auditLogService = new AuditLogService();
    FieldUtils.writeField(
        auditLogService, "namedParameterJdbcTemplate", namedParameterJdbcTemplate, true);
    FieldUtils.writeField(auditLogService, "auditLogEventPublisher", auditLogEventPublisher, true);
    FieldUtils.writeField(auditLogService, "userService", userService, true);
    FieldUtils.writeField(auditLogService, "enableUserConfigAudit", true, true);
  }

  @Test
  public void publishAuditLog_create() {
    UserConfiguration output = new UserConfiguration();
    output.setUserConfigurationId(123);
    when(userService.getUserConfigurationWithRrCodeById(anyInt()))
        .thenReturn(output);
    when(userService.getUserConfigurationWithRrCodeByIdFromTable(anyInt()))
        .thenReturn(output);
    when(namedParameterJdbcTemplate.queryForObject(
            any(String.class), any(MapSqlParameterSource.class), any(Class.class)))
        .thenReturn("id|r2|r2|r3|");
    UserConfiguration uc = auditLogService.publishAuditLog(
        null,
        true,
        AuditEventType.CREATE,
        () -> output);
    assert(uc != null);
    assertEquals(123, uc.getUserConfigurationId().longValue());
  }

  @Test
  public void publishAuditLog_update() {
    UserConfiguration output = new UserConfiguration();
    output.setUserConfigurationId(123);
    when(userService.getUserConfigurationWithRrCodeById(anyInt()))
        .thenReturn(output);
    when(userService.getUserConfigurationWithRrCodeByIdFromTable(anyInt()))
        .thenReturn(output);
    when(namedParameterJdbcTemplate.queryForObject(
        any(String.class), any(MapSqlParameterSource.class), any(Class.class)))
        .thenReturn("id|r2|r2|r3|");
    when(userService.getUserConfigurationWithRrCodeById(anyInt()))
        .thenReturn(new UserConfiguration());
    when(namedParameterJdbcTemplate.queryForObject(
            any(String.class), any(MapSqlParameterSource.class), any(Class.class)))
        .thenReturn("id|r2|r2|r3|");
    UserConfiguration uc = auditLogService.publishAuditLog(
        3,
        true,
        AuditEventType.UPDATE,
        () -> output);
    assertEquals(123, uc.getUserConfigurationId().longValue());
  }

  @Test
  public void publishAuditLog_update_readsBeforeSnapshotFromTable_notMaterializedView() {
    UserConfiguration output = new UserConfiguration();
    output.setUserConfigurationId(123);
    // Both the before and after snapshots must be read from the USER_CONFIGURATION
    // table so they are built through the identical mapping path (NWPI-14590).
    // idpUserId is left null so getUserConfiguration returns early without triggering
    // downstream enrichment.
    when(userService.getUserConfigurationWithRrCodeByIdFromTable(anyInt()))
        .thenReturn(output);

    auditLogService.publishAuditLog(3, false, AuditEventType.UPDATE, () -> output);

    // The materialized-view read must no longer build the audit snapshot.
    verify(userService, never()).getUserConfigurationWithRrCodeById(anyInt());
    // The synchronous before snapshot is read from the table.
    verify(userService, atLeastOnce()).getUserConfigurationWithRrCodeByIdFromTable(anyInt());
  }
}
