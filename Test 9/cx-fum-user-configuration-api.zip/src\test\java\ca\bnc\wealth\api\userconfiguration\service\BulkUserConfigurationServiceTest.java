package ca.bnc.wealth.api.userconfiguration.service;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import ca.bnc.wealth.api.userconfiguration.util.BulkUserConstants;
import ca.bnc.wealth.api.userconfiguration.util.MockData;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentFirm;
import ca.bnc.wealth.common.userconfiguration.model.Response;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class BulkUserConfigurationServiceTest {

  @Mock
  private UserService userService;

  @Mock
  private UserConfigurationService userConfigurationService;

  @Mock
  private UserAssignmentService userAssignmentService;

  @Mock
  private BulkUserValidationService bulkUserValidationService;

  @Mock
  private FirmBmaGuardService firmBmaGuardService;

  @InjectMocks
  private BulkUserConfigurationService bulkUserConfigurationService;

  @Test
  void testUpdateUser_Success() {
    Map<String, String> requestMap = new HashMap<>();
    requestMap.put(BulkUserConstants.USER_NAME, "john.doe");
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setUserConfigurationId(1);
    userConfiguration.setIdpSubject("idpSubject");
    userConfiguration.setIdpUserId("idpUserId");
    userConfiguration.setCompassR2Id("r2");
    userConfiguration.setSecureZoneIds(List.of("sz"));

    when(userService.getUserConfigurationByIdOrName("john.doe")).thenReturn(userConfiguration);
    when(userService.getCompassR2Id(anyString())).thenReturn("compass123");
    String[] sz = new String[1];
    sz[0] = "sz";
    when(userService.getSecureZoneId(anyString())).thenReturn(sz);
    when(bulkUserValidationService.userUpdateValidation(any(UserConfiguration.class))).thenReturn(
        Collections.emptyList());

    Response response = bulkUserConfigurationService.updateUser(requestMap);

    assertEquals(BulkUploadStatus.SUCCESS.name(), response.getStatus());
  }

  @Test
  void testUpdateUser_UserNotFound() {
    Map<String, String> requestMap = new HashMap<>();
    requestMap.put(BulkUserConstants.USER_NAME, "john.doe");
    when(userService.getUserConfigurationByIdOrName("john.doe")).thenThrow(new RuntimeException("User not found"));

    Response response = bulkUserConfigurationService.updateUser(requestMap);

    assertEquals(BulkUploadStatus.FAILED.name(), response.getStatus());
  }

  @Test
  void testUpdateUser_ValidationFailed() {
    Map<String, String> requestMap = new HashMap<>();
    requestMap.put(BulkUserConstants.USER_NAME, "john.doe");
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setUserConfigurationId(1);

    when(userService.getUserConfigurationByIdOrName("john.doe")).thenReturn(userConfiguration);
    when(userService.getCompassR2Id(anyString())).thenReturn("compass123");
    String[] sz = new String[1];
    sz[0] = "sz";
    when(userService.getSecureZoneId(anyString())).thenReturn(sz);
    when(bulkUserValidationService.userUpdateValidation(any(UserConfiguration.class)))
        .thenReturn(List.of(Pair.of("ERR_CODE", "Validation error")));

    Response response = bulkUserConfigurationService.updateUser(requestMap);

    assertEquals(BulkUploadStatus.FAILED.name(), response.getStatus());
  }

  @Test
  void testUpdateUser_Exception() {
    Map<String, String> requestMap = new HashMap<>();
    requestMap.put(BulkUserConstants.USER_NAME, "john.doe");
    when(userService.getUserConfigurationByIdOrName("john.doe")).thenThrow(new RuntimeException("Unexpected error"));

    Response response = bulkUserConfigurationService.updateUser(requestMap);

    assertEquals(BulkUploadStatus.FAILED.name(), response.getStatus());
  }

  @Test
  void testUpdateUser_whenRRCodeAndFirmLevel_shouldSucceed() {
    Map<String,String> requestMap = new HashMap<>();
    requestMap.put(BulkUserConstants.USER_NAME, "user");
    requestMap.put(BulkUserConstants.REQUEST_ID, "123");
    requestMap.put(BulkUserConstants.CURRENT_USER, "current_user");
    requestMap.put(BulkUserConstants.DEFAULT_MODULE, "defaultModule");
    requestMap.put(BulkUserConstants.FIRM_LEVEL_ACCESS, "firm_level_access");
    requestMap.put(BulkUserConstants.RR_CODES, "AABB,CCDD");

    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(MockData.getUserConfiguration());
    when(userService.getCompassR2Id(anyString())).thenReturn("compassR2");
    when(userService.getSecureZoneId(anyString())).thenReturn(new String[]{"secureZoneId"});
    List<Object> list = new ArrayList<>();
    list.add(MockData.getUserAssignmentFirmEntityList().get(0));
    when(userAssignmentService.getUserAssignment(anyString(), any(UserAssignmentType.class)))
        .thenReturn(list);
    when(bulkUserValidationService.userUpdateValidation(any())).thenReturn(new ArrayList<>());

    Response response = bulkUserConfigurationService.updateUser(requestMap);
    assertEquals("SUCCESS", response.getStatus());
  }

  @Test
  void testUpdateUser_whenUserAssignmentHasNoFirm_shouldSucceed() {
    Map<String,String> requestMap = new HashMap<>();
    requestMap.put(BulkUserConstants.USER_NAME, "user");
    requestMap.put(BulkUserConstants.REQUEST_ID, "123");
    requestMap.put(BulkUserConstants.CURRENT_USER, "current_user");
    requestMap.put(BulkUserConstants.DEFAULT_MODULE, "defaultModule");
    requestMap.put(BulkUserConstants.FIRM_LEVEL_ACCESS, "firm_level_access");
    requestMap.put(BulkUserConstants.RR_CODES, "AABB,CCDD");

    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(MockData.getUserConfiguration());
    when(userService.getCompassR2Id(anyString())).thenReturn("compassR2");
    when(userService.getSecureZoneId(anyString())).thenReturn(new String[]{"secureZoneId"});

    UserAssignmentFirm userAssignmentFirm = MockData.getUserAssignmentFirmEntityList().get(0);
    userAssignmentFirm.setFirm(null);

    List<Object> list = new ArrayList<>();
    list.add(userAssignmentFirm);
    when(userAssignmentService.getUserAssignment(anyString(), any(UserAssignmentType.class)))
        .thenReturn(list);
    when(bulkUserValidationService.userUpdateValidation(any())).thenReturn(new ArrayList<>());

    Response response = bulkUserConfigurationService.updateUser(requestMap);
    assertEquals("SUCCESS", response.getStatus());
  }

  @Test
  void testUpdateUser_whenSingleRrCode_shouldSucceed() {
    Map<String,String> requestMap = new HashMap<>();
    requestMap.put(BulkUserConstants.USER_NAME, "user");
    requestMap.put(BulkUserConstants.REQUEST_ID, "123");
    requestMap.put(BulkUserConstants.CURRENT_USER, "current_user");
    requestMap.put(BulkUserConstants.DEFAULT_MODULE, "defaultModule");
    requestMap.put(BulkUserConstants.FIRM_LEVEL_ACCESS, "firm_level_access");
    requestMap.put(BulkUserConstants.RR_CODES, "AABB");

    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(MockData.getUserConfiguration());
    when(userService.getCompassR2Id(anyString())).thenReturn("compassR2");
    when(userService.getSecureZoneId(anyString())).thenReturn(new String[]{"secureZoneId"});

    UserAssignmentFirm userAssignmentFirm = MockData.getUserAssignmentFirmEntityList().get(0);
    userAssignmentFirm.setFirm(null);

    List<Object> list = new ArrayList<>();
    list.add(userAssignmentFirm);
    when(userAssignmentService.getUserAssignment(anyString(), any(UserAssignmentType.class)))
        .thenReturn(list);
    when(bulkUserValidationService.userUpdateValidation(any())).thenReturn(new ArrayList<>());

    Response response = bulkUserConfigurationService.updateUser(requestMap);
    assertEquals("SUCCESS", response.getStatus());
  }

  @Test
  void testUpdateUser_whenDefaultModuleIsNotPresent_shouldSucceed() {
    Map<String,String> requestMap = new HashMap<>();
    requestMap.put(BulkUserConstants.USER_NAME, "user");
    requestMap.put(BulkUserConstants.REQUEST_ID, "123");
    requestMap.put(BulkUserConstants.CURRENT_USER, "current_user");
    requestMap.put(BulkUserConstants.FIRM_LEVEL_ACCESS, "firm_level_access");
    requestMap.put(BulkUserConstants.RR_CODES, "AABB,CCDD");

    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(MockData.getUserConfiguration());
    when(userService.getCompassR2Id(anyString())).thenReturn("compassR2");
    when(userService.getSecureZoneId(anyString())).thenReturn(new String[]{"secureZoneId"});
    List<Object> list = new ArrayList<>();
    list.add(MockData.getUserAssignmentFirmEntityList().get(0));

    Response response = bulkUserConfigurationService.updateUser(requestMap);
    assertEquals("SUCCESS", response.getStatus());
  }

  @Test
  void testUpdateUser_whenRRCodeAndFirmLevelTrueAndSecureZoneId_shouldSucceed() {
    Map<String,String> requestMap = new HashMap<>();
    requestMap.put(BulkUserConstants.USER_NAME, "user");
    requestMap.put(BulkUserConstants.REQUEST_ID, "123");
    requestMap.put(BulkUserConstants.CURRENT_USER, "current_user");
    requestMap.put(BulkUserConstants.DEFAULT_MODULE, "invalid");
    requestMap.put(BulkUserConstants.SECURE_ZONE_ID, "1234");
    requestMap.put(BulkUserConstants.FIRM_LEVEL_ACCESS, "true");
    requestMap.put(BulkUserConstants.RR_CODES, "AABB,CCDD");

    UserConfiguration user = MockData.getUserConfiguration();
    user.setUserPreferences(null);

    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(user);
    when(userService.getCompassR2Id(anyString())).thenReturn("compassR2");
    when(userService.getSecureZoneId(anyString())).thenReturn(new String[]{"secureZoneId"});
    List<Object> list = new ArrayList<>();
    list.add(MockData.getUserAssignmentFirmEntityList().get(0));
    when(userAssignmentService.getUserAssignment(anyString(), any(UserAssignmentType.class)))
        .thenReturn(list);
    when(bulkUserValidationService.userUpdateValidation(any())).thenReturn(new ArrayList<>());

    Response response = bulkUserConfigurationService.updateUser(requestMap);
    assertEquals("SUCCESS", response.getStatus());
  }

  @Test
  void testUpdateUser_whenDataCorrupt_shouldFail() {
    Map<String,String> requestMap = new HashMap<>();
    requestMap.put(BulkUserConstants.USER_NAME, "user");
    requestMap.put(BulkUserConstants.REQUEST_ID, "123");
    requestMap.put(BulkUserConstants.CURRENT_USER, "current_user");
    requestMap.put(BulkUserConstants.DEFAULT_MODULE, "defaultModule");

    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(MockData.getUserConfiguration());
    when(userService.getCompassR2Id(anyString())).thenReturn("compassR2");
    when(userService.getSecureZoneId(anyString())).thenReturn(new String[]{"secureZoneId"});
    List<Object> list = new ArrayList<>();
    list.add(MockData.getUserAssignmentFirmEntityList().get(0));
    when(userAssignmentService.getUserAssignment(anyString(), any(UserAssignmentType.class)))
        .thenReturn(Collections.singletonList(list));

    Response response = bulkUserConfigurationService.updateUser(requestMap);
    assertEquals("FAILED", response.getStatus());
  }

  @Test
  void testUpdateUser_whenValidationFail_shouldFail() {
    Map<String,String> requestMap = new HashMap<>();
    requestMap.put(BulkUserConstants.USER_NAME, "user");
    requestMap.put(BulkUserConstants.REQUEST_ID, "123");
    requestMap.put(BulkUserConstants.CURRENT_USER, "current_user");
    requestMap.put(BulkUserConstants.DEFAULT_MODULE, "defaultModule");
    requestMap.put(BulkUserConstants.FIRM_LEVEL_ACCESS, "firm_level_access");
    requestMap.put(BulkUserConstants.RR_CODES, "AABB,CCDD");

    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(MockData.getUserConfiguration());
    when(userService.getCompassR2Id(anyString())).thenReturn("compassR2");
    when(userService.getSecureZoneId(anyString())).thenReturn(new String[]{"secureZoneId"});
    List<Object> list = new ArrayList<>();
    list.add(MockData.getUserAssignmentFirmEntityList().get(0));
    when(userAssignmentService.getUserAssignment(anyString(), any(UserAssignmentType.class)))
        .thenReturn(list);
    Pair<String, String> pair = Pair.of("ERR_CODE", "ERR_MESSAGE");
    ArrayList<Pair<String, String>> validationList = new ArrayList<>();
    validationList.add(pair);
    when(bulkUserValidationService.userUpdateValidation(any(UserConfiguration.class))).thenReturn(validationList);

    Response response = bulkUserConfigurationService.updateUser(requestMap);
    assertEquals("FAILED", response.getStatus());
  }

  @Test
  void testUpdateUser_whenFirmBmaInProgress_shouldFail() {
    Map<String, String> requestMap = new HashMap<>();
    requestMap.put(BulkUserConstants.USER_NAME, "user");
    requestMap.put(BulkUserConstants.REQUEST_ID, "123");
    requestMap.put(BulkUserConstants.CURRENT_USER, "current_user");

    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setFirmId("FIRM001");

    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(userConfiguration);
    when(userService.getCompassR2Id(anyString())).thenReturn("compassR2");
    when(userService.getSecureZoneId(anyString())).thenReturn(new String[]{"secureZoneId"});

    when(firmBmaGuardService.isFirmBmaInProgress("FIRM001")).thenReturn(true);

    Response response = bulkUserConfigurationService.updateUser(requestMap);
    assertEquals("FAILED", response.getStatus());
    assertEquals(BulkUserConstants.ERROR_FIRM_BMA_IN_PROGRESS, response.getErrorCode());
  }

  @Test
  void testUpdateUser_whenFirmBmaNotInProgress_shouldProceed() {
    Map<String, String> requestMap = new HashMap<>();
    requestMap.put(BulkUserConstants.USER_NAME, "user");
    requestMap.put(BulkUserConstants.REQUEST_ID, "123");
    requestMap.put(BulkUserConstants.CURRENT_USER, "current_user");

    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setFirmId("FIRM001");

    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(userConfiguration);
    when(userService.getCompassR2Id(anyString())).thenReturn("compassR2");
    when(userService.getSecureZoneId(anyString())).thenReturn(new String[]{"secureZoneId"});
    when(firmBmaGuardService.isFirmBmaInProgress("FIRM001")).thenReturn(false);
    when(bulkUserValidationService.userUpdateValidation(any())).thenReturn(new ArrayList<>());

    Response response = bulkUserConfigurationService.updateUser(requestMap);
    assertEquals(BulkUploadStatus.SUCCESS.name(), response.getStatus());
  }

  @Test
  void testUpdateUser_whenFirmBmaInProgress_shouldReturnCorrectErrorMessage() {
    Map<String, String> requestMap = new HashMap<>();
    requestMap.put(BulkUserConstants.USER_NAME, "user");
    requestMap.put(BulkUserConstants.REQUEST_ID, "456");
    requestMap.put(BulkUserConstants.CURRENT_USER, "admin");

    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setFirmId("FIRM002");

    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(userConfiguration);
    when(userService.getCompassR2Id(anyString())).thenReturn("compassR2");
    when(userService.getSecureZoneId(anyString())).thenReturn(new String[]{"secureZoneId"});
    when(firmBmaGuardService.isFirmBmaInProgress("FIRM002")).thenReturn(true);

    Response response = bulkUserConfigurationService.updateUser(requestMap);
    assertEquals(BulkUploadStatus.FAILED.name(), response.getStatus());
    assertEquals(BulkUserConstants.ERROR_FIRM_BMA_IN_PROGRESS, response.getErrorCode());
    assertEquals(BulkUserConstants.ERROR_FIRM_BMA_IN_PROGRESS_MESSAGE, response.getErrorMessage());
    assertEquals("456", response.getId());
  }
}