package ca.bnc.wealth.api.userconfiguration.service;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.userconfiguration.util.BulkUserConstants;
import ca.bnc.wealth.api.userconfiguration.util.MockData;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class BulkUserValidationServiceTest {

  @Mock
  private UserService userService;

  @Mock
  private R2Service r2Service;

  @InjectMocks
  private BulkUserValidationService bulkUserValidationService;

  @Test
  void userUpdateValidation_whenEmailIsInvalid() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setEmail("invalidEmail");
    List<Pair<String, String>> expected = new ArrayList<>();
    expected.add(Pair.of(BulkUserConstants.ERROR_EMAIL_INVALID_FORMAT, BulkUserConstants.ERROR_EMAIL_INVALID_FORMAT_MESSAGE));
    expected.add(Pair.of(BulkUserConstants.ERROR_RRCODE_INVALID, BulkUserConstants.ERROR_RRCODE_INVALID_MESSAGE));

    List<Pair<String, String>> actual = bulkUserValidationService.userUpdateValidation(userConfiguration);

    assertEquals(expected, actual);
  }

  @Test
  void userUpdateValidation_whenInvalidRRCode() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    List<Pair<String, String>> expected = new ArrayList<>();
    expected.add(Pair.of(BulkUserConstants.ERROR_RRCODE_INVALID, BulkUserConstants.ERROR_RRCODE_INVALID_MESSAGE));

    List<Pair<String, String>> actual = bulkUserValidationService.userUpdateValidation(userConfiguration);

    assertEquals(expected, actual);
  }

  @Test
  void userUpdateValidate_whenR2Invalid() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.compassR2Id("invalid");
    when(userService.validRrCodeRangeForFirmId(anyString(), any(), any())).thenReturn(true);
    when(r2Service.r2ValidationForUpdateUser(anyString(), anyString())).thenReturn(Pair.of(false, "R2 not found"));
    List<Pair<String, String>> expected = new ArrayList<>();
    expected.add(Pair.of(BulkUserConstants.ERROR_R2_NOT_FOUND, BulkUserConstants.ERROR_R2_NOT_FOUND_MESSAGE));

    List<Pair<String, String>> actual = bulkUserValidationService.userUpdateValidation(userConfiguration);

    assertEquals(expected, actual);
  }

  @Test
  void userUpdateValidate_whenR2IsValid() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.compassR2Id("invalid");
    when(userService.validRrCodeRangeForFirmId(anyString(), any(), any())).thenReturn(true);
    when(r2Service.r2ValidationForUpdateUser(anyString(), anyString())).thenReturn(Pair.of(true, "R2 is found"));
    List<Pair<String, String>> expected = new ArrayList<>();
    expected.add(Pair.of(BulkUserConstants.ERROR_R2_NOT_FOUND, BulkUserConstants.ERROR_R2_NOT_FOUND_MESSAGE));

    List<Pair<String, String>> actual = bulkUserValidationService.userUpdateValidation(userConfiguration);

    assertEquals(0, actual.size());
  }

  @Test
  void userUpdateValidate_whenR2IsNull() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    when(userService.validRrCodeRangeForFirmId(anyString(), any(), any())).thenReturn(true);
    List<Pair<String, String>> expected = new ArrayList<>();
    expected.add(Pair.of(BulkUserConstants.ERROR_R2_NOT_FOUND, BulkUserConstants.ERROR_R2_NOT_FOUND_MESSAGE));

    List<Pair<String, String>> actual = bulkUserValidationService.userUpdateValidation(userConfiguration);

    assertEquals(0, actual.size());
  }

}