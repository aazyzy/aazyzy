package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.userconfiguration.dao.CiamOktaDao;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import java.util.Arrays;
import java.util.Optional;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class CiamServiceTest {

  private CiamService ciamService;

  @MockitoBean private CiamOktaDao ciamOktaDao;

  @Before
  public void setup() {
    ciamService = new CiamService(ciamOktaDao);
  }

  @Test
  public void getOktaUserProfileWithRetry_shouldReturnProfile_afterRetry() {
    OktaUserProfile profile = new OktaUserProfile();
    when(ciamOktaDao.getOktaUserProfile("idp-user"))
        .thenThrow(new RuntimeException("temporary failure"))
        .thenReturn(profile);

    Optional<OktaUserProfile> result = ciamService.getOktaUserProfile("idp-user", 2);

    assertTrue(result.isPresent());
    verify(ciamOktaDao, times(2)).getOktaUserProfile("idp-user");
  }

  @Test(expected = FumNotFoundException.class)
  public void getOktaUserProfile_shouldThrowNotFound_whenDaoReturnsNull() {
    when(ciamOktaDao.getOktaUserProfile("missing-user")).thenReturn(null);

    ciamService.getOktaUserProfile("missing-user");
  }

  @Test
  public void getOktaUserProfileWithRetry_shouldReturnEmpty_whenRetriesExhausted() {
    when(ciamOktaDao.getOktaUserProfile("idp-user")).thenThrow(new RuntimeException("always fail"));

    Optional<OktaUserProfile> result = ciamService.getOktaUserProfile("idp-user", 2);

    assertFalse(result.isPresent());
    verify(ciamOktaDao, times(2)).getOktaUserProfile("idp-user");
  }

  @Test
  public void updateOktaUserGroups_shouldReplaceCompassXGroups_whenRequestedGroupMissing() {
    when(ciamOktaDao.getUserOktaGroups("idp-user"))
        .thenReturn(Arrays.asList("Wealth.CompassX.Old", "SomeOtherGroup"));

    ciamService.updateOktaUserGroups("idp-user", "Wealth.CompassX.New");

    verify(ciamOktaDao, times(1)).deleteOktaUserGroup("idp-user", "Wealth.CompassX.Old");
    verify(ciamOktaDao, times(1)).addOktaUserGroup("idp-user", "Wealth.CompassX.New");
  }

  @Test
  public void updateOktaUserGroups_shouldNotModify_whenRequestedGroupAlreadyPresent() {
    when(ciamOktaDao.getUserOktaGroups("idp-user"))
        .thenReturn(Arrays.asList("Wealth.CompassX.New", "SomeOtherGroup"));

    ciamService.updateOktaUserGroups("idp-user", "Wealth.CompassX.New");

    verify(ciamOktaDao, never()).deleteOktaUserGroup("idp-user", "Wealth.CompassX.New");
    verify(ciamOktaDao, never()).addOktaUserGroup("idp-user", "Wealth.CompassX.New");
  }

  @Test(expected = FumNotFoundException.class)
  public void getOktaUserProfile_shouldThrowNotFound_whenIdpUserIdBlank() {
    try {
      ciamService.getOktaUserProfile("");
    } finally {
      verify(ciamOktaDao, never()).getOktaUserProfile(anyString());
    }
  }

  @Test
  public void getOktaUserProfileWithRetry_shouldReturnEmpty_whenIdpUserIdBlank() {
    Optional<OktaUserProfile> result = ciamService.getOktaUserProfile("", 2);

    assertFalse(result.isPresent());
    verify(ciamOktaDao, never()).getOktaUserProfile(anyString());
  }

  @Test
  public void updateOktaUserGroups_shouldSkip_whenIdpUserIdBlank() {
    ciamService.updateOktaUserGroups("", "Wealth.CompassX.New");

    verify(ciamOktaDao, never()).getUserOktaGroups(anyString());
  }
}
