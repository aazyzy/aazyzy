package ca.bnc.wealth.api.userconfiguration.service;

import static ca.bnc.wealth.api.userconfiguration.util.MockData.IDP_USER_ID;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.USER_CONFIGURATION_ID;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.userconfiguration.dao.CiamOktaDao;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.MockData;
import ca.bnc.wealth.common.ciam.model.OktaAccessProfile;
import ca.bnc.wealth.common.ciam.model.OktaFactor;
import ca.bnc.wealth.common.ciam.model.OktaNewPassword;
import ca.bnc.wealth.common.ciam.model.OktaUserEmail;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.ciam.model.OktaUserRequest;
import ca.bnc.wealth.common.ciam.model.OktaUserWithHashedPasswordRequest;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ErrorSeverity;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ServiceException;
import java.util.List;
import java.util.Optional;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletWebRequest;

@RunWith(SpringRunner.class)
public class CiamServiceTests {

  private static final int RETRY_COUNT = 2;

  private CiamService ciamService;
  @MockitoBean
  private CiamOktaDao ciamOktaDao;

  @Before
  public void setup() {
    ciamService =
        new CiamService(ciamOktaDao);
  }

  @Test
  public void testCreateOktaUser() {

    OktaUserRequest mockOktaUserRequest = MockData.getOktaUserRequest();
    ciamService.createOktaUser(mockOktaUserRequest);
    verify(ciamOktaDao, times(1)).createOktaUser(Mockito.any());
  }

  @Test
  public void testCreateOktaUserWithHashedPassword() {
    ciamService.createOktaUserWithHashedPassword(new OktaUserWithHashedPasswordRequest());
    verify(ciamOktaDao, times(1)).createOktaUserWithHashedPassword(
        any(OktaUserWithHashedPasswordRequest.class));
  }

  @Test
  public void testCreateActiveOktaUserWithHashedPassword() {
    ciamService.createActiveOktaUserWithHashedPassword(new OktaUserWithHashedPasswordRequest());
    verify(ciamOktaDao, times(1)).createActiveOktaUserWithHashedPassword(
        any(OktaUserWithHashedPasswordRequest.class));
  }

  @Test(expected = ServiceException.class)
  public void testCreateOktaUserWithHashedPassword_whenCallToOktaFails_shouldThrowException() {
    doThrow(new ServiceException(ErrorSeverity.ERROR, "Error creating user in Okta")).when(
        ciamOktaDao).createOktaUserWithHashedPassword(any(OktaUserWithHashedPasswordRequest.class));
    ciamService.createOktaUserWithHashedPassword(new OktaUserWithHashedPasswordRequest());
  }

  @Test
  public void testGetOktaUserProfile() {
    OktaUserProfile mockOktaUserProfile = MockData.getOktaUserProfile();
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(mockOktaUserProfile);
    OktaUserProfile oktaUserProfile = ciamService.getOktaUserProfile(IDP_USER_ID);
    Assert.assertEquals(mockOktaUserProfile.getAccessProfile().getEmail(),
        oktaUserProfile.getAccessProfile().getEmail());
  }

  @Test(expected = FumNotFoundException.class)
  public void testGetOktaUserProfile_whenOktaProfileIsNul_shouldThrowNoResultsFoundException() {
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(null);
    ciamService.getOktaUserProfile(IDP_USER_ID);
  }

  @Test
  public void testGetOktaUserProfileWithRetry() {
    OktaUserProfile mockOktaUserProfile = MockData.getOktaUserProfile();
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(mockOktaUserProfile);
    OktaUserProfile oktaUserProfile = ciamService.getOktaUserProfile(IDP_USER_ID, 1).get();
    Assert.assertEquals(mockOktaUserProfile.getAccessProfile().getEmail(),
        oktaUserProfile.getAccessProfile().getEmail());
  }

  @Test
  public void testGetOktaUserProfileWithRetryException() {
    OktaUserProfile mockOktaUserProfile = MockData.getOktaUserProfile();
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenThrow(
        new ServiceException(ErrorSeverity.ERROR, "Error getting user profile from Okta"));
    Optional<OktaUserProfile> oktaUserProfile = ciamService.getOktaUserProfile(IDP_USER_ID, 1);
    Assert.assertFalse(oktaUserProfile.isPresent());
  }

  @Test
  public void testDeleteOktaUserProfile() {
    OktaUserProfile oktaUserProfile = MockData.getOktaUserProfile();
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(oktaUserProfile);
    Mockito.doNothing().when(ciamOktaDao).deleteOktaUser(anyString());
    ciamService.deleteOktaUserProfile(IDP_USER_ID);
    verify(ciamOktaDao, times(1)).deleteOktaUser(Mockito.any());
  }

  @Test
  public void testResetPassword() {
    Mockito.doNothing().when(ciamOktaDao)
        .resetPassword(anyString(), Mockito.any(OktaNewPassword.class));
    ciamService.resetPassword(String.valueOf(USER_CONFIGURATION_ID), new OktaNewPassword());
    verify(ciamOktaDao, times(1)).resetPassword(Mockito.any(), Mockito.any());
  }

  @Test
  public void testDeleteOktaUser2Fa() {
    OktaUserProfile oktaUserProfile = MockData.getOktaUserProfile();
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(oktaUserProfile);
    ciamService.deleteOktaUser2fa(IDP_USER_ID);
    verify(ciamOktaDao, times(1)).getOktaUserProfile(Mockito.any());
  }

  @Test
  public void testDeleteOktaUser2Fa_whenSms2faNotPresent_shouldNotCallOkta() {
    OktaFactor oktaFactor = new OktaFactor();
    oktaFactor.setFactorType("email");
    OktaFactor[] oktaFactors = {oktaFactor};

    OktaUserProfile oktaUserProfile = MockData.getOktaUserProfile();
    oktaUserProfile.setFactors(oktaFactors);

    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(oktaUserProfile);
    ciamService.deleteOktaUser2fa(IDP_USER_ID);
    verify(ciamOktaDao, times(0)).deleteOktaUser2fa(any());
  }

  @Test
  public void testNoChangeInUserGroups() {
    List<String> userGroups = MockData.getUserGroupList();
    when(ciamOktaDao.getUserOktaGroups(anyString())).thenReturn(userGroups);
    ciamService.updateOktaUserGroups(IDP_USER_ID, userGroups.get(0));
    verify(ciamOktaDao, times(1)).getUserOktaGroups(Mockito.any());
  }

  @Test
  public void testChangeInUserGroups() {
    List<String> userGroups = MockData.getUserGroupList();
    when(ciamOktaDao.getUserOktaGroups(anyString())).thenReturn(userGroups);

    ciamService.updateOktaUserGroups(IDP_USER_ID, "Advisor");
    verify(ciamOktaDao, times(1)).getUserOktaGroups(any());
    verify(ciamOktaDao, times(2)).deleteOktaUserGroup(any(), any());
    verify(ciamOktaDao, times(1)).addOktaUserGroup(any(), any());
  }

  @Test(expected = ServiceException.class)
  public void testChangeInUserGroups_whenOktaCallFails_shouldThrowException() {
    List<String> userGroups = MockData.getUserGroupList();
    when(ciamOktaDao.getUserOktaGroups(anyString())).thenReturn(userGroups);
    doThrow(ServiceException.class).when(ciamOktaDao).deleteOktaUserGroup(anyString(), anyString());
    ciamService.updateOktaUserGroups(IDP_USER_ID, "Advisor");
  }

  @Test
  public void testSuspendOktaUserProfile() {
    OktaUserProfile mockOktaUserProfile = MockData.getOktaUserProfile();
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(mockOktaUserProfile);
    try {
      ciamService.suspendUserOktaProfile(IDP_USER_ID);
    } catch (Exception e) {
      fail("This test should not throw any exception");
    }
  }

  @Test(expected = ServiceException.class)
  public void testSuspendOktaUserProfile_whenOktaUserProfileNotFound_shouldThrowException() {
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenThrow(
        new ServiceException(ErrorSeverity.ERROR, "Error getting user profile from Okta"));
    ciamService.suspendUserOktaProfile(IDP_USER_ID);
  }

  @Test(expected = ServiceException.class)
  public void testSuspendOktaUserProfile_whenSuspendOktaUserProfileFails_shouldThrowException() {
    OktaUserProfile mockOktaUserProfile = MockData.getOktaUserProfile();
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(mockOktaUserProfile);
    doThrow(new ServiceException(ErrorSeverity.ERROR, "Error suspending user Okta profile")).when(
        ciamOktaDao).suspendUserOktaProfile(anyString());
    ciamService.suspendUserOktaProfile(IDP_USER_ID);
  }

  @Test
  public void testUnsuspendOktaUserProfile() {
    OktaUserProfile mockOktaUserProfile = MockData.getOktaUserProfile();
    mockOktaUserProfile.setStatus(Constants.IDP_STATUS_SUSPENDED);
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(mockOktaUserProfile);
    try {
      ciamService.unsuspendUserOktaProfile(IDP_USER_ID);
    } catch (Exception e) {
      fail("This test should not throw any exception");
    }
    verify(ciamOktaDao, times(1)).unsuspendUserOktaProfile(IDP_USER_ID);
  }

  // NWPI-15109: Okta rejects a lifecycle call that is already satisfied, which stranded a retried
  // sunset row whose suspend had succeeded but whose DB decommission then failed.
  @Test
  public void testSuspendOktaUserProfile_whenAlreadySuspended_shouldSkipTheCall() {
    OktaUserProfile mockOktaUserProfile = MockData.getOktaUserProfile();
    mockOktaUserProfile.setStatus(Constants.IDP_STATUS_SUSPENDED);
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(mockOktaUserProfile);

    ciamService.suspendUserOktaProfile(IDP_USER_ID);

    verify(ciamOktaDao, times(0)).suspendUserOktaProfile(anyString());
  }

  @Test
  public void testUnsuspendOktaUserProfile_whenNotSuspended_shouldSkipTheCall() {
    OktaUserProfile mockOktaUserProfile = MockData.getOktaUserProfile();
    mockOktaUserProfile.setStatus(Constants.IDP_STATUS_ACTIVE);
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(mockOktaUserProfile);

    ciamService.unsuspendUserOktaProfile(IDP_USER_ID);

    verify(ciamOktaDao, times(0)).unsuspendUserOktaProfile(anyString());
  }

  @Test(expected = ServiceException.class)
  public void testUnsuspendOktaUserProfile_whenOktaUserProfileNotFound_shouldThrowException() {
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenThrow(
        new ServiceException(ErrorSeverity.ERROR, "Error getting user profile from Okta"));
    ciamService.unsuspendUserOktaProfile(IDP_USER_ID);
  }

  @Test(expected = ServiceException.class)
  public void testUnsuspendOktaUserProfile_whenUnsuspendOktaUserProfileFails_shouldThrowException() {
    OktaUserProfile mockOktaUserProfile = MockData.getOktaUserProfile();
    mockOktaUserProfile.setStatus(Constants.IDP_STATUS_SUSPENDED);
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(mockOktaUserProfile);
    doThrow(new ServiceException(ErrorSeverity.ERROR, "Error unsuspending user Okta profile")).when(
        ciamOktaDao).unsuspendUserOktaProfile(anyString());
    ciamService.unsuspendUserOktaProfile(IDP_USER_ID);
  }

  @Test
  public void testUpdateOktaSecureZoneId() {
    OktaUserProfile mockOktaUserProfile = new OktaUserProfile();
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(mockOktaUserProfile);
    try {
      ciamService.updateOktaSecureZoneId(IDP_USER_ID, new String[]{"test1", "test2"});
    } catch (Exception e) {
      fail("This test should not throw any exception");
    }
  }

  @Test
  public void testUpdateOktaSecureZoneId_whenAccessProfileIsNotNUllAndSecureZoneIdIsNull() {
    OktaUserProfile mockOktaUserProfile = new OktaUserProfile();
    mockOktaUserProfile.setAccessProfile(new OktaAccessProfile());
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(mockOktaUserProfile);
    try {
      ciamService.updateOktaSecureZoneId(IDP_USER_ID, new String[]{"test1", "test2"});
    } catch (Exception e) {
      fail("This test should not throw any exception");
    }
  }

  @Test
  public void testUpdateOktaSecureZoneId_whenSecureZoneIdsAlreadyMatchesWithExistingOnesInOkta() {
    OktaUserProfile mockOktaUserProfile = new OktaUserProfile();
    OktaAccessProfile accessProfile = new OktaAccessProfile();
    accessProfile.setBngfSecureZoneId(new String[]{"test1", "test2"});
    mockOktaUserProfile.setAccessProfile(accessProfile);
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(mockOktaUserProfile);
    try {
      ciamService.updateOktaSecureZoneId(IDP_USER_ID, new String[]{"test1", "test2"});
    } catch (Exception e) {
      fail("This test should not throw any exception");
    }
  }

  @Test(expected = ServiceException.class)
  public void testUpdateOktaSecureZoneId_whenOktaUserProfileNotFound_shouldThrowException() {
    when(ciamOktaDao.getOktaUserProfile(anyString()))
        .thenThrow(
            new ServiceException(ErrorSeverity.ERROR, "Error getting user profile from Okta"));
    ciamService.updateOktaSecureZoneId(IDP_USER_ID, new String[]{"test1", "test2"});
  }

  @Test(expected = ServiceException.class)
  public void testUpdateOktaSecureZoneId_whenSuspendOktaUserProfileFails_shouldThrowException() {
    OktaUserProfile mockOktaUserProfile = new OktaUserProfile();
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(mockOktaUserProfile);
    doThrow(new ServiceException(ErrorSeverity.ERROR,
        "Error updating secureZoneId for user's Okta profile"))
        .when(ciamOktaDao).updateOktaSecureZoneId(anyString(), any());
    ciamService.updateOktaSecureZoneId(IDP_USER_ID, new String[]{"test1", "test2"});
  }

  @Test
  public void testSyncOktaUserProfile() {
    OktaUserProfile mockOktaUserProfile = MockData.getOktaUserProfile();
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(mockOktaUserProfile);
    try {
      ciamService.syncOktaUserProfile(IDP_USER_ID, RETRY_COUNT);
    } catch (Exception e) {
      fail("This test should not throw any exception");
    }
  }

  @Test(expected = ServiceException.class)
  public void testSyncOktaUserProfile_whenOktaUserProfileNotFound_shouldThrowException() {
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenThrow(
        new ServiceException(ErrorSeverity.ERROR, "Error getting user profile from Okta"));
    ciamService.syncOktaUserProfile(IDP_USER_ID, RETRY_COUNT);
  }

  @Test(expected = FumServiceException.class)
  public void testSyncOktaUserProfile_whenSyncOktaUserProfileFails_shouldThrowException() {
    OktaUserProfile mockOktaUserProfile = MockData.getOktaUserProfile();
    when(ciamOktaDao.getOktaUserProfile(anyString())).thenReturn(mockOktaUserProfile);
    doThrow(new ServiceException(ErrorSeverity.ERROR, "Error syncing user Okta profile")).when(
        ciamOktaDao).syncOktaUserProfile(anyString());

    RequestAttributes mockRequest = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(mockRequest);
    ciamService.syncOktaUserProfile(IDP_USER_ID, RETRY_COUNT);
  }

  @Test
  public void testUpdateOktaUserEmail() {
    OktaUserEmail oktaUserEmail = new OktaUserEmail();
    oktaUserEmail.setNewEmail("new@email.com");
    try {
      ciamService.updateOktaUserEmail(IDP_USER_ID, oktaUserEmail);
    } catch (Exception e) {
      fail("This test should not throw any exception");
    }
  }

  @Test(expected = ServiceException.class)
  public void testUpdateOktaUserEmail_whenCallToOktaFails_shouldThrowException() {
    OktaUserEmail oktaUserEmail = new OktaUserEmail();
    oktaUserEmail.setNewEmail("new@email.com");
    doThrow(new ServiceException(ErrorSeverity.ERROR, "Error getting user profile from Okta")).when(
        ciamOktaDao).updateOktaUserEmail(anyString(), any(OktaUserEmail.class));
    ciamService.updateOktaUserEmail(IDP_USER_ID, oktaUserEmail);
  }

   @Test(expected = ServiceException.class)
  public void testAssignOktaUserGroup_whenCallToOktaFails_shouldThrowException() {
    doThrow(new ServiceException(ErrorSeverity.ERROR, "Error getting user profile from Okta")).when(
        ciamOktaDao).addOktaUserGroup(anyString(), anyString());
    ciamService.assignOktaUserGroup(IDP_USER_ID, "Advisor");
  }

  @Test
  public void testDeleteOktaUserGroup_whenGroupExists_shouldDeleteGroup() {
    List<String> userGroups = MockData.getUserGroupList();
    when(ciamOktaDao.getUserOktaGroups(anyString())).thenReturn(userGroups);
    ciamService.deleteOktaUserGroup(IDP_USER_ID, userGroups.get(0));
    verify(ciamOktaDao, times(1)).deleteOktaUserGroup(IDP_USER_ID, userGroups.get(0));
  }

  @Test(expected = FumValidationException.class)
  public void testDeleteOktaUserGroup_whenGroupNotFound_shouldThrowFumValidationException() {
    List<String> userGroups = MockData.getUserGroupList();
    when(ciamOktaDao.getUserOktaGroups(anyString())).thenReturn(userGroups);
    ciamService.deleteOktaUserGroup(IDP_USER_ID, "NonExistentGroup");
  }

  @Test(expected = ServiceException.class)
  public void testDeleteOktaUserGroup_whenOktaCallFails_shouldThrowServiceException() {
    List<String> userGroups = MockData.getUserGroupList();
    when(ciamOktaDao.getUserOktaGroups(anyString())).thenReturn(userGroups);
    doThrow(new RuntimeException("Okta error")).when(ciamOktaDao)
        .deleteOktaUserGroup(anyString(), anyString());
    ciamService.deleteOktaUserGroup(IDP_USER_ID, userGroups.get(0));
  }

}
