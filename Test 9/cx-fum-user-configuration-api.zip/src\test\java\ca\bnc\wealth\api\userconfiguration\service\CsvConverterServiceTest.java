package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.jupiter.api.Assertions.assertTrue;

import ca.bnc.wealth.api.userconfiguration.model.UserData;
import ca.bnc.wealth.api.userconfiguration.util.MockData;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.csv.CSVPrinter;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ByteArrayResource;

@ExtendWith(MockitoExtension.class)
public class CsvConverterServiceTest {

  private CsvConverterService csvConverterService;
  private List<UserData> userDataList;

  @Before
  public void setUp() {
    csvConverterService = new CsvConverterService();
    UserData userData1 = new UserData();
    userData1.setFirmId("123");
    userData1.setFirmName("ABC Wealth Management");
    userData1.setFirmType("Financial Institution");
    userData1.setIdpUserIdentifier("user123");
    userData1.setIdpSubject("subject123");
    userData1.setUsername(MockData.USER_NAME_LABEL);
    userData1.setSecureZoneIds(Arrays.asList("zone1", "zone2"));
    userData1.setOssUserId("oss123");
    userData1.setOssGroupId("group123");
    userData1.setFirstName("John");
    userData1.setLastName("Doe");
    userData1.setEmail("john.doe@example.com");
    userData1.setCompassR2Id("compass123");
    userData1.setRrCodes(Arrays.asList("RR1", "RR2"));
    userData1.setUserGroup("Admin");
    userData1.setRoleScopeType("Full Access");
    // Set up other mock data as needed for userData1

    UserData userData2 = new UserData();
    userData2.setFirmId("456");
    userData2.setFirmName("XYZ Investments");
    userData2.setFirmType("Investment Firm");
    userData2.setIdpUserIdentifier("user456");
    userData2.setIdpSubject("subject456");
    userData2.setUsername(MockData.USER_NAME_LABEL + "2");
    userData2.setSecureZoneIds(Arrays.asList("zone3", "zone4"));
    userData2.setOssUserId("oss456");
    userData2.setOssGroupId("group456");
    userData2.setFirstName("Jane");
    userData2.setLastName("Smith");
    userData2.setEmail("jane.smith@example.com");
    userData2.setCompassR2Id("compass456");
    userData2.setRrCodes(Arrays.asList("RR3", "RR4"));
    userData2.setUserGroup("User");
    userData2.setRoleScopeType("Limited Access");
    userDataList = Arrays.asList(userData1, userData2);
  }

  @Test
  public void convertToCsv_shouldConvertUserDataListToCsv() {
    setUp();
    ByteArrayResource byteArrayResource = csvConverterService.convertToCsv(userDataList);
    assertTrue(byteArrayResource.contentLength() > 0);
  }
}
