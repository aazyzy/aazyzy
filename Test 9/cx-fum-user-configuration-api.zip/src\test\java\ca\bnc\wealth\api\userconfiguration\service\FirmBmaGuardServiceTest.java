package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.userconfiguration.util.BulkUserConstants;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class FirmBmaGuardServiceTest {

  @Mock
  private FirmRepository firmRepository;

  @InjectMocks
  private FirmBmaGuardService firmBmaGuardService;

  @Test
  void testIsFirmBmaInProgress_whenBatchIdPresent_shouldReturnTrue() {
    Firm firm = new Firm();
    Map<String, String> preferences = new HashMap<>();
    preferences.put(BulkUserConstants.FIRM_FEATURE_PACKAGE_ASSIGNMENT_BATCH_ID, "batch-123");
    firm.setFirmPreferences(preferences);

    when(firmRepository.findByFirmId("FIRM001")).thenReturn(firm);

    assertTrue(firmBmaGuardService.isFirmBmaInProgress("FIRM001"));
  }

  @Test
  void testIsFirmBmaInProgress_whenBatchIdAbsent_shouldReturnFalse() {
    Firm firm = new Firm();
    Map<String, String> preferences = new HashMap<>();
    preferences.put("defaultModule", "someModule");
    firm.setFirmPreferences(preferences);

    when(firmRepository.findByFirmId("FIRM001")).thenReturn(firm);

    assertFalse(firmBmaGuardService.isFirmBmaInProgress("FIRM001"));
  }

  @Test
  void testIsFirmBmaInProgress_whenBatchIdIsBlank_shouldReturnFalse() {
    Firm firm = new Firm();
    Map<String, String> preferences = new HashMap<>();
    preferences.put(BulkUserConstants.FIRM_FEATURE_PACKAGE_ASSIGNMENT_BATCH_ID, "");
    firm.setFirmPreferences(preferences);

    when(firmRepository.findByFirmId("FIRM001")).thenReturn(firm);

    assertFalse(firmBmaGuardService.isFirmBmaInProgress("FIRM001"));
  }

  @Test
  void testIsFirmBmaInProgress_whenFirmPreferencesNull_shouldReturnFalse() {
    Firm firm = new Firm();
    firm.setFirmPreferences(null);

    when(firmRepository.findByFirmId("FIRM001")).thenReturn(firm);

    assertFalse(firmBmaGuardService.isFirmBmaInProgress("FIRM001"));
  }

  @Test
  void testIsFirmBmaInProgress_whenFirmNotFound_shouldReturnFalse() {
    when(firmRepository.findByFirmId("UNKNOWN")).thenReturn(null);

    assertFalse(firmBmaGuardService.isFirmBmaInProgress("UNKNOWN"));
  }

  @Test
  void testIsFirmBmaInProgress_whenFirmIdIsNull_shouldReturnFalse() {
    assertFalse(firmBmaGuardService.isFirmBmaInProgress(null));
    verify(firmRepository, never()).findByFirmId(null);
  }

  @Test
  void testIsFirmBmaInProgress_whenFirmIdIsBlank_shouldReturnFalse() {
    assertFalse(firmBmaGuardService.isFirmBmaInProgress(""));
    verify(firmRepository, never()).findByFirmId("");
  }

  @Test
  void testIsFirmBmaInProgress_whenPreferencesEmpty_shouldReturnFalse() {
    Firm firm = new Firm();
    firm.setFirmPreferences(new HashMap<>());

    when(firmRepository.findByFirmId("FIRM001")).thenReturn(firm);

    assertFalse(firmBmaGuardService.isFirmBmaInProgress("FIRM001"));
  }
}
