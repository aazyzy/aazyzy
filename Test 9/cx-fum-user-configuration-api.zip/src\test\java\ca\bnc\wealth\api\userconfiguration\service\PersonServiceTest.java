package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.Person;
import ca.bnc.wealth.common.jpa.entity.iam.PersonAssignment;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PersonAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PersonRepository;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Limit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class PersonServiceTest {

  private static final Long USER_CONFIG_ID = 1234L;
  private static final String EMAIL = "test@email.com";
  private static final String FIRST_NAME = "John";
  private static final String LAST_NAME = "Doe";
  private static final String IDP_SUBJECT = "idp-subject-123";
  private static final String IDP = "nbin";
  private static final String CREATED_BY = "system";
  private static final String UPDATED_BY = "admin";
  private static final Long PERSON_ID = 99L;

  @InjectMocks
  private PersonService personService;

  @Mock
  private PersonRepository personRepository;

  @Mock
  private PersonAssignmentRepository personAssignmentRepository;

  @Mock
  private IamUserConfigurationRepository iamUserConfigurationRepository;

  @Captor
  private ArgumentCaptor<Person> personCaptor;

  @Captor
  private ArgumentCaptor<PersonAssignment> assignmentCaptor;

  @Captor
  private ArgumentCaptor<Limit> limitCaptor;

  // --- null / missing-id guard ---

  @Test
  void syncPersonFromUserConfiguration_nullInput_doesNothing() {
    assertDoesNotThrow(() -> personService.syncPersonFromUserConfiguration(null));
    verifyNoInteractions(personRepository, personAssignmentRepository);
  }

  @Test
  void syncPersonFromUserConfiguration_nullUserConfigId_doesNothing() {
    IamUserConfiguration config = new IamUserConfiguration();
    config.setUserConfigurationId(null);

    personService.syncPersonFromUserConfiguration(config);

    verifyNoInteractions(personRepository, personAssignmentRepository);
  }

  // --- null email guard ---

  @Test
  void syncPersonFromUserConfiguration_nullEmail_skips() {
    IamUserConfiguration config = buildIamUserConfig();
    config.setEmail(null);

    personService.syncPersonFromUserConfiguration(config);

    verifyNoInteractions(personRepository);
    verify(personAssignmentRepository, never()).save(any(PersonAssignment.class));
  }

  // --- create path (person does not exist) ---

  @Test
  void syncPersonFromUserConfiguration_newPerson_createsPersonAndAssignment() {
    IamUserConfiguration config = buildIamUserConfig();
    Person savedPerson = buildPerson();

    when(personRepository.findFirstByEmailIgnoreCase(EMAIL)).thenReturn(Optional.empty());
    when(personRepository.save(any(Person.class))).thenReturn(savedPerson);

    personService.syncPersonFromUserConfiguration(config);

    verify(personRepository).save(personCaptor.capture());
    Person captured = personCaptor.getValue();
    assertEquals(FIRST_NAME, captured.getFirstName());
    assertEquals(LAST_NAME, captured.getLastName());
    assertEquals(PreferredLanguageType.EN, captured.getLanguage());
    assertEquals(EMAIL, captured.getEmail());
    assertEquals(IDP, captured.getOrganization());
    assertEquals(CREATED_BY, captured.getCreatedBy());
    assertNotNull(captured.getCreatedDt());

    verify(personAssignmentRepository).save(assignmentCaptor.capture());
    PersonAssignment capturedAssignment = assignmentCaptor.getValue();
    assertEquals(savedPerson, capturedAssignment.getPerson());
    assertEquals(USER_CONFIG_ID.intValue(), capturedAssignment.getUserId());
    assertEquals(CREATED_BY, capturedAssignment.getCreatedBy());
    assertNotNull(capturedAssignment.getCreatedDt());
  }

  @Test
  void syncPersonFromUserConfiguration_newPerson_nullLanguage_defaultsToEN() {
    IamUserConfiguration config = buildIamUserConfig();
    config.setPreferredLanguageType(null);
    Person savedPerson = buildPerson();

    when(personRepository.findFirstByEmailIgnoreCase(EMAIL)).thenReturn(Optional.empty());
    when(personRepository.save(any(Person.class))).thenReturn(savedPerson);

    personService.syncPersonFromUserConfiguration(config);

    verify(personRepository).save(personCaptor.capture());
    assertEquals(PreferredLanguageType.EN, personCaptor.getValue().getLanguage());
  }

  @Test
  void syncPersonFromUserConfiguration_newPerson_frLanguage_preserved() {
    IamUserConfiguration config = buildIamUserConfig();
    config.setPreferredLanguageType(PreferredLanguageType.FR);
    Person savedPerson = buildPerson();

    when(personRepository.findFirstByEmailIgnoreCase(EMAIL)).thenReturn(Optional.empty());
    when(personRepository.save(any(Person.class))).thenReturn(savedPerson);

    personService.syncPersonFromUserConfiguration(config);

    verify(personRepository).save(personCaptor.capture());
    assertEquals(PreferredLanguageType.FR, personCaptor.getValue().getLanguage());
  }

  // --- update path (person already exists) ---

  @Test
  void syncPersonFromUserConfiguration_existingPerson_updatesPersonAndCreatesAssignment() {
    IamUserConfiguration config = buildIamUserConfig();
    config.setLastUpdatedBy(UPDATED_BY);
    Person existingPerson = buildPerson();

    when(personRepository.findFirstByEmailIgnoreCase(EMAIL)).thenReturn(Optional.of(existingPerson));
    when(personRepository.save(any(Person.class))).thenReturn(existingPerson);

    personService.syncPersonFromUserConfiguration(config);

    verify(personRepository).save(personCaptor.capture());
    Person captured = personCaptor.getValue();
    assertEquals(FIRST_NAME, captured.getFirstName());
    assertEquals(LAST_NAME, captured.getLastName());
    assertEquals(PreferredLanguageType.EN, captured.getLanguage());
    assertEquals(IDP, captured.getOrganization());
    assertEquals(UPDATED_BY, captured.getUpdatedBy());
    assertNotNull(captured.getUpdatedDt());

    verify(personAssignmentRepository).save(any(PersonAssignment.class));
  }

  @Test
  void syncPersonFromUserConfiguration_existingPerson_nullLanguage_defaultsToEN() {
    IamUserConfiguration config = buildIamUserConfig();
    config.setPreferredLanguageType(null);
    config.setLastUpdatedBy(UPDATED_BY);
    Person existingPerson = buildPerson();

    when(personRepository.findFirstByEmailIgnoreCase(EMAIL)).thenReturn(Optional.of(existingPerson));
    when(personRepository.save(any(Person.class))).thenReturn(existingPerson);

    personService.syncPersonFromUserConfiguration(config);

    verify(personRepository).save(personCaptor.capture());
    assertEquals(PreferredLanguageType.EN, personCaptor.getValue().getLanguage());
  }

  // --- already linked: the link is established once and never re-pointed ---

  @Test
  void syncPersonFromUserConfiguration_alreadyLinked_keepsLinkAndIgnoresEmail() {
    IamUserConfiguration config = buildIamUserConfig();
    config.setEmail("moved.to.another.person@nbc.ca");
    Person linkedPerson = buildPerson();
    PersonAssignment existingAssignment = PersonAssignment.builder()
        .personAssignmentId(1L)
        .person(linkedPerson)
        .userId(USER_CONFIG_ID.intValue())
        .build();

    when(personAssignmentRepository.findFirstByUserId(USER_CONFIG_ID.intValue()))
        .thenReturn(Optional.of(existingAssignment));
    when(personRepository.save(any(Person.class))).thenReturn(linkedPerson);

    personService.syncPersonFromUserConfiguration(config);

    verify(personRepository, never()).findFirstByEmailIgnoreCase(anyString());
    verify(personAssignmentRepository, never()).save(any(PersonAssignment.class));
    verify(personRepository).save(personCaptor.capture());
    assertEquals(EMAIL, personCaptor.getValue().getEmail());
  }

  // --- exception handling (catch block) ---

  @Test
  void syncPersonFromUserConfiguration_repositoryThrows_doesNotPropagate() {
    IamUserConfiguration config = buildIamUserConfig();

    when(personRepository.findFirstByEmailIgnoreCase(EMAIL)).thenThrow(new RuntimeException("DB error"));

    assertDoesNotThrow(() -> personService.syncPersonFromUserConfiguration(config));
  }

  @Test
  void syncPersonFromUserConfiguration_saveThrows_doesNotPropagate() {
    IamUserConfiguration config = buildIamUserConfig();

    when(personRepository.findFirstByEmailIgnoreCase(EMAIL)).thenReturn(Optional.empty());
    when(personRepository.save(any(Person.class))).thenThrow(new RuntimeException("Constraint violation"));

    assertDoesNotThrow(() -> personService.syncPersonFromUserConfiguration(config));
  }

  @Test
  void syncPersonFromUserConfiguration_assignmentSaveThrows_doesNotPropagate() {
    IamUserConfiguration config = buildIamUserConfig();
    Person savedPerson = buildPerson();

    when(personRepository.findFirstByEmailIgnoreCase(EMAIL)).thenReturn(Optional.empty());
    when(personRepository.save(any(Person.class))).thenReturn(savedPerson);
    when(personAssignmentRepository.save(any(PersonAssignment.class)))
        .thenThrow(new RuntimeException("FK violation"));

    assertDoesNotThrow(() -> personService.syncPersonFromUserConfiguration(config));
  }

  // --- removePersonLink: unlink PERSON_USER on delete (fk_person_user_user_configuration) ---

  @Test
  void removePersonLink_nullInput_doesNothing() {
    assertDoesNotThrow(() -> personService.removePersonLink(null));
    verifyNoInteractions(personRepository, personAssignmentRepository);
  }

  @Test
  void removePersonLink_nullUserConfigId_doesNothing() {
    IamUserConfiguration config = new IamUserConfiguration();
    config.setUserConfigurationId(null);

    personService.removePersonLink(config);

    verifyNoInteractions(personRepository, personAssignmentRepository);
  }

  @Test
  void removePersonLink_noAssignment_doesNothing() {
    IamUserConfiguration config = buildIamUserConfig();

    when(personAssignmentRepository.findFirstByUserId(USER_CONFIG_ID.intValue()))
        .thenReturn(Optional.empty());

    personService.removePersonLink(config);

    verify(personAssignmentRepository, never()).delete(any(PersonAssignment.class));
    verify(personRepository, never()).delete(any(Person.class));
  }

  @Test
  void removePersonLink_lastAssignment_deletesAssignmentAndOrphanedPerson() {
    IamUserConfiguration config = buildIamUserConfig();
    Person linkedPerson = buildPerson();
    PersonAssignment assignment = PersonAssignment.builder()
        .personAssignmentId(1L)
        .person(linkedPerson)
        .userId(USER_CONFIG_ID.intValue())
        .build();

    when(personAssignmentRepository.findFirstByUserId(USER_CONFIG_ID.intValue()))
        .thenReturn(Optional.of(assignment));
    when(personAssignmentRepository.findAllByPersonPersonId(PERSON_ID))
        .thenReturn(java.util.List.of());

    personService.removePersonLink(config);

    verify(personAssignmentRepository).delete(assignment);
    verify(personRepository).delete(linkedPerson);
  }

  @Test
  void removePersonLink_personHasOtherAssignments_keepsPerson() {
    IamUserConfiguration config = buildIamUserConfig();
    Person linkedPerson = buildPerson();
    PersonAssignment assignment = PersonAssignment.builder()
        .personAssignmentId(1L)
        .person(linkedPerson)
        .userId(USER_CONFIG_ID.intValue())
        .build();
    PersonAssignment otherAssignment = PersonAssignment.builder()
        .personAssignmentId(2L)
        .person(linkedPerson)
        .userId(5678)
        .build();

    when(personAssignmentRepository.findFirstByUserId(USER_CONFIG_ID.intValue()))
        .thenReturn(Optional.of(assignment));
    when(personAssignmentRepository.findAllByPersonPersonId(PERSON_ID))
        .thenReturn(java.util.List.of(otherAssignment));

    personService.removePersonLink(config);

    verify(personAssignmentRepository).delete(assignment);
    verify(personRepository, never()).delete(any(Person.class));
  }

  @Test
  void removePersonLink_nullPersonOnAssignment_deletesAssignmentOnly() {
    IamUserConfiguration config = buildIamUserConfig();
    PersonAssignment assignment = PersonAssignment.builder()
        .personAssignmentId(1L)
        .person(null)
        .userId(USER_CONFIG_ID.intValue())
        .build();

    when(personAssignmentRepository.findFirstByUserId(USER_CONFIG_ID.intValue()))
        .thenReturn(Optional.of(assignment));

    personService.removePersonLink(config);

    verify(personAssignmentRepository).delete(assignment);
    verify(personAssignmentRepository, never()).findAllByPersonPersonId(any());
    verify(personRepository, never()).delete(any(Person.class));
  }

  // --- isSecondaryAccount: a non-employee account sharing its email with an IAMi account ---

  @Test
  void isSecondaryAccount_nullUser_returnsFalse() {
    assertFalse(personService.isSecondaryAccount(null));
    verifyNoInteractions(iamUserConfigurationRepository);
  }

  @Test
  void isSecondaryAccount_nullEmail_returnsFalse() {
    IamUserConfiguration user = buildIamUserConfig();
    user.setEmail(null);

    assertFalse(personService.isSecondaryAccount(user));
    verifyNoInteractions(iamUserConfigurationRepository);
  }

  @Test
  void isSecondaryAccount_blankEmail_returnsFalse() {
    IamUserConfiguration user = buildIamUserConfig();
    user.setEmail("   ");

    assertFalse(personService.isSecondaryAccount(user));
    verifyNoInteractions(iamUserConfigurationRepository);
  }

  @Test
  void isSecondaryAccount_userIsEmployee_returnsFalse() {
    IamUserConfiguration user = buildIamUserConfig();
    user.setIdp(Constants.EMPLOYEE_IDP);

    assertFalse(personService.isSecondaryAccount(user));
    verifyNoInteractions(iamUserConfigurationRepository);
  }

  @Test
  void isSecondaryAccount_userIsEmployeeDifferentCase_returnsFalse() {
    IamUserConfiguration user = buildIamUserConfig();
    user.setIdp(Constants.EMPLOYEE_IDP.toUpperCase());

    assertFalse(personService.isSecondaryAccount(user));
    verifyNoInteractions(iamUserConfigurationRepository);
  }

  @Test
  void isSecondaryAccount_noAccountWithSameEmail_returnsFalse() {
    IamUserConfiguration user = buildIamUserConfig();

    when(iamUserConfigurationRepository.findByEmailIgnoreCase(eq(EMAIL), any(Limit.class)))
        .thenReturn(List.of());

    assertFalse(personService.isSecondaryAccount(user));
  }

  @Test
  void isSecondaryAccount_onlyMatchIsItself_returnsFalse() {
    IamUserConfiguration user = buildIamUserConfig();
    // The repository also returns the caller's own row; it must be filtered out by id, even when
    // that row carries the employee idp (a stale/mis-tagged self row must not self-qualify).
    IamUserConfiguration self = buildMatch(USER_CONFIG_ID, Constants.EMPLOYEE_IDP);

    when(iamUserConfigurationRepository.findByEmailIgnoreCase(eq(EMAIL), any(Limit.class)))
        .thenReturn(List.of(self));

    assertFalse(personService.isSecondaryAccount(user));
  }

  @Test
  void isSecondaryAccount_matchIsNotEmployee_returnsFalse() {
    IamUserConfiguration user = buildIamUserConfig();
    IamUserConfiguration otherNbin = buildMatch(5678L, IDP);

    when(iamUserConfigurationRepository.findByEmailIgnoreCase(eq(EMAIL), any(Limit.class)))
        .thenReturn(List.of(otherNbin));

    assertFalse(personService.isSecondaryAccount(user));
  }

  @Test
  void isSecondaryAccount_matchHasNullIdp_returnsFalse() {
    IamUserConfiguration user = buildIamUserConfig();
    IamUserConfiguration noIdp = buildMatch(5678L, null);

    when(iamUserConfigurationRepository.findByEmailIgnoreCase(eq(EMAIL), any(Limit.class)))
        .thenReturn(List.of(noIdp));

    assertFalse(personService.isSecondaryAccount(user));
  }

  @Test
  void isSecondaryAccount_matchIsEmployee_returnsTrue() {
    IamUserConfiguration user = buildIamUserConfig();
    IamUserConfiguration employee = buildMatch(5678L, Constants.EMPLOYEE_IDP);

    when(iamUserConfigurationRepository.findByEmailIgnoreCase(eq(EMAIL), any(Limit.class)))
        .thenReturn(List.of(employee));

    assertTrue(personService.isSecondaryAccount(user));
  }

  @Test
  void isSecondaryAccount_matchIsEmployeeDifferentCase_returnsTrue() {
    IamUserConfiguration user = buildIamUserConfig();
    IamUserConfiguration employee = buildMatch(5678L, Constants.EMPLOYEE_IDP.toLowerCase());

    when(iamUserConfigurationRepository.findByEmailIgnoreCase(eq(EMAIL), any(Limit.class)))
        .thenReturn(List.of(employee));

    assertTrue(personService.isSecondaryAccount(user));
  }

  @Test
  void isSecondaryAccount_employeeFoundAmongSeveralMatches_returnsTrue() {
    IamUserConfiguration user = buildIamUserConfig();

    when(iamUserConfigurationRepository.findByEmailIgnoreCase(eq(EMAIL), any(Limit.class)))
        .thenReturn(List.of(
            buildMatch(USER_CONFIG_ID, IDP),
            buildMatch(5678L, IDP),
            buildMatch(9012L, Constants.EMPLOYEE_IDP)));

    assertTrue(personService.isSecondaryAccount(user));
  }

  @Test
  void isSecondaryAccount_unsavedUserWithoutId_stillMatchesEmployee() {
    IamUserConfiguration user = buildIamUserConfig();
    user.setUserConfigurationId(null);
    IamUserConfiguration employee = buildMatch(5678L, Constants.EMPLOYEE_IDP);

    when(iamUserConfigurationRepository.findByEmailIgnoreCase(eq(EMAIL), any(Limit.class)))
        .thenReturn(List.of(employee));

    assertTrue(personService.isSecondaryAccount(user));
  }

  @Test
  void isSecondaryAccount_queriesWithUnlimitedLimit() {
    IamUserConfiguration user = buildIamUserConfig();

    when(iamUserConfigurationRepository.findByEmailIgnoreCase(eq(EMAIL), limitCaptor.capture()))
        .thenReturn(List.of());

    personService.isSecondaryAccount(user);

    // the IAMi row has no guaranteed position in the result, so the query must not be capped
    assertTrue(limitCaptor.getValue().isUnlimited());
  }

  // --- helpers ---

  private IamUserConfiguration buildMatch(Long userConfigurationId, String idp) {
    IamUserConfiguration match = new IamUserConfiguration();
    match.setUserConfigurationId(userConfigurationId);
    match.setEmail(EMAIL);
    match.setIdp(idp);
    return match;
  }

  private IamUserConfiguration buildIamUserConfig() {
    IamUserConfiguration config = new IamUserConfiguration();
    config.setUserConfigurationId(USER_CONFIG_ID);
    config.setEmail(EMAIL);
    config.setFirstName(FIRST_NAME);
    config.setLastName(LAST_NAME);
    config.setPreferredLanguageType(PreferredLanguageType.EN);
    config.setIdpSubject(IDP_SUBJECT);
    config.setIdp(IDP);
    config.setCreatedBy(CREATED_BY);
    config.setLastUpdatedBy(UPDATED_BY);
    return config;
  }

  private Person buildPerson() {
    return Person.builder()
        .personId(PERSON_ID)
        .firstName(FIRST_NAME)
        .lastName(LAST_NAME)
        .language(PreferredLanguageType.EN)
        .email(EMAIL)
        .organization(IDP)
        .build();
  }
}
