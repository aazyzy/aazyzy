package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.userconfiguration.model.R2userStatus;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.common.r2.feign.client.CxUserProfileClient;
import ca.bnc.wealth.common.r2.feign.client.R2UserProfileClient;
import ca.bnc.wealth.common.r2.model.R2UserProfile;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class R2ServiceTest {

  private static final String STUB_BEARER_TOKEN = "stub-" + java.util.UUID.randomUUID();

  @MockitoBean R2UserProfileClient r2UserProfileClient;
  @MockitoBean CxUserProfileClient cxUserProfileClient;
  @MockitoBean SystemTokenFactory systemTokenFactory;
  private R2Service r2Service;

  @SneakyThrows
  @Before
  public void setup() {
    r2Service = new R2Service();
    FieldUtils.writeField(r2Service, "r2UserProfileClient", r2UserProfileClient, true);
    FieldUtils.writeField(r2Service, "cxUserProfileClient", cxUserProfileClient, true);
    FieldUtils.writeField(r2Service, "systemTokenFactory", systemTokenFactory, true);
  }

  @Test
  public void getR2UserProfileWithStatusNotFound() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    R2UserProfile r2UserProfile = new R2UserProfile();
    r2UserProfile.setError("User Not found");
    when(r2UserProfileClient.getR2UserProfile(any(), any(), any()))
        .thenReturn(r2UserProfile);
    Pair<R2userStatus, R2UserProfile> pair = r2Service.getR2UserProfileWithStatus("r2id");
    assertEquals(R2userStatus.NOT_FOUND, pair.getKey());
  }

  @Test
  public void getR2UserProfileWithStatusWithCpxStub() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    R2UserProfile r2UserProfile = new R2UserProfile();
    r2UserProfile.setCxUserId("cxId");
    when(r2UserProfileClient.getR2UserProfile(any(), any(), any()))
        .thenReturn(r2UserProfile);
    Pair<R2userStatus, R2UserProfile> pair = r2Service.getR2UserProfileWithStatus("r2id");
    assertEquals(R2userStatus.WITH_CPX_SUB, pair.getKey());
  }

  @Test
  public void getR2UserProfileWithStatusWithoutCpxStub() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    R2UserProfile r2UserProfile = new R2UserProfile();
    when(r2UserProfileClient.getR2UserProfile(any(), any(), any()))
        .thenReturn(r2UserProfile);
    Pair<R2userStatus, R2UserProfile> pair = r2Service.getR2UserProfileWithStatus("r2id");
    assertEquals(R2userStatus.WITHOUT_CPX_SUB, pair.getKey());
  }

  @Test
  public void getCxUserProfile() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    ResponseEntity<String> r = ResponseEntity.status(HttpStatus.OK).body("r2id");

    when(cxUserProfileClient.getR2UserProfile(any(), any(), any()))
        .thenReturn(r);
    Pair<HttpStatusCode, String> pair = r2Service.getCxUserProfile("cxId");
    assertEquals(HttpStatus.OK, pair.getKey());
    assertEquals("r2id", pair.getValue());

    when(cxUserProfileClient.getR2UserProfile(any(), any(), any()))
        .thenThrow(new RuntimeException("error"));
    assertNull(r2Service.getCxUserProfile("cxId"));
  }

  @Test
  public void r2ValidationForUpdateUser() {
    R2UserProfile r2UserProfile = new R2UserProfile();

    // Not found status
    r2UserProfile.setError("User Not found");
    when(r2UserProfileClient.getR2UserProfile(any(), any(), any()))
        .thenReturn(r2UserProfile);
    Pair<Boolean, String> pair = r2Service.r2ValidationForUpdateUser("cxId", "idpSubject");
    assertFalse(pair.getLeft());
    assertEquals(Constants.ERROR_R2_NOT_FOUND, pair.getRight());

    // With Cpx sub status and same idpSubject
    r2UserProfile.setError(null);
    r2UserProfile.setCxUserId("idpSubject");
    when(r2UserProfileClient.getR2UserProfile(any(), any(), any()))
        .thenReturn(r2UserProfile);
    pair = r2Service.r2ValidationForUpdateUser("cxId", "idpSubject");
    assertTrue(pair.getLeft());
    assertNull(pair.getRight());

    // With Cpx sub status and different idpSubject
    r2UserProfile.setCxUserId("different");
    when(r2UserProfileClient.getR2UserProfile(any(), any(), any()))
        .thenReturn(r2UserProfile);
    pair = r2Service.r2ValidationForUpdateUser("cxId", "idpSubject");
    assertFalse(pair.getLeft());
    assertEquals(Constants.ERROR_R2_NOT_MATCHED, pair.getRight());

    // Without Cpx sub status
    r2UserProfile.setCxUserId(null);
    when(r2UserProfileClient.getR2UserProfile(any(), any(), any()))
        .thenReturn(r2UserProfile);
    pair = r2Service.r2ValidationForUpdateUser("cxId", "idpSubject");
    assertTrue(pair.getLeft());
    assertNull(pair.getRight());
  }
}
