package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;

import ca.bnc.wealth.common.jpa.entity.platform.SchedulerStatus;
import ca.bnc.wealth.common.jpa.repo.platform.SchedulerStatusRepository;
import java.sql.Timestamp;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class ScheduleStatusServiceTest {

  private ScheduleStatusService scheduleStatusService;
  @MockitoBean
  private SchedulerStatusRepository schedulerStatusRepository;

  @Before
  public void setup() {
    scheduleStatusService = new ScheduleStatusService(schedulerStatusRepository);
  }

  @Test
  public void canRunScheduleNoEntryForSchedularName() {
    String sName = "S_NAME";
    Mockito.when(schedulerStatusRepository.findFirstBySchedulerName(sName)).thenReturn(null);
    boolean response = scheduleStatusService.canRunSchedule(sName, 40);
    assertEquals(true, response);
  }

  @Test
  public void canRunScheduleInProgress() {
    String sName = "S_NAME";
    SchedulerStatus schedulerStatus = new SchedulerStatus();
    schedulerStatus.setSchedulerName(sName);
    schedulerStatus.setSchedulerStart(new Timestamp(System.currentTimeMillis()));
    Mockito.when(schedulerStatusRepository.findFirstBySchedulerName(sName))
        .thenReturn(schedulerStatus);
    boolean response = scheduleStatusService.canRunSchedule(sName, 40);
    assertEquals(false, response);
  }

  @Test
  public void canRunScheduleStartDateNull() {
    String sName = "S_NAME";
    SchedulerStatus schedulerStatus = new SchedulerStatus();
    schedulerStatus.setSchedulerName(sName);
    Mockito.when(schedulerStatusRepository.findFirstBySchedulerName(sName))
        .thenReturn(schedulerStatus);
    boolean response = scheduleStatusService.canRunSchedule(sName, 40);
    assertEquals(true, response);
  }

  @Test
  public void canRunSchedule() {
    String sName = "S_NAME";
    SchedulerStatus schedulerStatus = new SchedulerStatus();
    schedulerStatus.setSchedulerName(sName);
    schedulerStatus.setSchedulerStart(new Timestamp(System.currentTimeMillis()));
    schedulerStatus.setSchedulerEnd(new Timestamp(System.currentTimeMillis()));
    Mockito.when(schedulerStatusRepository.findFirstBySchedulerName(sName))
        .thenReturn(schedulerStatus);
    boolean response = scheduleStatusService.canRunSchedule(sName, 40);
    assertEquals(false, response);
  }

  @Test(expected = Exception.class)
  public void updateStatusToFinishFailed() {
    String sName = "S_NAME";
    scheduleStatusService.updateStatusToFinish(sName);
  }

  @Test
  public void updateStatusToFinish() {
    String sName = "S_NAME";
    SchedulerStatus schedulerStatus = new SchedulerStatus();
    schedulerStatus.setSchedulerName(sName);
    schedulerStatus.setSchedulerStart(new Timestamp(System.currentTimeMillis()));
    schedulerStatus.setSchedulerEnd(new Timestamp(System.currentTimeMillis()));
    Mockito.when(schedulerStatusRepository.findFirstBySchedulerName(sName))
        .thenReturn(schedulerStatus);

    try {
      scheduleStatusService.updateStatusToFinish(sName);
    } catch (Exception e) {
      fail();
    }
  }
}
