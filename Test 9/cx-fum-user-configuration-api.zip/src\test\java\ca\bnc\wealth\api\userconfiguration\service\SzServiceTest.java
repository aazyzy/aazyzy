package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.sz.feign.client.SzClientUAMA;
import ca.bnc.wealth.common.sz.model.SzUser;
import ca.bnc.wealth.common.sz.model.SzUserSearch;
import feign.FeignException;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletWebRequest;

@RunWith(SpringRunner.class)
public class SzServiceTest {

  private static final String STUB_BEARER_TOKEN = "stub-" + java.util.UUID.randomUUID();

  @MockitoBean SzClientUAMA szClientUAMA;
  @MockitoBean SystemTokenFactory systemTokenFactory;
  private SzService szService;

  @SneakyThrows
  @Before
  public void setup() {
    szService = new SzService();
    FieldUtils.writeField(szService, "szClientUAMA", szClientUAMA, true);
    FieldUtils.writeField(szService, "systemTokenFactory", systemTokenFactory, true);
  }

  @Test
  public void testAssignExternalIdToUsername_whenSuccessful_shouldNotThrowException() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.assignUsernameToSzId(any(), any(), any(), any()))
        .thenReturn(new ResponseEntity<>("response", HttpStatus.OK));
    try {
      szService.assignExternalIdToUsername("szId", "idpSubject", "NBIN");
    } catch (Exception e) {
      fail("Should not throw exception");
    }
  }

  @Test(expected = FumValidationException.class)
  public void testAssignExternalIdToUsername_whenInvalidSzId_shouldFumValidationException() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.assignUsernameToSzId(any(), any(), any(), any()))
        .thenReturn(new ResponseEntity<>("response", HttpStatus.BAD_REQUEST));
    szService.assignExternalIdToUsername("szId", "idpSubject", "NBIN");
  }

  @Test(expected = FumServiceException.class)
  public void testAssignExternalIdToUsername_whenSzNotAvailable_shouldFumServiceException() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.assignUsernameToSzId(any(), any(), any(), any()))
        .thenReturn(new ResponseEntity<>("response", HttpStatus.INTERNAL_SERVER_ERROR));
    szService.assignExternalIdToUsername("szId", "idpSubject", "NBIN");
  }

  @Test(expected = FumServiceException.class)
  public void testAssignExternalIdToUsername_whenUnsuccessfulCall_shouldFumServiceException() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.assignUsernameToSzId(any(), any(), any(), any()))
        .thenThrow(mock(FeignException.FeignServerException.class));
    RequestAttributes mockRequest = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(mockRequest);
    szService.assignExternalIdToUsername("szId", "idpSubject", "NBIN");
  }

  @Test
  public void testGetExternalUser_whenSuccessful_shouldReturnSzUser() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    SzUser szUser = new SzUser();
    szUser.setId("123");
    szUser.setUserName("testUser");
    when(szClientUAMA.getUser(any(), any()))
        .thenReturn(new ResponseEntity<>(szUser, HttpStatus.OK));
    SzUser result = szService.getExternalUser("szId");
    assertEquals("123", result.getId());
    assertEquals("testUser", result.getUserName());
  }

  @Test(expected = FumValidationException.class)
  public void testGetExternalUser_when4xxError_shouldThrowFumValidationException() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.getUser(any(), any()))
        .thenReturn(new ResponseEntity<>((HttpHeaders) null, HttpStatus.BAD_REQUEST));
    szService.getExternalUser("szId");
  }

  @Test(expected = FumServiceException.class)
  public void testGetExternalUser_when5xxError_shouldThrowFumServiceException() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.getUser(any(), any()))
        .thenReturn(new ResponseEntity<>((HttpHeaders) null, HttpStatus.INTERNAL_SERVER_ERROR));
    szService.getExternalUser("szId");
  }

  @Test(expected = FumServiceException.class)
  public void testGetExternalUser_whenExceptionThrown_shouldThrowFumServiceException() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.getUser(any(), any()))
        .thenThrow(mock(FeignException.FeignServerException.class));
    RequestAttributes mockRequest = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(mockRequest);
    szService.getExternalUser("szId");
  }

  @Test(expected = FumValidationException.class)
  public void testGetExternalUser_whenFumValidationExceptionThrown_shouldRethrow() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.getUser(any(), any()))
        .thenThrow(new FumValidationException("error", "validation error"));
    szService.getExternalUser("szId");
  }

  @Test(expected = FumServiceException.class)
  public void testGetExternalUser_whenFumServiceExceptionThrown_shouldRethrow() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.getUser(any(), any()))
        .thenThrow(new FumServiceException("error", "service error"));
    szService.getExternalUser("szId");
  }

  @Test
  public void testAssignExternalIdToUsername_whenFumValidationExceptionThrown_shouldRethrow() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.assignUsernameToSzId(any(), any(), any(), any()))
        .thenThrow(new FumValidationException("error", "validation error"));
    try {
      szService.assignExternalIdToUsername("szId", "idpSubject", "NBIN");
      fail("Should throw FumValidationException");
    } catch (FumValidationException e) {
      assertEquals("error", e.getCode());
    }
  }

  @Test(expected = FumServiceException.class)
  public void testAssignExternalIdToUsername_whenFumServiceExceptionThrown_shouldRethrow() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.assignUsernameToSzId(any(), any(), any(), any()))
        .thenThrow(new FumServiceException("error", "service error"));
    szService.assignExternalIdToUsername("szId", "idpSubject", "NBIN");
  }

  @Test
  public void testGetExternalUserByIdpSubject_whenSuccessful_shouldReturnSzUserSearch() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    SzUserSearch szUserSearch = new SzUserSearch();
    szUserSearch.setTotalResults(1);
    szUserSearch.setStartIndex(0);
    szUserSearch.setPageResults(1);
    when(szClientUAMA.searchUsers(any(), any()))
        .thenReturn(new ResponseEntity<>(szUserSearch, HttpStatus.OK));
    SzUserSearch result = szService.getExternalUserByIdpSubject("testIdpSubject");
    assertEquals(1, result.getTotalResults());
    assertEquals(0, result.getStartIndex());
    assertEquals(1, result.getPageResults());
  }

  @Test(expected = FumValidationException.class)
  public void testGetExternalUserByIdpSubject_when4xxError_shouldThrowFumValidationException() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.searchUsers(any(), any()))
        .thenReturn(new ResponseEntity<>((HttpHeaders) null, HttpStatus.BAD_REQUEST));
    szService.getExternalUserByIdpSubject("testIdpSubject");
  }

  @Test(expected = FumServiceException.class)
  public void testGetExternalUserByIdpSubject_when5xxError_shouldThrowFumServiceException() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.searchUsers(any(), any()))
        .thenReturn(new ResponseEntity<>((HttpHeaders) null, HttpStatus.INTERNAL_SERVER_ERROR));
    szService.getExternalUserByIdpSubject("testIdpSubject");
  }

  @Test(expected = FumServiceException.class)
  public void testGetExternalUserByIdpSubject_whenExceptionThrown_shouldThrowFumServiceException() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.searchUsers(any(), any()))
        .thenThrow(mock(FeignException.FeignServerException.class));
    RequestAttributes mockRequest = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(mockRequest);
    szService.getExternalUserByIdpSubject("testIdpSubject");
  }

  @Test(expected = FumValidationException.class)
  public void testGetExternalUserByIdpSubject_whenFumValidationExceptionThrown_shouldRethrow() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.searchUsers(any(), any()))
        .thenThrow(new FumValidationException("error", "validation error"));
    szService.getExternalUserByIdpSubject("testIdpSubject");
  }

  @Test(expected = FumServiceException.class)
  public void testGetExternalUserByIdpSubject_whenFumServiceExceptionThrown_shouldRethrow() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.searchUsers(any(), any()))
        .thenThrow(new FumServiceException("error", "service error"));
    szService.getExternalUserByIdpSubject("testIdpSubject");
  }

  @Test
  public void testUpdateUserActiveStatus_whenSuccessful_shouldNotThrowException() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.updateUser(any(), any(), any()))
        .thenReturn(new ResponseEntity<>("response", HttpStatus.OK));
    try {
      szService.updateUserActiveStatus("szId", new SzUser());
    } catch (Exception e) {
      fail("Should not throw exception");
    }
  }

  @Test(expected = FumValidationException.class)
  public void testUpdateUserActiveStatus_when4xxError_shouldThrowFumValidationException() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.updateUser(any(), any(), any()))
        .thenReturn(new ResponseEntity<>("response", HttpStatus.BAD_REQUEST));
    szService.updateUserActiveStatus("szId", new SzUser());
  }

  @Test(expected = FumServiceException.class)
  public void testUpdateUserActiveStatus_when5xxError_shouldThrowFumServiceException() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.updateUser(any(), any(), any()))
        .thenReturn(new ResponseEntity<>("response", HttpStatus.INTERNAL_SERVER_ERROR));
    szService.updateUserActiveStatus("szId", new SzUser());
  }

  @Test(expected = FumServiceException.class)
  public void testUpdateUserActiveStatus_whenExceptionThrown_shouldThrowFumServiceException() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.updateUser(any(), any(), any()))
        .thenThrow(mock(FeignException.FeignServerException.class));
    RequestAttributes mockRequest = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(mockRequest);
    szService.updateUserActiveStatus("szId", new SzUser());
  }

  @Test(expected = FumValidationException.class)
  public void testUpdateUserActiveStatus_whenFumValidationExceptionThrown_shouldRethrow() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.updateUser(any(), any(), any()))
        .thenThrow(new FumValidationException("error", "validation error"));
    szService.updateUserActiveStatus("szId", new SzUser());
  }

  @Test(expected = FumServiceException.class)
  public void testUpdateUserActiveStatus_whenFumServiceExceptionThrown_shouldRethrow() {
    when(systemTokenFactory.getBearerToken(any())).thenReturn(STUB_BEARER_TOKEN);
    when(szClientUAMA.updateUser(any(), any(), any()))
        .thenThrow(new FumServiceException("error", "service error"));
    szService.updateUserActiveStatus("szId", new SzUser());
  }
}
