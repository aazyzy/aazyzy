package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.Duration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

@RunWith(MockitoJUnitRunner.Silent.class)
public class TokenRevocationServiceTest {

  @Mock
  private RedisTemplate<String, Object> redisTemplate;

  @Mock
  private ValueOperations<String, Object> valueOperations;

  private TokenRevocationService tokenRevocationService;

  @Before
  public void setUp() {
    when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    tokenRevocationService = new TokenRevocationService(redisTemplate);
  }

  @Test
  public void revokeToken_shouldStoreTokenInRedisWithCorrectKeyAndTtl() {
    String token = "eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ1c2VyMSJ9.sig";

    tokenRevocationService.revokeToken(token);

    ArgumentCaptor<String> keyCaptor = ArgumentCaptor.forClass(String.class);
    ArgumentCaptor<Object> valueCaptor = ArgumentCaptor.forClass(Object.class);
    ArgumentCaptor<Duration> ttlCaptor = ArgumentCaptor.forClass(Duration.class);

    verify(valueOperations).set(keyCaptor.capture(), valueCaptor.capture(), ttlCaptor.capture());

    assertEquals("revoked-token:" + token, keyCaptor.getValue());
    assertEquals("revoked", valueCaptor.getValue());
    assertEquals(Duration.ofMinutes(30), ttlCaptor.getValue());
  }

  @Test
  public void revokeToken_shouldStoreFullTokenAsKey() {
    String token = "header.payload.signature";

    tokenRevocationService.revokeToken(token);

    ArgumentCaptor<String> keyCaptor = ArgumentCaptor.forClass(String.class);
    verify(valueOperations).set(keyCaptor.capture(),
        org.mockito.ArgumentMatchers.anyString(),
        org.mockito.ArgumentMatchers.any(Duration.class));

    assertEquals("revoked-token:header.payload.signature", keyCaptor.getValue());
  }

  @Test(expected = IllegalArgumentException.class)
  public void revokeToken_shouldThrowOnBlankToken() {
    tokenRevocationService.revokeToken("");
  }

  @Test(expected = IllegalArgumentException.class)
  public void revokeToken_shouldThrowOnNullToken() {
    tokenRevocationService.revokeToken(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void revokeToken_shouldThrowOnWhitespaceToken() {
    tokenRevocationService.revokeToken("   ");
  }

}