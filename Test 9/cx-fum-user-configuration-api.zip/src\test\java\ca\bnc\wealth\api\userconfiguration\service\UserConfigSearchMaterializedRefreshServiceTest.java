package ca.bnc.wealth.api.userconfiguration.service;

import static org.mockito.Mockito.verify;

import ca.bnc.wealth.common.fum.service.UserSearchViewRefreshService;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class UserConfigSearchMaterializedRefreshServiceTest {

  @Mock
  private UserSearchViewRefreshService userSearchViewRefreshService;

  @InjectMocks
  private UserConfigSearchMaterializedRefreshService userConfigSearchMaterializedRefreshService;

  @Test
  void refreshUserSearchMaterializedView_delegatesToSharedService() {
    userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(true);

    verify(userSearchViewRefreshService).refreshAsync(true);
  }

  @Test
  void refreshUserSearchMaterializedViewWithRunnable_delegatesToSharedService() {
    Runnable afterRefresh = () -> { };

    userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedView(afterRefresh, false);

    verify(userSearchViewRefreshService).refreshAsync(afterRefresh, false);
  }

  @Test
  void refreshUserSearchMaterializedViewIfChanged_delegatesToSharedService() {
    IamUserConfiguration before = new IamUserConfiguration();
    IamUserConfiguration after = new IamUserConfiguration();

    userConfigSearchMaterializedRefreshService.refreshUserSearchMaterializedViewIfChanged(before, after, false);

    verify(userSearchViewRefreshService).refreshAsyncIfSearchFieldChanged(before, after, false);
  }
}
