package ca.bnc.wealth.api.userconfiguration.service;

import static ca.bnc.wealth.api.userconfiguration.util.MockData.IDP_USER_SUB;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.INDALL;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.USER_EMAIL;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.USER_FIRST_NAME;
import static ca.bnc.wealth.api.userconfiguration.util.MockData.USER_LAST_NAME;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.userconfiguration.model.R2userStatus;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.MockData;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.service.FeaturePackageServiceHelper;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.r2.model.R2UserProfile;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.NoResultsFoundException;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ServiceException;
import ca.bnc.wealth.common.userconfiguration.model.FeaturePackage;
import ca.bnc.wealth.common.userconfiguration.model.NbxUserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.NbxUserConfiguration.PreferredLanguageEnum;
import ca.bnc.wealth.common.userconfiguration.model.ResourceName;
import ca.bnc.wealth.common.userconfiguration.model.UamaUpdateUserExternalId;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserCredentials;
import ca.bnc.wealth.common.userconfiguration.model.UserDetails;
import ca.bnc.wealth.common.userconfiguration.model.UserGroupName;
import ca.bnc.wealth.common.userconfiguration.model.UserOktaProfile;
import ca.bnc.wealth.common.userconfiguration.model.UserPreferredLanguage;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletWebRequest;

@RunWith(SpringRunner.class)
public class UserConfigValidationServiceTests {

  private static final String HASHED_PASSWORD =
      "$2a$12$oXag6QzQfCFxF13b7xv3mONFqtWJSqb7IYmQgizjOGG71leQFN6B2";

  private UserConfigValidationService userConfigValidationService;

  @MockitoBean private UserConfigurationServiceJpa userConfigurationServiceJpa;

  @MockitoBean private R2Service r2Service;

  @MockitoBean private CiamService ciamService;

  @MockitoBean private UserValidationService userValidationService;

  @MockitoBean private UserService userService;

  @MockitoBean private FeaturePackageServiceHelper featurePackageServiceHelper;

  @MockitoBean private ResourceRepository resourceRepository;

  @Before
  public void setup() {
    userConfigValidationService =
        new UserConfigValidationService(
            userConfigurationServiceJpa, r2Service, ciamService, userValidationService, userService, featurePackageServiceHelper, resourceRepository);
  }

  @Test
  public void testGetUsernameAndTempPassword_DaoReturnEmpty() {
    UserDetails userName = new UserDetails();
    userName.setFirstName(USER_FIRST_NAME);
    userName.setLastName(USER_LAST_NAME);
    userName.setEmail(USER_EMAIL);

    UserCredentials userCredentials =
        userConfigValidationService.getUsernameAndTempPassword(userName);
    assertEquals(userCredentials.getUsername(), USER_FIRST_NAME + "." + USER_LAST_NAME);
  }

  @Test
  public void testGetUsernameAndTempPassword_DaoReturnOneRecord() {
    UserDetails userName = new UserDetails();
    userName.setFirstName(USER_FIRST_NAME);
    userName.setLastName(USER_LAST_NAME);
    userName.setEmail(USER_EMAIL);

    when(userConfigurationServiceJpa.getMatchedUserName(anyString()))
        .thenReturn(List.of(USER_FIRST_NAME + "." + USER_LAST_NAME));
    UserCredentials userCredentials =
        userConfigValidationService.getUsernameAndTempPassword(userName);
    assertEquals(userCredentials.getUsername(), USER_FIRST_NAME + "." + USER_LAST_NAME + 1);
  }

  @Test
  public void testGetUserNameAndTempPassword_caseInsensitive() {
    UserDetails userName = new UserDetails();
    userName.setFirstName("firstName");
    userName.setLastName("lastName");
    userName.setEmail(USER_EMAIL);

    when(userConfigurationServiceJpa.getMatchedUserName(anyString()))
        .thenReturn(List.of());
    UserCredentials userCredentials =
        userConfigValidationService.getUsernameAndTempPassword(userName);
    assertEquals( "firstname.lastname", userCredentials.getUsername());

    when(userConfigurationServiceJpa.getMatchedUserName(anyString()))
        .thenReturn(List.of("firstname.lastname"));
    userCredentials =
        userConfigValidationService.getUsernameAndTempPassword(userName);
    assertEquals( "firstname.lastname1", userCredentials.getUsername());

    when(userConfigurationServiceJpa.getMatchedUserName(anyString()))
        .thenReturn(List.of("Firstname.Lastname"));
    userCredentials =
        userConfigValidationService.getUsernameAndTempPassword(userName);
    assertEquals("firstname.lastname1", userCredentials.getUsername());


    when(userConfigurationServiceJpa.getMatchedUserName(anyString()))
        .thenReturn(List.of("Firstname.Lastname", "Firstname.Lastname1"));
    userCredentials =
        userConfigValidationService.getUsernameAndTempPassword(userName);
    assertEquals("firstname.lastname2", userCredentials.getUsername());

    when(userConfigurationServiceJpa.getMatchedUserName(anyString()))
        .thenReturn(List.of("Firstname.Lastname", "Firstname.Lastname1", "Firstname.Lastname2"));
    userCredentials =
        userConfigValidationService.getUsernameAndTempPassword(userName);
    assertEquals("firstname.lastname3", userCredentials.getUsername());

    when(userConfigurationServiceJpa.getMatchedUserName(anyString()))
        .thenReturn(List.of("Firstname.Lastname", "Firstname.Lastname1", "Firstname.Lastname7"));
    userCredentials =
        userConfigValidationService.getUsernameAndTempPassword(userName);
    assertEquals("firstname.lastname8", userCredentials.getUsername());

    when(userConfigurationServiceJpa.getMatchedUserName(anyString()))
        .thenReturn(List.of( "Firstname.Lastname7"));
    userCredentials =
        userConfigValidationService.getUsernameAndTempPassword(userName);
    assertEquals("firstname.lastname8", userCredentials.getUsername());

  }

  @Test
  public void test_createUserConfigurationMatchedUserName() {
    Map<String, String> map = new HashMap<>();
    map.put(Constants.EMAIL, "email alrady available");
    UserConfiguration userConf = MockData.getUserConfiguration();
    when(userValidationService.validateUser(userConf)).thenReturn(map);
    userConf.setCompassR2Id("cxId");

    when(r2Service.getR2UserProfileWithStatus(anyString()))
        .thenReturn(Pair.of(R2userStatus.WITH_CPX_SUB, new R2UserProfile()));
    Map<String, String> res =
        userConfigValidationService.validateUserConfigurationCreation(userConf, false);
    assertTrue(res.size() > 0);
  }

  @Test
  public void test_createUserConfigurationR2WithCpxId() {
    UserConfiguration userConf = MockData.getUserConfiguration();

    userConf.setUsername(null);
    userConf.setPassword(null);
    userConf.setCompassR2Id("cxId");
    when(userValidationService.isExternalSSOEnabled(any())).thenReturn(true);
    when(r2Service.getR2UserProfileWithStatus(anyString()))
        .thenReturn(Pair.of(R2userStatus.WITH_CPX_SUB, new R2UserProfile()));
    Map<String, String> response =
        userConfigValidationService.validateUserConfigurationCreation(userConf, false);
    assertEquals(1, response.size());
  }

  @Test
  public void test_createUserConfigurationR2WithOutCpxId() {
    UserConfiguration userConf = MockData.getUserConfiguration();

    userConf.setUsername(null);
    userConf.setPassword(null);
    userConf.setCompassR2Id("cxId");
    when(userValidationService.isExternalSSOEnabled(any())).thenReturn(true);
    when(r2Service.getR2UserProfileWithStatus(anyString()))
        .thenReturn(Pair.of(R2userStatus.WITHOUT_CPX_SUB, new R2UserProfile()));
    Map<String, String> response =
        userConfigValidationService.validateUserConfigurationCreation(userConf, false);
    assertEquals(0, response.size());
  }

  @Test
  @Ignore
  public void test_createUserConfigurationR2NotFound() {
    UserConfiguration userConf = MockData.getUserConfiguration();

    userConf.setUsername(null);
    userConf.setPassword(null);
    userConf.setCompassR2Id("cxId");

    when(r2Service.getR2UserProfileWithStatus(anyString()))
        .thenReturn(Pair.of(R2userStatus.NOT_FOUND, new R2UserProfile()));
    Map<String, String> response =
        userConfigValidationService.validateUserConfigurationCreation(userConf, false);
    assertEquals(1, response.size());
  }

  @Test
  public void test_createUserConfigurationR2NotProvided() {
    UserConfiguration userConf = MockData.getUserConfiguration();

    userConf.setUsername(null);
    userConf.setPassword(null);
    userConf.setCompassR2Id(null);

    Map<String, String> response =
        userConfigValidationService.validateUserConfigurationCreation(userConf, false);
    assertEquals(0, response.size());
  }

  @Test
  @Ignore
  public void test_createUserConfigurationR2CallFails() {
    UserConfiguration userConf = MockData.getUserConfiguration();

    userConf.setUsername(null);
    userConf.setPassword(null);
    userConf.setCompassR2Id("invalid");

    when(r2Service.getR2UserProfileWithStatus(anyString())).thenThrow(ServiceException.class);
    Map<String, String> response =
        userConfigValidationService.validateUserConfigurationCreation(userConf, false);
    assertEquals(1, response.size());
  }

  @Test
  public void test_createUserConfiguration_whenOnlyUserNameProvided() {
    UserConfiguration userConf = MockData.getUserConfiguration();
    userConf.setPassword(null);
    userConf.setCompassR2Id("cxId");

    when(r2Service.getR2UserProfileWithStatus(anyString()))
        .thenReturn(Pair.of(R2userStatus.WITH_CPX_SUB, new R2UserProfile()));

    userConfigValidationService.validateUserConfigurationCreation(userConf, false);
    assertEquals(MockData.USER_NAME_LABEL, userConf.getUsername());
    assertNotNull(userConf.getPassword());
  }

  @Test
  public void test_createUserConfiguration_whenExternalClientIdProvided() {
    UserConfiguration userConf = MockData.getUserConfiguration();
    userConf.setPassword(null);
    userConf.setCompassR2Id("cxId");

    when(r2Service.getR2UserProfileWithStatus(anyString()))
        .thenReturn(Pair.of(R2userStatus.WITH_CPX_SUB, new R2UserProfile()));

    Map<String, String> response =
        userConfigValidationService.validateUserConfigurationCreation(userConf, false);
    assertEquals(MockData.USER_NAME_LABEL, userConf.getUsername());
    assertNotNull(userConf.getPassword());
  }

  @Test
  public void test_createUserConfiguration_whenEnvVariableProvided() throws Exception {
    Field field = userConfigValidationService.getClass().getDeclaredField("env");
    field.set(userConfigValidationService, "dev");
    UserConfiguration userConf = MockData.getUserConfiguration();
    userConf.setCompassR2Id("cxId");

    when(r2Service.getR2UserProfileWithStatus(anyString()))
        .thenReturn(Pair.of(R2userStatus.WITH_CPX_SUB, new R2UserProfile()));

    userConfigValidationService.validateUserConfigurationCreation(userConf, false);
    assertEquals(
        MockData.USER_NAME_LABEL + "." + userConfigValidationService.env, userConf.getUsername());
    assertNotNull(userConf.getPassword());
  }

  @Test
  public void test_createUserConfiguration_whenCloning() throws Exception {
    Field field = userConfigValidationService.getClass().getDeclaredField("env");
    field.set(userConfigValidationService, "dev");
    UserConfiguration userConf = MockData.getUserConfiguration();
    userConf.setSourceIdpSubject("1234");
    userConf.setCompassR2Id("cxId");

    when(r2Service.getR2UserProfileWithStatus(anyString()))
        .thenReturn(Pair.of(R2userStatus.WITH_CPX_SUB, new R2UserProfile()));

    userConfigValidationService.validateUserConfigurationCreation(userConf, false);
    assertEquals(MockData.USER_NAME_LABEL, userConf.getUsername());
    assertNotNull(userConf.getPassword());
  }

  @Test
  public void test_createUserConfiguration_whenOktaProfileExists() throws Exception {
    Field field = userConfigValidationService.getClass().getDeclaredField("env");
    field.set(userConfigValidationService, "dev");
    UserConfiguration userConf = MockData.getUserConfiguration();
    userConf.setSourceIdpSubject("1234");
    userConf.setCompassR2Id("cxId");

    when(r2Service.getR2UserProfileWithStatus(anyString()))
        .thenReturn(Pair.of(R2userStatus.WITH_CPX_SUB, new R2UserProfile()));
    when(ciamService.getOktaUserProfile(any(), anyInt())).thenReturn(Optional.of(MockData.getOktaUserProfile()));

    Map<String, String> response = userConfigValidationService.validateUserConfigurationCreation(userConf, false);
    assertFalse(response.isEmpty());
    assertEquals(Constants.ERROR_OKTA_PROFILE_FOUND, response.get(Constants.OKTA_PROFILE));
  }

  @Test
  public void test_createUserConfiguration_whenExternalClientId() throws Exception {
    Field field = userConfigValidationService.getClass().getDeclaredField("env");
    field.set(userConfigValidationService, "dev");
    UserConfiguration userConf = MockData.getUserConfiguration();
    userConf.setSourceIdpSubject("1234");
    userConf.setCompassR2Id("cxId");
    userConf.setExternalClientId("abc");

    when(r2Service.getR2UserProfileWithStatus(anyString()))
        .thenReturn(Pair.of(R2userStatus.WITH_CPX_SUB, new R2UserProfile()));
    when(userService.generateUserNameForSSO(anyString(), anyString())).thenReturn("indall_abc");

    userConfigValidationService.validateUserConfigurationCreation(userConf, true);
    assertEquals("indall_abc", userConf.getUsername());
    assertNotNull(userConf.getPassword());
  }

  @Test
  public void test_createUserConfiguration_whenHashedPasswordProvided_shouldNotGenerateTempPassword() {
    UserConfiguration userConf = MockData.getUserConfiguration();
    userConf.setPassword(null);
    userConf.setHashedPassword(HASHED_PASSWORD);

    userConfigValidationService.validateUserConfigurationCreation(userConf, false);

    assertNull(userConf.getPassword());
    assertEquals(HASHED_PASSWORD, userConf.getHashedPassword());
    assertEquals(MockData.USER_NAME_LABEL, userConf.getUsername());
    verify(userConfigurationServiceJpa, never()).getMatchedUserName(anyString());
  }

  @Test
  public void test_createUserConfiguration_whenHashedPasswordAndNoUsername_shouldGenerateUsernameOnly() {
    UserConfiguration userConf = MockData.getUserConfiguration();
    userConf.setUsername(null);
    userConf.setPassword(null);
    userConf.setHashedPassword(HASHED_PASSWORD);

    userConfigValidationService.validateUserConfigurationCreation(userConf, false);

    assertNotNull(userConf.getUsername());
    assertNull(userConf.getPassword());
  }

  @Test
  public void test_createUserConfiguration_whenSsoUserWithHashedPassword_shouldUseTempPassword() {
    UserConfiguration userConf = MockData.getUserConfiguration();
    userConf.setPassword(null);
    userConf.setHashedPassword(HASHED_PASSWORD);
    userConf.setExternalClientId("abc");
    when(userService.generateUserNameForSSO(any(), anyString())).thenReturn("indall_abc");

    userConfigValidationService.validateUserConfigurationCreation(userConf, false);

    assertNull(userConf.getHashedPassword());
    assertNotNull(userConf.getPassword());
  }

  @Test
  public void test_getUsernameAndTempPassword() {
    UserDetails userDetails =
        new UserDetails()
            .firstName(MockData.USER_FIRST_NAME)
            .lastName(MockData.USER_LAST_NAME)
            .email(MockData.USER_EMAIL);

    UserCredentials userCredentials =
        userConfigValidationService.getUsernameAndTempPassword(userDetails);
    assertEquals(MockData.USER_NAME_LABEL, userCredentials.getUsername());
    assertNotNull(userCredentials.getTempPassword());
  }

  @Test
  public void test_getUsernameAndTempPassword_whenEnvVariableSet() throws Exception {
    Field field = userConfigValidationService.getClass().getDeclaredField("env");
    field.set(userConfigValidationService, "dev");
    UserDetails userDetails =
        new UserDetails()
            .firstName(MockData.USER_FIRST_NAME)
            .lastName(MockData.USER_LAST_NAME)
            .email(MockData.USER_EMAIL);

    UserCredentials userCredentials =
        userConfigValidationService.getUsernameAndTempPassword(userDetails);
    assertEquals(
        MockData.USER_NAME_LABEL + "." + userConfigValidationService.env, userCredentials.getUsername());
    assertNotNull(userConfigValidationService.env, userCredentials.getTempPassword());
  }

  @Test
  public void test_validateUserDetailsMandatoryFields_whenAllFieldsProvidedProvided() {
    UserDetails userDetails =
        new UserDetails()
            .firstName(MockData.USER_FIRST_NAME)
            .lastName(MockData.USER_LAST_NAME)
            .email(USER_EMAIL);
    try {
      userConfigValidationService.validateUserDetailsMandatoryFields(userDetails);
    } catch (Exception e) {
      fail("This test case should not throw any exception");
    }
  }

  @Test(expected = ServiceException.class)
  public void test_validateUserDetailsMandatoryFields_whenEmptyUserDetails() {
    userConfigValidationService.validateUserDetailsMandatoryFields(new UserDetails());
  }

  @Test(expected = ServiceException.class)
  public void test_validateUserDetailsMandatoryFields_whenOnlyFirstNameProvided() {
    UserDetails userDetails = new UserDetails().firstName(MockData.USER_FIRST_NAME);
    userConfigValidationService.validateUserDetailsMandatoryFields(userDetails);
  }

  @Test(expected = ServiceException.class)
  public void test_validateUserDetailsMandatoryFields_whenOnlyFirstNameAndLastNameProvided() {
    UserDetails userDetails =
        new UserDetails().firstName(MockData.USER_FIRST_NAME).lastName(MockData.USER_LAST_NAME);
    userConfigValidationService.validateUserDetailsMandatoryFields(userDetails);
  }

  @Test
  public void test_validateUserPreferredLanguage_whenValidUserPreferredLanguage() {
    UserPreferredLanguage userPreferredLanguage = new UserPreferredLanguage();
    userPreferredLanguage.setPreferredLanguage(UserPreferredLanguage.PreferredLanguageEnum.EN);

    try {
      userConfigValidationService.validateUserPreferredLanguage(userPreferredLanguage);
    } catch (Exception e) {
      fail("Should not throw exception");
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserPreferredLanguage_whenNullObject() {
    userConfigValidationService.validateUserPreferredLanguage(null);
  }

  @Test
  public void test_validateResourceName_whenValidResourceName() {
    ResourceName resourceName = new ResourceName();
    resourceName.setResourceName("Test Name");

    try {
      userConfigValidationService.validateResourceName(resourceName);
    } catch (Exception e) {
      fail("Should not throw exception");
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateResourceName_whenNullObject() {
    userConfigValidationService.validateResourceName(null);
  }

  @Test
  public void test_validateDwhResourceName_whenValid() {
    ResourceName resourceName = new ResourceName();
    resourceName.setResourceName("dwh-module-1");
    when(resourceRepository.findFirstByTypeAndName("dwh_ui_module", "dwh-module-1"))
        .thenReturn(Optional.of(new Resource()));
    try {
      userConfigValidationService.validateDwhResourceName(resourceName);
    } catch (Exception e) {
      fail("Should not throw exception");
    }
  }

  @Test(expected = FumValidationException.class)
  public void test_validateDwhResourceName_whenResourceNotFound() {
    ResourceName resourceName = new ResourceName();
    resourceName.setResourceName("non-existent");
    when(resourceRepository.findFirstByTypeAndName("dwh_ui_module", "non-existent"))
        .thenReturn(Optional.empty());
    userConfigValidationService.validateDwhResourceName(resourceName);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateDwhResourceName_whenNullObject() {
    userConfigValidationService.validateDwhResourceName(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateDwhResourceName_whenNullResourceName() {
    ResourceName resourceName = new ResourceName();
    userConfigValidationService.validateDwhResourceName(resourceName);
  }

  @Test
  public void test_getDwhResourceNames_returnsNames() {
    Resource r1 = new Resource();
    r1.setName("dwh-module-1");
    Resource r2 = new Resource();
    r2.setName("dwh-module-2");
    when(resourceRepository.findByType("dwh_ui_module"))
        .thenReturn(List.of(r1, r2));
    Set<String> result = userConfigValidationService.getDwhResourceNames();
    assertEquals(2, result.size());
    assertTrue(result.contains("dwh-module-1"));
    assertTrue(result.contains("dwh-module-2"));
  }

  @Test
  public void test_getDwhResourceNames_whenEmpty() {
    when(resourceRepository.findByType("dwh_ui_module"))
        .thenReturn(List.of());
    Set<String> result = userConfigValidationService.getDwhResourceNames();
    assertTrue(result.isEmpty());
  }

  @Test
  public void test_validateUserGroupName_whenValidUserGroupName() {
    UserGroupName userGroupName = new UserGroupName();
    userGroupName.setUserGroupName("Test Name");

    try {
      userConfigValidationService.validateUserGroupName(userGroupName);
    } catch (Exception e) {
      fail("Should not throw exception");
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserGroupName_whenNullObject() {
    userConfigValidationService.validateUserGroupName(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserPreferredLanguage_whenNullUserPreferredLanguage() {
    userConfigValidationService.validateUserPreferredLanguage(new UserPreferredLanguage());
  }

  @Test
  public void test_validateUserCreationMandatoryFields_whenAllFieldsProvided() {
    try {
      UserConfiguration userConfiguration = MockData.getUserConfiguration();
      userConfiguration.setFeaturePackage(new FeaturePackage());
      userConfigValidationService.validateUserCreationMandatoryFields(userConfiguration);
    } catch (Exception e) {
      fail("Should not throw exception");
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFields_whenNullFirstName() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setFirstName(null);
    userConfigValidationService.validateUserCreationMandatoryFields(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFields_whenNullLastName() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setLastName(null);
    userConfigValidationService.validateUserCreationMandatoryFields(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFields_whenNullEmail() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setEmail(null);
    userConfigValidationService.validateUserCreationMandatoryFields(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFields_whenInvalidEmail() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setEmail("invalid");
    userConfigValidationService.validateUserCreationMandatoryFields(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFields_whenNullUserGroup() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setUserGroup(null);
    userConfigValidationService.validateUserCreationMandatoryFields(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFields_whenNullPreferredLanguage() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setPreferredLanguage(null);
    userConfigValidationService.validateUserCreationMandatoryFields(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFieldsForNonNbin_whenNullFirstName() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setFirstName(null);
    userConfigValidationService.validateUserCreationForNonNbin(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFieldsForNonNbin_whenInvalidFirstName() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setFirstName(MockData.INVALID_NAME);
    userConfigValidationService.validateUserCreationForNonNbin(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFieldsForNonNbin_whenNullLastName() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setLastName(null);
    userConfigValidationService.validateUserCreationForNonNbin(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFieldsForNonNbin_whenInvalidLastName() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setLastName(MockData.INVALID_NAME);
    userConfigValidationService.validateUserCreationForNonNbin(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFieldsForNonNbin_whenNullEmail() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setEmail(null);
    userConfigValidationService.validateUserCreationForNonNbin(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFieldsForNonNbin_whenInvalidEmail() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setEmail("invalid");
    userConfigValidationService.validateUserCreationForNonNbin(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFieldsForNonNbin_whenNullPreferredLanguage() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setPreferredLanguage(null);
    userConfigValidationService.validateUserCreationForNonNbin(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFieldsForNonNbin_whenNullIdpSubject() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setIdpSubject(null);
    userConfigValidationService.validateUserCreationForNonNbin(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFieldsForNonNbin_whenNullIdpUserId() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setIdpUserId(null);
    userConfigValidationService.validateUserCreationForNonNbin(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFieldsForNonNbin_whenNullUserName() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setUsername(null);
    userConfigValidationService.validateUserCreationForNonNbin(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFieldsForNonNbin_whenR2CallFaild() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setCompassR2Id("r2");
    userConfigValidationService.validateUserCreationForNonNbin(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserCreationMandatoryFieldsForNonNbin_whenR2NotFound() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setCompassR2Id("r2");
    when(r2Service.getR2UserProfileWithStatus(anyString()))
        .thenReturn(Pair.of(R2userStatus.NOT_FOUND, null));
    userConfigValidationService.validateUserCreationForNonNbin(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateIdp_Mismatch() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setIdp("nbin");
    UserOktaProfile oktaUserProfile = MockData.getUserOktaProfile();
    when(userService.getOktaProfile(Mockito.anyString())).thenReturn(oktaUserProfile);
    userConfigValidationService.validateIdp(userConfiguration);
  }

  @Test
  public void test_validateIdp() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setIdp(INDALL);
    UserOktaProfile oktaUserProfile = MockData.getUserOktaProfile();
    when(userService.getOktaProfile(Mockito.anyString())).thenReturn(oktaUserProfile);
    userConfigValidationService.validateIdp(userConfiguration);
  }

  @Test
  public void test_validateUserUpdateMandatoryFields() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    when(r2Service.getR2UserProfileWithStatus(anyString()))
        .thenReturn(Pair.of(R2userStatus.WITHOUT_CPX_SUB, null));
    userConfigValidationService.validateUserUpdateForNonNbin(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserUpdateMandatoryFieldsForNonNbin_whenR2CallFaild() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setCompassR2Id("r2");
    userConfigValidationService.validateUserUpdateForNonNbin(userConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUserUpdateMandatoryFieldsForNonNbin_whenR2NotFound() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setCompassR2Id("r2");
    when(r2Service.getR2UserProfileWithStatus(anyString()))
        .thenReturn(Pair.of(R2userStatus.NOT_FOUND, null));
    userConfigValidationService.validateUserUpdateForNonNbin(userConfiguration);
  }

  @Test
  public void test_validateUserUpdateForNonNbin_whenCompassR2IdEmpty_skipsR2Validation() {
    // Clearing the R2 field in the UI sends an empty string, not null. A blank id is an unlink
    // request, so it must never be validated against R2 - R2 answers NOT_FOUND for a blank id,
    // which surfaced as error.r2.notfound and made removing an employee's R2 id impossible.
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setCompassR2Id("");

    userConfigValidationService.validateUserUpdateForNonNbin(userConfiguration);

    verify(r2Service, times(0)).getR2UserProfileWithStatus(anyString());
  }

  @Test
  public void test_validateUserUpdateForNonNbin_whenCompassR2IdWhitespace_skipsR2Validation() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setCompassR2Id("   ");

    userConfigValidationService.validateUserUpdateForNonNbin(userConfiguration);

    verify(r2Service, times(0)).getR2UserProfileWithStatus(anyString());
  }

  @Test
  public void test_validateUserUpdateForNonNbin_whenCompassR2IdNull_skipsR2Validation() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setCompassR2Id(null);

    userConfigValidationService.validateUserUpdateForNonNbin(userConfiguration);

    verify(r2Service, times(0)).getR2UserProfileWithStatus(anyString());
  }

  @Test
  public void test_validateUserUpdateForNonNbin_whenCompassR2IdProvided_stillValidatesAgainstR2() {
    // The blank guard must not weaken validation of a real id.
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setCompassR2Id("paul.guevarra");
    when(r2Service.getR2UserProfileWithStatus(anyString()))
        .thenReturn(Pair.of(R2userStatus.WITHOUT_CPX_SUB, null));

    userConfigValidationService.validateUserUpdateForNonNbin(userConfiguration);

    verify(r2Service, times(1)).getR2UserProfileWithStatus("paul.guevarra");
  }

  @Test
  public void test_validateFieldsForNonNbin_whenEmployeeIdpAndNullIdpUserId_shouldNotThrow()
      throws Exception {
    setEmployeeIdp(Constants.EMPLOYEE_IDP);
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setIdp(Constants.EMPLOYEE_IDP);
    userConfiguration.setIdpUserId(null);
    try {
      userConfigValidationService.validateFieldsForNonNbin(userConfiguration);
    } catch (IllegalArgumentException e) {
      fail("Employee (IAMi) users with a null idpUserId should not be rejected: " + e.getMessage());
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateFieldsForNonNbin_whenNonEmployeeIdpAndNullIdpUserId_shouldThrow()
      throws Exception {
    setEmployeeIdp(Constants.EMPLOYEE_IDP);
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setIdp(INDALL);
    userConfiguration.setIdpUserId(null);
    userConfigValidationService.validateFieldsForNonNbin(userConfiguration);
  }

  @Test
  public void test_validateUserUpdateForNonNbin_whenEmployeeIdpAndNullIdpUserId_shouldNotThrow()
      throws Exception {
    setEmployeeIdp(Constants.EMPLOYEE_IDP);
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setIdp(Constants.EMPLOYEE_IDP);
    userConfiguration.setIdpUserId(null);
    userConfiguration.setCompassR2Id(null);
    try {
      userConfigValidationService.validateUserUpdateForNonNbin(userConfiguration);
    } catch (IllegalArgumentException e) {
      fail("Employee (IAMi) users with a null idpUserId should not be rejected: " + e.getMessage());
    }
  }

  @Test
  public void test_validateUserCreationForNonNbin_whenEmployeeIdpAndNullIdpUserId_shouldNotThrow()
      throws Exception {
    setEmployeeIdp(Constants.EMPLOYEE_IDP);
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setIdp(Constants.EMPLOYEE_IDP);
    userConfiguration.setIdpUserId(null);
    userConfiguration.setCompassR2Id(null);
    when(userValidationService.validateUser(any())).thenReturn(new HashMap<>());
    try {
      userConfigValidationService.validateUserCreationForNonNbin(userConfiguration);
    } catch (IllegalArgumentException e) {
      fail("Employee (IAMi) users with a null idpUserId should not be rejected on creation: "
          + e.getMessage());
    }
  }

  private void setEmployeeIdp(String idp) throws Exception {
    Field field = userConfigValidationService.getClass().getDeclaredField("employeeIdp");
    field.setAccessible(true);
    field.set(userConfigValidationService, idp);
  }

  @Test
  public void test_checkForUpdatingIdpUserId() {
    setMockUser(true);

    try {
      userConfigValidationService.checkForUpdatingIdpUserId(
          MockData.getUserConfiguration(), MockData.getUserConfiguration());
    } catch (Exception e) {
      fail("Test case should not throw any exception");
    }
  }

  @Test
  public void test_checkForUpdatingIdpUserId_whenSystemTokenFalseAndNewUserIdpIsNull() {
    UserConfiguration newConfiguration = new UserConfiguration();
    newConfiguration.setIdpUserId(null);
    setMockUser(false);

    try {
      userConfigValidationService.checkForUpdatingIdpUserId(
          MockData.getUserConfiguration(), newConfiguration);
    } catch (Exception e) {
      fail("Test case should not throw any exception");
    }
  }

  @Test
  public void
      test_checkForUpdatingIdpUserId_whenSystemTokenFalseAndNewUserIdpMatchesExistingUserIdp() {
    setMockUser(false);

    try {
      userConfigValidationService.checkForUpdatingIdpUserId(
          MockData.getUserConfiguration(), MockData.getUserConfiguration());
    } catch (Exception e) {
      fail("Test case should not throw any exception");
    }
  }

  @Test(expected = FumServiceException.class)
  public void
      test_checkForUpdatingIdpUserId_whenSystemTokenFalseAndNewUserIdpDoesNotMatchExistingUserIdp() {
    UserConfiguration newConfiguration = new UserConfiguration();
    newConfiguration.setIdpUserId("1");
    setMockUser(false);

    RequestAttributes mockRequest = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(mockRequest);
    userConfigValidationService.checkForUpdatingIdpUserId(
        MockData.getUserConfiguration(), newConfiguration);
  }

  @Test
  public void test_checkForUpdatingIdpUserId_whenSystemTokenTrueAndNewIdpIsNull() {
    UserConfiguration newConfiguration = new UserConfiguration();
    newConfiguration.setIdpUserId(null);
    setMockUser(true);

    userConfigValidationService.checkForUpdatingIdpUserId(
        MockData.getUserConfiguration(), newConfiguration);
    verify(ciamService, times(0)).getOktaUserProfile(any());
  }

  @Test
  public void test_checkForUpdatingIdpUserId_whenSystemTokenTrueAndCurrentIdpIsNull() {
    UserConfiguration currentConfiguration = new UserConfiguration();
    currentConfiguration.setIdpUserId(null);
    setMockUser(true);

    userConfigValidationService.checkForUpdatingIdpUserId(
        currentConfiguration, MockData.getUserConfiguration());
    verify(ciamService, times(0)).getOktaUserProfile(any());
  }

  @Test
  public void test_checkForUpdatingIdpUserId_whenSystemTokenTrueAndIdpValuesMatch() {
    setMockUser(true);
    userConfigValidationService.checkForUpdatingIdpUserId(
        MockData.getUserConfiguration(), MockData.getUserConfiguration());
    verify(ciamService, times(0)).getOktaUserProfile(any());
  }

  @Test(expected = FumServiceException.class)
  public void test_checkForUpdatingIdpUserId_whenOktaCallReturnsNull() {
    UserConfiguration newConfiguration = new UserConfiguration();
    newConfiguration.setIdpUserId("1");
    setMockUser(true);

    when(ciamService.getOktaUserProfile(any())).thenReturn(null);

    RequestAttributes mockRequest = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(mockRequest);
    userConfigValidationService.checkForUpdatingIdpUserId(
        MockData.getUserConfiguration(), newConfiguration);
  }

  @Test(expected = FumServiceException.class)
  public void test_checkForUpdatingIdpUserId_whenOktaCallReturnsDifferentUser() {
    UserConfiguration newConfiguration = new UserConfiguration();
    newConfiguration.setIdpUserId("1");
    setMockUser(true);

    OktaUserProfile oktaUserProfile = MockData.getOktaUserProfile();
    oktaUserProfile.getAccessProfile().setLogin("another.user");

    when(ciamService.getOktaUserProfile(any())).thenReturn(oktaUserProfile);

    RequestAttributes mockRequest = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(mockRequest);
    userConfigValidationService.checkForUpdatingIdpUserId(
        MockData.getUserConfiguration(), newConfiguration);
  }

  @Test(expected = FumServiceException.class)
  public void test_checkForUpdatingIdpUserId_whenOktaCallFails() {
    UserConfiguration newConfiguration = new UserConfiguration();
    newConfiguration.setIdpUserId("1");
    setMockUser(true);

    when(ciamService.getOktaUserProfile(any())).thenThrow(NoResultsFoundException.class);

    RequestAttributes mockRequest = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(mockRequest);
    userConfigValidationService.checkForUpdatingIdpUserId(
        MockData.getUserConfiguration(), newConfiguration);
  }

  @Test
  public void test_checkForUpdatingIdpUserId_whenOktaCallReturnsSameUser() {
    UserConfiguration newConfiguration = new UserConfiguration();
    newConfiguration.setIdpUserId("1");
    setMockUser(true);

    OktaUserProfile oktaUserProfile = MockData.getOktaUserProfile();
    oktaUserProfile.getAccessProfile().setLogin(MockData.getUserConfiguration().getUsername());

    when(ciamService.getOktaUserProfile(any())).thenReturn(oktaUserProfile);

    try {
      userConfigValidationService.checkForUpdatingIdpUserId(
          MockData.getUserConfiguration(), newConfiguration);
    } catch (Exception e) {
      fail("Test case should not throw any exception");
    }
  }

  @Test
  public void test_validateAndSetActivationDate_whenActivationDateIsNull() {
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setActivationDate(null);

    userConfigValidationService.validateAndSetActivationDate(userConfiguration);
    assertNotNull(userConfiguration.getActivationDate());
  }

  @Test
  public void test_validateAndSetActivationDate_whenDateIsSetAndNotSet() {
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setActivationDate(null);

    userConfigValidationService.validateAndSetActivationDate(userConfiguration);
    assertNotNull(userConfiguration.getActivationDate());
    assertEquals(
        LocalDateTime.parse(Constants.DEFAULT_ACTIVATION_DATE),
        userConfiguration.getActivationDate());

    LocalDateTime activationDate = LocalDateTime.now();
    userConfiguration.setActivationDate(activationDate);
    userConfigValidationService.validateAndSetActivationDate(userConfiguration);
    assertEquals(activationDate, userConfiguration.getActivationDate());
  }

  @Test
  public void test_validateCreateNbxUserConfiguration_withNoValidationError() {
    try {
      userConfigValidationService.validateCreateNbxUserConfiguration(MockData.getUserConfiguration());
    } catch (Exception e) {
      fail("Test case should not throw any exception");
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateCreateNbxUserConfiguration_withValidationError() {
    when(userValidationService.validateUser(any())).thenReturn(Map.of("error", "code"));
    userConfigValidationService.validateCreateNbxUserConfiguration(MockData.getUserConfiguration());
  }

  @Test(expected = FumValidationException.class)
  public void test_validateCreateNbxUserConfiguration_whenUserExists() {
    when(userConfigurationServiceJpa.getUserByEmail(any())).thenReturn(
        Optional.of(MockData.getIamUserConfigurationEntity()));
    userConfigValidationService.validateCreateNbxUserConfiguration(MockData.getUserConfiguration());
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUpdateNbxUserConfiguration_whenNbxUserNull_shouldThrowIllegalArgumentException() {
    NbxUserConfiguration nbxUserConfiguration = null;
    userConfigValidationService.validateUpdateNbxUserConfiguration(IDP_USER_SUB, nbxUserConfiguration);
  }

  @Test(expected = IllegalArgumentException.class)
  public void test_validateUpdateNbxUserConfiguration_whenNbxUserAllFieldNull_shouldThrowIllegalArgumentException() {
    NbxUserConfiguration nbxUserConfiguration = new NbxUserConfiguration();
    userConfigValidationService.validateUpdateNbxUserConfiguration(IDP_USER_SUB, nbxUserConfiguration);
  }

  @Test
  public void test_validateUpdateNbxUserConfiguration_whenNbxUserAllTheFieldsArePopulatedAndUniqueUser_shouldNotThrowError() {

    when(userConfigurationServiceJpa
        .getUserByEmail(anyString()))
        .thenReturn(Optional.empty());

    IamUserConfiguration mockIamUserConfiguration = MockData.getIamUserConfigurationEntity();
    mockIamUserConfiguration.setSource(MockData.NBX_SOURCE);

    when(userConfigurationServiceJpa.getUserByIdpSubject(anyString()))
        .thenReturn(Optional.of(mockIamUserConfiguration));

    NbxUserConfiguration nbxUserConfiguration = new NbxUserConfiguration();
    nbxUserConfiguration.setFirstName(USER_FIRST_NAME);
    nbxUserConfiguration.setLastName(USER_LAST_NAME);
    nbxUserConfiguration.setEmail(USER_EMAIL);
    nbxUserConfiguration.setPreferredLanguage(PreferredLanguageEnum.EN);
    userConfigValidationService.validateUpdateNbxUserConfiguration(IDP_USER_SUB, nbxUserConfiguration);
  }

  @Test
  public void test_validateUpdateNbxUserConfiguration_whenNbxUserOnlyFirstNamePopulatedAndUniqueUser_shouldNotThrowError() {

    when(userConfigurationServiceJpa
        .getUserByEmail(anyString()))
        .thenReturn(Optional.empty());

    IamUserConfiguration mockIamUserConfiguration = MockData.getIamUserConfigurationEntity();
    mockIamUserConfiguration.setSource(MockData.NBX_SOURCE);

    when(userConfigurationServiceJpa.getUserByIdpSubject(anyString()))
        .thenReturn(Optional.of(mockIamUserConfiguration));

    NbxUserConfiguration nbxUserConfiguration = new NbxUserConfiguration();
    nbxUserConfiguration.setFirstName(USER_FIRST_NAME);
    userConfigValidationService.validateUpdateNbxUserConfiguration(IDP_USER_SUB, nbxUserConfiguration);
  }

  @Test
  public void test_validateUpdateNbxUserConfiguration_whenNbxUserOnlyLastNamePopulatedAndUniqueUser_shouldNotThrowError() {

    when(userConfigurationServiceJpa
        .getUserByEmail(anyString()))
        .thenReturn(Optional.empty());

    IamUserConfiguration mockIamUserConfiguration = MockData.getIamUserConfigurationEntity();
    mockIamUserConfiguration.setSource(MockData.NBX_SOURCE);

    when(userConfigurationServiceJpa.getUserByIdpSubject(anyString()))
        .thenReturn(Optional.of(mockIamUserConfiguration));

    NbxUserConfiguration nbxUserConfiguration = new NbxUserConfiguration();
    nbxUserConfiguration.setLastName(USER_FIRST_NAME);
    userConfigValidationService.validateUpdateNbxUserConfiguration(IDP_USER_SUB, nbxUserConfiguration);
  }

  @Test
  public void test_validateUpdateNbxUserConfiguration_whenNbxUserOnlyEmailPopulatedAndUniqueUser_shouldNotThrowError() {

    when(userConfigurationServiceJpa
        .getUserByEmail(anyString()))
        .thenReturn(Optional.empty());

    IamUserConfiguration mockIamUserConfiguration = MockData.getIamUserConfigurationEntity();
    mockIamUserConfiguration.setSource(MockData.NBX_SOURCE);

    when(userConfigurationServiceJpa.getUserByIdpSubject(anyString()))
        .thenReturn(Optional.of(mockIamUserConfiguration));

    NbxUserConfiguration nbxUserConfiguration = new NbxUserConfiguration();
    nbxUserConfiguration.setEmail(USER_EMAIL);
    userConfigValidationService.validateUpdateNbxUserConfiguration(IDP_USER_SUB, nbxUserConfiguration);
  }

  @Test
  public void test_validateUpdateNbxUserConfiguration_whenNbxUserOnlyPreferredLanguagePopulatedAndUniqueUser_shouldNotThrowError() {

    when(userConfigurationServiceJpa
        .getUserByEmail(anyString()))
        .thenReturn(Optional.empty());

    IamUserConfiguration mockIamUserConfiguration = MockData.getIamUserConfigurationEntity();
    mockIamUserConfiguration.setSource(MockData.NBX_SOURCE);

    when(userConfigurationServiceJpa.getUserByIdpSubject(anyString()))
        .thenReturn(Optional.of(mockIamUserConfiguration));

    NbxUserConfiguration nbxUserConfiguration = new NbxUserConfiguration();
    nbxUserConfiguration.setPreferredLanguage(PreferredLanguageEnum.EN);
    userConfigValidationService.validateUpdateNbxUserConfiguration(IDP_USER_SUB, nbxUserConfiguration);
  }

  @Test(expected = FumValidationException.class)
  public void test_validateUpdateNbxUserConfiguration_whenNbxUserAllTheFieldsArePopulatedAndNotUniqueUser_shouldNotThrowError() {
    when(userConfigurationServiceJpa
        .getUserByEmail(anyString()))
        .thenReturn(Optional.of(MockData.getIamUserConfigurationEntity()));

    IamUserConfiguration mockIamUserConfiguration = MockData.getIamUserConfigurationEntity();
    mockIamUserConfiguration.setSource(MockData.NBX_SOURCE);

    when(userConfigurationServiceJpa.getUserByIdpSubject(anyString()))
        .thenReturn(Optional.of(mockIamUserConfiguration));
    NbxUserConfiguration nbxUserConfiguration = new NbxUserConfiguration();
    nbxUserConfiguration.setFirstName(USER_FIRST_NAME);
    nbxUserConfiguration.setLastName(USER_LAST_NAME);
    nbxUserConfiguration.setEmail(USER_EMAIL);
    nbxUserConfiguration.setPreferredLanguage(PreferredLanguageEnum.EN);
    userConfigValidationService.validateUpdateNbxUserConfiguration(IDP_USER_SUB, nbxUserConfiguration);
  }

  @Test(expected = FumValidationException.class)
  public void test_validateUpdateNbxUserConfiguration_whenNbxUserAllTheFieldsArePopulatedAndNotNbxUser_shouldNotThrowError() {
    IamUserConfiguration mockIamUserConfiguration = MockData.getIamUserConfigurationEntity();
    mockIamUserConfiguration.setSource(null);

    when(userConfigurationServiceJpa.getUserByIdpSubject(anyString()))
        .thenReturn(Optional.of(mockIamUserConfiguration));

    NbxUserConfiguration nbxUserConfiguration = new NbxUserConfiguration();
    nbxUserConfiguration.setFirstName(USER_FIRST_NAME);
    nbxUserConfiguration.setLastName(USER_LAST_NAME);
    nbxUserConfiguration.setEmail(USER_EMAIL);
    nbxUserConfiguration.setPreferredLanguage(PreferredLanguageEnum.EN);
    userConfigValidationService.validateUpdateNbxUserConfiguration(IDP_USER_SUB, nbxUserConfiguration);
  }

  @Test(expected = FumNotFoundException.class)
  public void test_validateUpdateNbxUserConfiguration_whenNbxUserAllTheFieldsArePopulatedAndUserNotExist_shouldNotThrowError() {
    IamUserConfiguration mockIamUserConfiguration = MockData.getIamUserConfigurationEntity();
    mockIamUserConfiguration.setSource(MockData.NBX_SOURCE);

    when(userConfigurationServiceJpa.getUserByIdpSubject(anyString()))
        .thenReturn(Optional.empty());

    NbxUserConfiguration nbxUserConfiguration = new NbxUserConfiguration();
    nbxUserConfiguration.setFirstName(USER_FIRST_NAME);
    nbxUserConfiguration.setLastName(USER_LAST_NAME);
    nbxUserConfiguration.setEmail(USER_EMAIL);
    nbxUserConfiguration.setPreferredLanguage(PreferredLanguageEnum.EN);
    userConfigValidationService.validateUpdateNbxUserConfiguration(IDP_USER_SUB, nbxUserConfiguration);
  }

  @Test
  public void testValidateUpdateUserExternalId_whenValidInput_shouldNotThrowException() {
    UamaUpdateUserExternalId updateUserExternalId = new UamaUpdateUserExternalId();
    updateUserExternalId.setExternalUserId(List.of("id"));
    try {
    userConfigValidationService.validateUpdateUserExternalId(updateUserExternalId);
    } catch (Exception e) {
      fail("Test case should not throw any exception");
    }
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUpdateUserExternalId_whenNullInput_shouldThrowFumValidationException() {
    userConfigValidationService.validateUpdateUserExternalId(null);
  }

  @Test(expected = FumValidationException.class)
  public void testValidateUpdateUserExternalId_whenEmptyListId_shouldThrowFumValidationException() {
    userConfigValidationService.validateUpdateUserExternalId(new UamaUpdateUserExternalId());
  }

  private void setMockUser(boolean isSystemToken) {
    User user = new User();
    user.setSystemToken(isSystemToken);

    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken =
        new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>());
    SecurityContext securityContext = mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(usernamePasswordAuthenticationToken);
    SecurityContextHolder.setContext(securityContext);
  }
}
