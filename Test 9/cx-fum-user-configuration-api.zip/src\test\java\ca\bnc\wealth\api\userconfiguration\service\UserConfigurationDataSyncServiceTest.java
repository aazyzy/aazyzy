package ca.bnc.wealth.api.userconfiguration.service;

import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.MockData;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.platform.CodeValueMapping;
import ca.bnc.wealth.common.jpa.entity.platform.IdpUserStatus;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.service.IamScheduleService;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ErrorSeverity;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ServiceException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
@Slf4j
public class UserConfigurationDataSyncServiceTest {

  private UserConfigurationDataSyncService userConfigurationDataSyncService;

  @MockitoBean private IamUserConfigurationRepository iamUserConfigurationRepository;
  @MockitoBean private IamScheduleService scheduleService;
  @MockitoBean private CiamService ciamService;
  @MockitoBean private UserStateService userStateService;
  @MockitoBean private RedisCacheOperationService redisCacheOperationService;
  @MockitoBean private UserService userService;

  private Map<String, CodeValueMapping> cxpCodeValueMap;
  private Map<String, CodeValueMapping> cxpSubCodeValueMap;

  @Before
  public void setup() throws IllegalAccessException {
    userConfigurationDataSyncService =
        new UserConfigurationDataSyncService(
            iamUserConfigurationRepository,
            ciamService,
            userStateService,
            redisCacheOperationService,
            userService);
    FieldUtils.writeField(userConfigurationDataSyncService, "chunkSize", 10, true);
  }

  @Test
  public void idpStatusUpdateSchedule() {
    IamUserConfiguration user = new IamUserConfiguration();
    user.setUserConfigurationId(1l);
    user.setIdp("nbin");
    when(scheduleService.canRunSchedule(anyString(), anyLong(), eq(TimeUnit.MINUTES))).thenReturn(true);

    when(iamUserConfigurationRepository.count()).thenReturn(1l);
    when(iamUserConfigurationRepository.findAll(any(PageRequest.class))).thenReturn(new PageImpl(Arrays.asList(user)));
    when(iamUserConfigurationRepository.findById(anyLong()))
        .thenReturn(Optional.ofNullable(new IamUserConfiguration()));
    try {
      userConfigurationDataSyncService.idpStatusUpdateSchedule(Arrays.asList(user));
    } catch (Exception e) {
      fail();
    }
  }

  @Before
  public void loadStatusMaps() {
    cxpCodeValueMap = new HashMap<>();
    cxpSubCodeValueMap = new HashMap<>();
    Arrays.asList(
            Constants.CXP_SUB_STATE_CREATED,
            Constants.CXP_SUB_STATE_2FA_PENDING,
            Constants.CXP_SUB_STATE_2FA_ACTIVE,
            Constants.CXP_SUB_STATE_RECOVERY_QUESTION_PENDING,
            Constants.CXP_SUB_STATE_CREATED,
            Constants.CXP_SUB_STATE_PASSWORD_EXPIRED,
            Constants.CXP_SUB_STATE_2FA_RESET,
            Constants.CXP_SUB_STATE_ACTIVE,
            Constants.CXP_SUB_STATE_SUSPENDED,
            Constants.CXP_SUB_STATE_LOCKED_OUT,
            Constants.CXP_SUB_STATE_DISABLED)
        .forEach(
            item -> {
              CodeValueMapping codeValueMappingSubState = new CodeValueMapping();
              codeValueMappingSubState.setCodeValue(item);
              cxpSubCodeValueMap.put(item, codeValueMappingSubState);
            });
    Arrays.asList(
            Constants.CXP_STATE_ONBOARDING,
            Constants.CXP_STATE_ACTIVE,
            Constants.CXP_STATE_INACTIVE,
            Constants.CXP_STATE_LOCKED_OUT)
        .forEach(
            item -> {
              CodeValueMapping codeValueMappingSubState = new CodeValueMapping();
              codeValueMappingSubState.setCodeValue(item);
              cxpCodeValueMap.put(item, codeValueMappingSubState);
            });
  }

  @Test
  @Ignore
  public void testSyncOktaUserProfile_whenSyncRequired_shouldCallCiamService() {
    userConfigurationDataSyncService.syncOktaUserProfile(
        "idpUserId", MockData.getUserConfiguration());
    verify(ciamService, times(1)).syncOktaUserProfile(anyString(), anyInt());
  }

  @Test
  @Ignore
  public void testSyncOktaUserProfile_whenSyncNotRequired_shouldNotCallCiamService() {
    ca.bnc.wealth.common.userconfiguration.model.UserConfiguration userConfiguration =
        MockData.getUserConfiguration();
    userConfiguration.setFirstName(null);
    userConfiguration.setLastName(null);
    userConfiguration.setPreferredLanguage(null);
    userConfigurationDataSyncService.syncOktaUserProfile("idpUserId", userConfiguration);
    verify(ciamService, times(0)).syncOktaUserProfile(anyString(), anyInt());
  }

  @Test(expected = ServiceException.class)
  @Ignore
  public void testSyncOktaUserProfile_whenSyncOktaUserFails_shouldThrowException() {
    doThrow(new ServiceException(ErrorSeverity.ERROR, "Error syncing user Okta profile"))
        .when(ciamService)
        .syncOktaUserProfile(anyString(), anyInt());
    userConfigurationDataSyncService.syncOktaUserProfile(
        "idpUserId", MockData.getUserConfiguration());
  }

  @Test
  public void testIsSyncOktaUserProfileRequired() {
    ca.bnc.wealth.common.userconfiguration.model.UserConfiguration userConfiguration =
        MockData.getUserConfiguration();
    assertTrue(userConfigurationDataSyncService.isSyncOktaUserProfileRequired(userConfiguration));

    userConfiguration.setFirstName(null);
    assertTrue(userConfigurationDataSyncService.isSyncOktaUserProfileRequired(userConfiguration));

    userConfiguration.setLastName(null);
    assertTrue(userConfigurationDataSyncService.isSyncOktaUserProfileRequired(userConfiguration));

    userConfiguration.setPreferredLanguage(null);
    assertFalse(userConfigurationDataSyncService.isSyncOktaUserProfileRequired(userConfiguration));

    userConfiguration.setIdp(null);
    assertFalse(userConfigurationDataSyncService.isSyncOktaUserProfileRequired(userConfiguration));
  }
}
