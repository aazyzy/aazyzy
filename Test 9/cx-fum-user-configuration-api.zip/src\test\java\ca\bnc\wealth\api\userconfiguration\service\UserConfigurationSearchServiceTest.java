package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.userconfiguration.model.state.UserStateEnum;
import ca.bnc.wealth.api.userconfiguration.util.MapperUtils;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.jpa.entity.EntityInterface;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import ca.bnc.wealth.common.jpa.entity.iam.UserGroup;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserConfigSearchMaterializedViewRepository;
import ca.bnc.wealth.common.jpa.specification.SpecificationWithQueryAndFilter;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearch;
import ca.bnc.wealth.common.userconfiguration.model.GroupByResponse;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class UserConfigurationSearchServiceTest {

  private UserConfigurationSearchService userConfigurationSearchService;

  @MockitoBean
  private FirmRepository firmConfigurationRepository;

  @MockitoBean private IamUserConfigurationRepository userConfigurationRepository;

  @MockitoBean private UserConfigSearchMaterializedViewRepository userConfigSearchMaterializedViewRepository;

  @MockitoBean private UserAssignmentService userAssignmentService;

  @SneakyThrows
  @Before
  public void setup() {
    userConfigurationSearchService = new UserConfigurationSearchService();
    FieldUtils.writeField(
        userConfigurationSearchService,
        "firmConfigurationRepository",
        firmConfigurationRepository,
        true);
    FieldUtils.writeField(
        userConfigurationSearchService,
        "userConfigurationRepository",
        userConfigurationRepository,
        true);
    FieldUtils.writeField(
        userConfigurationSearchService,
        "userConfigSearchMaterializedViewRepository",
        userConfigSearchMaterializedViewRepository,
        true);
    FieldUtils.writeField(
        userConfigurationSearchService,
        "userAssignmentService",
        userAssignmentService,
        true);
  }

  @SneakyThrows
  @Test
  public void searchViewForPrimaryFirm() {
    when(firmConfigurationRepository.count()).thenReturn(10l);
    when(
            userConfigSearchMaterializedViewRepository.findAll(
                any(Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl(Arrays.asList(getViewMockData())));
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("ABZZ");
    Future<Pair<Integer, List<GroupByResponse>>> future =
        userConfigurationSearchService.searchUserView(
            "idpSub", userSearch, new Firm(), new Firm(), true);
    Pair<Integer, List<GroupByResponse>> dto = future.get();
    assertEquals(1, dto.getValue().get(0).getGroupData().size());
    assertEquals("test@gmail.com", dto.getValue().get(0).getGroupData().get(0).getEmail());
    assertEquals("IAK", dto.getValue().get(0).getGroupData().get(0).getFirmId());
    assertEquals(
        "Wealth.CompassX.SecuritySteward",
        dto.getValue().get(0).getGroupData().get(0).getUserGroup());
    assertEquals("IAK", dto.getValue().get(0).getGroupKey());
  }

  @SneakyThrows
  @Test
  public void searchViewForOtherFirms() {
    when(firmConfigurationRepository.count()).thenReturn(10l);
    when(
            userConfigSearchMaterializedViewRepository.findAll(
                any(Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl(Arrays.asList(getViewMockData())));
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("ABZZ");
    Firm primaryFirm = new Firm();
    primaryFirm.setFirmId("IAK");
    Future<Pair<Integer, List<GroupByResponse>>> future =
        userConfigurationSearchService.searchUserView(
            "idpSub", userSearch, primaryFirm, new Firm(), false);
    Pair<Integer, List<GroupByResponse>> dto = future.get();
    assertEquals(1, dto.getValue().get(0).getGroupData().size());
    assertEquals("test@gmail.com", dto.getValue().get(0).getGroupData().get(0).getEmail());
    assertEquals("IAK", dto.getValue().get(0).getGroupData().get(0).getFirmId());
    assertEquals(
        "Wealth.CompassX.SecuritySteward",
        dto.getValue().get(0).getGroupData().get(0).getUserGroup());
    assertEquals("IAK", dto.getValue().get(0).getGroupKey());
  }

  @SneakyThrows
  @Test
  public void searchViewForOtherFirmsPrimaryisNBIN() {
    when(firmConfigurationRepository.count()).thenReturn(10l);
    when(
            userConfigSearchMaterializedViewRepository.findAll(
                any(Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl(Arrays.asList(getViewMockData())));
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("ABZZ");
    Firm primaryFirm = new Firm();
    primaryFirm.setFirmId("NBIN");
    Future<Pair<Integer, List<GroupByResponse>>> future =
        userConfigurationSearchService.searchUserView(
            "idpSub", userSearch, primaryFirm, new Firm(), false);
    Pair<Integer, List<GroupByResponse>> dto = future.get();
    assertEquals(1, dto.getValue().get(0).getGroupData().size());
    assertEquals("test@gmail.com", dto.getValue().get(0).getGroupData().get(0).getEmail());
    assertEquals("IAK", dto.getValue().get(0).getGroupData().get(0).getFirmId());
    assertEquals(
        "Wealth.CompassX.SecuritySteward",
        dto.getValue().get(0).getGroupData().get(0).getUserGroup());
    assertEquals("IAK", dto.getValue().get(0).getGroupKey());
  }

  @Test
  public void searchForPrimaryFirm() {
    /*when(
            firmConfigurationRepository.findFirmConfiguratoin(
                anyString(), anyString(), anyString()))
        .thenReturn(
            Arrays.asList(getMockData().getUserEntityAssignments().get(0).getResourceEntityId()));*/
    Map<String, List<EntityInterface>> firm = new HashMap<>();
    Firm f = new Firm();
    f.setFirmId("IAK");
    firm.put("idp", List.of(f));
    Map<String, List<EntityInterface>> group = new HashMap<>();
    UserGroup g = new UserGroup();
    g.setIsFirmScope(true);
    g.setName("Wealth.CompassX.SecuritySteward");
    group.put("idp", List.of(g));

    when(userAssignmentService.getUserAssignmentType(any(), any())).thenAnswer(invocationOnMock -> {
      UserAssignmentType type = invocationOnMock.getArgument(1);
      if(type == UserAssignmentType.F)
        return firm;
      else
        return group;
    });
    when(firmConfigurationRepository.count()).thenReturn(10l);
    when(
            userConfigurationRepository.findAll(
                any(Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl(Arrays.asList(getMockData())));
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("ABZZ");
    Pair<Integer, List<GroupByResponse>> dto =
        userConfigurationSearchService.search(
            "idpSub", userSearch, new Firm(), new Firm(), true);
    assertEquals(1, dto.getValue().get(0).getGroupData().size());
    assertEquals("test@gmail.com", dto.getValue().get(0).getGroupData().get(0).getEmail());
    assertEquals("IAK", dto.getValue().get(0).getGroupData().get(0).getFirmId());
    assertEquals(
        "Wealth.CompassX.SecuritySteward",
        dto.getValue().get(0).getGroupData().get(0).getUserGroup());
    assertEquals("IAK", dto.getValue().get(0).getGroupKey());
  }


  @Test
  public void searchForOtherFirms() {
    /*when(
            firmConfigurationRepository.findFirmConfiguratoin(
                anyString(), anyString(), anyString()))
        .thenReturn(
            Arrays.asList(getMockData().getUserEntityAssignments().get(0).getResourceEntityId()));*/
    Map<String, List<EntityInterface>> firm = new HashMap<>();
    Firm f = new Firm();
    f.setFirmId("IAK");
    firm.put("idp", List.of(f));
    Map<String, List<EntityInterface>> group = new HashMap<>();
    UserGroup g = new UserGroup();
    g.setIsFirmScope(true);
    g.setName("Wealth.CompassX.SecuritySteward");
    group.put("idp", List.of(g));

    when(userAssignmentService.getUserAssignmentType(any(), any())).thenAnswer(invocationOnMock -> {
      UserAssignmentType type = invocationOnMock.getArgument(1);
      if(type == UserAssignmentType.F)
        return firm;
      else
        return group;
    });
    when(firmConfigurationRepository.count()).thenReturn(10l);
    when(
            userConfigurationRepository.findAll(
                any(Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl(Arrays.asList(getMockData())));
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("ABZZ");
    Firm primaryFirm = new Firm();
    primaryFirm.setFirmId("IAK");
    Pair<Integer, List<GroupByResponse>> dto =
        userConfigurationSearchService.search(
            "idpSub", userSearch, primaryFirm, new Firm(), false);
    assertEquals(1, dto.getValue().get(0).getGroupData().size());
    assertEquals("test@gmail.com", dto.getValue().get(0).getGroupData().get(0).getEmail());
    assertEquals("IAK", dto.getValue().get(0).getGroupData().get(0).getFirmId());
    assertEquals(
        "Wealth.CompassX.SecuritySteward",
        dto.getValue().get(0).getGroupData().get(0).getUserGroup());
    assertEquals("IAK", dto.getValue().get(0).getGroupKey());
  }

  @Test
  public void searchForOtherFirmsPrimaryisNBIN() {
    /*when(
            firmConfigurationRepository.findFirmConfiguratoin(
                anyString(), anyString(), anyString()))
        .thenReturn(
            Arrays.asList(getMockData().getUserEntityAssignments().get(0).getResourceEntityId()));*/
    Map<String, List<EntityInterface>> firm = new HashMap<>();
    Firm f = new Firm();
    f.setFirmId("IAK");
    firm.put("idp", List.of(f));
    Map<String, List<EntityInterface>> group = new HashMap<>();
    UserGroup g = new UserGroup();
    g.setIsFirmScope(true);
    g.setName("Wealth.CompassX.SecuritySteward");
    group.put("idp", List.of(g));

    when(userAssignmentService.getUserAssignmentType(any(), any())).thenAnswer(invocationOnMock -> {
      UserAssignmentType type = invocationOnMock.getArgument(1);
      if(type == UserAssignmentType.F)
        return firm;
      else
        return group;
    });
    when(firmConfigurationRepository.count()).thenReturn(10l);
    when(
            userConfigurationRepository.findAll(
                any(Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl(Arrays.asList(getMockData())));
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("ABZZ");
    Firm primaryFirm = new Firm();
    primaryFirm.setFirmId("NBIN");
    Pair<Integer, List<GroupByResponse>> dto =
        userConfigurationSearchService.search(
            "idpSub", userSearch, primaryFirm, new Firm(), false);
    assertEquals(1, dto.getValue().get(0).getGroupData().size());
    assertEquals("test@gmail.com", dto.getValue().get(0).getGroupData().get(0).getEmail());
    assertEquals("IAK", dto.getValue().get(0).getGroupData().get(0).getFirmId());
    assertEquals(
        "Wealth.CompassX.SecuritySteward",
        dto.getValue().get(0).getGroupData().get(0).getUserGroup());
    assertEquals("IAK", dto.getValue().get(0).getGroupKey());
  }


  @Test
  public void genericUserSearchGroupBy()
      throws IntrospectionException, InvocationTargetException, IllegalAccessException {
    /*when(
            firmConfigurationRepository.findFirmConfiguratoin(
                anyString(), anyString(), anyString()))
        .thenReturn(
            Arrays.asList(getMockData().getUserEntityAssignments().get(0).getResourceEntityId()));*/
    Map<String, List<EntityInterface>> firm = new HashMap<>();
    Firm f = new Firm();
    f.setFirmId("IAK");
    firm.put("idp", List.of(f));
    Map<String, List<EntityInterface>> group = new HashMap<>();
    UserGroup g = new UserGroup();
    g.setIsFirmScope(true);
    g.setName("Wealth.CompassX.SecuritySteward");
    group.put("idp", List.of(g));

    when(userAssignmentService.getUserAssignmentType(any(), any())).thenAnswer(invocationOnMock -> {
      UserAssignmentType type = invocationOnMock.getArgument(1);
      if(type == UserAssignmentType.F)
        return firm;
      else
        return group;
    });
    when(firmConfigurationRepository.count()).thenReturn(10l);
    when(
            userConfigurationRepository.findAll(
                any(Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl(Arrays.asList(getMockData())));
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("ABZZ");

    Pair<Integer, List<GroupByResponse>> dto =
        userConfigurationSearchService.search(
            "idpSub", userSearch, new Firm(), new Firm(), true);
    assertEquals(1, dto.getValue().get(0).getGroupData().size());
    assertEquals("test@gmail.com", dto.getValue().get(0).getGroupData().get(0).getEmail());
    assertEquals("IAK", dto.getValue().get(0).getGroupData().get(0).getFirmId());
    assertEquals(
        "Wealth.CompassX.SecuritySteward",
        dto.getValue().get(0).getGroupData().get(0).getUserGroup());
    assertEquals("IAK", dto.getValue().get(0).getGroupKey());

    userSearch.setGroupBy(GenericSearch.GroupByEnum.PREFERRED_LANGUAGE);
    dto =
        userConfigurationSearchService.search(
            "idpSub", userSearch, new Firm(), new Firm(), true);
    assertEquals(1, dto.getValue().get(0).getGroupData().size());
    assertEquals("test@gmail.com", dto.getValue().get(0).getGroupData().get(0).getEmail());
    assertEquals("IAK", dto.getValue().get(0).getGroupData().get(0).getFirmId());
    assertEquals(
        "Wealth.CompassX.SecuritySteward",
        dto.getValue().get(0).getGroupData().get(0).getUserGroup());
    assertEquals("EN", dto.getValue().get(0).getGroupKey());

    userSearch.setGroupBy(GenericSearch.GroupByEnum.ROLE_SCOPE_TYPE);
    dto =
        userConfigurationSearchService.search(
            "idpSub", userSearch, new Firm(), new Firm(), true);
    assertEquals(1, dto.getValue().get(0).getGroupData().size());
    assertEquals("test@gmail.com", dto.getValue().get(0).getGroupData().get(0).getEmail());
    assertEquals("IAK", dto.getValue().get(0).getGroupData().get(0).getFirmId());
    assertEquals(
        "Wealth.CompassX.SecuritySteward",
        dto.getValue().get(0).getGroupData().get(0).getUserGroup());

    userSearch.setGroupBy(GenericSearch.GroupByEnum.ACTIVE);
    dto =
        userConfigurationSearchService.search(
            "idpSub", userSearch, new Firm(), new Firm(), true);
    assertEquals(1, dto.getValue().get(0).getGroupData().size());
    assertEquals("test@gmail.com", dto.getValue().get(0).getGroupData().get(0).getEmail());
    assertEquals("IAK", dto.getValue().get(0).getGroupData().get(0).getFirmId());
    assertEquals(
        "Wealth.CompassX.SecuritySteward",
        dto.getValue().get(0).getGroupData().get(0).getUserGroup());
    assertEquals("active", dto.getValue().get(0).getGroupKey());

    userSearch.setGroupBy(GenericSearch.GroupByEnum.USER_GROUPS);
    dto =
        userConfigurationSearchService.search(
            "idpSub", userSearch, new Firm(), new Firm(), true);
    assertEquals(1, dto.getValue().get(0).getGroupData().size());
    assertEquals("test@gmail.com", dto.getValue().get(0).getGroupData().get(0).getEmail());
    assertEquals("IAK", dto.getValue().get(0).getGroupData().get(0).getFirmId());
    assertEquals(
        "Wealth.CompassX.SecuritySteward",
        dto.getValue().get(0).getGroupData().get(0).getUserGroup());
    assertEquals("Wealth.CompassX.SecuritySteward", dto.getValue().get(0).getGroupKey());
  }


  @Test
  public void testIsNumber() {
    assertTrue(userConfigurationSearchService.isNumber("1"));
    assertFalse(userConfigurationSearchService.isNumber("string"));
  }

  public IamUserConfiguration getMockData() {
    IamUserConfiguration userConfiguration = new IamUserConfiguration();
    userConfiguration.setIdpSubject("idp");
    userConfiguration.setEmail("test@gmail.com");
    userConfiguration.setActive(true);
    userConfiguration.setUserConfigurationId(123l);

    userConfiguration.setPreferredLanguageType(PreferredLanguageType.EN);

    /*Firm firmConfiguration = new Firm();
    firmConfiguration.setFirmId("IAK");
    UserEntityAssignment uea = new UserEntityAssignment();
    uea.setResourceEntityId(firmConfiguration);
    userConfiguration.setUserEntityAssignments(Arrays.asList(uea));

    UserGroup userGroup = new UserGroup();
    userGroup.setName("Wealth.CompassX.SecuritySteward");
    userGroup.setIsFirmScope(true);
    UserGroupAssignment uga = new UserGroupAssignment();
    uga.setUserGroupId(userGroup);
    userConfiguration.setUserGroupAssignments(Arrays.asList(uga));

    RrCodeRange rrCodeRange = new RrCodeRange();
    rrCodeRange.setFromRrCode("ABZZ");
    rrCodeRange.setToRrCode("AB99");
    RrCodeRangeAssignment rra = new RrCodeRangeAssignment();
    rra.setRrCodeRangeId(rrCodeRange);
    userConfiguration.setRrCodeRangeAssignments(Arrays.asList(rra));*/

    return userConfiguration;
  }

  @Test
  public void testGetSpecification() {
    Map<String, List<EntityInterface>> firm = new HashMap<>();
    Firm primaryFirm = new Firm();
    primaryFirm.setFirmId("IAK");
    firm.put("idp", List.of(primaryFirm));
    Map<String, List<EntityInterface>> group = new HashMap<>();
    UserGroup g = new UserGroup();
    g.setIsFirmScope(true);
    g.setName("Wealth.CompassX.SecuritySteward");
    group.put("idp", List.of(g));

    Firm searchFirm = new Firm();
    searchFirm.setFirmId("IAVM");
    searchFirm.setFirmEntityId(2l);

    when(userAssignmentService.getUserAssignmentType(any(), any())).thenAnswer(invocationOnMock -> {
        UserAssignmentType type = invocationOnMock.getArgument(1);
        if (type == UserAssignmentType.F)
            return firm;
        else
            return group;
    });
    when(firmConfigurationRepository.count()).thenReturn(10l);
    when(
            userConfigurationRepository.findAll(
                    any(Specification.class), any(PageRequest.class)))
            .thenReturn(new PageImpl(Arrays.asList(getMockData())));
    when(firmConfigurationRepository.getAllFirmsByIdpSubject(any())).thenReturn(List.of(2l, 3l, 4l));
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("ABZZ");

    SpecificationWithQueryAndFilter specification =
            userConfigurationSearchService.getSpecification("123", userSearch, primaryFirm, searchFirm, false);
    assertNotNull(specification);
  }

  @Test
  public void testGetViewSpecification() {
    Map<String, List<EntityInterface>> firm = new HashMap<>();
    Firm primaryFirm = new Firm();
    primaryFirm.setFirmId("IAK");
    firm.put("idp", List.of(primaryFirm));
    Map<String, List<EntityInterface>> group = new HashMap<>();
    UserGroup g = new UserGroup();
    g.setIsFirmScope(true);
    g.setName("Wealth.CompassX.SecuritySteward");
    group.put("idp", List.of(g));

    Firm searchFirm = new Firm();
    searchFirm.setFirmId("IAVM");
    searchFirm.setFirmEntityId(2l);

    when(userAssignmentService.getUserAssignmentType(any(), any())).thenAnswer(invocationOnMock -> {
        UserAssignmentType type = invocationOnMock.getArgument(1);
        if (type == UserAssignmentType.F)
            return firm;
        else
            return group;
    });
    when(firmConfigurationRepository.count()).thenReturn(10l);
    when(
            userConfigurationRepository.findAll(
                    any(Specification.class), any(PageRequest.class)))
            .thenReturn(new PageImpl(Arrays.asList(getMockData())));
    when(firmConfigurationRepository.getAllFirmsByIdpSubject(any())).thenReturn(List.of(2l, 3l, 4l));
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("ABZZ");

    SpecificationWithQueryAndFilter specification =
            userConfigurationSearchService.getViewSpecification("123", userSearch, primaryFirm, searchFirm, false);
    assertNotNull(specification);
  }

  @Test
  public void testGetViewSpecification_whenPrimaryFirmIsNull() {
    SpecificationWithQueryAndFilter specification =
        userConfigurationSearchService.getViewSpecification("123", new GenericSearch(), null, null, false);
    assertNotNull(specification);
  }

  @SneakyThrows
  @Test
  @SuppressWarnings("unchecked")
  public void searchViewExcludesDecommissionedUsers() {
    when(
            userConfigSearchMaterializedViewRepository.findAll(
                any(Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl(Arrays.asList(getViewMockData())));

    userConfigurationSearchService.searchUserView("idpSub", new GenericSearch(), new Firm(), new Firm(), true).get();

    ArgumentCaptor<Specification<UserConfigSearchMaterializedView>> specCaptor =
        ArgumentCaptor.forClass(Specification.class);
    verify(userConfigSearchMaterializedViewRepository).findAll(specCaptor.capture(), any(PageRequest.class));
    Root<UserConfigSearchMaterializedView> root = mock(Root.class, RETURNS_DEEP_STUBS);
    CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class, RETURNS_DEEP_STUBS);
    Path<String> statePath = mock(Path.class);
    Expression<String> lowerState = mock(Expression.class);
    when(root.<String>get("state")).thenReturn(statePath);
    when(criteriaBuilder.lower(statePath)).thenReturn(lowerState);

    specCaptor.getValue().toPredicate(root, mock(CriteriaQuery.class), criteriaBuilder);

    verify(criteriaBuilder).notEqual(lowerState, UserStateEnum.DECOMMISSIONED.dbValue);
  }

  @Test
  @SuppressWarnings("unchecked")
  public void notDecommissionedKeepsUsersWithoutAStateAndIgnoresCase() {
    Root<UserConfigSearchMaterializedView> root = mock(Root.class);
    CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class);
    Path<String> statePath = mock(Path.class);
    Expression<String> lowerState = mock(Expression.class);
    Predicate stateIsNull = mock(Predicate.class);
    Predicate stateIsNotDecommissioned = mock(Predicate.class);
    when(root.<String>get("state")).thenReturn(statePath);
    when(criteriaBuilder.isNull(statePath)).thenReturn(stateIsNull);
    when(criteriaBuilder.lower(statePath)).thenReturn(lowerState);
    when(criteriaBuilder.notEqual(lowerState, "decommissioned")).thenReturn(stateIsNotDecommissioned);

    UserConfigurationSearchService.notDecommissioned()
        .toPredicate(root, mock(CriteriaQuery.class), criteriaBuilder);

    verify(criteriaBuilder).or(stateIsNull, stateIsNotDecommissioned);
  }

  @Test
  public void updateRrCode(){
    IamUserConfiguration iamUserConfiguration = getMockData();
    Map<String, List<EntityInterface>> userAssignments = new HashMap<>();
    IamRrCodeRange iamRrCodeRange = new IamRrCodeRange();
    iamRrCodeRange.setFromRrCode("ABCD");
    iamRrCodeRange.setToRrCode("ABCD");
    userAssignments.put(iamUserConfiguration.getIdpSubject(),List.of(iamRrCodeRange));

    when(userAssignmentService.getUserAssignmentType(anyList(), eq(UserAssignmentType.R))).thenReturn(userAssignments);
    List<UserConfiguration> lst = List.of(MapperUtils.toDto(iamUserConfiguration));
    userConfigurationSearchService.updateRrCode(List.of(iamUserConfiguration.getIdpSubject()), lst);
    assertEquals("ABCD", lst.get(0).getRrCodeRanges().get(0).getToRRCode());
  }

  private UserConfigSearchMaterializedView getViewMockData() {
    UserConfigSearchMaterializedView userConfiguration = new UserConfigSearchMaterializedView();
    userConfiguration.setId(1l);
    userConfiguration.setUserConfigurationId(1l);
    userConfiguration.setEmail("test@gmail.com");
    userConfiguration.setActive(true);
    userConfiguration.setFirmId("IAK");
    userConfiguration.setUserGroupName("Wealth.CompassX.SecuritySteward");

    userConfiguration.setPreferredLanguageType(PreferredLanguageType.EN);

    return userConfiguration;
  }
}
