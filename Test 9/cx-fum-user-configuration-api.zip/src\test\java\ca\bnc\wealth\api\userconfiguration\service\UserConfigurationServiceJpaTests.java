package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.userconfiguration.model.state.UserStateActionEnum;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.MockData;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.fum.service.ResourceServiceHelper;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.jpa.entity.iam.*;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import ca.bnc.wealth.common.userconfiguration.model.UpdateUserStatus;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class UserConfigurationServiceJpaTests {

  private UserConfigurationServiceJpa userConfigurationServiceJpa;

  @MockitoBean
  private CiamService ciamService;
  @MockitoBean
  private IamUserConfigurationRepository iamUserConfigurationRepository;
  @MockitoBean
  private FeaturePackageRepository featurePackageRepository;
  @MockitoBean
  private FeaturePackageAssignmentResourceRepository featurePackageAssignmentResourceRepository;
  @MockitoBean
  private UserService userService;
  @MockitoBean
  private UserAssignmentService userAssignmentService;
  @MockitoBean
  private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
  @MockitoBean
  private RedisCacheOperationService redisCacheOperationService;
  @MockitoBean
  private ResourceServiceHelper resourceServiceHelper;

  @MockitoBean
  private UserStateService userStateService;

  @MockitoBean
  private PersonService personService;

  @Before
  public void setup() {
    userConfigurationServiceJpa =
        new UserConfigurationServiceJpa(
            iamUserConfigurationRepository,
            featurePackageRepository,
            ciamService,
            featurePackageAssignmentResourceRepository,
            resourceServiceHelper,
            userService,
            userAssignmentService,
            namedParameterJdbcTemplate,
            redisCacheOperationService,
            userStateService,
            personService);
  }

  @Test
  public void testGetMatchedUserName() {
    // when users matched
    Map<String, Object> userMap = Map.of(
        "USER_CONFIGURATION_ID", MockData.getIamUserConfigurationEntity().getUserConfigurationId().intValue(),
        "PREFERRED_LANGUAGE", MockData.getIamUserConfigurationEntity().getPreferredLanguageType().name(),
        "CREATION_DATE", new Timestamp(System.currentTimeMillis()),
        "ACTIVE", true,
        "IDP_USER_ID", MockData.getIamUserConfigurationEntity().getIdpUserIdentifier(),
        "USERNAME", "username");
    when(namedParameterJdbcTemplate.queryForList(eq(Constants.GET_USER_BY_USERNAME_QUERY),
        any(SqlParameterSource.class))).thenReturn(List.of(userMap));
    List<String> result = userConfigurationServiceJpa.getMatchedUserName("user");
    assertEquals(1, result.size());

    // when no users matched
    when(namedParameterJdbcTemplate.queryForList(eq(Constants.GET_USER_BY_USERNAME_QUERY),
        any(SqlParameterSource.class))).thenReturn(new ArrayList<>());
    result = userConfigurationServiceJpa.getMatchedUserName("user");
    assertTrue(result.isEmpty());
  }

  @Test
  public void testIsDataAccessResourceTypeSharedWithPackageTemplate() {
    // when packageTemplate is null
    assertFalse(userConfigurationServiceJpa.isDataAccessResourceTypeSharedWithPackageTemplate(null, "firmId"));

    // when firmId is null
    assertFalse(userConfigurationServiceJpa.isDataAccessResourceTypeSharedWithPackageTemplate(1, null));

    // when only user resources is empty
    when(featurePackageAssignmentResourceRepository.findAll(any(Specification.class))).thenReturn(Collections.emptyList());
    assertFalse(userConfigurationServiceJpa.isDataAccessResourceTypeSharedWithPackageTemplate(1, "firmId"));

    // when only firm resources is empty
    Resource resource = new Resource();
    resource.setName("firm_level_access");
    resource.setType("data_access");

    PackageTemplateAssignmentResource ptar = new PackageTemplateAssignmentResource();
    ptar.setResource(resource);

    FeaturePackageAssignmentResource fpar =  new FeaturePackageAssignmentResource();
    fpar.setPackageTemplateAssignmentResource(ptar);

    when(featurePackageAssignmentResourceRepository.findAll(any(Specification.class))).thenReturn(List.of(fpar));
    when(resourceServiceHelper.getFirmResources(any(), anyBoolean())).thenReturn(Collections.emptyList());
    assertFalse(userConfigurationServiceJpa.isDataAccessResourceTypeSharedWithPackageTemplate(1, "firmId"));

    // when user and firm resources are valid
    when(resourceServiceHelper.getFirmResources(any(), anyBoolean())).thenReturn(List.of(resource));
    assertTrue(userConfigurationServiceJpa.isDataAccessResourceTypeSharedWithPackageTemplate(1, "firmId"));
  }

  @Test
  public void testIsDataAccessResourceTypeSharedBetweenUserAndFirm() {
    // when only user resources is empty
    when(resourceServiceHelper.getUserResources(any())).thenReturn(Collections.emptyList());
    assertFalse(userConfigurationServiceJpa.isDataAccessResourceTypeSharedBetweenUserAndFirm("idpSubject", "firmId"));

    // when only firm resources is empty
    Resource resource = new Resource();
    resource.setName("firm_level_access");
    resource.setType("data_access");

    when(resourceServiceHelper.getUserResources(any())).thenReturn(List.of(resource));
    when(resourceServiceHelper.getFirmResources(any(), anyBoolean())).thenReturn(Collections.emptyList());
    assertFalse(userConfigurationServiceJpa.isDataAccessResourceTypeSharedBetweenUserAndFirm("idpSubject", "firmId"));

    // when user and firm resources are valid
    when(resourceServiceHelper.getFirmResources(any(), anyBoolean())).thenReturn(List.of(resource));
    assertTrue(userConfigurationServiceJpa.isDataAccessResourceTypeSharedBetweenUserAndFirm("idpSubject", "firmId"));
  }

  @Test
  public void testApplyFirmAccessLevelCheck() {
    ca.bnc.wealth.common.userconfiguration.model.UserConfiguration currentUserConfiguration = new ca.bnc.wealth.common.userconfiguration.model.UserConfiguration();
    currentUserConfiguration.setIdpSubject("idpSubject");
    currentUserConfiguration.setFirmId("firmId");
    // when access not shared between firm and user
    userConfigurationServiceJpa.applyFirmAccessLevelCheck( currentUserConfiguration, "requestedBy");
    verify(userAssignmentService, times(0)).assignRrRangesSp(any(), anyString(), any(), any());

    // when access is shared between firm and user
    Resource resource = new Resource();
    resource.setName("firm_level_access");
    resource.setType("data_access");

    when(resourceServiceHelper.getUserResources(any())).thenReturn(List.of(resource));
    when(resourceServiceHelper.getFirmResources(any(), anyBoolean())).thenReturn(List.of(resource));

    userConfigurationServiceJpa.applyFirmAccessLevelCheck(currentUserConfiguration, "requestedBy");
    verify(userAssignmentService, times(1)).assignRrRangesSp(any(), anyString(), any(), any());
  }

  @Test
  public void testUpdateUserConfigState_whenUserStateActionIsActive_shouldActivateUser() {
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(
        Optional.ofNullable(MockData.getIamUserConfigurationEntity()));
    try {
      userConfigurationServiceJpa.updateUserConfigState(123, UserStateActionEnum.ACTIVE);
    } catch(Exception e) {
      fail("This test should not fail.");
    }
  }

  @Test
  public void testUpdateUserConfigState_whenUserStateActionIsSuspended_shouldSuspendUser() {
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(
            Optional.ofNullable(MockData.getIamUserConfigurationEntity()));
    try {
      userConfigurationServiceJpa.updateUserConfigState(123, UserStateActionEnum.SUSPENDED);
    } catch(Exception e) {
      fail("This test should not fail.");
    }
  }

  @Test(expected = FumNotFoundException.class)
  public void testUpdateUserConfigState_whenUserConfigurationIsNull_shouldThrowFumNotFoundException() {
      userConfigurationServiceJpa.updateUserConfigState(123, UserStateActionEnum.SUSPENDED);
  }

  @Test(expected = FumValidationException.class)
  public void testUpdateUserConfigState_whenUserStateActionIsBlank_shouldThrowFumValidationException() {
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(
            Optional.ofNullable(MockData.getIamUserConfigurationEntity()));
      userConfigurationServiceJpa.updateUserConfigState(123, UserStateActionEnum.BLANK);
  }

  @Test(expected = FumNotFoundException.class)
  public void testUpdateUserStatus_whenIamUserConfigurationIsNull_shouldThrowFumNotFoundException() {
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(
            Optional.ofNullable(null));
    userConfigurationServiceJpa.updateUserStatus(123, UpdateUserStatus.StatusEnum.ACTIVE);
  }

  @Test
  public void testUpdateUserStatus_whenUserStatusIsActive_shouldReturn() {
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(
            Optional.ofNullable(iamUserConfiguration));
    userConfigurationServiceJpa.updateUserStatus(123, UpdateUserStatus.StatusEnum.ACTIVE);
    assertEquals(true, iamUserConfiguration.getActive());
  }

  @Test
  public void testUpdateUserStatus_whenUserStatusIsInactive_shouldSetIamUserConfigurationActiveFalse() {
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(
            Optional.ofNullable(iamUserConfiguration));
    userConfigurationServiceJpa.updateUserStatus(123, UpdateUserStatus.StatusEnum.INACTIVE);
    assertEquals(false,iamUserConfiguration.getActive());
  }

  @Test
  public void testUpdateUserConfigState_whenUserStateActionIsSuspend_shouldSuspendUser() {
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(
            Optional.ofNullable(MockData.getIamUserConfigurationEntity()));
    try {
      userConfigurationServiceJpa.updateUserConfigState(123, UserStateActionEnum.SUSPENDED);
    } catch(Exception e) {
      fail("This test should not fail.");
    }
  }

  @Test(expected = FumNotFoundException.class)
  public void testUpdateUserConfigState_whenIamUserConfigurationIsNull_shouldThrowFumNotFoundException() {
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(
            Optional.ofNullable(null));
    userConfigurationServiceJpa.updateUserConfigState(1, UserStateActionEnum.ACTIVE);
  }

  @Test(expected = FumValidationException.class)
  public void testUpdateUserConfigState_whenUserStateActionIsNotActiveOrSuspend_shouldThrowFumNotFoundException() {
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(
            Optional.ofNullable(MockData.getIamUserConfigurationEntity()));
    userConfigurationServiceJpa.updateUserConfigState(1, UserStateActionEnum.LOCKED);
  }

  @Test
  public void testFindFeaturePackage() {
    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setFeaturePackageId(123);
    when(featurePackageRepository.findById(anyLong())).thenReturn(Optional.ofNullable(featurePackage));
    assertEquals(Optional.ofNullable(featurePackage), userConfigurationServiceJpa.findFeaturePackage(123));
  }

  @Test
  public void testGetUserByFirstNameLastNameAndEmail() {
    when(iamUserConfigurationRepository.findFirstByEmailIgnoreCase(any())).thenReturn(Optional.of(MockData.getIamUserConfigurationEntity()));
    assertNotNull(userConfigurationServiceJpa.getUserByEmail("email"));
  }

  @Test
  public void testGetUserByIdpSubject() {
    when(iamUserConfigurationRepository.findFirstByIdpSubject(any())).thenReturn(Optional.of(MockData.getIamUserConfigurationEntity()));
    assertNotNull(userConfigurationServiceJpa.getUserByIdpSubject(MockData.IDP_USER_SUB));
  }

  @Test
  public void deleteUserConfiguration_removesPersonLinkThenAssignmentsThenUserConfiguration() {
    IamUserConfiguration iamUserConfiguration = new IamUserConfiguration();
    iamUserConfiguration.setUserConfigurationId(1234L);

    userConfigurationServiceJpa.deleteUserConfiguration(iamUserConfiguration);

    // The PERSON_USER link must be removed before deleting the USER_CONFIGURATION row, otherwise
    // fk_person_user_user_configuration blocks the delete (SQLState 23503).
    InOrder inOrder =
        inOrder(personService, userAssignmentService, iamUserConfigurationRepository);
    inOrder.verify(personService).removePersonLink(iamUserConfiguration);
    inOrder.verify(userAssignmentService).deleteUserAssignments(iamUserConfiguration);
    inOrder.verify(iamUserConfigurationRepository).delete(iamUserConfiguration);
  }
}
