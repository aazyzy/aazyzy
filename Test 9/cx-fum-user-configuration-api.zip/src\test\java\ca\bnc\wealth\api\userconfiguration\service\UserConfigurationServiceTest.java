package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.anyBoolean;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.security.impl.TokenDecoderImpl;
import ca.bnc.wealth.api.authorization.security.token.TokenValidatorConfigLoader;
import ca.bnc.wealth.api.authorization.security.token.TokenValidatorProperty;
import ca.bnc.wealth.api.authorization.security.util.JwtUtil;
import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.userconfiguration.dao.UserConfigurationDao;
import ca.bnc.wealth.api.userconfiguration.kafka.UserConfigEventProducerService;
import ca.bnc.wealth.api.userconfiguration.model.FeaturePackageCreateResponse;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.MockData;
import ca.bnc.wealth.common.authorization.model.GetFeaturePackage;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.kafka.model.EventMessages;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.UserAssignment;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserIdentity;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.assertj.core.util.Arrays;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.MockedConstruction;
import org.mockito.Mockito;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletWebRequest;

@RunWith(SpringRunner.class)
public class UserConfigurationServiceTest {

  private static final String STUB_BEARER_TOKEN = "stub-" + java.util.UUID.randomUUID();

  private UserConfigurationService userConfigurationService;

  @MockitoBean private UserConfigurationDao userConfigurationDao;
  @MockitoBean private CiamService ciamService;
  @MockitoBean private UserConfigurationServiceJpa userConfigurationServiceJpa;
  @MockitoBean private UserConfigEventProducerService userConfigEventProducerService;
  @MockitoBean private UserConfigValidationService userConfigValidationService;
  @MockitoBean private FirmRepository firmRepository;
  @MockitoBean private UserAssignmentService userAssignmentService;
  @MockitoBean private SystemTokenFactory systemTokenFactory;
  @MockitoBean private AuthorizationClient authorizationClient;
  @MockitoBean private UserService userService;

  @MockitoBean private UserStateService userStateService;
  @MockitoBean private UserValidationService userValidationService;
  @MockitoBean private RedisCacheOperationService redisCacheOperationService;
  @MockitoBean private UserConfigurationDataSyncService userConfigurationDataSyncService;

  @MockitoBean private TokenValidatorConfigLoader tokenConfig;
  @MockitoBean private UserConfigSearchMaterializedRefreshService userConfigSearchMaterializedRefreshService;
  @MockitoBean private AuditLogService auditLogService;
  @MockitoBean private JwtUtil jwtUtil;

  @Before
  public void setup() {
    userConfigurationService =
        new UserConfigurationService(
            userConfigurationDao,
            ciamService,
            userConfigurationServiceJpa,
            userConfigEventProducerService,
            userConfigValidationService,
            firmRepository,
            systemTokenFactory,
            authorizationClient,
            userService,
            userStateService,
            userValidationService,
            redisCacheOperationService,
            userConfigurationDataSyncService,
            userAssignmentService,
            tokenConfig,
            userConfigSearchMaterializedRefreshService,
            auditLogService,
            jwtUtil);

    RequestAttributes mockRequest = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(mockRequest);
  }

  @Test
  public void test_updateUserConfiguration() {
    // NBIN users
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(userConfiguration);
    when(userService.getUserConfiguration(anyString())).thenReturn(userConfiguration);
    userConfigurationService.updateUserConfiguration(1, userConfiguration, "nbin", "updateRequestedBy");
    verify(userConfigEventProducerService, times(1)).publishMessage(any());
    verify(redisCacheOperationService, times(1)).deleteUserConfigurationCacheNoException(any());

    clearInvocations(userConfigEventProducerService, redisCacheOperationService);

    // SSO users
    userConfigurationService.updateUserConfiguration(1, userConfiguration, "indall", "updateRequestedBy");
    verify(userConfigEventProducerService, times(1)).publishMessage(any());
    verify(redisCacheOperationService, times(1)).deleteUserConfigurationCacheNoException(any());
  }

  @Test
  public void test_updateUserConfigIdentityForExternalSSOUsers() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();

    when(userService.getUserConfigurationByIdOrName(any())).thenReturn(null);
    userConfigurationService.updateUserConfigIdentityForExternalSSOUsers("idpSubject", 1, userConfiguration);
    verify(redisCacheOperationService, times(0)).deleteUserConfigurationCache(any());

    when(userService.getUserConfigurationByIdOrName(any())).thenReturn(userConfiguration);
    userConfigurationService.updateUserConfigIdentityForExternalSSOUsers("idpSubject", 1, userConfiguration);
    verify(userService, times(0)).suspendOktaProfileByIdpSubject(any());
    verify(userConfigSearchMaterializedRefreshService, times(1)).refreshUserSearchMaterializedView(any(), anyBoolean());

    userConfiguration.setIdp("indall");
    userConfigurationService.updateUserConfigIdentityForExternalSSOUsers("idpSubject", 1, userConfiguration);
    verify(userService, times(1)).suspendOktaProfileByIdpSubject(any());
  }

  @Test
  public void test_updateUserConfigAccessForExternalSSOUsers() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setFeaturePackage(MockData.getFeaturePackage());

    // When package template id is provided
    when(userService.getUserConfigurationByIdOrName(any())).thenReturn(userConfiguration);
    when(userService.requestHasFeaturePackage(any())).thenReturn(true);
    userConfigurationService.updateUserConfigAccessForExternalSSOUsers("idpSubject", 1, userConfiguration);
    verify(userConfigEventProducerService, times(1)).publishMessage(any());

    // When package template name is provided
    clearInvocations(userConfigEventProducerService);
    userConfiguration.getFeaturePackage().setPackageName("TestPackage");
    userConfiguration.getFeaturePackage().setPackageTemplateId(null);
    when(userService.getUserConfigurationByIdOrName(any())).thenReturn(userConfiguration);
    userConfigurationService.updateUserConfigAccessForExternalSSOUsers("idpSubject", 1, userConfiguration);
    verify(userConfigEventProducerService, times(1)).publishMessage(any());
  }

  @Test
  public void test_updateRRCodeFirmLevelAccess() {
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpSubject("idp");
    userConfiguration.setRrCodes(List.of("1234"));
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(true);
    try {
      userConfigurationService.addRrCode(userConfiguration, "idp", "idp");
    } catch (Exception e) {
      fail();
    }
  }

  @Test
  public void test_updateRRCodeWithoutFirmLevelAccess() {
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setRrCodes(List.of("1234"));
    RRCodeRange rrCodeRange = new RRCodeRange();
    userConfiguration.setRrCodeRanges(List.of(rrCodeRange));
    try {
      userConfigurationService.addRrCode(userConfiguration, "idp", "idp");
    } catch (Exception e) {
      fail();
    }
  }

  @Test
  public void test_addRrCode_shouldThrow_whenRestrictClientDataAccessAndFirmLevelAccess() {
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpSubject("idp");
    doThrow(new FumValidationException(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS,
        Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS_MESSAGE))
        .when(userService).validateRestrictClientDataAccess("idp", userConfiguration);
    try {
      userConfigurationService.addRrCode(userConfiguration, "idp", "idp");
      fail("Expected FumValidationException");
    } catch (FumValidationException e) {
      assertEquals(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS, e.getCode());
    }
  }

  @Test
  public void test_addRrCode_shouldThrow_whenRestrictClientDataAccessAndRrCodesProvided() {
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpSubject("idp");
    userConfiguration.setRrCodes(List.of("1234"));
    doThrow(new FumValidationException(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE,
        Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE_MESSAGE))
        .when(userService).validateRestrictClientDataAccess("idp", userConfiguration);
    try {
      userConfigurationService.addRrCode(userConfiguration, "idp", "idp");
      fail("Expected FumValidationException");
    } catch (FumValidationException e) {
      assertEquals(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE, e.getCode());
    }
  }

  @Test
  public void test_addRrCode_shouldSucceed_whenNoRestrictClientDataAccess() {
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpSubject("idp");
    userConfiguration.setRrCodes(List.of("1234"));
    // validateRestrictClientDataAccess does nothing by default (mock void method)
    try {
      userConfigurationService.addRrCode(userConfiguration, "idp", "idp");
    } catch (Exception e) {
      fail();
    }
  }

  @Test
  public void test_updateUserRrCodeRangesBySubjectId() {
    when(userService.getUserConfiguration(anyString())).thenReturn(MockData.getUserConfiguration());

    userConfigurationService.updateUserRrCodeRangesBySubjectId("idp", List.of(new RRCodeRange()));
    verify(userConfigEventProducerService, times(1)).publishMessage(any());
  }

  @Test
  public void test_updateUserConfigurationByUserId() {
    UserConfiguration user = MockData.getUserConfiguration();
    user.setFeaturePackage(MockData.getFeaturePackage());
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(user);
    when(userService.requestHasFeaturePackage(any())).thenReturn(true);
    userConfigurationService.updateUserConfigurationByUserId("idp", 1, user);
    verify(userConfigValidationService, times(1)).validateAndSetActivationDate(any());
    verify(userConfigEventProducerService, times(1)).publishMessage(any());

    // When package template name is provided
    clearInvocations(userConfigValidationService, userConfigEventProducerService);
    user.getFeaturePackage().setPackageName("TestPackage");
    user.getFeaturePackage().setPackageTemplateId(null);
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(user);
    userConfigurationService.updateUserConfigurationByUserId("idp", 1, user);
    verify(userConfigEventProducerService, times(1)).publishMessage(any());

    // When idp is not nbin
    clearInvocations(userConfigValidationService, userConfigEventProducerService);
    user.setIdp("indall");
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(user);
    userConfigurationService.updateUserConfigurationByUserId("idp", 1, user);
    verify(userConfigEventProducerService, times(1)).publishMessage(any());
  }

  @Test
  public void test_updateUserConfigurationByUserId_whenEmployeeIdpAndRequestIdpBlank_backfillsIdpFromCurrent() {
    // Employee (IAMi) users have no Okta profile, so the request body may omit idp and idpUserId.
    // The authoritative current configuration's idp must be backfilled before validation so the
    // user is routed through the non-Nbin update path and not rejected for a null idpUserId.
    UserConfiguration currentUser = MockData.getUserConfiguration();
    currentUser.setIdp(Constants.EMPLOYEE_IDP);

    UserConfiguration requestUser = MockData.getUserConfiguration();
    requestUser.setIdp(null);
    requestUser.setIdpUserId(null);

    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(currentUser);

    userConfigurationService.updateUserConfigurationByUserId("idpSubject", 1, requestUser);

    assertEquals(Constants.EMPLOYEE_IDP, requestUser.getIdp());
    verify(userConfigValidationService, times(1)).validateUserUpdateForNonNbin(requestUser);
    verify(userService, times(1)).updateUserForNonNbin(requestUser, 1, "idpSubject", null);
  }

  @Test
  public void
      test_updateUserConfigurationByUserId_whenEmployeeIdpWithFeaturePackage_createsAndAssignsFeaturePackage() {
    // Employee (IAMi) users have no Okta profile, but their feature package (features and
    // resources) is owned by the authorization service. On update the package must be created and
    // the response handed to updateUserForNonNbin so the assignment is persisted in the same
    // transaction as the identity update.
    UserConfiguration currentUser = MockData.getUserConfiguration();
    currentUser.setIdp(Constants.EMPLOYEE_IDP);

    UserConfiguration requestUser = MockData.getUserConfiguration();
    requestUser.setIdp(Constants.EMPLOYEE_IDP);
    requestUser.setFeaturePackage(MockData.getFeaturePackage());

    FeaturePackageCreateResponse featurePackageCreateResponse =
        MockData.getFeaturePackageCreateResponse();

    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(currentUser);
    when(userService.requestHasFeaturePackage(requestUser)).thenReturn(true);
    when(authorizationClient.createFeaturePackage(any(), any()))
        .thenReturn(featurePackageCreateResponse);

    userConfigurationService.updateUserConfigurationByUserId("idpSubject", 1, requestUser);

    verify(authorizationClient, times(1))
        .createFeaturePackage(any(), eq(requestUser.getFeaturePackage()));
    verify(userService, times(1))
        .updateUserForNonNbin(requestUser, 1, "idpSubject", featurePackageCreateResponse);
    assertTrue(requestUser.getAccessProfileSet());
  }

  @Test
  public void test_updateUserConfigurationByUserId_alwaysUsesCurrentIdp_ignoringRequestBodyIdp() {
    // An external (non-employee) user must not bypass idpUserId validation by spoofing the employee
    // idp in the request body. idp does not change on update, so the authoritative idp from the
    // current configuration always wins regardless of what the request body carries.
    UserConfiguration currentUser = MockData.getUserConfiguration();
    currentUser.setIdp("indall");

    UserConfiguration requestUser = MockData.getUserConfiguration();
    requestUser.setIdp(Constants.EMPLOYEE_IDP);

    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(currentUser);

    userConfigurationService.updateUserConfigurationByUserId("idpSubject", 1, requestUser);

    assertEquals("indall", requestUser.getIdp());
    verify(userConfigValidationService, times(1)).validateUserUpdateForNonNbin(requestUser);
  }

  @Test
  public void test_updateUserConfigurationByUserId_whenNonNbinAndBlankR2Id_publishesBlankR2Tag() {
    // A blank compassR2Id is the unlink signal the downstream CX-R2 adaptor consumes, and is the
    // same payload the dedicated unlink endpoint produces. Validation must let it through.
    UserConfiguration currentUser = MockData.getUserConfiguration();
    currentUser.setIdp(Constants.EMPLOYEE_IDP);

    UserConfiguration requestUser = MockData.getUserConfiguration();
    requestUser.setIdp(Constants.EMPLOYEE_IDP);
    requestUser.setCompassR2Id("");

    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(currentUser);

    userConfigurationService.updateUserConfigurationByUserId("idpSubject", 1, requestUser);

    ArgumentCaptor<EventMessages> eventCaptor = ArgumentCaptor.forClass(EventMessages.class);
    verify(userConfigEventProducerService, times(1)).publishMessage(eventCaptor.capture());
    assertEquals("", eventCaptor.getValue().getHeader().getTags().getCompassR2Id());
  }

  @Test
  public void test_cloneProfile() {
    UserConfiguration user = MockData.getUserConfiguration();
    UserConfiguration clone = new UserConfiguration();
    clone.setSourceIdpSubject("1234");

    when(userService.getUserConfigurationWithRrCodeById(anyInt())).thenReturn(user);
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(user);
    when(userService.getCompassR2Id(anyString())).thenReturn("test-r2");
    when(userService.getSecureZoneId(anyString())).thenReturn(Arrays.array("test-secure-zone"));

    UserAssignment assignment = new UserAssignment();
    assignment.setAssigneeId(1);
    when(userAssignmentService.getUserAssignments(anyString(), anyList(), anyBoolean()))
        .thenReturn(List.of(assignment));
    when(systemTokenFactory.getBearerToken(anyString())).thenReturn(STUB_BEARER_TOKEN);

    GetFeaturePackage featurePackage = new GetFeaturePackage();
    featurePackage.setName("FeaturePackage");
    featurePackage.setPackageTemplateId(1L);
    featurePackage.setDetails(Collections.emptyList());
    when(authorizationClient.getFeaturePackage(anyString(), anyInt())).thenReturn(featurePackage);

    userConfigurationService.cloneProfile(clone);
    assert (clone.getUsername() == null);
    assert (clone.getIdpSubject() == null);
    assert (clone.getFirstName().equals(user.getFirstName()));
    assert (!clone.getRrCodeRanges().isEmpty());
  }

  @Test
  public void test_cloneProfileFeatureAssignment() {
    UserConfiguration user = MockData.getUserConfiguration();
    UserConfiguration clone = new UserConfiguration();
    clone.setSourceIdpSubject("1234");

    when(userService.getUserConfigurationWithRrCodeById(anyInt())).thenReturn(user);
    when(userService.getUserConfigurationByIdOrName(anyString())).thenReturn(user);
    when(userService.getCompassR2Id(anyString())).thenReturn("test-r2");
    when(userService.getSecureZoneId(anyString())).thenReturn(Arrays.array("test-secure-zone"));

    UserAssignment assignment = new UserAssignment();
    assignment.setAssigneeId(1);
    when(userAssignmentService.getUserAssignments(anyString(), anyList(), anyBoolean()))
        .thenReturn(List.of(assignment));
    when(systemTokenFactory.getBearerToken(anyString())).thenReturn(STUB_BEARER_TOKEN);

    GetFeaturePackage featurePackage = new GetFeaturePackage();
    featurePackage.setName("FeaturePackage");
    featurePackage.setPackageTemplateId(1L);
    ca.bnc.wealth.common.authorization.model.FeaturePackageDetails details =
        new ca.bnc.wealth.common.authorization.model.FeaturePackageDetails();
    details.setSelected(true);

    ca.bnc.wealth.common.authorization.model.Resource resource =
        new ca.bnc.wealth.common.authorization.model.Resource();
    resource.setName("test-resource");
    resource.setRestriction(true);
    details.setResource(resource);
    featurePackage.setDetails(List.of(details));
    when(authorizationClient.getFeaturePackage(anyString(), anyInt())).thenReturn(featurePackage);

    userConfigurationService.cloneProfile(clone);
    assert (clone.getFeaturePackage() != null);
    assert (!clone.getFeaturePackage().getModuleOverrides().isEmpty());
  }

  @Test
  public void test_cloneProfile_whenError() {
    UserConfiguration user = MockData.getUserConfiguration();

    when(userService.getUserConfigurationByIdOrName(any())).thenReturn(null);
    assertThrows(IllegalArgumentException.class,
        () -> userConfigurationService.cloneProfile(user),
        "Should throw IllegalArgumentException");

    when(userService.getUserConfigurationWithRrCodeById(any())).thenThrow(new RuntimeException("error"));
    assertThrows(IllegalArgumentException.class,
        () -> userConfigurationService.cloneProfile(user),
        "Should throw IllegalArgumentException");
  }

  @Test
  public void test_publishUserUpdateMessage_whenR2IdIsPresent() {
    UserConfiguration user = MockData.getUserConfiguration();
    user.setCompassR2Id("r2Id");
    userConfigurationService.publishUserUpdateMessage(user.getUserConfigurationId(), user);
    verify(userConfigEventProducerService, times(1)).publishMessage(any());
  }

  @Test
  public void test_publishUserUpdateMessage_whenR2IdIsNotPresent() {
    UserConfiguration user = MockData.getUserConfiguration();
    user.setCompassR2Id(null);
    userConfigurationService.publishUserUpdateMessage(user.getUserConfigurationId(), user);
    verify(userConfigEventProducerService, times(1)).publishMessage(any());
  }

  @Test
  public void test_linkCompassR2Id_setsIdAndPublishesEvent() {
    UserConfiguration user = MockData.getUserConfiguration();
    when(userService.getUserConfigurationByIdOrName("24718")).thenReturn(user);
    userConfigurationService.linkCompassR2Id("24718", "r2Id");
    assertEquals("r2Id", user.getCompassR2Id());
    verify(userConfigEventProducerService, times(1)).publishMessage(any());
  }

  @Test
  public void test_linkCompassR2Id_whenBlankR2Id_throwsValidationAndDoesNotPublish() {
    assertThrows(
        FumValidationException.class,
        () -> userConfigurationService.linkCompassR2Id("24718", "  "));
    verify(userConfigEventProducerService, times(0)).publishMessage(any());
  }

  @Test
  public void test_unlinkCompassR2Id_clearsIdAndPublishesEvent() {
    UserConfiguration user = MockData.getUserConfiguration();
    user.setCompassR2Id("r2Id");
    when(userService.getUserConfigurationByIdOrName("24718")).thenReturn(user);
    userConfigurationService.unlinkCompassR2Id("24718");
    assertNull(user.getCompassR2Id());
    verify(userConfigEventProducerService, times(1)).publishMessage(any());
  }

  @Test
  public void test_linkCompassR2Id_whenUserNotFound_throwsNotFound() {
    when(userService.getUserConfigurationByIdOrName("999")).thenReturn(null);
    assertThrows(
        FumNotFoundException.class,
        () -> userConfigurationService.linkCompassR2Id("999", "r2Id"));
    verify(userConfigEventProducerService, times(0)).publishMessage(any());
  }

  @Test
  public void test_createUserConfig() {
    UserConfiguration user = MockData.getUserConfiguration();
    user.setFeaturePackage(MockData.getFeaturePackage());
    when(userService.saveNewUserConfiguration(any(), any())).thenReturn(MockData.getIamUserConfigurationEntity());
    when(firmRepository.findByFirmId(any())).thenReturn(MockData.getFirmEntity());
    when(authorizationClient.createFeaturePackage(any(), any())).thenReturn(MockData.getFeaturePackageCreateResponse());
    when(userService.getUserConfigurationFromTableByUserId(anyLong())).thenReturn(user);
    when(userService.getUserIdpUserIdentifierWithRefresh(any())).thenReturn("idpUserIdentifier");
    when(userConfigurationServiceJpa.getIamUserConfiguration(any())).thenReturn(MockData.getIamUserConfigurationEntity());
    doReturn(MockData.getUserAssignmentUserGroupEntityList())
        .when(userAssignmentService)
        .getUserAssignment(anyString(), eq(UserAssignmentType.G));
    assertNotNull(userConfigurationService.createUserConfig(user, "idpSubject").getUserConfigurationId());

    when(userConfigValidationService.validateUserConfigurationCreation(any(), anyBoolean())).thenReturn(Map.of("key", "value"));
    assertThrows(
        FumServiceException.class,
        () -> userConfigurationService.createUserConfig(user, "idpSubject"),
        "Should throw FumServiceException");

    when(userConfigValidationService.validateUserConfigurationCreation(any(), anyBoolean())).thenThrow(new RuntimeException("error"));
    assertThrows(
        FumServiceException.class,
        () -> userConfigurationService.createUserConfig(user, "idpSubject"),
        "Should throw FumServiceException");
  }

  @Test
  public void testValidateAndFetchIdTokenClaims_selectsValidatorMatchingIdTokenIssuer() {
    // The Id Token is Employee-issued, so the matching "employee" validator (not "okta") must be
    // selected and its JWKS keyUrl used to build the decoder.
    String idToken = "id-token";
    String employeeIssuer = "https://emp-nbc.oktapreview.com/oauth2/aust4o2r54FVc1IGl0h7";
    String employeeKeyUrl = "https://emp-nbc.oktapreview.com/oauth2/aust4o2r54FVc1IGl0h7/v1/keys";
    UserIdentity userIdentity = new UserIdentity();
    userIdentity.setIdToken(idToken);
    when(jwtUtil.getIssuer(idToken)).thenReturn(employeeIssuer);
    when(tokenConfig.getTokenValidators())
        .thenReturn(
            Map.of(
                "okta",
                new TokenValidatorProperty(
                    "https://auth-pp.nbin.ca/oauth2/aussg4wyd2HZEBGR30h7/v1/keys",
                    "https://auth-pp.nbin.ca/oauth2/aussg4wyd2HZEBGR30h7",
                    new String[] {"oktaKey"}),
                "employee",
                new TokenValidatorProperty(
                    employeeKeyUrl, employeeIssuer, new String[] {"employeeKey"})));

    List<Object> capturedDecoderArgs = new ArrayList<>();
    try (MockedConstruction<TokenDecoderImpl> mockedDecoder =
        Mockito.mockConstruction(
            TokenDecoderImpl.class,
            (mock, context) -> capturedDecoderArgs.addAll(context.arguments()))) {

      // The mocked decoder returns null from getDecoder(), so decoding fails and the method throws
      // IllegalArgumentException. We only care that the decoder was built for the matching validator.
      assertThrows(
          IllegalArgumentException.class,
          () -> userConfigurationService.validateAndFetchIdTokenClaims(userIdentity));

      assertEquals(1, mockedDecoder.constructed().size());
      // First constructor argument is the JWKS keyUrl of the selected validator.
      assertEquals(employeeKeyUrl, capturedDecoderArgs.get(0));
    }
    verify(jwtUtil, times(1)).getIssuer(idToken);
  }

  @Test
  public void testValidateAndFetchIdTokenClaims_whenNoValidatorMatchesIssuer_throwsWithIssuerSpecificMessage() {
    String idToken = "id-token";
    String unknownIssuer = "https://unknown-issuer";
    UserIdentity userIdentity = new UserIdentity();
    userIdentity.setIdToken(idToken);
    when(jwtUtil.getIssuer(idToken)).thenReturn(unknownIssuer);
    when(tokenConfig.getTokenValidators())
        .thenReturn(
            Map.of(
                "okta",
                new TokenValidatorProperty(
                    "https://auth-pp.nbin.ca/oauth2/aussg4wyd2HZEBGR30h7/v1/keys",
                    "https://auth-pp.nbin.ca/oauth2/aussg4wyd2HZEBGR30h7",
                    new String[] {"oktaKey"})));

    IllegalArgumentException exception =
        assertThrows(
            IllegalArgumentException.class,
            () -> userConfigurationService.validateAndFetchIdTokenClaims(userIdentity));
    assertTrue(
        exception.getMessage().contains("No token validator configured for the Id Token issuer"));
    assertTrue(exception.getMessage().contains(unknownIssuer));
  }

  @Test(expected = FumServiceException.class)
  public void testCreateUser_whenCreateFeaturePackageFails_shouldThrowException() {
    UserConfiguration user = MockData.getUserConfiguration();
    user.setFeaturePackage(MockData.getFeaturePackage());
    user.setOssProxyId(null);

    when(userService.saveNewUserConfiguration(any(), any())).thenReturn(MockData.getIamUserConfigurationEntity());
    when(firmRepository.findByFirmId(any())).thenReturn(MockData.getFirmEntity());
    when(authorizationClient.createFeaturePackage(any(), any())).thenReturn(null);
    userConfigurationService.createUserConfig(user, "idpSubject");
  }

  @Test(expected = FumServiceException.class)
  public void testCreateUser_whenCreateFeaturePackageNull_shouldThrowException() {
    UserConfiguration user = MockData.getUserConfiguration();
    user.setFeaturePackage(null);

    when(userService.saveNewUserConfiguration(any(), any())).thenReturn(MockData.getIamUserConfigurationEntity());
    when(firmRepository.findByFirmId(any())).thenReturn(MockData.getFirmEntity());

    userConfigurationService.createUserConfig(user, "idpSubject");
  }

  @Test(expected = FumServiceException.class)
  public void testCreateUser_whenUnexpectedError_shouldThrowException() {
    UserConfiguration user = MockData.getUserConfiguration();
    user.setFeaturePackage(MockData.getFeaturePackage());

    when(userService.saveNewUserConfiguration(any(), any())).thenReturn(MockData.getIamUserConfigurationEntity());
    when(firmRepository.findByFirmId(any())).thenReturn(MockData.getFirmEntity());
    when(authorizationClient.createFeaturePackage(any(), any())).thenThrow(new RuntimeException("error"));

    userConfigurationService.createUserConfig(user, "idpSubject");
  }

  @Test
  public void testCreateUser_whenValidUser_shouldCreateUser() {
    UserConfiguration user = MockData.getUserConfiguration();
    user.setFeaturePackage(MockData.getFeaturePackage());

    when(userService.saveNewUserConfiguration(any(), any())).thenReturn(MockData.getIamUserConfigurationEntity());
    when(firmRepository.findByFirmId(any())).thenReturn(MockData.getFirmEntity());
    when(authorizationClient.createFeaturePackage(any(), any())).thenReturn(MockData.getFeaturePackageCreateResponse());
    when(userService.getUserConfigurationFromTableByUserId(anyLong())).thenReturn(user);
    when(userService.getUserIdpUserIdentifierWithRefresh(any())).thenReturn("idpUserIdentifier");
    when(userConfigurationServiceJpa.getIamUserConfiguration(any())).thenReturn(MockData.getIamUserConfigurationEntity());
    doReturn(MockData.getUserAssignmentUserGroupEntityList())
        .when(userAssignmentService)
        .getUserAssignment(anyString(), eq(UserAssignmentType.G));

    userConfigurationService.createUserConfig(user, "idpSubject");
    verify(ciamService, times(1)).createOktaUser(any());
  }

  @Test(expected = FumServiceException.class)
  public void testCreateUser_whenErrorCreatingUser_shouldThrowException() {
    UserConfiguration user = MockData.getUserConfiguration();
    user.setFeaturePackage(MockData.getFeaturePackage());

    when(userService.saveNewUserConfiguration(any(), any())).thenReturn(MockData.getIamUserConfigurationEntity());
    when(firmRepository.findByFirmId(any())).thenReturn(MockData.getFirmEntity());
    when(authorizationClient.createFeaturePackage(any(), any())).thenReturn(MockData.getFeaturePackageCreateResponse());
    when(userService.getUserConfigurationFromTableByUserId(anyLong())).thenReturn(user);
    when(userService.getUserIdpUserIdentifierWithRefresh(any())).thenReturn("idpUserIdentifier");
    when(userConfigurationServiceJpa.getIamUserConfiguration(any())).thenReturn(MockData.getIamUserConfigurationEntity());
    doThrow(new RuntimeException("error"))
        .when(userAssignmentService)
        .getUserAssignment(anyString(), eq(UserAssignmentType.G));

    userConfigurationService.createUserConfig(user, "idpSubject");
  }

  @Test(expected = FumServiceException.class)
  public void testCreateUser_whenUnexpectedOktaError_shouldThrowException() {
    UserConfiguration user = MockData.getUserConfiguration();
    user.setFeaturePackage(MockData.getFeaturePackage());

    when(userService.saveNewUserConfiguration(any(), any())).thenReturn(MockData.getIamUserConfigurationEntity());
    when(firmRepository.findByFirmId(any())).thenReturn(MockData.getFirmEntity());
    when(authorizationClient.createFeaturePackage(any(), any())).thenReturn(MockData.getFeaturePackageCreateResponse());
    when(userService.getUserConfigurationFromTableByUserId(anyLong())).thenReturn(user);
    when(userService.getUserIdpUserIdentifierWithRefresh(any())).thenReturn("idpUserIdentifier");
    when(userConfigurationServiceJpa.getIamUserConfiguration(any())).thenReturn(MockData.getIamUserConfigurationEntity());
    doThrow(new FumServiceException("errorCode", "errorMessage")).when(ciamService).createOktaUser(any());

    userConfigurationService.createUserConfig(user, "idpSubject");
  }

  @Test
  public void test_getUserDwhAssignmentsResources_filtersToOnlyDwhResources() {
    UserAssignment dwhAssignment = new UserAssignment();
    dwhAssignment.setAssignmentType("S");
    dwhAssignment.setAssigneeId(1);
    dwhAssignment.setResourceName("dwh-module-1");

    UserAssignment nonDwhAssignment = new UserAssignment();
    nonDwhAssignment.setAssignmentType("S");
    nonDwhAssignment.setAssigneeId(2);
    nonDwhAssignment.setResourceName("non-dwh-resource");

    when(userService.getUserIdpSubjectById(anyInt())).thenReturn("idpSubject");
    when(userConfigValidationService.getDwhResourceNames())
        .thenReturn(Set.of("dwh-module-1", "dwh-module-2"));
    when(userAssignmentService.getUserAssignments(anyString(), anyList(), anyBoolean()))
        .thenReturn(List.of(dwhAssignment, nonDwhAssignment));

    List<UserAssignment> result = userConfigurationService.getUserDwhAssignmentsResources(1234);

    assertEquals(1, result.size());
    assertEquals("dwh-module-1", result.get(0).getResourceName());
  }

  @Test
  public void test_getUserDwhAssignmentsResources_whenNoDwhResources_returnsEmpty() {
    UserAssignment nonDwhAssignment = new UserAssignment();
    nonDwhAssignment.setAssignmentType("S");
    nonDwhAssignment.setAssigneeId(1);
    nonDwhAssignment.setResourceName("non-dwh-resource");

    when(userService.getUserIdpSubjectById(anyInt())).thenReturn("idpSubject");
    when(userConfigValidationService.getDwhResourceNames())
        .thenReturn(Set.of("dwh-module-1"));
    when(userAssignmentService.getUserAssignments(anyString(), anyList(), anyBoolean()))
        .thenReturn(List.of(nonDwhAssignment));

    List<UserAssignment> result = userConfigurationService.getUserDwhAssignmentsResources(1234);

    assertTrue(result.isEmpty());
  }

}
