package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.userconfiguration.util.MockData;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.extract.api.ExtractType;
import ca.bnc.wealth.common.extract.service.ExtractService;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.NotNull;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatusCode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class UserExtractServiceTest {

  private final MockExtractService extractService = new MockExtractService();
  @MockitoBean
  private UserService userService;
  @MockitoBean
  private CsvConverterService csvConverterService;
  @MockitoBean
  private R2Service r2Service;
  @MockitoBean
  private CiamService ciamService;
  private UserExtractService userExtractService;

  @Before
  public void setup() {
    userExtractService =
        new UserExtractService(userService, csvConverterService, r2Service,
            ciamService, extractService);
  }

  @Test
  public void testGetExtractType_DoReturnExtractType() {
    assertEquals(userExtractService.getExtractType(), ExtractType.USER.name());
  }

  @Test
  public void testGetExtract_DoReturnExtractInByteArray() {
    when(userService.getUserConfigurationById(anyInt())).thenReturn(
        new UserConfiguration());
    when(userService.getAllUserDataAssociatedToFirmAndChildFirms(
        anyString())).thenReturn(MockData.getUserDataList());
    when(csvConverterService.convertToCsv(any())).thenReturn(new ByteArrayResource(new byte[0]));
    when(ciamService.getOktaUserProfile(anyString())).thenReturn(MockData.getOktaUserProfile());
    when(r2Service.getCxUserProfile(anyString())).thenReturn(getCxUserProfile());
    assertNotNull(userExtractService.getExtract(anyInt()));
  }

  @Test
  public void testGetUserDataInCsvByteArray_whenReturnsBytes() {
    UserConfiguration userConfiguration = mock(UserConfiguration.class);
    when(userConfiguration.getUserConfigurationId()).thenReturn(123);
    when(userService.getUserConfiguration(anyString())).thenReturn(
        userConfiguration);
    extractService.setData(new byte[0]);
    assertNotNull(userExtractService.getUserDataInCsvByteArray("idpSubject"));
  }

  @Test
  public void testGetUserDataInCsvByteArray_whenReturnsNull() {
    UserConfiguration userConfiguration = mock(UserConfiguration.class);
    when(userConfiguration.getUserConfigurationId()).thenReturn(123);
    when(userService.getUserConfiguration(anyString())).thenReturn(
        userConfiguration);
    extractService.setData(null);
    assertNull(userExtractService.getUserDataInCsvByteArray("idpSubject"));
  }

  @NotNull
  private Pair<HttpStatusCode, String> getCxUserProfile() {
    return new Pair<HttpStatusCode, String>() {
      @Override
      public HttpStatusCode getLeft() {
        return null;
      }

      @Override
      public String getRight() {
        return "value";
      }

      @Override
      public String setValue(String value) {
        return null;
      }
    };
  }

  class MockExtractService extends ExtractService {

    private byte[] data = new byte[0];

    @Override
    public byte[] getExtract(long userConfigurationId, ExtractType extractType)
        throws FumServiceException {
      return data;
    }

    public void setData(byte[] data) {
      this.data = data;
    }
  }

}
