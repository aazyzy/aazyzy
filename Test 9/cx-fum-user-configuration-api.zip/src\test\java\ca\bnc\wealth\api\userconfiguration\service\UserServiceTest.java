package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class UserServiceTest {

  @Test
  public void shutdownAndAwait_shouldShutdownExecutor() {
    ExecutorService executorService = Executors.newFixedThreadPool(1);
    executorService.submit(() -> 1 + 1);

    UserService.shutdownAndAwait(executorService);

    assertTrue(executorService.isShutdown());
  }
}
