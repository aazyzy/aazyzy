package ca.bnc.wealth.api.userconfiguration.service;

import static ca.bnc.wealth.api.userconfiguration.model.state.UserStateActionEnum.SUSPENDED;
import static ca.bnc.wealth.api.userconfiguration.util.Constants.CPX_IDP;
import static ca.bnc.wealth.api.userconfiguration.util.Constants.DWH_IDP;
import static ca.bnc.wealth.api.userconfiguration.util.Constants.EMPLOYEE_IDP;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.userconfiguration.jpa.GenericUserSearchCriteria;
import ca.bnc.wealth.api.userconfiguration.kafka.UserConfigEventProducerService;
import ca.bnc.wealth.api.userconfiguration.model.FeaturePackageCreateResponse;
import ca.bnc.wealth.api.userconfiguration.model.UserData;
import ca.bnc.wealth.api.userconfiguration.model.state.UserStateActionEnum;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.MockData;
import ca.bnc.wealth.common.ciam.model.OktaAccessProfile;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.exception.Entity.FumConflictException;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.service.FirmServiceHelper;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.UserGroup;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentFeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentUserGroupRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserGroupRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.specification.SpecificationWithQueryAndFilter;
import ca.bnc.wealth.common.jpa.utils.QueryParameterCombination;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.NoResultsFoundException;
import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ServiceException;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearch;
import ca.bnc.wealth.common.userconfiguration.model.GenericSearchResponse;
import ca.bnc.wealth.common.userconfiguration.model.GroupByResponse;
import ca.bnc.wealth.common.userconfiguration.model.NbxUserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.PageInfo;
import ca.bnc.wealth.common.userconfiguration.model.PageInfo.SortOrderEnum;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.UamaUser;
import ca.bnc.wealth.common.userconfiguration.model.UamaUserSearchResponse;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserCredentials;
import ca.bnc.wealth.common.userconfiguration.model.UserExternalSystemConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserOktaProfile;
import ca.bnc.wealth.common.userconfiguration.model.UserSearch;
import ca.bnc.wealth.common.userconfiguration.model.Users;
import ca.bnc.wealth.common.sz.model.SzUser;
import ca.bnc.wealth.common.sz.model.SzUserSearch;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import jakarta.persistence.EntityManager;
import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.PageImpl;
import org.springframework.expression.Expression;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletWebRequest;
import tools.jackson.core.JacksonException;

@RunWith(SpringRunner.class)
public class UserServiceTests {

  private static final String INACTIVE = "inactive";
    private static final String ACTIVE = "active";
  private UserService userService;

  @MockitoBean private IamUserConfigurationRepository iamUserConfigurationRepository;

  @MockitoBean private UserAssignmentUserGroupRepository userAssignmentUserGroupRepository;

  @MockitoBean private UserAssignmentRrCodeRangeRepository userAssignmentRrCodeRangeRepository;

  @MockitoBean private UserAssignmentFeaturePackageRepository userAssignmentFeaturePackageRepository;

  @MockitoBean private IamRrCodeRangeRepository iamRrCodeRangeRepository;

  @MockitoBean private FeaturePackageRepository featurePackageRepository;

  @MockitoBean
  private PackageTemplateAssignmentUserGroupRepository packageTemplateAssignmentUserGroupRepository;

  @MockitoBean private UserGroupRepository userGroupRepository;

  @MockitoBean private FirmRepository firmRepository;

  @MockitoBean private CiamService ciamService;

  @MockitoBean private R2Service r2Service;

  @MockitoBean private SzService szService;

  @MockitoBean private UserConfigurationSearchService userConfigurationSearchService;

  @MockitoBean private UserAssignmentService userAssignmentService;

  @MockitoBean private EntityManager entityManager;

  @MockitoBean private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  @MockitoBean private UserStateService userStateService;

  @MockitoBean private UserConfigEventProducerService userConfigEventProducerService;

  @MockitoBean private FirmServiceHelper firmServiceHelper;

  @MockitoBean private RedisCacheOperationService redisCacheOperationService;

  @MockitoBean private PersonService personService;

  private final ObjectMapper objectMapper = spy(JsonMapper.builderWithJackson2Defaults().build());

  @Before
  public void setup() throws IllegalAccessException {
    userService = new UserService();

    FieldUtils.writeField(
        userService, "iamUserConfigurationRepository", iamUserConfigurationRepository, true);
    FieldUtils.writeField(
        userService, "userAssignmentUserGroupRepository", userAssignmentUserGroupRepository, true);
    FieldUtils.writeField(
        userService,
        "userAssignmentRrCodeRangeRepository",
        userAssignmentRrCodeRangeRepository,
        true);
    FieldUtils.writeField(
        userService,
        "userAssignmentFeaturePackageRepository",
        userAssignmentFeaturePackageRepository,
        true);
    FieldUtils.writeField(userService, "iamRrCodeRangeRepository", iamRrCodeRangeRepository, true);
    FieldUtils.writeField(userService, "featurePackageRepository", featurePackageRepository, true);
    FieldUtils.writeField(
        userService,
        "packageTemplateAssignmentUserGroupRepository",
        packageTemplateAssignmentUserGroupRepository,
        true);
    FieldUtils.writeField(userService, "userGroupRepository", userGroupRepository, true);
    FieldUtils.writeField(userService, "firmRepository", firmRepository, true);
    FieldUtils.writeField(userService, "ciamService", ciamService, true);
    FieldUtils.writeField(userService, "r2Service", r2Service, true);
    FieldUtils.writeField(userService, "szService", szService, true);
    FieldUtils.writeField(
        userService, "userConfigurationSearchService", userConfigurationSearchService, true);
    FieldUtils.writeField(userService, "userAssignmentService", userAssignmentService, true);
    FieldUtils.writeField(userService, "entityManager", entityManager, true);
    FieldUtils.writeField(
        userService, "namedParameterJdbcTemplate", namedParameterJdbcTemplate, true);
    FieldUtils.writeField(userService, "userStateService", userStateService, true);
    FieldUtils.writeField(
        userService, "userConfigEventProducerService", userConfigEventProducerService, true);
    FieldUtils.writeField(userService, "firmServiceHelper", firmServiceHelper, true);
    FieldUtils.writeField(
        userService, "redisCacheOperationService", redisCacheOperationService, true);
    FieldUtils.writeField(userService, "objectMapper", objectMapper, true);
    FieldUtils.writeField(userService, "personService", personService, true);
    FieldUtils.writeField(userService, "employeeIdp", EMPLOYEE_IDP, true);
    FieldUtils.writeField(userService, "isUamaEnabled", true, true);

    RequestAttributes mockRequest = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(mockRequest);
  }

  @Test
  public void getUserConfiguration_whenUserConfigurationExistsInMV_shouldReturnUserConfiguration() {
    when(namedParameterJdbcTemplate.queryForList(anyString(), any(SqlParameterSource.class)))
        .thenReturn(List.of(MockData.getUserConfigurationMap()));
    UserConfiguration userConfiguration = userService.getUserConfiguration("123");
    assertNotNull(userConfiguration.getUserConfigurationId());
  }

  @Test
  public void getUserConfiguration_whenUserConfigurationExistsInDB_shouldReturnUserConfiguration() {
    when(namedParameterJdbcTemplate.queryForList(anyString(), any(SqlParameterSource.class)))
        .thenReturn(new ArrayList<>());
    when(iamUserConfigurationRepository.findFirstByIdpSubject(anyString()))
        .thenReturn(Optional.of(MockData.getIamUserConfigurationEntity()));
    UserConfiguration userConfiguration = userService.getUserConfiguration("123");
    assertNotNull(userConfiguration.getUserConfigurationId());
  }

  @Test(expected = FumNotFoundException.class)
  public void
      getUserConfiguration_whenUserConfigurationDoesNotExist_shouldThrowFumNotFoundException() {
    when(namedParameterJdbcTemplate.queryForList(anyString(), any(SqlParameterSource.class)))
        .thenReturn(new ArrayList<>());
    when(iamUserConfigurationRepository.findFirstByIdpSubject(anyString()))
        .thenReturn(Optional.empty());
    userService.getUserConfiguration(MockData.IDP_USER_SUB);
  }

  @Test
  public void getUserConfigurationById_whenUserConfigurationExist_shouldReturnUserConfiguration() {
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_USER_FROM_MV_BY_CONF_ID_QUERY), any(SqlParameterSource.class)))
        .thenReturn(List.of(MockData.getUserConfigurationMap()));
    doReturn(MockData.getUserAssignmentFirmEntityList())
        .when(userAssignmentService)
        .getUserAssignment(anyString(), eq(UserAssignmentType.F));
    doReturn(MockData.getUserAssignmentUserGroupEntityList())
        .when(userAssignmentService)
        .getUserAssignment(anyString(), eq(UserAssignmentType.G));
    UserConfiguration userConfiguration = userService.getUserConfigurationById(123);
    assertEquals(
        MockData.getUserConfigurationMap().get("IDP_USER_ID"), userConfiguration.getIdpUserId());
  }

  @Test(expected = Exception.class)
  public void
      getUserConfigurationWithRrCodeById_whenUserConfigurationDoesNotExist_shouldThrowFumNotFoundException() {
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_USER_FROM_MV_BY_CONF_ID_QUERY), any(SqlParameterSource.class)))
        .thenReturn(new ArrayList<>());
    when(iamUserConfigurationRepository.getReferenceById(anyLong())).thenThrow(NoResultsFoundException.class);

    userService.getUserConfigurationWithRrCodeById(123);
  }

  @Test
  public void
      getUserConfigurationWithRrCodeById_whenUserConfigurationExist_shouldReturnUserConfiguration() {
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_USER_FROM_MV_BY_CONF_ID_QUERY), any(SqlParameterSource.class)))
        .thenReturn(List.of(MockData.getUserConfigurationMap()));
    when(r2Service.getCxUserProfile(anyString())).thenReturn(MockData.getCxUserProfile());

    UserConfiguration userConfiguration = userService.getUserConfigurationWithRrCodeById(123);
    assertEquals(
        MockData.getUserConfigurationMap().get("IDP_USER_ID"), userConfiguration.getIdpUserId());
    assertEquals(
        MockData.getUserConfigurationMap().get("USER_CONFIGURATION_ID"),
        userConfiguration.getUserConfigurationId());
  }

  @Test
  public void
      getUserConfigurationWithRrCodeById_whenUserOktaProfileDoesNotExist_shouldDeleteUserConfigurationFromCache() {
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_USER_FROM_MV_BY_CONF_ID_QUERY), any(SqlParameterSource.class)))
        .thenReturn(List.of(MockData.getUserConfigurationMap()));
    when(ciamService.getOktaUserProfile(any())).thenThrow(FumNotFoundException.class);

    UserConfiguration userConfiguration = userService.getUserConfigurationWithRrCodeById(123);
    assertEquals(
        MockData.getUserConfigurationMap().get("IDP_USER_ID"), userConfiguration.getIdpUserId());
    assertEquals(
        MockData.getUserConfigurationMap().get("USER_CONFIGURATION_ID"),
        userConfiguration.getUserConfigurationId());
    verify(userStateService, times(1)).updateStateForDeletedOktaProfile(any());
    verify(redisCacheOperationService, times(1)).deleteUserConfigurationCache(any(), any(), any());
  }

  @Test
  public void testSuspendOktaProfileByIdpSubject() {
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(anyString()))
            .thenReturn(Optional.of(MockData.getIamUserConfigurationEntity()));
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_USER_FROM_MV_BY_IDP_SUBJECT_QUERY), any(SqlParameterSource.class)))
            .thenReturn(List.of(MockData.getUserConfigurationMap()));
    OktaUserProfile oktaUserProfile = new OktaUserProfile();
    oktaUserProfile.setStatus("ACTIVE");
    when(ciamService.getOktaUserProfile(any())).thenReturn(oktaUserProfile);
    userService.suspendOktaProfileByIdpSubject("indall_test");

    verify(ciamService, times(1)).suspendUserOktaProfile(any());
  }

  @Test
  public void
      getUserIdpUserIdentifierWithRefresh_whenUserConfigurationExist_shouldReturnIdpUserIdentifier() {
    when(iamUserConfigurationRepository.findById(anyLong()))
        .thenReturn(Optional.of(MockData.getIamUserConfigurationEntity()));
    String idpUserIdentifier =
        userService.getUserIdpUserIdentifierWithRefresh(MockData.getIamUserConfigurationEntity());
    assertEquals(
        MockData.getIamUserConfigurationEntity().getIdpUserIdentifier(), idpUserIdentifier);
  }

  @Test(expected = FumNotFoundException.class)
  public void
      getUserIdpUserIdentifierWithRefresh_whenUserConfigurationDoNotExist_shouldThrowFumNotFoundException() {
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(Optional.empty());
    String idpUserIdentifier =
        userService.getUserIdpUserIdentifierWithRefresh(MockData.getIamUserConfigurationEntity());
  }

  @Test
  public void getUserIdpSubjectById_whenUserConfigurationExist_shouldReturnIdpUserIdentifier() {
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_USER_FROM_MV_BY_CONF_ID_QUERY), any(SqlParameterSource.class)))
        .thenReturn(List.of(MockData.getUserConfigurationMap()));
    String idpSubject = userService.getUserIdpSubjectById(123);
    assertEquals(MockData.getUserConfigurationMap().get("IDP_SUBJECT"), idpSubject);
  }

  @Test(expected = FumNotFoundException.class)
  public void
      getUserIdpSubjectById_whenUserConfigurationDoNotExist_shouldThrowFumNotFoundException() {
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_USER_FROM_MV_BY_CONF_ID_QUERY), any(SqlParameterSource.class)))
        .thenReturn(new ArrayList<>());
    userService.getUserIdpSubjectById(123);
  }

  @Test
  public void
      getUserConfigurationByIdOrName_whenInputIsIsNumberAndUserConfigurationExist_shouldReturnUserConfiguration() {
    when(iamUserConfigurationRepository.findById(anyLong()))
        .thenReturn(Optional.of(MockData.getIamUserConfigurationEntity()));
    UserConfiguration userConfiguration = userService.getUserConfigurationByIdOrName("123");
    assertEquals(
        MockData.getIamUserConfigurationEntity().getUserConfigurationId().intValue(),
        userConfiguration.getUserConfigurationId());
  }

  @Test
  public void
      getUserConfigurationByIdOrName_whenInputIsIsStringAndUserConfigurationExist_shouldReturnUserConfiguration() {
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(anyString()))
        .thenReturn(Optional.of(MockData.getIamUserConfigurationEntity()));
    UserConfiguration userConfiguration = userService.getUserConfigurationByIdOrName("idpSubject");
    assertEquals(
        MockData.getIamUserConfigurationEntity().getUserConfigurationId().intValue(),
        userConfiguration.getUserConfigurationId());
  }

  @Test
  public void
      getUserConfigurationByIdOrName_whenShortIdCaseDiffersFromStoredUsername_shouldReturnUserConfiguration() {
    IamUserConfiguration storedUser = MockData.getIamUserConfigurationEntity();
    storedUser.setUsername("raza002");
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("RAZA002"))
        .thenReturn(Optional.of(storedUser));

    UserConfiguration userConfiguration = userService.getUserConfigurationByIdOrName("RAZA002");

    assertEquals(
        storedUser.getUserConfigurationId().intValue(),
        userConfiguration.getUserConfigurationId());
    assertEquals("raza002", userConfiguration.getUsername());
    verify(iamUserConfigurationRepository, never()).findFirstByIdpSubjectIgnoreCase(anyString());
  }

  @Test
  public void
      getUserConfigurationByIdOrName_whenUsernameLookupMisses_shouldFallBackToIdpSubject() {
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(anyString()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(anyString()))
        .thenReturn(Optional.of(MockData.getIamUserConfigurationEntity()));

    UserConfiguration userConfiguration = userService.getUserConfigurationByIdOrName("idpSubject");

    assertEquals(
        MockData.getIamUserConfigurationEntity().getUserConfigurationId().intValue(),
        userConfiguration.getUserConfigurationId());
    verify(iamUserConfigurationRepository, times(1)).findFirstByIdpSubjectIgnoreCase("idpSubject");
  }

  @Test
  public void
      getUserConfigurationByIdOrName_whenInputIsIsNumberAndUserConfigurationDoNotExist_shouldReturnUserConfiguration() {
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(Optional.empty());
    UserConfiguration userConfiguration = userService.getUserConfigurationByIdOrName("123");
    Assertions.assertNull(userConfiguration);
  }

  @Test(expected = FumNotFoundException.class)
  public void
      getUserConfigurationByIdOrName_whenInputIsIsStringAndUserConfigurationDoNotExist_shouldReturnUserConfiguration() {
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(anyString()))
        .thenReturn(Optional.empty());
    UserConfiguration userConfiguration = userService.getUserConfigurationByIdOrName("idpSubject");
  }

  @Test
  public void getUserGroupByGroupName_whenUserGroupPresent_shouldReturnUserGroup() {
    when(userGroupRepository.findOne(any(Specification.class)))
        .thenReturn(Optional.of(MockData.getUserGroupEntity()));
    UserGroup userGroup = userService.getUserGroupByGroupName("userGroup");
    assertEquals(MockData.getUserGroupEntity().getName(), userGroup.getName());
  }

  @Test(expected = ServiceException.class)
  public void getUserGroupByGroupName_whenUserGroupNotPresent_shouldThrowServiceException() {
    when(userGroupRepository.findOne(any(Specification.class))).thenReturn(Optional.empty());
    userService.getUserGroupByGroupName("userGroup");
  }

  @Test
  public void testGetRRCodeListByIdpSubject_whenValidIdpSubject_shouldReturnRrCodeList() {
    Map<String, Object> rrCodeRangeInRange = new HashMap<>(getRrCodeRangeMap());
    rrCodeRangeInRange.put("FROM_RR_CODE", "A2A1");
    rrCodeRangeInRange.put("FROM_RR_CODE_B10", 2L);
    rrCodeRangeInRange.put("TO_RR_CODE", "A2A3");
    rrCodeRangeInRange.put("TO_RR_CODE_B10", 4L);

    Map<String, Object> rrCodeRangeOutOfRange = new HashMap<>(getRrCodeRangeMap());
    rrCodeRangeOutOfRange.put("FROM_RR_CODE", "A6WA");
    rrCodeRangeOutOfRange.put("FROM_RR_CODE_B10", 11L);
    rrCodeRangeOutOfRange.put("TO_RR_CODE", "A6WZ");
    rrCodeRangeOutOfRange.put("TO_RR_CODE_B10", 20L);

    List<Map<String, Object>> expectedList = List.of(getRrCodeRangeMap(), rrCodeRangeInRange, rrCodeRangeOutOfRange);

    when(namedParameterJdbcTemplate.queryForList(eq(Constants.GET_RRCODE_BY_USER_QUERY), any(SqlParameterSource.class)))
        .thenReturn(expectedList);

    List<RRCodeRange> rrCodeRanges = userService.getRRCodeListByIdpSubject("idpSubject", true);
    assertEquals(2, rrCodeRanges.size());
    assertEquals(expectedList.get(0).get("FROM_RR_CODE"), rrCodeRanges.get(1).getFromRRCode());
    assertEquals(expectedList.get(0).get("TO_RR_CODE"), rrCodeRanges.get(1).getToRRCode());
    assertEquals(expectedList.get(2).get("FROM_RR_CODE"), rrCodeRanges.get(0).getFromRRCode());
    assertEquals(expectedList.get(2).get("TO_RR_CODE"), rrCodeRanges.get(0).getToRRCode());
  }

  @Test
  public void getIamRRCodeListByFirmId_whenActiveIsTrue_shouldReturnIamRrCodeRangeList() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(MockData.getRrCodeRangeEntityList());
    List<RRCodeRange> rrCodeRanges = userService.getRRCodeListByFirmId("NBIN", true);
    assertEquals(
        MockData.getRrCodeRangeEntityList().get(0).getToRrCode(),
        rrCodeRanges.get(0).getToRRCode());
  }

  @Test
  public void getIamRRCodeListByFirmId_whenActiveIsFalse_shouldReturnIamRrCodeRangeList() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(MockData.getRrCodeRangeEntityList());
    List<RRCodeRange> rrCodeRanges = userService.getRRCodeListByFirmId("NBIN", false);
    assertEquals(
        MockData.getRrCodeRangeEntityList().get(0).getToRrCode(),
        rrCodeRanges.get(0).getToRRCode());
  }

  @Test(expected = ServiceException.class)
  public void
      getAllUserDataAssociatedToFirmAndChildFirms_whenNoFirmExist_shouldThrowServiceException() {
    when(firmRepository.findOne(any(Specification.class))).thenReturn(Optional.empty());
    userService.getAllUserDataAssociatedToFirmAndChildFirms(MockData.IDP_USER_SUB);
  }

  @Test
  public void
      getAllUserDataAssociatedToFirmAndChildFirms_whenFirmIsNBIN_shouldReturnAssociatedUserData() {
    Firm firm = MockData.getFirmEntity();
    firm.setFirmId("NBIN");
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.of(firm));
    when(iamUserConfigurationRepository.findAll())
        .thenReturn(MockData.getIamUserConfigurationEntityList());
    List<UserData> userDataList =
        userService.getAllUserDataAssociatedToFirmAndChildFirms(MockData.IDP_USER_SUB);
    assertEquals(
        MockData.getIamUserConfigurationEntityList().get(0).getIdpUserIdentifier(),
        userDataList.get(0).getIdpUserIdentifier());
  }

  @Test
  public void
      getAllUserDataAssociatedToFirmAndChildFirms_whenFirmIsNotNBIN_shouldReturnAssociatedUserData() {
    Firm firm = MockData.getFirmEntity();
    firm.setFirmId("OTHER");
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.of(firm));
    when(firmRepository.getAllFirmsByIdpSubject(anyString())).thenReturn(List.of(1234L));
    when(iamUserConfigurationRepository.findAll(any(Specification.class)))
        .thenReturn(MockData.getIamUserConfigurationEntityList());
    List<UserData> userDataList =
        userService.getAllUserDataAssociatedToFirmAndChildFirms(MockData.IDP_USER_SUB);
    assertEquals(
        MockData.getIamUserConfigurationEntityList().get(0).getIdpUserIdentifier(),
        userDataList.get(0).getIdpUserIdentifier());
  }

  @Test(expected = ServiceException.class)
  public void searchUsers_whenFirmDoNotExist_shouldThrowServiceException()
      throws IntrospectionException, InvocationTargetException, IllegalAccessException {
    when(firmRepository.findOne(any(Specification.class))).thenReturn(Optional.empty());
    userService.searchUsers(MockData.IDP_USER_SUB, new UserSearch());
  }

  @Test
  public void searchUsers_whenFirmExist_shouldReturnUserConfigurationList()
      throws IntrospectionException, InvocationTargetException, IllegalAccessException {
    Firm firm = MockData.getFirmEntity();
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.of(firm));
    when(firmRepository.getAllFirmsByIdpSubject(anyString())).thenReturn(List.of(1234L));
    when(firmRepository.count()).thenReturn(1L);
    when(iamRrCodeRangeRepository.rrCodeDecoder(anyString())).thenReturn(1234567L);
    when(iamUserConfigurationRepository.findAll(any(SpecificationWithQueryAndFilter.class)))
        .thenReturn(MockData.getIamUserConfigurationEntityList());
    when(userConfigurationSearchService.getSpecification(
            anyString(), any(UserSearch.class), anyLong(), anyList()))
        .thenReturn(
            new SpecificationWithQueryAndFilter<>(
                null,
                GenericUserSearchCriteria.class,
                new HashMap<>(),
                new QueryParameterCombination(),
                null,
                true));

    List<UserConfiguration> userConfigurations =
        userService.searchUsers(MockData.IDP_USER_SUB, MockData.getUserSearch());
    assertTrue(userConfigurations.size() > 0);
  }

  @Test
  public void
      searchUsers_whenFirmExistButDoesNotMatchWithTotalFirm_shouldReturnUserConfigurationList()
          throws IntrospectionException, InvocationTargetException, IllegalAccessException {
    Firm firm = MockData.getFirmEntity();
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.of(firm));
    when(firmRepository.getAllFirmsByIdpSubject(anyString())).thenReturn(List.of(1234L));
    when(firmRepository.count()).thenReturn(2L);
    when(iamRrCodeRangeRepository.rrCodeDecoder(anyString())).thenReturn(1234567L);
    when(iamUserConfigurationRepository.findAll(any(SpecificationWithQueryAndFilter.class)))
        .thenReturn(MockData.getIamUserConfigurationEntityList());
    when(userConfigurationSearchService.getSpecification(
            anyString(), any(UserSearch.class), anyLong(), anyList()))
        .thenReturn(
            new SpecificationWithQueryAndFilter<>(
                null,
                GenericUserSearchCriteria.class,
                new HashMap<>(),
                new QueryParameterCombination(),
                null,
                true));

    List<UserConfiguration> userConfigurations =
        userService.searchUsers(MockData.IDP_USER_SUB, new UserSearch());
    assertTrue(userConfigurations.size() > 0);
  }

  @Test
  public void materializedViewSearch() {
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("test");
    userSearch.setFirmId("NBIN");
    Firm firm = MockData.getFirmEntity();
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.of(firm));
    when(firmRepository.findByFirmId(anyString())).thenReturn(firm);
    GroupByResponse groupByResponse = new GroupByResponse();
    groupByResponse.setGroupKey("NBIN");
    UserConfiguration uc = new UserConfiguration();
    uc.username(MockData.USER_NAME_LABEL);
    groupByResponse.setGroupData(Arrays.asList(uc));
    Pair<Integer, List<GroupByResponse>> pair = Pair.of(1, Arrays.asList(groupByResponse));
    when(userConfigurationSearchService.searchUserView(
            anyString(), any(), any(), any(), anyBoolean()))
        .thenReturn(CompletableFuture.completedFuture(pair));
    GenericSearchResponse response = userService.materializedViewSearch("idp", userSearch);
    assertEquals(1, response.getCurrentFirmUserCount());
    assertEquals(1, response.getOtherFirmUserCount());
  }

  @Test
  public void materializedViewSearch_withPagesize() {
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("test");
    userSearch.setPageNumber(1);
    userSearch.setPageSize(1);
    userSearch.setFirmId("NBIN");
    Firm firm = MockData.getFirmEntity();
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.of(firm));
    when(firmRepository.findByFirmId(anyString())).thenReturn(firm);
    GroupByResponse groupByResponse = new GroupByResponse();
    groupByResponse.setGroupKey("NBIN");
    UserConfiguration uc = new UserConfiguration();
    uc.username(MockData.USER_NAME_LABEL);
    groupByResponse.setGroupData(Arrays.asList(uc));
    Pair<Integer, List<GroupByResponse>> pair = Pair.of(1, Arrays.asList(groupByResponse));
    when(userConfigurationSearchService.searchUserView(
            anyString(), any(), any(), any(), anyBoolean()))
        .thenReturn(CompletableFuture.completedFuture(pair));
    GenericSearchResponse response = userService.materializedViewSearch("idp", userSearch);
    assertEquals(1, response.getCurrentFirmUserCount());
    assertEquals(1, response.getOtherFirmUserCount());
  }

  @Test
  public void materializedViewSearch_noFirmIdInput() {
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("test");
    Firm firm = MockData.getFirmEntity();
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.of(firm));
    GroupByResponse groupByResponse = new GroupByResponse();
    groupByResponse.setGroupKey("NBIN");
    UserConfiguration uc = new UserConfiguration();
    uc.username(MockData.USER_NAME_LABEL);
    groupByResponse.setGroupData(Arrays.asList(uc));
    Pair<Integer, List<GroupByResponse>> pair = Pair.of(1, Arrays.asList(groupByResponse));
    when(userConfigurationSearchService.searchUserView(
            anyString(), any(), any(), any(), anyBoolean()))
        .thenReturn(CompletableFuture.completedFuture(pair));
    GenericSearchResponse response = userService.materializedViewSearch("idp", userSearch);
    assertEquals(1, response.getCurrentFirmUserCount());
    assertEquals(1, response.getOtherFirmUserCount());
  }

  @Test
  public void materializedViewSearch_withoutsearchTest() {
    GenericSearch userSearch = new GenericSearch();
    Firm firm = MockData.getFirmEntity();
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.of(firm));
    GroupByResponse groupByResponse = new GroupByResponse();
    groupByResponse.setGroupKey("NBIN");
    UserConfiguration uc = new UserConfiguration();
    uc.username(MockData.USER_NAME_LABEL);
    groupByResponse.setGroupData(Arrays.asList(uc));
    Pair<Integer, List<GroupByResponse>> pair = Pair.of(1, Arrays.asList(groupByResponse));
    when(userConfigurationSearchService.searchUserView(
            anyString(), any(), any(), any(), anyBoolean()))
        .thenReturn(CompletableFuture.completedFuture(pair));
    GenericSearchResponse response = userService.materializedViewSearch("idp", userSearch);
    assertEquals(1, response.getCurrentFirmUserCount());
  }

  @Test
  public void materializedViewSearch_firmNotFound_withFirmId_shouldSucceed() {
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("test");
    userSearch.setFirmId("NBIN");
    Firm firm = MockData.getFirmEntity();
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.empty());
    when(firmRepository.findByFirmId(anyString())).thenReturn(firm);
    GroupByResponse groupByResponse = new GroupByResponse();
    groupByResponse.setGroupKey("NBIN");
    UserConfiguration uc = new UserConfiguration();
    uc.username(MockData.USER_NAME_LABEL);
    groupByResponse.setGroupData(Arrays.asList(uc));
    Pair<Integer, List<GroupByResponse>> pair = Pair.of(1, Arrays.asList(groupByResponse));
    when(userConfigurationSearchService.searchUserView(
            anyString(), any(), any(), any(), anyBoolean()))
        .thenReturn(CompletableFuture.completedFuture(pair));
    GenericSearchResponse response = userService.materializedViewSearch("idp", userSearch);
    assertEquals(1, response.getCurrentFirmUserCount());
  }

  @Test(expected = Exception.class)
  public void materializedViewSearch_firmNotFound_withoutFirmId_shouldThrow() {
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("test");
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.empty());
    userService.materializedViewSearch("idp", userSearch);
  }

  @Test
  public void setSecureZoneId_whenOktaUserProfileDoNotExist_shouldNotSetSecureZoneId() {
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpUserId(MockData.IDP_USER_ID);
    userService.getSecureZoneId(userConfiguration.getIdpUserId());
    assertNull(userConfiguration.getSecureZoneIds());
  }

  @Test
  public void
      setSecureZoneId_whenOktaUserProfileDoExistAndOktaAccessProfileDoNotExist_shouldNotSetSecureZoneId() {
    OktaUserProfile oktaUserProfile = new OktaUserProfile();
    when(ciamService.getOktaUserProfile(anyString())).thenReturn(oktaUserProfile);
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpUserId(MockData.IDP_USER_ID);
    userService.getSecureZoneId(userConfiguration.getIdpUserId());
    assertNull(userConfiguration.getSecureZoneIds());
  }

  @Test
  public void
      setSecureZoneId_whenOktaUserProfileAndOktaAccessProfileDoExistAndSecureZoneIdIsNull_shouldNotSetSecureZoneId() {
    OktaUserProfile oktaUserProfile = new OktaUserProfile();
    oktaUserProfile.setAccessProfile(new OktaAccessProfile());
    when(ciamService.getOktaUserProfile(anyString())).thenReturn(oktaUserProfile);
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpUserId(MockData.IDP_USER_ID);
    userService.getSecureZoneId(userConfiguration.getIdpUserId());
    assertNull(userConfiguration.getSecureZoneIds());
  }

  @Test
  public void
      setSecureZoneId_whenOktaUserProfileAndOktaAccessProfileDoExistAndSecureZoneIdIsEmptyArray_shouldReturnEmptySetSecureZoneIdList() {
    OktaUserProfile oktaUserProfile = new OktaUserProfile();
    OktaAccessProfile accessProfile = new OktaAccessProfile();
    accessProfile.setBngfSecureZoneId(new String[0]);
    oktaUserProfile.setAccessProfile(accessProfile);
    when(ciamService.getOktaUserProfile(anyString())).thenReturn(oktaUserProfile);
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpUserId(MockData.IDP_USER_ID);
    String[] ids = userService.getSecureZoneId(userConfiguration.getIdpUserId());
    assertNotNull(ids);
    Assert.assertEquals(0, ids.length);
  }

  @Test
  public void
      setSecureZoneId_whenOktaUserProfileAndOktaAccessProfileDoExistAndSecureZoneIdIsEmptyArray_shouldReturnSecureZoneId() {
    OktaUserProfile oktaUserProfile = new OktaUserProfile();
    OktaAccessProfile accessProfile = new OktaAccessProfile();
    accessProfile.setBngfSecureZoneId(new String[] {"abc", "bce"});
    oktaUserProfile.setAccessProfile(accessProfile);
    when(ciamService.getOktaUserProfile(anyString())).thenReturn(oktaUserProfile);
    doReturn(oktaUserProfile).when(ciamService).getOktaUserProfile(anyString());
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpUserId(MockData.IDP_USER_ID);
    String[] ids = userService.getSecureZoneId(userConfiguration.getIdpUserId());
    assertNotNull(ids);
    assertTrue(ids.length > 0);
  }

  @Test
  public void getUserConfigurationsByFirmId() {
    PageInfo pageInfo = new PageInfo();
    pageInfo.setSortBy(List.of("username", "email"));
    pageInfo.setSortOrder(SortOrderEnum.ASC);
    pageInfo.setPageNumber(1);
    pageInfo.setPageSize(50);

    Map<String, Object> firmMap = getFirmMap("NBIN");
    when(namedParameterJdbcTemplate.queryForMap(
            eq(Constants.GET_FIRM_BY_USER_QUERY), any(SqlParameterSource.class)))
        .thenReturn(firmMap);

    doReturn(new PageImpl(MockData.getIamUserConfigurationEntityList()))
        .when(userAssignmentService)
        .getUserConfigByAssignment(any(), anyString(), any(PageInfo.class));

    Users users = userService.getUserConfigurationsByFirmId("userId", "NBIN", pageInfo);
    assertEquals(1, users.getTotalCount());
    assertEquals(
        MockData.getIamUserConfigurationEntity().getUserConfigurationId().intValue(),
        users.getUsers().get(0).getUserConfigurationId());
  }

  @Test
  public void getFirm_whenFirmIsNBINAndFirmIdIsNBIN_shouldReturnNBINFirm() {
    Map<String, Object> firmMap = getFirmMap("NBIN");
    when(namedParameterJdbcTemplate.queryForMap(
            eq(Constants.GET_FIRM_BY_USER_QUERY), any(SqlParameterSource.class)))
        .thenReturn(firmMap);

    Firm firm = userService.getFirm("userId", "NBIN");
    assertEquals("NBIN", firm.getFirmId());
  }

  @Test
  public void getFirm_whenFirmIsNBINAndFirmIdIsNotNBIN_shouldReturnFirmId() {
    String expectedFirm = "firmId";

    Map<String, Object> nbinFirmMap = getFirmMap("NBIN");
    when(namedParameterJdbcTemplate.queryForMap(
            eq(Constants.GET_FIRM_BY_USER_QUERY), any(SqlParameterSource.class)))
        .thenReturn(nbinFirmMap);

    Map<String, Object> firmMap = getFirmMap(expectedFirm);
    when(namedParameterJdbcTemplate.queryForMap(
            eq(Constants.GET_FIRM_BY_ID_QUERY), any(SqlParameterSource.class)))
        .thenReturn(firmMap);

    Firm firm = userService.getFirm("userId", expectedFirm);
    assertEquals(expectedFirm, firm.getFirmId());
  }

  @Test
  public void getFirm_whenFirmIsNotNBIN_shouldReturnFirmId() {
    String expectedFirm = "firmId";

    Map<String, Object> firmMap = getFirmMap(expectedFirm);
    when(namedParameterJdbcTemplate.queryForMap(
            eq(Constants.GET_FIRM_BY_USER_QUERY), any(SqlParameterSource.class)))
        .thenReturn(firmMap);

    Firm firm = userService.getFirm("userId", expectedFirm);
    assertEquals(expectedFirm, firm.getFirmId());
  }

  @Test(expected = FumNotFoundException.class)
  public void getFirm_whenFirmNotFound_shouldThrowException() {
    when(namedParameterJdbcTemplate.queryForMap(
            eq(Constants.GET_FIRM_BY_USER_QUERY), any(SqlParameterSource.class)))
        .thenThrow(EmptyResultDataAccessException.class);
    userService.getFirm("userId", "firmId");
  }

  @Test(expected = FumNotFoundException.class)
  public void
      getUserExternalSystemConfiguration_whenUserDoNotExist_shouldThrowFumNotFoundException() {
    userService.getUserExternalSystemConfiguration(123, "compass-r2");
  }

  @Test
  public void
      getUserExternalSystemConfiguration_whenUserDoExistAndExternalSystemIsCompassR2_shouldReturnCompassR2Id() {
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_USER_FROM_MV_BY_CONF_ID_QUERY), any(SqlParameterSource.class)))
        .thenReturn(List.of(MockData.getUserConfigurationMap()));
    when(r2Service.getCxUserProfile(anyString())).thenReturn(MockData.getCxUserProfile());
    UserExternalSystemConfiguration userExternalSystemConfiguration =
        userService.getUserExternalSystemConfiguration(123, "compass-r2");
    assertEquals(
        MockData.getCxUserProfile().getValue(), userExternalSystemConfiguration.getCompassR2Id());
    assertNull(userExternalSystemConfiguration.getSecureZoneId());
  }

  @Test
  public void
      getUserExternalSystemConfiguration_whenUserDoExistAndExternalSystemIsSecureZoneId_shouldReturnSecureZone() {
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_USER_FROM_MV_BY_IDP_SUBJECT_QUERY), any(SqlParameterSource.class)))
        .thenReturn(List.of(MockData.getUserConfigurationMap()));
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_USER_FROM_MV_BY_CONF_ID_QUERY), any(SqlParameterSource.class)))
        .thenReturn(List.of(MockData.getUserConfigurationMap()));
    when(ciamService.getOktaUserProfile(anyString())).thenReturn(MockData.getOktaUserProfile());
    UserExternalSystemConfiguration userExternalSystemConfiguration =
        userService.getUserExternalSystemConfiguration(123, "secure-zone");
    assertEquals(
        MockData.getOktaUserProfile().getAccessProfile().getBngfSecureZoneId()[0],
        userExternalSystemConfiguration.getSecureZoneId().get(0));
    assertNull(userExternalSystemConfiguration.getCompassR2Id());
  }

  @Test
  public void
      getUserExternalSystemConfiguration_whenUserDoExistAndExternalSystemIsOSS_shouldReturnOSS() {
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_USER_FROM_MV_BY_IDP_SUBJECT_QUERY), any(SqlParameterSource.class)))
        .thenReturn(List.of(MockData.getUserConfigurationMap()));
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_USER_FROM_MV_BY_CONF_ID_QUERY), any(SqlParameterSource.class)))
        .thenReturn(List.of(MockData.getUserConfigurationMap()));
    UserExternalSystemConfiguration userExternalSystemConfiguration =
        userService.getUserExternalSystemConfiguration(123, "oss");
    assertNotNull(userExternalSystemConfiguration.getOss());
    assertNull(userExternalSystemConfiguration.getCompassR2Id());
    assertNull(userExternalSystemConfiguration.getSecureZoneId());
  }

  @Test
  public void updateRRCodeFirmLevelAccess() {
    IamUserConfiguration iamUserConfiguration = new IamUserConfiguration();
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpSubject("idp");
    userConfiguration.setRrCodes(Arrays.asList("1234"));
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(true);
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(false);
    FeaturePackageCreateResponse featurePackageCreateResponse = new FeaturePackageCreateResponse();
    userService.updateRRCode(
        iamUserConfiguration, userConfiguration, featurePackageCreateResponse, "idp");
  }

  @Test
  public void updateRRCodeWithoutFirmLevelAccess() {
    IamUserConfiguration iamUserConfiguration = new IamUserConfiguration();
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setRrCodes(Arrays.asList("1234"));
    FeaturePackageCreateResponse featurePackageCreateResponse = new FeaturePackageCreateResponse();
    userService.updateRRCode(
        iamUserConfiguration, userConfiguration, featurePackageCreateResponse, "idp");
  }

  @Test
  public void updateRRCode_shouldThrow_whenRestrictClientDataAccessAndFirmLevelAccess() {
    IamUserConfiguration iamUserConfiguration = new IamUserConfiguration();
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpSubject("idp");
    userConfiguration.setRrCodes(Arrays.asList("1234"));
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(true);
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(true);
    FeaturePackageCreateResponse featurePackageCreateResponse = new FeaturePackageCreateResponse();
    try {
      userService.updateRRCode(
          iamUserConfiguration, userConfiguration, featurePackageCreateResponse, "idp");
      fail("Expected FumValidationException");
    } catch (FumValidationException e) {
      assertEquals(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS, e.getCode());
    }
  }

  @Test
  public void updateRRCode_shouldThrow_whenRestrictClientDataAccessAndRrCodesProvided() {
    IamUserConfiguration iamUserConfiguration = new IamUserConfiguration();
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpSubject("idp");
    userConfiguration.setRrCodes(Arrays.asList("1234"));
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(false);
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(true);
    FeaturePackageCreateResponse featurePackageCreateResponse = new FeaturePackageCreateResponse();
    try {
      userService.updateRRCode(
          iamUserConfiguration, userConfiguration, featurePackageCreateResponse, "idp");
      fail("Expected FumValidationException");
    } catch (FumValidationException e) {
      assertEquals(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE, e.getCode());
    }
  }

  @Test
  public void updateRRCode_shouldThrow_whenRestrictClientDataAccessAndRrCodeRangesProvided() {
    IamUserConfiguration iamUserConfiguration = new IamUserConfiguration();
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpSubject("idp");
    RRCodeRange rrCodeRange = new RRCodeRange();
    userConfiguration.setRrCodeRanges(Arrays.asList(rrCodeRange));
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(false);
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(true);
    FeaturePackageCreateResponse featurePackageCreateResponse = new FeaturePackageCreateResponse();
    try {
      userService.updateRRCode(
          iamUserConfiguration, userConfiguration, featurePackageCreateResponse, "idp");
      fail("Expected FumValidationException");
    } catch (FumValidationException e) {
      assertEquals(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE, e.getCode());
    }
  }

  @Test
  public void updateRRCode_shouldSucceed_whenRestrictClientDataAccessButNoRrCodesAndNoFirmLevelAccess() {
    IamUserConfiguration iamUserConfiguration = new IamUserConfiguration();
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpSubject("idp");
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(false);
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(true);
    FeaturePackageCreateResponse featurePackageCreateResponse = new FeaturePackageCreateResponse();
    userService.updateRRCode(
        iamUserConfiguration, userConfiguration, featurePackageCreateResponse, "idp");
  }

  @Test
  public void addRRCode() {
    IamUserConfiguration iamUserConfiguration = new IamUserConfiguration();
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpSubject("idp");
    userConfiguration.setRrCodes(Arrays.asList("1234"));
    RRCodeRange rrCodeRange = new RRCodeRange();
    userConfiguration.setRrCodeRanges(Arrays.asList(rrCodeRange));
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(false);
    FeaturePackageCreateResponse featurePackageCreateResponse = new FeaturePackageCreateResponse();
    userService.addRrCode(userConfiguration, "idp");
  }

  @Test
  public void addRrCode_shouldThrow_whenRestrictClientDataAccessAndFirmLevelAccess() {
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpSubject("idp");
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(true);
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(true);
    try {
      userService.addRrCode(userConfiguration, "idp");
      fail("Expected FumValidationException");
    } catch (FumValidationException e) {
      assertEquals(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS, e.getCode());
    }
  }

  @Test
  public void addRrCode_shouldThrow_whenRestrictClientDataAccessAndRrCodesProvided() {
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpSubject("idp");
    userConfiguration.setRrCodes(Arrays.asList("1234"));
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(false);
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(true);
    try {
      userService.addRrCode(userConfiguration, "idp");
      fail("Expected FumValidationException");
    } catch (FumValidationException e) {
      assertEquals(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE, e.getCode());
    }
  }

  @Test
  public void addRrCode_shouldThrow_whenRestrictClientDataAccessAndRrCodeRangesProvided() {
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpSubject("idp");
    RRCodeRange rrCodeRange = new RRCodeRange();
    userConfiguration.setRrCodeRanges(Arrays.asList(rrCodeRange));
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(false);
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(true);
    try {
      userService.addRrCode(userConfiguration, "idp");
      fail("Expected FumValidationException");
    } catch (FumValidationException e) {
      assertEquals(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE, e.getCode());
    }
  }

  @Test
  public void addRrCode_shouldSucceed_whenRestrictClientDataAccessButNoRrCodes() {
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpSubject("idp");
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(false);
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(true);
    userService.addRrCode(userConfiguration, "idp");
  }

  @Test
  public void addRrCode_shouldSucceed_whenNoRestrictClientDataAccessWithRrCodes() {
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpSubject("idp");
    userConfiguration.setRrCodes(Arrays.asList("1234"));
    when(userAssignmentService.hasUserAssignment("idp", Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(false);
    userService.addRrCode(userConfiguration, "idp");
  }

  @Test
  public void saveNewUserConfiguration() {
    IamUserConfiguration userConfiguration = new IamUserConfiguration();
    userConfiguration.setUsername(MockData.USER_NAME_LABEL);
    UserConfiguration request = new UserConfiguration();
    request.setFirmId("firmId");
    String requestedBy = "nbinu";
    Firm firm = MockData.getFirmEntity();
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.of(firm));
    when(firmRepository.findByFirmId(anyString())).thenReturn(firm);
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(userConfiguration);

    // when creating nbin user without setting idp
    IamUserConfiguration response = userService.saveNewUserConfiguration(request, requestedBy);
    assertEquals(MockData.USER_NAME_LABEL, response.getUsername());
    verify(iamUserConfigurationRepository, times(2)).save(any(IamUserConfiguration.class));

    // when creating nbin user with setting idp
    clearInvocations(iamUserConfigurationRepository);
    request.setIdp("nbin");
    request.setIdentityLastUpdatedDate(LocalDateTime.now());
    userService.saveNewUserConfiguration(request, requestedBy);
    verify(iamUserConfigurationRepository, times(2)).save(any(IamUserConfiguration.class));

    // when creating nbc user
    clearInvocations(iamUserConfigurationRepository);
    request.setIdp("nbc");
    userService.saveNewUserConfiguration(request, requestedBy);
    verify(iamUserConfigurationRepository, times(2)).save(any(IamUserConfiguration.class));

    // when creating other user
    clearInvocations(iamUserConfigurationRepository);
    request.setIdp("cpx");
    userService.saveNewUserConfiguration(request, requestedBy);
    verify(iamUserConfigurationRepository, times(2)).save(any(IamUserConfiguration.class));
  }

  @Test
  public void saveNewUserConfiguration_givenDataIntegrityError_shouldThrowFumConflictException() {
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenThrow(new DataIntegrityViolationException("Duplicate entry for user"));

    FumConflictException exception =
        Assertions.assertThrows(
            FumConflictException.class,
            () -> userService.saveNewUserConfiguration(MockData.getUserConfiguration(), "requestedBy"));
    assertEquals(Constants.ERROR_CODE_CREATE_USER, exception.getCode());
    assertEquals(Constants.ERROR_USER_ALREADY_EXISTS, exception.getMessage());
  }

  @Test
  public void saveNewUserConfiguration_whenEmployeeIdp_shouldPersistShortIdUpperCase() {
    // The BEFORE INSERT trigger cannot carry this on its own: the second save() below is a full
    // UPDATE that writes the entity's in-memory identity fields back over the normalised row, and
    // it must not re-derive a prefixed "<identitySource>_<externalClientId>" (NWPI-14901).
    UserConfiguration request = new UserConfiguration();
    request.setFirmId("firmId");
    request.setIdp(Constants.EMPLOYEE_IDP);
    request.setUsername("  raza002  ");
    request.setIdpSubject("raza002");
    request.setBngfReferenceId("raza002");
    request.setExternalClientId("raza002");
    Firm firm = MockData.getFirmEntity();
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.of(firm));
    when(firmRepository.findByFirmId(anyString())).thenReturn(firm);
    // The service mutates and re-saves the same instance, so snapshot the identity fields on each
    // call — an ArgumentCaptor would hand back the final state twice and hide a reverted UPDATE.
    List<List<String>> savedIdentities = new ArrayList<>();
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenAnswer(invocation -> {
          IamUserConfiguration entity = invocation.getArgument(0);
          savedIdentities.add(Arrays.asList(
              entity.getUsername(), entity.getIdpSubject(), entity.getBngfReferenceId()));
          return entity;
        });

    userService.saveNewUserConfiguration(request, "requestedBy");

    assertEquals(2, savedIdentities.size());
    savedIdentities.forEach(identity ->
        assertEquals(Arrays.asList("RAZA002", "RAZA002", "RAZA002"), identity));
  }

  @Test
  public void saveNewUserConfiguration_whenNonEmployeeIdp_shouldNotChangeUsernameCase() {
    UserConfiguration request = new UserConfiguration();
    request.setFirmId("firmId");
    request.setIdp(Constants.CPX_IDP);
    request.setUsername("MiXeD.Case");
    Firm firm = MockData.getFirmEntity();
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.of(firm));
    when(firmRepository.findByFirmId(anyString())).thenReturn(firm);
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenAnswer(invocation -> invocation.getArgument(0));

    userService.saveNewUserConfiguration(request, "requestedBy");

    ArgumentCaptor<IamUserConfiguration> captor =
        ArgumentCaptor.forClass(IamUserConfiguration.class);
    verify(iamUserConfigurationRepository, atLeastOnce()).save(captor.capture());
    assertEquals("MiXeD.Case", captor.getValue().getUsername());
  }

  @Test(expected = FumServiceException.class)
  public void saveNewUserConfiguration_givenUnexpectedError_shouldThrowFumServiceException() {
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenThrow(new RuntimeException("Error"));

    userService.saveNewUserConfiguration(MockData.getUserConfiguration(), "requestedBy");
  }

  @Test
  public void publishUserCreationMessage() {
    UserConfiguration user = new UserConfiguration();
    Date d = new Date();
    user.setActivationDate(new java.sql.Timestamp(d.getTime()).toLocalDateTime());
    userService.publishUserCreationMessage(user);
  }

  @Test
  public void publishUserCreationMessage_whenR2IdNotProvided() {
    UserConfiguration user = MockData.getUserConfiguration();
    user.setCompassR2Id(null);
    userService.publishUserCreationMessage(user);
    verify(userConfigEventProducerService, times(1)).publishMessage(any());
  }

  @Test
  public void publishUserCreationMessage_whenR2IdProvided() {
    UserConfiguration user = MockData.getUserConfiguration();
    user.setCompassR2Id("r2Id");
    userService.publishUserCreationMessage(user);
    verify(userConfigEventProducerService, times(1)).publishMessage(any());
  }

  @Test
  public void createUser() {
    IamUserConfiguration userConfiguration = new IamUserConfiguration();
    userConfiguration.setUserConfigurationId(1l);
    userConfiguration.setUsername(MockData.USER_NAME_LABEL);

    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(userConfiguration);
    UserConfiguration user = new UserConfiguration();
    Date d = new Date();
    user.setActivationDate(new java.sql.Timestamp(d.getTime()).toLocalDateTime());
    user.setIdp("test");
    user.setFirmId("test");
    user.setAccessProfileSet(true);
    Firm firm = MockData.getFirmEntity();
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.of(firm));
    when(firmRepository.findByFirmId(anyString())).thenReturn(firm);
    doNothing()
        .when(userAssignmentService)
        .assignFirmToUser(anyLong(), anyString(), anyLong(), anyString());
    setMockUser(false);
    UserConfiguration response = userService.createUserForNonNbin(user, "username");
    assertEquals(1, response.getUserConfigurationId().intValue());
  }

  private void setMockUser(boolean isSystemToken) {
    User user = new User();
    user.setSystemToken(isSystemToken);
    user.setGroups(List.of("Wealth.CompassX.ManageFirm"));

    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken =
        new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>());
    SecurityContext securityContext = mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(usernamePasswordAuthenticationToken);
    SecurityContextHolder.setContext(securityContext);
  }

  @Test(expected = Exception.class)
  public void updateUserForNonNbin_UserNotFound() {
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(Optional.empty());
    userService.updateUserForNonNbin(new UserConfiguration(), 12, "user", null);
  }

  @Test(expected = Exception.class)
  public void updateUserForNonNbin_updatingIdpSubject() {
    IamUserConfiguration userConfiguration = new IamUserConfiguration();
    userConfiguration.setUserConfigurationId(1l);
    userConfiguration.setUsername(MockData.USER_NAME_LABEL);
    userConfiguration.setIdpSubject("idp1");
    when(iamUserConfigurationRepository.findById(anyLong()))
        .thenReturn(Optional.of(userConfiguration));
    userService.updateUserForNonNbin(new UserConfiguration(), 12, "user", null);
  }

  @Test(expected = Exception.class)
  public void updateUserForNonNbin_outofRangeRrcode() {
    IamUserConfiguration userConfiguration = new IamUserConfiguration();
    userConfiguration.setUserConfigurationId(1l);
    userConfiguration.setUsername(MockData.USER_NAME_LABEL);
    userConfiguration.setIdpSubject("idp1");
    UserConfiguration request = new UserConfiguration();
    request.setRrCodes(Arrays.asList("AAAA"));
    request.setIdpSubject("idp1");
    when(iamUserConfigurationRepository.findById(anyLong()))
        .thenReturn(Optional.of(userConfiguration));
    when(iamUserConfigurationRepository.save(any())).thenReturn(userConfiguration);
    when(userAssignmentService.getUserAssignment(anyString(), any()))
        .thenReturn(Collections.emptyList());
    userService.updateUserForNonNbin(request, 12, "user", null);
  }

  @Test
  public void updateUserForNonNbin() {
    IamUserConfiguration userConfiguration = new IamUserConfiguration();
    userConfiguration.setUserConfigurationId(1l);
    userConfiguration.setUsername(MockData.USER_NAME_LABEL);
    userConfiguration.setIdpSubject("idp1");
    UserConfiguration request = new UserConfiguration();
    request.setIdpSubject("idp1");
    when(iamUserConfigurationRepository.findById(anyLong()))
        .thenReturn(Optional.of(userConfiguration));
    when(iamUserConfigurationRepository.save(any())).thenReturn(userConfiguration);
    when(userAssignmentService.getUserAssignment(anyString(), any()))
        .thenReturn(Collections.emptyList());
    userService.updateUserForNonNbin(request, 12, "user", null);
  }

  @Test
  public void updateUserForNonNbin_withFeaturePackage_assignsFeaturePackageToUser() {
    IamUserConfiguration userConfiguration = new IamUserConfiguration();
    userConfiguration.setUserConfigurationId(1l);
    userConfiguration.setUsername(MockData.USER_NAME_LABEL);
    userConfiguration.setIdpSubject("idp1");
    UserConfiguration request = new UserConfiguration();
    request.setIdpSubject("idp1");
    FeaturePackageCreateResponse featurePackageCreateResponse = new FeaturePackageCreateResponse();
    featurePackageCreateResponse.setFeaturePackageId(999L);
    when(iamUserConfigurationRepository.findById(anyLong()))
        .thenReturn(Optional.of(userConfiguration));
    when(iamUserConfigurationRepository.save(any())).thenReturn(userConfiguration);
    when(userAssignmentService.getUserAssignment(anyString(), any()))
        .thenReturn(Collections.emptyList());
    doNothing()
        .when(userAssignmentService)
        .assignFeaturePackageToUser(anyLong(), anyString(), anyLong(), anyString());

    userService.updateUserForNonNbin(request, 12, "user", featurePackageCreateResponse);

    verify(userAssignmentService, times(1)).assignFeaturePackageToUser(1L, "idp1", 999, "user");
  }

  @Test
  public void getRecoveryQuestions() {
    when(namedParameterJdbcTemplate.queryForList(anyString(), any(SqlParameterSource.class)))
            .thenReturn(List.of(MockData.getUserConfigurationMap()));
    Map<String, Object> recoveryQuestionMap =
        Map.of(
            "CONTENT_TRANSLATION_ID", 1,
            "TRANSLATION_KEY", "key",
            "TRANSLATION_VALUE", "value",
            "LANGUAGE", "EN",
            "CREATED_BY", "CREATED_BY",
            "CREATED_DT", new Timestamp(System.currentTimeMillis()),
            "UPDATED_BY", "UPDATED_BY",
            "UPDATED_DT", new Timestamp(System.currentTimeMillis()));
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_RECOVERY_QUESTIONS_BY_LANGUAGE_QUERY), any(SqlParameterSource.class)))
        .thenReturn(List.of(recoveryQuestionMap));
    Map<String, String> result = userService.getRecoveryQuestions("EN", "idpSubject");
    assertTrue(result.containsKey(String.valueOf(recoveryQuestionMap.get("TRANSLATION_KEY"))));
    assertEquals(
        String.valueOf(recoveryQuestionMap.get("TRANSLATION_VALUE")),
        result.get(String.valueOf(recoveryQuestionMap.get("TRANSLATION_KEY"))));

    // should not throw exception when acceptLanguage is null or FR
    userService.getRecoveryQuestions(null, "idpSubject");
    userService.getRecoveryQuestions("FR", "idpSubject");
  }

  @Test(expected = FumNotFoundException.class)
  public void getRecoveryQuestions_whenRecoveryQuestionsNotFound_shouldThrowFumNotFoundException() {
    when(namedParameterJdbcTemplate.queryForList(anyString(), any(SqlParameterSource.class)))
            .thenReturn(List.of(MockData.getUserConfigurationMap()));
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_RECOVERY_QUESTIONS_BY_LANGUAGE_QUERY), any(SqlParameterSource.class)))
        .thenReturn(new ArrayList<>());
    userService.getRecoveryQuestions("EN", "idpSubject");
  }

  @Test(expected = IllegalArgumentException.class)
  public void getRecoveryQuestions_whenRecoveryQuestionsForNonNbinUser_shouldThrowIllegalArgumentException() {
    when(namedParameterJdbcTemplate.queryForList(anyString(), any(SqlParameterSource.class)))
            .thenReturn(List.of(MockData.getUserConfigurationMapForNonNbin()));
    userService.getRecoveryQuestions("EN", "idpSubject");
  }

  @Test
  public void getOktaProfile_whenValidIdpSubject_shouldReturnOktaProfile() {
    OktaUserProfile oktaUserProfile = new OktaUserProfile();
    oktaUserProfile.setId("id");
    when(iamUserConfigurationRepository.findById(any()))
        .thenReturn(Optional.of(MockData.getIamUserConfigurationEntity()));
    when(ciamService.getOktaUserProfile(any())).thenReturn(oktaUserProfile);

    UserOktaProfile response = userService.getOktaProfile("1111");
    assertEquals(oktaUserProfile.getId(), response.getId());
  }

  @Test
  public void getOktaProfile_whenValidUsername_shouldReturnOktaProfile() {
    OktaUserProfile oktaUserProfile = new OktaUserProfile();
    oktaUserProfile.setId("id");
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(any()))
        .thenReturn(Optional.of(MockData.getIamUserConfigurationEntity()));
    when(ciamService.getOktaUserProfile(any())).thenReturn(oktaUserProfile);

    UserOktaProfile response = userService.getOktaProfile("username");
    assertEquals(oktaUserProfile.getId(), response.getId());
  }

  @Test
  public void getOktaProfile_whenIdpSubjectIsDifferentThanUsername_shouldReturnOktaProfile() {
    OktaUserProfile oktaUserProfile = new OktaUserProfile();
    oktaUserProfile.setId("id");
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(any()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(any()))
        .thenReturn(Optional.of(MockData.getIamUserConfigurationEntity()));
    when(ciamService.getOktaUserProfile(any())).thenReturn(oktaUserProfile);

    UserOktaProfile response = userService.getOktaProfile("idpSubject");
    assertEquals(oktaUserProfile.getId(), response.getId());
  }

  @Test(expected = FumNotFoundException.class)
  public void getOktaProfile_whenUsernameNotFound_shouldThrowFumNotFoundExceptionException() {
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(any()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(any()))
        .thenReturn(Optional.empty());
    userService.getOktaProfile("username");
  }

  @Test(expected = NoResultsFoundException.class)
  public void getOktaProfile_whenOktaProfileNotFound_shouldThrowNoResultFoundException() {
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(any()))
        .thenReturn(Optional.of(MockData.getIamUserConfigurationEntity()));
    when(ciamService.getOktaUserProfile(any())).thenThrow(NoResultsFoundException.class);
    userService.getOktaProfile("username");
  }

  @Test(expected = ServiceException.class)
  public void getOktaProfile_whenUnableToProcessOktaProfile_shouldServiceException()
      throws Exception {
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(any()))
        .thenReturn(Optional.of(MockData.getIamUserConfigurationEntity()));
    when(ciamService.getOktaUserProfile(any())).thenReturn(new OktaUserProfile());
    when(objectMapper.writeValueAsString(any())).thenThrow(JacksonException.class);
    userService.getOktaProfile("username");
  }

  @Test
  public void getOktaProfileOrEmpty_whenEmployeeUserHasNoIdpUserId_shouldReturnEmptyProfileWithoutCallingCiam() {
    IamUserConfiguration employee = new IamUserConfiguration();
    employee.setIdpUserIdentifier(null);
    when(iamUserConfigurationRepository.findById(any())).thenReturn(Optional.of(employee));

    UserOktaProfile response = userService.getOktaProfileOrEmpty("1111");

    assertNotNull(response);
    assertNull(response.getId());
    verify(ciamService, never()).getOktaUserProfile(anyString());
    verify(userStateService, never()).updateStateForDeletedOktaProfile(any());
  }

  @Test(expected = FumNotFoundException.class)
  public void getOktaProfile_whenEmployeeUserHasNoIdpUserId_shouldThrowNotFoundWithoutCallingCiam() {
    IamUserConfiguration employee = new IamUserConfiguration();
    employee.setIdpUserIdentifier(null);
    when(iamUserConfigurationRepository.findById(any())).thenReturn(Optional.of(employee));

    try {
      userService.getOktaProfile("1111");
    } finally {
      verify(ciamService, never()).getOktaUserProfile(anyString());
      verify(userStateService, never()).updateStateForDeletedOktaProfile(any());
    }
  }

  @Test
  public void getSecureZoneId_whenIdpUserIdBlank_shouldReturnNullWithoutCallingCiam() {
    assertNull(userService.getSecureZoneId(""));
    assertNull(userService.getSecureZoneId(null));
    verify(ciamService, never()).getOktaUserProfile(anyString());
  }

  /** Mimics Spring's cache SpEL root so {@code #root.getTarget()} resolves during evaluation. */
  private static class CacheConditionRoot {
    private final Object target;

    CacheConditionRoot(Object target) {
      this.target = target;
    }

    public Object getTarget() {
      return target;
    }
  }

  @Test
  public void getSecureZoneIdCacheCondition_shouldDisableCacheForNullOrBlankIdpUserId()
      throws Exception {
    // getSecureZoneId is @Cacheable with key "#idpUserId". Employee users have a null idpUserId,
    // which makes Spring throw "Null key returned for cache operation". The condition must disable
    // caching for null/blank idpUserId while still caching for real Okta users. This reads the
    // actual annotation so the test stays in lock-step with the production condition.
    Cacheable cacheable =
        UserService.class.getMethod("getSecureZoneId", String.class).getAnnotation(Cacheable.class);
    assertNotNull(cacheable);
    Expression condition = new SpelExpressionParser().parseExpression(cacheable.condition());

    FieldUtils.writeField(userService, "enableCache", true, true);
    StandardEvaluationContext context =
        new StandardEvaluationContext(new CacheConditionRoot(userService));

    context.setVariable("idpUserId", null);
    assertEquals(Boolean.FALSE, condition.getValue(context, Boolean.class));
    context.setVariable("idpUserId", "");
    assertEquals(Boolean.FALSE, condition.getValue(context, Boolean.class));
    context.setVariable("idpUserId", "   ");
    assertEquals(Boolean.FALSE, condition.getValue(context, Boolean.class));
    context.setVariable("idpUserId", "idp-user-123");
    assertEquals(Boolean.TRUE, condition.getValue(context, Boolean.class));
  }

  @Test
  public void getUserConfigurationByUserIds() {
    IamUserConfiguration uc2 = new IamUserConfiguration();
    uc2.setIdpSubject("def");
    uc2.setUserConfigurationId(2l);
    uc2.setActive(true);
    uc2.setPreferredLanguageType(PreferredLanguageType.EN);
    IamUserConfiguration uc4 = new IamUserConfiguration();
    uc4.setIdpSubject("456");
    uc4.setUserConfigurationId(456l);
    uc4.setActive(true);
    uc4.setPreferredLanguageType(PreferredLanguageType.EN);
    when(iamUserConfigurationRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(uc2, uc4));

    List<UserConfiguration> response =
        userService.getUserConfigurationByUserIds(List.of("abc", "def"), "idp");
    assertEquals(2, response.size());
  }

  @Test
  public void getUserLastUpdatedDateByIdpSubject_whenUserExists_shouldReturnUserLastUpdateDate() {
    Map<String, Object> userMap = MockData.getUserConfigurationMap();
    userMap.put("LAST_UPDATE_DATE", "2024-03-20 14:54:06.821");
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_USER_LAST_UPDATE_DATE_BY_IDP_SUBJECT_QUERY),
            any(SqlParameterSource.class)))
        .thenReturn(List.of(userMap));
    assertEquals(
        "2024-03-20T14:54:06.821", userService.getUserLastUpdatedDateByIdpSubject("idpSubject"));
  }

  @Test
  public void getUserLastUpdatedDateByIdpSubject_whenUserNotUpdated_shouldReturnNull() {
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_USER_LAST_UPDATE_DATE_BY_IDP_SUBJECT_QUERY),
            any(SqlParameterSource.class)))
        .thenReturn(List.of(MockData.getUserConfigurationMap()));
    assertNull(userService.getUserLastUpdatedDateByIdpSubject("idpSubject"));
  }

  @Test(expected = FumNotFoundException.class)
  public void
      getUserLastUpdatedDateByIdpSubject_whenUserDoesNotExists_shouldThrowFumNotFoundException() {
    when(namedParameterJdbcTemplate.queryForList(
            eq(Constants.GET_USER_LAST_UPDATE_DATE_BY_IDP_SUBJECT_QUERY),
            any(SqlParameterSource.class)))
        .thenReturn(new ArrayList<>());
    userService.getUserLastUpdatedDateByIdpSubject("idpSubject");
  }

  @Test
  public void idpStatusUpdateSchedule() {
    IamUserConfiguration user = new IamUserConfiguration();
    user.setIdpUserIdentifier("idp");
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(Optional.of(user));
    when(ciamService.getOktaUserProfile(anyString(), anyInt()))
        .thenReturn(Optional.of(new OktaUserProfile()));
    userService.idpStatusUpdateSchedule(1);
  }

  @Test
  public void testIsValidFirmId_whenFirmIdIsNullOrEmpty_shouldReturnTrue() {
    assertTrue(userService.isValidFirmId(null));
    assertTrue(userService.isValidFirmId(" "));
  }

  @Test
  public void testIsValidFirmId_whenFirmIdIsNumberOrStringAndFirmExist_shouldReturnTrue() {
    when(firmRepository.existsById(anyLong())).thenReturn(true);
    assertTrue(userService.isValidFirmId("123"));

    when(firmRepository.exists(any(Specification.class))).thenReturn(true);
    assertTrue(userService.isValidFirmId("NBIN"));
  }

  @Test(expected = ServiceException.class)
  public void testGenericUserSearchWithPagination_whenNoFirmExist_shouldThrowServiceException() {
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.empty());
    userService.genericUserSearchWithPagination(MockData.IDP_USER_SUB, new GenericSearch());
  }

  @Test
  public void testGenericUserSearchWithPagination_whenFirmExist_shouldReturnGenericSearchResponse() {
    Firm mockFirm = MockData.getFirmEntity();
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.of(mockFirm));
    when(firmRepository.findByFirmId(anyString())).thenReturn(mockFirm);
    GenericSearchResponse response = userService.genericUserSearchWithPagination(MockData.IDP_USER_SUB, new GenericSearch());
    assertNotNull(response);
  }

  @Test
  public void testGenericUserSearchWithPagination_whenFirmExistAndUserSearchIsPopulated_shouldReturnGenericSearchResponse() {
    Firm mockFirm = MockData.getFirmEntity();
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.of(mockFirm));
    when(firmRepository.findByFirmId(anyString())).thenReturn(mockFirm);
    GenericSearch userSearch = new GenericSearch();
    userSearch.setFirmId("NBIN");
    userSearch.pageSize(3);
    userSearch.setSearchText("NBIN");
    GenericSearchResponse response = userService.genericUserSearchWithPagination(MockData.IDP_USER_SUB, userSearch);
    assertNotNull(response);
  }

  @Test
  public void createUserForNonNbin() {
    IamUserConfiguration userConfiguration = new IamUserConfiguration();
    userConfiguration.setUserConfigurationId(1l);
    userConfiguration.setUsername(MockData.USER_NAME_LABEL);

    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(userConfiguration);
    UserConfiguration user = new UserConfiguration();
    Date d = new Date();
    user.setActivationDate(new java.sql.Timestamp(d.getTime()).toLocalDateTime());
    user.setIdp("test");
    user.setFirmId("test");
    user.setAccessProfileSet(true);
    user.setOssId(MockData.OSS_ID);
    user.setOssProxyId(null);
    user.setIdp("indall");
    Firm firm = MockData.getFirmEntity();
    when(firmServiceHelper.getPrimaryFirm(anyString(), eq(null))).thenReturn(Optional.of(firm));
    when(firmRepository.findByFirmId(anyString())).thenReturn(firm);
    doNothing()
        .when(userAssignmentService)
        .assignFirmToUser(anyLong(), anyString(), anyLong(), anyString());
    setMockUser(false);
    when(firmRepository.findByIdentitySource(anyString())).thenReturn(MockData.getFirmEntity());
    UserConfiguration response = userService.createUserForNonNbin(user, "username");
    assertEquals(1, response.getUserConfigurationId().intValue());
  }

  @Test(expected = FumNotFoundException.class)
  public void testUpdateUserIdentityForExternalSSOUsers_UserDoesNotExist_shouldThrowFumNotFoundException() {
    userService.updateUserIdentityForExternalSSOUsers(new UserConfiguration(), 123, "system");
  }

  @Test(expected = FumValidationException.class)
  public void testUpdateUserIdentityForExternalSSOUsers_UserDoesNotMatch_shouldThrowFumValidationException() {
    IamUserConfiguration mockUserConfiguration = MockData.getIamUserConfigurationEntity();
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(
        Optional.of(mockUserConfiguration));
    userService.updateUserIdentityForExternalSSOUsers(new UserConfiguration(), 123, "system");
  }

  @Test
  public void testUpdateUserIdentityForExternalSSOUsers_UserIsValid_shouldSaveUserConfiguration() {
    IamUserConfiguration mockUserConfiguration = MockData.getIamUserConfigurationEntity();
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setIdpSubject(mockUserConfiguration.getIdpSubject());
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(
        Optional.of(mockUserConfiguration));
    try{
      userService.updateUserIdentityForExternalSSOUsers(userConfiguration, 123, "system");
    } catch (Exception e) {
      fail("This test should not fail");
    }
  }

  @Test(expected = FumNotFoundException.class)
  public void testUpdateUserAccessForExternalSSOUsers_UserDoesNotExist_shouldThrowFumNotFoundException() {
    userService.updateUserAccessForExternalSSOUsers(123, MockData.IDP_USER_SUB, new UserConfiguration(),
        new FeaturePackageCreateResponse());
  }

  @Test
  public void testUpdateUserAccessForExternalSSOUsers_UserExists_shouldUpdateUser() {
    IamUserConfiguration mockUserConfiguration = MockData.getIamUserConfigurationEntity();
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setIdpSubject(mockUserConfiguration.getIdpSubject());
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(
        Optional.of(mockUserConfiguration));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class))).thenReturn(mockUserConfiguration);
    when(userGroupRepository.findAll(any(Specification.class))).thenReturn(Arrays.asList(MockData.getUserGroupEntity()));
    doNothing().when(userAssignmentService).assignFeaturePackageToUser(anyLong(), anyString(), anyLong(), anyString());
    userService.updateUserAccessForExternalSSOUsers(123, MockData.IDP_USER_SUB, userConfiguration,
        MockData.getFeaturePackageCreateResponse());
  }

  @Test(expected = FumNotFoundException.class)
  public void testUpdateUserConfigurationByUserId_UserDoesNotExist_shouldThrowFumNotFoundException() {
    userService.updateUserConfigurationByUserId(123, MockData.IDP_USER_SUB, new UserConfiguration(),
        new FeaturePackageCreateResponse());
  }

  @Test
  public void testUpdateUserConfigurationByUserId_UserExists_shouldUpdateUser() {
    IamUserConfiguration mockUserConfiguration = MockData.getIamUserConfigurationEntity();
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setIdpSubject(mockUserConfiguration.getIdpSubject());
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(
        Optional.of(mockUserConfiguration));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class))).thenReturn(mockUserConfiguration);
    when(userGroupRepository.findAll(any(Specification.class))).thenReturn(Arrays.asList(MockData.getUserGroupEntity()));
    doNothing().when(userAssignmentService).assignFeaturePackageToUser(anyLong(), anyString(), anyLong(), anyString());
    try {
      userService.updateUserConfigurationByUserId(123, MockData.IDP_USER_SUB, userConfiguration,
          MockData.getFeaturePackageCreateResponse());
    } catch (Exception e) {
      fail("This test should not fail");
    }
  }

  @Test
  public void testUpdateUserLanguage_whenIUserExist_shouldSaveUserAndDeleteFromCache() {
    IamUserConfiguration mockUserConfiguration = MockData.getIamUserConfigurationEntity();

    when(iamUserConfigurationRepository.findByIdpSubject(anyString())).thenReturn(mockUserConfiguration);
    when(iamUserConfigurationRepository.save(any())).thenReturn(mockUserConfiguration);

    UserConfiguration userConfiguration = userService.updateUserLanguage(MockData.IDP_USER_SUB, PreferredLanguageType.EN);
    assertEquals(mockUserConfiguration.getUserConfigurationId().intValue(),
        userConfiguration.getUserConfigurationId());
    assertEquals(mockUserConfiguration.getIdpSubject(), userConfiguration.getIdpSubject());
    assertEquals(mockUserConfiguration.getPreferredLanguageType().name(),
        userConfiguration.getPreferredLanguage());
  }

  @Test
  public void testDeleteUser2FA_whenUserExist_shouldDeleteUser2FA() {
    when(iamUserConfigurationRepository.findById(anyLong()))
        .thenReturn(Optional.of(MockData.getIamUserConfigurationEntity()));
    try {
      userService.deleteUser2FA("123");
    } catch (Exception e) {
      fail("This test should not fail");
    }
  }

  @Test
  public void testResetPassword_whenTempPasswordIsNotNull_shouldResetPassword() {
    UserCredentials mockCredentials = MockData.getUserCredentials();
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(
        Optional.of(MockData.getIamUserConfigurationEntity()));
    try {
      userService.resetPassword("123", mockCredentials);
    } catch (Exception e) {
      fail("This test should not fail");
    }
  }

  @Test
  public void testResetPassword_whenTempPasswordIsNull_shouldResetPassword() {
    UserCredentials mockCredentials = MockData.getUserCredentials();
    mockCredentials.setTempPassword(null);
    when(iamUserConfigurationRepository.findById(anyLong())).thenReturn(
        Optional.of(MockData.getIamUserConfigurationEntity()));
    try {
      userService.resetPassword("123", mockCredentials);
    } catch (Exception e) {
      fail("This test should not fail");
    }
  }

  @Test
  public void testDeleteUserConfigurationByUserId_whenUserExist_shouldDeleteUser() {
    when(iamUserConfigurationRepository.getReferenceById(anyLong()))
        .thenReturn(MockData.getIamUserConfigurationEntity());
    try {
      userService.deleteUserConfigurationByUserId("system", 123);
    } catch (Exception e) {
      fail("This test should not fail");
    }
  }

  @Test
  public void testUnsuspendUserOktaProfile() {
    IamUserConfiguration suspendedUser = MockData.getIamUserConfigurationEntity();
    suspendedUser.setActive(false);
    suspendedUser.setState(INACTIVE);
    suspendedUser.setStateDescription(SUSPENDED.dbValue);
    suspendedUser.setStateAction(null);
    when(iamUserConfigurationRepository.findById(anyLong()))
        .thenReturn(Optional.of(suspendedUser));
    try {
      userService.unsuspendUserOktaProfile(new UserConfiguration());
    } catch (Exception e) {
      fail("This test should not fail");
    }
  }

  @Test(expected = FumValidationException.class)
  public void testValidateIsUserSuspended_whenUserStateIsNotSuspended_shouldThrowFumValidationException() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setStatus(INACTIVE);
    userConfiguration.setState(ACTIVE);
    userService.validateIsUserSuspended(userConfiguration);
  }

  @Test(expected = FumValidationException.class)
  public void testValidateIsUserSuspended_whenUserStateDescriptionIsNotSuspended_shouldThrowFumValidationException() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setStateDescription(UserStateActionEnum.ACTIVE.dbValue);
    userConfiguration.setState(INACTIVE);
    userConfiguration.setStatus(INACTIVE);
    userService.validateIsUserSuspended(userConfiguration);
  }

  @Test(expected = FumValidationException.class)
  public void testValidateIsUserSuspended_whenUserIsNotSuspended_shouldThrowFumValidationException() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userService.validateIsUserSuspended(userConfiguration);
  }

  @Test
  public void testValidateIsUserSuspended_whenUserIsSuspended_shouldNotThrowFumValidationException() {
    UserConfiguration userConfiguration = MockData.getUserConfiguration();
    userConfiguration.setStateDescription(SUSPENDED.dbValue);
    userConfiguration.setState(INACTIVE);
    userConfiguration.setStatus(INACTIVE);
    try {
      userService.validateIsUserSuspended(userConfiguration);
    } catch(Exception e) {
      fail("This test should not fail");
    }
  }

  @Test
  public void testUpdateLastLoginDate_whenUserExist_shouldUpdateLastLoginDate() {
    when(iamUserConfigurationRepository.findByIdpSubject(anyString()))
        .thenReturn(MockData.getIamUserConfigurationEntity());
    try {
      userService.updateLastLoginDate("123");
    } catch (Exception e) {
      fail("This test should not fail");
    }
  }

  @Test(expected = FumNotFoundException.class)
  public void testUpdateLastLoginDate_whenUserDoesNotExist_shouldThrowFumNotFoundException() {
    userService.updateLastLoginDate("123");
  }

  @Test
  public void testUpdateLastUpdatedBy_whenUserExist_shouldUpdateLastUpdatedBy() {
    when(iamUserConfigurationRepository.findById(anyLong()))
            .thenReturn(Optional.ofNullable(MockData.getIamUserConfigurationEntity()));
    try {
      userService.updateLastUpdatedBy(123, "112341");
    } catch (Exception e) {
      fail("This test should not fail " + e);
    }
  }

  @Test(expected = FumNotFoundException.class)
  public void testUpdateLastUpdatedBy_whenUserDoesNotExist_shouldThrowFumNotFoundException() {
      userService.updateLastUpdatedBy(123, "112341");
  }

  @Test
  @SneakyThrows
  public void getUserPreferences() {
    Map<String, Object> userConf = MockData.getUserConfigurationMap();
    Map<String, String> userPreferences = new HashMap<>();
    userPreferences.put("defaultModule23", "m1");
    ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().build();
    userConf.put("USER_PREFERENCES", objectMapper.writeValueAsString(userPreferences));
    Map<String, String> firmPreferences = new HashMap<>();
    firmPreferences.put("defaultModule", "m1");
    userConf.put("FIRM_PREFERENCES", objectMapper.writeValueAsString(firmPreferences));

    when(namedParameterJdbcTemplate.queryForList(anyString(), any(SqlParameterSource.class)))
        .thenReturn(List.of(userConf));
    UserConfiguration userConfiguration = userService.getUserConfiguration("123");
    assertNotNull(userConfiguration.getUserConfigurationId());

    userPreferences = new HashMap<>();
    userPreferences.put("defaultModule", "m1");
    objectMapper = JsonMapper.builderWithJackson2Defaults().build();
    userConf.put("USER_PREFERENCES", objectMapper.writeValueAsString(userPreferences));
    firmPreferences = new HashMap<>();
    firmPreferences.put("defaultModule", "m1");
    userConf.put("FIRM_PREFERENCES", objectMapper.writeValueAsString(firmPreferences));

    when(namedParameterJdbcTemplate.queryForList(anyString(), any(SqlParameterSource.class)))
        .thenReturn(List.of(userConf));
    userConfiguration = userService.getUserConfiguration("123");
    assertNotNull(userConfiguration.getUserConfigurationId());

    userPreferences = new HashMap<>();
    userPreferences.put("defaultModule123", "m1");
    objectMapper = JsonMapper.builderWithJackson2Defaults().build();
    userConf.put("USER_PREFERENCES", objectMapper.writeValueAsString(userPreferences));
    firmPreferences = new HashMap<>();
    firmPreferences.put("defaultModule123", "m1");
    userConf.put("FIRM_PREFERENCES", objectMapper.writeValueAsString(firmPreferences));

    when(namedParameterJdbcTemplate.queryForList(anyString(), any(SqlParameterSource.class)))
        .thenReturn(List.of(userConf));
    userConfiguration = userService.getUserConfiguration("123");
    assertNotNull(userConfiguration.getUserConfigurationId());

  }

  @Test
  public void getUserConfigurationFromTableByUserId() {

    when(iamUserConfigurationRepository.getReferenceById(anyLong()))
        .thenReturn(MockData.getIamUserConfigurationEntity());
    when(userAssignmentService.getUserAssignment(anyString(), eq(UserAssignmentType.F)))
        .thenReturn(Collections.singletonList(MockData.getUserAssignmentFirmEntityList().get(0)));
    when(userAssignmentService.getUserAssignment(anyString(), eq(UserAssignmentType.G)))
        .thenReturn(Collections.emptyList());

    UserConfiguration userConfiguration = userService.getUserConfigurationFromTableByUserId(1l);
    assertNotNull(userConfiguration);
    assertEquals(1234, userConfiguration.getUserConfigurationId());
  }

  @Test
  public void getIdpSubjectFromPrincipalOrUserToken_userToken() {
    User user = new User();
    user.setIdpSubject("idpSubject");
    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken =
        new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>());
    SecurityContext securityContext = mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(usernamePasswordAuthenticationToken);
    SecurityContextHolder.setContext(securityContext);
    assertEquals("idpSubject", userService.getIdpSubjectFromPrincipalOrUserToken(null));
  }

  @Test
  public void getIdpSubjectFromPrincipalOrUserToken_systemTokenWithoutUserToken() {
    User user = new User();
    user.setIdpSubject("idpSubject");
    user.setSystemToken(true);
    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken =
        new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>());
    SecurityContext securityContext = mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(usernamePasswordAuthenticationToken);
    SecurityContextHolder.setContext(securityContext);
    assertNull(userService.getIdpSubjectFromPrincipalOrUserToken(null));
  }

  @Test
  public void getIdpSubjectFromPrincipalOrUserToken_systemTokenWithUserToken() {
    User user = new User();
    user.setIdpSubject("idpSubject");
    user.setSystemToken(true);
    String usertoken = "eyJraWQiOiJiX0ktTk1QZElmSkR0VnNHTDNnY1BWZ01OdlF6T2x2TERYZnRsRGNfS0s0IiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULkFFMWdUdG5qZkFNeDEwNW1Hcy1MZ0ZOUkUwSVBnRXV4NWJLd3d0MTJFeDQiLCJpc3MiOiJodHRwczovL2F1dGgtcHAubmJpbi5jYS9vYXV0aDIvYXVzc2c0d3lkMkhaRUJHUjMwaDciLCJhdWQiOiJhcGk6Ly9kZWZhdWx0IiwiaWF0IjoxNzM0OTg5Mjg5LCJleHAiOjE3MzQ5OTAxODksImNpZCI6IjBvYTEwcmd6cThyTDNsQ1pHMGg4IiwidWlkIjoiMDB1MW90cXB4ZHhPa2VKdGYwaDgiLCJzY3AiOlsiY2lhbTpwcm9maWxlczp3cml0ZSIsIndlYWx0aDphY2Nlc3MtY29udHJvbDp2aWV3ZXIiLCJ3ZWFsdGg6YWNjZXNzLWNvbnRyb2w6ZWRpdG9yIiwib3BlbmlkIiwid2VhbHRoOmN4LXVzZXItY29uZjp2aWV3ZXIiLCJ3ZWFsdGg6Y3gtZmlybS1jb25mOnZpZXdlciIsIndlYWx0aDpjeC1maXJtLWNvbmY6ZWRpdG9yIiwid2VhbHRoOmN4LXVzZXItY29uZjplZGl0b3IiLCJjaWFtOnByb2ZpbGVzOnJlYWQiXSwiYXV0aF90aW1lIjoxNzM0OTg5MjgzLCJzdWIiOiI2MTU0IiwicHJlZmVycmVkTGFuZ3VhZ2UiOiJFTiIsImJuZ2ZSZWZlcmVuY2VJZCI6IjYxNTQiLCJibmdmSWRlbnRpdHlTb3VyY2UiOiJDUFgiLCJncm91cHMiOlsiV2VhbHRoLkNvbXBhc3NYIiwiV2VhbHRoLkNvbXBhc3NYLk1hbmdlRmlybSIsIldlYWx0aCIsIldlYWx0aC5Db21wYXNzWC5Ob01GQSJdfQ.O0T5Mdr2NClLG75xTxoRdUED1Wzg-pJuSWCt4JtzK7HRDJxImyT0YvMTmqPO4V74TRYZ7t_jOCQ8QynCdcQTCRFygx82fNwkJ1ho5EeMr7v_w6BTuvSJ0XTKw08uiziFN_qXqG2C7KxD66amdRHFV2AJuUo9brgWDmV8zxqmRDWiVNoioLi5UI4DAIbf55_kO5beOCBCkZGK_XpLm7FomMV0E3N3s_0O6lau4yIdlLCczfa6ztIVV22EzCUc0LbAUb4qRJ8nBfy8gQ9PkoQe7SxRziQxo_cQSYNHxWMqUCbgAtUQCDvcPnDRA5jqx4eNPj_ue3z7YwdSShpPWlngrQ";
    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken =
        new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>());
    SecurityContext securityContext = mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(usernamePasswordAuthenticationToken);
    SecurityContextHolder.setContext(securityContext);
    assertEquals("6154", userService.getIdpSubjectFromPrincipalOrUserToken(usertoken));
  }

  @Test
  public void generateBngfReferenceId() {
    Firm firm = MockData.getFirmEntity();
    assertEquals("cpx_clientId", userService.generateBngfReferenceId(null, "clientId"));
    when(firmRepository.findByFirmId(any())).thenReturn(firm);
    assertEquals("cpx_clientId", userService.generateBngfReferenceId("firm", "clientId"));
    firm.setIdentitySource("indall");
    when(firmRepository.findByFirmId(any())).thenReturn(firm);
    assertEquals("indall_clientId", userService.generateBngfReferenceId("firm", "clientId"));
  }

  @Test
  public void testUpdateNbxUserConfiguration_whenAllFieldsArePopulated_shouldUpdateUser() {
    User user = new User();
    user.setIdpSubject("idpSubject");
    UsernamePasswordAuthenticationToken auth =
        new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>());
    SecurityContext securityContext = mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(auth);
    SecurityContextHolder.setContext(securityContext);

    NbxUserConfiguration mockNbxUserConfiguration = MockData.getNbxUserConfiguration();

    IamUserConfiguration mockIamUserConfiguration = MockData.getIamUserConfigurationEntity();
    mockIamUserConfiguration.setSource(MockData.NBX_SOURCE);
    when(iamUserConfigurationRepository.findFirstByIdpSubject(anyString())).thenReturn(Optional.of(mockIamUserConfiguration));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class))).thenReturn(MockData.getIamUserConfigurationEntity());

    IamUserConfiguration updatedNbxUser = userService.updateNbxUserConfiguration(MockData.IDP_USER_SUB, mockNbxUserConfiguration);

    assertNotNull(updatedNbxUser);
  }

  @Test
  public void testUpdateNbxUserConfiguration_whenPreferredLanguageNotPopulated_shouldUpdateUser() {
    User user = new User();
    user.setIdpSubject("idpSubject");
    UsernamePasswordAuthenticationToken auth =
        new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>());
    SecurityContext securityContext = mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(auth);
    SecurityContextHolder.setContext(securityContext);

    NbxUserConfiguration mockNbxUserConfiguration = MockData.getNbxUserConfiguration();
    mockNbxUserConfiguration.setPreferredLanguage(null);

    IamUserConfiguration mockIamUserConfiguration = MockData.getIamUserConfigurationEntity();
    mockIamUserConfiguration.setSource(MockData.NBX_SOURCE);
    when(iamUserConfigurationRepository.findFirstByIdpSubject(anyString())).thenReturn(Optional.of(mockIamUserConfiguration));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class))).thenReturn(MockData.getIamUserConfigurationEntity());

    IamUserConfiguration updatedNbxUser = userService.updateNbxUserConfiguration(MockData.IDP_USER_SUB, mockNbxUserConfiguration);

    assertNotNull(updatedNbxUser);
  }

  @Test(expected = FumNotFoundException.class)
  public void testUpdateNbxUserConfiguration_whenUserNotExist_shouldThrowFumNotFoundException() {
    NbxUserConfiguration mockNbxUserConfiguration = MockData.getNbxUserConfiguration();

    when(iamUserConfigurationRepository.findFirstByIdpSubject(anyString())).thenReturn(Optional.empty());

    userService.updateNbxUserConfiguration(MockData.IDP_USER_SUB, mockNbxUserConfiguration);
  }

  @Test
  public void testUpdateNbxUserConfiguration_whenLastNameNotPopulated_shouldUpdateUser() {
    User user = new User();
    user.setIdpSubject("idpSubject");
    UsernamePasswordAuthenticationToken auth =
        new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>());
    SecurityContext securityContext = mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(auth);
    SecurityContextHolder.setContext(securityContext);

    NbxUserConfiguration mockNbxUserConfiguration = MockData.getNbxUserConfiguration();
    mockNbxUserConfiguration.setLastName(null);

    IamUserConfiguration mockIamUserConfiguration = MockData.getIamUserConfigurationEntity();
    mockIamUserConfiguration.setSource(MockData.NBX_SOURCE);
    when(iamUserConfigurationRepository.findFirstByIdpSubject(anyString())).thenReturn(Optional.of(mockIamUserConfiguration));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class))).thenReturn(MockData.getIamUserConfigurationEntity());

    IamUserConfiguration updatedNbxUser = userService.updateNbxUserConfiguration(MockData.IDP_USER_SUB, mockNbxUserConfiguration);

    assertNotNull(updatedNbxUser);
  }

  @Test
  public void testUpdateNbxUserConfiguration_whenEmailNotPopulated_shouldUpdateUser() {
    User user = new User();
    user.setIdpSubject("idpSubject");
    UsernamePasswordAuthenticationToken auth =
        new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>());
    SecurityContext securityContext = mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(auth);
    SecurityContextHolder.setContext(securityContext);

    NbxUserConfiguration mockNbxUserConfiguration = MockData.getNbxUserConfiguration();
    mockNbxUserConfiguration.setEmail(null);

    IamUserConfiguration mockIamUserConfiguration = MockData.getIamUserConfigurationEntity();
    mockIamUserConfiguration.setSource(MockData.NBX_SOURCE);
    when(iamUserConfigurationRepository.findFirstByIdpSubject(anyString())).thenReturn(Optional.of(mockIamUserConfiguration));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class))).thenReturn(MockData.getIamUserConfigurationEntity());

    IamUserConfiguration updatedNbxUser = userService.updateNbxUserConfiguration(MockData.IDP_USER_SUB, mockNbxUserConfiguration);

    assertNotNull(updatedNbxUser);
  }

  @Test
  public void testUpdateNbxUserConfiguration_whenFirstNameNotPopulated_shouldUpdateUser() {
    User user = new User();
    user.setIdpSubject("idpSubject");
    UsernamePasswordAuthenticationToken auth =
        new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>());
    SecurityContext securityContext = mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(auth);
    SecurityContextHolder.setContext(securityContext);

    NbxUserConfiguration mockNbxUserConfiguration = MockData.getNbxUserConfiguration();
    mockNbxUserConfiguration.setFirstName(null);

    IamUserConfiguration mockIamUserConfiguration = MockData.getIamUserConfigurationEntity();
    mockIamUserConfiguration.setSource(MockData.NBX_SOURCE);
    when(iamUserConfigurationRepository.findFirstByIdpSubject(anyString())).thenReturn(Optional.of(mockIamUserConfiguration));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class))).thenReturn(MockData.getIamUserConfigurationEntity());

    IamUserConfiguration updatedNbxUser = userService.updateNbxUserConfiguration(MockData.IDP_USER_SUB, mockNbxUserConfiguration);

    assertNotNull(updatedNbxUser);
  }

  @Test
  public void testGenericNbxUserSearchWithPagination_whenFirmAndPaginationProvided_shouldReturnGenericSearchResponse() {
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("Name");
    userSearch.setFirmId("NBIN");
    userSearch.setPageSize(2);

    Future<Pair<Integer, List<GroupByResponse>>> otherFuture = CompletableFuture.completedFuture(Pair.of(2,
        List.of(new GroupByResponse().groupKey("NBIN").groupData(MockData.getUserConfigurationList()))));
    when(userConfigurationSearchService.searchUserView(any(), any(), any(), any(), anyBoolean())).thenReturn(otherFuture);
    when(firmRepository.findByFirmId(anyString())).thenReturn(MockData.getFirmEntity());

    GenericSearchResponse genericSearchResponse = userService.genericNbxUserSearchWithPagination(userSearch);
    assertNull(genericSearchResponse.getCurrentFirmUserCount());
    assertNull(genericSearchResponse.getCurrentFirmUserPages());
    assertNull(genericSearchResponse.getCurrentFirmUsers());
    assertEquals(2, genericSearchResponse.getOtherFirmUserCount());
    assertEquals(1, genericSearchResponse.getOtherFirmUserPages());
    assertEquals(1, genericSearchResponse.getOtherFirmUsers().size());
  }

  @Test
  public void testGenericNbxUserSearchWithPagination_whenFirmAndNoPaginationProvided_shouldReturnOneGenericSearchResponse() {
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("Name");
    userSearch.setFirmId("NBIN");

    Future<Pair<Integer, List<GroupByResponse>>> otherFuture = MockData.getComparableFuture("NBIN");
    when(userConfigurationSearchService.searchUserView(any(), any(), any(), any(), anyBoolean())).thenReturn(otherFuture);
    when(firmRepository.findByFirmId(anyString())).thenReturn(MockData.getFirmEntity());

    GenericSearchResponse genericSearchResponse = userService.genericNbxUserSearchWithPagination(userSearch);
    assertNull(genericSearchResponse.getCurrentFirmUserCount());
    assertNull(genericSearchResponse.getCurrentFirmUserPages());
    assertNull(genericSearchResponse.getCurrentFirmUsers());
    assertEquals(1, genericSearchResponse.getOtherFirmUserCount());
    assertNull(genericSearchResponse.getOtherFirmUserPages());
    assertEquals(1, genericSearchResponse.getOtherFirmUsers().size());
  }

  @Test
  public void testGenericNbxUserSearchWithPagination_whenFirmNotProvided_shouldReturnEmptyGenericSearchResponse() {
    GenericSearch userSearch = new GenericSearch();
    userSearch.setSearchText("Name");

    Future<Pair<Integer, List<GroupByResponse>>> otherFuture = CompletableFuture.completedFuture(Pair.of(0, new ArrayList<>()));
    when(userConfigurationSearchService.searchUserView(any(), any(), any(), any(), anyBoolean())).thenReturn(otherFuture);

    GenericSearchResponse genericSearchResponse = userService.genericNbxUserSearchWithPagination(userSearch);
    assertNull(genericSearchResponse.getCurrentFirmUserCount());
    assertNull(genericSearchResponse.getCurrentFirmUserPages());
    assertNull(genericSearchResponse.getCurrentFirmUsers());
    assertEquals(0, genericSearchResponse.getOtherFirmUserCount());
    assertNull(genericSearchResponse.getOtherFirmUserPages());
    assertTrue(genericSearchResponse.getOtherFirmUsers().isEmpty());
  }

  @Test
  public void testGenericNbxUserSearchWithPagination_whenUserSearchTextNotProvided_shouldReturnAllGenericSearchResponse() {
    Future<Pair<Integer, List<GroupByResponse>>> otherFuture = MockData.getComparableFuture("NBIN");
    when(userConfigurationSearchService.searchUserView(any(), any(), any(), any(), anyBoolean())).thenReturn(otherFuture);

    GenericSearchResponse genericSearchResponse = userService.genericNbxUserSearchWithPagination(new GenericSearch());
    assertNull(genericSearchResponse.getCurrentFirmUserCount());
    assertNull(genericSearchResponse.getCurrentFirmUserPages());
    assertNull(genericSearchResponse.getCurrentFirmUsers());
    assertEquals(1, genericSearchResponse.getOtherFirmUserCount());
    assertNull(genericSearchResponse.getOtherFirmUserPages());
    assertEquals(1, genericSearchResponse.getOtherFirmUsers().size());
  }

  @Test
  public void testGetUserType_whenNbinOrNbcIdp_shouldReturnUserType() {
    assertEquals(CPX_IDP.toUpperCase(), userService.getUserType("NBIN"));
    assertEquals(DWH_IDP.toUpperCase(), userService.getUserType("nbc"));
  }

  @Test(expected = FumValidationException.class)
  public void testGetUserType_whenUnknownIdp_shouldReturnUserType() {
    userService.getUserType("source");
  }

  @Test
  public void testGetUserType_whenEmployeeIdp_shouldReturnEmployeeUserType() {
    assertEquals(EMPLOYEE_IDP.toUpperCase(), userService.getUserType(EMPLOYEE_IDP));
    assertEquals(EMPLOYEE_IDP.toUpperCase(), userService.getUserType(EMPLOYEE_IDP.toLowerCase()));
  }

  @Test
  public void updateUserSecureZoneIds_whenNewSecureZoneIds_shouldCallUamaThenOkta() {
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setSecureZoneIds(List.of("SZ1234", "SZ5678"));

    userService.updateUserSecureZoneIds(userConfiguration, iamUserConfiguration);

    org.mockito.InOrder inOrder = org.mockito.Mockito.inOrder(szService, ciamService);
    inOrder
        .verify(szService)
        .assignExternalIdToUsername("SZ1234", iamUserConfiguration.getIdpSubject(), "NBIN");
    inOrder
        .verify(szService)
        .assignExternalIdToUsername("SZ5678", iamUserConfiguration.getIdpSubject(), "NBIN");
    ArgumentCaptor<String[]> oktaCaptor = ArgumentCaptor.forClass(String[].class);
    inOrder
        .verify(ciamService)
        .updateOktaSecureZoneId(eq("1234"), oktaCaptor.capture());
    Assertions.assertArrayEquals(new String[] {"SZ1234", "SZ5678"}, oktaCaptor.getValue());
  }

  @Test
  public void updateUserSecureZoneIds_whenUamaReturns404_shouldRollbackAndSkipOkta() {
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setSecureZoneIds(List.of("SZBAD"));
    doThrow(new FumValidationException(Constants.ERROR_SZ_ASSIGN_CALL_4xx, "Invalid externalSystemId"))
        .when(szService)
        .assignExternalIdToUsername("SZBAD", iamUserConfiguration.getIdpSubject(), "NBIN");

    Assertions.assertThrows(
        FumValidationException.class,
        () -> userService.updateUserSecureZoneIds(userConfiguration, iamUserConfiguration));

    verify(ciamService, never()).updateOktaSecureZoneId(anyString(), any());
  }

  @Test
  public void updateUserSecureZoneIds_whenUamaReturns5xx_shouldRollbackAndSkipOkta() {
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setSecureZoneIds(List.of("SZ1234"));
    doThrow(new FumServiceException(Constants.ERROR_SZ_ASSIGN_CALL_5xx, "SecureZone unavailable"))
        .when(szService)
        .assignExternalIdToUsername("SZ1234", iamUserConfiguration.getIdpSubject(), "NBIN");

    Assertions.assertThrows(
        FumServiceException.class,
        () -> userService.updateUserSecureZoneIds(userConfiguration, iamUserConfiguration));

    verify(ciamService, never()).updateOktaSecureZoneId(anyString(), any());
  }

  private SzUserSearch szUserSearch(String userName, String... szIds) {
    SzUserSearch search = new SzUserSearch();
    search.setTotalResults(szIds.length);
    search.setResources(Arrays.stream(szIds).map(szId -> {
      SzUser szUser = new SzUser();
      szUser.setId(szId);
      szUser.setUserName(userName);
      return szUser;
    }).toList());
    return search;
  }

  @Test
  public void updateUserSecureZoneIds_whenSecureZoneIdsNull_shouldUnassignExistingSzIdInUama() {
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    when(szService.getExternalUserByIdpSubject(iamUserConfiguration.getIdpSubject()))
        .thenReturn(szUserSearch(iamUserConfiguration.getIdpSubject(), "SZ1234"));

    userService.updateUserSecureZoneIds(new UserConfiguration(), iamUserConfiguration);

    org.mockito.InOrder inOrder = org.mockito.Mockito.inOrder(szService, ciamService);
    inOrder.verify(szService).assignExternalIdToUsername("SZ1234", "null", "NBIN");
    ArgumentCaptor<String[]> oktaCaptor = ArgumentCaptor.forClass(String[].class);
    inOrder.verify(ciamService).updateOktaSecureZoneId(eq("1234"), oktaCaptor.capture());
    Assertions.assertArrayEquals(new String[0], oktaCaptor.getValue());
  }

  @Test
  public void updateUserSecureZoneIds_whenSecureZoneIdsEmpty_shouldUnassignAllExistingSzIds() {
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setSecureZoneIds(new ArrayList<>());
    when(szService.getExternalUserByIdpSubject(iamUserConfiguration.getIdpSubject()))
        .thenReturn(szUserSearch(iamUserConfiguration.getIdpSubject(), "SZ1", "SZ2"));

    userService.updateUserSecureZoneIds(userConfiguration, iamUserConfiguration);

    verify(szService).assignExternalIdToUsername("SZ1", "null", "NBIN");
    verify(szService).assignExternalIdToUsername("SZ2", "null", "NBIN");
    verify(ciamService).updateOktaSecureZoneId(eq("1234"), any());
  }

  @Test
  public void updateUserSecureZoneIds_whenNoSzIdAssignedInUama_shouldStillClearOkta() {
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    when(szService.getExternalUserByIdpSubject(iamUserConfiguration.getIdpSubject()))
        .thenReturn(new SzUserSearch());

    userService.updateUserSecureZoneIds(new UserConfiguration(), iamUserConfiguration);

    verify(szService, never()).assignExternalIdToUsername(any(), any(), any());
    ArgumentCaptor<String[]> oktaCaptor = ArgumentCaptor.forClass(String[].class);
    verify(ciamService).updateOktaSecureZoneId(eq("1234"), oktaCaptor.capture());
    Assertions.assertArrayEquals(new String[0], oktaCaptor.getValue());
  }

  @Test
  public void updateUserSecureZoneIds_whenExternalSsoIdpAndNoSecureZoneIds_shouldClearOktaWithoutResolvingUserType() {
    // indall / sunlif are not supported by getUserType, but an access update for those users must
    // still succeed when no SecureZone id is involved - UAMA is simply not reachable for them.
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    iamUserConfiguration.setIdp("indall");
    when(szService.getExternalUserByIdpSubject(iamUserConfiguration.getIdpSubject()))
        .thenReturn(new SzUserSearch());

    userService.updateUserSecureZoneIds(new UserConfiguration(), iamUserConfiguration);

    verify(szService, never()).assignExternalIdToUsername(any(), any(), any());
    verify(ciamService).updateOktaSecureZoneId(eq("1234"), any());
  }

  @Test
  public void updateUserSecureZoneIds_whenIdpIsNullAndNoSecureZoneIds_shouldClearOktaWithoutResolvingUserType() {
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    iamUserConfiguration.setIdp(null);
    when(szService.getExternalUserByIdpSubject(iamUserConfiguration.getIdpSubject()))
        .thenReturn(new SzUserSearch());

    userService.updateUserSecureZoneIds(new UserConfiguration(), iamUserConfiguration);

    verify(szService, never()).assignExternalIdToUsername(any(), any(), any());
    verify(ciamService).updateOktaSecureZoneId(eq("1234"), any());
  }

  @Test
  public void updateUserSecureZoneIds_whenSearchReturnsPrefixMatchOnly_shouldNotUnassignButClearOkta() {
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    when(szService.getExternalUserByIdpSubject(iamUserConfiguration.getIdpSubject()))
        .thenReturn(szUserSearch(iamUserConfiguration.getIdpSubject() + "-other", "SZ9999"));

    userService.updateUserSecureZoneIds(new UserConfiguration(), iamUserConfiguration);

    verify(szService, never()).assignExternalIdToUsername(any(), any(), any());
    verify(ciamService).updateOktaSecureZoneId(eq("1234"), any());
  }

  @Test
  public void updateUserSecureZoneIds_whenUamaSearchFails_shouldPropagateAndSkipOkta() {
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    when(szService.getExternalUserByIdpSubject(iamUserConfiguration.getIdpSubject()))
        .thenThrow(
            new FumServiceException(Constants.ERROR_SZ_GET_USER_CALL_5xx, "SecureZone unavailable"));

    Assertions.assertThrows(
        FumServiceException.class,
        () -> userService.updateUserSecureZoneIds(new UserConfiguration(), iamUserConfiguration));

    verify(szService, never()).assignExternalIdToUsername(any(), any(), any());
    verify(ciamService, never()).updateOktaSecureZoneId(anyString(), any());
  }

  @Test
  public void updateUserSecureZoneIds_whenUnassignFails_shouldPropagateAndSkipOkta() {
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    when(szService.getExternalUserByIdpSubject(iamUserConfiguration.getIdpSubject()))
        .thenReturn(szUserSearch(iamUserConfiguration.getIdpSubject(), "SZ1234"));
    doThrow(new FumValidationException(Constants.ERROR_SZ_ASSIGN_CALL_4xx, "Invalid externalSystemId"))
        .when(szService)
        .assignExternalIdToUsername("SZ1234", "null", "NBIN");

    Assertions.assertThrows(
        FumValidationException.class,
        () -> userService.updateUserSecureZoneIds(new UserConfiguration(), iamUserConfiguration));

    verify(ciamService, never()).updateOktaSecureZoneId(anyString(), any());
  }

  @Test
  public void updateUserSecureZoneIds_whenUamaDisabled_shouldSkipUamaButStillUpdateOkta()
      throws IllegalAccessException {
    FieldUtils.writeField(userService, "isUamaEnabled", false, true);
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setSecureZoneIds(List.of("SZ1234", "SZ5678"));

    userService.updateUserSecureZoneIds(userConfiguration, iamUserConfiguration);

    verify(szService, never()).assignExternalIdToUsername(anyString(), anyString(), anyString());
    ArgumentCaptor<String[]> oktaCaptor = ArgumentCaptor.forClass(String[].class);
    verify(ciamService).updateOktaSecureZoneId(eq("1234"), oktaCaptor.capture());
    Assertions.assertArrayEquals(new String[] {"SZ1234", "SZ5678"}, oktaCaptor.getValue());
  }

  @Test
  public void
      updateUserSecureZoneIds_whenUamaDisabledAndNoSecureZoneIds_shouldSkipSearchButClearOkta()
          throws IllegalAccessException {
    FieldUtils.writeField(userService, "isUamaEnabled", false, true);
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();

    userService.updateUserSecureZoneIds(new UserConfiguration(), iamUserConfiguration);

    verify(szService, never()).getExternalUserByIdpSubject(anyString());
    verify(szService, never()).assignExternalIdToUsername(anyString(), anyString(), anyString());
    ArgumentCaptor<String[]> oktaCaptor = ArgumentCaptor.forClass(String[].class);
    verify(ciamService).updateOktaSecureZoneId(eq("1234"), oktaCaptor.capture());
    Assertions.assertArrayEquals(new String[0], oktaCaptor.getValue());
  }

  @Test
  public void updateSecureZoneUserActiveStatus_whenUamaDisabled_shouldNotCallUamaOrOkta()
      throws IllegalAccessException {
    FieldUtils.writeField(userService, "isUamaEnabled", false, true);
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();

    userService.updateSecureZoneUserActiveStatus(iamUserConfiguration, false);

    verify(ciamService, never()).getOktaUserProfile(anyString());
    verify(szService, never()).getExternalUser(anyString());
    verify(szService, never()).updateUserActiveStatus(anyString(), any(SzUser.class));
  }

  @Test
  public void updateSecureZoneUserActiveStatus_whenSecureZoneIds_shouldGetThenPutWithActiveFlag() {
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    OktaUserProfile oktaUserProfile = new OktaUserProfile();
    OktaAccessProfile accessProfile = new OktaAccessProfile();
    accessProfile.setBngfSecureZoneId(new String[] {"SZ1", "SZ2"});
    oktaUserProfile.setAccessProfile(accessProfile);
    when(ciamService.getOktaUserProfile("1234")).thenReturn(oktaUserProfile);

    SzUser szUser1 = new SzUser();
    szUser1.setActive(true);
    SzUser szUser2 = new SzUser();
    szUser2.setActive(true);
    when(szService.getExternalUser("SZ1")).thenReturn(szUser1);
    when(szService.getExternalUser("SZ2")).thenReturn(szUser2);

    userService.updateSecureZoneUserActiveStatus(iamUserConfiguration, false);

    org.mockito.InOrder inOrder = org.mockito.Mockito.inOrder(szService);
    inOrder.verify(szService).getExternalUser("SZ1");
    inOrder.verify(szService).updateUserActiveStatus("SZ1", szUser1);
    inOrder.verify(szService).getExternalUser("SZ2");
    inOrder.verify(szService).updateUserActiveStatus("SZ2", szUser2);
    Assertions.assertFalse(szUser1.isActive());
    Assertions.assertFalse(szUser2.isActive());
  }

  @Test
  public void updateSecureZoneUserActiveStatus_whenNoSecureZoneIds_shouldDoNothing() {
    when(ciamService.getOktaUserProfile("1234")).thenReturn(null);

    userService.updateSecureZoneUserActiveStatus(MockData.getIamUserConfigurationEntity(), false);

    verify(szService, never()).getExternalUser(anyString());
    verify(szService, never()).updateUserActiveStatus(anyString(), any());
  }

  @Test
  public void updateSecureZoneUserActiveStatus_whenEmptySecureZoneIds_shouldDoNothing() {
    OktaUserProfile oktaUserProfile = new OktaUserProfile();
    OktaAccessProfile accessProfile = new OktaAccessProfile();
    accessProfile.setBngfSecureZoneId(new String[0]);
    oktaUserProfile.setAccessProfile(accessProfile);
    when(ciamService.getOktaUserProfile("1234")).thenReturn(oktaUserProfile);

    userService.updateSecureZoneUserActiveStatus(MockData.getIamUserConfigurationEntity(), false);

    verify(szService, never()).getExternalUser(anyString());
    verify(szService, never()).updateUserActiveStatus(anyString(), any());
  }

  @Test
  public void updateSecureZoneUserActiveStatus_whenGetFails_shouldSkipThatSzIdAndContinue() {
    OktaUserProfile oktaUserProfile = new OktaUserProfile();
    OktaAccessProfile accessProfile = new OktaAccessProfile();
    accessProfile.setBngfSecureZoneId(new String[] {"SZ1", "SZ2"});
    oktaUserProfile.setAccessProfile(accessProfile);
    when(ciamService.getOktaUserProfile("1234")).thenReturn(oktaUserProfile);

    when(szService.getExternalUser("SZ1"))
        .thenThrow(new FumValidationException(Constants.ERROR_SZ_GET_USER_CALL_4xx, "not found"));
    SzUser szUser2 = new SzUser();
    when(szService.getExternalUser("SZ2")).thenReturn(szUser2);

    userService.updateSecureZoneUserActiveStatus(MockData.getIamUserConfigurationEntity(), false);

    verify(szService, never()).updateUserActiveStatus("SZ1", null);
    verify(szService, times(1)).updateUserActiveStatus("SZ2", szUser2);
  }

  @Test
  public void updateSecureZoneUserActiveStatus_whenPutFails_shouldSkipAndNotPropagate() {
    OktaUserProfile oktaUserProfile = new OktaUserProfile();
    OktaAccessProfile accessProfile = new OktaAccessProfile();
    accessProfile.setBngfSecureZoneId(new String[] {"SZ1", "SZ2"});
    oktaUserProfile.setAccessProfile(accessProfile);
    when(ciamService.getOktaUserProfile("1234")).thenReturn(oktaUserProfile);

    SzUser szUser1 = new SzUser();
    SzUser szUser2 = new SzUser();
    when(szService.getExternalUser("SZ1")).thenReturn(szUser1);
    when(szService.getExternalUser("SZ2")).thenReturn(szUser2);
    doThrow(new FumServiceException(Constants.ERROR_SZ_UPDATE_CALL_5xx, "unavailable"))
        .when(szService)
        .updateUserActiveStatus("SZ1", szUser1);

    userService.updateSecureZoneUserActiveStatus(MockData.getIamUserConfigurationEntity(), false);

    verify(szService, times(1)).updateUserActiveStatus("SZ1", szUser1);
    verify(szService, times(1)).updateUserActiveStatus("SZ2", szUser2);
  }

  @Test
  public void testDeleteUserConfigurationByUserId_whenSzFails_shouldNotPropagateAndStillSuspendOkta() {
    IamUserConfiguration iamUserConfiguration = MockData.getIamUserConfigurationEntity();
    when(iamUserConfigurationRepository.getReferenceById(anyLong())).thenReturn(iamUserConfiguration);
    OktaUserProfile oktaUserProfile = new OktaUserProfile();
    OktaAccessProfile accessProfile = new OktaAccessProfile();
    accessProfile.setBngfSecureZoneId(new String[] {"SZ1"});
    oktaUserProfile.setAccessProfile(accessProfile);
    when(ciamService.getOktaUserProfile("1234")).thenReturn(oktaUserProfile);
    when(szService.getExternalUser("SZ1"))
        .thenThrow(new FumServiceException(Constants.ERROR_SZ_GET_USER_CALL_5xx, "unavailable"));

    userService.deleteUserConfigurationByUserId("system", 123);

    verify(ciamService, times(1)).suspendUserOktaProfile("1234");
  }

  @Test
  public void testUpdateExternalUserIds_whenSecureZoneSystemId_shouldCallSecureZone() {
    when(iamUserConfigurationRepository.findByIdpSubject(anyString()))
        .thenReturn(MockData.getIamUserConfigurationEntity());

    // Empty list of external ids
    userService.updateExternalUserIds("testIdpSubject", "secure-zone", new ArrayList<>());
    verify(szService, never()).assignExternalIdToUsername(any(), any(), any());

    // Valid list of external ids
    userService.updateExternalUserIds("testIdpSubject", "secure-zone", List.of("id"));
    verify(szService, times(1)).assignExternalIdToUsername(any(), any(), any());
  }

  @Test(expected = FumValidationException.class)
  public void testUpdateExternalUserIds_whenOtherSystemId_shouldThrowFumValidationException() {
    when(iamUserConfigurationRepository.findByIdpSubject(anyString()))
        .thenReturn(MockData.getIamUserConfigurationEntity());
    userService.updateExternalUserIds("testIdpSubject", "oss", new ArrayList<>());
  }

  @Test
  public void testGetUserConfigurationByExternalUserId_whenSecureZone_shouldReturnUamaUser() {
    SzUser szUser = new SzUser();
    szUser.setId("123");
    szUser.setUserName("testUser");
    szUser.setActive(true);
    szUser.setFamilyName("Doe");
    szUser.setGivenName("John");
    when(szService.getExternalUser("szId123")).thenReturn(szUser);

    UamaUser result = userService.getUserConfigurationByExternalUserId("secure-zone", "szId123");
    assertNotNull(result);
    assertEquals("123", result.getId());
    assertEquals("testUser", result.getUserName());
    assertEquals(true, result.getActive());
    assertEquals("Doe", result.getFamilyName());
    assertEquals("John", result.getGivenName());
  }

  @Test(expected = FumValidationException.class)
  public void testGetUserConfigurationByExternalUserId_whenUnsupportedSystem_shouldThrowFumValidationException() {
    userService.getUserConfigurationByExternalUserId("unsupported-system", "extId");
  }

  @Test
  public void testGetUserConfigurationByExternalUserId_whenNullSzUser_shouldReturnNull() {
    when(szService.getExternalUser("szId")).thenReturn(null);
    UamaUser result = userService.getUserConfigurationByExternalUserId("secure-zone", "szId");
    assertNull(result);
  }

  @Test(expected = FumNotFoundException.class)
  public void testUpdateExternalUserIds_whenUserNotFound_shouldThrowFumNotFoundException() {
    when(iamUserConfigurationRepository.findByIdpSubject(anyString())).thenReturn(null);
    userService.updateExternalUserIds("unknownIdpSubject", "secure-zone", List.of("id"));
  }

  @Test
  public void testGetUserConfigurationByIdpSubjectAndExternalSystemId_whenSecureZone_shouldReturnResponse() {
    when(iamUserConfigurationRepository.findByIdpSubject(anyString()))
        .thenReturn(MockData.getIamUserConfigurationEntity());
    SzUserSearch szUserSearch = new SzUserSearch();
    szUserSearch.setTotalResults(1);
    szUserSearch.setStartIndex(0);
    szUserSearch.setPageResults(1);
    SzUser szUser = new SzUser();
    szUser.setId("123");
    szUser.setUserName("testUser");
    szUser.setActive(true);
    szUserSearch.setResources(List.of(szUser));
    when(szService.getExternalUserByIdpSubject(anyString())).thenReturn(szUserSearch);

    UamaUserSearchResponse result = userService.getUserConfigurationByIdpSubjectAndExternalSystemId("testIdpSubject", "secure-zone");
    assertNotNull(result);
    assertEquals(1, result.getTotalResults().intValue());
    assertEquals(1, result.getUsers().size());
    assertEquals("123", result.getUsers().get(0).getId());
  }

  @Test(expected = FumNotFoundException.class)
  public void testGetUserConfigurationByIdpSubjectAndExternalSystemId_whenUserNotFound_shouldThrowFumNotFoundException() {
    when(iamUserConfigurationRepository.findByIdpSubject(anyString())).thenReturn(null);
    userService.getUserConfigurationByIdpSubjectAndExternalSystemId("unknownIdpSubject", "secure-zone");
  }

  @Test(expected = FumValidationException.class)
  public void testGetUserConfigurationByIdpSubjectAndExternalSystemId_whenUnsupportedSystem_shouldThrowFumValidationException() {
    when(iamUserConfigurationRepository.findByIdpSubject(anyString()))
        .thenReturn(MockData.getIamUserConfigurationEntity());
    userService.getUserConfigurationByIdpSubjectAndExternalSystemId("testIdpSubject", "unsupported-system");
  }

  @Test
  public void updateUserGroupByIdpSubject_shouldUpdateGroupSuccessfully() {
    when(iamUserConfigurationRepository.findByIdpSubject(anyString())).thenReturn(MockData.getIamUserConfigurationEntity());
    when(firmRepository.findByFirmId(any())).thenReturn(MockData.getFirmEntity());
    when(userAssignmentService.getUserAssignment(anyString(), eq(UserAssignmentType.G))).thenReturn(new ArrayList<>());
    when(userGroupRepository.findAll(any(Specification.class))).thenReturn(List.of(MockData.getUserGroupEntity()));

    userService.updateUserGroupByIdpSubject("testIdp", "TestGroup");

    verify(ciamService, times(1)).updateOktaUserGroups(any(), any());
    verify(userAssignmentUserGroupRepository, times(1)).save(any());
  }

  @Test(expected = FumNotFoundException.class)
  public void updateUserGroupByIdpSubject_whenUserNotFound_shouldThrowFumNotFoundException() {
    when(iamUserConfigurationRepository.findByIdpSubject(anyString())).thenReturn(null);
    userService.updateUserGroupByIdpSubject("testIdp", "TestGroup");
  }

  @Test
  public void deleteUserGroupByIdpSubject_shouldDeleteGroupSuccessfully() {
    when(iamUserConfigurationRepository.findByIdpSubject(anyString())).thenReturn(MockData.getIamUserConfigurationEntity());
    when(userAssignmentService.getUserAssignment(anyString(), eq(UserAssignmentType.G))).thenReturn(new ArrayList<>());

    userService.deleteUserGroupByIdpSubject("testIdp", "TestGroup");

    verify(ciamService, times(1)).deleteOktaUserGroup(any(), eq("TestGroup"));
  }

  @Test(expected = FumNotFoundException.class)
  public void deleteUserGroupByIdpSubject_whenUserNotFound_shouldThrowFumNotFoundException() {
    when(iamUserConfigurationRepository.findByIdpSubject(anyString())).thenReturn(null);
    userService.deleteUserGroupByIdpSubject("testIdp", "TestGroup");
  }

  @Test(expected = FumValidationException.class)
  public void deleteUserGroupByIdpSubject_whenGroupNotInOkta_shouldThrowFumValidationException() {
    when(iamUserConfigurationRepository.findByIdpSubject(anyString())).thenReturn(MockData.getIamUserConfigurationEntity());
    doThrow(new FumValidationException("error.groupName.notFound", "Group not found"))
        .when(ciamService).deleteOktaUserGroup(anyString(), anyString());

    userService.deleteUserGroupByIdpSubject("testIdp", "NonExistentGroup");
  }

  private Map<String, Object> getFirmMap(String firmId) {
    return Map.of(
        "FIRM_ENTITY_ID",
        1,
        "FIRM_ID",
        firmId,
        "TYPE",
        FirmType.IB,
        "PREFERRED_LANGUAGE",
        PreferredLanguageType.EN,
        "CREATION_DATE",
        new Timestamp(System.currentTimeMillis()));
  }

  @Test
  public void assignEmployeeExternalUserGroup_shouldAssignGroup_whenSecondaryAccount() {
    IamUserConfiguration user = new IamUserConfiguration();
    when(personService.isSecondaryAccount(user)).thenReturn(true);

    userService.assignEmployeeExternalUserGroup("idp-user", user);

    verify(ciamService, times(1))
        .assignOktaUserGroup("idp-user", Constants.EMPLOYEE_EXTERNAL_USER_GROUP);
  }

  @Test
  public void assignEmployeeExternalUserGroup_shouldDoNothing_whenNotSecondaryAccount() {
    IamUserConfiguration user = new IamUserConfiguration();
    when(personService.isSecondaryAccount(user)).thenReturn(false);

    userService.assignEmployeeExternalUserGroup("idp-user", user);

    verify(ciamService, never()).assignOktaUserGroup(any(), any());
  }

  private Map<String, Object> getRrCodeRangeMap() {
    return Map.of(
        "RR_CODE_RANGE_ID", 1,
        "ACTIVE", true,
        "FROM_RR_CODE", "A2AA",
        "FROM_RR_CODE_B10", 1L,
        "TO_RR_CODE", "A2ZZ",
        "TO_RR_CODE_B10", 10L);
  }
}
