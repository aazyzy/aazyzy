package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.userconfiguration.model.state.UserStateActionEnum;
import ca.bnc.wealth.api.userconfiguration.model.state.UserStateDescriptionEnum;
import ca.bnc.wealth.api.userconfiguration.model.state.UserStateEnum;
import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.MockData;
import ca.bnc.wealth.common.ciam.model.OktaFactor;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import java.util.Optional;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class UserStateServiceTest {

  @MockitoBean
  private IamUserConfigurationRepository iamUserConfigurationRepository;
  @MockitoBean
  private UserConfigSearchMaterializedRefreshService userConfigSearchMaterializedRefreshService;
  private UserStateService userStateService;

  @Before
  public void setup() {
    userStateService = new UserStateService(iamUserConfigurationRepository, userConfigSearchMaterializedRefreshService);
  }

  @Test
  public void testUpdateStateForDeletedOktaProfile() {
    IamUserConfiguration configuration = new IamUserConfiguration();
    userStateService.updateStateForDeletedOktaProfile(configuration);

    assertEquals(UserStateEnum.INACTIVE.dbValue, configuration.getState());
    assertFalse(configuration.getActive());
    assertEquals(UserStateDescriptionEnum.DELETED.dbValue, configuration.getStateDescription());
    assertEquals(UserStateActionEnum.DELETED.dbValue, configuration.getStateAction());
    assertNotNull(configuration.getStatusLastUpdated());
    verify(iamUserConfigurationRepository, times(1)).save(any());
  }

  @Test
  public void testSetStateOnboardingStaged() {
    IamUserConfiguration configuration = new IamUserConfiguration();
    userStateService.setStateOnboardingStaged(configuration);

    assertEquals(UserStateEnum.ONBOARDING.dbValue, configuration.getState());
    assertFalse(configuration.getActive());
    assertEquals(UserStateDescriptionEnum.STAGED.dbValue, configuration.getStateDescription());
    assertEquals(UserStateActionEnum.ONBOARDING.dbValue, configuration.getStateAction());
    assertNotNull(configuration.getStatusLastUpdated());
  }

  @Test
  public void testSetStateOnboardingPendingUser() {
    IamUserConfiguration configuration = new IamUserConfiguration();
    userStateService.setStateOnboardingPendingUser(configuration);

    assertEquals(UserStateEnum.PROVISIONED.dbValue, configuration.getState());
    assertTrue(configuration.getActive());
    assertEquals(UserStateDescriptionEnum.PENDING_USER_ACTION.dbValue, configuration.getStateDescription());
    assertEquals(UserStateActionEnum.ONBOARDING.dbValue, configuration.getStateAction());
    assertNotNull(configuration.getStatusLastUpdated());
  }

  @Test
  public void testSetState2FaPendingUser() {
    IamUserConfiguration configuration = new IamUserConfiguration();
    userStateService.setState2FaPendingUser(configuration);

    assertEquals(UserStateEnum.PROVISIONED.dbValue, configuration.getState());
    assertTrue(configuration.getActive());
    assertEquals(UserStateDescriptionEnum.PENDING_USER_ACTION.dbValue, configuration.getStateDescription());
    assertEquals(UserStateActionEnum.SET_2FA.dbValue, configuration.getStateAction());
    assertNotNull(configuration.getStatusLastUpdated());
  }

  @Test
  public void testSetStatePasswordPendingUser() {
    IamUserConfiguration configuration = new IamUserConfiguration();
    userStateService.setStatePasswordPendingUser(configuration);

    assertEquals(UserStateEnum.PROVISIONED.dbValue, configuration.getState());
    assertTrue(configuration.getActive());
    assertEquals(UserStateDescriptionEnum.PENDING_USER_ACTION.dbValue, configuration.getStateDescription());
    assertEquals(UserStateActionEnum.SET_PASSWORD.dbValue, configuration.getStateAction());
    assertNotNull(configuration.getStatusLastUpdated());
  }

  @Test
  public void testSetStatePasswordExpired() {
    IamUserConfiguration configuration = new IamUserConfiguration();
    userStateService.setStatePasswordExpired(configuration);

    assertEquals(UserStateEnum.RECOVERY.dbValue, configuration.getState());
    assertTrue(configuration.getActive());
    assertEquals(UserStateDescriptionEnum.PASSWORD_EXPIRED.dbValue, configuration.getStateDescription());
    assertEquals(UserStateActionEnum.PASSWORD_EXPIRED.dbValue, configuration.getStateAction());
    assertNotNull(configuration.getStatusLastUpdated());
  }

  @Test
  public void testSetStateActive() {
    IamUserConfiguration configuration = new IamUserConfiguration();
    userStateService.setStateActive(configuration);

    assertEquals(UserStateEnum.ACTIVE.dbValue, configuration.getState());
    assertTrue(configuration.getActive());
    assertEquals(UserStateDescriptionEnum.ACTIVE.dbValue, configuration.getStateDescription());
    assertEquals("", configuration.getStateAction());
    assertNotNull(configuration.getStatusLastUpdated());
  }

  @Test
  public void testSetStateReset(){
    IamUserConfiguration configuration = new IamUserConfiguration();
    userStateService.setStateReset(configuration);

    assertEquals(UserStateEnum.RECOVERY.dbValue, configuration.getState());
    assertTrue(configuration.getActive());
    assertEquals(UserStateDescriptionEnum.PASSWORD_RESET.dbValue, configuration.getStateDescription());
    assertEquals(UserStateActionEnum.PASSWORD_RESET.dbValue, configuration.getStateAction());
    assertNotNull(configuration.getStatusLastUpdated());
  }

  @Test
  public void testSetStateSuspended(){
    IamUserConfiguration configuration = new IamUserConfiguration();
    userStateService.setStateSuspended(configuration);

    assertEquals(UserStateEnum.INACTIVE.dbValue, configuration.getState());
    assertFalse(configuration.getActive());
    assertEquals(UserStateDescriptionEnum.SUSPENDED.dbValue, configuration.getStateDescription());
    assertEquals("", configuration.getStateAction());
    assertNotNull(configuration.getStatusLastUpdated());
  }

  @Test
  public void testSetStateLockedOut(){
    IamUserConfiguration configuration = new IamUserConfiguration();
    userStateService.setStateLockedOut(configuration);

    assertEquals(UserStateEnum.INACTIVE.dbValue, configuration.getState());
    assertFalse(configuration.getActive());
    assertEquals(UserStateDescriptionEnum.LOCKED.dbValue, configuration.getStateDescription());
    assertEquals(UserStateActionEnum.LOCKED.dbValue, configuration.getStateAction());
    assertNotNull(configuration.getStatusLastUpdated());
  }

  @Test
  public void testSetStateDecommissioned(){
    IamUserConfiguration configuration = new IamUserConfiguration();
    userStateService.setStateDecommissioned(configuration);

    assertEquals(UserStateEnum.DECOMMISSIONED.dbValue, configuration.getState());
    assertFalse(configuration.getActive());
    assertEquals(UserStateDescriptionEnum.SUSPENDED.dbValue, configuration.getStateDescription());
    assertEquals(UserStateActionEnum.SUSPENDED.dbValue, configuration.getStateAction());
    assertNotNull(configuration.getStatusLastUpdated());
  }

  @Test
  public void testSaveStateOnboardingPendingUser(){
    IamUserConfiguration configuration = new IamUserConfiguration();
    userStateService.saveStateOnboardingPendingUser(configuration);

    assertEquals(UserStateEnum.PROVISIONED.dbValue, configuration.getState());
    assertTrue(configuration.getActive());
    assertEquals(UserStateDescriptionEnum.PENDING_USER_ACTION.dbValue, configuration.getStateDescription());
    assertEquals(UserStateActionEnum.ONBOARDING.dbValue, configuration.getStateAction());
    assertNotNull(configuration.getStatusLastUpdated());
    verify(iamUserConfigurationRepository, times(1)).save(any());
  }

  @Test
  public void testSavePasswordReset(){
    when(iamUserConfigurationRepository.findById(any())).thenReturn(Optional.of(MockData.getIamUserConfigurationEntity()));
    userStateService.savePasswordReset(1);
    verify(iamUserConfigurationRepository, times(1)).save(any());
  }

  // NWPI-15109: decommissioned is now sticky, so an unrecognised Okta status must not decommission a
  // live user - RECOVERY is simply a password reset in progress, and used to self-heal on the next sync.
  @Test
  public void testUpdateStateFromOktaProfileLeavesStateAloneOnTransientStatus() {
    for (String transientStatus : new String[] {"RECOVERY", "PROVISIONED", "STAGED"}) {
      IamUserConfiguration configuration = MockData.getIamUserConfigurationEntity();
      configuration.setIdp("nbin");
      resetUserState(configuration);
      configuration.setState(UserStateEnum.ACTIVE.dbValue);
      configuration.setActive(true);
      configuration.setStateDescription(UserStateDescriptionEnum.ACTIVE.dbValue);
      configuration.setStateAction("");

      OktaUserProfile oktaUserProfile = MockData.getOktaUserProfile();
      oktaUserProfile.setStatus(transientStatus);

      userStateService.updateStateFromOktaProfile(configuration, oktaUserProfile);

      assertEquals(UserStateEnum.ACTIVE.dbValue, configuration.getState(),
          "status " + transientStatus + " must not decommission a live user");
      assertTrue(configuration.getActive());
    }
    verify(iamUserConfigurationRepository, times(0)).save(any());
    clearInvocations(iamUserConfigurationRepository);
  }

  @Test
  public void testUpdateStateFromOktaProfileDecommissionsOnDeprovisioned() {
    IamUserConfiguration configuration = MockData.getIamUserConfigurationEntity();
    configuration.setIdp("nbin");
    resetUserState(configuration);
    configuration.setState(UserStateEnum.ACTIVE.dbValue);
    configuration.setActive(true);
    configuration.setStateDescription(UserStateDescriptionEnum.ACTIVE.dbValue);
    configuration.setStateAction("");

    OktaUserProfile oktaUserProfile = MockData.getOktaUserProfile();
    oktaUserProfile.setStatus(Constants.IDP_STATUS_DEPROVISIONED);

    userStateService.updateStateFromOktaProfile(configuration, oktaUserProfile);

    assertEquals(UserStateEnum.DECOMMISSIONED.dbValue, configuration.getState());
    assertFalse(configuration.getActive());
    verify(iamUserConfigurationRepository, times(1)).save(any());
    clearInvocations(iamUserConfigurationRepository);
  }

  @Test
  public void testUpdateStateForDeletedOktaProfileKeepsDecommissioned() {
    // NWPI-15109: an Okta 404 reaches updateStateForDeletedOktaProfile, which would otherwise
    // downgrade a deliberately retired account to 'inactive'/Deleted and break migration sign-off.
    IamUserConfiguration configuration = new IamUserConfiguration();
    configuration.setState(UserStateEnum.DECOMMISSIONED.dbValue);
    configuration.setActive(false);
    configuration.setStateDescription(UserStateDescriptionEnum.SUSPENDED.dbValue);
    configuration.setStateAction(UserStateActionEnum.SUSPENDED.dbValue);

    userStateService.updateStateForDeletedOktaProfile(configuration);

    assertEquals(UserStateEnum.DECOMMISSIONED.dbValue, configuration.getState());
    assertFalse(configuration.getActive());
    verify(iamUserConfigurationRepository, times(0)).save(any());
    clearInvocations(iamUserConfigurationRepository);
  }

  @Test
  public void testUpdateStateFromOktaProfileSkipsDecommissionedUser() {
    // NWPI-15109: sunset retires the account in the DB, but Okta still reports it ACTIVE. Without the
    // guard the SSO branch maps that straight to setStateActive and resurrects a retired account.
    IamUserConfiguration configuration = MockData.getIamUserConfigurationEntity();
    configuration.setIdp("nbin");
    configuration.setState(UserStateEnum.DECOMMISSIONED.dbValue);
    configuration.setActive(false);
    configuration.setStateDescription(UserStateDescriptionEnum.SUSPENDED.dbValue);
    configuration.setStateAction(UserStateActionEnum.SUSPENDED.dbValue);

    OktaUserProfile oktaUserProfile = MockData.getOktaUserProfile();
    oktaUserProfile.setStatus(Constants.IDP_STATUS_ACTIVE);

    userStateService.updateStateFromOktaProfile(configuration, oktaUserProfile);

    assertEquals(UserStateEnum.DECOMMISSIONED.dbValue, configuration.getState());
    assertFalse(configuration.getActive());
    verify(iamUserConfigurationRepository, times(0)).save(any());
    clearInvocations(iamUserConfigurationRepository);
  }

  @Test
  public void testUpdateStateFromOktaProfileStillSyncsSuspendedUser() {
    // Only setStateDecommissioned writes 'decommissioned'; suspended and locked-out users are
    // 'inactive', so the guard must not stop them following Okta out of the suspended state.
    IamUserConfiguration configuration = MockData.getIamUserConfigurationEntity();
    configuration.setIdp("nbin");
    configuration.setState(UserStateEnum.INACTIVE.dbValue);
    configuration.setActive(false);
    configuration.setStateDescription(UserStateDescriptionEnum.SUSPENDED.dbValue);
    configuration.setStateAction("");

    OktaUserProfile oktaUserProfile = MockData.getOktaUserProfile();
    oktaUserProfile.setStatus(Constants.IDP_STATUS_ACTIVE);

    userStateService.updateStateFromOktaProfile(configuration, oktaUserProfile);

    assertNotEquals(UserStateEnum.INACTIVE.dbValue, configuration.getState());
    verify(iamUserConfigurationRepository, times(1)).save(any());
    clearInvocations(iamUserConfigurationRepository);
  }

  @Test
  public void testUpdateStateFromOktaProfile() {
    IamUserConfiguration configuration = MockData.getIamUserConfigurationEntity();
    configuration.setIdp("non-nbin");
    resetUserState(configuration);

    OktaUserProfile oktaUserProfile = MockData.getOktaUserProfile();

    // Password expired, recovery question is null and factor type is empty
    resetUserState(configuration);
    configuration.setIdp("nbin");
    oktaUserProfile.setStatus(Constants.IDP_STATUS_PASSWORD_EXPIRED);
    oktaUserProfile.setFactors(null);
    userStateService.updateStateFromOktaProfile(configuration, oktaUserProfile);
    verify(iamUserConfigurationRepository, times(1)).save(any());
    clearInvocations(iamUserConfigurationRepository);

    // Password expired, recovery question is null and factors is inactive sms
    resetUserState(configuration);
    oktaUserProfile = MockData.getOktaUserProfile();
    oktaUserProfile.setStatus(Constants.IDP_STATUS_PASSWORD_EXPIRED);
    oktaUserProfile.getFactors()[0].setStatus("INACTIVE");
    userStateService.updateStateFromOktaProfile(configuration, oktaUserProfile);
    verify(iamUserConfigurationRepository, times(1)).save(any());
    clearInvocations(iamUserConfigurationRepository);

    // Password expired status, recovery question is null and factors is active sms
    resetUserState(configuration);
    oktaUserProfile = MockData.getOktaUserProfile();
    oktaUserProfile.setStatus(Constants.IDP_STATUS_PASSWORD_EXPIRED);
    oktaUserProfile.getFactors()[0].setStatus("ACTIVE");
    userStateService.updateStateFromOktaProfile(configuration, oktaUserProfile);
    verify(iamUserConfigurationRepository, times(1)).save(any());
    clearInvocations(iamUserConfigurationRepository);

    // Password expired status, recovery question is null and factors is unknown
    resetUserState(configuration);
    oktaUserProfile = MockData.getOktaUserProfile();
    oktaUserProfile.setStatus(Constants.IDP_STATUS_PASSWORD_EXPIRED);
    oktaUserProfile.getFactors()[0].setFactorType("UNKNOWN");
    userStateService.updateStateFromOktaProfile(configuration, oktaUserProfile);
    verify(iamUserConfigurationRepository, times(1)).save(any());
    clearInvocations(iamUserConfigurationRepository);

    // Active status, recovery question is null
    resetUserState(configuration);
    oktaUserProfile = MockData.getOktaUserProfile();
    oktaUserProfile.setStatus(Constants.IDP_STATUS_ACTIVE);
    userStateService.updateStateFromOktaProfile(configuration, oktaUserProfile);
    verify(iamUserConfigurationRepository, times(1)).save(any());
    clearInvocations(iamUserConfigurationRepository);

    // Suspended status
    resetUserState(configuration);
    oktaUserProfile = MockData.getOktaUserProfile();
    oktaUserProfile.setStatus(Constants.IDP_STATUS_SUSPENDED);
    userStateService.updateStateFromOktaProfile(configuration, oktaUserProfile);
    verify(iamUserConfigurationRepository, times(1)).save(any());
    clearInvocations(iamUserConfigurationRepository);

    // Locked out status
    resetUserState(configuration);
    oktaUserProfile = MockData.getOktaUserProfile();
    oktaUserProfile.setStatus(Constants.IDP_STATUS_LOCKED_OUT);
    userStateService.updateStateFromOktaProfile(configuration, oktaUserProfile);
    verify(iamUserConfigurationRepository, times(1)).save(any());
    clearInvocations(iamUserConfigurationRepository);

    // Unknown status - must NOT decommission. It previously did, which was harmless while the state
    // could be re-derived, but decommissioned is now sticky (NWPI-15109).
    resetUserState(configuration);
    oktaUserProfile = MockData.getOktaUserProfile();
    oktaUserProfile.setStatus("Unknown");
    userStateService.updateStateFromOktaProfile(configuration, oktaUserProfile);
    verify(iamUserConfigurationRepository, times(0)).save(any());
    clearInvocations(iamUserConfigurationRepository);
  }

  @Test
  public void testHasSmsInactive() {
    // No factors
    assertTrue(userStateService.hasSmsInactive(new OktaFactor[]{}));

    // Email factor
    OktaFactor oktaFactor = new OktaFactor();
    oktaFactor.setFactorType("email");
    OktaFactor[] oktaFactors = new OktaFactor[]{oktaFactor};
    assertFalse(userStateService.hasSmsInactive(oktaFactors));

    // SMS factor, ACTIVE status
    oktaFactor.setFactorType("sms");
    oktaFactor.setStatus("ACTIVE");
    oktaFactors = new OktaFactor[]{oktaFactor};
    assertFalse(userStateService.hasSmsInactive(oktaFactors));

    // SMS factor, PENDING_ACTIVATION status
    oktaFactor.setFactorType("sms");
    oktaFactor.setStatus("PENDING_ACTIVATION");
    oktaFactors = new OktaFactor[]{oktaFactor};
    assertFalse(userStateService.hasSmsInactive(oktaFactors));

    // SMS factor, OTHER status
    oktaFactor.setFactorType("sms");
    oktaFactor.setStatus("OTHER");
    oktaFactors = new OktaFactor[]{oktaFactor};
    assertTrue(userStateService.hasSmsInactive(oktaFactors));
  }

  private void resetUserState(IamUserConfiguration configuration) {
    configuration.setState("");
    configuration.setStateDescription("");
    configuration.setStateAction("");
    configuration.setActive(false);
  }
}
