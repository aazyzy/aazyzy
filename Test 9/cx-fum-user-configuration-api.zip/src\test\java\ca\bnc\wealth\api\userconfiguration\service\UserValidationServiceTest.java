package ca.bnc.wealth.api.userconfiguration.service;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.userconfiguration.util.Constants;
import ca.bnc.wealth.api.userconfiguration.util.MockData;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.fum.service.FeaturePackageServiceHelper;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletWebRequest;

@RunWith(SpringRunner.class)
public class UserValidationServiceTest {
  private UserValidationService userValidationService;
  @MockitoBean private R2Service r2Service;
  @MockitoBean private UserService userService;
  @MockitoBean private IamUserConfigurationRepository iamUserConfigurationRepository;
  @MockitoBean private FirmRepository firmRepository;
  @MockitoBean private FeaturePackageServiceHelper featurePackageServiceHelper;

  @Before
  public void setup() {
    userValidationService =
        new UserValidationService(
            r2Service, userService, iamUserConfigurationRepository, firmRepository, featurePackageServiceHelper);

    RequestAttributes mockRequest = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(mockRequest);
  }

  @Test
  public void test_validateUserFailure() {
    UserConfiguration user = new UserConfiguration();
    user.setEmail("test@nbc.ca");
    user.setBngfReferenceId("123456");
    user.setUsername(MockData.USER_NAME_LABEL);

    UserConfiguration newUser = new UserConfiguration();
    newUser.setExternalClientId("idpUserId");
    newUser.setEmail("test@nbc.ca");
    newUser.setUsername(MockData.USER_NAME_LABEL);
    newUser.setFirmId("firmId");
    newUser.setHashedPassword("hashedPassword");
    newUser.setPreferredLanguage("XX");
    Map<String,String> map = new HashMap<>();
    map.put("pref", "123456");
    newUser.setUserPreferences(map);

    when(userService.generateBngfReferenceId(anyString(), anyString())).thenReturn("123456");
    when(userService.validRrCodeRangeForFirmId(anyString(), anyList(), anyList()))
        .thenReturn(false);
    when(iamUserConfigurationRepository.findFirstByBngfReferenceId(anyString()))
        .thenReturn(Optional.of(new IamUserConfiguration()));
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(anyString()))
        .thenReturn(Optional.of(new IamUserConfiguration()));
    Map<String, String> response = userValidationService.validateUser(newUser);
    assert (response.containsKey(Constants.BNGF_REFERENCE_ID));
    assert (response.containsKey(Constants.USERNAME));
    assert (response.containsKey(Constants.RR_CODES));
    assert (response.containsKey(Constants.HASHED_PASSWORD));
    assert (response.containsKey(Constants.PREFERRED_LANGUAGE));
  }

  @Test
  public void test_validateBngfReferenceIdFailure() {
    UserConfiguration newUser = new UserConfiguration();
    newUser.setExternalClientId("idpUserId");
    newUser.setFirmId("firmId");

    IamUserConfiguration existing = new IamUserConfiguration();
    existing.setIdpUserIdentifier("idpUserId");
    existing.setBngfReferenceId("123456");

    when(userService.generateBngfReferenceId(anyString(), anyString())).thenReturn("123456");
    when(iamUserConfigurationRepository.findFirstByBngfReferenceId(anyString()))
        .thenReturn(Optional.of(existing));
    Map<String, String> response = new HashMap<>();
    userValidationService.validateBngfReferenceId(newUser, response);
    assert (response.containsKey(Constants.BNGF_REFERENCE_ID));
  }

  @Test
  public void test_validateBngfReferenceIdCloneUser() {
    UserConfiguration newUser = new UserConfiguration();
    newUser.setExternalClientId("idpUserId");
    newUser.setFirmId("firmId");

    IamUserConfiguration existing = new IamUserConfiguration();
    existing.setIdpUserIdentifier("idpUserId");
    existing.setBngfReferenceId("123456");

    when(userService.generateBngfReferenceId(anyString(), anyString())).thenReturn("123456");
    when(iamUserConfigurationRepository.findFirstByBngfReferenceId(anyString()))
        .thenReturn(Optional.empty());
    Map<String, String> response = new HashMap<>();
    userValidationService.validateBngfReferenceId(newUser, response);
    assert (response.isEmpty());
  }

  @Test
  public void test_validateBngfReferenceIdCloneUserExists() {
    UserConfiguration newUser = new UserConfiguration();
    newUser.setExternalClientId("idpUserId");
    newUser.setFirmId("firmId");

    IamUserConfiguration existing = new IamUserConfiguration();
    existing.setIdpUserIdentifier("idpUserId");
    existing.setBngfReferenceId("123456");

    when(userService.generateBngfReferenceId(anyString(), anyString())).thenReturn("123456");
    when(iamUserConfigurationRepository.findFirstByBngfReferenceId(anyString()))
        .thenReturn(Optional.of(existing));
    Map<String, String> response = new HashMap<>();
    userValidationService.validateBngfReferenceId(newUser, response);
    assert (response.containsKey(Constants.BNGF_REFERENCE_ID));
  }

  @Test
  public void test_validateBngfReferenceIdUpdatingUserJIT() {
    UserConfiguration newUser = new UserConfiguration();
    newUser.setExternalClientId("idpUserId");
    newUser.setFirmId("firmId");
    newUser.setExternalClientId("externalClientId");
    newUser.setIdpUserId("idpUserId");

    IamUserConfiguration existing = new IamUserConfiguration();
    existing.setIdpUserIdentifier("idpUserId");
    existing.setBngfReferenceId("123456");

    when(userService.generateBngfReferenceId(anyString(), anyString())).thenReturn("123456");
    when(iamUserConfigurationRepository.findFirstByBngfReferenceId(anyString()))
        .thenReturn(Optional.of(existing));
    Map<String, String> response = new HashMap<>();
    userValidationService.validateBngfReferenceId(newUser, response);
    assert (response.isEmpty());
  }

  @Test
  public void test_validateExternalSSOEnabledUser_noExternalClientId() {
    UserConfiguration newUser = new UserConfiguration();
    assertTrue(userValidationService.isExternalSSOEnabled(newUser));
  }

  @Test
  public void test_validateExternalSSOEnabledUser_hasExternalClientIdButFirmIsNotSSOEnabled() {
    UserConfiguration newUser = new UserConfiguration();
    newUser.setExternalClientId("externalClientId");
    newUser.setFirmId("firmId");
    Firm firm = new Firm();
    when(firmRepository.findByFirmId(anyString())).thenReturn(firm);
    assertFalse(userValidationService.isExternalSSOEnabled(newUser));
  }

  @Test
  public void test_validateExternalSSOEnabledUser_hasExternalClientIdButFirmIsSSOEnabled() {
    UserConfiguration newUser = new UserConfiguration();
    newUser.setExternalClientId("externalClientId");
    newUser.setFirmId("firmId");
    Firm firm = new Firm();
    firm.setIdentitySource("SSO");
    when(firmRepository.findByFirmId(anyString())).thenReturn(firm);
    assertTrue(userValidationService.isExternalSSOEnabled(newUser));
  }

  @Test
  public void test_validateExternalSSOEnabledUser_hasExternalClientIdButFirmIsCPX() {
    UserConfiguration newUser = new UserConfiguration();
    newUser.setExternalClientId("externalClientId");
    newUser.setFirmId("firmId");
    Firm firm = new Firm();
    firm.setIdentitySource("cpx");
    when(firmRepository.findByFirmId(anyString())).thenReturn(firm);
    assertFalse(userValidationService.isExternalSSOEnabled(newUser));
  }

  @Test
  public void test_validateUserConfigurationUpdate_noR2IdProvided() {
    when(userService.isValidFirmId(any())).thenReturn(true);
    when(userService.validRrCodeRangeForFirmId(any(), any(), any())).thenReturn(true);

    UserConfiguration currentUser = MockData.getUserConfiguration();
    currentUser.setCompassR2Id("r2Id");

    UserConfiguration newUser = MockData.getUserConfiguration();
    newUser.setCompassR2Id("");

    try {
      userValidationService.validateUserConfigurationUpdate(currentUser, newUser);
    } catch (Exception e) {
      fail("Should not throw exception");
    }
  }

  @Test(expected = FumServiceException.class)
  public void test_validateUserConfigurationUpdate_invalidR2IdProvided() {
    when(userService.isValidFirmId(any())).thenReturn(true);
    when(userService.validRrCodeRangeForFirmId(any(), any(), any())).thenReturn(true);
    when(r2Service.r2ValidationForUpdateUser(anyString(), anyString())).thenReturn(
        Pair.of(false, Constants.ERROR_R2_NOT_FOUND));

    UserConfiguration currentUser = MockData.getUserConfiguration();
    currentUser.setCompassR2Id("r2Id");

    UserConfiguration newUser = MockData.getUserConfiguration();
    newUser.setCompassR2Id("r2Id-new");

    userValidationService.validateUserConfigurationUpdate(currentUser, newUser);
  }

  @Test(expected = FumServiceException.class)
  public void test_validateUserConfigurationUpdate_invalidFirmId() {
    when(userService.isValidFirmId(any())).thenReturn(false);
    when(userService.validRrCodeRangeForFirmId(any(), any(), any())).thenReturn(true);

    UserConfiguration currentUser = MockData.getUserConfiguration();
    UserConfiguration newUser = MockData.getUserConfiguration();

    userValidationService.validateUserConfigurationUpdate(currentUser, newUser);
  }

  @Test
  public void test_validateUserConfigurationUpdate_validR2IdProvided() {
    when(userService.isValidFirmId(any())).thenReturn(true);
    when(userService.validRrCodeRangeForFirmId(any(), any(), any())).thenReturn(true);
    when(r2Service.r2ValidationForUpdateUser(anyString(), anyString())).thenReturn(
        Pair.of(true, null));

    UserConfiguration currentUser = MockData.getUserConfiguration();
    currentUser.setCompassR2Id("r2Id");

    UserConfiguration newUser = MockData.getUserConfiguration();
    newUser.setCompassR2Id("r2Id-new");

    try {
      userValidationService.validateUserConfigurationUpdate(currentUser, newUser);
    } catch (Exception e) {
      fail("Should not throw exception");
    }
  }

}
