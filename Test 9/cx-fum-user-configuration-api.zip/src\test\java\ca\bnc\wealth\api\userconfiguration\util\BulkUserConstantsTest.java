package ca.bnc.wealth.api.userconfiguration.util;

import java.lang.reflect.Constructor;
import org.junit.Test;

public class BulkUserConstantsTest {

  @Test(expected = IllegalStateException.class)
  public void testBulkUserConstantsConstructor() throws Exception {
    Constructor<BulkUserConstants> constructor = BulkUserConstants.class.getDeclaredConstructor();
    constructor.setAccessible(true);
    try {
      constructor.newInstance();
    } catch (Exception e) {
      throw (IllegalStateException) e.getCause();
    }
  }
}
