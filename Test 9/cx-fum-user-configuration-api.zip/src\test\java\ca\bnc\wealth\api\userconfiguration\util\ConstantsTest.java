package ca.bnc.wealth.api.userconfiguration.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.Constructor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.junit.Test;

public class ConstantsTest {

  @Test(expected = IllegalStateException.class)
  public void testConstantsConstructor() throws Exception {
    Constructor<Constants> constructor = Constants.class.getDeclaredConstructor();
    constructor.setAccessible(true);
    try {
      constructor.newInstance();
    } catch (Exception e) {
      throw (IllegalStateException) e.getCause();
    }
  }

  @Test
  public void testHashedPasswordRegex() {
    String algo = "$2a$";
    int workFactor = 12;
    String salt = "R9h/cIPz0gi.URNNX3kh2O";
    String hashValue = "PST9/PgBkqquzi.Ss7KIUgO2t0jWMUW";

    String hashedPassword = algo + workFactor + "$" + salt + hashValue;

    Pattern pattern = Pattern.compile(Constants.BCRYPT_HASH_REGEX);
    Matcher matcher = pattern.matcher(hashedPassword);

    // Valid hashed password
    assertTrue(matcher.matches() && matcher.groupCount() == 4);
    assertEquals(hashedPassword, matcher.group(0));
    assertEquals(algo, matcher.group(1));
    assertEquals(String.valueOf(workFactor), matcher.group(2));
    assertEquals(salt, matcher.group(3));
    assertEquals(hashValue, matcher.group(4));

    // Invalid format
    assertFalse(Pattern.matches(Constants.BCRYPT_HASH_REGEX, "invalid_string"));
    // Invalid algorithm
    assertFalse(Pattern.matches(Constants.BCRYPT_HASH_REGEX,
        "invalid" + workFactor + "$" + salt + hashValue));
    // Invalid factor
    assertFalse(
        Pattern.matches(Constants.BCRYPT_HASH_REGEX, algo + "invalid" + "$" + salt + hashValue));
    // Invalid salt
    assertFalse(Pattern.matches(Constants.BCRYPT_HASH_REGEX,
        algo + workFactor + "$" + "invalid" + hashValue));
    // Invalid hash value
    assertFalse(
        Pattern.matches(Constants.BCRYPT_HASH_REGEX, algo + workFactor + "$" + salt + "invalid"));
    // Too long string
    assertFalse(Pattern.matches(Constants.BCRYPT_HASH_REGEX, hashedPassword + "x"));
  }
}
