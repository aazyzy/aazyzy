package ca.bnc.wealth.api.userconfiguration.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamContentTranslation;
import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import ca.bnc.wealth.common.jpa.entity.iam.UserGroup;
import ca.bnc.wealth.common.jpa.entity.platform.CodeValueMapping;
import ca.bnc.wealth.common.jpa.entity.platform.FirmConfiguration;
import ca.bnc.wealth.common.jpa.entity.platform.RrCodeRange;
import ca.bnc.wealth.common.jpa.entity.platform.RrCodeRangeAssignment;
import ca.bnc.wealth.common.jpa.entity.platform.UserEntityAssignment;
import ca.bnc.wealth.common.jpa.entity.platform.UserGroupAssignment;
import ca.bnc.wealth.common.kafka.model.RrCodeRanges;
import ca.bnc.wealth.common.sz.model.SzUser;
import ca.bnc.wealth.common.sz.model.SzUserSearch;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.UamaUser;
import ca.bnc.wealth.common.userconfiguration.model.UamaUserSearchResponse;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.lang.reflect.Constructor;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Test;

public class MapperUtilsTest {

  @Test(expected = IllegalStateException.class)
  public void testMapperUtilsConstructor() throws Exception {
    Constructor<MapperUtils> constructor = MapperUtils.class.getDeclaredConstructor();
    constructor.setAccessible(true);
    try {
      constructor.newInstance();
    } catch (Exception e) {
      throw (IllegalStateException) e.getCause();
    }
  }

  @Test
  public void testRrCodeRangeEntityToDto() {
    RrCodeRange rrCodeRangeEntity = new RrCodeRange();
    rrCodeRangeEntity.setRrCodeRangeId(1);
    rrCodeRangeEntity.setFromRrCode("fromRrCode");
    rrCodeRangeEntity.setToRrCode("toRrCode");
    rrCodeRangeEntity.setFromRrCodeB10(123);
    rrCodeRangeEntity.setToRrCodeB10(321);
    rrCodeRangeEntity.setCreatedBy("createdBy");
    rrCodeRangeEntity.setLastUpdatedBy("lastUpdatedBy");
    rrCodeRangeEntity.setCreationDate(new Timestamp(System.currentTimeMillis()));
    rrCodeRangeEntity.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));

    RRCodeRange rrCodeRangeDto = MapperUtils.toDto(rrCodeRangeEntity);
    assertEquals(Integer.valueOf((int) rrCodeRangeEntity.getRrCodeRangeId()),
        rrCodeRangeDto.getRrCodeRangeId());
    assertEquals(rrCodeRangeEntity.getFromRrCode(), rrCodeRangeDto.getFromRRCode());
    assertEquals(rrCodeRangeEntity.getToRrCode(), rrCodeRangeDto.getToRRCode());
    assertEquals(Integer.valueOf((int) rrCodeRangeEntity.getFromRrCodeB10()),
        rrCodeRangeDto.getFromRRCodeB10());
    assertEquals(Integer.valueOf((int) rrCodeRangeEntity.getToRrCodeB10()),
        rrCodeRangeDto.getToRRCodeB10());
    assertEquals(rrCodeRangeEntity.getCreatedBy(), rrCodeRangeDto.getCreatedBy());
    assertEquals(rrCodeRangeEntity.getLastUpdatedBy(), rrCodeRangeDto.getLastUpdatedBy());
    assertEquals(rrCodeRangeEntity.getCreationDate().toLocalDateTime(),
        rrCodeRangeDto.getCreationDate());
    assertEquals(rrCodeRangeEntity.getLastUpdateDate().toLocalDateTime(),
        rrCodeRangeDto.getLastUpdatedDate());
  }

  @Test
  public void testToRRCodeRangeDto() {
    Map<String, Object> rrCodeMap = new HashMap<>();
    rrCodeMap.put("RR_CODE_RANGE_ID", 1);
    rrCodeMap.put("CREATED_BY", "user");
    rrCodeMap.put("CREATION_DATE", null);
    rrCodeMap.put("LAST_UPDATED_BY", "user");
    rrCodeMap.put("LAST_UPDATE_DATE", null);
    rrCodeMap.put("FROM_RR_CODE", "AAAA");
    rrCodeMap.put("FROM_RR_CODE_B10", 12345L);
    rrCodeMap.put("TO_RR_CODE", "9999");
    rrCodeMap.put("TO_RR_CODE_B10", 54321L);

    RRCodeRange rrCodeRange = MapperUtils.toRRCodeRangeDto(rrCodeMap);
    assertEquals(String.valueOf(rrCodeMap.get("RR_CODE_RANGE_ID")),
        String.valueOf(rrCodeRange.getRrCodeRangeId()));
    assertEquals(rrCodeMap.get("FROM_RR_CODE"), rrCodeRange.getFromRRCode());
    assertEquals(((Long) rrCodeMap.get("FROM_RR_CODE_B10")).intValue(), rrCodeRange.getFromRRCodeB10().intValue());
    assertEquals(rrCodeMap.get("TO_RR_CODE"), rrCodeRange.getToRRCode());
    assertEquals(((Long) rrCodeMap.get("TO_RR_CODE_B10")).intValue(), rrCodeRange.getToRRCodeB10().intValue());
    assertEquals(rrCodeMap.get("CREATED_BY"), rrCodeRange.getCreatedBy());
    assertEquals(rrCodeMap.get("CREATION_DATE"), rrCodeRange.getCreationDate());
    assertEquals(rrCodeMap.get("LAST_UPDATED_BY"), rrCodeRange.getLastUpdatedBy());
    assertEquals(rrCodeMap.get("LAST_UPDATE_DATE"), rrCodeRange.getLastUpdatedDate());

    rrCodeMap.put("CREATION_DATE", new Timestamp(System.currentTimeMillis()));
    rrCodeMap.put("LAST_UPDATE_DATE", new Timestamp(System.currentTimeMillis()));

    rrCodeRange = MapperUtils.toRRCodeRangeDto(rrCodeMap);
    assertEquals(((Timestamp) rrCodeMap.get("CREATION_DATE")).toLocalDateTime(), rrCodeRange.getCreationDate());
    assertEquals(((Timestamp) rrCodeMap.get("LAST_UPDATE_DATE")).toLocalDateTime(), rrCodeRange.getLastUpdatedDate());
  }

  @Test
  public void testRrCodeRangesToDto() {
    List<RrCodeRanges> rrCodeRanges = new ArrayList<>();
    RrCodeRanges r1 = new RrCodeRanges();
    r1.setFromRRCode("AZAA");
    r1.setToRRCode("R3GL");
    rrCodeRanges.add(r1);

    List<RRCodeRange> rrCodeRangeList = MapperUtils.toDto(rrCodeRanges);
    assertEquals(rrCodeRanges.size(), rrCodeRangeList.size());
    assertEquals(rrCodeRanges.get(0).getFromRRCode(), rrCodeRangeList.get(0).getFromRRCode());
    assertEquals(rrCodeRanges.get(0).getToRRCode(), rrCodeRangeList.get(0).getToRRCode());
  }

  @Test
  public void testUserConfigSearchMaterializedViewEntityToDto() {
    UserConfigSearchMaterializedView userConfigurationEntity = new UserConfigSearchMaterializedView();
    userConfigurationEntity.setId(1l);
    userConfigurationEntity.setUserConfigurationId(1l);
    userConfigurationEntity.setActive(true);
    userConfigurationEntity.setPreferredLanguageType(PreferredLanguageType.EN);
    userConfigurationEntity.setCreationDate(new Timestamp(System.currentTimeMillis()));
    userConfigurationEntity.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));

    UserConfiguration userConfigurationDto = MapperUtils.toDto(userConfigurationEntity);
    assertEquals(userConfigurationEntity.getCreationDate().toLocalDateTime(),
        userConfigurationDto.getCreationDate());
    assertEquals(userConfigurationEntity.getLastUpdateDate().toLocalDateTime(),
        userConfigurationDto.getLastUpdatedDate());
  }

  @Test
  public void testUserConfigurationEntityToDto() {
    ca.bnc.wealth.common.jpa.entity.platform.UserConfiguration userConfigurationEntity = new ca.bnc.wealth.common.jpa.entity.platform.UserConfiguration();

    assertNull(userConfigurationEntity.getCodeValueMappingCxpStatusCode());
    assertNull(userConfigurationEntity.getCodeValueMappingCxpStatusCode());
    assertNull(userConfigurationEntity.getCreationDate());
    assertNull(userConfigurationEntity.getLastUpdateDate());

    CodeValueMapping cxpStatusCode = new CodeValueMapping();
    cxpStatusCode.setCodeValue("Active");

    CodeValueMapping cxpSubStatusCode = new CodeValueMapping();
    cxpSubStatusCode.setCodeValue("2FA-PENDING");

    userConfigurationEntity.setCodeValueMappingCxpStatusCode(cxpStatusCode);
    userConfigurationEntity.setCodeValueMappingCxpSubStatusCode(cxpSubStatusCode);
    userConfigurationEntity.setCreationDate(new Timestamp(System.currentTimeMillis()));
    userConfigurationEntity.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));

    UserConfiguration userConfigurationDto = MapperUtils.toDto(userConfigurationEntity);
    assertEquals(userConfigurationEntity.getCodeValueMappingCxpStatusCode().getCodeValue(),
        userConfigurationDto.getStatus());
    assertEquals(userConfigurationEntity.getCodeValueMappingCxpSubStatusCode().getCodeValue(),
        userConfigurationDto.getSubStatus());
    assertEquals(userConfigurationEntity.getCreationDate().toLocalDateTime(),
        userConfigurationDto.getCreationDate());
    assertEquals(userConfigurationEntity.getLastUpdateDate().toLocalDateTime(),
        userConfigurationDto.getLastUpdatedDate());
  }

  @Test
  public void toDtoWithUserGroupAndFirmId() {
    ca.bnc.wealth.common.jpa.entity.platform.UserConfiguration userConfiguration = getMockData();
    UserConfiguration dto = MapperUtils.toDtoWithUserGroupAndFirmId(userConfiguration);

    assertEquals("test@gmail.com", dto.getEmail());
    assertEquals("IAK", dto.getFirmId());
    assertEquals("Wealth.CompassX.SecuritySteward", dto.getUserGroup());

    userConfiguration.setUserGroupAssignments(null);
    dto = MapperUtils.toDtoWithUserGroupAndFirmId(userConfiguration);
    assertNull(dto.getUserGroup());

    userConfiguration.setUserGroupAssignments(new ArrayList<>());
    dto = MapperUtils.toDtoWithUserGroupAndFirmId(userConfiguration);
    assertNull(dto.getUserGroup());

    userConfiguration.setUserEntityAssignments(new ArrayList<>());
    dto = MapperUtils.toDtoWithUserGroupAndFirmId(userConfiguration);
    assertNull(dto.getFirmId());
  }

  @Test
  public void testGetTimeStamp() {
    assertEquals("2023-01-05 11:53:25.607",
        String.valueOf(MapperUtils.getTimeStamp("2023-01-05T11:50:23.182607")));
    assertNull(MapperUtils.getTimeStamp("invalid"));
  }

  private ca.bnc.wealth.common.jpa.entity.platform.UserConfiguration getMockData() {
    ca.bnc.wealth.common.jpa.entity.platform.UserConfiguration userConfiguration = new ca.bnc.wealth.common.jpa.entity.platform.UserConfiguration();
    userConfiguration.setEmail("test@gmail.com");

    FirmConfiguration firmConfiguration = new FirmConfiguration();
    firmConfiguration.setFirmId("IAK");
    UserEntityAssignment uea = new UserEntityAssignment();
    uea.setResourceEntityId(firmConfiguration);
    userConfiguration.setUserEntityAssignments(Arrays.asList(uea));

    UserGroup userGroup = new UserGroup();
    userGroup.setName("Wealth.CompassX.SecuritySteward");
    UserGroupAssignment uga = new UserGroupAssignment();
    uga.setUserGroupId(userGroup);
    userConfiguration.setUserGroupAssignments(Arrays.asList(uga));

    RrCodeRange rrCodeRange = new RrCodeRange();
    rrCodeRange.setFromRrCode("ABZZ");
    rrCodeRange.setToRrCode("AB99");
    RrCodeRangeAssignment rra = new RrCodeRangeAssignment();
    rra.setRrCodeRangeId(rrCodeRange);
    userConfiguration.setRrCodeRangeAssignments(Arrays.asList(rra));

    return userConfiguration;
  }

  @Test
  public void testFirmToEntity() {
    Map<String, Object> firmMap = new HashMap<>();
    firmMap.put("FIRM_ENTITY_ID", 1);
    firmMap.put("FIRM_ID", "NBIN");
    firmMap.put("TYPE", FirmType.IB);
    firmMap.put("NAME", "NBIN");
    firmMap.put("ACTIVE", true);
    firmMap.put("STATE", "onboarding");
    firmMap.put("PREFERRED_LANGUAGE", PreferredLanguageType.EN);
    firmMap.put("CREATED_BY", "user");
    firmMap.put("CREATION_DATE", new Timestamp(System.currentTimeMillis()));
    firmMap.put("LAST_UPDATED_BY", "user");
    firmMap.put("LAST_UPDATE_DATE", new Timestamp(System.currentTimeMillis()));

    Firm firm = MapperUtils.toEntity(firmMap);
    assertEquals(String.valueOf(firmMap.get("FIRM_ENTITY_ID")),
        String.valueOf(firm.getFirmEntityId()));
    assertEquals(firmMap.get("FIRM_ID"), firm.getFirmId());
    assertEquals(firmMap.get("TYPE"), firm.getFirmType());
    assertEquals(firmMap.get("NAME"), firm.getName());
    assertEquals(firmMap.get("ACTIVE"), firm.getActive());
    assertEquals(firmMap.get("STATE"), firm.getState());
    assertEquals(firmMap.get("PREFERRED_LANGUAGE"), firm.getPreferredLanguageType());
    assertEquals(firmMap.get("CREATED_BY"), firm.getCreatedBy());
    assertEquals(firmMap.get("CREATION_DATE"), firm.getCreationDate());
    assertEquals(firmMap.get("LAST_UPDATED_BY"), firm.getLastUpdatedBy());
    assertEquals(firmMap.get("LAST_UPDATE_DATE"), firm.getLastUpdateDate());
  }

  @Test
  public void testToIamContentTranslationEntity() {
    Map<String, Object> recoveryQuestionMap = new HashMap<>();
    recoveryQuestionMap.put("CONTENT_TRANSLATION_ID", 1);
    recoveryQuestionMap.put("TRANSLATION_KEY", "key");
    recoveryQuestionMap.put("TRANSLATION_VALUE", "value");
    recoveryQuestionMap.put("LANGUAGE", "EN");
    recoveryQuestionMap.put("CREATED_BY", "CREATED_BY");
    recoveryQuestionMap.put("CREATED_DT", null);
    recoveryQuestionMap.put("UPDATED_BY", "UPDATED_BY");
    recoveryQuestionMap.put("UPDATED_DT", null);

    IamContentTranslation contentTranslation = MapperUtils.toIamContentTranslationEntity(recoveryQuestionMap);
    assertEquals(((Integer) recoveryQuestionMap.get("CONTENT_TRANSLATION_ID")).longValue(), contentTranslation.getContentTranslationId());
    assertEquals(recoveryQuestionMap.get("TRANSLATION_KEY"), contentTranslation.getTranslationKey());
    assertEquals(recoveryQuestionMap.get("TRANSLATION_VALUE"), contentTranslation.getTranslationValue());
    assertEquals(recoveryQuestionMap.get("LANGUAGE"), contentTranslation.getPreferredLanguage().name());
    assertEquals(recoveryQuestionMap.get("CREATED_BY"), contentTranslation.getCreatedBy());
    assertEquals(recoveryQuestionMap.get("CREATED_DT"), contentTranslation.getCreationDate());
    assertEquals(recoveryQuestionMap.get("UPDATED_BY"), contentTranslation.getLastUpdatedBy());
    assertEquals(recoveryQuestionMap.get("UPDATED_DT"), contentTranslation.getLastUpdateDate());

    recoveryQuestionMap.put("CREATED_DT", new Timestamp(System.currentTimeMillis()));
    recoveryQuestionMap.put("UPDATED_DT", new Timestamp(System.currentTimeMillis()));

    contentTranslation = MapperUtils.toIamContentTranslationEntity(recoveryQuestionMap);
    assertEquals(recoveryQuestionMap.get("CREATED_DT"), contentTranslation.getCreationDate());
    assertEquals(recoveryQuestionMap.get("UPDATED_DT"), contentTranslation.getLastUpdateDate());
  }

  @Test
  public void testSzUserToDto_whenValidSzUser_shouldMapAllFields() {
    SzUser szUser = new SzUser();
    szUser.setId("123");
    szUser.setActive(true);
    szUser.setUserName("testUser");
    szUser.setFamilyName("Doe");
    szUser.setGivenName("John");
    szUser.setExternalId("ext123");
    szUser.setUserType("NBIN");
    szUser.setPreferredLanguage("en");
    szUser.setGroups(List.of("group1", "group2"));
    szUser.setEmpId("emp456");

    UamaUser result = MapperUtils.toDto(szUser);

    assertEquals("123", result.getId());
    assertEquals(true, result.getActive());
    assertEquals("testUser", result.getUserName());
    assertEquals("Doe", result.getFamilyName());
    assertEquals("John", result.getGivenName());
    assertEquals("ext123", result.getExternalId());
    assertEquals("NBIN", result.getUserType());
    assertEquals("en", result.getPreferredLanguage());
    assertEquals(List.of("group1", "group2"), result.getGroups());
    assertEquals("emp456", result.getEmpId());
  }

  @Test
  public void testSzUserToDto_whenNullSzUser_shouldReturnNull() {
    assertNull(MapperUtils.toDto((SzUser) null));
  }

  @Test
  public void testSzUserSearchToDto_whenValidSzUserSearch_shouldMapAllFields() {
    SzUser szUser1 = new SzUser();
    szUser1.setId("u1");
    szUser1.setUserName("user1");
    szUser1.setActive(true);
    SzUser szUser2 = new SzUser();
    szUser2.setId("u2");
    szUser2.setUserName("user2");
    szUser2.setActive(false);

    SzUserSearch szUserSearch = new SzUserSearch();
    szUserSearch.setStartIndex(0);
    szUserSearch.setPageResults(2);
    szUserSearch.setTotalResults(10);
    szUserSearch.setResources(List.of(szUser1, szUser2));

    UamaUserSearchResponse result = MapperUtils.toDto(szUserSearch);

    assertEquals(0, result.getStartIndex().intValue());
    assertEquals(2, result.getPageResults().intValue());
    assertEquals(10, result.getTotalResults().intValue());
    assertEquals(2, result.getUsers().size());
    assertEquals("u1", result.getUsers().get(0).getId());
    assertEquals("user1", result.getUsers().get(0).getUserName());
    assertEquals(true, result.getUsers().get(0).getActive());
    assertEquals("u2", result.getUsers().get(1).getId());
    assertEquals("user2", result.getUsers().get(1).getUserName());
    assertEquals(false, result.getUsers().get(1).getActive());
  }

  @Test
  public void testSzUserSearchToDto_whenNullSzUserSearch_shouldReturnNull() {
    assertNull(MapperUtils.toDto((SzUserSearch) null));
  }

  @Test
  public void testSzUserSearchToDto_whenNullResources_shouldReturnNullUsers() {
    SzUserSearch szUserSearch = new SzUserSearch();
    szUserSearch.setStartIndex(0);
    szUserSearch.setPageResults(0);
    szUserSearch.setTotalResults(0);
    szUserSearch.setResources(null);

    UamaUserSearchResponse result = MapperUtils.toDto(szUserSearch);

    assertEquals(0, result.getStartIndex().intValue());
    assertEquals(0, result.getPageResults().intValue());
    assertEquals(0, result.getTotalResults().intValue());
    assertNull(result.getUsers());
  }
}
