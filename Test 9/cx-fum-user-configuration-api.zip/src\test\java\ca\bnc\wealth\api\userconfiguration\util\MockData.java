package ca.bnc.wealth.api.userconfiguration.util;

import ca.bnc.wealth.api.userconfiguration.model.FeaturePackageCreateResponse;
import ca.bnc.wealth.api.userconfiguration.model.UserData;
import ca.bnc.wealth.api.userconfiguration.model.state.UserStateDescriptionEnum;
import ca.bnc.wealth.common.ciam.model.OktaAccessProfile;
import ca.bnc.wealth.common.ciam.model.OktaCredentials;
import ca.bnc.wealth.common.ciam.model.OktaFactor;
import ca.bnc.wealth.common.ciam.model.OktaNewPassword;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.ciam.model.OktaUserRequest;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentFirm;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.UserGroup;
import ca.bnc.wealth.common.userconfiguration.model.FeaturePackage;
import ca.bnc.wealth.common.userconfiguration.model.GroupByResponse;
import ca.bnc.wealth.common.userconfiguration.model.NbxUserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.NbxUserConfiguration.PreferredLanguageEnum;
import ca.bnc.wealth.common.userconfiguration.model.OktaUserAccessProfile;
import ca.bnc.wealth.common.userconfiguration.model.PackageTemplateAssignment;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.UserAssignment;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserCredentials;
import ca.bnc.wealth.common.userconfiguration.model.UserExternalSystemConfiguration;
import ca.bnc.wealth.common.userconfiguration.model.UserOktaProfile;
import ca.bnc.wealth.common.userconfiguration.model.UserSearch;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.http.HttpStatusCode;

public class MockData {

  public static final String IDP_USER_SUB = "101";
  public static final String IDP_USER_ID = "00u1aqz8bibuPytV20h8";
  public static final String NBX_SOURCE = "nbx";
  public static final Integer USER_CONFIGURATION_ID = 1;
  public static final String USER_FIRST_NAME = "test";
  public static final String USER_LAST_NAME = "user";
  public static final String USER_EMAIL = "test.user@email.com";
  public static final String USER_NAME_LABEL = generateUsername();
  public static final String USER_PREFERRED_LANGUAGE = "EN";
  public static final String OSS_ID = "GULCHAA";
  public static final String OSS_PROXY_ID = "AGTEST";
  public static final List<String> SECURE_ZONE_IDS = Arrays.asList("ACHOGI3", "ACH0HP4");
  public static final String USER_ACTIVE = "Y";
  public static final String USER_PASSWORD = UUID.randomUUID().toString();
  public static final String RR_CODE = "BB345";
  public static final String FROM_RR_CODE = "A2T8";
  public static final String TO_RR_CODE = "A2T9";
  public static final String USER_GROUP = "Wealth.CompassX.Trader";
  public static final String OKTA_FACTOR_TYPE_SMS = "sms";
  public static final List<String> USER_GROUP_LIST =
      Arrays.asList("Wealth.CompassX.Assistant", "Wealth.CompassX.Trader");
  public static final String COMPASS_R2ID = "COMPASS_R2";
  public static final String INDALL = "indall";
  public static final String INVALID_NAME= "invalidNameinvalidNameinvalidNameinvalidNameinvalidNameinvalidNameinvalidNameinvalidNameinvalidNameinvalidName";

  private static String generateUsername() {
    return String.join(".", USER_FIRST_NAME, USER_LAST_NAME);
  }

  private static String generateUsername(String suffix) {
    return generateUsername() + suffix;
  }

  public static List<String> createMockRRCodes() {
    List<String> rrCodes = new ArrayList<>();
    rrCodes.add(RR_CODE);
    return rrCodes;
  }

  public static List<RRCodeRange> createMockRRCodeList() {
    List<RRCodeRange> rrCodeRangeList = new ArrayList<>();
    RRCodeRange rrCodeRange = new RRCodeRange();
    rrCodeRange.setRrCodeRangeId(1);
    rrCodeRange.setFromRRCode("A2T8");
    RRCodeRange rrCodeRange2 = new RRCodeRange();
    rrCodeRange2.setRrCodeRangeId(1);
    rrCodeRange2.setFromRRCode("A2T9");
    rrCodeRangeList.add(rrCodeRange);
    return rrCodeRangeList;
  }

  public static UserConfiguration getUserConfiguration() {
    UserConfiguration userConf = new UserConfiguration();
    userConf.setUserConfigurationId(USER_CONFIGURATION_ID);
    userConf.setIdpSubject(IDP_USER_SUB);
    userConf.setIdpUserId(IDP_USER_ID);
    userConf.setEmail(USER_EMAIL);
    userConf.setFirstName(USER_FIRST_NAME);
    userConf.setLastName(USER_LAST_NAME);
    userConf.setUsername(USER_NAME_LABEL);
    userConf.preferredLanguage(USER_PREFERRED_LANGUAGE);
    userConf.setOssId(OSS_ID);
    userConf.setOssProxyId(OSS_PROXY_ID);
    userConf.setSecureZoneIds(SECURE_ZONE_IDS);
    userConf.setUserGroup(getUserGroupList().get(0));
    userConf.setRrCodeRanges(createMockRRCodeList());
    userConf.setRrCodes(createMockRRCodes());
    userConf.setActive(USER_ACTIVE);
    userConf.setPassword(USER_PASSWORD);
    userConf.setFirmId("NBIN");
    userConf.setState(UserStateDescriptionEnum.ACTIVE.dbValue);
    userConf.setStatus(UserStateDescriptionEnum.ACTIVE.dbValue);
    userConf.setStateDescription(UserStateDescriptionEnum.ACTIVE.dbValue);
    userConf.setIdp(Constants.CPX_IDP);

    HashMap<String, String> map = new HashMap<>();
    map.put("defaultModule", "defaultModule");

    userConf.setUserPreferences(map);

    return userConf;
  }

  public static FeaturePackage getFeaturePackage() {
    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setPackageTemplateId(123);
    featurePackage.setAssignments(getPackageTemplateAssignmentList());
    return featurePackage;
  }

  public static List<PackageTemplateAssignment> getPackageTemplateAssignmentList() {
    PackageTemplateAssignment packageTemplateAssignment = new PackageTemplateAssignment();
    packageTemplateAssignment.setAssignmentId(123);
    packageTemplateAssignment.setSelected(true);

    return Arrays.asList(packageTemplateAssignment);
  }

  public static List<RRCodeRange> getRrCodeRangeList() {
    RRCodeRange rrCodeRange = new RRCodeRange();
    rrCodeRange.setFromRRCode("AABB");
    rrCodeRange.setToRRCode("AABC");
    return Arrays.asList(rrCodeRange);
  }

  public static List<IamRrCodeRange> getRrCodeRangeEntityList() {
    IamRrCodeRange iamRrCodeRange = new IamRrCodeRange();
    iamRrCodeRange.setFromRrCode("AABB");
    iamRrCodeRange.setToRrCode("AABC");
    return Arrays.asList(iamRrCodeRange);
  }

  public static UserGroup getUserGroupEntity() {
    UserGroup userGroup = new UserGroup();
    userGroup.setUserGroupId(123);
    userGroup.setName(getUserGroupList().get(0));
    userGroup.setIsFirmScope(true);
    userGroup.setIsActive(true);
    return userGroup;
  }

  public static UserAssignment getUserAssignment() {
    UserAssignment userAssignment = new UserAssignment();
    userAssignment.setAssignmentType("assignmentType");
    userAssignment.setAssigneeId(123);
    userAssignment.setFromRrCode(getRrCodeRangeList().get(0).getFromRRCode());
    userAssignment.setToRrCode(getRrCodeRangeList().get(0).getToRRCode());
    return userAssignment;
  }

  public static UserExternalSystemConfiguration getUserExternalSystemConfiguration() {
    return UserExternalSystemConfiguration.builder().compassR2Id(COMPASS_R2ID).build();
  }

  public static UserSearch createUserSearch() {
    UserSearch userSearch = new UserSearch();
    userSearch.setUserConfigurationId(1);
    userSearch.setEmail(USER_EMAIL);
    userSearch.setUsername(USER_NAME_LABEL);
    userSearch.setRrCode(RR_CODE);
    userSearch.setOssId(OSS_ID);
    userSearch.setIdpSubject(IDP_USER_SUB);
    userSearch.setIdpUserId(IDP_USER_ID);
    userSearch.setFirstName(USER_FIRST_NAME);
    userSearch.setLastName(USER_LAST_NAME);
    userSearch.setOssId(OSS_ID);
    userSearch.setOssProxyId(OSS_PROXY_ID);
    userSearch.setUserGroup(USER_GROUP);
    userSearch.setFromRRCode(FROM_RR_CODE);
    userSearch.setToRRCode(TO_RR_CODE);

    return userSearch;
  }

  public static List<UserConfiguration> getUserConfigurationList() {
    List<UserConfiguration> userConfigurationList = new ArrayList<>();
    UserConfiguration userConfiguration = new UserConfiguration();
    userConfiguration.setUserConfigurationId(USER_CONFIGURATION_ID);
    userConfiguration.setEmail(USER_EMAIL);
    userConfiguration.setOssId(OSS_ID);
    userConfiguration.setSecureZoneIds(SECURE_ZONE_IDS);
    userConfigurationList.add(userConfiguration);
    return userConfigurationList;
  }

  public static List<String> getUserGroupList() {
    return USER_GROUP_LIST;
  }

  public static OktaUserProfile getOktaUserProfile() {
    OktaUserProfile oktaUserProfile = new OktaUserProfile();
    OktaAccessProfile accessProfile = new OktaAccessProfile();
    OktaCredentials oktaCredentials = new OktaCredentials();
    OktaFactor oktaFactor = new OktaFactor();
    oktaFactor.setFactorType(OKTA_FACTOR_TYPE_SMS);
    OktaFactor[] oktaFactors = {oktaFactor};
    accessProfile.setUsername(USER_NAME_LABEL);
    accessProfile.setEmail(USER_EMAIL);
    accessProfile.setBngfSecureZoneId(new String[] {"123"});
    oktaCredentials.setPassword(USER_PASSWORD);
    oktaUserProfile.setAccessProfile(accessProfile);
    oktaUserProfile.setCredentials(oktaCredentials);
    oktaUserProfile.setFactors(oktaFactors);

    return oktaUserProfile;
  }

  public static OktaUserRequest getOktaUserRequest() {
    OktaUserRequest oktaUserRequest = new OktaUserRequest();
    OktaAccessProfile oktaAccessProfile = new OktaAccessProfile();
    oktaAccessProfile.setUsername(USER_NAME_LABEL);
    OktaCredentials oktaCredentials = new OktaCredentials();
    oktaUserRequest.setAccessProfile(oktaAccessProfile);
    return oktaUserRequest;
  }

  public static Map<String, List<String>> getUserGroups() {
    Map userGroupMap = new HashMap();
    userGroupMap.put("groupNames", USER_GROUP_LIST);
    return userGroupMap;
  }

  public static UserCredentials getUserCredentials() {
    UserCredentials userCredentials = new UserCredentials();
    userCredentials.setUsername(USER_NAME_LABEL);
    userCredentials.setTempPassword(USER_PASSWORD);
    return userCredentials;
  }

  public static OktaNewPassword getOktaNewPassword() {
    OktaNewPassword oktaNewPassword = new OktaNewPassword();
    oktaNewPassword.setNewPassword(USER_PASSWORD);
    return oktaNewPassword;
  }

  public static List<UserData> getUserDataList() {
    UserData userData1 = new UserData();
    userData1.setFirmId("NBIN");
    userData1.setFirmType("Internal");
    userData1.setUsername(generateUsername("1"));
    userData1.setFirstName(USER_FIRST_NAME);
    userData1.setLastName("Data1");
    userData1.setEmail("userData1@gamil.com");

    UserData userData2 = new UserData();
    userData2.setFirmId("NBIN");
    userData2.setFirmType("Internal");
    userData2.setUsername(generateUsername("2"));
    userData2.setFirstName(USER_FIRST_NAME);
    userData2.setLastName("Data2");
    userData2.setEmail("userData2@gamil.com");
    return Arrays.asList(userData1, userData2);
  }

  public static Map<String, Object> getUserConfigurationMap() {
    Map<String, Object> userConf = new HashMap<>();
    userConf.put("USER_CONFIGURATION_ID", 123);
    userConf.put("IDP_USER_ID", "idpUserId");
    userConf.put("IDP", "nbin");
    userConf.put("IDP_SUBJECT", "idpSubject");
    userConf.put("USERNAME", USER_NAME_LABEL);
    userConf.put("ACTIVE", true);
    userConf.put("IS_FIRM_SCOPE", true);
    userConf.put("OSS_USER_ID", "123");
    userConf.put("OSS_GROUP_ID", "123");
    userConf.put("PREFERRED_LANGUAGE", "EN");
    userConf.put("CREATION_DATE", new Timestamp(System.currentTimeMillis()));
    return userConf;
  }

  public static Map<String, Object> getUserConfigurationMapForNonNbin() {
    Map<String, Object> userConf = new HashMap<>();
    userConf.put("USER_CONFIGURATION_ID", 123);
    userConf.put("IDP_USER_ID", "idpUserId");
    userConf.put("IDP", "sunlif");
    userConf.put("IDP_SUBJECT", "idpSubject");
    userConf.put("USERNAME", USER_NAME_LABEL);
    userConf.put("ACTIVE", true);
    userConf.put("IS_FIRM_SCOPE", true);
    userConf.put("OSS_USER_ID", "123");
    userConf.put("OSS_GROUP_ID", "123");
    userConf.put("PREFERRED_LANGUAGE", "EN");
    userConf.put("CREATION_DATE", new Timestamp(System.currentTimeMillis()));
    return userConf;
  }

  public static List<IamUserConfiguration> getIamUserConfigurationEntityList() {
    IamUserConfiguration iamUserConfiguration = new IamUserConfiguration();
    iamUserConfiguration.setIdpSubject(IDP_USER_SUB);
    iamUserConfiguration.setIdpUserIdentifier("1234");
    iamUserConfiguration.setIdp("nbin");
    iamUserConfiguration.setUserConfigurationId(1234L);
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setPreferredLanguageType(PreferredLanguageType.EN);
    iamUserConfiguration.setOssUserId("123");
    iamUserConfiguration.setOssGroupId("123");
    iamUserConfiguration.setFirstName("firstName");
    iamUserConfiguration.setLastName("lastName");
    iamUserConfiguration.setEmail("email@email.com");
    return Arrays.asList(iamUserConfiguration);
  }

  public static IamUserConfiguration getIamUserConfigurationEntity() {
    return getIamUserConfigurationEntityList().get(0);
  }

  public static List<UserAssignmentFirm> getUserAssignmentFirmEntityList() {
    UserAssignmentFirm userAssignmentFirm = new UserAssignmentFirm();
    userAssignmentFirm.setAssignmentType(UserAssignmentType.F);
    userAssignmentFirm.setFirm(getFirmEntity());
    userAssignmentFirm.setUserConfiguration(getIamUserConfigurationEntity());
    return Arrays.asList(userAssignmentFirm);
  }

  public static List<UserAssignmentUserGroup> getUserAssignmentUserGroupEntityList() {
    UserAssignmentUserGroup userAssignmentUserGroup = new UserAssignmentUserGroup();
    userAssignmentUserGroup.setAssignmentType(UserAssignmentType.G);
    userAssignmentUserGroup.setUserConfiguration(getIamUserConfigurationEntity());
    userAssignmentUserGroup.setUserGroup(getUserGroupEntity());

    return Arrays.asList(userAssignmentUserGroup);
  }

  public static Future<Pair<Integer, List<GroupByResponse>>> getComparableFuture(String firmId) {
    List<UserConfiguration> userConfigurationList = MockData.getUserConfigurationList();
    return CompletableFuture.completedFuture(Pair.of(userConfigurationList.size(),
        List.of(new GroupByResponse().groupKey(firmId).groupData(userConfigurationList))));
  }

  public static Firm getFirmEntity() {
    Firm firm = new Firm();
    firm.setFirmId("NBIN");
    firm.setFirmType(FirmType.IB);
    firm.setActive(true);
    firm.setName("NBIN");
    firm.setFirmEntityId(1L);

    HashMap<String, String> map = new HashMap<>();
    map.put("defaultModule", "defaultModule");
    firm.setFirmPreferences(map);

    return firm;
  }

  public static Pair<HttpStatusCode, String> getCxUserProfile() {
    return Pair.of(HttpStatusCode.valueOf(200), "user");
  }

  public static UserSearch getUserSearch() {
    UserSearch userSearch = new UserSearch();
    userSearch.setRrCode("AABB");
    userSearch.setUserGroup("wealth");

    return userSearch;
  }

  public static UserData getUserData() {
    return getUserDataList().get(0);
  }

  public static List<Resource> getResourceEntityList() {
    Resource resource = new Resource();
    resource.setName("Resource");
    resource.setResourceId(123);
    resource.setActive(true);
    resource.setPurpose("feature");
    resource.setLabel("label");
    return Arrays.asList(resource);
  }

  public static List<Map<String, Object>> getAssigneeNames() {
    Map<String, Object> assignee1 = new HashMap<>();
    assignee1.put("AssigneeId", null);
    assignee1.put("fromRrcode", null);
    assignee1.put("toRrcode", null);
    assignee1.put("assigneeName", "assignee1");

    Map<String, Object> assignee2 = new HashMap<>();
    assignee2.put("AssigneeId", null);
    assignee2.put("fromRrcode", null);
    assignee2.put("toRrcode", null);
    assignee2.put("assigneeName", "assignee2");
    return Arrays.asList(assignee1, assignee2);
  }

   public static UserOktaProfile getUserOktaProfile() {
    OktaUserAccessProfile oktaAccessProfile = new OktaUserAccessProfile();
    oktaAccessProfile.setBngfIdentitySource(INDALL);
    UserOktaProfile oktaUserProfile = new UserOktaProfile();
    oktaUserProfile.setAccessProfile(oktaAccessProfile);
    return oktaUserProfile;
  }

  public static FeaturePackageCreateResponse getFeaturePackageCreateResponse() {
    FeaturePackageCreateResponse featurePackageCreateResponse = new FeaturePackageCreateResponse();
    featurePackageCreateResponse.setFeaturePackageId(123L);

    return featurePackageCreateResponse;
  }

  public static NbxUserConfiguration getNbxUserConfiguration() {
    NbxUserConfiguration nbxUserConfiguration = new NbxUserConfiguration();
    nbxUserConfiguration.setFirstName("firstName");
    nbxUserConfiguration.setLastName("lastName");
    nbxUserConfiguration.setEmail("email");
    nbxUserConfiguration.setPreferredLanguage(PreferredLanguageEnum.EN);

    return nbxUserConfiguration;
  }
}
