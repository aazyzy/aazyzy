package ca.bnc.wealth.api.userconfiguration.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import ca.bnc.wealth.common.spring.microservice.starter.core.exception.ServiceException;
import java.lang.reflect.Constructor;
import java.util.List;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Test;


public class UserConfigUtilsTest {

  @Test(expected = IllegalStateException.class)
  public void testUserConfigUtilsConstructor() throws Exception {
    Constructor<UserConfigUtils> constructor = UserConfigUtils.class.getDeclaredConstructor();
    constructor.setAccessible(true);
    try {
      constructor.newInstance();
    } catch (Exception e) {
      throw (IllegalStateException) e.getCause();
    }
  }

  @Test
  public void testIsTwoArraysEqual() {
    String[] secureZoneIds1 = new String[]{"test1", "test2", "test3", "test4"};
    String[] secureZoneIds2 = new String[]{"test2", "test3", "test4", "test1"};
    assertTrue(UserConfigUtils.isTwoArraysEqual(secureZoneIds1, secureZoneIds2));
    assertEquals("test1", secureZoneIds1[0]);
    assertEquals("test2", secureZoneIds2[0]);

    secureZoneIds1 = new String[]{"test1", "test2", "test3", "test4"};
    secureZoneIds2 = new String[]{"test2", "test5", "test4", "test1"};
    assertFalse(UserConfigUtils.isTwoArraysEqual(secureZoneIds1, secureZoneIds2));

    secureZoneIds1 = new String[]{"test1", "test2", "test3", "test4"};
    secureZoneIds2 = new String[]{"test2", "test4", "test1"};
    assertFalse(UserConfigUtils.isTwoArraysEqual(secureZoneIds1, secureZoneIds2));

    secureZoneIds1 = new String[]{"test1", "test2", "test3", "test4"};
    secureZoneIds2 = null;
    assertFalse(UserConfigUtils.isTwoArraysEqual(secureZoneIds1, secureZoneIds2));
  }

  @Test
  public void testGetUserNamePrefix() {
    assertEquals(1, UserConfigUtils.getUserNamePrefix("test", "test1", null));
    assertEquals(2, UserConfigUtils.getUserNamePrefix("test", "test2.dev", "dev"));
  }

  @Test
  public void testGetTempPassword() {
    assertNotNull(UserConfigUtils.getTempPassword("test", "test"));
  }

  @Test(expected = ServiceException.class)
  public void testGetTempPassword_whenInvalidUserNameAndLastName_shouldThrowServiceException() {
    UserConfigUtils.getTempPassword("", "");
  }

  @Test
  public void testGetUserName() {
    assertEquals("user2", UserConfigUtils.getUserName(Pair.of("user", List.of("user1")), null));
  }

  @Test(expected = ServiceException.class)
  public void testGetUserName_whenInvalidUserName_shouldThrowServiceException() {
    UserConfigUtils.getUserName(Pair.of("user", List.of("user1000")), null);
  }

  @Test
  public void testIsEmpty() {
    assertTrue(UserConfigUtils.isEmpty(null));
    assertTrue(UserConfigUtils.isEmpty(""));
    assertFalse(UserConfigUtils.isEmpty("test"));
  }
}