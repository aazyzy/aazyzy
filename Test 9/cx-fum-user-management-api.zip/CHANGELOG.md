# Changelog

## [5.0.2](https://github.com/NBC-GPMF/cx-fum-user-management-api/compare/v5.0.1...v5.0.2) (2026-11-20)


### Bug Fixes

* trigger 5.0.2 release ([dd75d13](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/dd75d13c798f718e2264c4631f2061dddb3b2a5e))

## [5.0.1](https://github.com/NBC-GPMF/cx-fum-user-management-api/compare/v5.0.0...v5.0.1) (2026-11-02)


### Miscellaneous Chores

* move to parent-pom-core 3.0.1, which fixes the Snyk findings of the 5.0.0 release: Tomcat 11.0.27, Jackson 3.2.4 and 2.22.4, Hibernate Validator 9.1.6.Final and java-jwt 4.6.2

## [5.0.0](https://github.com/NBC-GPMF/cx-fum-user-management-api/compare/v4.0.1...v5.0.0) (2026-10-29)


### Miscellaneous Chores

* align develop versions with main after the 4.0.1 release ([#146](https://github.com/NBC-GPMF/cx-fum-user-management-api/pull/146)) ([1278511](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/1278511610931e181db871af649bec0e424ffbfa))
* move user-management-api to Spring Boot 4.1.1 in develop ([#148](https://github.com/NBC-GPMF/cx-fum-user-management-api/pull/148)) ([8953db9](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/8953db96fadbd90a280a4a9538d072d889d06c27))
* NWPI-15023: assign employee-external Okta group to secondary accounts ([#149](https://github.com/NBC-GPMF/cx-fum-user-management-api/pull/149)) ([08477d4](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/08477d4f88c1f5fd08d3a38b9fb7bb0d063b2602))
* NWPI-15023: self-heal employee-external Okta group on employee update ([#151](https://github.com/NBC-GPMF/cx-fum-user-management-api/pull/151)) ([a3e1ed8](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/a3e1ed8ec24a6159e1547195f7425defce243d53))
* skip Sonar in the release workflow on Java 25 ([#154](https://github.com/NBC-GPMF/cx-fum-user-management-api/pull/154)) ([f1536df](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/f1536dfee18d9ddb61eed5b6ddff1e3517a58f7c))
* skip the SonarQube analysis for now ([#152](https://github.com/NBC-GPMF/cx-fum-user-management-api/pull/152)) ([daffe0a](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/daffe0a895e224dd52a42fb31100c494abd2a574))
* sync 6900 dependency versions to develop SNAPSHOTs ([#153](https://github.com/NBC-GPMF/cx-fum-user-management-api/pull/153)) ([4048c2c](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/4048c2c64e52b4ce3d48dcba4168eb085c29b4be))

## [4.0.1](https://github.com/NBC-GPMF/cx-fum-user-management-api/compare/v4.0.0...v4.0.1) (2026-10-14)


### Miscellaneous Chores

* remediate Snyk vulnerabilities on the 4.0 release line ([#143](https://github.com/NBC-GPMF/cx-fum-user-management-api/issues/143)) ([57c935a](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/57c935ae20ebba6682369a62fd8143c24056a79a))

## [4.0.0](https://github.com/NBC-GPMF/cx-fum-user-management-api/compare/v3.2.4...v4.0.0) (2026-10-14)


### Miscellaneous Chores

* NWPI-15146 make idpsubject and bngfreferenceid case sensitive ([89094c5](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/89094c590f591438c7337bdf8365eeb5a064d0d1))
* NWPI-15076 add the SpecialInquiries endpoint for users under RR codes ([b5cd396](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/b5cd39645a0cfb7d3152953e9b44c9bb767c0ae0))
* NWPI-15142 only cascade linked accounts on deactivate ([8643c56](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/8643c56ce966aa0827883320f7a44aff0b5c04c1))
* NWPI-15089 look up SpecialInquiries roles by name and add GET all active users ([453d2d1](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/453d2d184cc5dcd461c8a88b706140c24cbcc5da))
* NWPI-15097 evict cached employee profiles when an employee's status changes, inside the transaction ([797a331](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/797a331876eb4e3619c7ac433867df54e154af3d), [0e6ee03](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/0e6ee0387fe852fe720849a28c1f1d9488a9626c))
* NWPI-15025 cascade an employee email change to linked accounts ([4118b06](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/4118b06c49f9ee0b07774d4aad36d139030d3147))
* NWPI-14872 set the Okta status on user creation and update ([4aef38c](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/4aef38c9d6510a108f57af4a79fd9edb624ebd2d))
* pin released 6900 dependency versions for release 4.0.0: commons-lib 2.1.42 (NWPI-15097), api-schemas-wealth 1.11.58 ([171e949](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/171e949a1a9bc5a6cf1fb0a9facb3e891968a538))

## [3.2.4](https://github.com/NBC-GPMF/cx-fum-user-management-api/compare/v3.2.3...v3.2.4) (2026-09-27)


### Miscellaneous Chores

* only decommission on a terminal okta status ([91efd96](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/91efd96d2e617d9457b7ed8b89ca3bb4ce0c1bc9))

## [3.2.3](https://github.com/NBC-GPMF/cx-fum-user-management-api/compare/v3.2.2...v3.2.3) (2026-09-26)


### Miscellaneous Chores

* do not re-enable decommissioned linked accounts ([9a347cd](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/9a347cd58d0a0fd83ba7f8ac10d4ab0fa948069d))

## [3.2.2](https://github.com/NBC-GPMF/cx-fum-user-management-api/compare/v3.2.1...v3.2.2) (2026-09-22)


### Miscellaneous Chores

* release 3.2.2 ([#119](https://github.com/NBC-GPMF/cx-fum-user-management-api/issues/119)) ([8e1a5f3](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/8e1a5f3ecf1d6999bc9ac1f0750fb5f2cc6e6de1))

## [3.2.1](https://github.com/NBC-GPMF/cx-fum-user-management-api/compare/v3.2.0...v3.2.1) (2026-09-22)


### Miscellaneous Chores

* release 3.2.1 ([#112](https://github.com/NBC-GPMF/cx-fum-user-management-api/issues/112)) ([a099787](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/a099787dac4e14c6ff763c561cfb8351f510acfe))

## [3.2.0](https://github.com/NBC-GPMF/cx-fum-user-management-api/compare/v3.0.0...v3.2.0) (2026-09-16)


### Bug Fixes

* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([1b41b9a](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/1b41b9a95ee2c3591041256a9ae617b28e610a25))
* **deps:** upgrade to Spring Boot 3.5.16 and align CVE pins ([76e402e](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/76e402e243c7c2cdaf146a9f3eac749f18ed3e4d))
* remediate Snyk vulnerabilities (run 2026-09-15) ([d1be798](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/d1be7981c7ab3fcc4280cfc0ec18539e704bd5a0))


### Miscellaneous Chores

* pin released 6900 dependency versions for release 3.2.0 ([87d26ff](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/87d26ff782385855b8cb78e565edacacd53abfbe))

## [3.0.0](https://github.com/NBC-GPMF/cx-fum-user-management-api/compare/v2.2.4...v3.0.0) (2026-08-19)


### Miscellaneous Chores

* release 3.0.0 ([6675bfc](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/6675bfc3db7a32d1b53c36ec4e7ee23cf1ad4abb))

## [2.2.4](https://github.com/NBC-GPMF/cx-fum-user-management-api/compare/v2.2.3...v2.2.4) (2026-08-19)


### Bug Fixes

* **deps:** pin at.yawk.lz4:lz4-java 1.11.1 for CVE-2026-59949 ([#54](https://github.com/NBC-GPMF/cx-fum-user-management-api/issues/54)) ([59317be](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/59317be12f6adbd5d4a0dcfcb10a405469d93852))
* **deps:** pin at.yawk.lz4:lz4-java 1.11.1 for CVE-2026-59949 ([#56](https://github.com/NBC-GPMF/cx-fum-user-management-api/issues/56)) ([ffd80c3](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/ffd80c3971ddec40b4883aca368f684d93adbcaa))
* **deps:** pin vulnerable transitive dependencies for Snyk remediation ([29b0bdb](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/29b0bdb38b11b7a0ccba8a467c13386ed73b4940))

## [2.2.3](https://github.com/NBC-GPMF/cx-fum-user-management-api/compare/v2.2.2...v2.2.3) (2026-07-10)


### Bug Fixes

* **deps:** pin tomcat-embed 10.1.56 and logback-core 1.5.36 (Snyk HIGH) ([#37](https://github.com/NBC-GPMF/cx-fum-user-management-api/issues/37)) ([8747898](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/8747898e2c14fb3ba5bb0aea37bce6d8cdc54aef))

## [2.2.2](https://github.com/NBC-GPMF/cx-fum-user-management-api/compare/v2.2.1...v2.2.2) (2026-06-29)


### Bug Fixes

* release 2.2.1 ([3e29ad3](https://github.com/NBC-GPMF/cx-fum-user-management-api/commit/3e29ad36bd55864acc03af20f2cc622fd016653d))
