# User Access Management API

## Overview
User Access Management API is a Spring Boot service used by FUM/CX flows to manage user access and attestation processing.

Primary responsibilities:
- User configuration operations for IIQ and employee users
- RR code access validation using authenticated user context
- Attestation generation and trigger flows
- Scheduled attestation status polling and state updates
- Integration with IAM/Auth APIs, Report API, BMA callbacks, JPA repositories, and S3

Base runtime settings (from `application.yml`):
- Context path: `/user-management`
- Default port: `8081`
- Actuator base path: `/manage`
- Exposed actuator endpoints: `health`, `info`

## Tech Stack
- Java 17
- Spring Boot
- Spring Data JPA
- OpenFeign
- Maven Wrapper (`mvnw`)
- JUnit 5 / Spring test

## Project Layout
- `src/main/java/ca/bnc/wealth/api/user/controller`: REST controllers
- `src/main/java/ca/bnc/wealth/api/user/service`: business logic and external integrations
- `src/main/java/ca/bnc/wealth/api/user/schedule`: scheduled attestation status job
- `src/main/resources/application.yml`: baseline service configuration
- `src/test/java`: unit tests for controllers, services, schedule, and utils

## API Surface
Controllers implement schema interfaces from shared libraries (`ca.bnc.wealth.common.user_management.api.*`).

Implemented operation groups:
- `UserManagementController`
	- `triggerAttestation`
	- `generateAttestation`
	- `validateRRCode`
- `EmployeeAccessManagementController`
	- `getEmployeesWithPagination`
	- `getEmployeeUser`
	- `createEmployee`
	- `updateEmployeeByShortId`
	- `patchEmployeeByShortId`
	- `deleteEmployeeByShortId`
- `IiqUserManagementController`
	- `getIiqUser`
	- `getIiqUsersWithPagination`
	- `getIiqUserAccessGroups`

Note: exact request paths/methods are defined by the shared API interface contracts shipped in the schema dependencies.

## Scheduled Processing
`AttestationStatusCheckService` runs a fixed-delay job to poll and update attestation statuses.

Config keys:
- `attestation.schedule.name` (default: `FIRM_ATTESTATION_STATUS_CHECK_SCHEDULE`)
- `attestation.schedule.duration` in seconds (default: `60`)

## Configuration
Keep environment-specific or secret values in a local external file (for example `application-local.yml`) and load it with `spring.config.additional-location`.

Common keys used by this service:
- `feign.iamApi.url`
- `feign.ciamApi.context`
- `s3.firmAttestation.bucket`
- `s3.firmAttestation.keyPrefix`
- `s3.firmAttestation.accessKeyId`
- `s3.firmAttestation.secretAccessKey`
- `s3.firmAttestation.region` (default: `ca-central-1`)
- `redis.cache.enable` (default: `false`)
- `user.management.extract.chunkSize` (default: `100`)
- `user.management.extract.timeBetweenChunkExec` (default: `60000`)
- `user.management.extract.disableDelay` (default: `true`)

## Run Locally
1. Create local config (example):

```yaml
# application-local.yml
feign:
	iamApi:
		url: https://<iam-host>
	ciamApi:
		context: /<ciam-context>

s3:
	firmAttestation:
		bucket: <bucket-name>
		keyPrefix: <key-prefix>
		accessKeyId: <access-key-id>
		secretAccessKey: <secret-access-key>
		region: ca-central-1
```

2. Start from CLI:

```bash
./mvnw spring-boot:run -Dspring-boot.run.jvmArguments="-Dspring.config.additional-location=file:/absolute/path/to/application-local.yml"
```

3. Or run `ca.bnc.wealth.api.user.Application` in IDE with VM option:

```text
-Dspring.config.additional-location=file:/absolute/path/to/application-local.yml
```

## Build And Test
```bash
./mvnw clean verify
```

Run only tests:

```bash
./mvnw test
```

## Health Checks
Once running locally:
- `GET http://localhost:8081/user-management/manage/health`
- `GET http://localhost:8081/user-management/manage/info`

## Notes
- Security context is required for several operations (for example RR code validation and user-scoped queries).
- `validateRRCode` supports both user tokens and marketplace/system tokens, with firm resolution from token claims.
- Attestation generation flow uploads/copies report files in S3 and persists output metadata for downstream processing.
