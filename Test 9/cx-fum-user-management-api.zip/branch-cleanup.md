# Branch Cleanup Report: user-management-api

Generated: 2026-06-08 19:29:36
Default Branch: develop
Total Branches: 15

---

## Summary

- Total Branches: 15
- Excluded from Deletion: 0
- Marked for Deletion: 15

---

## All Branches

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `feature/NWPI-14000` | 2025-10-17 11:15:23 -0400 | 2025-10-17 11:15:23 -0400 | MERGED |
| `release/1.28.0` | 2025-11-10 16:06:24 -0500 | 2025-11-10 16:06:24 -0500 | MERGED |
| `feature/NWPI-14206-rework-with-new-changes-1-fetch-the-access-profile-of-a-user` | 2025-12-07 08:03:12 -0500 | 2025-12-07 08:03:12 -0500 | MERGED |
| `feature/NWPI-14092` | 2025-12-15 10:18:39 -0500 | 2025-12-15 10:18:39 -0500 | MERGED |
| `feature/NWPI-14092_1` | 2025-12-15 14:16:36 -0500 | 2025-12-15 14:16:36 -0500 | MERGED |
| `feature/NWPI-14278-create-attestation-api-performance-fixes` | 2026-01-13 08:33:20 -0500 | 2026-01-13 08:33:20 -0500 | MERGED |
| `feature/NWPI-14278-1-create-attestation-api-performance-fixes` | 2026-01-19 16:27:51 -0500 | 2026-01-19 16:27:51 -0500 | MERGED |
| `release/2.1.0` | 2026-01-28 11:55:32 -0500 | 2026-01-28 11:55:32 -0500 | MERGED |
| `feature/NWPI-14270-firm-attestation-list-is-taking-long-time-to-load-for-nbin-firm` | 2026-02-19 13:33:37 -0500 | 2026-02-19 13:33:37 -0500 | MERGED |
| `feature/NWPI-14340-create-attestation-api-for-all-firms-never-finish` | 2026-02-23 14:04:20 -0500 | 2026-02-23 14:04:20 -0500 | MERGED |
| `release/2.1.1` | 2026-03-06 13:27:04 -0500 | 2026-03-06 13:27:04 -0500 | MERGED |
| `feature/initialize-copilot` | 2026-03-26 13:51:48 -0400 | 2026-03-26 13:51:48 -0400 | MERGED |
| `release/2.2.0` | 2026-05-15 10:36:47 -0400 | 2026-05-15 10:36:47 -0400 | MERGED |
| `fix/snyk-2026-05-26` | 2026-05-26 11:54:35 -0400 | 2026-05-26 11:54:35 -0400 | MERGED |
| `feature/NWPI-14561` | 2026-05-29 11:53:06 -0400 | 2026-05-29 11:53:06 -0400 | MERGED |

---

## Excluded from Deletion

Criteria: Unmerged branches with last commit less than 2 months old
Count: 0

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| No branches excluded | | | |

---

## Marked for Deletion

Criteria: All merged branches + unmerged branches with last commit older than 2 months
Count: 15

| Branch Name | Created | Last Commit | Status |
|-------------|---------|-------------|--------|
| `feature/NWPI-14000` | 2025-10-17 11:15:23 -0400 | 2025-10-17 11:15:23 -0400 | MERGED |
| `release/1.28.0` | 2025-11-10 16:06:24 -0500 | 2025-11-10 16:06:24 -0500 | MERGED |
| `feature/NWPI-14206-rework-with-new-changes-1-fetch-the-access-profile-of-a-user` | 2025-12-07 08:03:12 -0500 | 2025-12-07 08:03:12 -0500 | MERGED |
| `feature/NWPI-14092` | 2025-12-15 10:18:39 -0500 | 2025-12-15 10:18:39 -0500 | MERGED |
| `feature/NWPI-14092_1` | 2025-12-15 14:16:36 -0500 | 2025-12-15 14:16:36 -0500 | MERGED |
| `feature/NWPI-14278-create-attestation-api-performance-fixes` | 2026-01-13 08:33:20 -0500 | 2026-01-13 08:33:20 -0500 | MERGED |
| `feature/NWPI-14278-1-create-attestation-api-performance-fixes` | 2026-01-19 16:27:51 -0500 | 2026-01-19 16:27:51 -0500 | MERGED |
| `release/2.1.0` | 2026-01-28 11:55:32 -0500 | 2026-01-28 11:55:32 -0500 | MERGED |
| `feature/NWPI-14270-firm-attestation-list-is-taking-long-time-to-load-for-nbin-firm` | 2026-02-19 13:33:37 -0500 | 2026-02-19 13:33:37 -0500 | MERGED |
| `feature/NWPI-14340-create-attestation-api-for-all-firms-never-finish` | 2026-02-23 14:04:20 -0500 | 2026-02-23 14:04:20 -0500 | MERGED |
| `release/2.1.1` | 2026-03-06 13:27:04 -0500 | 2026-03-06 13:27:04 -0500 | MERGED |
| `feature/initialize-copilot` | 2026-03-26 13:51:48 -0400 | 2026-03-26 13:51:48 -0400 | MERGED |
| `release/2.2.0` | 2026-05-15 10:36:47 -0400 | 2026-05-15 10:36:47 -0400 | MERGED |
| `fix/snyk-2026-05-26` | 2026-05-26 11:54:35 -0400 | 2026-05-26 11:54:35 -0400 | MERGED |
| `feature/NWPI-14561` | 2026-05-29 11:53:06 -0400 | 2026-05-29 11:53:06 -0400 | MERGED |

---

## Deletion Results

Total Attempted: 15
Successfully Deleted: 14
Failed: 1
Skipped (Excluded Safety Gate): 0

### Failed Deletions

| Branch Name | Error |
|-------------|-------|
| `feature/NWPI-14561` | You cannot delete this branch since it has at least one open pull request associated with it |
