# Code Review Report

**Date**: 2026-07-07 14:16
**Ticket**: NWPI-14644 — Remove `employees` boolean query param from `GET /employees`; always apply the `IDP_EMP` filter
**Repositories**:
- `cx-fum-api-schemas-wealth` (module `user-management-schema`) — branch `develop`
- `cx-fum-user-management-api` — branch `develop`
**Iterations**: 2 (max: 10)
**Outcome**: CONSENSUS REACHED

---

## Iteration Summary

| # | GPT Issues | Sonnet Issues | Consensus | Fixes Applied |
|---|-----------|--------------|-----------|---------------|
| 1 | 2         | 2            | 2 (1 MEDIUM, 1 LOW) | 1 (the MEDIUM) |
| 2 | 0         | 0            | 0         | 0             |

Per the decision gate, only consensus issues of severity MEDIUM or higher are
auto-fixed. The single MEDIUM consensus issue was fixed in iteration 1; the LOW
consensus issue is logged below (not auto-fixed). Iteration 2 re-reviewed the
applied fix and both models agreed it is correct — consensus reached.

---

## Changes Reviewed

**Schema (`cx-fum-api-schemas-wealth`)**
- `user-management-schema/src/main/resources/api/user-management-employee-api.yaml`
  — removed the required `employees` boolean query parameter from `GET /employees`.

**API (`cx-fum-user-management-api`)**
- `EmployeeUserManagementController.java` — dropped the `Boolean employees` argument
  and removed it from the debug log line.
- `EmployeeUserManagementService.java` — `getEmployeesWithPagination` now applies the
  `IDP_EMP` filter unconditionally (removed the `if (Boolean.TRUE.equals(employees))` guard).
- `EmployeeUserManagementControllerTest.java` — removed `anyBoolean()` matchers/args.
- `EmployeeUserManagementServiceTest.java` — removed the leading `true`/`false` arg,
  renamed `_employeesFalseAndNullApplication` → `_nullApplication`, and (this review)
  **added `testGetEmployeesWithPagination_alwaysAppliesIdpEmployeeFilter`**.

### Correctness checks performed
- No remaining references to the removed `employees` parameter in either repo
  (`git grep` across `src/main` and `src/test`).
- Contract change is backward-tolerant: removing a required query param makes the
  contract strictly more permissive; existing clients still sending `employees=...`
  are unaffected (extra query params are ignored by the generated controller).
- Controller/service signatures are consistent with the regenerated
  `EmployeeUserManagementApi` interface; the module compiles and tests pass.
- Full `EmployeeUserManagementServiceTest` run after the fix: **155 tests, 0 failures**
  (was 154 before the added test).

---

## Consensus Issues

### CONSENSUS-1 (MEDIUM, missing-test) — FIXED
The core behavioral guarantee of the ticket — that the `IDP_EMP` filter is now
*always* applied — had no test coverage. Every service test stubbed
`iamUserConfigurationRepository.findAll(any(Specification.class), any(PageRequest.class))`,
so the content of the built `Specification` was never inspected. Deleting the filter
lines entirely would have left all tests green.

**Fix applied** — see "Fixes Applied" below.

### CONSENSUS-2 (LOW, missing-test) — logged, not auto-fixed
`testGetEmployeesWithPagination_nullApplication` (renamed from
`_employeesFalseAndNullApplication`) asserts only pagination metadata
(`pageSize`, `pageNumber`, `totalUsers`) and does not assert any DTO field that
depends on the source/application being null (e.g. `dto.getProfile().getDefaultModule()`).
As written it does not verify the "null application" behavior its name implies.
Per the decision gate, LOW consensus issues are logged only. Optional follow-up:
add a DTO-level assertion (e.g. assert `getDefaultModule()` is null for a null source)
or drop the "nullApplication" name.

---

## All Fixes Applied

### Fix 1 (Iteration 1): Assert the always-on IDP_EMP filter
- **File**: `src/test/java/ca/bnc/wealth/api/user/service/EmployeeUserManagementServiceTest.java`
- **Issue**: CONSENSUS-1 — the unconditional `IDP_EMP` filter was never asserted.
- **Change**: Added `testGetEmployeesWithPagination_alwaysAppliesIdpEmployeeFilter`,
  which captures the `ca.bnc.wealth.common.jpa.specification.Specification` passed to
  `iamUserConfigurationRepository.findAll` via `ArgumentCaptor`, reads its private
  `fieldValueMap` via `ReflectionTestUtils`, and asserts the map contains
  `GenericEmployeeSearchCriteria.IDP.getEntityField()` →
  `Pair.of(EnumQueryCriteria.IGNORE_CASE_EQUALS, Constants.IDP_EMP)`. Added imports for
  `GenericEmployeeSearchCriteria`, `EnumQueryCriteria`, and `Pair`
  (`ArgumentCaptor`/`ReflectionTestUtils` were already imported).
- **Verification**: `mvn clean test -Dtest=EmployeeUserManagementServiceTest` →
  155 tests, 0 failures. Iteration-2 re-review by GPT and Sonnet: NO ISSUES FOUND.

---

## Iteration 2 — GPT Review
NO ISSUES FOUND (Total: 0)

## Iteration 2 — Sonnet Review
NO ISSUES FOUND (Total: 0). Sonnet traced all ten assertion/failure-mode steps and
confirmed the new test breaks if the filter is removed, if the criteria type is wrong,
or if the filter value is wrong — i.e., it genuinely locks the invariant.

---

## Outcome
Consensus reached after 2 iterations. One MEDIUM consensus issue fixed and verified;
one LOW consensus issue logged for optional follow-up. No open blocking issues.
