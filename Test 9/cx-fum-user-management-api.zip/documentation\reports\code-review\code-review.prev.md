# Code Review Report

**Date**: 2026-07-03 18:05
**Repository**: cx-fum-user-management-api
**Branch**: chore/feature-package-usergroup-assignments
**Iterations**: 1 (max: 10)
**Outcome**: CONSENSUS REACHED

---

## Iteration Summary

| # | GPT Issues | Sonnet Issues | Consensus | Fixes Applied |
|---|-----------|--------------|-----------|---------------|
| 1 | 0         | 1 (LOW)      | 0         | 1 (voluntary) |

No consensus (MEDIUM+ flagged by both) issues were found. GPT reported a clean
review; Sonnet raised a single LOW missing-test observation. Although
non-consensus LOW findings are not auto-fixed under the skill rules, the
suggested test closed a genuine, cheap coverage gap so it was added.
`getPackageTemplateAssignmentResources()` returns EVERY detail row (S and G).
`authorization-api` (`FeaturePackageServiceHelper.validatePackageTemplateAssignments`)
requires exactly one assignment entry per detail row
(count = `ptaugs.size()` + `ptars.size()`), all M-mode entries `selected=true`,
and all G entries `selected=true`. The old code skipped rows with a null
`resource` (i.e. the G rows), under-counting and triggering the 400.

**Fix:** Iterate the detail collection once, emit exactly one entry per row keyed
by `templateAssignmentId`, never skip. Branch on type: `G` -> `selected=true`;
`S` mode `M` -> `selected=true`; `S` mode `O` -> selected only if the resource was
requested AND also exists as a mandatory (M) entry. `mandatoryResourceNames`
excludes G rows.

---

## Final Iteration — GPT Review (gpt-5.4)

NO ISSUES FOUND

**Total: 0 issues (0 critical, 0 high, 0 medium, 0 low)**

---

## Final Iteration — Sonnet Review (claude-sonnet-4.6)

Verified loop/branching correctness against the auth-api validator contract
(count = ptaugs + ptars, all M selected=true, all G selected=true), the shared
JPA entity model, and test conventions. Confirmed every row emits exactly one
entry and all three validator conditions are satisfied. Noted the added
`assignmentType != G` filter on `mandatoryResourceNames` is functionally
redundant (G rows have null resource, already removed by `Objects::nonNull`) but
harmless. Confirmed the `(int)` cast and O-mode mandatory-gate are pre-existing
and unchanged.

### ISSUE-1: Missing test for S-type O-mode null-resource entry — now emitted as selected=false rather than skipped
- **Severity**: LOW
- **Category**: missing-test
- **File**: src/test/java/ca/bnc/wealth/api/user/service/EmployeeUserManagementServiceTest.java
- **Lines**: general
- **Description**: The renamed test covers the null-resource M-mode case
  (selected=true). The symmetric O-mode null-resource case (now emitted as
  selected=false rather than skipped) had no dedicated assertion. A future
  refactor of the branch order could regress it undetected.
- **Suggestion**: Add a test asserting the O-mode null-resource entry is present
  (correct count) with `selected=false`.

**Total: 1 issue (0 critical, 0 high, 0 medium, 1 low)**

---

## All Fixes Applied

### Fix 1 (Iteration 1): Add O-mode null-resource coverage test
- **File**: src/test/java/ca/bnc/wealth/api/user/service/EmployeeUserManagementServiceTest.java
- **Issue**: Sonnet ISSUE-1 (LOW, missing-test)
- **Change**: Added `testCreateFeaturePackage_nullResourceOmodeEntry_emittedAsNotSelected`
  asserting an S-type O-mode row with a null resource is emitted (size 2) with
  `selected=false`.

---

## Non-Consensus Issues (logged only)

### Sonnet-only: Redundant `assignmentType != G` filter on mandatoryResourceNames
- **File**: src/main/java/ca/bnc/wealth/api/user/service/EmployeeUserManagementService.java
- **Description**: The `.filter(ar -> ar.getAssignmentType() != PackageAssignmentType.G)`
  is functionally redundant because G rows carry a null resource and are removed
  by the later `.filter(Objects::nonNull)`. Kept intentionally for clarity/intent;
  harmless. Not fixed.
- **Flagged by**: Sonnet only
