package ca.bnc.wealth.api.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(
    scanBasePackages = {
      "ca.bnc.wealth.api.*",
      "ca.bnc.wealth.common.exception.*",
      "ca.bnc.wealth.common.report.*",
      "ca.bnc.wealth.common.ciam.*",
      "ca.bnc.wealth.common.r2.*",
      "ca.bnc.wealth.common.s3",
      "ca.bnc.wealth.common.fum.service",
      "ca.bnc.wealth.common.core.cors",
      "ca.bnc.wealth.common.health.*",
      "ca.bnc.wealth.common.jpa.*",
      "ca.bnc.wealth.common.bma.*"
    })
@EnableJpaRepositories({"ca.bnc.wealth.common.jpa.repo"})
@EntityScan(basePackages = {"ca.bnc.wealth.common.jpa.entity"})
@EnableFeignClients(basePackages = "ca.bnc.wealth.api.user.service")
public class Application {

  public static void main(String[] args) {
    SpringApplication.run(Application.class, args);
  }
}
