package ca.bnc.wealth.api.user.config;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
@EnableAsync
@ConditionalOnProperty(name = "app.async.enable", havingValue = "true", matchIfMissing = true)
public class AsyncConfiguration implements AsyncConfigurer {

  @Override
  public Executor getAsyncExecutor() {
    ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
    executor.setCorePoolSize(5); // 5 threads execute simultaneously
    executor.setMaxPoolSize(5); // keep max equal to core to prevent additional threads
    executor.setQueueCapacity(1000); // bounded queue to prevent memory exhaustion
    executor.setThreadNamePrefix("Async-");
    executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
    executor.setWaitForTasksToCompleteOnShutdown(true); // graceful shutdown
    executor.setAwaitTerminationSeconds(60); // wait up to 60s for tasks to complete
    executor.initialize(); // must be called last
    return executor;
  }

}


