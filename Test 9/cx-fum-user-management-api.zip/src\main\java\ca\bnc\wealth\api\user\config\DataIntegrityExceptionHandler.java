package ca.bnc.wealth.api.user.config;

import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.common.exception.Entity.ErrorMessage;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * Translates a violation of the PERSON email constraints or of the USER_CONFIGURATION username
 * constraints into a 409 instead of a 500. The service layer pre-checks both, but those checks are
 * read-before-write: a concurrent request can still lose the race against IAM_V2.PERSON's unique
 * index on LOWER("EMAIL") (NWPI-14875) or against the byte-exact / case-insensitive unique indexes
 * on USER_CONFIGURATION."USERNAME" (NWPI-14901).
 * Any other integrity violation is rethrown — masking those as a conflict would hide real defects.
 */
@Slf4j
@ControllerAdvice
public class DataIntegrityExceptionHandler {

  private static final String PERSON_EMAIL_UNIQUE_INDEX = "ux_person_email_lower";
  private static final String PERSON_EMAIL_CHECK = "ck_person_email_lowercase";
  private static final String USERNAME_UNIQUE_KEY = "USER_CONFIGURATION_USERNAME_key";
  private static final String USERNAME_CI_UNIQUE_INDEX = "USER_CONFIGURATION_USERNAME_CI_uidx";
  // createEmployee writes the canonical Short ID into IDP_SUBJECT and BNGF_REFERENCE_ID too, and
  // both are uniquely constrained (V1_0_13, V1_0_89) — without these a Short ID clash that the
  // read-before-write pre-check loses the race to surfaces as a 500 (NWPI-14901).
  private static final String IDP_SUBJECT_UNIQUE_KEY = "USER_CONFIGURATION_IDP_SUBJECT_key";
  private static final String BNGF_REFERENCE_ID_UNIQUE_KEY = "unq_user_conf_bngf";

  private static final List<String> CONFLICT_CONSTRAINTS = List.of(
      PERSON_EMAIL_UNIQUE_INDEX, PERSON_EMAIL_CHECK, USERNAME_UNIQUE_KEY, USERNAME_CI_UNIQUE_INDEX,
      IDP_SUBJECT_UNIQUE_KEY, BNGF_REFERENCE_ID_UNIQUE_KEY);

  @ExceptionHandler(DataIntegrityViolationException.class)
  public ResponseEntity<ErrorMessage> handleDataIntegrityViolation(
      DataIntegrityViolationException ex) {
    String cause = ex.getMostSpecificCause().getMessage();
    if (cause == null || CONFLICT_CONSTRAINTS.stream().noneMatch(cause::contains)) {
      throw ex;
    }
    log.warn("Uniqueness constraint violation: {}", cause);
    ErrorMessage errorMessage = new ErrorMessage(Constants.EMPLOYEE_CONSTRAINT_VIOLATION_CODE,
        Constants.EMPLOYEE_CONSTRAINT_VIOLATION_MESSAGE, HttpStatus.CONFLICT);
    return ResponseEntity.status(HttpStatus.CONFLICT).body(errorMessage);
  }
}
