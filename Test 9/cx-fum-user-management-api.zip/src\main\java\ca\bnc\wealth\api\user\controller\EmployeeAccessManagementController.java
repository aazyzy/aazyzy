package ca.bnc.wealth.api.user.controller;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.user.service.EmployeeAccessManagementService;
import ca.bnc.wealth.api.user.service.UserManagementService;
import ca.bnc.wealth.common.employee.user_management.model.CreateUserEmployee;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeGenericSearchResponse;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeUserConfiguration;
import ca.bnc.wealth.common.employee.user_management.model.PatchUserEmployee;
import ca.bnc.wealth.common.employee.user_management.model.UpdateUserEmployee;
import ca.bnc.wealth.common.user_management.api.EmployeeAccessManagementApi;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class EmployeeAccessManagementController implements EmployeeAccessManagementApi {

  private final EmployeeAccessManagementService employeeAccessManagementService;
  private final UserManagementService userManagementService;

  @Override
  public ResponseEntity<EmployeeGenericSearchResponse> getEmployeesWithPagination(
      Integer pageSize, Integer pageNumber) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.debug("getEmployeesWithPagination # Start: idpSubject: {} pageSize: {} pageNumber: {}",
        user.getIdpSubject(), pageSize, pageNumber);

    return ResponseEntity.ok(
        employeeAccessManagementService.getEmployeesWithPagination(pageSize, pageNumber));
  }

  @Override
  public ResponseEntity<EmployeeUserConfiguration> getEmployeeUser(String shortId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("EMPLOYEE_PII_ACCESS: actor={}, targetShortId={}", user.getIdpSubject(), shortId);
    return ResponseEntity.ok(employeeAccessManagementService.getEmployeeUser(shortId));
  }

  @Override
  public ResponseEntity<Void> createEmployee(CreateUserEmployee createUserEmployee) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("createEmployee # Start: idpSubject: {}", user.getIdpSubject());
    employeeAccessManagementService.createEmployee(createUserEmployee, user.getIdpSubject());
    userManagementService.refreshUserSearchMaterializedView();
    return ResponseEntity.status(HttpStatus.CREATED).build();
  }

  @Override
  public ResponseEntity<Void> updateEmployeeByShortId(String shortId, UpdateUserEmployee updateUserEmployee) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("updateEmployeeByShortId # Start: idpSubject: {} shortId: {}", user.getIdpSubject(), shortId);
    employeeAccessManagementService.updateOrCreateEmployee(shortId, updateUserEmployee, user.getIdpSubject());
    userManagementService.refreshUserSearchMaterializedView();
    return ResponseEntity.noContent().build();
  }

  @Override
  public ResponseEntity<Void> patchEmployeeByShortId(String shortId, PatchUserEmployee patchUserEmployee) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("patchEmployeeByShortId # Start: idpSubject: {} shortId: {}", user.getIdpSubject(), shortId);
    employeeAccessManagementService.patchEmployee(shortId, patchUserEmployee, user.getIdpSubject());
    userManagementService.refreshUserSearchMaterializedView();
    return ResponseEntity.noContent().build();
  }

  @Override
  public ResponseEntity<Void> deleteEmployeeByShortId(String shortId) {
    User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    log.info("deleteEmployeeByShortId # Start: idpSubject: {} shortId: {}", user.getIdpSubject(), shortId);
    employeeAccessManagementService.deleteEmployee(shortId);
    userManagementService.refreshUserSearchMaterializedView();
    return ResponseEntity.noContent().build();
  }
}
