package ca.bnc.wealth.api.user.controller;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.user.service.EntitlementModuleService;
import ca.bnc.wealth.api.user.service.EntitlementPackageService;
import ca.bnc.wealth.api.user.service.EntitlementResourceService;
import ca.bnc.wealth.api.user.service.EntitlementFirmService;
import ca.bnc.wealth.common.entitlements.user_management.model.FirmsResponse;
import ca.bnc.wealth.common.entitlements.user_management.model.ModulesResponse;
import ca.bnc.wealth.common.entitlements.user_management.model.PackagesResponse;
import ca.bnc.wealth.common.entitlements.user_management.model.ResourcesResponse;
import ca.bnc.wealth.common.entitlements.user_management.model.RrCodesResponse;
import ca.bnc.wealth.common.user_management.api.EntitlementsApi;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class EntitlementController implements EntitlementsApi {

  private final EntitlementResourceService entitlementResourceService;
  private final EntitlementPackageService entitlementPackageService;
  private final EntitlementFirmService entitlementFirmService;
  private final EntitlementModuleService entitlementModuleService;

  @Override
  public ResponseEntity<ModulesResponse> getEntitlementModules() {
    log.info("ENTITLEMENT_DATA_ACCESS: actor={}, resource=modules", currentActor());
    return ResponseEntity.ok(entitlementModuleService.getEntitlementModules());
  }

  @Override
  public ResponseEntity<ResourcesResponse> getEntitlementResources() {
    log.info("ENTITLEMENT_DATA_ACCESS: actor={}, resource=resources", currentActor());
    ResourcesResponse response = entitlementResourceService.getEntitlementResources();
    return ResponseEntity.ok(response);
  }

  @Override
  public ResponseEntity<PackagesResponse> getEntitlementPackages() {
    log.info("ENTITLEMENT_DATA_ACCESS: actor={}, resource=packages", currentActor());
    PackagesResponse response = entitlementPackageService.getEntitlementPackages();
    return ResponseEntity.ok(response);
  }
  @Override
  public ResponseEntity<FirmsResponse> getEntitlementFirmsInternals() {
    log.info("ENTITLEMENT_DATA_ACCESS: actor={}, resource=firms", currentActor());
    return ResponseEntity.ok(entitlementFirmService.getEntitlementFirmsInternals());
  }

  @Override
  public ResponseEntity<RrCodesResponse> getEntitlementRrCodesInternals() {
    log.info("ENTITLEMENT_DATA_ACCESS: actor={}, resource=rrcodes", currentActor());
    return ResponseEntity.ok(entitlementFirmService.getEntitlementRrCodesInternals());
  }

  private String currentActor() {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    if (authentication != null && authentication.getPrincipal() instanceof User user) {
      return user.getIdpSubject();
    }
    return "unknown";
  }
}
