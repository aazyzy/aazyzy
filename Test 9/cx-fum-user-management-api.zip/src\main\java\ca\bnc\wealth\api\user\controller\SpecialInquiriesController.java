package ca.bnc.wealth.api.user.controller;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.user.service.SpecialInquiriesService;
import ca.bnc.wealth.common.specialinquiries.user_management.model.FirmsResponse;
import ca.bnc.wealth.common.specialinquiries.user_management.model.RrCodesRequest;
import ca.bnc.wealth.common.specialinquiries.user_management.model.UsersResponse;
import ca.bnc.wealth.common.user_management.api.SpecialInquiriesApi;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class SpecialInquiriesController implements SpecialInquiriesApi {

  private static final int MAX_LOGGED_VALUES = 1000;
  private static final int MAX_LOGGED_VALUE_LENGTH = 8;

  private final SpecialInquiriesService specialInquiriesService;

  @Override
  public ResponseEntity<UsersResponse> getAllUsers() {
    log.info("SPECIAL_INQUIRY_DATA_ACCESS: actor={}, resource=users, criterion=allActive",
        currentActor());
    return ResponseEntity.ok(specialInquiriesService.getAllUsers());
  }

  @Override
  public ResponseEntity<UsersResponse> getUsersByFirm(String firmId) {
    log.info("SPECIAL_INQUIRY_DATA_ACCESS: actor={}, resource=users, criterion=firm:{}",
        currentActor(), forLog(firmId));
    return ResponseEntity.ok(specialInquiriesService.getUsersByFirm(firmId));
  }

  @Override
  public ResponseEntity<UsersResponse> getUsersByUserPackage(String userPackageName) {
    log.info("SPECIAL_INQUIRY_DATA_ACCESS: actor={}, resource=users, criterion=userPackage:{}",
        currentActor(), forLog(userPackageName));
    return ResponseEntity.ok(specialInquiriesService.getUsersByUserPackage(userPackageName));
  }

  @Override
  public ResponseEntity<FirmsResponse> getFirmsByFirmType(String firmType) {
    log.info("SPECIAL_INQUIRY_DATA_ACCESS: actor={}, resource=firms, criterion=firmType:{}",
        currentActor(), forLog(firmType));
    return ResponseEntity.ok(specialInquiriesService.getFirmsByFirmType(firmType));
  }

  @Override
  public ResponseEntity<UsersResponse> getUsersByResource(String resourceName) {
    log.info("SPECIAL_INQUIRY_DATA_ACCESS: actor={}, resource=users, criterion=resource:{}",
        currentActor(), forLog(resourceName));
    return ResponseEntity.ok(specialInquiriesService.getUsersByResource(resourceName));
  }

  @Override
  public ResponseEntity<UsersResponse> getUsersByFirmAndUserPackage(
      String firmId, String userPackageName) {
    log.info(
        "SPECIAL_INQUIRY_DATA_ACCESS: actor={}, resource=users, criterion=firm:{}+userPackage:{}",
        currentActor(), forLog(firmId), forLog(userPackageName));
    return ResponseEntity.ok(
        specialInquiriesService.getUsersByFirmAndUserPackage(firmId, userPackageName));
  }

  @Override
  public ResponseEntity<UsersResponse> getUsersByFirmAndResource(
      String firmId, String resourceName) {
    log.info(
        "SPECIAL_INQUIRY_DATA_ACCESS: actor={}, resource=users, criterion=firm:{}+resource:{}",
        currentActor(), forLog(firmId), forLog(resourceName));
    return ResponseEntity.ok(
        specialInquiriesService.getUsersByFirmAndResource(firmId, resourceName));
  }

  @Override
  public ResponseEntity<UsersResponse> getUsersByRrCodes(RrCodesRequest rrCodesRequest) {
    List<String> rrCodes = rrCodesRequest.getRrCodes();
    log.info("SPECIAL_INQUIRY_DATA_ACCESS: actor={}, resource=users, criterion=rrCodes:{}",
        currentActor(), forLog(rrCodes));
    return ResponseEntity.ok(specialInquiriesService.getUsersByRrCodes(rrCodes));
  }

  private String currentActor() {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    if (authentication != null && authentication.getPrincipal() instanceof User user) {
      return forLog(user.getIdpSubject());
    }
    return "unknown";
  }

  /**
   * Neutralizes control characters in a request-supplied path value so it cannot forge extra lines
   * in the audit record (CWE-117). These values reach the controller unvalidated - the contract
   * declares them as free-form strings and the service only validates them afterwards.
   */
  private static String forLog(String value) {
    return value == null ? null : value.replaceAll("\\p{Cntrl}", "_");
  }

  /**
   * Renders a request-body list for the audit record. The body is not validated yet, so both the
   * number of values and the length of each are capped to keep one request from flooding the log.
   */
  private static String forLog(List<String> values) {
    if (values == null) {
      return null;
    }
    String logged = values.stream()
        .limit(MAX_LOGGED_VALUES)
        .map(value -> forLog(StringUtils.abbreviate(value, MAX_LOGGED_VALUE_LENGTH)))
        .collect(Collectors.joining(","));
    return values.size() > MAX_LOGGED_VALUES
        ? logged + ",...(" + values.size() + " values)"
        : logged;
  }
}
