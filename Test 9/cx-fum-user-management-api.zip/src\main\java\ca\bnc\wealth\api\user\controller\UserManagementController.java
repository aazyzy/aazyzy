package ca.bnc.wealth.api.user.controller;

import java.text.ParseException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTParser;
import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.user.service.AttestationService;
import ca.bnc.wealth.api.user.service.UserManagementService;
import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.common.bma.service.BulkManagementApiCallBack;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.user_management.api.UserManagementApi;
import ca.bnc.wealth.common.user_management.model.RRCodeAccess;
import ca.bnc.wealth.common.user_management.model.ValidateRRCodeRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@RequiredArgsConstructor
public class UserManagementController implements UserManagementApi {

    private final AttestationService attestationService;
    private final UserManagementService userManagementService;

    @Override
    public ResponseEntity<Void> triggerAttestation(Long attestationId) {
        attestationService.updateStateToProcessing(attestationId);
        attestationService.uploadAndTriggerAttestation(attestationId);
        return ResponseEntity.ok().build();
    }

    @Override
    @BulkManagementApiCallBack
    public ResponseEntity<Void> generateAttestation(Long attestationId, Long firmEntityId) {
        String uuid = java.util.UUID.randomUUID().toString();
        try {
            attestationService.generateAttestation(attestationId, firmEntityId, uuid);
        } catch (Exception e) {
            log.error("Error generating attestation for attestationId: {} and firmEntityId: {}. Error: {}", attestationId, firmEntityId, e.getMessage());
            throw new FumValidationException(Constants.ATTESTATION_GENERATION_FAILED, Constants.ATTESTATION_GENERATION_FAILED_MESSAGE);
        }
        return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<RRCodeAccess> validateRRCode(String authorization, ValidateRRCodeRequest validateRRCodeRequest) {
        boolean isValid;
        User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String firmId;
        RRCodeAccess response = new RRCodeAccess();

        if (!user.isSystemToken() && user.getIdpSubject() != null) {
            isValid = userManagementService.validateRrCodeByUser(user.getIdpSubject(), validateRRCodeRequest.getRrRange());
            if (!isValid) {
                log.warn("RRCODE_ACCESS_DENIED: principal={}, principalType=USER, rrRange={}",
                        user.getIdpSubject(), validateRRCodeRequest.getRrRange());
            }
            response.setHasAccess(isValid);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else if (user.isSystemToken()) {
            try {
                String token = authorization.replace("Bearer", "").trim();
                JWT jwt = JWTParser.parse(token);
                firmId = jwt.getJWTClaimsSet().getClaims().get("entityCode").toString();

            } catch (ParseException e) {
                log.warn("AUTH_TOKEN_PARSE_FAILURE: endpoint=validateRRCode, reason=parse_exception");
                throw new FumValidationException(Constants.FIRM_RRCODE_PARSE_TOKEN, Constants.FIRM_RRCODE_PARSE_TOKEN_MESSAGE);
            } catch (NullPointerException npe) {
                log.warn("AUTH_TOKEN_PARSE_FAILURE: endpoint=validateRRCode, reason=missing_entityCode_claim");
                throw new FumValidationException(Constants.FIRM_RRCODE_INVALID_SYSTEM_TOKEN_FORMAT, Constants.FIRM_RRCODE_INVALID_SYSTEM_TOKEN_FORMAT_MESSAGE);
            } catch (Exception ex) {
                log.warn("AUTH_TOKEN_PARSE_FAILURE: endpoint=validateRRCode, reason=invalid_token");
                throw new FumValidationException(Constants.FIRM_RRCODE_INVALID_TOKEN, Constants.FIRM_RRCODE_INVALID_TOKEN_MESSAGE);
            }
            isValid = userManagementService.validateRrCodeByFirmId(firmId, validateRRCodeRequest.getRrRange());
            if (!isValid) {
                log.warn("RRCODE_ACCESS_DENIED: principal={}, principalType=FIRM, rrRange={}",
                        firmId, validateRRCodeRequest.getRrRange());
            }
            response.setHasAccess(isValid);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        log.warn("AUTH_TOKEN_PARSE_FAILURE: endpoint=validateRRCode, reason=unsupported_token_type");
        throw new FumValidationException(Constants.FIRM_RRCODE_INVALID_TOKEN, Constants.FIRM_RRCODE_INVALID_TOKEN_MESSAGE);
    }

    @ExceptionHandler(FumValidationException.class)
    public ResponseEntity<Object> handleBadRequest(FumValidationException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
    }

}
