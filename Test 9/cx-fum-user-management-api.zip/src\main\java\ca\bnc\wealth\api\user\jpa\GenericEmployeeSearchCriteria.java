package ca.bnc.wealth.api.user.jpa;

import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.jpa.utils.GenericQuery;
import jakarta.persistence.criteria.JoinType;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum GenericEmployeeSearchCriteria implements GenericQuery {
  IDP(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "idp", null, null),
  IDP_SUBJECT(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "idpSubject", null, null),
  SOURCE(EnumQueryCriteria.IGNORE_CASE_CONTAINS, "source", null, null);

  private EnumQueryCriteria criteria;
  private String field;
  private Object defaultValue;
  private JoinType[] joinTypes;

  @Override
  public EnumQueryCriteria getCriteria() {
    return this.criteria;
  }

  @Override
  public String getEntityField() {
    return this.field;
  }

  @Override
  public Object getDefaultValue() {
    return this.defaultValue;
  }

  @Override
  public JoinType[] getJoinTypes() {
    return this.joinTypes;
  }
}