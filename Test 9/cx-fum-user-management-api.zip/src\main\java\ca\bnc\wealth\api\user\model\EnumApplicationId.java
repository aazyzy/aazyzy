package ca.bnc.wealth.api.user.model;

public enum EnumApplicationId {
  CI, GDI, ML, WP, CRM, DC;
}
