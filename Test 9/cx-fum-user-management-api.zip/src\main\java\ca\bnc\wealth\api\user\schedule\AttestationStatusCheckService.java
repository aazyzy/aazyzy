package ca.bnc.wealth.api.user.schedule;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ca.bnc.wealth.api.user.service.AttestationService;
import ca.bnc.wealth.common.jpa.entity.enums.AttestationStatusType;
import ca.bnc.wealth.common.jpa.entity.iam.Attestation;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationRepository;
import ca.bnc.wealth.common.jpa.service.IamScheduleService;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class AttestationStatusCheckService {

  private final IamScheduleService scheduleService;

  private final AttestationRepository attestationRepository;

  private final AttestationService attestationService;

  @Value("${attestation.schedule.name:FIRM_ATTESTATION_STATUS_CHECK_SCHEDULE}")
  private String scheduleName;

  @Value("${attestation.schedule.duration:60}")
  private long schedulerDuration;

  @Scheduled(
      fixedDelayString = "${attestation.schedule.duration:60}",
      timeUnit = TimeUnit.SECONDS)
  public void updateBulkStatus() {
    if (this.scheduleService.canRunSchedule(scheduleName, schedulerDuration, TimeUnit.SECONDS)) {
      List<Attestation> lst = getPendingAttestation();
      log.info("Processing {} pending attestations for status check", lst.size());

      lst.forEach(entity -> attestationService.checkAndUpdateStatus(entity.getAttestationId()));
      this.scheduleService.updateStatusToFinish(scheduleName);
    }
  }

  private List<Attestation> getPendingAttestation() {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("attestationStatusType", Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, AttestationStatusType.PROCESSING.name()));
    return attestationRepository.findAll(new Specification<>(fieldValueMap));
  }
}
