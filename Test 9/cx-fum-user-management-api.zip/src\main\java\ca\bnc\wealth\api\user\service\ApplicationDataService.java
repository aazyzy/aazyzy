package ca.bnc.wealth.api.user.service;

import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Semaphore;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;
import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.report.feign.client.ReportApiClient;
import ca.bnc.wealth.common.report.model.ReportRequest;
import ca.bnc.wealth.common.report.model.S3Details;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class ApplicationDataService {

  private final ReportApiClient reportApiClient;

  private final SystemTokenFactory systemTokenFactory;

  private final Semaphore csvProcessingSemaphore = new Semaphore(3);

  @Value("${redis.cache.enable:false}")
  private boolean enableCache;

  @Cacheable(value = "User-Management-API-GetSecurityZoneData-By-s3Url-versionId", key = "#s3Url.concat('-').concat(#versionId)", cacheManager = "redisCacheManager", sync = true)
  public Map<String, Map<String, Map<String, String>>> getSecurityZoneData(String s3Url, String versionId, String uuid) {

    log.info("{{}} Fetching SECURITY_ZONE data from Report API for S3 URL: {} and versionId: {}", uuid, s3Url, versionId);
    byte[] fileBytes = getS3File(s3Url, versionId, uuid);

    log.info("{{}} Processing data...", uuid);
    List<Map<String, String>> rowData = convertCsvFileToMap(fileBytes);
    log.info("{{}} Processing data done", uuid);

    Map<String, Map<String, Map<String, String>>> mapByApplicationIdAndSecurityZone = new HashMap<>();

    if (CollectionUtils.isNotEmpty(rowData)) {
      for (Map<String, String> row : rowData) {
        String applicationId = row.get(Constants.APPLICATION_ID);
        String securityZone = row.get(Constants.USER_ID);

        if (StringUtils.isNotBlank(applicationId) && StringUtils.isNotBlank(securityZone)) {
          mapByApplicationIdAndSecurityZone
              .computeIfAbsent(applicationId, k -> new HashMap<>())
              .put(securityZone.trim(), row);

          String[] multipleSecurityZones = securityZone.trim().split(",");
          if (multipleSecurityZones.length > 1) {
            for (String secZone : multipleSecurityZones) {
              mapByApplicationIdAndSecurityZone.get(applicationId).put(secZone.trim(), row);
            }
          }
        }
      }
    }
    log.info("{{}} Successfully processed SECURITY_ZONE data. Total applications found: {}", uuid, mapByApplicationIdAndSecurityZone.size());
    return mapByApplicationIdAndSecurityZone;
  }

  public Map<String, String> getOtherData(List<String> startsWithLst) {
    Map<String, String> map = new HashMap<>();
    for (String startsWith : startsWithLst) {
      String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);
      ReportRequest reportRequest = new ReportRequest();
      reportRequest.set_object(Constants.REPORT_API_OBJECT_ATTESTATION);
      reportRequest.setFunction(Constants.REPORT_API_FUNCTION_S3_LS);

      Map<String, String> additionalCriteriaMap = new HashMap<>();
      additionalCriteriaMap.put(Constants.REPORT_API_GET_LATEST_VERSION_ID, "true");
      additionalCriteriaMap.put(Constants.REPORT_API_STARTS_WITH, startsWith);

      reportRequest.setAdditionalCriteria(additionalCriteriaMap);

      List<S3Details> s3DetailsList = reportApiClient.getS3Details(token, reportRequest).getBody();
      if (CollectionUtils.isNotEmpty(s3DetailsList)) {
        s3DetailsList.forEach(s3Details -> map.put(s3Details.getS3Uri(), s3Details.getVersionId()));
      }
    }
    return map;
  }

  private byte[] getS3File(String s3Url, String versionId, String uuid) {
    String token = systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM);
    ReportRequest reportRequest = new ReportRequest();
    reportRequest.set_object(Constants.REPORT_API_OBJECT_ATTESTATION);
    reportRequest.setFunction(Constants.REPORT_API_FUNCTION_S3_DOWNLOAD);
    Map<String, String> map = new HashMap<>();
    map.put(Constants.S3_URI, s3Url);
    if (StringUtils.isNotBlank(versionId))
      map.put(Constants.S3_URI_VERSION, versionId);
    reportRequest.setAdditionalCriteria(map);
    log.info("{{}} Downloading S3 file from Report API for S3 URL: {} and versionId: {}", uuid, s3Url, versionId);
    ByteArrayResource response = reportApiClient.download(token, reportRequest).getBody();
    log.info("{{}} Successfully downloaded S3 file from Report API for S3 URL: {} and versionId: {}", uuid, s3Url, versionId);
    if (response == null) {
      log.warn("{{}} Failed to download S3 file from Report API for S3 URL: {} and versionId: {}", uuid, s3Url, versionId);
      throw new FumServiceException("error.downloadS3File.fail", "Failed to download S3 file from Report API");
    }
    return response.getByteArray();
  }

  List<Map<String, String>> convertCsvFileToMap(byte[] fileBytes) {
    try {
      csvProcessingSemaphore.acquire();
      log.debug("Acquired semaphore for CSV processing. Available permits: {}", csvProcessingSemaphore.availablePermits());
      
      List<Map<String, String>> results = new ArrayList<>();
      try (StringReader reader = new StringReader(new String(fileBytes, StandardCharsets.UTF_8));
          CSVParser csvParser = new CSVParser(reader,
              CSVFormat.RFC4180.builder()
                  .setIgnoreEmptyLines(true)
                  .setHeader(new String[0])
                  .setDelimiter("|")
                  .setIgnoreHeaderCase(true)
                  .setSkipHeaderRecord(true)
                  .setTrim(true)
                  .build())) {

        for (CSVRecord csvRecord : csvParser) {
          Map<String, String> rowMap = new HashMap<>();
          csvRecord.toMap().forEach((k, v) -> rowMap.put(k.trim(), v != null ? v.trim() : v));
          results.add(rowMap);
        }
      } catch (Exception e) {
        log.error("Exception while converting CSV file to map: {}", e.getMessage());
        throw new FumServiceException("error.unableToProcessCsv","Exception while converting CSV file to map: " + e.getMessage());
      }
      return results;
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      log.error("Thread interrupted while waiting for CSV processing semaphore: {}", e.getMessage());
      throw new FumServiceException("error.unableToProcessCsv", "Thread interrupted while waiting to process CSV file");
    } finally {
      csvProcessingSemaphore.release();
      log.debug("Released semaphore for CSV processing. Available permits: {}", csvProcessingSemaphore.availablePermits());
    }
  }

  public boolean redisCacheEnabled() {
    return enableCache;
  }
}
