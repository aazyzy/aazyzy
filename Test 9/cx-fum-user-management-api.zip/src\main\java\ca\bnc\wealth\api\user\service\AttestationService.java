package ca.bnc.wealth.api.user.service;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ca.bnc.wealth.api.user.utils.AttestationHeaders;
import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.api.user.utils.UserManagementApiUtils;
import ca.bnc.wealth.common.exception.Entity.FumConflictException;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.jpa.entity.enums.AttestationStatusType;
import ca.bnc.wealth.common.jpa.entity.enums.BulkUploadStatus;
import ca.bnc.wealth.common.jpa.entity.iam.Attestation;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmFile;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmStaging;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationSourceData;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationFirmFileRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationFirmStagingRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.s3.S3Service;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class AttestationService {

  private final AttestationRepository attestationRepository;

  private final AttestationFirmStagingRepository attestationFirmStagingRepository;

  private final AttestationFirmFileRepository attestationFirmFileRepository;

  private final ApplicationDataService applicationDataService;

  private final UserExtractService userExtractService;

  private final S3Service s3Service;

  private final S3PropertyService s3PropertyService;

  private final BmaService bmaService;

  @Value("${s3.firmAttestation.bucket:#{null}}")
  private String bucket;

  @Value("${s3.firmAttestation.keyPrefix:#{null}}")
  private String keyPrefix;

  @Async
  public void uploadAndTriggerAttestation(Long attestationId) {
    String uuid = UUID.randomUUID().toString();
    log.info("{{}} Trigger attestation for attestationId: {}", uuid, attestationId);
    try {
      List<String> batchIds = bmaService.uploadToBma(attestationId, uuid);
      log.info("{{}} Successfully uploaded attestation files to BMA for attestationId: {}. Number of batches: {}", uuid, attestationId, batchIds.size());
      bmaService.triggerBulkProcess(batchIds, uuid);
    } catch (Exception exception) {
      if (exception instanceof FumNotFoundException)
        updateState(attestationId, AttestationStatusType.INVALID);
      else if (!(exception instanceof FumConflictException))
        updateState(attestationId, AttestationStatusType.SYSTEM_ERROR);
      log.error("{{}} Error trigger attestation for attestationId: {}", uuid, attestationId, exception);
      throw exception;
    }
  }

  private Attestation getAttestation(Long attestationId) {
    return attestationRepository.findById(attestationId)
        .orElseThrow(() -> {
          log.warn("Attestation not found for attestationId: {}", attestationId);
          return new FumNotFoundException(Constants.ATTESTATION_ID_NOT_FOUND_CODE,
              String.format(Constants.ATTESTATION_ID_NOT_FOUND_MESSAGE, attestationId));
        });
  }

  @Transactional
  public void generateAttestation(Long attestationId, Long firmEntityId, String uuid) throws Exception {
    log.info("{{}} Generate attestation for attestationId: {} and firmId: {}", uuid, attestationId, firmEntityId);
    AttestationFirmStaging attestationFirmStaging = null;
    try {
      Map<String, String> attestationFileMap = new HashMap<>();

      log.info("{{}} Fetching firm attestation", uuid);
      attestationFirmStaging = getAttestationFirmStaging(attestationId, firmEntityId);
      log.info("{{}} Validating attestation state", uuid);
      attestationFirmStaging = validateStateAndGet(attestationFirmStaging, attestationId, firmEntityId, uuid);
      log.info("{{}} Fetching attestation and firm", uuid);
      Attestation attestation = attestationFirmStaging.getAttestation();
      Firm firm = attestationFirmStaging.getFirm();

      log.info("{{}} Fetching security zone data", uuid);
      Map<String, Map<String, Map<String, String>>> securityZoneData = getSecurityZoneData(attestation, uuid);
      log.info("{{}} Fetching user extract data", uuid);
      List<Map<String, String>> userExtractData = userExtractService.getUserExtractData(firm.getFirmId(), securityZoneData, uuid);
      log.info("{{}} Generating CSV string for user extract data", uuid);
      String csvString = getCsvString(attestationFirmStaging.getFirm(), userExtractData, ",");
      String fileName = String.format("%s_%s_compass_user_access.csv", firm.getFirmId(), attestation.getLabel());
      Pair<String, String> pair = s3Service.getVersionAfterUpload(s3PropertyService.getS3AccessFor(), bucket, keyPrefix + "/" + attestation.getLabel() + "/" + firm.getFirmId(), fileName, csvString);
      log.info("{{}} Uploaded attestation file to S3 for attestationId: {} and firmId: {}. S3 URL: {}, VersionId: {}", uuid, attestationId, firmEntityId, pair.getLeft(), pair.getRight());
      attestationFileMap.put(pair.getLeft(), pair.getRight());
      log.info("{{}} Fetching other attestation source data and uploading to S3 if applicable", uuid);
      Map<String, String> otherDataMap = getOtherData(attestation.getAttestationSourceDataList(), List.of("User Access Review_" + firm.getFirmId()));

      otherDataMap.forEach((key, value) -> {
        String fileNameFromS3Url = UserManagementApiUtils.getFileNameFromS3Url(key);
        String copytoS3Url = String.format("s3://%s/%s/%s/%s/%s", bucket, keyPrefix, attestation.getLabel(), firm.getFirmId(), fileNameFromS3Url);
        String versionId = s3Service.copyS3Object(s3PropertyService.getS3AccessFor(), key, value, copytoS3Url);
        attestationFileMap.put(copytoS3Url, versionId);
      });
      log.info("{{}} Uploaded other attestation source data files to S3 for attestationId: {} and firmId: {}. Files: {}", uuid, attestationId, firmEntityId, attestationFileMap);
      createAttestationFirmFiles(attestationFirmStaging, attestationFileMap, pair.getLeft(), userExtractData.size(), uuid);

      log.info("{{}} Successfully generated attestation for attestationId: {} and firmId: {}", uuid, attestationId, firmEntityId);
      updateStateAndGet(attestationFirmStaging, AttestationStatusType.DRAFT);
    } catch (Exception exception) {
      if (exception instanceof FumNotFoundException)
        updateStateAndGet(attestationFirmStaging, AttestationStatusType.INVALID);
      else if (!(exception instanceof FumConflictException))
        updateStateAndGet(attestationFirmStaging, AttestationStatusType.SYSTEM_ERROR);
      else
        log.error("{{}} Attestation generation skipped for attestationId: {} and firmId: {} due to conflict.", uuid, attestationId, firmEntityId);
      log.error("{{}} Error generating attestation for attestationId: {} and firmId: {}", uuid, attestationId, firmEntityId, exception);
      throw exception;
    }
  }

  private AttestationFirmStaging validateStateAndGet(AttestationFirmStaging attestationFirmStaging, Long attestationId, Long firmEntityId, String uuid) {
    if (attestationFirmStaging.getAttestationStatusType() == AttestationStatusType.PROCESSING) {
      log.error("{{}} AttestationFirmStaging is already in PROCESSING state for attestationId: {} and firmEntityId: {}", uuid, attestationId, firmEntityId);
      throw new FumConflictException(Constants.ATTESTATION_STAGING_INVALID_STATUS_CODE,
          String.format(Constants.ATTESTATION_STAGING_INVALID_STATUS_MESSAGE, attestationId, firmEntityId));
    } else {
      attestationFirmStaging.setAttestationStatusType(AttestationStatusType.PROCESSING);
      return attestationFirmStagingRepository.saveAndFlush(attestationFirmStaging);
    }
  }

  @Transactional
  public Attestation updateStateToProcessing(Long attestationId) {
    Attestation attestation = getAttestation(attestationId);
    if (attestation.getAttestationStatusType() == AttestationStatusType.PROCESSING) {
      log.error("Attestation is already in PROCESSING state for attestationId: {}", attestation.getAttestationId());
      throw new FumConflictException(Constants.ATTESTATION_INVALID_STATUS_CODE,
          String.format(Constants.ATTESTATION_INVALID_STATUS_MESSAGE, attestation.getAttestationId()));
    }
    attestation.setAttestationStatusType(AttestationStatusType.PROCESSING);
    Optional.ofNullable(attestation.getAttestationFirmStagingList()).ifPresent(afsl -> afsl.forEach(afs -> afs.setAttestationStatusType(AttestationStatusType.PENDING)));
    return attestationRepository.save(attestation);
  }

  private Attestation updateStateAndGet(Attestation attestation, AttestationStatusType statusType) {
    attestation.setAttestationStatusType(statusType);
    return attestationRepository.saveAndFlush(attestation);
  }

  private void updateState(Long attestationFirmStagingId, AttestationStatusType statusType) {
    attestationFirmStagingRepository.findById(attestationFirmStagingId).ifPresent(attestationFirmStaging -> {
      attestationFirmStaging.setAttestationStatusType(statusType);
      attestationFirmStagingRepository.saveAndFlush(attestationFirmStaging);
    });
  }

  private AttestationFirmStaging updateStateAndGet(AttestationFirmStaging attestationFirmStaging, AttestationStatusType statusType) {
    attestationFirmStaging.setAttestationStatusType(statusType);
    return attestationFirmStagingRepository.saveAndFlush(attestationFirmStaging);
  }

  private void createAttestationFirmFiles(AttestationFirmStaging attestationFirmStaging, Map<String, String> attestationFileMap, String generateFileS3Url, int generatedSize, String uuid) {
    if (attestationFileMap == null || attestationFileMap.isEmpty()) {
      log.warn("{{}} No attestation files to create for attestationFirmStagingId: {}", uuid, attestationFirmStaging.getAttestationFirmStagingId());
      return;
    }

    // delete existing files
    List<AttestationFirmFile> existingFiles = attestationFirmStaging.getAttestationFirmFiles();
    attestationFirmFileRepository.deleteAll(existingFiles);

    List<AttestationFirmFile> attestationFirmFileList = new ArrayList<>();
    attestationFileMap.forEach((s3Url, versionId) -> {
      ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmFile attestationFirmFile = new ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmFile();
      attestationFirmFile.setAttestationFirmStaging(attestationFirmStaging);
      attestationFirmFile.setReportId(s3Url);
      attestationFirmFile.setReportVersionId(versionId);
      attestationFirmFile.setCreatedBy("");
      attestationFirmFile.setCreatedDate(Timestamp.valueOf(LocalDateTime.now()));
      attestationFirmFile.setGenerated(false);
      if (s3Url != null && s3Url.equalsIgnoreCase(generateFileS3Url)) {
        attestationFirmFile.setGenerated(true);
        attestationFirmFile.setRecordCount(generatedSize);
      }
      attestationFirmFileList.add(attestationFirmFile);
    });

    attestationFirmStaging.setAttestationFirmFiles(attestationFirmFileRepository.saveAll(attestationFirmFileList));
  }

  private String getCsvString(Firm firm, List<Map<String, String>> userExtractData, String delimiter) throws IOException {
    List<String> eligibleHeaders = getHeaders(firm);

    List<String> headers = removeEmptyHeaders(eligibleHeaders, userExtractData);

    StringWriter sw = new StringWriter();
    CSVFormat csvFormat = CSVFormat.DEFAULT.builder()
        .setHeader(headers.toArray(new String[headers.size()]))
        .setDelimiter(delimiter)
        .build();

    try (CSVPrinter printer = new CSVPrinter(sw, csvFormat)) {
      for (Map<String, String> row : userExtractData) {
        printer.printRecord(headers.stream().map(header -> row.get(header) != null ? row.get(header) : "").toList());
      }
    }

    return sw.toString();
  }

  private List<String> removeEmptyHeaders(List<String> headers, List<Map<String, String>> userExtractData) {
    Map<String, Boolean> headerHasDataMap = headers.stream().collect(Collectors.toMap(h -> h, h -> true));
    AttestationHeaders.HEADER_GROUP_MAP.forEach((group, groupHeaders) -> {
      boolean groupIsBlank = userExtractData.stream().map(map -> map.get(group)).allMatch(StringUtils::isBlank);
      if (groupIsBlank) {
        groupHeaders.forEach(header -> headerHasDataMap.put(header, false));
      }
    });
    return headers.stream().filter(headerHasDataMap::get).toList();
  }

  private List<String> getHeaders(Firm firm) {
    switch (firm.getFirmType()) {
      case NBIN, Internal:
        return List.of(AttestationHeaders.NBIN_HEADERS);
      case IB:
        if (StringUtils.isNotBlank(firm.getIdentitySource())) {
          return List.of(AttestationHeaders.SSO_IB_HEADERS);
        } else {
          return List.of(AttestationHeaders.IB_HEADERS);
        }
      case PM, IFM, OT:
        if (StringUtils.isNotBlank(firm.getIdentitySource())) {
          return List.of(AttestationHeaders.SSO_PM_HEADERS);
        } else {
          return List.of(AttestationHeaders.PM_HEADERS);
        }
      default:
        if (StringUtils.isNotBlank(firm.getIdentitySource())) {
          return List.of(AttestationHeaders.SSO_PM_HEADERS);
        } else {
          return List.of(AttestationHeaders.PM_HEADERS);
        }
    }
  }

  private AttestationFirmStaging getAttestationFirmStaging(Long attestationId, Long firmEntityId) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put("attestation.attestationId", Pair.of(EnumQueryCriteria.EQUALS, attestationId));
    fieldValueMap.put("firm.firmEntityId", Pair.of(EnumQueryCriteria.EQUALS, firmEntityId));
    return attestationFirmStagingRepository.findOne(new Specification<>(fieldValueMap))
        .orElseThrow(() -> {
          log.warn("AttestationFirmStaging not found for attestationId: {} and firmEntityId: {}", attestationId, firmEntityId);
          return new FumNotFoundException(Constants.ATTESTATION_STAGING_NOT_FOUND_CODE,
              String.format(Constants.ATTESTATION_STAGING_NOT_FOUND_MESSAGE, attestationId, firmEntityId));
        });
  }

  private Map<String, Map<String, Map<String, String>>> getSecurityZoneData(Attestation attestation, String uuid) {
    log.info("{{}} Fetching SECURITY_ZONE data for attestationId: {}", uuid, attestation.getAttestationId());
    List<AttestationSourceData> sourceDataList = attestation.getAttestationSourceDataList();
    if (sourceDataList == null || sourceDataList.isEmpty()) {
      log.warn("{{}} No source data found for attestationId: {}", uuid, attestation.getAttestationId());
      throw new FumNotFoundException(Constants.ATTESTATION_SOURCE_DATA_NOT_FOUND_CODE,
          Constants.ATTESTATION_SOURCE_DATA_NOT_FOUND_MESSAGE + attestation.getAttestationId());
    }
    log.info("{{}} Total source data found: {}", uuid, sourceDataList.size());
    AttestationSourceData attestationSourceData = sourceDataList.stream()
        .filter(asd -> asd.getAttestationSourceType() != null
            && asd.getAttestationSourceType().getCode().equalsIgnoreCase(Constants.SECURITY_ZONE))
        .findFirst()
        .orElseThrow(() -> {
          log.warn("{{}} No SECURITY_ZONE source data found for attestationId: {}", uuid, attestation.getAttestationId());
          return new FumNotFoundException(Constants.ATTESTATION_SOURCE_DATA_NOT_FOUND_CODE,
              Constants.ATTESTATION_SOURCE_DATA_NOT_FOUND_MESSAGE + attestation.getAttestationId());
        });
    log.info("{{}} attestationSourceData.getReportId(): {}, attestationSourceData.getReportVersionId(): {}", uuid, attestationSourceData.getReportId(), attestationSourceData.getReportVersionId());
    if (StringUtils.isBlank(attestationSourceData.getReportId())) {
      log.warn("{{}} No reportId found in SECURITY_ZONE source data for attestationId: {}", uuid, attestation.getAttestationId());
      throw new FumNotFoundException(Constants.ATTESTATION_SOURCE_DATA_NOT_FOUND_CODE,
          Constants.ATTESTATION_SOURCE_DATA_NOT_FOUND_MESSAGE + attestation.getAttestationId());
    }

    return applicationDataService.getSecurityZoneData(attestationSourceData.getReportId(), attestationSourceData.getReportVersionId(), uuid);
  }

  private Map<String, String> getOtherData(List<AttestationSourceData> sourceDataList, List<String> startWithList) {
    Map<String, String> map = new HashMap<>();
    sourceDataList.stream().filter(asd -> asd.getAttestationSourceType() == null || !asd.getAttestationSourceType().getCode().equalsIgnoreCase(Constants.SECURITY_ZONE))
        .filter(asd -> {
          String fileName = UserManagementApiUtils.getFileNameFromS3Url(asd.getReportId());
          return fileName != null && startWithList.stream().anyMatch(fileName::startsWith);
        })
        .forEach(asd -> map.put(asd.getReportId(), asd.getReportVersionId()));

    return map;
  }

  @Async
  @Transactional
  public void checkAndUpdateStatus(long attestationId) {
    Attestation attestation = getAttestation(attestationId);
    List<AttestationFirmStaging> attestationFirmStagingList = attestation.getAttestationFirmStagingList();

    if (CollectionUtils.isNotEmpty(attestationFirmStagingList)) {
      Map<AttestationStatusType, Long> countMap =
          attestationFirmStagingList.stream()
              .collect(Collectors.groupingBy(AttestationFirmStaging::getAttestationStatusType, Collectors.counting()));
      Long totalCount = (long) attestationFirmStagingList.size();
      Long draftCount = countMap.getOrDefault(AttestationStatusType.DRAFT, 0L);
      Long systemErrorCount = countMap.getOrDefault(AttestationStatusType.SYSTEM_ERROR, 0L);
      Long invalidCount = countMap.getOrDefault(AttestationStatusType.INVALID, 0L);
      Long processingCount = countMap.getOrDefault(AttestationStatusType.PROCESSING, 0L);
      Long pendingCount = countMap.getOrDefault(AttestationStatusType.PENDING, 0L);

      log.info("AttestationFirmStaging status counts for attestationId {}: TOTAL={}, DRAFT={}, SYSTEM_ERROR={}, INVALID={}, PROCESSING={}, PENDING={}",
          attestationId, totalCount, draftCount, systemErrorCount, invalidCount, processingCount, pendingCount);

      if (draftCount == attestationFirmStagingList.size()) {
        updateStateAndGet(attestation, AttestationStatusType.DRAFT);
      } else if (systemErrorCount == attestationFirmStagingList.size()) {
        updateStateAndGet(attestation, AttestationStatusType.SYSTEM_ERROR);
      } else if (invalidCount == attestationFirmStagingList.size()) {
        updateStateAndGet(attestation, AttestationStatusType.INVALID);
      } else if (draftCount + systemErrorCount + invalidCount == attestationFirmStagingList.size()) {
        if (systemErrorCount != 0 || invalidCount != 0)
          updateStateAndGet(attestation, AttestationStatusType.INVALID);
        else
          updateStateAndGet(attestation, AttestationStatusType.DRAFT);
      } else {
        attestationFirmStagingList.forEach(afs -> {
          if (afs.getAttestationStatusType() == AttestationStatusType.PROCESSING || afs.getAttestationStatusType() == AttestationStatusType.PENDING) {
            if (afs.getBulkUpload() != null && afs.getBulkUpload().getBulkUploadStatus() == BulkUploadStatus.FAILED) {
              updateStateAndGet(afs, AttestationStatusType.SYSTEM_ERROR);
            } else if (afs.getBulkUpload() != null && afs.getBulkUpload().getBulkUploadStatus() == BulkUploadStatus.SUCCESS) {
              updateStateAndGet(afs, AttestationStatusType.DRAFT);
            }
          }
        });
      }
    }
  }
}
