package ca.bnc.wealth.api.user.service;

import ca.bnc.wealth.api.user.kafka.AuditLogEventPublisher;
import ca.bnc.wealth.common.jpa.entity.enums.AuditEventType;
import ca.bnc.wealth.common.kafka.model.EventMessages;
import ca.bnc.wealth.common.kafka.model.Header;
import ca.bnc.wealth.common.kafka.model.audit.AuditUserConfigPayLoad;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuditLogService {

  private final AuditLogEventPublisher auditLogEventPublisher;

  public void publishEmployeeAudit(AuditEventType auditEventType, UserConfiguration before,
      UserConfiguration after) {
    if (after == null) {
      log.warn("publishEmployeeAudit # after snapshot is null, skipping audit publication for type: {}",
          auditEventType);
      return;
    }
    try {
      EventMessages<AuditUserConfigPayLoad> messages =
          buildEventMessage(auditEventType.name(), before, after);
      auditLogEventPublisher.publish(messages);
    } catch (Exception e) {
      log.warn("AUDIT_PUBLISH_FAILURE: eventType={}, reason={}", auditEventType, e.getMessage(), e);
    }
  }

  private EventMessages<AuditUserConfigPayLoad> buildEventMessage(String auditEventType,
      UserConfiguration before, UserConfiguration after) {
    EventMessages<AuditUserConfigPayLoad> messages = new EventMessages<>();

    Header header = new Header();
    header.setId(UUID.randomUUID().toString());
    messages.setHeader(header);

    AuditUserConfigPayLoad payload = new AuditUserConfigPayLoad();
    payload.setType(auditEventType);
    payload.setUserConfigurationBefore(before);
    payload.setUserConfigurationAfter(after);
    messages.setPayload(payload);

    return messages;
  }
}
