package ca.bnc.wealth.api.user.service;

import ca.bnc.wealth.common.authorization.model.FeaturePackageCreateResponse;
import ca.bnc.wealth.common.userconfiguration.model.FeaturePackage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name = "authorization-client", url = "${feign.iamApi.url}")
public interface AuthorizationClient {

  @RequestMapping(
      path = "access-control/features/packages/package",
      method = RequestMethod.POST)
  FeaturePackageCreateResponse createFeaturePackage(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @RequestBody FeaturePackage featurePackage);

  @RequestMapping(
      path = "/access-control/features/packages/package/{package-id}",
      method = RequestMethod.DELETE)
  void deleteFeaturePackage(
      @RequestHeader(name = HttpHeaders.AUTHORIZATION) String authorization,
      @PathVariable(value = "package-id") Integer featurePackageId
  );

}
