package ca.bnc.wealth.api.user.service;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.common.bma.model.JsonPayLoad;
import ca.bnc.wealth.common.bma.service.BulkManagementClientService;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.jpa.entity.enums.AttestationStatusType;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmStaging;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.BulkUploadRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class BmaService {

  private final AttestationRepository attestationRepository;

  private final BulkUploadRepository bulkUploadRepository;

  private final BulkManagementClientService bulkManagementClientService;

  @Transactional
  public List<String> uploadToBma(Long attestationId, String uuid) {
    List<String> batchIds = new ArrayList<>();
    log.info("{{}} find attestaion {}", uuid, attestationId);
    attestationRepository.findById(attestationId).ifPresentOrElse(attestation -> {
      List<AttestationFirmStaging> attestationFirmStagingList = attestation.getAttestationFirmStagingList();

      log.info("{{}} AttestationFirmStaging list size for attestationId {}: {}", uuid, attestationId, CollectionUtils.size(attestationFirmStagingList));
      if (CollectionUtils.isEmpty(attestationFirmStagingList)) {
        log.warn("{{}} No AttestationFirmStaging found for attestationId: {}", uuid, attestationId);
        throw new FumNotFoundException(Constants.ATTESTATION_STAGING_NOT_FOUND_CODE,
            String.format(Constants.ATTESTATION_STAGING_NOT_FOUND_MESSAGE, attestationId));
      }

      attestationFirmStagingList.forEach(afs -> {
        List<JsonPayLoad> jsonPayLoads = createPayLoad(attestationId, afs.getFirm().getFirmEntityId());
        String fileName = String.format("firm_attestation_%s_firmStaging_%s_%s.json", attestationId, afs.getAttestationFirmStagingId(), System.currentTimeMillis());

        String batchId = bulkManagementClientService.upload(Constants.FIRM_ATTESTATION_TEMPLATE_NAME, "", jsonPayLoads, fileName);
        batchIds.add(batchId);
        log.info("Batch ID for feature package assignment upload: {}", batchId);

        afs.setBulkUpload(bulkUploadRepository.findByBatchID(batchId).orElse(null));
        afs.setAttestationStatusType(AttestationStatusType.PENDING);
      });
      log.info("{{}} Saving attestation with updated AttestationFirmStaging list for attestationId: {}", uuid, attestationId);
      attestationRepository.save(attestation);
    }, () -> {
      log.warn("{{}} Attestation not found for attestationId: {}", uuid, attestationId);
      throw new FumNotFoundException(Constants.ATTESTATION_ID_NOT_FOUND_CODE,
          String.format(Constants.ATTESTATION_ID_NOT_FOUND_MESSAGE, attestationId));
    });
    return batchIds;
  }

  public void triggerBulkProcess(List<String> batchIds, String uuid) {
    batchIds.forEach(batchId -> {
      try {
        Thread.sleep(1000);
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        log.warn("{{}} Thread interrupted while sleeping for batchId: {}", uuid, batchId);
      }
      bulkManagementClientService.triggerBulkProcess(batchId);
    });
  }

  private List<JsonPayLoad> createPayLoad(Long attestationId, Long attestationFirmStagingId) {
    List<JsonPayLoad> jsonPayLoads = new ArrayList<>();

    JsonPayLoad jsonPayLoad = new JsonPayLoad();
    jsonPayLoad.setTargetUrl("/user-management/attestation/" + attestationId + "/" + attestationFirmStagingId);
    jsonPayLoad.setHttpMethod("POST");
    jsonPayLoad.setRequiresCallback(true);

    jsonPayLoads.add(jsonPayLoad);

    return jsonPayLoads;
  }

}
