package ca.bnc.wealth.api.user.service;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.user.jpa.GenericEmployeeSearchCriteria;
import ca.bnc.wealth.api.user.utils.ApiMapper;
import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.common.authorization.model.FeaturePackageCreateResponse;
import ca.bnc.wealth.common.ciam.model.OktaFactor;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.employee.user_management.model.CreateUserEmployee;
import ca.bnc.wealth.common.employee.user_management.model.CreateUserEmployeeProfile;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeAssignment;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeAssignmentRequest;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeGenericSearchResponse;
import ca.bnc.wealth.common.employee.user_management.model.EmployeePackageRequest;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeProfile;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeUserConfiguration;
import ca.bnc.wealth.common.employee.user_management.model.PatchUserEmployee;
import ca.bnc.wealth.common.employee.user_management.model.PatchUserEmployeeProfile;
import ca.bnc.wealth.common.employee.user_management.model.UpdateUserEmployee;
import ca.bnc.wealth.common.employee.user_management.model.UpdateUserEmployeeProfile;
import ca.bnc.wealth.common.exception.Entity.FumConflictException;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.model.UserPreferencesEnum;
import ca.bnc.wealth.common.fum.model.UserStateActionEnum;
import ca.bnc.wealth.common.fum.model.UserStateDescriptionEnum;
import ca.bnc.wealth.common.fum.model.UserStateEnum;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.jpa.entity.enums.AuditEventType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.Person;
import ca.bnc.wealth.common.jpa.entity.iam.PersonAssignment;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignment;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PersonAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PersonRepository;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EmailUtils;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.jpa.utils.RepositoryUtils;
import ca.bnc.wealth.common.jpa.utils.ShortIdUtils;
import ca.bnc.wealth.common.userconfiguration.model.FeaturePackage;
import ca.bnc.wealth.common.userconfiguration.model.PackageTemplateAssignment;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

@Service
@Slf4j
@RequiredArgsConstructor
public class EmployeeAccessManagementService {

  private static final Set<String> ALLOWED_LANGUAGES = Set.of("EN", "FR");

  private final IamUserConfigurationRepository iamUserConfigurationRepository;
  private final PersonRepository personRepository;
  private final PersonAssignmentRepository personAssignmentRepository;
  private final UserAssignmentRepository userAssignmentRepository;
  private final ResourceRepository resourceRepository;
  private final FeaturePackageRepository featurePackageRepository;
  private final PackageTemplateRepository packageTemplateRepository;
  private final FirmRepository firmRepository;
  private final RrCodeService rrCodeService;
  private final UserAssignmentService userAssignmentService;
  private final AuthorizationClient authorizationClient;
  private final SystemTokenFactory systemTokenFactory;
  private final AuditLogService auditLogService;
  private final ExternalClientService externalClientService;
  private final RedisCacheOperationService redisCacheOperationService;

  @PersistenceContext
  private EntityManager entityManager;

  public EmployeeGenericSearchResponse getEmployeesWithPagination(
      Integer pageSize, Integer pageNumber) {

    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(GenericEmployeeSearchCriteria.IDP.getEntityField(),
        Pair.of(EnumQueryCriteria.IGNORE_CASE_EQUALS, Constants.IDP_EMP));

    Specification<IamUserConfiguration> spec = new Specification<>(fieldValueMap);

    List<String> fields = List.of(GenericEmployeeSearchCriteria.IDP_SUBJECT.getEntityField());

    PageRequest page = RepositoryUtils.getPageRequest(pageNumber, pageSize, fields, null, false);

    Page<IamUserConfiguration> userConfigs = iamUserConfigurationRepository.findAll(spec, page);

    List<Integer> userConfigIds = userConfigs.stream()
        .map(uc -> uc.getUserConfigurationId().intValue())
        .toList();

    Map<Integer, Person> assigneeIdToPersonMap = getPersonMapByAssigneeIds(userConfigIds);

    List<EmployeeUserConfiguration> employeeDtos = userConfigs.stream()
        .map(uc -> {
          Person person = assigneeIdToPersonMap.get(uc.getUserConfigurationId().intValue());
          EmployeeUserConfiguration dto = ApiMapper.toEmployeeDto(person, uc);
          dto.getProfile().setAssignment(ApiMapper.toAssignment(uc));
          updateAssignments(dto, uc.getIdpSubject());
          return dto;
        })
        .toList();

    EmployeeGenericSearchResponse response = new EmployeeGenericSearchResponse();
    response.setUsers(employeeDtos);
    response.setPageSize(pageSize);
    response.setPageNumber(pageNumber);
    response.setTotalUsers((int) userConfigs.getTotalElements());
    return response;
  }

  private Map<Integer, Person> getPersonMapByAssigneeIds(List<Integer> userIds) {
    if (userIds.isEmpty()) {
      return Map.of();
    }

    List<PersonAssignment> assignments = personAssignmentRepository.findAll(
        (root, query, cb) -> root.get("userId").in(userIds)
    );

    return assignments.stream()
        .collect(Collectors.toMap(
            PersonAssignment::getUserId,
            PersonAssignment::getPerson,
            (p1, p2) -> p1
        ));
  }

  private void updateAssignments(EmployeeUserConfiguration dto, String idpSubject) {
    userAssignmentRepository.findFirstByIdpSubjectAndAssignmentType(idpSubject, UserAssignmentType.P)
        .ifPresent(ua -> featurePackageRepository.findById((long) ua.getAssigneeId())
            .ifPresent(fp -> {
              if (fp.getPackageTemplate() != null) {
                String packageName = fp.getPackageTemplate().getName();
                EmployeeProfile profile = dto.getProfile() != null
                    ? dto.getProfile() : new EmployeeProfile();
                EmployeeAssignment assignment = profile.getAssignment() != null
                    ? profile.getAssignment() : new EmployeeAssignment();

                var employeePackage = ApiMapper.toPackage(packageName);
                employeePackage.setFeatureSelections(
                    ApiMapper.toFeatureSelections(fp.getFeaturePackageAssignmentResources()));
                assignment.setPackage(employeePackage);

                profile.setAssignment(assignment);
                dto.setProfile(profile);
                log.debug("Assigned package: {} to idpSubject: {}", packageName, idpSubject);
              }
            }));
  }

  @Transactional
  public void createEmployee(CreateUserEmployee createUserEmployee, String requestedBy) {
    validateRequiredFields(createUserEmployee);

    String shortId = createUserEmployee.getProfile().getShortId();
    PackageTemplate packageTemplate = null;
    EmployeePackageRequest packages = null;
    List<String> rrCodes = null;
    String firmId = null;
    if (createUserEmployee.getProfile().getAssignment() != null) {
      firmId = createUserEmployee.getProfile().getAssignment().getFirm();
      packages = createUserEmployee.getProfile().getAssignment().getPackage();
      rrCodes = createUserEmployee.getProfile().getAssignment().getRrcodes();
    }

    Firm firm = getFirm(firmId);

    if (packages != null) {
      packageTemplate = validatePackages(packages.getName());
      validateFeatureSelections(packageTemplate, packages.getFeatureSelections());
    }

    // Reject when the Short ID is taken, by an employee or by any other profile — the
    // case-insensitive unique index on USERNAME would refuse the insert anyway (NWPI-14901).
    if (findByShortId(shortId).isPresent()) {
      throw new FumConflictException(
          Constants.EMPLOYEE_EXISTS_CODE,
          String.format(Constants.EMPLOYEE_EXISTS_MESSAGE, shortId));
    }

    // Reject the create when the email already belongs to another employee. A Person that is only
    // linked to external users is reused below, which is how an external user gains an emp profile.
    String email = EmailUtils.canonicalize(createUserEmployee.getEmail());
    Optional<Person> existingPerson = personRepository.findFirstByEmailIgnoreCase(email);
    if (existingPerson.isPresent() && isLinkedToEmployee(existingPerson.get())) {
      throw new FumValidationException(
          Constants.EMPLOYEE_EMAIL_DUPLICATE_CODE,
          String.format(Constants.EMPLOYEE_EMAIL_DUPLICATE_MESSAGE, email));
    }

    IamUserConfiguration entity = new IamUserConfiguration();
    String trimmedShortId = shortId.trim();
    entity.setIdpSubject(trimmedShortId);
    entity.setUsername(ShortIdUtils.canonicalize(shortId));
    entity.setBngfReferenceId(trimmedShortId);
    entity.setFirstName(createUserEmployee.getFirstName());
    entity.setLastName(createUserEmployee.getLastName());
    entity.setEmail(createUserEmployee.getEmail());
    updateUserPreferences(entity, createUserEmployee.getProfile().getDefaultModule());
    if (Boolean.FALSE.equals(createUserEmployee.getProfile().getActive())) {
      setStateSuspended(entity);
    } else {
      setStateActive(entity);
    }
    entity.setActivationDate(
        Timestamp.valueOf(LocalDateTime.parse(Constants.DEFAULT_ACTIVATION_DATE)));
    entity.setIdp(Constants.IDP_EMP);
    entity.setCreatedBy(requestedBy);
    entity.setCreationDate(Timestamp.valueOf(LocalDateTime.now()));
    entity.setAccessProfileSet(true);

    if (createUserEmployee.getLanguage() != null) {
      entity.setPreferredLanguageType(
          PreferredLanguageType.valueOf(createUserEmployee.getLanguage()));
    }

    IamUserConfiguration saved = iamUserConfigurationRepository.save(entity);
    log.debug("createEmployee # Save successful: shortId: {}", shortId);

    // If Person exists and User exists but is external, create an internal user (idp = emp) and assign to Person
    if (existingPerson.isPresent()) {
      log.info("createEmployee # Existing person and non-emp user found for email, linking to new emp user config: shortId: {}", shortId);
      createPersonAssignment(existingPerson.get(), saved, requestedBy);
      // Must run after createPersonAssignment so the new link is visible to the lookup.
      assignEmployeeExternalGroupToLinkedAccounts(saved);
    } else {
      Person person = createPerson(createUserEmployee, requestedBy);
      createPersonAssignment(person, saved, requestedBy);
    }

    // only a deactivation cascades to the Person's other accounts, matching PUT
    // and PATCH. Activating the primary/SSO account must not re-activate linked accounts.
    // Must run after createPersonAssignment so the new link is visible to the lookup below.
    if (Boolean.FALSE.equals(createUserEmployee.getProfile().getActive())) {
      updateActiveToLinkedAccounts(saved, false, requestedBy);
    }

    // Assign User Firm
    if (firm != null) {
      userAssignmentService.assignFirmToUser(saved.getUserConfigurationId(),
          saved.getIdpSubject(), firm.getFirmEntityId(), requestedBy);
      log.debug("createEmployee # Firm assignment successful: firm: {}", firm);
    }

    // Assign Feature Package
    if (packageTemplate != null) {
      assignUserToPackageTemplate(saved, packageTemplate, packages.getFeatureSelections(), requestedBy);
      log.debug("createEmployee # Package assignment successful: packages: {}", packages);
    }

    // Assign RR Codes — detect firm_level_access from the payload's featureSelections to avoid
    // a stale JPA read after the stored procedure in assignUserToPackageTemplate. When no package
    // is in the request, firm_level_access cannot be present — no RR code action needed for it.
    boolean hasFirmLevelAccess = packages != null
        && hasFirmLevelAccessInFeatureSelections(packages);

    // firm_level_access and restrict_client_data_access are mutually exclusive.
    if (hasFirmLevelAccess && hasRestrictClientDataAccessInPackageTemplate(packageTemplate)) {
      throw new FumValidationException(
          Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS,
          Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS_MESSAGE);
    }

    rrCodeService.assignRrCodesToUser(saved, firm, rrCodes, requestedBy, hasFirmLevelAccess);
    log.debug("createEmployee # Rr code assignment successful: rrCodes: {}", rrCodes);

    UserConfiguration auditAfter = buildAuditSnapshot(shortId);
    auditLogService.publishEmployeeAudit(AuditEventType.CREATE, null, auditAfter);
  }

  Person createPerson(CreateUserEmployee createUserEmployee, String requestedBy) {
    Person person = new Person();
    person.setFirstName(createUserEmployee.getFirstName());
    person.setLastName(createUserEmployee.getLastName());
    person.setEmail(createUserEmployee.getEmail());
    if (createUserEmployee.getLanguage() != null) {
      person.setLanguage(
          ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType.valueOf(
              createUserEmployee.getLanguage())
      );
    }
    person.setCreatedBy(requestedBy);
    person.setCreatedDt(new Timestamp(System.currentTimeMillis()));

    Person savedPerson = personRepository.save(person);
    log.debug("createEmployee # Person created: personId: {} for shortId: {}",
        savedPerson.getPersonId(), createUserEmployee.getProfile().getShortId());
    return savedPerson;
  }

  void createPersonAssignment(Person person, IamUserConfiguration userConfig, String requestedBy) {
    PersonAssignment personAssignment = new PersonAssignment();
    personAssignment.setPerson(person);
    personAssignment.setUserId(userConfig.getUserConfigurationId().intValue());
    personAssignment.setCreatedBy(requestedBy);
    personAssignment.setCreatedDt(new Timestamp(System.currentTimeMillis()));

    personAssignmentRepository.save(personAssignment);
    log.debug("createEmployee # PersonAssignment created: personId: {} -> userConfigId: {}",
        person.getPersonId(), userConfig.getUserConfigurationId());
  }

  private void validateLanguage(String language) {
    if (language != null && !ALLOWED_LANGUAGES.contains(language)) {
      throw new FumValidationException(Constants.EMPLOYEE_LANGUAGE_CODE,
          Constants.EMPLOYEE_LANGUAGE_MESSAGE);
    }
  }

  void validateRequiredFields(CreateUserEmployee employee) {
    if (employee == null) {
      throw new FumValidationException(Constants.EMPLOYEE_REQUIRED_FIELD_CODE,
          String.format(Constants.EMPLOYEE_REQUIRED_FIELD_MESSAGE, "createUserEmployee"));
    }

    if (StringUtils.isBlank(employee.getFirstName())) {
      throw new FumValidationException(Constants.EMPLOYEE_REQUIRED_FIELD_CODE,
          String.format(Constants.EMPLOYEE_REQUIRED_FIELD_MESSAGE, "firstName"));
    }
    if (StringUtils.isBlank(employee.getLastName())) {
      throw new FumValidationException(Constants.EMPLOYEE_REQUIRED_FIELD_CODE,
          String.format(Constants.EMPLOYEE_REQUIRED_FIELD_MESSAGE, "lastName"));
    }
    if (StringUtils.isBlank(employee.getEmail())) {
      throw new FumValidationException(Constants.EMPLOYEE_REQUIRED_FIELD_CODE,
          String.format(Constants.EMPLOYEE_REQUIRED_FIELD_MESSAGE, "email"));
    }
    if (employee.getLanguage() == null) {
      throw new FumValidationException(Constants.EMPLOYEE_REQUIRED_FIELD_CODE,
          String.format(Constants.EMPLOYEE_REQUIRED_FIELD_MESSAGE, "language"));
    }
    validateLanguage(employee.getLanguage());

    // checking profile
    if (employee.getProfile() == null) {
      throw new FumValidationException(Constants.EMPLOYEE_REQUIRED_FIELD_CODE,
          String.format(Constants.EMPLOYEE_REQUIRED_FIELD_MESSAGE, "profile"));
    }
    if (StringUtils.isBlank(employee.getProfile().getShortId())) {
      throw new FumValidationException(Constants.EMPLOYEE_REQUIRED_FIELD_CODE,
          String.format(Constants.EMPLOYEE_REQUIRED_FIELD_MESSAGE, "shortId"));
    }
    if (employee.getProfile().getAssignment() == null
        || StringUtils.isBlank(employee.getProfile().getAssignment().getFirm())) {
      throw new FumValidationException(Constants.FIRM_MISSING, Constants.FIRM_MISSING_MESSAGE);
    }
    if (employee.getProfile().getDefaultModule() != null && !Constants.DEFAULT_MODULES.contains(employee.getProfile().getDefaultModule())) {
      throw new FumValidationException(Constants.EMPLOYEE_DEFAULT_MODULE_CODE,
          Constants.EMPLOYEE_DEFAULT_MODULE_MESSAGE);
    }
  }

  PackageTemplate validatePackages(String packageName) {
    Optional<PackageTemplate> packageTemplate = packageTemplateRepository.findByNameAndType(packageName, PackageType.U);

    if (StringUtils.isEmpty(packageName) || packageTemplate.isEmpty() || !packageName.equalsIgnoreCase(packageTemplate.get().getName())) {
      throw new FumValidationException(Constants.EMPLOYEE_PACKAGE_INVALID_CODE,
          String.format(Constants.EMPLOYEE_PACKAGE_INVALID_MESSAGE, packageName));
    }

    return packageTemplate.get();
  }

  void validateFeatureSelections(PackageTemplate packageTemplate, List<String> featureSelections) {
    // Nothing to validate when no selections were provided.
    if (CollectionUtils.isEmpty(featureSelections)) {
      return;
    }

    // Names of every resource that belongs to the package template.
    Set<String> packageResourceNames =
        Optional.ofNullable(packageTemplate.getPackageTemplateAssignmentResources()).orElseGet(List::of)
            .stream()
            .map(PackageTemplateAssignmentResource::getResource)
            .filter(Objects::nonNull)
            .map(Resource::getName)
            .collect(Collectors.toSet());

    // Any provided selection that is not part of the package is invalid.
    List<String> invalidSelections = featureSelections.stream()
        .filter(Objects::nonNull)
        .filter(selection -> !packageResourceNames.contains(selection))
        .distinct()
        .toList();

    if (!invalidSelections.isEmpty()) {
      log.warn("validateFeatureSelections # Invalid feature selection(s) {} for package: {}",
          invalidSelections, packageTemplate.getName());
      throw new FumValidationException(Constants.EMPLOYEE_FEATURE_SELECTION_INVALID_CODE,
          String.format(Constants.EMPLOYEE_FEATURE_SELECTION_INVALID_MESSAGE,
              packageTemplate.getName(), String.join(", ", invalidSelections)));
    }
  }

  Firm getFirm(String firmId) {
    if (firmId == null) {
      return null;
    }

    Firm firm = firmRepository.findByFirmId(firmId);
    if (firm == null) {
      throw new FumValidationException(Constants.FIRM_NOT_FOUND, Constants.FIRM_NOT_FOUND_MESSAGE);
    }

    return firm;
  }

  void assignUserToPackageTemplate(IamUserConfiguration user, PackageTemplate packageTemplate,
      List<String> featureSelections, String requestedBy) {
    FeaturePackageCreateResponse savedFeaturePackage = createFeaturePackage(packageTemplate, featureSelections, user.getIdpSubject());
    log.info("FeaturePackageCreateResponse for feature package creation: {}", savedFeaturePackage);

    if (savedFeaturePackage == null) {
      throw new FumValidationException(Constants.EMPLOYEE_ASSIGNMENTS_FAILED, Constants.EMPLOYEE_ASSIGNMENTS_FAILED_MESSAGE);
    }

    // No selection -> assign the entire feature package P, G, S
    userAssignmentService.assignFeaturePackageToUser(
        user.getUserConfigurationId(), user.getIdpSubject(),
        savedFeaturePackage.getFeaturePackageId().intValue(), requestedBy);
    log.debug("Assigned full package: {} to employee: {}", packageTemplate.getName(), user.getIdpSubject());
  }

  FeaturePackageCreateResponse createFeaturePackage(PackageTemplate packageTemplate, List<String> featureSelections, String idpSubject) {
    // PackageTemplateAssignmentResource and PackageTemplateAssignmentUserGroup are both mapped
    // to the IAM_V2.PACKAGE_TEMPLATE_DETAILS table and are distinguished only by ASSIGNMENT_TYPE
    // (S = resource, G = user group). Neither @OneToMany collection is type-filtered, so
    // getPackageTemplateAssignmentResources() already returns EVERY detail row (both S and G).
    // The authorization-api validates that the request carries exactly one assignment entry per
    // detail row (its count is ptaugs.size() + ptars.size(), i.e. G rows + S rows); iterating
    // both collections would double-count and iterating one while skipping the other's rows would
    // under-count - either way it rejects with error.FeaturePackage.unwantedData. Emit exactly one
    // entry per detail row, keyed by TEMPLATE_DETAIL_ID, and never skip a row.
    List<PackageTemplateAssignmentResource> templateDetails =
        Optional.ofNullable(packageTemplate.getPackageTemplateAssignmentResources()).orElseGet(List::of);

    // Names of resource (S) rows that are mandatory (M). G rows carry no resource and are excluded.
    Set<String> mandatoryResourceNames = templateDetails.stream()
        .filter(ar -> ar.getAssignmentType() != PackageAssignmentType.G)
        .filter(ar -> ar.getAssignmentMode() == PackageAssignmentMode.M)
        .map(PackageTemplateAssignmentResource::getResource)
        .filter(Objects::nonNull)
        .map(Resource::getName)
        .collect(Collectors.toSet());

    Set<String> selections = new HashSet<>(
        Optional.ofNullable(featureSelections).orElseGet(List::of));

    // The authorization-api validates that the request carries exactly one assignment entry
    // for EVERY package-template assignment - both resources (type S) AND user groups (type G) -
    // otherwise it rejects the request with error.FeaturePackage.unwantedData. An entry must
    // therefore be emitted for every template row, even one whose association is null.
    List<PackageTemplateAssignment> assignments = new ArrayList<>();
    for (PackageTemplateAssignmentResource detail : templateDetails) {
      boolean selected;
      if (detail.getAssignmentType() == PackageAssignmentType.G) {
        // User-group assignments are always selected, matching the authorization-api behaviour
        // in FeaturePackageServiceHelper.updateFeaturePackageAssignments.
        selected = true;
      } else if (detail.getAssignmentMode() == PackageAssignmentMode.M) {
        // All mandatory resources are selected.
        selected = true;
      } else {
        // Optional resources: behaviour depends on the restriction flag.
        Resource resource = detail.getResource();
        if (resource != null && Boolean.TRUE.equals(resource.getRestriction())) {
          // Restricted optional resources are not selected only when the user explicitly
          // included them in their feature selections;
            selected = resource != null
            && !(selections.contains(resource.getName())
            && mandatoryResourceNames.contains(resource.getName()));
        } else {
          // Non-restricted optional resources are selected when explicitly requested.
          selected = resource != null && selections.contains(resource.getName());
        }
      }

      assignments.add(new PackageTemplateAssignment()
          .assignmentId((int) detail.getTemplateAssignmentId())
          .selected(selected));
    }

    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setPackageTemplateId((int) packageTemplate.getPackageTemplateId());
    featurePackage.setAssignments(assignments);

    log.debug("Creating featurePackage for packageName: {} for employee: {}", packageTemplate.getName(), idpSubject);

    try {
      return authorizationClient.createFeaturePackage(
          systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM),
          featurePackage);
    } catch (Exception e) {
      log.error("Failed to create featurePackage for packageName: {} for employee: {} exception: {}",
          packageTemplate.getName(), idpSubject, e.getMessage(), e);
      throw e;
    }
  }

  void assignPackageResources(IamUserConfiguration user, PackageTemplate packageTemplate,
      List<String> featureSelections) {
    // Null-safe: when no selections are provided, only mandatory (M) resources are assigned.
    List<String> selections = Optional.ofNullable(featureSelections).orElseGet(List::of);

    for (PackageTemplateAssignmentResource ar :
        Optional.ofNullable(packageTemplate.getPackageTemplateAssignmentResources()).orElseGet(List::of)) {
      Resource resource = ar.getResource();
      if (resource == null) {
        continue;
      }
      boolean mandatory = ar.getAssignmentMode() == PackageAssignmentMode.M && ar.isSelectionDefault();
      boolean optionalSelected = ar.getAssignmentMode() == PackageAssignmentMode.O
          && !ar.isSelectionDefault()
          && selections.contains(resource.getName());

      // Mandatory (M) is always assigned; optional (O) only when explicitly selected.
      // A name present as both M and O yields two assignments (one per template entry).
      if (mandatory || optionalSelected) {
        userAssignmentService.assignResourceToUser(
            user.getUserConfigurationId(), user.getIdpSubject(),
            resource.getResourceId(), user.getIdpSubject());
        log.debug("assignPackageResources # Assigned {} resource: {} to employee: {}",
            mandatory ? "mandatory" : "optional", resource.getName(), user.getIdpSubject());
      }
    }
  }

  @Transactional
  public void updateOrCreateEmployee(String shortId, UpdateUserEmployee updateUserEmployee, String requestedBy) {
    Optional<IamUserConfiguration> existingUser = findByShortId(shortId);

    if (existingUser.isPresent() && Constants.IDP_EMP.equalsIgnoreCase(existingUser.get().getIdp())) {
      updateExistingEmployee(existingUser.get(), updateUserEmployee, requestedBy);
    } else {
      log.info("updateOrCreateEmployee # Employee not found for shortId: {}, creating new employee", shortId);
      CreateUserEmployee createRequest = toCreateUserEmployee(shortId, updateUserEmployee);
      createEmployee(createRequest, requestedBy);
    }
  }

  void updateExistingEmployee(IamUserConfiguration entity, UpdateUserEmployee update, String requestedBy) {
    if (StringUtils.isBlank(update.getFirstName())) {
      throw new FumValidationException(Constants.EMPLOYEE_REQUIRED_FIELD_CODE,
          String.format(Constants.EMPLOYEE_REQUIRED_FIELD_MESSAGE, "firstName"));
    }
    if (StringUtils.isBlank(update.getLastName())) {
      throw new FumValidationException(Constants.EMPLOYEE_REQUIRED_FIELD_CODE,
          String.format(Constants.EMPLOYEE_REQUIRED_FIELD_MESSAGE, "lastName"));
    }
    validateLanguage(update.getLanguage());
    validateEmailAvailable(update.getEmail(), entity);
    UserConfiguration auditBefore = ApiMapper.toAuditUserConfiguration(entity);
    if (update.getFirstName() != null) {
      entity.setFirstName(update.getFirstName());
    }
    if (update.getLastName() != null) {
      entity.setLastName(update.getLastName());
    }
    if (update.getEmail() != null) {
      entity.setEmail(update.getEmail());
    }
    if (update.getLanguage() != null) {
      entity.setPreferredLanguageType(
          PreferredLanguageType.valueOf(update.getLanguage()));
    }
    if (update.getProfile() != null) {
      if (update.getProfile().getDefaultModule() != null && Constants.DEFAULT_MODULES.contains(update.getProfile().getDefaultModule())) {
        updateUserPreferences(entity, update.getProfile().getDefaultModule());
      } else {
        throw new FumValidationException(Constants.EMPLOYEE_DEFAULT_MODULE_CODE,
            Constants.EMPLOYEE_DEFAULT_MODULE_MESSAGE);
      }

      if (update.getProfile().getActive() != null) {
        boolean active = Boolean.TRUE.equals(update.getProfile().getActive());
        externalClientService.updateOktaUserStatus(entity.getIdpUserIdentifier(), active);
        applyOktaDerivedState(entity, active);
        evictUserConfigurationCache(entity);
        log.info("updateExistingEmployee # State transition for shortId: {} active={}",
            entity.getUsername(), active);
        // only a deactivation cascades to linked accounts; activating the
        // primary/SSO account must not re-activate linked accounts.
        if (!active) {
          updateActiveToLinkedAccounts(entity, false, requestedBy);
        }
      }
    }

    entity.setLastUpdatedBy(requestedBy);
    entity.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
    iamUserConfigurationRepository.save(entity);
    log.debug("updateOrCreateEmployee # Updated IamUserConfiguration for shortId: {}", entity.getUsername());

    Person person = getPersonByUserConfigId(entity.getUserConfigurationId().intValue());
    if (person != null) {
      updatePersonFields(person, update, requestedBy);
      personRepository.save(person);
      log.debug("updateOrCreateEmployee # Updated Person for shortId: {}", entity.getUsername());
    } else {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, entity.getUsername()));
    }

    handleFirmReassignment(entity, update, requestedBy);
    PackageTemplate resolvedPackageTemplate = handlePackageReassignment(entity, update, requestedBy);
    handleRrCodeReassignment(entity, update, requestedBy, resolvedPackageTemplate);

    // Cascaded last: the reassignments above can still reject the request, and their audit
    // events would otherwise be published for a transaction that never commits.
    updateEmailOnLinkedAccounts(entity, update.getEmail(), requestedBy);
    // Self-heals employees created before the group existed. Idempotent, and a no-op costing
    // zero Okta calls for the common case of an employee with no linked account.
    assignEmployeeExternalGroupToLinkedAccounts(entity);

    UserConfiguration auditAfter = buildAuditSnapshot(entity.getIdpSubject());
    auditLogService.publishEmployeeAudit(AuditEventType.UPDATE, auditBefore, auditAfter);
  }

  private UserConfiguration buildAuditSnapshot(String shortId) {
    // Flush pending changes and clear the persistence context before re-reading the entity.
    // Firm/package/RR-code reassignments are performed via bulk delete/insert operations that
    // bypass the persistence context, so the entity's already-initialized @OneToMany collections
    // (userAssignmentFirms, userAssignmentRrCodeRanges, userAssignmentResources) would otherwise
    // remain stale. Without this, the "after" snapshot mirrors the pre-update state and the
    // downstream audit consumer skips the event as unchanged (before equals after).
    entityManager.flush();
    entityManager.clear();
    return ApiMapper.toAuditUserConfiguration(findByShortId(shortId).orElse(null));
  }

  /**
   * Resolves a profile from a Short ID, ignoring case. IdentityIQ may send any case and existing
   * rows are not normalised until the One-Time Employee Loader runs (NWPI-14901).
   *
   * <p>The value is trimmed but deliberately not upper-cased: {@code IgnoreCase} already renders
   * {@code upper(x) = upper(?)}, but it does not trim, so a padded Short ID would silently miss the
   * row it is meant to resolve — letting the create duplicate check pass and the insert then breach
   * the unique index, and leaving the audit snapshot empty.
   */
  private Optional<IamUserConfiguration> findByShortId(String shortId) {
    String lookupId = shortId == null ? null : shortId.trim();
    return iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(lookupId)
        .or(() -> iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(lookupId));
  }

  private void updatePersonFields(Person person, UpdateUserEmployee update, String requestedBy) {
    if (update.getFirstName() != null) {
      person.setFirstName(update.getFirstName());
    }
    if (update.getLastName() != null) {
      person.setLastName(update.getLastName());
    }
    if (update.getEmail() != null) {
      person.setEmail(update.getEmail());
    }
    if (update.getLanguage() != null) {
      person.setLanguage(PreferredLanguageType.valueOf(update.getLanguage()));
    }
    person.setUpdatedBy(requestedBy);
    person.setUpdatedDt(new Timestamp(System.currentTimeMillis()));
  }

  private void handleFirmReassignment(IamUserConfiguration entity, UpdateUserEmployee update, String requestedBy) {
    UpdateUserEmployeeProfile userProfile = update.getProfile();
    if (userProfile == null
        || userProfile.getAssignment() == null
        || StringUtils.isEmpty(userProfile.getAssignment().getFirm())) {
      return;
    }

    Firm firm = getFirm(userProfile.getAssignment().getFirm());
    removeExistingUserAssignment(entity.getIdpSubject(), UserAssignmentType.F);
    userAssignmentService.assignFirmToUser(entity.getUserConfigurationId(),
        entity.getIdpSubject(), firm.getFirmEntityId(), requestedBy);
    // Removing RR codes assigned to User because of new Firm Assignment
    rrCodeService.deleteUserRRCodesByIdpSubject(entity.getIdpSubject());
    log.debug("updateOrCreateEmployee # Firm reassignment complete for shortId: {}", entity.getUsername());
  }

  private PackageTemplate handlePackageReassignment(IamUserConfiguration entity, UpdateUserEmployee update, String requestedBy) {
    UpdateUserEmployeeProfile userProfile = update.getProfile();
    if (userProfile == null
        || userProfile.getAssignment() == null
        || userProfile.getAssignment().getPackage() == null) {
      return null;
    }

    String packageName = userProfile.getAssignment().getPackage().getName();

    PackageTemplate packageTemplate = validatePackages(packageName);
    validateFeatureSelections(packageTemplate,
        userProfile.getAssignment().getPackage().getFeatureSelections());
    removeExistingUserAssignment(entity.getIdpSubject(), UserAssignmentType.P);
    removeResourceAssignmentsExceptDwh(entity.getIdpSubject());
    removeExistingUserAssignment(entity.getIdpSubject(), UserAssignmentType.G);
    deleteExistingFeaturePackages(entity.getIdpSubject(), entity);
    assignUserToPackageTemplate(entity, packageTemplate, userProfile.getAssignment().getPackage().getFeatureSelections(), requestedBy);
    log.debug("updateOrCreateEmployee # Package reassignment complete for shortId: {}", entity.getUsername());
    return packageTemplate;
  }

  private void handleRrCodeReassignment(IamUserConfiguration entity, UpdateUserEmployee update, String requestedBy,
      PackageTemplate resolvedPackageTemplate) {
    UpdateUserEmployeeProfile userProfile = update.getProfile();
    if (userProfile == null || userProfile.getAssignment() == null) {
      return;
    }

    // Detect firm_level_access from the payload's featureSelections to avoid a stale JPA read
    // after the stored procedure in handlePackageReassignment. When no package is in the request,
    // firm_level_access is not being changed — treat it as false so that null rrCodes means
    // "no changes" (preserving existing RR codes).
    boolean hasFirmLevelAccess = userProfile.getAssignment().getPackage() != null
        && hasFirmLevelAccessInFeatureSelections(userProfile.getAssignment().getPackage());
    // Use the already-resolved PackageTemplate from handlePackageReassignment to avoid a
    // redundant DB query. When no package was in the request, resolvedPackageTemplate is null
    // (restrict_client_data_access cannot be present without a package).
    boolean hasRestrictClientDataAccess = resolvedPackageTemplate != null
        && hasRestrictClientDataAccessInPackageTemplate(resolvedPackageTemplate);
    List<String> rrCodes = userProfile.getAssignment().getRrcodes();

    // firm_level_access and restrict_client_data_access are mutually exclusive.
    if (hasFirmLevelAccess && hasRestrictClientDataAccess) {
      throw new FumValidationException(
          Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS,
          Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS_MESSAGE);
    }


    // The firm is optional on an RR code update. When the caller changes only the RR codes and
    // omits the firm, fall back to the user's currently assigned firm so the RR code reassignment
    // is not silently skipped. A null firm (none in the request and none assigned) is handled by
    // rrCodeService.assignRrCodesToUser, which raises the FIRM_MISSING validation error.
    String firmId = userProfile.getAssignment().getFirm();
    if (StringUtils.isEmpty(firmId)) {
      firmId = getAssignedFirmId(entity);
    }

    // Pass the pre-computed firmLevelAccess flag to avoid a stale JPA read — the stored procedure
    // in handlePackageReassignment inserted the firm_level_access row via native SQL, so the
    // persistence context does not yet see it.
    rrCodeService.assignRrCodesToUser(entity, getFirm(firmId), rrCodes, requestedBy, hasFirmLevelAccess);
    log.debug("updateOrCreateEmployee # RrCodes reassignment complete for shortId: {}", entity.getUsername());
  }

  private boolean hasFirmLevelAccessInFeatureSelections(EmployeePackageRequest employeePackage) {
    if (employeePackage == null || employeePackage.getFeatureSelections() == null) {
      return false;
    }
    return employeePackage.getFeatureSelections()
        .contains(Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS);
  }

  private boolean hasRestrictClientDataAccessInPackageTemplate(PackageTemplate packageTemplate) {
    if (packageTemplate == null) {
      return false;
    }
    return Optional.ofNullable(packageTemplate.getPackageTemplateAssignmentResources())
        .orElseGet(List::of)
        .stream()
        .map(PackageTemplateAssignmentResource::getResource)
        .filter(Objects::nonNull)
        .map(Resource::getName)
        .anyMatch(Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS::equals);
  }

  private String getAssignedFirmId(IamUserConfiguration entity) {
    if (entity.getUserAssignmentFirms() == null || entity.getUserAssignmentFirms().isEmpty()) {
      return null;
    }
    // UserAssignmentFirm shares the USER_ASSIGNMENT table with every assignment type and the
    // collection is not type-filtered, so it returns every row. Only type-F rows resolve to a
    // Firm; taking get(0) blindly could pick a non-firm row and return a null firm. Filter to F.
    return entity.getUserAssignmentFirms().stream()
        .filter(uaf -> uaf.getAssignmentType() == UserAssignmentType.F && uaf.getFirm() != null)
        .map(uaf -> uaf.getFirm().getFirmId())
        .findFirst()
        .orElse(null);
  }

  @Transactional
  public void patchEmployee(String shortId, PatchUserEmployee patch, String requestedBy) {
    validateSingleFieldPatch(patch);
    validateLanguage(patch.getLanguage());

    IamUserConfiguration entity = findByShortId(shortId).orElse(null);

    if (entity == null || !Constants.IDP_EMP.equalsIgnoreCase(entity.getIdp())) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, shortId));
    }

    validateEmailAvailable(patch.getEmail(), entity);

    UserConfiguration auditBefore = ApiMapper.toAuditUserConfiguration(entity);

    if (patch.getFirstName() != null) {
      entity.setFirstName(patch.getFirstName());
    }
    if (patch.getLastName() != null) {
      entity.setLastName(patch.getLastName());
    }
    if (patch.getEmail() != null) {
      entity.setEmail(patch.getEmail());
    }
    if (patch.getLanguage() != null) {
      entity.setPreferredLanguageType(
          PreferredLanguageType.valueOf(patch.getLanguage()));
    }
    if (patch.getProfile() != null) {
      PatchUserEmployeeProfile profile = patch.getProfile();
      if (profile.getDefaultModule() != null) {
        updateUserPreferences(entity, profile.getDefaultModule());
      }
      if (profile.getActive() != null) {
        boolean active = Boolean.TRUE.equals(profile.getActive());
        externalClientService.updateOktaUserStatus(entity.getIdpUserIdentifier(), active);
        applyOktaDerivedState(entity, active);
        evictUserConfigurationCache(entity);
        log.info("patchEmployee # State transition for shortId: {} active={}", shortId, active);
        // PATCH deactivate cascades to every linked account, but PATCH activate
        // must only activate the primary/SSO account.
        if (!active) {
          updateActiveToLinkedAccounts(entity, false, requestedBy);
        }
      }
    }

    entity.setLastUpdatedBy(requestedBy);
    entity.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
    iamUserConfigurationRepository.save(entity);

    updatePersonFromPatch(entity, patch, requestedBy);

    updateEmailOnLinkedAccounts(entity, patch.getEmail(), requestedBy);
    // Self-heals employees created before the group existed. Idempotent, and a no-op costing
    // zero Okta calls for the common case of an employee with no linked account.
    assignEmployeeExternalGroupToLinkedAccounts(entity);

    log.debug("patchEmployee # Updated field for shortId: {}", shortId);

    UserConfiguration auditAfter = buildAuditSnapshot(entity.getIdpSubject());
    auditLogService.publishEmployeeAudit(AuditEventType.UPDATE, auditBefore, auditAfter);
  }

  private void updatePersonFromPatch(IamUserConfiguration entity, PatchUserEmployee patch, String requestedBy) {
    Person person = getPersonByUserConfigId(entity.getUserConfigurationId().intValue());
    if (person == null) {
      log.debug("patchEmployee # No linked Person found for shortId: {}", entity.getUsername());
      throw new FumValidationException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, entity.getIdpSubject()));
    }

    if (patch.getFirstName() != null) {
      person.setFirstName(patch.getFirstName());
    }
    if (patch.getLastName() != null) {
      person.setLastName(patch.getLastName());
    }
    if (patch.getEmail() != null) {
      person.setEmail(patch.getEmail());
    }
    if (patch.getLanguage() != null) {
      person.setLanguage(PreferredLanguageType.valueOf(patch.getLanguage()));
    }
    person.setUpdatedBy(requestedBy);
    person.setUpdatedDt(new Timestamp(System.currentTimeMillis()));
    personRepository.save(person);
    log.debug("patchEmployee # Updated Person for shortId: {}", entity.getUsername());
  }

  /**
   * deactivating the primary/SSO account cascades to every linked account of the
   * same Person, matching IIQ's "deactivate everything" expectation. Activating the primary
   * account is deliberately NOT cascaded here — only the primary account should transition to
   * active; linked accounts keep their own independent state.
   */
  private void updateActiveToLinkedAccounts(IamUserConfiguration ssoAccount, boolean active,
      String requestedBy) {
    List<IamUserConfiguration> linkedAccounts = getLinkedAccounts(ssoAccount);

    if (linkedAccounts.isEmpty()) {
      return;
    }

    Timestamp now = new Timestamp(System.currentTimeMillis());
    for (IamUserConfiguration linkedAccount : linkedAccounts) {
      // NWPI-15109: a decommissioned linked account was deliberately retired by the employee
      // migration's sunset step. Re-enabling it in Okta would make the old external SSO account
      // loginable again, and applyOktaDerivedState would then re-derive it back to active.
      if (UserStateEnum.DECOMMISSIONED.dbValue.equalsIgnoreCase(linkedAccount.getState())) {
        log.info("updateActiveToLinkedAccounts # Skipping decommissioned linked account {} "
            + "for shortId: {}", linkedAccount.getUsername(), ssoAccount.getUsername());
        continue;
      }
      UserConfiguration before = ApiMapper.toAuditUserConfiguration(linkedAccount);
      // Linked accounts are real Okta users, so this is where the status change actually lands.
      externalClientService.updateOktaUserStatus(linkedAccount.getIdpUserIdentifier(), active);
      applyOktaDerivedState(linkedAccount, active);
      linkedAccount.setLastUpdatedBy(requestedBy);
      linkedAccount.setLastUpdateDate(now);
      iamUserConfigurationRepository.save(linkedAccount);
      evictUserConfigurationCache(linkedAccount);
      auditLogService.publishEmployeeAudit(AuditEventType.UPDATE, before,
          ApiMapper.toAuditUserConfiguration(linkedAccount));
    }

    log.info("updateActiveToLinkedAccounts # Applied active={} to {} linked account(s) "
        + "for shortId: {}", active, linkedAccounts.size(), ssoAccount.getUsername());
  }

  /**
   * A new employee account makes every other account on the same Person a secondary account, so
   * each one gains the employee-external group in Okta. Employee (IAMi) accounts themselves are
   * excluded: they have no Okta profile and are the primary of the pair, never the secondary.
   *
   * <p>Also called from the update and patch paths, where it self-heals employees created before
   * the group existed. It is idempotent — the group is read before it is added — and makes no
   * Okta call at all when the Person has no other account.
   *
   * <p>NWPI-15109: decommissioned linked accounts were deliberately retired by the employee
   * migration's sunset step, so they are skipped here too — granting them the group would hand a
   * retired account a standing CompassX entitlement.
   *
   * <p>The group lives only in Okta — no FUM row changes — so there is nothing to persist,
   * cache-evict, or audit here. Must be called after the new PERSON_USER link is saved, since
   * the Person is resolved through it.
   */
  void assignEmployeeExternalGroupToLinkedAccounts(IamUserConfiguration employee) {
    List<IamUserConfiguration> externalAccounts = getLinkedAccounts(employee).stream()
        .filter(account -> !Constants.IDP_EMP.equalsIgnoreCase(account.getIdp()))
        .filter(account -> !UserStateEnum.DECOMMISSIONED.dbValue.equalsIgnoreCase(
            account.getState()))
        .toList();

    if (externalAccounts.isEmpty()) {
      return;
    }

    externalAccounts.forEach(account -> externalClientService.assignOktaUserGroup(
        account.getIdpUserIdentifier(), Constants.EMPLOYEE_EXTERNAL_USER_GROUP));

    log.info("createEmployee # Assigned {} to {} linked external account(s) for shortId: {}",
        Constants.EMPLOYEE_EXTERNAL_USER_GROUP, externalAccounts.size(), employee.getUsername());
  }

  /**
   * Propagates an email change to every other user configuration of the same Person. The
   * employee configuration and the Person are updated by the caller; without this the
   * Person's remaining profiles keep the previous address, so FUM stops agreeing with itself
   * on which address the human owns (NWPI-15025).
   */
  void updateEmailOnLinkedAccounts(IamUserConfiguration ssoAccount, String email,
      String requestedBy) {
    if (StringUtils.isBlank(email)) {
      return;
    }

    List<IamUserConfiguration> staleAccounts = getLinkedAccounts(ssoAccount).stream()
        .filter(linkedAccount -> !email.equalsIgnoreCase(linkedAccount.getEmail()))
        .toList();

    if (staleAccounts.isEmpty()) {
      return;
    }

    Timestamp now = new Timestamp(System.currentTimeMillis());
    List<Pair<UserConfiguration, UserConfiguration>> auditSnapshots = new ArrayList<>();
    for (IamUserConfiguration linkedAccount : staleAccounts) {
      UserConfiguration before = ApiMapper.toAuditUserConfiguration(linkedAccount);
      linkedAccount.setEmail(email);
      linkedAccount.setLastUpdatedBy(requestedBy);
      linkedAccount.setLastUpdateDate(now);
      iamUserConfigurationRepository.save(linkedAccount);
      evictUserConfigurationCache(linkedAccount);
      auditSnapshots.add(Pair.of(before, ApiMapper.toAuditUserConfiguration(linkedAccount)));
    }

    // Publishing is a fire-and-forget Kafka call, so force the cascade to reach the database
    // first: otherwise a constraint failure here leaves audit events describing writes the
    // rolled-back transaction never kept.
    entityManager.flush();
    auditSnapshots.forEach(snapshot -> auditLogService.publishEmployeeAudit(
        AuditEventType.UPDATE, snapshot.getLeft(), snapshot.getRight()));

    log.info("updateEmailOnLinkedAccounts # Applied the new email to {} linked account(s) "
        + "for shortId: {}", staleAccounts.size(), ssoAccount.getUsername());
  }

  /** Every user configuration of the account's Person, excluding the account itself. */
  private List<IamUserConfiguration> getLinkedAccounts(IamUserConfiguration ssoAccount) {
    Person person = getPersonByUserConfigId(ssoAccount.getUserConfigurationId().intValue());
    if (person == null) {
      return List.of();
    }

    Integer ssoUserId = ssoAccount.getUserConfigurationId().intValue();
    List<Long> linkedUserIds = personAssignmentRepository
        .findAllByPersonPersonId(person.getPersonId()).stream()
        .map(PersonAssignment::getUserId)
        .filter(Objects::nonNull)
        .filter(userId -> !userId.equals(ssoUserId))
        .distinct()
        .map(Integer::longValue)
        .toList();

    if (linkedUserIds.isEmpty()) {
      return List.of();
    }

    return iamUserConfigurationRepository.findAllById(linkedUserIds);
  }

  // The transaction-aware RedisCacheManager applies this on commit; an afterCommit callback drops it.
  private void evictUserConfigurationCache(IamUserConfiguration account) {
    redisCacheOperationService.deleteUserConfigurationCache(account.getIdpSubject(),
        account.getUserConfigurationId().intValue(), account.getIdpUserIdentifier());
  }

  private void setStateActive(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.ACTIVE.dbValue);
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.ACTIVE.dbValue);
    iamUserConfiguration.setStateAction("");
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  private void setStateSuspended(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.INACTIVE.dbValue);
    iamUserConfiguration.setActive(false);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.SUSPENDED.dbValue);
    iamUserConfiguration.setStateAction("");
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  private void setStateOnboardingStaged(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.ONBOARDING.dbValue);
    iamUserConfiguration.setActive(false);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.STAGED.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.ONBOARDING.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  private void setStateOnboardingPendingUser(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.PROVISIONED.dbValue);
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.PENDING_USER_ACTION.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.ONBOARDING.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  private void setState2FaPendingUser(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.PROVISIONED.dbValue);
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.PENDING_USER_ACTION.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.SET_2FA.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  private void setStatePasswordPendingUser(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.PROVISIONED.dbValue);
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.PENDING_USER_ACTION.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.SET_PASSWORD.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  private void setStatePasswordExpired(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.RECOVERY.dbValue);
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.PASSWORD_EXPIRED.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.PASSWORD_EXPIRED.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  private void setStateReset(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.RECOVERY.dbValue);
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.PASSWORD_RESET.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.PASSWORD_RESET.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  private void setStateLockedOut(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.INACTIVE.dbValue);
    iamUserConfiguration.setActive(false);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.LOCKED.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.LOCKED.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  private void setStateDecommissioned(IamUserConfiguration iamUserConfiguration) {
    iamUserConfiguration.setState(UserStateEnum.DECOMMISSIONED.dbValue);
    iamUserConfiguration.setActive(false);
    iamUserConfiguration.setStateDescription(UserStateDescriptionEnum.SUSPENDED.dbValue);
    iamUserConfiguration.setStateAction(UserStateActionEnum.SUSPENDED.dbValue);
    iamUserConfiguration.setStatusLastUpdated(new Timestamp(System.currentTimeMillis()));
  }

  /**
   * Re-derives the account's state from its live Okta profile. Okta is the source of truth for
   * nbin users, so a state written locally holds only until the next read syncs it back.
   */
  private void applyOktaDerivedState(IamUserConfiguration account, boolean active) {
    // NWPI-15109: never re-derive a deliberately retired account. Okta keeps reporting a sunset
    // external account ACTIVE, so without this the switch below maps it straight back to active.
    if (UserStateEnum.DECOMMISSIONED.dbValue.equalsIgnoreCase(account.getState())) {
      return;
    }
    if (StringUtils.isBlank(account.getIdpUserIdentifier())) {
      if (active) {
        setStateActive(account);
      } else {
        setStateSuspended(account);
      }
      return;
    }

    OktaUserProfile profile = externalClientService
        .getOktaUserProfile(account.getIdpUserIdentifier(), "");
    if (profile == null || profile.getStatus() == null) {
      log.warn("Could not read Okta profile for {}", account.getIdpUserIdentifier());
      throw new FumServiceException(Constants.ERROR_OKTA_STATUS_GET_CODE,
          Constants.ERROR_OKTA_STATUS_GET_MESSAGE);
    }

    boolean onboardingIncomplete = profile.getCredentials() == null
        || profile.getCredentials().getRecoveryQuestion() == null;

    switch (profile.getStatus()) {
      case Constants.IDP_STATUS_PASSWORD_EXPIRED -> {
        if (onboardingIncomplete) {
          OktaFactor[] factors = profile.getFactors();
          if (isEmptyFactor(factors)) {
            setStateOnboardingStaged(account);
          } else if (hasSmsInactive(factors)) {
            setState2FaPendingUser(account);
          } else if (hasSmsActive(factors)) {
            setStatePasswordPendingUser(account);
          } else {
            log.warn("Unknown Okta profile status for {} - setting onboarding",
                account.getUsername());
            setStateOnboardingStaged(account);
          }
        } else {
          setStatePasswordExpired(account);
        }
      }
      case Constants.IDP_STATUS_ACTIVE -> {
        if (onboardingIncomplete) {
          setStateOnboardingPendingUser(account);
        } else {
          OktaFactor[] factors = profile.getFactors();
          if (isEmptyFactor(factors) || hasSmsInactive(factors)) {
            setStateReset(account);
          } else {
            setStateActive(account);
          }
        }
      }
      case Constants.IDP_STATUS_SUSPENDED -> setStateSuspended(account);
      case Constants.IDP_STATUS_LOCKED_OUT -> setStateLockedOut(account);
      case Constants.IDP_STATUS_DEPROVISIONED -> setStateDecommissioned(account);
      default ->
          // Okta also reports STAGED / PROVISIONED / RECOVERY, which are transient - RECOVERY is
          // simply a password reset in progress. Decommissioning on those used to self-heal on the
          // next sync, but decommissioned is now sticky (NWPI-15109), so it would brick a live user.
          log.warn("Unhandled okta status {} for {} - leaving state {} unchanged",
              profile.getStatus(), account.getUsername(), account.getState());
    }
  }

  private boolean isEmptyFactor(OktaFactor[] factors) {
    return factors == null || factors.length < 1;
  }

  private boolean hasSmsInactive(OktaFactor[] oktaFactors) {
    if (isEmptyFactor(oktaFactors)) {
      return true;
    }
    return Arrays.stream(oktaFactors)
        .anyMatch(oktaFactor -> Constants.SMS.equals(oktaFactor.getFactorType())
            && !(Constants.IDP_STATUS_ACTIVE.equals(oktaFactor.getStatus())
                || Constants.IDP_STATUS_PENDING_ACTIVATION.equals(oktaFactor.getStatus())));
  }

  private boolean hasSmsActive(OktaFactor[] oktaFactors) {
    if (isEmptyFactor(oktaFactors)) {
      return true;
    }
    return Arrays.stream(oktaFactors)
        .anyMatch(oktaFactor -> Constants.SMS.equals(oktaFactor.getFactorType())
            && Constants.IDP_STATUS_ACTIVE.equals(oktaFactor.getStatus()));
  }


  private void validateSingleFieldPatch(PatchUserEmployee patch) {
    long fieldCount = Stream.of(
        patch.getFirstName(),
        patch.getLastName(),
        patch.getEmail(),
        patch.getLanguage(),
        patch.getProfile()
    ).filter(Objects::nonNull).count();

    if (fieldCount != 1) {
      throw new FumValidationException(Constants.EMPLOYEE_PATCH_SINGLE_FIELD_CODE,
          Constants.EMPLOYEE_PATCH_SINGLE_FIELD_MESSAGE);
    }

    if (patch.getProfile() != null) {
      long profileFieldCount = Stream.of(
          patch.getProfile().getActive(),
          patch.getProfile().getDefaultModule()
      ).filter(Objects::nonNull).count();

      if (profileFieldCount != 1) {
        throw new FumValidationException(Constants.EMPLOYEE_PATCH_SINGLE_FIELD_CODE,
            Constants.EMPLOYEE_PATCH_SINGLE_FIELD_MESSAGE);
      }

      if (patch.getProfile().getDefaultModule() != null
          && !Constants.DEFAULT_MODULES.contains(patch.getProfile().getDefaultModule())) {
        throw new FumValidationException(Constants.EMPLOYEE_DEFAULT_MODULE_CODE,
            Constants.EMPLOYEE_DEFAULT_MODULE_MESSAGE);
      }
    }
  }

  private void updateUserPreferences(IamUserConfiguration entity, String defaultModule) {
    String saveDefaultModule = StringUtils.isEmpty(defaultModule) ? null : defaultModule;
    Optional.ofNullable(entity.getUserPreferences())
        .ifPresentOrElse(map -> map.put(UserPreferencesEnum.defaultModule.name(), saveDefaultModule),
            () -> {
              Map<String, String> userPreferences = new HashMap<>();
              userPreferences.put(UserPreferencesEnum.defaultModule.name(), saveDefaultModule);
              entity.setUserPreferences(userPreferences);
            });
  }

  private void removeExistingUserAssignment(String idpSubject, UserAssignmentType userAssignmentType) {
    log.debug("Deleting User assignments of type {} - FeaturePackage for user: {}", userAssignmentType.name(), idpSubject);
    try {
      userAssignmentRepository.deleteUserAssignmentsByIdpSubjectAndAssignmentType(
          idpSubject, userAssignmentType);
    } catch(Exception e) {
      log.debug("Delete UserAssignment failed for assignment type {} - FeaturePackage for user: {} exception: {}",
          userAssignmentType.name(), idpSubject, e.getMessage());
      throw e;
    }
  }

  /**
   * Removes the user's existing resource (type S) assignments during a reassignment, while
   * preserving any resource whose type is {@code dwh_ui_module}. Those data-warehouse resources
   * must survive a feature-package/resource reassignment and remain assigned as-is.
   */
  void removeResourceAssignmentsExceptDwh(String idpSubject) {
    List<UserAssignment> resourceAssignments = userAssignmentRepository
        .findAllByIdpSubjectAndAssignmentType(idpSubject, UserAssignmentType.S)
        .orElseGet(List::of);
    if (resourceAssignments.isEmpty()) {
      return;
    }

    // Resource ids to keep: those pointing to a dwh_ui_module resource.
    Set<Long> dwhResourceIds = resourceRepository
        .findByType(Constants.RESOURCE_TYPE_DWH_UI_MODULE)
        .stream()
        .map(Resource::getResourceId)
        .collect(Collectors.toSet());

    List<UserAssignment> toRemove = resourceAssignments.stream()
        .filter(assignment -> assignment.getAssigneeId() == null
            || !dwhResourceIds.contains(assignment.getAssigneeId().longValue()))
        .collect(Collectors.toList());

    if (toRemove.isEmpty()) {
      log.debug("removeResourceAssignmentsExceptDwh # All resource assignments are dwh_ui_module; nothing removed for user: {}", idpSubject);
      return;
    }

    userAssignmentRepository.deleteAll(toRemove);
    log.debug("removeResourceAssignmentsExceptDwh # Removed {} resource assignment(s), preserved {} dwh_ui_module resource(s) for user: {}",
        toRemove.size(), resourceAssignments.size() - toRemove.size(), idpSubject);
  }

  CreateUserEmployee toCreateUserEmployee(String shortId, UpdateUserEmployee update) {
    CreateUserEmployee create = new CreateUserEmployee();
    create.setFirstName(update.getFirstName());
    create.setLastName(update.getLastName());
    create.setEmail(update.getEmail());

    if (update.getLanguage() != null) {
      create.setLanguage(update.getLanguage());
    }

    if (update.getProfile() != null) {
      CreateUserEmployeeProfile profile = new CreateUserEmployeeProfile();
      profile.setDefaultModule(update.getProfile().getDefaultModule());
      profile.setActive(update.getProfile().getActive());
      profile.setShortId(shortId);
      create.setProfile(profile);

      if (update.getProfile().getAssignment() != null) {
        EmployeeAssignmentRequest source = update.getProfile().getAssignment();
        EmployeeAssignmentRequest assignments = new EmployeeAssignmentRequest();
        assignments.setFirm(source.getFirm());
        assignments.setPackage(source.getPackage());
        assignments.setRrcodes(source.getRrcodes());
        create.getProfile().setAssignment(assignments);
      }
    }

    return create;
  }

  public EmployeeUserConfiguration getEmployeeUser(String shortId) {
    IamUserConfiguration userConfig = findByShortId(shortId).orElse(null);

    if (userConfig == null || !Constants.IDP_EMP.equalsIgnoreCase(userConfig.getIdp())) {
      throw new FumNotFoundException(Constants.ERROR_USER_NOT_FOUND_CODE,
          String.format(Constants.ERROR_USER_NOT_FOUND_MESSAGE, shortId));
    }

    Person person = getPersonByUserConfigId(userConfig.getUserConfigurationId().intValue());

    EmployeeUserConfiguration dto = ApiMapper.toEmployeeDto(person, userConfig);

    dto.setLinkedProfiles(ApiMapper.toLinkedProfiles(userConfig));

    EmployeeAssignment assignment = ApiMapper.toAssignment(userConfig);
    dto.getProfile().setAssignment(assignment);

    updateAssignments(dto, userConfig.getIdpSubject());

    log.debug("Fetched employee details for shortId: {}", shortId);
    return dto;
  }

  private Person getPersonByUserConfigId(Integer userConfigId) {
    List<PersonAssignment> assignments = personAssignmentRepository.findAll(
        (root, query, cb) -> cb.equal(root.get("userId"), userConfigId)
    );
    return assignments.isEmpty() ? null : assignments.get(0).getPerson();
  }

  private boolean isLinkedToEmployee(Person person) {
    return personAssignmentRepository.findAllByPersonPersonId(person.getPersonId()).stream()
        .map(PersonAssignment::getUserId)
        .filter(Objects::nonNull)
        .map(userId -> iamUserConfigurationRepository.findById(userId.longValue()))
        .flatMap(Optional::stream)
        .anyMatch(userConfig -> Constants.IDP_EMP.equalsIgnoreCase(userConfig.getIdp()));
  }

  /** Rejects an email already owned by a different Person, which the unique index would reject too. */
  private void validateEmailAvailable(String email, IamUserConfiguration entity) {
    if (email == null) {
      return;
    }
    String canonicalEmail = EmailUtils.canonicalize(email);
    if (canonicalEmail.isEmpty()) {
      throw new FumValidationException(Constants.EMPLOYEE_REQUIRED_FIELD_CODE,
          String.format(Constants.EMPLOYEE_REQUIRED_FIELD_MESSAGE, "email"));
    }
    personRepository.findFirstByEmailIgnoreCase(canonicalEmail)
        .filter(person -> personAssignmentRepository.findFirstByPersonPersonIdAndUserId(
            person.getPersonId(), entity.getUserConfigurationId().intValue()).isEmpty())
        .ifPresent(person -> {
          throw new FumConflictException(Constants.EMPLOYEE_EMAIL_DUPLICATE_CODE,
              String.format(Constants.EMPLOYEE_EMAIL_DUPLICATE_MESSAGE, canonicalEmail));
        });
  }

  @Transactional
  public void deleteEmployee(String shortId) {
    IamUserConfiguration userConfig = findByShortId(shortId).orElse(null);

    if (userConfig == null) {
      log.debug("deleteEmployee # Employee not found for shortId: {}, returning 204", shortId);
      return;
    }

    // Resolve the linked Person before clearing the session; it is needed later for FK-safe
    // person cleanup.
    Person person = getPersonByUserConfigId(userConfig.getUserConfigurationId().intValue());

    // Capture the audit snapshot NOW, while userConfig and its lazy @OneToMany collections
    // are loaded in the current session. toAuditUserConfiguration() materializes a fully
    // detached POJO (including firm/RR-code/resource assignments), so it remains valid after
    // the session is cleared and the entity is removed. Building it AFTER the delete would
    // re-trigger lazy loading of the child assignment entities, which hold @ManyToOne
    // references back to the now-removed IamUserConfiguration and cause a
    // TransientObjectException at commit-time flush.
    UserConfiguration auditBefore = ApiMapper.toAuditUserConfiguration(userConfig);

    // Clear persistence context to evict lazy-loaded child entities (UserAssignmentFirm, etc.)
    // that would cause TransientObjectException when IamUserConfiguration is removed. The audit
    // snapshot above already materialized every field needed, so detaching is safe.
    Long userConfigId = userConfig.getUserConfigurationId();
    String idpSubject = userConfig.getIdpSubject();
    entityManager.clear();

    // Re-fetch userConfig with a clean session (uninitialized lazy collections)
    userConfig = iamUserConfigurationRepository.findById(userConfigId).orElse(null);
    if (userConfig == null) {
      return;
    }

    // Delete feature packages via Authorization API
    deleteExistingFeaturePackages(shortId, userConfig);

    // Delete all user assignments (matches UserConfigurationServiceJpa.deleteUserConfiguration pattern)
    userAssignmentRepository.deleteUserAssignmentsByIdpSubject(idpSubject);
    log.debug("deleteEmployee # Deleted all user assignments for shortId: {}", shortId);

    // Delete the Person and ALL of its PERSON_USER assignments. Deleting the
    // Person while any PERSON_USER row still references it violates the
    // fk_person foreign-key constraint, so every assignment for the Person must
    // be removed first (not just the link for the user being deleted).
    if (person != null) {
      List<PersonAssignment> personAssignments =
          personAssignmentRepository.findAllByPersonPersonId(person.getPersonId());
      if (!personAssignments.isEmpty()) {
        personAssignmentRepository.deleteAll(personAssignments);
        log.debug("deleteEmployee # Deleted {} person assignment(s) for shortId: {}",
            personAssignments.size(), shortId);
      }
      personRepository.delete(person);
      log.debug("deleteEmployee # Deleted person for shortId: {}", shortId);
    }

    // Hard delete the user configuration
    iamUserConfigurationRepository.delete(userConfig);
    evictUserConfigurationCache(userConfig);
    log.debug("deleteEmployee # Hard deleted user configuration for shortId: {}", shortId);

    // Publish the audit snapshot captured before deletion. Do NOT re-read userConfig's
    // lazy collections here: the entity is scheduled for removal and touching its
    // @OneToMany associations would re-attach child entities that reference it,
    // triggering TransientObjectException at commit-time flush.
    auditLogService.publishEmployeeAudit(AuditEventType.UPDATE, auditBefore, null);
  }

  private void deleteExistingFeaturePackages(String shortId, IamUserConfiguration userConfig) {
    List<Integer> featurePackageIds = fetchFeaturePackageIds(userConfig.getIdpSubject());
    if (!featurePackageIds.isEmpty()) {
      for (Integer featurePackageId : featurePackageIds) {
        try {
          authorizationClient.deleteFeaturePackage(
              systemTokenFactory.getBearerToken(Constants.SYSTEM_TOKEN_FUM), featurePackageId);
          log.debug("deleteEmployee # Deleted featurePackage: {} for shortId: {}", featurePackageId, shortId);
        } catch (Exception e) {
          log.warn("deleteEmployee # Failed to delete featurePackage: {} for shortId: {} exception: {}",
              featurePackageId, shortId, e.getMessage());
        }
      }
    }
  }

  private List<Integer> fetchFeaturePackageIds(String idpSubject) {
    return userAssignmentRepository
        .findAllByIdpSubjectAndAssignmentType(idpSubject, UserAssignmentType.P)
        .orElse(List.of())
        .stream()
        .map(UserAssignment::getAssigneeId)
        .toList();
  }
}
