package ca.bnc.wealth.api.user.service;

import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.common.entitlements.user_management.model.Firm;
import ca.bnc.wealth.common.entitlements.user_management.model.FirmsResponse;
import ca.bnc.wealth.common.entitlements.user_management.model.RrCodeRange;
import ca.bnc.wealth.common.entitlements.user_management.model.RrCodes;
import ca.bnc.wealth.common.entitlements.user_management.model.RrCodesResponse;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class EntitlementFirmService {

    private static final Set<FirmType> ALLOWED_FIRM_TYPES = Set.of(FirmType.NBIN, FirmType.Internal);

    private final FirmRepository firmRepository;

    public FirmsResponse getEntitlementFirmsInternals() {
        log.debug("getEntitlementFirmsInternals # Start");

        List<ca.bnc.wealth.common.jpa.entity.iam.Firm> firmEntities =
            firmRepository.findAllByFirmTypeIn(ALLOWED_FIRM_TYPES);

        List<Firm> firms = firmEntities.stream()
            .map(this::mapToEntitlementFirm)
            .toList();

        FirmsResponse response = new FirmsResponse();
        response.setFirms(firms);
        return response;
    }

    public RrCodesResponse getEntitlementRrCodesInternals() {
        log.debug("getEntitlementRrCodesInternals # Start");
        RrCodesResponse response = new RrCodesResponse();
        response.setRrCodes(List.of(Constants.INTERNAL_RRCODE));
        return response;
    }

    private Firm mapToEntitlementFirm(ca.bnc.wealth.common.jpa.entity.iam.Firm firmEntity) {
        Firm firm = new Firm();
        firm.setId(firmEntity.getFirmId());
        firm.setName(firmEntity.getName());
        firm.setType(Optional.ofNullable(firmEntity.getFirmType())
            .map(type -> type.name())
            .orElse(null));
        firm.setDescription(firmEntity.getDescription());
        firm.setActive(firmEntity.getActive());

        Optional.ofNullable(firmEntity.getFinancialEntity())
            .ifPresent(fe -> {
                firm.setBrokerCode(fe.getBrokerCode());
                firm.bNumber(fe.getBranchNumber());
                firm.setDealerCode(fe.getDealerCode());
            });

        firm.setRrCodes(mapRrCodes(firmEntity));
        return firm;
    }

    private RrCodes mapRrCodes(ca.bnc.wealth.common.jpa.entity.iam.Firm firmEntity) {
        RrCodes rrCodes = new RrCodes();
        List<String> codes = new ArrayList<>();
        List<RrCodeRange> ranges = new ArrayList<>();

        Optional.ofNullable(firmEntity.getFirmAssignmentRrCodeRanges())
            .ifPresent(assignments -> assignments.stream()
                .map(assignment -> assignment.getIamRrCodeRange())
                .filter(Objects::nonNull)
                .forEach(range -> {
                    if (range.getFromRrCode().equals(range.getToRrCode())) {
                        codes.add(range.getFromRrCode());
                    } else {
                        RrCodeRange rrCodeRange = new RrCodeRange();
                        rrCodeRange.setFrom(range.getFromRrCode());
                        rrCodeRange.setTo(range.getToRrCode());
                        ranges.add(rrCodeRange);
                    }
                }));

        rrCodes.setCodes(codes);
        rrCodes.setRanges(ranges);
        return rrCodes;
    }
}
