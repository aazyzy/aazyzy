package ca.bnc.wealth.api.user.service;

import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.common.entitlements.user_management.model.ModulesResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class EntitlementModuleService {

  public ModulesResponse getEntitlementModules() {
    log.debug("getEntitlementModules # Start");
    ModulesResponse response = new ModulesResponse();
    response.setModules(
        Constants.DEFAULT_MODULES.stream()
            .filter(StringUtils::isNotBlank)
            .toList());
    return response;
  }
}
