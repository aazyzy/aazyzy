package ca.bnc.wealth.api.user.service;

import ca.bnc.wealth.common.entitlements.user_management.model.ModelPackage;
import ca.bnc.wealth.common.entitlements.user_management.model.PackageFeature;
import ca.bnc.wealth.common.entitlements.user_management.model.PackagesResponse;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.UserGroup;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class EntitlementPackageService {

  private final PackageTemplateRepository packageTemplateRepository;

  public PackagesResponse getEntitlementPackages() {
    log.info("getEntitlementPackages # Start");
    List<PackageTemplate> packageTemplates = packageTemplateRepository.findAll();

    List<ModelPackage> packages = packageTemplates.stream()
        .map(this::toModelPackage)
        .toList();

    PackagesResponse response = new PackagesResponse();
    response.setPackages(packages);

    log.info("getEntitlementPackages # End: returned {} packages", packages.size());
    return response;
  }

  private ModelPackage toModelPackage(PackageTemplate template) {
    ModelPackage dto = new ModelPackage();
    dto.setId(String.valueOf(template.getPackageTemplateId()));
    dto.setName(template.getName());
    dto.setDescription(template.getDescription());
    dto.setGroup(resolveGroup(template));
    dto.setActive(template.isActive());
    dto.setFeatures(toFeatures(template));
    return dto;
  }

  /**
   * Resolves the package group from its assigned user group. A package template is mapped 1:1 to a
   * user group, so the first user-group assignment (assignment type {@code G}) is used. Returns
   * {@code null} when no user group is assigned.
   */
  private String resolveGroup(PackageTemplate template) {
    List<PackageTemplateAssignmentUserGroup> userGroupAssignments =
        template.getPackageTemplateAssignmentUserGroups();
    if (userGroupAssignments == null) {
      return null;
    }

    return userGroupAssignments.stream()
        .filter(assignment -> assignment.getAssignmentType() == PackageAssignmentType.G)
        .map(PackageTemplateAssignmentUserGroup::getUserGroup)
        .filter(Objects::nonNull)
        .map(UserGroup::getName)
        .findFirst()
        .orElse(null);
  }

  private List<PackageFeature> toFeatures(PackageTemplate template) {
    List<PackageTemplateAssignmentResource> assignments =
        template.getPackageTemplateAssignmentResources();
    if (assignments == null) {
      return Collections.emptyList();
    }

    return assignments.stream()
        .filter(assignment -> assignment.getAssignmentType() == PackageAssignmentType.S)
        .filter(assignment -> Objects.nonNull(assignment.getResource()))
        .map(this::toPackageFeature)
        .toList();
  }

  private PackageFeature toPackageFeature(PackageTemplateAssignmentResource assignment) {
    PackageFeature feature = new PackageFeature();
    feature.setResource(assignment.getResource().getName());
    feature.setMandatory(assignment.getAssignmentMode() == PackageAssignmentMode.M);
    feature.setSelected(assignment.isSelectionDefault());
    return feature;
  }
}
