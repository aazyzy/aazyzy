package ca.bnc.wealth.api.user.service;

import ca.bnc.wealth.common.entitlements.user_management.model.EntitlementResource;
import ca.bnc.wealth.common.entitlements.user_management.model.ResourcesResponse;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class EntitlementResourceService {

  private final ResourceRepository resourceRepository;

  public ResourcesResponse getEntitlementResources() {
    log.info("getEntitlementResources # Start");
    List<Resource> resources = resourceRepository.findAll();

    List<EntitlementResource> entitlementResources = resources.stream()
        .map(this::toEntitlementResource)
        .toList();

    ResourcesResponse response = new ResourcesResponse();
    response.setResources(entitlementResources);

    log.info("getEntitlementResources # End: returned {} resources", entitlementResources.size());
    return response;
  }

  private EntitlementResource toEntitlementResource(Resource resource) {
    EntitlementResource dto = new EntitlementResource();
    dto.setId(String.valueOf(resource.getResourceId()));
    dto.setName(resource.getName());
    dto.setType(resource.getType());
    dto.setRestriction(resource.getRestriction());
    dto.setDescription(resource.getDescription());
    dto.setGroup(resource.getGroupName());
    dto.setLabel(resource.getLabel());
    dto.setPurpose(resource.getPurpose());
    dto.setVersion(resource.getVersion());
    dto.setActive(resource.isActive());
    return dto;
  }
}
