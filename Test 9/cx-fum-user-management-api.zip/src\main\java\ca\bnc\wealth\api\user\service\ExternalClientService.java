package ca.bnc.wealth.api.user.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ca.bnc.wealth.common.ciam.feign.client.AddOktaUserGroupClient;
import ca.bnc.wealth.common.ciam.feign.client.GetOktaUserGroupsClient;
import ca.bnc.wealth.common.ciam.feign.client.GetOktaUserProfileClient;
import ca.bnc.wealth.common.ciam.feign.client.SuspendOktaUserProfileClient;
import ca.bnc.wealth.common.ciam.feign.client.UnsuspendOktaUserProfileClient;
import ca.bnc.wealth.common.ciam.model.OktaAccessProfile;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.ciam.security.CiamSystemToken;
import ca.bnc.wealth.common.r2.feign.client.CxUserProfileClient;
import ca.bnc.wealth.common.r2.model.R2UserProfile;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class ExternalClientService {

  @Value("${feign.ciamApi.context}")
  private String ciamContext;

  private final CxUserProfileClient cxUserProfileClient;

  private final CiamSystemToken ciamSystemToken;

  private final GetOktaUserProfileClient userOktaProfileClient;

  private final SuspendOktaUserProfileClient suspendOktaUserProfileClient;

  private final UnsuspendOktaUserProfileClient unsuspendOktaUserProfileClient;

  private final GetOktaUserGroupsClient getOktaUserGroupsClient;

  private final AddOktaUserGroupClient addOktaUserGroupClient;

  public Map<String, R2UserProfile> getR2UserProfiles(List<String> idpSubjects, String uuid) {
    log.info("{{}} Getting R2 profiles for users {}", uuid, idpSubjects);
    Map<String, R2UserProfile> r2UserProfileMap = new HashMap<>();
    try {
      String bearerToken = ciamSystemToken.getBearerToken();
      r2UserProfileMap = cxUserProfileClient.getR2UserProfiles(bearerToken, idpSubjects).getBody();
    } catch (Exception e) {
      log.warn("{{}} Error getting R2 profiles from Cx with error: {}", uuid, e.getMessage());
    }
    log.info("{{}} R2 profiles {} ", uuid, r2UserProfileMap);
    return r2UserProfileMap;
  }

  public String getSecureZoneId(String idpUserId, String uuid) {
    OktaUserProfile oktaUserProfile = getOktaUserProfile(idpUserId, uuid);

    return Optional.ofNullable(oktaUserProfile)
        .map(OktaUserProfile::getAccessProfile)
        .map(OktaAccessProfile::getBngfSecureZoneId)
        .map(array -> String.join(",", array))
        .orElse("");
  }

  public OktaUserProfile getOktaUserProfile(String idpUserId, String uuid) {
    OktaUserProfile oktaUserProfile = null;
    try {
      String bearerToken = ciamSystemToken.getBearerToken();
      oktaUserProfile =
          userOktaProfileClient.getOktaUserProfile(bearerToken, ciamContext, idpUserId);
    } catch (Exception e) {
      log.warn("{{}} Error getting {} profile from Okta with error: {}", uuid, idpUserId, e.getMessage());
    }
    return oktaUserProfile;
  }

  /**
   * Pushes an active/inactive status change to Okta. Employee (IAMi) users have no Okta profile
   * and a blank idpUserId, so the call is skipped for them.
   *
   * <p>Okta lifecycle endpoints are transitions, not desired-state operations: unsuspending an
   * already-ACTIVE user (or suspending an already-SUSPENDED one) is rejected with a 400. Such a
   * rejection is a no-op, not a failure, so this method never throws and never fails the
   * enclosing employee create/update/patch. The caller re-reads the profile immediately
   * afterwards and derives FUM state from Okta's actual status, which is what keeps the two
   * systems consistent.
   */
  public void updateOktaUserStatus(String idpUserId, boolean active) {
    if (StringUtils.isBlank(idpUserId)) {
      log.debug("Skipping Okta status update - user has no idpUserId (non-Okta/employee user)");
      return;
    }
    String bearerToken = ciamSystemToken.getBearerToken();
    try {
      if (active) {
        unsuspendOktaUserProfileClient.unsuspendOktaUserProfile(bearerToken, ciamContext, idpUserId);
      } else {
        suspendOktaUserProfileClient.suspendOktaUserProfile(bearerToken, ciamContext, idpUserId);
      }
      log.info("Okta status updated for {} active={}", idpUserId, active);
    } catch (Exception e) {
      // Not fatal: state is derived from the profile read-back, so FUM cannot diverge from Okta.
      log.warn("Could not update Okta status for {} active={} - continuing: {}", idpUserId, active,
          e.getMessage(), e);
    }
  }

  /**
   * Adds an Okta group to a user, if the user does not already hold it. Employee (IAMi) users have
   * no Okta profile and a blank idpUserId, so the call is skipped for them.
   *
   * <p>The group exists only in Okta — it is not mirrored by any FUM row — so a failure here
   * leaves nothing inconsistent on our side and must not roll back the enclosing employee
   * create/update. This method therefore never throws.
   */
  @SuppressWarnings("unchecked")
  public void assignOktaUserGroup(String idpUserId, String groupName) {
    if (StringUtils.isBlank(idpUserId)) {
      log.debug("Skipping Okta group assignment - user has no idpUserId (non-Okta/employee user)");
      return;
    }
    try {
      String bearerToken = ciamSystemToken.getBearerToken();
      ResponseEntity<Object> response =
          getOktaUserGroupsClient.getOktaUserGroups(bearerToken, ciamContext, idpUserId);

      List<String> groupsInOkta = Optional.ofNullable(response)
          .map(ResponseEntity::getBody)
          .filter(Map.class::isInstance)
          .map(body -> (List<String>) ((Map<String, Object>) body).get("groupNames"))
          .orElse(List.of());

      if (groupsInOkta.contains(groupName)) {
        log.debug("Okta group {} already assigned to {}", groupName, idpUserId);
        return;
      }

      addOktaUserGroupClient.addUserGroup(bearerToken, ciamContext, groupName, idpUserId);
      log.info("Okta group {} assigned to {}", groupName, idpUserId);
    } catch (Exception e) {
      log.warn("Could not assign Okta group {} to {} - continuing: {}", groupName, idpUserId,
          e.getMessage(), e);
    }
  }
}
