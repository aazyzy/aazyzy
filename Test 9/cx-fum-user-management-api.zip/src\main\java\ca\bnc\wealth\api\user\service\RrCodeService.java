package ca.bnc.wealth.api.user.service;

import ca.bnc.wealth.api.user.utils.ApiMapper;
import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.model.UserStatusEnum;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentRrCodeRange;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class RrCodeService {

  private static final String RANGE_DELIMITER = "-";

  private final IamRrCodeRangeRepository iamRrCodeRangeRepository;
  private final UserAssignmentRrCodeRangeRepository userAssignmentRrCodeRangeRepository;
  private final UserAssignmentService userAssignmentService;
  private final UserManagementService userManagementService;

  public void assignRrCodesToUser(IamUserConfiguration user, Firm firm, List<String> rrCodes, String requestedBy) {
    assignRrCodesToUser(user, firm, rrCodes, requestedBy, hasFirmLevelAccess(user));
  }

  public void assignRrCodesToUser(IamUserConfiguration user, Firm firm, List<String> rrCodes, String requestedBy,
      boolean firmLevelAccess) {
    if (firm == null) {
      throw new FumValidationException(Constants.FIRM_MISSING, Constants.RRCODE_FIRM_MISSING_MESSAGE);
    }
    validateRestrictClientDataAccess(user, rrCodes);
    deleteUserRRCodesByIdpSubject(user.getIdpSubject());

    if (!CollectionUtils.isEmpty(rrCodes) || firmLevelAccess) {
      addRRCodeRangeToUser(user, firm, rrCodes, requestedBy, firmLevelAccess);
    }
  }

  public void deleteUserRRCodesByIdpSubject(String idpSubject) {
    List<UserAssignmentRrCodeRange> lst = userAssignmentService.getUserAssignment(idpSubject, UserAssignmentType.R);
    // Delete the existing RR code assignments immediately (single bulk statement) instead of using
    // the deferred deleteAll(...). The downstream IAM_V2.user_rr_code_assignment stored procedure
    // replaces the user's RR code set (delete existing + insert new) as soon as it runs. If the
    // removals were left queued in the persistence context, they would only be flushed later (e.g.
    // when building the audit snapshot); by then the rows have already been deleted by the stored
    // procedure, so the flush fails with a StaleObjectStateException and the whole transactional
    // update rolls back - leaving the RR codes unchanged. Executing the delete now keeps the
    // persistence context clean and lets the new RR codes persist.
    userAssignmentRrCodeRangeRepository.deleteAllInBatch(lst);
  }

  private void addRRCodeRangeToUser(IamUserConfiguration user, Firm firm, List<String> rrCodes, String requestedBy,
      boolean firmLevelAccess) {
    // if Firm level access, then assign all RR Codes from Firm to User regardless of input
    if (firmLevelAccess) {
      List<IamRrCodeRange> firmList = getIamRRCodeListByFirmId(firm.getFirmId());
      userAssignmentService.assignRrRangesSp(
          Math.toIntExact(user.getUserConfigurationId()),
          user.getIdpSubject(),
          firmList.stream().map(ApiMapper::toRrCodeRangeDto).collect(Collectors.toList()),
          requestedBy);
    } else {
      boolean isValidRrCodes = userManagementService.validateRrCodeByFirmId(firm.getFirmId(), rrCodes);
      if (!isValidRrCodes) {
        throw new FumValidationException(Constants.FIRM_RRCODE_INVALID, Constants.FIRM_RRCODE_INVALID_MESSAGE);
      }
      userAssignmentService.assignRrRangesSp(
          Math.toIntExact(user.getUserConfigurationId()),
          user.getIdpSubject(),
          toRrCodeRanges(rrCodes),
          requestedBy);
    }
  }

  public boolean hasFirmLevelAccess(IamUserConfiguration user) {
    return userAssignmentService.hasUserAssignment(
            user.getIdpSubject(), Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S);
  }

  private boolean hasRestrictClientDataAccess(IamUserConfiguration user) {
    return userAssignmentService.hasUserAssignment(
            user.getIdpSubject(), Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S);
  }

  private void validateRestrictClientDataAccess(IamUserConfiguration user, List<String> rrCodes) {
    boolean hasRestrictClientDataAccess = hasRestrictClientDataAccess(user);
    if (!hasRestrictClientDataAccess) {
      return;
    }
    if (hasFirmLevelAccess(user)) {
      throw new FumValidationException(
          Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS,
          Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS_MESSAGE);
    }
    if (rrCodes != null && !rrCodes.isEmpty()) {
      throw new FumValidationException(
          Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE,
          Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE_MESSAGE);
    }
  }

  private List<IamRrCodeRange> getIamRRCodeListByFirmId(String firmId) {
    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
    fieldValueMap.put(UserStatusEnum.ACTIVE.dbValue, Pair.of(EnumQueryCriteria.EQUALS, true));
    fieldValueMap.put("firmAssignmentRrCodeRanges.assignmentType",
            Pair.of(EnumQueryCriteria.EQUALS_CHARACTER, UserAssignmentType.R.name()));
    fieldValueMap.put("firmAssignmentRrCodeRanges.firm.firmId",
            Pair.of(EnumQueryCriteria.EQUALS, firmId));
    Specification<IamRrCodeRange> spec = new Specification<>(fieldValueMap);
    return iamRrCodeRangeRepository.findAll(spec);
  }

  List<RRCodeRange> toRrCodeRanges(List<String> rrCodes) {
    if (rrCodes == null) {
      return List.of();
    }
    return rrCodes.stream()
        .filter(Objects::nonNull)
        .map(String::trim)
        .filter(rrCode -> !rrCode.isEmpty())
        .map(this::toRrCodeRange)
        .toList();
  }

  private RRCodeRange toRrCodeRange(String rrCodes) {
    String[] parts = rrCodes.split(RANGE_DELIMITER, 2);
    String from = parts[0].trim();
    String to = (parts.length > 1 && !parts[1].isBlank()) ? parts[1].trim() : from;
    return new RRCodeRange()
        .fromRRCode(from)
        .toRRCode(to);
  }
}
