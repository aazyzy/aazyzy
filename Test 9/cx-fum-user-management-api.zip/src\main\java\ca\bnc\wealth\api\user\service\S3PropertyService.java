package ca.bnc.wealth.api.user.service;

import ca.bnc.wealth.common.s3.S3PropertyInterface;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.regions.Region;

@Service
public class S3PropertyService implements S3PropertyInterface {
  private static final String FIRM_ATTESTATION = "FIRM_ATTESTATION";

  @Value("${s3.firmAttestation.accessKeyId}")
  private String s3AccessKeyId;

  @Value("${s3.firmAttestation.secretAccessKey}")
  private String s3SecretAccessKey;

  @Value("${s3.firmAttestation.region:ca-central-1}")
  private String region;

  @Override
  public String getS3AccessFor() {
    return FIRM_ATTESTATION;
  }

  @Override
  public Region getS3Region() {
    return Region.of(region);
  }

  @Override
  public String getS3AccessKeyId() {
    return s3AccessKeyId;
  }

  @Override
  public String getS3SecretAccessKey() {
    return s3SecretAccessKey;
  }
}