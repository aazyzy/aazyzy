package ca.bnc.wealth.api.user.service;

import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.api.user.utils.SpecialInquiriesMapper;
import ca.bnc.wealth.common.core.helper.SubstitutionBase36EncoderHelper;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.enums.FirmAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FirmAssignment;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignment;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentFeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import ca.bnc.wealth.common.jpa.repo.iam.FirmAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentFeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserConfigSearchMaterializedViewRepository;
import ca.bnc.wealth.common.specialinquiries.user_management.model.Firm;
import ca.bnc.wealth.common.specialinquiries.user_management.model.FirmsResponse;
import ca.bnc.wealth.common.specialinquiries.user_management.model.UserConfiguration;
import ca.bnc.wealth.common.specialinquiries.user_management.model.UsersResponse;
import jakarta.persistence.criteria.Predicate;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

/**
 * Read-only inquiries backing the SpecialInquiries endpoints (NBINEN-12288).
 *
 * <p>Users are always read from {@code USER_CONFIGURATION_MATERIALIZED} so the payload matches
 * {@code POST /user-conf/users/genericSearchWithPagination} field for field, and NBX-only users are
 * excluded from every result exactly as that endpoint does.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SpecialInquiriesService {

  static final int MAX_RR_CODES = 1000;
  private static final Pattern RR_CODE_PATTERN = Pattern.compile("[A-Za-z0-9]{4}");
  // Same encoding as IAM_V2.B36_DECODE, which fills RR_CODE_RANGE.FROM/TO_RR_CODE_B10.
  private static final SubstitutionBase36EncoderHelper RR_CODE_DECODER =
      new SubstitutionBase36EncoderHelper();

  private final FirmRepository firmRepository;
  private final ResourceRepository resourceRepository;
  private final PackageTemplateRepository packageTemplateRepository;
  private final UserAssignmentFeaturePackageRepository userAssignmentFeaturePackageRepository;
  private final UserAssignmentResourceRepository userAssignmentResourceRepository;
  private final UserConfigSearchMaterializedViewRepository userConfigSearchMaterializedViewRepository;
  private final IamRrCodeRangeRepository iamRrCodeRangeRepository;
  private final UserAssignmentRepository userAssignmentRepository;
  private final FirmAssignmentRepository firmAssignmentRepository;

  // Active-only is specific to this inquiry: the scoped inquiries return inactive users too.
  public UsersResponse getAllUsers() {
    log.debug("getAllUsers");
    return findUsers(isActive());
  }

  public UsersResponse getUsersByFirm(String firmId) {
    log.debug("getUsersByFirm # firmId={}", firmId);
    requireFirm(firmId);
    return findUsers(firmIs(firmId));
  }

  public UsersResponse getUsersByUserPackage(String userPackageName) {
    log.debug("getUsersByUserPackage # userPackageName={}", userPackageName);
    PackageTemplate packageTemplate = requireUserPackage(userPackageName);
    return findUsersByIdpSubjects(idpSubjectsByUserPackage(packageTemplate), null);
  }

  public UsersResponse getUsersByResource(String resourceName) {
    log.debug("getUsersByResource # resourceName={}", resourceName);
    requireResource(resourceName);
    return findUsersByIdpSubjects(idpSubjectsByResource(resourceName), null);
  }

  public UsersResponse getUsersByFirmAndUserPackage(String firmId, String userPackageName) {
    log.debug("getUsersByFirmAndUserPackage # firmId={}, userPackageName={}", firmId, userPackageName);
    requireFirm(firmId);
    PackageTemplate packageTemplate = requireUserPackage(userPackageName);
    return findUsersByIdpSubjects(idpSubjectsByUserPackage(packageTemplate), firmId);
  }

  public UsersResponse getUsersByFirmAndResource(String firmId, String resourceName) {
    log.debug("getUsersByFirmAndResource # firmId={}, resourceName={}", firmId, resourceName);
    requireFirm(firmId);
    requireResource(resourceName);
    return findUsersByIdpSubjects(idpSubjectsByResource(resourceName), firmId);
  }

  /**
   * Users under at least one of the RR codes: those assigned an RR code range containing a code,
   * plus the firm-level-access users of every firm assigned such a range. The latter are restricted
   * to their row for that firm, as in {@link #getUsersByFirmAndResource}.
   */
  public UsersResponse getUsersByRrCodes(List<String> rrCodes) {
    Set<String> normalizedRrCodes = requireRrCodes(rrCodes);
    log.debug("getUsersByRrCodes # rrCodes={}", normalizedRrCodes);

    List<Integer> rrCodeRangeIds = rrCodeRangeIdsContainingAny(normalizedRrCodes);
    if (rrCodeRangeIds.isEmpty()) {
      return emptyUsersResponse();
    }

    Set<String> rrCodeRangeHolders = idpSubjectsAssigned(UserAssignmentType.R, rrCodeRangeIds);
    Set<Long> owningFirmEntityIds = firmEntityIdsAssigned(rrCodeRangeIds);
    Set<String> firmLevelAccessHolders = owningFirmEntityIds.isEmpty()
        ? Set.of()
        : idpSubjectsAssigned(UserAssignmentType.S, firmLevelAccessResourceIds());

    Specification<UserConfigSearchMaterializedView> spec = null;
    if (!rrCodeRangeHolders.isEmpty()) {
      spec = idpSubjectIn(rrCodeRangeHolders);
    }
    if (!firmLevelAccessHolders.isEmpty()) {
      Specification<UserConfigSearchMaterializedView> firmLevelAccessInOwningFirm =
          idpSubjectIn(firmLevelAccessHolders).and(firmEntityIdIn(owningFirmEntityIds));
      spec = spec == null ? firmLevelAccessInOwningFirm : spec.or(firmLevelAccessInOwningFirm);
    }
    return spec == null ? emptyUsersResponse() : findUsers(spec);
  }

  public FirmsResponse getFirmsByFirmType(String firmType) {
    log.debug("getFirmsByFirmType # firmType={}", firmType);
    List<Firm> firms = firmRepository.findAllByFirmType(toFirmType(firmType)).stream()
        .map(SpecialInquiriesService::toFirm)
        .toList();

    FirmsResponse response = new FirmsResponse();
    response.setFirms(firms);
    return response;
  }

  private Set<String> idpSubjectsByUserPackage(PackageTemplate packageTemplate) {
    return toIdpSubjects(
        userAssignmentFeaturePackageRepository.findAll((root, query, cb) -> cb.and(
            cb.equal(root.get("assignmentType"), UserAssignmentType.P),
            cb.equal(root.get("featurePackage").get("packageTemplate"), packageTemplate))),
        UserAssignmentFeaturePackage::getUserConfiguration);
  }

  private Set<String> idpSubjectsByResource(String resourceName) {
    // Matched on name so every version of the resource is covered.
    return toIdpSubjects(
        userAssignmentResourceRepository.findAll((root, query, cb) -> cb.and(
            cb.equal(root.get("assignmentType"), UserAssignmentType.S),
            cb.equal(root.get("resource").get("name"), resourceName))),
        UserAssignmentResource::getUserConfiguration);
  }

  private static <T> Set<String> toIdpSubjects(
      List<T> assignments, Function<T, IamUserConfiguration> userConfigurationExtractor) {
    return assignments.stream()
        .map(userConfigurationExtractor)
        .filter(Objects::nonNull)
        .map(IamUserConfiguration::getIdpSubject)
        .filter(StringUtils::isNotBlank)
        .collect(Collectors.toCollection(LinkedHashSet::new));
  }

  private List<Integer> rrCodeRangeIdsContainingAny(Collection<String> rrCodes) {
    List<Long> rrCodesB10 = rrCodes.stream()
        .map(rrCode -> RR_CODE_DECODER.base36EncodedCipher(RR_CODE_DECODER.createCipherText(rrCode)))
        .toList();
    return iamRrCodeRangeRepository.findAll(containsAnyOf(rrCodesB10)).stream()
        .map(rrCodeRange -> Math.toIntExact(rrCodeRange.getRrCodeRangeId()))
        .toList();
  }

  private static Specification<IamRrCodeRange> containsAnyOf(List<Long> rrCodesB10) {
    return (root, query, cb) -> cb.or(rrCodesB10.stream()
        .map(rrCodeB10 -> cb.and(
            cb.lessThanOrEqualTo(root.<Long>get("fromRrCodeB10"), rrCodeB10),
            cb.greaterThanOrEqualTo(root.<Long>get("toRrCodeB10"), rrCodeB10)))
        .toArray(Predicate[]::new));
  }

  // Untyped USER_ASSIGNMENT / FIRM_ASSIGNMENT rows have no eager associations: one query, no N+1.
  private Set<String> idpSubjectsAssigned(
      UserAssignmentType assignmentType, Collection<Integer> assigneeIds) {
    if (assigneeIds.isEmpty()) {
      return Set.of();
    }
    return userAssignmentRepository.findAll((root, query, cb) -> cb.and(
            cb.equal(root.get("assignmentType"), assignmentType),
            root.get("assigneeId").in(assigneeIds)))
        .stream()
        .map(UserAssignment::getIdpSubject)
        .filter(StringUtils::isNotBlank)
        .collect(Collectors.toCollection(LinkedHashSet::new));
  }

  private Set<Long> firmEntityIdsAssigned(Collection<Integer> rrCodeRangeIds) {
    return firmAssignmentRepository.findAll((root, query, cb) -> cb.and(
            cb.equal(root.get("assignmentType"), FirmAssignmentType.R),
            root.get("assigneeId").in(rrCodeRangeIds)))
        .stream()
        .map(FirmAssignment::getFirmEntityId)
        .filter(Objects::nonNull)
        .map(Integer::longValue)
        .collect(Collectors.toCollection(LinkedHashSet::new));
  }

  private List<Integer> firmLevelAccessResourceIds() {
    return resourceRepository.findAll((root, query, cb) ->
            cb.equal(root.get("name"), Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS))
        .stream()
        .map(resource -> Math.toIntExact(resource.getResourceId()))
        .toList();
  }

  private UsersResponse findUsersByIdpSubjects(Set<String> idpSubjects, String firmId) {
    if (idpSubjects.isEmpty()) {
      return emptyUsersResponse();
    }
    Specification<UserConfigSearchMaterializedView> spec = idpSubjectIn(idpSubjects);
    if (firmId != null) {
      spec = spec.and(firmIs(firmId));
    }
    return findUsers(spec);
  }

  // Applied here rather than at each call site so no user query can skip the NBX exclusion.
  private UsersResponse findUsers(Specification<UserConfigSearchMaterializedView> spec) {
    List<UserConfiguration> users =
        userConfigSearchMaterializedViewRepository.findAll(spec.and(notNbxUser())).stream()
            .map(SpecialInquiriesMapper::toUserConfiguration)
            .toList();

    UsersResponse response = new UsersResponse();
    response.setUsers(users);
    return response;
  }

  private static UsersResponse emptyUsersResponse() {
    UsersResponse response = new UsersResponse();
    response.setUsers(List.of());
    return response;
  }

  private static Specification<UserConfigSearchMaterializedView> firmIs(String firmId) {
    return (root, query, cb) -> cb.equal(root.get("firmId"), firmId);
  }

  private static Specification<UserConfigSearchMaterializedView> isActive() {
    return (root, query, cb) -> cb.isTrue(root.get("active"));
  }

  private static Specification<UserConfigSearchMaterializedView> idpSubjectIn(
      Collection<String> idpSubjects) {
    return (root, query, cb) -> root.get("idpSubject").in(idpSubjects);
  }

  private static Specification<UserConfigSearchMaterializedView> firmEntityIdIn(
      Collection<Long> firmEntityIds) {
    return (root, query, cb) -> root.get("firmEntityId").in(firmEntityIds);
  }

  /**
   * Excludes NBX-only users, which carry {@code source = 'nbx'} while every other user leaves it
   * null. Mirrors {@code addingNbxUserFilter} (SOURCE_NOT_NBX / IS_NULL) that
   * {@code genericSearchWithPagination} applies unconditionally in cx-fum-user-configuration-api.
   */
  private static Specification<UserConfigSearchMaterializedView> notNbxUser() {
    return (root, query, cb) -> cb.isNull(root.get("source"));
  }

  private void requireFirm(String firmId) {
    if (firmRepository.findByFirmId(firmId) == null) {
      throw new FumNotFoundException(Constants.FIRM_NOT_FOUND, Constants.FIRM_NOT_FOUND_MESSAGE);
    }
  }

  private void requireResource(String resourceName) {
    resourceRepository.findFirstByName(resourceName)
        .orElseThrow(() -> new FumNotFoundException(Constants.RESOURCE_NOT_FOUND,
            String.format(Constants.RESOURCE_NOT_FOUND_MESSAGE, resourceName)));
  }

  // NAME is unique: a versioned role resolves only its own template, never its other versions.
  private PackageTemplate requireUserPackage(String userPackageName) {
    PackageTemplate packageTemplate = packageTemplateRepository.findByName(userPackageName)
        .orElseThrow(() -> new FumNotFoundException(Constants.USER_PACKAGE_NOT_FOUND,
            String.format(Constants.USER_PACKAGE_NOT_FOUND_MESSAGE, userPackageName)));

    if (packageTemplate.getType() != PackageType.U) {
      throw new FumValidationException(Constants.USER_PACKAGE_NOT_USER_TYPE,
          String.format(Constants.USER_PACKAGE_NOT_USER_TYPE_MESSAGE, userPackageName));
    }
    return packageTemplate;
  }

  // Validated before decoding: the decoder silently mis-reads any character outside A-Z / 0-9.
  private static Set<String> requireRrCodes(List<String> rrCodes) {
    if (rrCodes == null || rrCodes.isEmpty()) {
      throw new FumValidationException(Constants.RR_CODES_EMPTY, Constants.RR_CODES_EMPTY_MESSAGE);
    }
    if (rrCodes.size() > MAX_RR_CODES) {
      throw new FumValidationException(Constants.RR_CODES_TOO_MANY,
          String.format(Constants.RR_CODES_TOO_MANY_MESSAGE, MAX_RR_CODES));
    }

    Set<String> normalizedRrCodes = new LinkedHashSet<>();
    for (String rrCode : rrCodes) {
      String candidate = rrCode == null ? "" : rrCode.strip();
      if (!RR_CODE_PATTERN.matcher(candidate).matches()) {
        throw new FumValidationException(Constants.RR_CODE_INVALID,
            String.format(Constants.RR_CODE_INVALID_MESSAGE, StringUtils.abbreviate(rrCode, 20)));
      }
      normalizedRrCodes.add(candidate.toUpperCase(Locale.ROOT));
    }
    return normalizedRrCodes;
  }

  private static FirmType toFirmType(String firmType) {
    try {
      return FirmType.valueOf(firmType);
    } catch (IllegalArgumentException e) {
      throw new FumValidationException(Constants.FIRM_TYPE_INVALID,
          String.format(Constants.FIRM_TYPE_INVALID_MESSAGE, firmType));
    }
  }

  private static Firm toFirm(ca.bnc.wealth.common.jpa.entity.iam.Firm firmEntity) {
    Firm firm = new Firm();
    firm.setFirmId(firmEntity.getFirmId());
    firm.setName(firmEntity.getName());
    firm.setType(Optional.ofNullable(firmEntity.getFirmType()).map(Enum::name).orElse(null));
    firm.setDescription(firmEntity.getDescription());
    firm.setPreferredLanguage(
        Optional.ofNullable(firmEntity.getPreferredLanguageType()).map(Enum::name).orElse(null));
    firm.setActive(firmEntity.getActive());
    return firm;
  }
}
