package ca.bnc.wealth.api.user.service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import ca.bnc.wealth.api.user.model.EnumApplicationId;
import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.common.r2.model.R2UserProfile;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class UserExtractService {

  public static final String GET_USER_FROM_MV_BY_CONF_ID_QUERY =
      """
          select
           "USER_CONFIGURATION_ID", "IDP_SUBJECT", "IDP_USER_ID", "FIRM_ID", "FIRM_NAME", "FIRST_NAME", "LAST_NAME", "EMAIL", "USERNAME", "IS_FIRM_SCOPE", "RR_RANGES", "BNGF_REFERENCE_ID"
          from
            "IAM_V2"."USER_CONFIGURATION_LIVE"
          """;
  public static final String ORDER_BY = "  order by \"FIRM_ID\", \"FIRST_NAME\" , \"LAST_NAME\"";

  public static final String GET_FIRM_WITH_IDENTITY_SOURCE_QUERY = """
         select * from "IAM_V2"."FIRM" where "IDENTITY_SOURCE" is not null
      """;

  public static final String GET_CX_USER_LAST_LOGIN_QUERY = """
         select "IDP_SUBJECT", "LAST_LOGIN_DATE" from "IAM_V2"."USER_CONFIGURATION"  where "IDP_SUBJECT" in (:idp_subjects)
      """;
  @Qualifier("readJdbcTemplate")
  private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

  private final ExternalClientService externalClientService;

  @Value("${user.management.extract.chunkSize:100}")
  private int chunkSize;

  @Value("${user.management.extract.timeBetweenChunkExec:60000}")
  private int timeBetweenChunkExec;

  @Value("${user.management.extract.disableDelay:true}")
  private boolean disableDelay;


  public List<Map<String, String>> getUserExtractData(String firmId, Map<String, Map<String, Map<String, String>>> securityZoneData, String uuid) {

    List<Map<String, String>> cxUserList = getCxUserData(firmId);

    updateExternalIdAndLastCxLogin(cxUserList, uuid);

    return updateSecurityZoneData(cxUserList, securityZoneData);
  }

  private List<Map<String, String>> updateSecurityZoneData(List<Map<String, String>> cxUserList, Map<String, Map<String, Map<String, String>>> securityZoneData) {
    List<Map<String, String>> userExtractDataList = new ArrayList<>();
    cxUserList.forEach(
        userMap -> {
          String secureZoneId = userMap.get(Constants.SECURE_ZONE_ID);
          if (StringUtils.isNotBlank(secureZoneId)) {
            String[] secureZoneIds = secureZoneId.trim().split(",");
            for (String secZoneId : secureZoneIds) {
              Map<String, String> userExtractData = new HashMap<>(userMap);

              String trimmedSecZoneId = secZoneId.trim();

              List<String> lst = getSecurityZoneDataByApplicationIdAndSecurityZone(EnumApplicationId.GDI, trimmedSecZoneId, securityZoneData);
              addGDI(userExtractData, lst);

              lst = getSecurityZoneDataByApplicationIdAndSecurityZone(EnumApplicationId.ML, trimmedSecZoneId, securityZoneData);
              addMl(userExtractData, lst);

              lst = getSecurityZoneDataByApplicationIdAndSecurityZone(EnumApplicationId.WP, trimmedSecZoneId, securityZoneData);
              addWP(userExtractData, lst);

              lst = getSecurityZoneDataByApplicationIdAndSecurityZone(EnumApplicationId.CRM, trimmedSecZoneId, securityZoneData);
              addCRM(userExtractData, lst);

              lst = getSecurityZoneDataByApplicationIdAndSecurityZone(EnumApplicationId.CI, trimmedSecZoneId, securityZoneData);
              addCI(userExtractData, lst);

              lst = getSecurityZoneDataByApplicationIdAndSecurityZone(EnumApplicationId.DC, trimmedSecZoneId, securityZoneData);
              addDc(userExtractData, lst);

              userExtractDataList.add(userExtractData);
            }
          } else {
            userExtractDataList.add(userMap);
          }
        });
    return userExtractDataList;
  }

  private void addDc(Map<String, String> userExtractData, List<String> lst) {
    userExtractData.put(Constants.ATTESTATION_HEADER_MY_PORTFOLIO_PLUS_USER_ID, lst.get(0));
    userExtractData.put(Constants.ATTESTATION_HEADER_MY_PORTFOLIO_PLUS_RR_CODE, lst.get(1));
    userExtractData.put(Constants.ATTESTATION_HEADER_MY_PORTFOLIO_PLUS_USER_CREATED, lst.get(2));
    userExtractData.put(Constants.ATTESTATION_HEADER_MY_PORTFOLIO_PLUS_USER_LAST_LOGIN, lst.get(3));
  }

  private void addCI(Map<String, String> userExtractData, List<String> lst) {
    userExtractData.put(Constants.ATTESTATION_HEADER_SERVICING_IMOST_INTERVENTIONS_USER_ID, lst.get(0));
    userExtractData.put(Constants.ATTESTATION_HEADER_SERVICING_IMOST_INTERVENTIONS_RR_CODE, lst.get(1));
    userExtractData.put(Constants.ATTESTATION_HEADER_SERVICING_IMOST_INTERVENTIONS_USER_CREATED, lst.get(2));
    userExtractData.put(Constants.ATTESTATION_HEADER_SERVICING_IMOST_INTERVENTIONS_USER_LAST_LOGIN, lst.get(3));
  }

  private void addCRM(Map<String, String> userExtractData, List<String> lst) {
    userExtractData.put(Constants.ATTESTATION_HEADER_CREDIT_RISK_USER_ID, lst.get(0));
    userExtractData.put(Constants.ATTESTATION_HEADER_CREDIT_RISK_RR_CODE, lst.get(1));
    userExtractData.put(Constants.ATTESTATION_HEADER_CREDIT_RISK_USER_CREATED, lst.get(2));
    userExtractData.put(Constants.ATTESTATION_HEADER_CREDIT_RISK_USER_LAST_LOGIN, lst.get(3));
  }

  private void addWP(Map<String, String> userExtractData, List<String> lst) {
    userExtractData.put(Constants.ATTESTATION_HEADER_WEB_PANAGAN_USER_ID, lst.get(0));
    userExtractData.put(Constants.ATTESTATION_HEADER_WEB_PANAGAN_RR_CODE, lst.get(1));
    userExtractData.put(Constants.ATTESTATION_HEADER_WEB_PANAGAN_USER_CREATED, lst.get(2));
    userExtractData.put(Constants.ATTESTATION_HEADER_WEB_PANAGAN_USER_LAST_LOGIN, lst.get(3));
  }

  private void addMl(Map<String, String> userExtractData, List<String> lst) {
    userExtractData.put(Constants.ATTESTATION_HEADER_MAX_LITE_USER_ID, lst.get(0));
    userExtractData.put(Constants.ATTESTATION_HEADER_MAX_LITE_RR_CODE, lst.get(1));
    userExtractData.put(Constants.ATTESTATION_HEADER_MAX_LITE_USER_CREATED, lst.get(2));
    userExtractData.put(Constants.ATTESTATION_HEADER_MAX_LITE_USER_LAST_LOGIN, lst.get(3));
  }

  private void addGDI(Map<String, String> userExtractData, List<String> lst) {
    userExtractData.put(Constants.ATTESTATION_HEADER_SERVICING_IMOST_INSTRUCTIONS_USER_ID, lst.get(0));
    userExtractData.put(Constants.ATTESTATION_HEADER_SERVICING_IMOST_INSTRUCTIONS_RR_CODE, lst.get(1));
    userExtractData.put(Constants.ATTESTATION_HEADER_SERVICING_IMOST_INSTRUCTIONS_USER_CREATED, lst.get(2));
    userExtractData.put(Constants.ATTESTATION_HEADER_SERVICING_IMOST_INSTRUCTIONS_USER_LAST_LOGIN, lst.get(3));
  }

  private List<String> getSecurityZoneDataByApplicationIdAndSecurityZone(EnumApplicationId enumApplicationId, String secZoneId, Map<String, Map<String, Map<String, String>>> securityZoneData) {
    List<String> lst = new ArrayList<>();
    if (securityZoneData.containsKey(enumApplicationId.name())
        && securityZoneData.get(enumApplicationId.name()).containsKey(secZoneId)) {
      Map<String, String> secZoneData =
          securityZoneData.get(enumApplicationId.name()).get(secZoneId);
      lst.add(secZoneData.getOrDefault(Constants.USER_ID, ""));
      lst.add(secZoneData.getOrDefault(Constants.IA_ACCESS, ""));
      lst.add(secZoneData.getOrDefault(Constants.USER_EFFECTIVE_DATE, ""));
      lst.add(secZoneData.getOrDefault(Constants.USER_LAST_LOGIN, ""));
      return lst;
    } else {
      return List.of("", "", "", "");
    }
  }

  private void updateExternalIdAndLastCxLogin(List<Map<String, String>> userExtractData, String uuid) {
    ListUtils.partition(userExtractData, chunkSize).stream()
        .peek(list -> this.waitForNextExec())
        .forEach(chunk -> {
          List<String> idpSubjects = chunk.stream().map(map -> map.get(Constants.IDP_SUBJECT)).toList();

          Map<String, String> idpSubjectAndLastLogin = getIdpSubjectAndLastLogin(idpSubjects);
          Map<String, R2UserProfile> r2UserProfileMap = Optional.ofNullable(externalClientService.getR2UserProfiles(idpSubjects, uuid)).orElse(new HashMap<>());

          chunk.forEach(userMap -> {
            String idpSubject = userMap.get(Constants.IDP_SUBJECT);
            userMap.put(Constants.ATTESTATION_HEADER_COMPASS_LAST_LOGIN, StringUtils.isNotBlank(idpSubjectAndLastLogin.get(idpSubject)) ? idpSubjectAndLastLogin.get(idpSubject) : "");

            R2UserProfile r2UserProfile = r2UserProfileMap.get(idpSubject);
            updateR2Details(userMap, r2UserProfile);
            userMap.put(Constants.SECURE_ZONE_ID, externalClientService.getSecureZoneId(userMap.get(Constants.IDP_USER_ID), uuid));
          });
        });
  }

  private void updateR2Details(Map<String, String> userMap, R2UserProfile r2UserProfile) {
    if (r2UserProfile != null) {
      userMap.put(Constants.ATTESTATION_HEADER_COMPASS_LEGACY_USER_ID, StringUtils.isNotBlank(r2UserProfile.getUserId()) ? r2UserProfile.getUserId() : "");
      userMap.put(Constants.ATTESTATION_HEADER_COMPASS_LEGACY_USER_EMAIL, StringUtils.isNotBlank(r2UserProfile.getEmail()) ? r2UserProfile.getEmail() : "");
      userMap.put(Constants.ATTESTATION_HEADER_COMPASS_LEGACY_RR_CODE, CollectionUtils.isNotEmpty(r2UserProfile.getRrCodes()) ? String.join(",", r2UserProfile.getRrCodes()) : "");
      userMap.put(Constants.ATTESTATION_HEADER_COMPASS_LEGACY_SUB_ADVISER_RR_CODE, CollectionUtils.isNotEmpty(r2UserProfile.getSubAdviseRrCodes()) ? String.join(",", r2UserProfile.getSubAdviseRrCodes()) : "");
    } else {
      userMap.put(Constants.ATTESTATION_HEADER_COMPASS_LEGACY_USER_ID, "");
      userMap.put(Constants.ATTESTATION_HEADER_COMPASS_LEGACY_USER_EMAIL, "");
      userMap.put(Constants.ATTESTATION_HEADER_COMPASS_LEGACY_RR_CODE, "");
      userMap.put(Constants.ATTESTATION_HEADER_COMPASS_LEGACY_SUB_ADVISER_RR_CODE, "");
    }
  }

  private Map<String, String> getIdpSubjectAndLastLogin(List<String> idpSubjects) {
    Map<String, String> idpSubjectAndLastLogin = new HashMap<>();
    if (idpSubjects.isEmpty()) {
      return idpSubjectAndLastLogin;
    }
    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("idp_subjects", idpSubjects);
    log.info("getIdpSubjectAndLastLogin # query: {}", GET_CX_USER_LAST_LOGIN_QUERY);
    log.info("getIdpSubjectAndLastLogin # parameters: {}", parameters);
    List<Map<String, Object>> userList = namedParameterJdbcTemplate.queryForList(GET_CX_USER_LAST_LOGIN_QUERY, parameters);
    userList.forEach(map -> {
      String idpSubject = getStringValue(map.get("IDP_SUBJECT"));
      LocalDateTime lastLogin = getLocalDateTimeValue(map.get("LAST_LOGIN_DATE"));
      idpSubjectAndLastLogin.put(idpSubject, lastLogin != null ? lastLogin.toString() : "");
    });
    return idpSubjectAndLastLogin;
  }

  private List<Map<String, String>> getCxUserData(String firmId) {
    List<Map<String, String>> cxUserData = new ArrayList<>();

    Map<String, String> firmIdAndIdentitySource = getFirmIdAndIdentitySource();

    StringBuilder query = new StringBuilder(GET_USER_FROM_MV_BY_CONF_ID_QUERY);
    MapSqlParameterSource userParameters = new MapSqlParameterSource();

    query.append(" where \"STATE_DESCRIPTION\" not in ('Deleted', 'Suspended') ");

    if (!"NBIN".equalsIgnoreCase(firmId)) {
      query.append(" and \"FIRM_ID\" = :firmId ");
      userParameters.addValue("firmId", firmId);
    }

    query.append(ORDER_BY);
    log.info("getUserData # query: {}", query);
    log.info("getUserData # userParameters: {}", userParameters);
    List<Map<String, Object>> userList = namedParameterJdbcTemplate.queryForList(query.toString(), userParameters);

    userList.forEach(map -> {
      Map<String, String> userMap = new HashMap<>();

      String currentFirmId = getStringValue(map.get("FIRM_ID"));
      userMap.put(Constants.USER_CONFIGURATION_ID, getStringValue(map.get("USER_CONFIGURATION_ID")));
      userMap.put(Constants.IDP_SUBJECT, getStringValue(map.get("IDP_SUBJECT")));
      userMap.put(Constants.IDP_USER_ID, getStringValue(map.get("IDP_USER_ID")));
      // Firm Information
      userMap.put(Constants.ATTESTATION_HEADER_FIRM_ID, currentFirmId);
      userMap.put(Constants.ATTESTATION_HEADER_FIRM_NAME, getStringValue(map.get("FIRM_NAME")));

      // Identity Information
      userMap.put(Constants.ATTESTATION_HEADER_IDENTITY_NAME, String.join(" ", getStringValue(map.get("FIRST_NAME")), getStringValue(map.get("LAST_NAME"))).trim());
      userMap.put(Constants.ATTESTATION_HEADER_IDENTITY_EMAIL, getStringValue(map.get("EMAIL")));

      String bngfReferenceId = getStringValue(map.get("BNGF_REFERENCE_ID"));
      if (bngfReferenceId != null && firmIdAndIdentitySource.containsKey(currentFirmId) && bngfReferenceId.startsWith(firmIdAndIdentitySource.get(currentFirmId))) {
        String externalClientId = bngfReferenceId.replace(firmIdAndIdentitySource.get(currentFirmId) + "_", "");
        userMap.put(Constants.ATTESTATION_HEADER_IDENTITY_SSO_USER_ID, externalClientId);
      } else {
        userMap.put(Constants.ATTESTATION_HEADER_IDENTITY_SSO_USER_ID, "");
      }

      // Compass Information
      userMap.put(Constants.ATTESTATION_HEADER_COMPASS_USER_ID, getStringValue(map.get("USERNAME")));
      userMap.put(Constants.ATTESTATION_HEADER_COMPASS_FIRM_LEVEL_ACCESS, getStringValue(map.get("IS_FIRM_SCOPE")));
      userMap.put(Constants.ATTESTATION_HEADER_COMPASS_RR_CODE, getStringValue(map.get("RR_RANGES")));

      cxUserData.add(userMap);
    });
    return cxUserData;
  }

  private Map<String, String> getFirmIdAndIdentitySource() {
    Map<String, String> firmIdAndName = new HashMap<>();
    namedParameterJdbcTemplate.queryForList(GET_FIRM_WITH_IDENTITY_SOURCE_QUERY, new MapSqlParameterSource())
        .forEach(map -> {
          String firmId = getStringValue(map.get("FIRM_ID"));
          String identitySource = getStringValue(map.get("IDENTITY_SOURCE"));
          if (StringUtils.isNotBlank(firmId) && StringUtils.isNotBlank(identitySource)) {
            firmIdAndName.put(firmId, identitySource);
          }
        });
    return firmIdAndName;
  }

  private String getStringValue(Object object) {
    return object != null ? object.toString() : null;
  }

  private LocalDateTime getLocalDateTimeValue(Object object) {
    return object != null ? ((Timestamp) object).toLocalDateTime() : null;
  }

  @SneakyThrows
  private void waitForNextExec() {
    if (disableDelay) {
      return;
    }
    log.info("Waiting for " + timeBetweenChunkExec + " millsecond before starting next chunk");
    Thread.sleep(timeBetweenChunkExec);
    log.info("will start the next chunk of records");
  }
}
