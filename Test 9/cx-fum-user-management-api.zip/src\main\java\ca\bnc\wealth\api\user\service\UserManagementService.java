package ca.bnc.wealth.api.user.service;


import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.fum.service.UserSearchViewRefreshService;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import ca.bnc.wealth.common.jpa.specification.Specification;

import java.util.*;
import java.util.regex.Pattern;


@Service
@Slf4j
@RequiredArgsConstructor
public class UserManagementService {


    private final FirmRepository firmRepository;
    private final IamUserConfigurationRepository iamUserConfigurationRepository;
    private final IamRrCodeRangeRepository iamRrCodeRangeRepository;
    private final UserSearchViewRefreshService userSearchViewRefreshService;


    private static final String FIRM_ID = "firmId";


    public boolean validateRrCodeByFirmId(String firmId, List<String> rrCodeRangeList) {
        // Check if firm exists
        if(getFirm(firmId)==null) {
            throw new FumValidationException(Constants.FIRM_NOT_FOUND,
                    Constants.FIRM_NOT_FOUND_MESSAGE);
        }

        List<String> uniqueRrCodeRangesList = getUniqueRrCodeRangeList(rrCodeRangeList);
        List<String> invalidRrCodeRanges = uniqueRrCodeRangesList.stream()
                .filter(rrCode -> !isValidRrCodeRangeByFirm(firmId, rrCode))
                .toList();

        return invalidRrCodeRanges.isEmpty();
    }

    public boolean validateRrCodeByUser(String idpSubject, List<String> rrCodeRangeList) {

        // Check if user exists
        IamUserConfiguration checkUser = getUser(idpSubject).orElse(null);
        if(checkUser == null) {
            return false;
        }

        List<String> uniqueRrCodeRangesList = getUniqueRrCodeRangeList(rrCodeRangeList);
        List<String> invalidRrCodeRanges = uniqueRrCodeRangesList.stream()
                .filter(rrCode -> !isValidRrCodeRangeByUser(idpSubject, rrCode))
                .toList();

        return invalidRrCodeRanges.isEmpty();
    }

    public List<String> getUniqueRrCodeRangeList(List<String> rrCodeRangeList){
        if (rrCodeRangeList == null) {
            log.warn("RRCODE_INPUT_VALIDATION_FAILURE: reason=empty_input");
            throw new FumValidationException(Constants.FIRM_RRCODE_EMPTY,
                    Constants.FIRM_RRCODE_EMPTY_MESSAGE);
        }

        // Removing all blank values
        rrCodeRangeList = rrCodeRangeList.stream()
                .filter(s -> s != null && !s.replaceAll("\\s", "").isEmpty())
                .toList();
        if (CollectionUtils.isEmpty(rrCodeRangeList)) {
            log.warn("RRCODE_INPUT_VALIDATION_FAILURE: reason=empty_input");
            throw new FumValidationException(Constants.FIRM_RRCODE_EMPTY,
                    Constants.FIRM_RRCODE_EMPTY_MESSAGE);
        }

        Pattern pattern = Pattern.compile(Constants.RRCODE_REGEX);
        String[] rrCodeRanges = String.join(",", rrCodeRangeList).replaceAll("\\s", "").split(",");
        List<String> invalidRrCodesFormat = Arrays.stream(rrCodeRanges)
                .filter(StringUtils::isNotBlank)
                .filter(rrCode -> !pattern.matcher(rrCode).matches())
                .toList();

        if (!invalidRrCodesFormat.isEmpty()) {
            log.warn("RRCODE_INPUT_VALIDATION_FAILURE: reason=invalid_format, invalidValues={}", invalidRrCodesFormat);
            throw new FumValidationException(Constants.FIRM_RRCODE_INVALID_FORMAT,
                    String.join(",", invalidRrCodesFormat));
        }

        // Removing duplicate values
        Set<String> uniqueRrCodeRanges = new HashSet<>();

        return Arrays.stream(rrCodeRanges)
                .filter(uniqueRrCodeRanges::add)
                .toList();
    }


    private boolean isValidRrCodeRangeByFirm(String firmId, String rrCode) {
        String[] rrCodes = rrCode.split("-");
        String rrCodeFrom = rrCodes[0];
        String rrCodeTo = rrCodes.length == 2 ? rrCodes[1] : rrCodes[0];
        Boolean isValid = firmRepository.validRrCodeRangeForFirmId(firmId.toUpperCase(), rrCodeFrom.toUpperCase(), rrCodeTo.toUpperCase());
        return isValid != null && isValid;
    }

    public boolean isValidRrCodeRangeByUser(String idpSubject, String rrCode) {
        String[] rrCodes = rrCode.split("-");
        String rrCodeFrom = rrCodes[0];
        String rrCodeTo = rrCodes.length == 2 ? rrCodes[1] : rrCodes[0];

        Boolean isValid = iamRrCodeRangeRepository.validRrCodeRangeForUser(idpSubject, rrCodeFrom.toUpperCase(), rrCodeTo.toUpperCase());
        return isValid != null && isValid;
    }

    public Firm getFirm(String firmId){
        Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap = new HashMap<>();
        fieldValueMap.put(FIRM_ID,Pair.of(EnumQueryCriteria.EQUALS, firmId));
        Specification<Firm> spec =
                new Specification<>(fieldValueMap);
        List<Firm> lst = this.firmRepository.findAll(spec);
        if(CollectionUtils.isEmpty(lst)){
            return null;
        }
        return lst.get(0);
    }

    public Optional<IamUserConfiguration> getUser(String userId){
        return (iamUserConfigurationRepository.findFirstByIdpSubject(userId));
    }

    public void refreshUserSearchMaterializedView() {
        userSearchViewRefreshService.refreshNow(false);
    }
}
