package ca.bnc.wealth.api.user.utils;

import ca.bnc.wealth.common.employee.user_management.model.EmployeeAssignment;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeLinkedProfiles;
import ca.bnc.wealth.common.employee.user_management.model.EmployeePackage;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeProfile;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeUserConfiguration;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeUserConfiguration.LanguageEnum;
import ca.bnc.wealth.common.employee.user_management.model.OssProfile;
import ca.bnc.wealth.common.fum.model.UserPreferencesEnum;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.Person;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackageAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentFeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.util.CollectionUtils;

public class ApiMapper {

  private ApiMapper() {
  }

  public static EmployeeUserConfiguration toEmployeeDto(Person person, IamUserConfiguration userConfig) {
    EmployeeUserConfiguration dto = new EmployeeUserConfiguration();

    if (person != null) {
      dto.setFirstName(person.getFirstName());
      dto.setLastName(person.getLastName());
      dto.setEmail(person.getEmail());
      dto.setLanguage(person.getLanguage() != null
          ? LanguageEnum.fromValue(person.getLanguage().name()) : null);
    } else {
      dto.setFirstName(userConfig.getFirstName());
      dto.setLastName(userConfig.getLastName());
      dto.setEmail(userConfig.getEmail());
      dto.setLanguage(userConfig.getPreferredLanguageType() != null
          ? LanguageEnum.fromValue(userConfig.getPreferredLanguageType().name()) : null);
    }

    EmployeeProfile profile = new EmployeeProfile();
    profile.setShortId(userConfig.getUsername());
    profile.setDefaultModule(userConfig.getUserPreferences() != null ?
        userConfig.getUserPreferences().get(UserPreferencesEnum.defaultModule.name()) : null);
    profile.setActive(userConfig.getActive());
    profile.setLastLogin(userConfig.getLastLoginDate() != null
        ? userConfig.getLastLoginDate().toLocalDateTime() : null);
    dto.setProfile(profile);

    return dto;
  }

  public static EmployeeLinkedProfiles toLinkedProfiles(IamUserConfiguration userConfig) {
    EmployeeLinkedProfiles linkedProfiles = new EmployeeLinkedProfiles();

    OssProfile ossProfile = new OssProfile();
    ossProfile.setUserId(userConfig.getOssUserId());
    ossProfile.setGroupId(userConfig.getOssGroupId());
    linkedProfiles.setOss(ossProfile);

    return linkedProfiles;
  }

  public static EmployeeAssignment toAssignment(IamUserConfiguration userConfig) {
    EmployeeAssignment assignment = new EmployeeAssignment();

    if (userConfig.getUserAssignmentFirms() != null) {
      // UserAssignmentFirm shares the USER_ASSIGNMENT table with every other assignment type
      // (R, P, F, S, G) and the collection is not type-filtered, so it returns EVERY row. Only
      // type-F rows carry a firm; taking get(0) blindly could pick a non-firm row whose
      // ASSIGNEE_ID does not resolve to a Firm, leaving firm null. Filter to type F.
      userConfig.getUserAssignmentFirms().stream()
          .filter(uaf -> uaf.getAssignmentType() == UserAssignmentType.F && uaf.getFirm() != null)
          .map(uaf -> uaf.getFirm().getFirmId())
          .findFirst()
          .ifPresent(assignment::setFirm);
    }

    if (userConfig.getUserAssignmentRrCodeRanges() != null) {
      List<String> rrcodes = userConfig.getUserAssignmentRrCodeRanges().stream()
          .filter(rr -> rr.getAssignmentType() == UserAssignmentType.R && rr.getIamRrCodeRange() != null)
          .map(rr -> {
            String from = rr.getIamRrCodeRange().getFromRrCode();
            String to = rr.getIamRrCodeRange().getToRrCode();
            return from != null && to != null && !from.equals(to) ? from + "-" + to : from;
          })
          .toList();
      assignment.setRrcodes(rrcodes);
    }

    if (userConfig.getUserAssignmentFeaturePackages() != null) {
      List<FeaturePackageAssignmentResource> allDetails =
          userConfig.getUserAssignmentFeaturePackages().stream()
              .filter(ua -> ua.getAssignmentType() == UserAssignmentType.P
                  && ua.getFeaturePackage() != null
                  && ua.getFeaturePackage().getFeaturePackageAssignmentResources() != null)
              .flatMap(ua -> ua.getFeaturePackage().getFeaturePackageAssignmentResources().stream())
              .filter(d -> d.getPackageTemplateAssignmentResource() != null
                  && d.getPackageTemplateAssignmentResource().getResource() != null)
              .toList();

      // All restricted resource names — used to exclude from regular resources.
      Set<String> allRestrictedNames = allDetails.stream()
          .filter(d -> Boolean.TRUE.equals(
              d.getPackageTemplateAssignmentResource().getResource().getRestriction()))
          .map(d -> d.getPackageTemplateAssignmentResource().getResource().getName())
          .filter(Objects::nonNull)
          .collect(Collectors.toSet());

      // Restricted resources surfaced to the caller (restricted && !selected).
      Set<String> restrictedResourceNames = allDetails.stream()
          .filter(d -> {
            boolean restricted = Boolean.TRUE.equals(
                d.getPackageTemplateAssignmentResource().getResource().getRestriction());
            boolean selected = d.isSelected();
            return restricted && !selected;
          })
          .map(d -> d.getPackageTemplateAssignmentResource().getResource().getName())
          .filter(Objects::nonNull)
          .collect(Collectors.toSet());

      // Regular resources (!restricted && selected), excluding any whose name matches
      // a restricted resource.
      List<String> resources = allDetails.stream()
          .filter(d -> {
            boolean restricted = Boolean.TRUE.equals(
                d.getPackageTemplateAssignmentResource().getResource().getRestriction());
            boolean selected = d.isSelected();
            return !restricted && selected;
          })
          .map(d -> d.getPackageTemplateAssignmentResource().getResource().getName())
          .filter(Objects::nonNull)
          .filter(name -> !allRestrictedNames.contains(name))
          .toList();
      assignment.setResources(resources);

      assignment.setRestrictedResources(new ArrayList<>(restrictedResourceNames));
    }

    return assignment;
  }

  public static EmployeePackage toPackage(String packageName) {
    EmployeePackage featurePackage = new EmployeePackage();
    featurePackage.setName(packageName);
    return featurePackage;
  }

  public static UserConfiguration toAuditUserConfiguration(IamUserConfiguration userConfig) {
    UserConfiguration uc = new UserConfiguration();
    if (userConfig == null) {
      return uc;
    }

    uc.setFirstName(userConfig.getFirstName());
    uc.setLastName(userConfig.getLastName());
    uc.setEmail(userConfig.getEmail());
    uc.setUsername(userConfig.getUsername());
    uc.setIdpSubject(userConfig.getIdpSubject());
    uc.setIdp(userConfig.getIdp());
    uc.setAccessProfileSet(userConfig.getAccessProfileSet());
    uc.setOssId(userConfig.getOssUserId());
    uc.setActive(userConfig.getActive() != null ? String.valueOf(userConfig.getActive()) : null);
    uc.setPreferredLanguage(userConfig.getPreferredLanguageType() != null
        ? userConfig.getPreferredLanguageType().name() : null);
    // Defensive copy: updateUserPreferences() mutates the entity's preferences map in place,
    // so a shared reference would let a later mutation leak into an earlier ("before") snapshot.
    uc.setUserPreferences(userConfig.getUserPreferences() != null
        ? new HashMap<>(userConfig.getUserPreferences()) : null);

    if (userConfig.getUserAssignmentFirms() != null) {
      // Filter to type-F rows: the collection returns every USER_ASSIGNMENT row regardless of
      // type, and only firm rows resolve to a Firm via ASSIGNEE_ID.
      userConfig.getUserAssignmentFirms().stream()
          .filter(uaf -> uaf.getAssignmentType() == UserAssignmentType.F && uaf.getFirm() != null)
          .map(uaf -> uaf.getFirm().getFirmId())
          .findFirst()
          .ifPresent(uc::setFirmId);
    }

    if (userConfig.getUserAssignmentRrCodeRanges() != null) {
      List<String> rrcodes = userConfig.getUserAssignmentRrCodeRanges().stream()
          .filter(rr -> rr.getIamRrCodeRange() != null)
          .map(rr -> {
            String from = rr.getIamRrCodeRange().getFromRrCode();
            String to = rr.getIamRrCodeRange().getToRrCode();
            return from != null && to != null && !from.equals(to) ? from + "-" + to : from;
          })
          .toList();
      uc.setRrCodes(rrcodes);
    }

    if (userConfig.getUserAssignmentResources() != null) {
      List<String> resources = userConfig.getUserAssignmentResources().stream()
          .filter(r -> r.getResource() != null)
          .map(r -> r.getResource().getName())
          .toList();
      uc.setResources(resources);
    }

    return uc;
  }

  public static RRCodeRange toRrCodeRangeDto(IamRrCodeRange rrCodeRange) {
    RRCodeRange dto = new RRCodeRange();
    dto.setRrCodeRangeId((int) rrCodeRange.getRrCodeRangeId());
    dto.setFromRRCode(rrCodeRange.getFromRrCode());
    dto.setToRRCode(rrCodeRange.getToRrCode());
    dto.setFromRRCodeB10((int) rrCodeRange.getFromRrCodeB10());
    dto.setToRRCodeB10((int) rrCodeRange.getToRrCodeB10());
    dto.setCreatedBy(rrCodeRange.getCreatedBy());
    dto.setLastUpdatedBy(rrCodeRange.getLastUpdatedBy());
    dto.setCreationDate(
        rrCodeRange.getCreationDate() != null
            ? rrCodeRange.getCreationDate().toLocalDateTime()
            : null);
    dto.setLastUpdatedDate(
        rrCodeRange.getLastUpdateDate() != null
            ? rrCodeRange.getLastUpdateDate().toLocalDateTime()
            : null);
    return dto;
  }

  /**
   * Derives featureSelections from feature package details: includes optional resources that are
   * either (not restricted and selected) or (restricted and not selected).
   */
  public static List<String> toFeatureSelections(
      List<FeaturePackageAssignmentResource> details) {
    if (CollectionUtils.isEmpty(details)) {
      return List.of();
    }

    return details.stream()
        .filter(d -> d.getPackageTemplateAssignmentResource() != null)
        .filter(d -> d.getPackageTemplateAssignmentResource().getAssignmentMode() == PackageAssignmentMode.O)
        .filter(d -> d.getPackageTemplateAssignmentResource().getResource() != null)
        .filter(d -> {
          boolean restricted = Boolean.TRUE.equals(
              d.getPackageTemplateAssignmentResource().getResource().getRestriction());
          boolean selected = d.isSelected();
          return (!restricted && selected) || (restricted && !selected);
        })
        .map(d -> d.getPackageTemplateAssignmentResource().getResource().getName())
        .filter(Objects::nonNull)
        .toList();
  }
}
