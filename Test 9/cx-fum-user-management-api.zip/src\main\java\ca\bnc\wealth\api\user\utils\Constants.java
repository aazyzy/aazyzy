package ca.bnc.wealth.api.user.utils;

import java.util.List;

public class Constants {
  public static final String USER_CONFIGURATION_ID = "User Configuration Id";
  public static final String IDP_SUBJECT = "IDP Subject";
  public static final String IDP_USER_ID = "IDP User Id";
  public static final String SECURE_ZONE_ID ="SecureZone ID";
  // Firm Information
  public static final String ATTESTATION_HEADER_FIRM_ID = "Firm Id";
  public static final String ATTESTATION_HEADER_FIRM_NAME = "Firm Name";
  // Identity Information
  public static final String ATTESTATION_HEADER_IDENTITY_NAME = "Name";
  public static final String ATTESTATION_HEADER_IDENTITY_EMAIL = "Email Address";
  public static final String ATTESTATION_HEADER_IDENTITY_SSO_USER_ID = "SSO User Id";
  // Compass Information
  public static final String ATTESTATION_HEADER_COMPASS_USER_ID = "Compass User Id";
  public static final String ATTESTATION_HEADER_COMPASS_LAST_LOGIN = "Compass Last Login";
  public static final String ATTESTATION_HEADER_COMPASS_FIRM_LEVEL_ACCESS = "Compass Firm Level Access";
  public static final String ATTESTATION_HEADER_COMPASS_RR_CODE = "Compass RR Code";
  // Compass Legacy Information
  public static final String ATTESTATION_HEADER_COMPASS_LEGACY_USER_ID = "Compass Legacy User Id";
  public static final String ATTESTATION_HEADER_COMPASS_LEGACY_USER_EMAIL = "Compass(Legacy) Email Address";
  public static final String ATTESTATION_HEADER_COMPASS_LEGACY_RR_CODE = "Compass(Legacy) RR Code";
  public static final String ATTESTATION_HEADER_COMPASS_LEGACY_SUB_ADVISER_RR_CODE = "Compass(Legacy) Sub-adviser RR Code";
  // iMOST Instructions Information
  public static final String ATTESTATION_HEADER_SERVICING_IMOST_INSTRUCTIONS_USER_ID = "Servicing User Id";
  public static final String ATTESTATION_HEADER_SERVICING_IMOST_INSTRUCTIONS_RR_CODE = "Servicing RR Code";
  public static final String ATTESTATION_HEADER_SERVICING_IMOST_INSTRUCTIONS_USER_CREATED = "Servicing User Created";
  public static final String ATTESTATION_HEADER_SERVICING_IMOST_INSTRUCTIONS_USER_LAST_LOGIN = "Servicing User Last Login";
  // iMOST Interventions Information
  public static final String ATTESTATION_HEADER_SERVICING_IMOST_INTERVENTIONS_USER_ID = "Servicing Approvals User Id";
  public static final String ATTESTATION_HEADER_SERVICING_IMOST_INTERVENTIONS_RR_CODE = "Servicing Approvals RR Code";
  public static final String ATTESTATION_HEADER_SERVICING_IMOST_INTERVENTIONS_USER_CREATED = "Servicing Approvals User Created";
  public static final String ATTESTATION_HEADER_SERVICING_IMOST_INTERVENTIONS_USER_LAST_LOGIN = "Servicing Approvals User Last Login";
  // MyPortfolioPlus Information
  public static final String ATTESTATION_HEADER_MY_PORTFOLIO_PLUS_USER_ID = "MyPortfolioPlus User Id";
  public static final String ATTESTATION_HEADER_MY_PORTFOLIO_PLUS_RR_CODE = "MyPortfolioPlus RR Code";
  public static final String ATTESTATION_HEADER_MY_PORTFOLIO_PLUS_USER_CREATED = "MyPortfolioPlus User Created";
  public static final String ATTESTATION_HEADER_MY_PORTFOLIO_PLUS_USER_LAST_LOGIN = "MyPortfolioPlus User Last Login";
  // Credit Risk Information
  public static final String ATTESTATION_HEADER_CREDIT_RISK_USER_ID = "Credit Risk User Id";
  public static final String ATTESTATION_HEADER_CREDIT_RISK_RR_CODE = "Credit Risk RR Code";
  public static final String ATTESTATION_HEADER_CREDIT_RISK_USER_CREATED = "Credit Risk User Created";
  public static final String ATTESTATION_HEADER_CREDIT_RISK_USER_LAST_LOGIN = "Credit Risk User Last Login";
  // MaxLite Information
  public static final String ATTESTATION_HEADER_MAX_LITE_USER_ID = "MaxLite User Id";
  public static final String ATTESTATION_HEADER_MAX_LITE_RR_CODE = "MaxLite RR Code";
  public static final String ATTESTATION_HEADER_MAX_LITE_USER_CREATED = "MaxLite User Created";
  public static final String ATTESTATION_HEADER_MAX_LITE_USER_LAST_LOGIN = "MaxLite User Last Login";
  // WebPanagan Information
  public static final String ATTESTATION_HEADER_WEB_PANAGAN_USER_ID = "WebPanagan User Id";
  public static final String ATTESTATION_HEADER_WEB_PANAGAN_RR_CODE = "WebPanagan RR Code";
  public static final String ATTESTATION_HEADER_WEB_PANAGAN_USER_CREATED = "WebPanagan User Created";
  public static final String ATTESTATION_HEADER_WEB_PANAGAN_USER_LAST_LOGIN = "WebPanagan User Last Login";

  public static final String APPLICATION_ID = "Application Id";
  public static final String USER_ID = "User Id";
  public static final String GIVEN_NAME = "Given Name";
  public static final String FAMILY_NAME = "Family Name";
  public static final String BROKER_ID = "Broker Id";
  public static final String BROKER_NAME = "Broker Name";
  public static final String FUNCTION = "Function";
  public static final String BROKER_ACCESS = "Broker Access";
  public static final String BRANCH_ACCESS = "Branch Access";
  public static final String IA_ACCESS = "IA Access";
  public static final String USER_EFFECTIVE_DATE = "User Effective Date";
  public static final String USER_END_DATE = "User End Date";
  public static final String USER_LAST_LOGIN = "User Last Login";
  public static final String REPORT_API_OBJECT_ATTESTATION = "Attestation_User_Data";
  public static final String REPORT_API_FUNCTION_S3_DOWNLOAD = "DOWNLOAD";
  public static final String REPORT_API_FUNCTION_S3_LS = "LS";
  public static final String REPORT_API_GET_LATEST_VERSION_ID = "GET_LATEST_VERSION_ID";
  public static final String REPORT_API_STARTS_WITH = "STARTS_WITH";
  public static final String S3_URI = "S3_URI";
  public static final String S3_URI_VERSION = "S3_URI_VERSION";
  public static final String SYSTEM_TOKEN_FUM = "fum";
  public static final String SECURITY_ZONE = "secureZone";
  public static final String FIRM_ATTESTATION_TEMPLATE_NAME = "FirmAttestation";
  public static final String ATTESTATION_ID_NOT_FOUND_CODE = "firm.attestation.id.notFound";
  public static final String ATTESTATION_ID_NOT_FOUND_MESSAGE = "Attestation not found for id: %s";
  public static final String ATTESTATION_STAGING_NOT_FOUND_CODE = "firm.attestationStaging.id.notFound";
  public static final String ATTESTATION_STAGING_NOT_FOUND_MESSAGE = "AttestationStaging not found for attestation id: %s and firm entity id: %s";
  public static final String ATTESTATION_SOURCE_DATA_NOT_FOUND_CODE = "firm.attestation.sourceData.notFound";
  public static final String ATTESTATION_SOURCE_DATA_NOT_FOUND_MESSAGE = "Attestation source data not found for attestationId: ";
  public static final String UNSUPPORTED_FIRM_TYPE_CODE = "firm.attestation.unsupportedFirmType";
  public static final String UNSUPPORTED_FIRM_TYPE_MESSAGE = "Unsupported firm type: %s";
  public static final String ATTESTATION_STAGING_INVALID_STATUS_CODE = "firm.attestation.staging.status.error";
  public static final String ATTESTATION_STAGING_INVALID_STATUS_MESSAGE = "AttestationFirmStaging is already in PROCESSING state for attestationId: %s and firmId: %s";
  public static final String ATTESTATION_INVALID_STATUS_CODE = "firm.attestation.status.error";
  public static final String ATTESTATION_INVALID_STATUS_MESSAGE = "Attestation is already in PROCESSING state for attestationId: %s";
  public static final String ERROR_USER_NOT_FOUND_CODE = "error.user.notFound";
  public static final String ERROR_USER_NOT_FOUND_MESSAGE = "User %s was not found";
  public static final String EMPLOYEE_EXISTS_CODE = "error.employee.uniqueConstraintViolation";
  public static final String EMPLOYEE_EXISTS_MESSAGE = "Employee with the same short ID already exists: %s";
  public static final String EMPLOYEE_PACKAGE_INVALID_CODE = "error.employee.package.invalid";
  public static final String EMPLOYEE_PACKAGE_INVALID_MESSAGE = "Employee package is invalid: %s";
  public static final String EMPLOYEE_FEATURE_SELECTION_INVALID_CODE =
      "error.employee.featureSelection.invalid";
  public static final String EMPLOYEE_FEATURE_SELECTION_INVALID_MESSAGE =
      "The following feature selection(s) do not belong to package '%s': %s";
  public static final String EMPLOYEE_REQUIRED_FIELD_CODE = "error.employee.requiredField";
  public static final String EMPLOYEE_REQUIRED_FIELD_MESSAGE = "Required field is missing: %s";
  public static final String EMPLOYEE_PATCH_SINGLE_FIELD_CODE = "error.employee.patch.singleField";
  public static final String EMPLOYEE_PATCH_SINGLE_FIELD_MESSAGE = "Exactly one field must be provided for PATCH";
  public static final String EMPLOYEE_EMAIL_DUPLICATE_CODE = "error.employee.email.duplicate";
  public static final String EMPLOYEE_EMAIL_DUPLICATE_MESSAGE = "Employee with the same email already exists: %s";
  public static final String EMPLOYEE_CONSTRAINT_VIOLATION_CODE =
      "error.employee.constraintViolation";
  public static final String EMPLOYEE_CONSTRAINT_VIOLATION_MESSAGE =
      "The request conflicts with an existing record";
  public static final String EMPLOYEE_DEFAULT_MODULE_CODE = "error.employee.profile.defaultModule";
  public static final String EMPLOYEE_DEFAULT_MODULE_MESSAGE = "Invalid default module value provided";
  // Default modules; the trailing empty string allows clearing a user's default module during validation.
  public static final List<String> DEFAULT_MODULES =
      List.of("firm_client_accounts", "users_module", "compass_r2", "");
  public static final String EMPLOYEE_LANGUAGE_CODE = "error.create.employee.language";
  public static final String EMPLOYEE_LANGUAGE_MESSAGE = "Invalid language";
  public static final String APPLICATION_CX = "CX";
  public static final String ATTESTATION_GENERATION_FAILED = "error.attestation.generation.failed";
  public static final String ATTESTATION_GENERATION_FAILED_MESSAGE = "Error occurred during attestation generation";
  public static final String FIRM_MISSING = "error.firm.notProvided";
  public static final String FIRM_MISSING_MESSAGE = "Firm was not provided";
  public static final String RRCODE_FIRM_MISSING_MESSAGE = "Firm must be provided to assign RR Codes";
  public static final String SYSTEM = "system";
  public static final String IDP_EMP = "IAMi";
  public static final String EMPLOYEE_EXTERNAL_USER_GROUP = "Wealth.CompassX.employee.external";
  public static final String RESOURCE_NAME_FIRM_LEVEL_ACCESS="firm_level_access";
  public static final String RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS="restrict_client_data_access";
  // Resources of this type are preserved (never unassigned) during feature package / resource reassignment.
  public static final String RESOURCE_TYPE_DWH_UI_MODULE = "dwh_ui_module";
  public static final String ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS = "error.restrictClientDataAccessAndFirmLevelAccess";
  public static final String ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS_MESSAGE = "This role does not allow access to client data ( Firm level access not allowed for this role)";
  public static final String ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE = "error.restrictClientDataAccessAndRRCode";
  public static final String ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE_MESSAGE = "This role does not allow access to client data ( RR Code assignments not allowed for this role)";
  public static final String EMPLOYEE_ASSIGNMENTS_FAILED = "error.employee.assignment.failed";
  public static final String EMPLOYEE_ASSIGNMENTS_FAILED_MESSAGE = "Unable to assign package and/or featureSelection";
  //RR-Code needed to be returned
  public static final String INTERNAL_RRCODE = "CNTA";

  //RR-Code Validation
  public static final String FIRM_NOT_FOUND = "error.firm.notFound";
  public static final String FIRM_NOT_FOUND_MESSAGE = "Firm not found";
  public static final String FIRM_RRCODE_EMPTY = "error.rrRange.empty";
  public static final String FIRM_RRCODE_EMPTY_MESSAGE = "RR range is empty";
  public static final String FIRM_RRCODE_INVALID_FORMAT = "error.rrRangeCode.invalidFormat";
  public static final String RRCODE_REGEX = "^[A-Z0-9]{4}(-[A-Z0-9]{4})?$";
  public static final String FIRM_RRCODE_INVALID_TOKEN = "error.invalid.rrRangeCode.token";
  public static final String FIRM_RRCODE_INVALID_TOKEN_MESSAGE = "Token is invalid";
  public static final String FIRM_RRCODE_INVALID_SYSTEM_TOKEN_FORMAT = "error.invalid.rrRangeCode.tokenFormat";
  public static final String FIRM_RRCODE_INVALID_SYSTEM_TOKEN_FORMAT_MESSAGE = "Token is invalid, missing EntityCode";
  public static final String FIRM_RRCODE_PARSE_TOKEN = "error.rrRangeCode.parse.token";
  public static final String FIRM_RRCODE_PARSE_TOKEN_MESSAGE = "Error parsing token";
  public static final String DEFAULT_ACTIVATION_DATE = "9999-09-09T00:00:00.000000";
  public static final String FIRM_RRCODE_INVALID = "error.invalid.rrRangeCode";
  public static final String FIRM_RRCODE_INVALID_MESSAGE = "RR Codes are invalid";

  //Special Inquiries
  public static final String FIRM_TYPE_INVALID = "error.firmType.invalid";
  public static final String FIRM_TYPE_INVALID_MESSAGE = "Invalid firm type: %s";
  public static final String RESOURCE_NOT_FOUND = "error.resource.notFound";
  public static final String RESOURCE_NOT_FOUND_MESSAGE = "Resource not found: %s";
  public static final String USER_PACKAGE_NOT_FOUND = "error.userPackage.notFound";
  public static final String USER_PACKAGE_NOT_FOUND_MESSAGE = "User package not found: %s";
  public static final String USER_PACKAGE_NOT_USER_TYPE = "error.userPackage.notUserType";
  public static final String USER_PACKAGE_NOT_USER_TYPE_MESSAGE =
      "Package %s is a firm package, not a user package";
  public static final String RR_CODES_EMPTY = "error.rrCodes.empty";
  public static final String RR_CODES_EMPTY_MESSAGE = "At least one RR code is required";
  public static final String RR_CODES_TOO_MANY = "error.rrCodes.tooMany";
  public static final String RR_CODES_TOO_MANY_MESSAGE = "At most %d RR codes are allowed per request";
  public static final String RR_CODE_INVALID = "error.rrCode.invalid";
  public static final String RR_CODE_INVALID_MESSAGE =
      "Invalid RR code: %s - an RR code is exactly 4 letters or digits";
  public static final String ERROR_OKTA_STATUS_UPDATE_CODE =
      "error.employee.okta.status.update.failed";
  public static final String ERROR_OKTA_STATUS_UPDATE_MESSAGE =
      "Unable to update the user status in Okta";
  public static final String ERROR_OKTA_STATUS_GET_CODE =
      "error.employee.okta.get.failed";
  public static final String ERROR_OKTA_STATUS_GET_MESSAGE =
      "Unable to get the user status in Okta";

  // Okta (IDP) profile statuses used to derive the local user state
  public static final String IDP_STATUS_ACTIVE = "ACTIVE";
  public static final String IDP_STATUS_SUSPENDED = "SUSPENDED";
  public static final String IDP_STATUS_LOCKED_OUT = "LOCKED_OUT";
  public static final String IDP_STATUS_PASSWORD_EXPIRED = "PASSWORD_EXPIRED";
  public static final String IDP_STATUS_DEPROVISIONED = "DEPROVISIONED";
  public static final String IDP_STATUS_PENDING_ACTIVATION = "PENDING_ACTIVATION";
  public static final String SMS = "sms";

  private Constants() {
    throw new IllegalStateException("Utility class");
  }
}
