package ca.bnc.wealth.api.user.utils;

import ca.bnc.wealth.common.fum.model.UserStatusEnum;
import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import ca.bnc.wealth.common.specialinquiries.user_management.model.UserConfiguration;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Optional;

/**
 * Mirrors {@code MapperUtils.toDto(UserConfigSearchMaterializedView)} in cx-fum-user-configuration-api
 * so the SpecialInquiries endpoints return the same user object as
 * {@code POST /user-conf/users/genericSearchWithPagination}. Keep the two in sync.
 */
public final class SpecialInquiriesMapper {

  private SpecialInquiriesMapper() {
    throw new IllegalStateException("Utility class");
  }

  public static UserConfiguration toUserConfiguration(UserConfigSearchMaterializedView view) {
    UserConfiguration userConfiguration = new UserConfiguration();

    Optional.ofNullable(view.getUserConfigurationId())
        .ifPresent(id -> userConfiguration.setUserConfigurationId(id.intValue()));
    userConfiguration.setIdpUserId(view.getIdpUserIdentifier());
    userConfiguration.setIdpSubject(view.getIdpSubject());
    userConfiguration.setIdp(view.getIdp());
    userConfiguration.setUsername(view.getUsername());
    // ossId / ossProxyId are deprecated aliases retained for parity with genericSearchWithPagination
    userConfiguration.setOssId(view.getOssUserId());
    userConfiguration.setOssProxyId(view.getOssGroupId());
    userConfiguration.setOssUserId(view.getOssUserId());
    userConfiguration.setOssGroupId(view.getOssGroupId());
    userConfiguration.setFirstName(view.getFirstName());
    userConfiguration.setLastName(view.getLastName());
    userConfiguration.setEmail(view.getEmail());

    String status = Boolean.TRUE.equals(view.getActive())
        ? UserStatusEnum.ACTIVE.dbValue
        : UserStatusEnum.INACTIVE.dbValue;
    userConfiguration.setStatus(status);
    userConfiguration.setActive(status);
    userConfiguration.setState(view.getState());
    userConfiguration.setStateDescription(view.getStateDescription());
    userConfiguration.setStateAction(view.getStateAction());

    Optional.ofNullable(view.getPreferredLanguageType())
        .ifPresent(language -> userConfiguration.setPreferredLanguage(language.name()));
    userConfiguration.setFirmId(view.getFirmId());
    userConfiguration.setUserGroup(view.getUserGroupName());
    userConfiguration.setUserGroupDescription(view.getUserGroupDescription());
    userConfiguration.setAccessProfileSet(view.getAccessProfileSet());
    userConfiguration.setSource(view.getSource());
    userConfiguration.setCreatedBy(view.getCreatedBy());
    userConfiguration.setLastUpdatedBy(view.getLastUpdatedBy());
    userConfiguration.setCreationDate(toLocalDateTime(view.getCreationDate()));
    userConfiguration.setLastUpdatedDate(toLocalDateTime(view.getLastUpdateDate()));

    return userConfiguration;
  }

  private static LocalDateTime toLocalDateTime(Timestamp timestamp) {
    return timestamp != null ? timestamp.toLocalDateTime() : null;
  }
}
