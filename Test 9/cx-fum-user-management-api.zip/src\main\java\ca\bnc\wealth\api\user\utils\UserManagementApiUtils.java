package ca.bnc.wealth.api.user.utils;

public class UserManagementApiUtils {
  public static String getFileNameFromS3Url(String s3Url) {
    if (s3Url == null || !s3Url.contains("/")) return s3Url;
    return s3Url.substring(s3Url.lastIndexOf('/') + 1);
  }
}
