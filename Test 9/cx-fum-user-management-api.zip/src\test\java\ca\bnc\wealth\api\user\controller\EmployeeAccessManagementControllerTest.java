package ca.bnc.wealth.api.user.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.eq;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.user.service.EmployeeAccessManagementService;
import ca.bnc.wealth.api.user.service.UserManagementService;
import ca.bnc.wealth.api.user.utils.MockData;
import ca.bnc.wealth.common.employee.user_management.model.CreateUserEmployee;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeGenericSearchResponse;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeUserConfiguration;
import ca.bnc.wealth.common.employee.user_management.model.PatchUserEmployee;
import ca.bnc.wealth.common.employee.user_management.model.UpdateUserEmployee;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

class EmployeeAccessManagementControllerTest {

  private EmployeeAccessManagementService service;
  private UserManagementService userManagementService;
  private EmployeeAccessManagementController controller;

  @BeforeEach
  void setUp() {
    service = mock(EmployeeAccessManagementService.class);
    userManagementService = mock(UserManagementService.class);
    controller = new EmployeeAccessManagementController(service, userManagementService);

    User mockUser = new User();
    mockUser.setIdpSubject("testUser");
    Authentication authentication = mock(Authentication.class);
    SecurityContext securityContext = mock(SecurityContext.class);

    when(authentication.getPrincipal()).thenReturn(mockUser);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
  }

  @Test
  void testGetEmployeesWithPagination() {
    EmployeeGenericSearchResponse searchResponse = new EmployeeGenericSearchResponse();
    when(service.getEmployeesWithPagination(anyInt(), anyInt())).thenReturn(searchResponse);

    ResponseEntity<EmployeeGenericSearchResponse> response =
        controller.getEmployeesWithPagination(50, 1);

    verify(service, times(1)).getEmployeesWithPagination(anyInt(), anyInt());
    assertEquals(200, response.getStatusCode().value());
    assertEquals(searchResponse, response.getBody());
  }

  @Test
  void testGetEmployeeUser() {
    String shortId = "raza002";
    EmployeeUserConfiguration config = new EmployeeUserConfiguration();
    when(service.getEmployeeUser(shortId)).thenReturn(config);

    ResponseEntity<EmployeeUserConfiguration> response = controller.getEmployeeUser(shortId);

    verify(service, times(1)).getEmployeeUser(shortId);
    assertEquals(200, response.getStatusCode().value());
    assertEquals(config, response.getBody());
  }

  @Test
  void testCreateEmployee() {
    CreateUserEmployee createUserEmployee = MockData.getCreateUserEmployee();
    doNothing().when(service).createEmployee(any(CreateUserEmployee.class), anyString());

    ResponseEntity<Void> response = controller.createEmployee(createUserEmployee);

    verify(service, times(1)).createEmployee(eq(createUserEmployee), anyString());
    assertEquals(201, response.getStatusCode().value());
  }

  @Test
  void testUpdateEmployeeByShortId() {
    String shortId = "raza002";
    UpdateUserEmployee updateUserEmployee = MockData.getUpdateUserEmployee();
    doNothing().when(service).updateOrCreateEmployee(any(String.class), any(UpdateUserEmployee.class), anyString());

    ResponseEntity<Void> response = controller.updateEmployeeByShortId(shortId, updateUserEmployee);

    verify(service, times(1)).updateOrCreateEmployee(eq(shortId), eq(updateUserEmployee), anyString());
    assertEquals(204, response.getStatusCode().value());
  }

  @Test
  void testGetEmployeesWithPagination_serviceThrows_propagatesException() {
    when(service.getEmployeesWithPagination(anyInt(), anyInt()))
        .thenThrow(new FumValidationException("error.validation", "Invalid page size"));

    assertThrows(FumValidationException.class,
        () -> controller.getEmployeesWithPagination(50, 1));
  }

  @Test
  void testGetEmployeeUser_serviceThrows_propagatesException() {
    when(service.getEmployeeUser("unknown"))
        .thenThrow(new FumNotFoundException("error.not.found", "Employee not found"));

    assertThrows(FumNotFoundException.class,
        () -> controller.getEmployeeUser("unknown"));
  }

  @Test
  void testCreateEmployee_serviceThrows_propagatesException() {
    CreateUserEmployee createUserEmployee = MockData.getCreateUserEmployee();
    doThrow(new FumValidationException("error.validation", "Missing required fields"))
        .when(service).createEmployee(any(CreateUserEmployee.class), anyString());

    assertThrows(FumValidationException.class,
        () -> controller.createEmployee(createUserEmployee));
  }

  @Test
  void testUpdateEmployeeByShortId_serviceThrows_propagatesException() {
    UpdateUserEmployee updateUserEmployee = MockData.getUpdateUserEmployee();
    doThrow(new FumNotFoundException("error.not.found", "Employee not found"))
        .when(service).updateOrCreateEmployee(any(String.class), any(UpdateUserEmployee.class), anyString());

    assertThrows(FumNotFoundException.class,
        () -> controller.updateEmployeeByShortId("unknown", updateUserEmployee));
  }

  @Test
  void testDeleteEmployeeByShortId_found_returns204() {
    String shortId = "raza002";
    doNothing().when(service).deleteEmployee(shortId);

    ResponseEntity<Void> response = controller.deleteEmployeeByShortId(shortId);

    verify(service, times(1)).deleteEmployee(shortId);
    verify(userManagementService, times(1)).refreshUserSearchMaterializedView();
    assertEquals(HttpStatus.NO_CONTENT.value(), response.getStatusCode().value());
    assertEquals(null, response.getBody());
  }

  @Test
  void testDeleteEmployeeByShortId_notFound_returns204() {
    String shortId = "unknown";
    doNothing().when(service).deleteEmployee(shortId);

    ResponseEntity<Void> response = controller.deleteEmployeeByShortId(shortId);

    verify(service, times(1)).deleteEmployee(shortId);
    assertEquals(HttpStatus.NO_CONTENT.value(), response.getStatusCode().value());
    assertEquals(null, response.getBody());
  }

  @Test
  void testPatchEmployeeByShortId_success() {
    String shortId = "raza002";
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setFirstName("NewFirst");
    doNothing().when(service).patchEmployee(eq(shortId), eq(patch), anyString());

    ResponseEntity<Void> response = controller.patchEmployeeByShortId(shortId, patch);

    verify(service, times(1)).patchEmployee(eq(shortId), eq(patch), anyString());
    assertEquals(HttpStatus.NO_CONTENT.value(), response.getStatusCode().value());
  }

  @Test
  void testPatchEmployeeByShortId_serviceThrows_propagatesException() {
    String shortId = "unknown";
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setFirstName("NewFirst");
    doThrow(new FumNotFoundException("error.not.found", "Employee not found"))
        .when(service).patchEmployee(any(String.class), any(PatchUserEmployee.class), anyString());

    assertThrows(FumNotFoundException.class,
        () -> controller.patchEmployeeByShortId(shortId, patch));
  }
}
