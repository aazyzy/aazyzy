package ca.bnc.wealth.api.user.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.user.service.EntitlementFirmService;
import ca.bnc.wealth.api.user.service.EntitlementModuleService;
import ca.bnc.wealth.api.user.service.EntitlementPackageService;
import ca.bnc.wealth.api.user.service.EntitlementResourceService;
import ca.bnc.wealth.common.entitlements.user_management.model.EntitlementResource;
import ca.bnc.wealth.common.entitlements.user_management.model.Firm;
import ca.bnc.wealth.common.entitlements.user_management.model.FirmsResponse;
import ca.bnc.wealth.common.entitlements.user_management.model.ModelPackage;
import ca.bnc.wealth.common.entitlements.user_management.model.ModulesResponse;
import ca.bnc.wealth.common.entitlements.user_management.model.PackageFeature;
import ca.bnc.wealth.common.entitlements.user_management.model.PackagesResponse;
import ca.bnc.wealth.common.entitlements.user_management.model.ResourcesResponse;
import ca.bnc.wealth.common.entitlements.user_management.model.RrCodesResponse;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

class EntitlementControllerTest {

  private EntitlementResourceService entitlementResourceService;
  private EntitlementPackageService entitlementPackageService;
  private EntitlementFirmService entitlementFirmService;
  private EntitlementModuleService entitlementModuleService;
  private EntitlementController controller;

  @BeforeEach
  void setUp() {
    entitlementResourceService = mock(EntitlementResourceService.class);
    entitlementPackageService = mock(EntitlementPackageService.class);
    entitlementFirmService = mock(EntitlementFirmService.class);
    entitlementModuleService = mock(EntitlementModuleService.class);
    controller = new EntitlementController(entitlementResourceService, entitlementPackageService,
        entitlementFirmService, entitlementModuleService);
  }

  @Test
  void testGetEntitlementResources_returnsOkWithResources() {
    ResourcesResponse mockResponse = new ResourcesResponse();
    EntitlementResource resource = new EntitlementResource();
    resource.setId("1");
    resource.setName("Advanced Trading");
    resource.setType("FEATURE");
    resource.setRestriction(false);
    resource.setDescription("Access to advanced trading capabilities");
    resource.setGroup("Trading");
    resource.setLabel("ADV_TRADING");
    resource.setPurpose("Provides advanced trading functionality");
    resource.setVersion("1.0");
    resource.setActive(true);
    mockResponse.setResources(List.of(resource));

    when(entitlementResourceService.getEntitlementResources()).thenReturn(mockResponse);

    ResponseEntity<ResourcesResponse> response = controller.getEntitlementResources();

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
    assertEquals(1, response.getBody().getResources().size());
    assertEquals("Advanced Trading", response.getBody().getResources().get(0).getName());

    verify(entitlementResourceService).getEntitlementResources();
  }

  @Test
  void testGetEntitlementResources_returnsOkWithEmptyList() {
    ResourcesResponse mockResponse = new ResourcesResponse();
    mockResponse.setResources(List.of());

    when(entitlementResourceService.getEntitlementResources()).thenReturn(mockResponse);

    ResponseEntity<ResourcesResponse> response = controller.getEntitlementResources();

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
    assertEquals(0, response.getBody().getResources().size());

    verify(entitlementResourceService).getEntitlementResources();
  }

  @Test
  void testGetEntitlementPackages_returnsOkWithPackages() {
    PackagesResponse mockResponse = new PackagesResponse();
    ModelPackage modelPackage = new ModelPackage();
    modelPackage.setId("10");
    modelPackage.setName("Premium Trading");
    modelPackage.setDescription("Premium trading package");
    modelPackage.setActive(true);
    PackageFeature feature = new PackageFeature();
    feature.setResource("Advanced Trading");
    feature.setMandatory(true);
    feature.setSelected(false);
    modelPackage.setFeatures(List.of(feature));
    mockResponse.setPackages(List.of(modelPackage));

    when(entitlementPackageService.getEntitlementPackages()).thenReturn(mockResponse);

    ResponseEntity<PackagesResponse> response = controller.getEntitlementPackages();

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
    assertEquals(1, response.getBody().getPackages().size());
    assertEquals("Premium Trading", response.getBody().getPackages().get(0).getName());
    assertEquals(1, response.getBody().getPackages().get(0).getFeatures().size());

    verify(entitlementPackageService).getEntitlementPackages();
  }

  @Test
  void testGetEntitlementPackages_returnsOkWithEmptyList() {
    PackagesResponse mockResponse = new PackagesResponse();
    mockResponse.setPackages(List.of());

    when(entitlementPackageService.getEntitlementPackages()).thenReturn(mockResponse);

    ResponseEntity<PackagesResponse> response = controller.getEntitlementPackages();

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
    assertEquals(0, response.getBody().getPackages().size());

    verify(entitlementPackageService).getEntitlementPackages();
  }

  @Test
  void testGetEntitlementFirmsInternals_returnsOkWithFirms() {
    FirmsResponse mockResponse = new FirmsResponse();
    Firm firm = new Firm();
    firm.setId("FIRM-001");
    firm.setName("Test Firm");
    firm.setType("NBIN");
    firm.setActive(true);
    mockResponse.setFirms(List.of(firm));

    when(entitlementFirmService.getEntitlementFirmsInternals()).thenReturn(mockResponse);

    ResponseEntity<FirmsResponse> response = controller.getEntitlementFirmsInternals();

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
    assertEquals(1, response.getBody().getFirms().size());
    assertEquals("Test Firm", response.getBody().getFirms().get(0).getName());

    verify(entitlementFirmService).getEntitlementFirmsInternals();
  }

  @Test
  void testGetEntitlementFirmsInternals_returnsOkWithEmptyList() {
    FirmsResponse mockResponse = new FirmsResponse();
    mockResponse.setFirms(List.of());

    when(entitlementFirmService.getEntitlementFirmsInternals()).thenReturn(mockResponse);

    ResponseEntity<FirmsResponse> response = controller.getEntitlementFirmsInternals();

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
    assertEquals(0, response.getBody().getFirms().size());

    verify(entitlementFirmService).getEntitlementFirmsInternals();
  }

  @Test
  void testGetEntitlementRrCodesInternals_returnsOkWithResponse() {
    RrCodesResponse mockResponse = new RrCodesResponse();

    when(entitlementFirmService.getEntitlementRrCodesInternals()).thenReturn(mockResponse);

    ResponseEntity<RrCodesResponse> response = controller.getEntitlementRrCodesInternals();

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());

    verify(entitlementFirmService).getEntitlementRrCodesInternals();
  }

  @Test
  void testGetEntitlementModules_returnsOkWithModules() {
    ModulesResponse mockResponse = new ModulesResponse();
    mockResponse.setModules(List.of("firm_client_accounts", "users_module", "compass_r2"));

    when(entitlementModuleService.getEntitlementModules()).thenReturn(mockResponse);

    ResponseEntity<ModulesResponse> response = controller.getEntitlementModules();

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNotNull(response.getBody());
    assertEquals(List.of("firm_client_accounts", "users_module", "compass_r2"), response.getBody().getModules());

    verify(entitlementModuleService).getEntitlementModules();
  }
}
