package ca.bnc.wealth.api.user.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import ca.bnc.wealth.api.user.service.SpecialInquiriesService;
import ca.bnc.wealth.common.specialinquiries.user_management.model.FirmsResponse;
import ca.bnc.wealth.common.specialinquiries.user_management.model.RrCodesRequest;
import ca.bnc.wealth.common.specialinquiries.user_management.model.UsersResponse;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ExtendWith(MockitoExtension.class)
class SpecialInquiriesControllerTest {

  private static final String FIRM_ID = "NBIN";
  private static final String RESOURCE_NAME = "firm_level_access";
  private static final String USER_PACKAGE_NAME = "AdminAll_V1.17";

  @InjectMocks
  private SpecialInquiriesController specialInquiriesController;

  @Mock
  private SpecialInquiriesService specialInquiriesService;

  @Test
  void testGetAllUsers_shouldDelegateAndReturnOk() {
    UsersResponse expected = new UsersResponse();
    when(specialInquiriesService.getAllUsers()).thenReturn(expected);

    ResponseEntity<UsersResponse> response = specialInquiriesController.getAllUsers();

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertSame(expected, response.getBody());
    verify(specialInquiriesService).getAllUsers();
  }

  @Test
  void testGetUsersByFirm_shouldDelegateAndReturnOk() {
    UsersResponse expected = new UsersResponse();
    when(specialInquiriesService.getUsersByFirm(FIRM_ID)).thenReturn(expected);

    ResponseEntity<UsersResponse> response = specialInquiriesController.getUsersByFirm(FIRM_ID);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertSame(expected, response.getBody());
    verify(specialInquiriesService).getUsersByFirm(FIRM_ID);
  }

  @Test
  void testGetUsersByUserPackage_shouldDelegateAndReturnOk() {
    UsersResponse expected = new UsersResponse();
    when(specialInquiriesService.getUsersByUserPackage(USER_PACKAGE_NAME)).thenReturn(expected);

    ResponseEntity<UsersResponse> response =
        specialInquiriesController.getUsersByUserPackage(USER_PACKAGE_NAME);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertSame(expected, response.getBody());
    verify(specialInquiriesService).getUsersByUserPackage(USER_PACKAGE_NAME);
  }

  @Test
  void testGetFirmsByFirmType_shouldDelegateAndReturnOk() {
    FirmsResponse expected = new FirmsResponse();
    when(specialInquiriesService.getFirmsByFirmType("IB")).thenReturn(expected);

    ResponseEntity<FirmsResponse> response = specialInquiriesController.getFirmsByFirmType("IB");

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertSame(expected, response.getBody());
    verify(specialInquiriesService).getFirmsByFirmType("IB");
  }

  @Test
  void testGetUsersByResource_shouldDelegateAndReturnOk() {
    UsersResponse expected = new UsersResponse();
    when(specialInquiriesService.getUsersByResource(RESOURCE_NAME)).thenReturn(expected);

    ResponseEntity<UsersResponse> response =
        specialInquiriesController.getUsersByResource(RESOURCE_NAME);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertSame(expected, response.getBody());
    verify(specialInquiriesService).getUsersByResource(RESOURCE_NAME);
  }

  @Test
  void testGetUsersByFirmAndUserPackage_shouldDelegateAndReturnOk() {
    UsersResponse expected = new UsersResponse();
    when(specialInquiriesService.getUsersByFirmAndUserPackage(FIRM_ID, USER_PACKAGE_NAME))
        .thenReturn(expected);

    ResponseEntity<UsersResponse> response =
        specialInquiriesController.getUsersByFirmAndUserPackage(FIRM_ID, USER_PACKAGE_NAME);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertSame(expected, response.getBody());
    verify(specialInquiriesService).getUsersByFirmAndUserPackage(FIRM_ID, USER_PACKAGE_NAME);
  }

  @Test
  void testGetUsersByFirmAndResource_shouldDelegateAndReturnOk() {
    UsersResponse expected = new UsersResponse();
    when(specialInquiriesService.getUsersByFirmAndResource(FIRM_ID, RESOURCE_NAME))
        .thenReturn(expected);

    ResponseEntity<UsersResponse> response =
        specialInquiriesController.getUsersByFirmAndResource(FIRM_ID, RESOURCE_NAME);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertSame(expected, response.getBody());
    verify(specialInquiriesService).getUsersByFirmAndResource(FIRM_ID, RESOURCE_NAME);
  }

  @Test
  void testGetUsersByFirm_shouldNeutralizeControlCharactersInTheAuditRecord() {
    String forgedFirmId = "NBIN\r\nSPECIAL_INQUIRY_DATA_ACCESS: actor=someone-else";
    when(specialInquiriesService.getUsersByFirm(forgedFirmId)).thenReturn(new UsersResponse());

    Logger logger = (Logger) LoggerFactory.getLogger(SpecialInquiriesController.class);
    ListAppender<ILoggingEvent> appender = new ListAppender<>();
    appender.start();
    logger.addAppender(appender);
    try {
      specialInquiriesController.getUsersByFirm(forgedFirmId);
    } finally {
      logger.detachAppender(appender);
    }

    assertEquals(1, appender.list.size());
    String auditRecord = appender.list.get(0).getFormattedMessage();
    assertFalse(auditRecord.contains("\r"));
    assertFalse(auditRecord.contains("\n"));
    // Sanitization applies to the audit record only - the query still uses the raw value.
    verify(specialInquiriesService).getUsersByFirm(forgedFirmId);
  }

  @Test
  void testGetUsersByFirmAndUserPackage_shouldNeutralizeControlCharactersInTheRoleName() {
    String forgedName = "AdminAll_V1.17\nSPECIAL_INQUIRY_DATA_ACCESS: actor=someone-else";
    when(specialInquiriesService.getUsersByFirmAndUserPackage(FIRM_ID, forgedName))
        .thenReturn(new UsersResponse());

    Logger logger = (Logger) LoggerFactory.getLogger(SpecialInquiriesController.class);
    ListAppender<ILoggingEvent> appender = new ListAppender<>();
    appender.start();
    logger.addAppender(appender);
    try {
      specialInquiriesController.getUsersByFirmAndUserPackage(FIRM_ID, forgedName);
    } finally {
      logger.detachAppender(appender);
    }

    assertEquals(1, appender.list.size());
    String auditRecord = appender.list.get(0).getFormattedMessage();
    assertFalse(auditRecord.contains("\n"));
    verify(specialInquiriesService).getUsersByFirmAndUserPackage(FIRM_ID, forgedName);
  }

  @Test
  void testGetUsersByRrCodes_shouldDelegateAndReturnOk() {
    UsersResponse expected = new UsersResponse();
    List<String> rrCodes = List.of("AB10", "CD20");
    when(specialInquiriesService.getUsersByRrCodes(rrCodes)).thenReturn(expected);

    ResponseEntity<UsersResponse> response =
        specialInquiriesController.getUsersByRrCodes(new RrCodesRequest().rrCodes(rrCodes));

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertSame(expected, response.getBody());
    verify(specialInquiriesService).getUsersByRrCodes(rrCodes);
  }

  @Test
  void testGetUsersByRrCodes_shouldNeutralizeAndBoundTheAuditRecord() {
    List<String> rrCodes = new ArrayList<>(Collections.nCopies(1500, "AB10"));
    rrCodes.set(0, "AB10\r\nSPECIAL_INQUIRY_DATA_ACCESS: actor=someone-else");
    rrCodes.set(1, "X".repeat(100_000));
    when(specialInquiriesService.getUsersByRrCodes(rrCodes)).thenReturn(new UsersResponse());

    Logger logger = (Logger) LoggerFactory.getLogger(SpecialInquiriesController.class);
    ListAppender<ILoggingEvent> appender = new ListAppender<>();
    appender.start();
    logger.addAppender(appender);
    try {
      specialInquiriesController.getUsersByRrCodes(new RrCodesRequest().rrCodes(rrCodes));
    } finally {
      logger.detachAppender(appender);
    }

    assertEquals(1, appender.list.size());
    String auditRecord = appender.list.get(0).getFormattedMessage();
    assertFalse(auditRecord.contains("\r"));
    assertFalse(auditRecord.contains("\n"));
    assertFalse(auditRecord.contains("someone-else"));
    assertTrue(auditRecord.endsWith(",...(1500 values)"));
    assertTrue(auditRecord.length() < 10_000);
    // The service still receives the raw list and does the validation.
    verify(specialInquiriesService).getUsersByRrCodes(rrCodes);
  }

  @Test
  void testGetUsersByRrCodes_shouldBindTheJsonBodyOfAPost() throws Exception {
    MockMvc mockMvc = MockMvcBuilders.standaloneSetup(specialInquiriesController).build();
    when(specialInquiriesService.getUsersByRrCodes(List.of("AB10", "CD20")))
        .thenReturn(new UsersResponse());

    mockMvc.perform(post("/special-inquiries/rr-codes/users")
            .contentType(MediaType.APPLICATION_JSON)
            .content("{\"rrCodes\":[\"AB10\",\"CD20\"]}"))
        .andExpect(status().isOk());

    verify(specialInquiriesService).getUsersByRrCodes(List.of("AB10", "CD20"));
  }

  @Test
  void testGetUsersByRrCodes_shouldRejectAMissingBodyBeforeReachingTheService() throws Exception {
    MockMvc mockMvc = MockMvcBuilders.standaloneSetup(specialInquiriesController).build();

    mockMvc.perform(post("/special-inquiries/rr-codes/users")
            .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest());

    verifyNoInteractions(specialInquiriesService);
  }
}
