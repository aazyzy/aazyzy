package ca.bnc.wealth.api.user.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import ca.bnc.wealth.api.authorization.model.User;
import ca.bnc.wealth.api.user.service.AttestationService;
import ca.bnc.wealth.api.user.service.UserManagementService;
import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.user_management.model.RRCodeAccess;
import ca.bnc.wealth.common.user_management.model.ValidateRRCodeRequest;
import com.nimbusds.jwt.JWT;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.JWTParser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;

class UserManagementControllerTest {


    private static final String NBIN = "NBIN";
    private static final String IDP_SUBJECT = "idpSubject";
    private static final String STUB_VALID_JWT = "stub-" + java.util.UUID.randomUUID();
    private static final String STUB_INVALID_JWT = "stub-" + java.util.UUID.randomUUID();

    private AttestationService attestationService;
    private UserManagementService userManagementService;
    private UserManagementController controller;
    private SecurityContext securityContext;
    private Authentication authentication;
    private User user;

    @BeforeEach
    void setUp() {
        attestationService = mock(AttestationService.class);
        userManagementService = mock(UserManagementService.class);
        controller = new UserManagementController(attestationService, userManagementService);
        securityContext = mock(SecurityContext.class);
        authentication = mock(Authentication.class);
        user = mock(User.class);
    }

    @Test
    void testTriggerAttestationCallsServiceAndReturnsOk() {
        Long attestationId = 1L;
        ResponseEntity<Void> response = controller.triggerAttestation(attestationId);
        verify(attestationService, times(1)).uploadAndTriggerAttestation(attestationId);
        assertEquals(200, response.getStatusCode().value());
        assertNull(response.getBody());
    }

    @Test
    void testGenerateAttestationCallsServiceAndReturnsOk() {
        Long attestationId = 2L;
        Long firmEntityId = 3L;
        ResponseEntity<Void> response = controller.generateAttestation(attestationId, firmEntityId);
        try {
            verify(attestationService, times(1)).generateAttestation(attestationId, firmEntityId, anyString());
        } catch (Exception e) {
            // Do nothing
        }
        assertEquals(200, response.getStatusCode().value());
        assertNull(response.getBody());
    }

    @Test
    void testValidateRRCodeWithValidUser() {
        when(user.isSystemToken()).thenReturn(false);
        when(user.getIdpSubject()).thenReturn(IDP_SUBJECT);
        when(authentication.getPrincipal()).thenReturn(user);
        when(securityContext.getAuthentication()).thenReturn(authentication);

        try (MockedStatic<SecurityContextHolder> mockedContext = mockStatic(SecurityContextHolder.class)) {
            mockedContext.when(SecurityContextHolder::getContext).thenReturn(securityContext);
            ValidateRRCodeRequest request = new ValidateRRCodeRequest().rrRange(List.of("AAAA", "9999"));
            when(userManagementService.validateRrCodeByUser(IDP_SUBJECT, request.getRrRange())).thenReturn(true);
            ResponseEntity<RRCodeAccess> response = controller.validateRRCode(null, request);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());
            assertTrue(response.getBody().getHasAccess());
        }
    }

    @Test
    void testValidateRRCodeWithSystemTokenAndValidFirmId() throws Exception {
        when(user.isSystemToken()).thenReturn(true);
        when(authentication.getPrincipal()).thenReturn(user);
        when(securityContext.getAuthentication()).thenReturn(authentication);

        try (MockedStatic<SecurityContextHolder> mockedContext = mockStatic(SecurityContextHolder.class)) {
            mockedContext.when(SecurityContextHolder::getContext).thenReturn(securityContext);

            JWT jwt = mock(JWT.class);
            JWTClaimsSet claimsSet = new JWTClaimsSet.Builder().claim("entityCode", NBIN).build();
            when(jwt.getJWTClaimsSet()).thenReturn(claimsSet);
            try (MockedStatic<JWTParser> mockedJwtParser = mockStatic(JWTParser.class)) {
                mockedJwtParser.when(() -> JWTParser.parse(STUB_VALID_JWT)).thenReturn(jwt);

                ValidateRRCodeRequest request = new ValidateRRCodeRequest().rrRange(List.of("AAAA", "9999"));
                when(userManagementService.validateRrCodeByFirmId(NBIN, request.getRrRange())).thenReturn(true);

                ResponseEntity<RRCodeAccess> response = controller.validateRRCode(STUB_VALID_JWT, request);

                assertEquals(HttpStatus.OK, response.getStatusCode());
                assertNotNull(response.getBody());
                assertTrue(response.getBody().getHasAccess());
            }
        }
    }

    @Test
    void testValidateRRCodeWithInvalidUser() {
        when(user.isSystemToken()).thenReturn(false);
        when(user.getIdpSubject()).thenReturn(null);
        when(authentication.getPrincipal()).thenReturn(user);
        when(securityContext.getAuthentication()).thenReturn(authentication);

        try (MockedStatic<SecurityContextHolder> mockedContext = mockStatic(SecurityContextHolder.class)) {
            mockedContext.when(SecurityContextHolder::getContext).thenReturn(securityContext);

            ValidateRRCodeRequest request = new ValidateRRCodeRequest().rrRange(List.of("AAAA", "9999"));

            FumValidationException exception = assertThrows(FumValidationException.class, () -> {
                controller.validateRRCode(null, request);
            });

            assertEquals(Constants.FIRM_RRCODE_INVALID_TOKEN, exception.getCode());
            assertEquals(Constants.FIRM_RRCODE_INVALID_TOKEN_MESSAGE, exception.getMessage());
        }
    }

    @Test
    void testValidateRRCodeWithInvalidSystemToken() throws Exception {
        // Mock SecurityContext and Authentication
        when(user.isSystemToken()).thenReturn(true);
        when(authentication.getPrincipal()).thenReturn(user);
        when(securityContext.getAuthentication()).thenReturn(authentication);

        try (MockedStatic<SecurityContextHolder> mockedContext = mockStatic(SecurityContextHolder.class)) {
            mockedContext.when(SecurityContextHolder::getContext).thenReturn(securityContext);

            try (MockedStatic<JWTParser> mockedJwtParser = mockStatic(JWTParser.class)) {
                mockedJwtParser.when(() -> JWTParser.parse(STUB_INVALID_JWT)).thenThrow(new RuntimeException("Invalid token"));
                ValidateRRCodeRequest request = new ValidateRRCodeRequest().rrRange(List.of("AAAA", "9999"));
                FumValidationException exception = assertThrows(FumValidationException.class, () -> {
                    controller.validateRRCode(STUB_INVALID_JWT, request);
                });

                assertEquals(Constants.FIRM_RRCODE_INVALID_TOKEN, exception.getCode());
                assertEquals(Constants.FIRM_RRCODE_INVALID_TOKEN_MESSAGE, exception.getMessage());
            }
        }
    }

    @Test
    void testValidateRRCodeWithMissingFirmId() throws Exception {
        when(user.isSystemToken()).thenReturn(true);
        when(authentication.getPrincipal()).thenReturn(user);
        when(securityContext.getAuthentication()).thenReturn(authentication);

        try (MockedStatic<SecurityContextHolder> mockedContext = mockStatic(SecurityContextHolder.class)) {
            mockedContext.when(SecurityContextHolder::getContext).thenReturn(securityContext);

            JWT jwt = mock(JWT.class);
            JWTClaimsSet claimsSet = new JWTClaimsSet.Builder().build();
            when(jwt.getJWTClaimsSet()).thenReturn(claimsSet);

            try (MockedStatic<JWTParser> mockedJwtParser = mockStatic(JWTParser.class)) {
                mockedJwtParser.when(() -> JWTParser.parse(STUB_VALID_JWT)).thenReturn(jwt);
                ValidateRRCodeRequest request = new ValidateRRCodeRequest().rrRange(List.of("AAAA", "9999"));
                FumValidationException exception = assertThrows(FumValidationException.class, () -> {
                    controller.validateRRCode(STUB_VALID_JWT, request);
                });

                assertEquals(Constants.FIRM_RRCODE_INVALID_SYSTEM_TOKEN_FORMAT, exception.getCode());
                assertEquals(Constants.FIRM_RRCODE_INVALID_SYSTEM_TOKEN_FORMAT_MESSAGE, exception.getMessage());
            }
        }
    }

}
