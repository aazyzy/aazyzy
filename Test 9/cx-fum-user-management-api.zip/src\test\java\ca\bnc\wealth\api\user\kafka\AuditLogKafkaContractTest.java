package ca.bnc.wealth.api.user.kafka;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import ca.bnc.wealth.api.user.service.AuditLogService;
import ca.bnc.wealth.common.jpa.entity.enums.AuditEventType;
import ca.bnc.wealth.common.kafka.model.EventMessages;
import ca.bnc.wealth.common.kafka.model.audit.AuditUserConfigPayLoad;
import ca.bnc.wealth.common.messenger.Messenger;
import ca.bnc.wealth.common.messenger.model.KafkaMessage;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import tools.jackson.databind.JavaType;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.test.util.ReflectionTestUtils;

/**
 * Offline contract test: proves the exact message produced by this API's audit publisher is
 * byte-for-byte consumable by audit-log-management-api's AuditLogEventSubscriber (which
 * deserializes EventMessages&lt;AuditUserConfigPayLoad&gt; via constructParametricType).
 *
 * <p>This does not require a running Kafka broker — it exercises the full serialization chain
 * (AuditLogService envelope build -> AuditLogEventPublisher JSON serialization -> consumer
 * deserialization) so we can validate messaging correctness without infrastructure.
 */
class AuditLogKafkaContractTest {

  // ObjectMapper equivalent to the Spring-managed one (Jackson 2 defaults; java.time is built into Jackson 3).
  private final ObjectMapper objectMapper = JsonMapper.builderWithJackson2Defaults().build();

  @Test
  void publishedMessageIsConsumableByAuditConsumer() throws Exception {
    UserConfiguration before = userConfiguration("Jane", "Doe", "jane.doe@bnc.ca", "jdoe001",
        "FIRM-1", List.of("R1"));
    UserConfiguration after = userConfiguration("Jane", "Smith", "jane.smith@bnc.ca", "jdoe001",
        "FIRM-1", List.of("R1", "R2"));

    // 1) Build the envelope exactly as the service does, capturing what would be published.
    AuditLogEventPublisher capturingPublisher = mock(AuditLogEventPublisher.class);
    AuditLogService auditLogService = new AuditLogService(capturingPublisher);
    auditLogService.publishEmployeeAudit(AuditEventType.UPDATE, before, after);

    @SuppressWarnings("unchecked")
    ArgumentCaptor<EventMessages<AuditUserConfigPayLoad>> envelopeCaptor =
        ArgumentCaptor.forClass(EventMessages.class);
    verify(capturingPublisher).publish(envelopeCaptor.capture());
    EventMessages<AuditUserConfigPayLoad> envelope = envelopeCaptor.getValue();

    // 2) Serialize via the real publisher with a mocked Messenger; capture the wire payload.
    AuditLogEventPublisher realPublisher = new AuditLogEventPublisher();
    ReflectionTestUtils.setField(realPublisher, "objectMapper", objectMapper);
    Messenger<Object, Object, byte[]> messenger = mock(Messenger.class);
    ReflectionTestUtils.setField(realPublisher, "messager", messenger);

    realPublisher.publish(envelope);

    ArgumentCaptor<KafkaMessage<String, String>> kafkaMessageCaptor =
        ArgumentCaptor.forClass(KafkaMessage.class);
    verify(messenger).process(kafkaMessageCaptor.capture());
    String wireJson = kafkaMessageCaptor.getValue().getMessage();
    assertNotNull(wireJson, "publisher must serialize a non-null JSON payload");

    // 3) Deserialize EXACTLY as audit-log-management-api's subscriber.parseJson does.
    JavaType type = objectMapper.getTypeFactory()
        .constructParametricType(EventMessages.class, AuditUserConfigPayLoad.class);
    EventMessages<AuditUserConfigPayLoad> roundTripped = objectMapper.readValue(wireJson, type);

    // 4) Assert the consumer receives the fields it diffs.
    assertNotNull(roundTripped.getHeader());
    assertNotNull(roundTripped.getHeader().getId());
    AuditUserConfigPayLoad payload = roundTripped.getPayload();
    assertEquals(AuditEventType.UPDATE.name(), payload.getType());

    UserConfiguration rtBefore = payload.getUserConfigurationBefore();
    UserConfiguration rtAfter = payload.getUserConfigurationAfter();
    assertEquals("Doe", rtBefore.getLastName());
    assertEquals("jane.doe@bnc.ca", rtBefore.getEmail());
    assertEquals(List.of("R1"), rtBefore.getResources());

    assertEquals("Jane", rtAfter.getFirstName());
    assertEquals("Smith", rtAfter.getLastName());
    assertEquals("jane.smith@bnc.ca", rtAfter.getEmail());
    assertEquals("jdoe001", rtAfter.getUsername());
    assertEquals("FIRM-1", rtAfter.getFirmId());
    assertEquals(List.of("R1", "R2"), rtAfter.getResources());
  }

  @Test
  void createEventCarriesNullBeforeSnapshot() throws Exception {
    UserConfiguration after = userConfiguration("New", "Hire", "new.hire@bnc.ca", "nhire01",
        "FIRM-9", List.of());

    AuditLogEventPublisher capturingPublisher = mock(AuditLogEventPublisher.class);
    new AuditLogService(capturingPublisher)
        .publishEmployeeAudit(AuditEventType.CREATE, null, after);

    @SuppressWarnings("unchecked")
    ArgumentCaptor<EventMessages<AuditUserConfigPayLoad>> envelopeCaptor =
        ArgumentCaptor.forClass(EventMessages.class);
    verify(capturingPublisher).publish(envelopeCaptor.capture());

    String wireJson = objectMapper.writeValueAsString(envelopeCaptor.getValue());
    JavaType type = objectMapper.getTypeFactory()
        .constructParametricType(EventMessages.class, AuditUserConfigPayLoad.class);
    EventMessages<AuditUserConfigPayLoad> roundTripped = objectMapper.readValue(wireJson, type);

    assertEquals(AuditEventType.CREATE.name(), roundTripped.getPayload().getType());
    assertNull(roundTripped.getPayload().getUserConfigurationBefore());
    assertEquals("nhire01", roundTripped.getPayload().getUserConfigurationAfter().getUsername());
  }

  @Test
  void nullAfterSnapshotIsNotPublished() {
    AuditLogEventPublisher capturingPublisher = mock(AuditLogEventPublisher.class);
    new AuditLogService(capturingPublisher)
        .publishEmployeeAudit(AuditEventType.UPDATE, new UserConfiguration(), null);
    verify(capturingPublisher, org.mockito.Mockito.never()).publish(any());
  }

  private UserConfiguration userConfiguration(String firstName, String lastName, String email,
      String username, String firmId, List<String> resources) {
    UserConfiguration uc = new UserConfiguration();
    uc.setFirstName(firstName);
    uc.setLastName(lastName);
    uc.setEmail(email);
    uc.setUsername(username);
    uc.setIdpSubject(username);
    uc.setIdp("emp");
    uc.setAccessProfileSet(true);
    uc.setFirmId(firmId);
    uc.setResources(resources);
    return uc;
  }
}
