package ca.bnc.wealth.api.user.schedule;

import ca.bnc.wealth.api.user.service.AttestationService;
import ca.bnc.wealth.common.jpa.entity.iam.Attestation;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationRepository;
import ca.bnc.wealth.common.jpa.service.IamScheduleService;
import ca.bnc.wealth.common.jpa.specification.Specification;
import lombok.SneakyThrows;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AttestationStatusCheckServiceTest {

  @Mock
  private IamScheduleService scheduleService;

  @Mock
  private AttestationRepository attestationRepository;

  @Mock
  private AttestationService attestationService;

  @InjectMocks
  private AttestationStatusCheckService service;

  @Test
  @SneakyThrows
  void testUpdateBulkStatus_ShouldProcessPendingAttestations() {
    Attestation attestation1 = new Attestation();
    attestation1.setAttestationId(1L);
    Attestation attestation2 = new Attestation();
    attestation2.setAttestationId(2L);
    FieldUtils.writeField(service, "scheduleName", "FIRM_ATTESTATION_STATUS_CHECK_SCHEDULE", true);
    FieldUtils.writeField(service, "schedulerDuration", 10, true);


    when(scheduleService.canRunSchedule(anyString(), anyLong(), any())).thenReturn(true);
    when(attestationRepository.findAll(any(Specification.class))).thenReturn(List.of(attestation1, attestation2));

    service.updateBulkStatus();

    verify(attestationService).checkAndUpdateStatus(1L);
    verify(attestationService).checkAndUpdateStatus(2L);
    verify(scheduleService).updateStatusToFinish(anyString());
  }
}