package ca.bnc.wealth.api.user.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doThrow;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.report.feign.client.ReportApiClient;
import ca.bnc.wealth.common.report.model.ReportRequest;
import ca.bnc.wealth.common.report.model.S3Details;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.test.util.ReflectionTestUtils;

class ApplicationDataServiceTest {

  private static final String STUB_BEARER_TOKEN = "stub-" + java.util.UUID.randomUUID();

  private ApplicationDataService service;
  private ReportApiClient reportApiClient;
  private SystemTokenFactory systemTokenFactory;

  @BeforeEach
  void setUp() {
    reportApiClient = Mockito.mock(ReportApiClient.class);
    systemTokenFactory = Mockito.mock(SystemTokenFactory.class);
    service = new ApplicationDataService(reportApiClient, systemTokenFactory);

    ReflectionTestUtils.setField(service, "enableCache", true);
  }

  @Test
  void testGetSecurityZoneDataReturnsMap() {
    String s3Url = "s3://bucket/file.csv";
    String versionId = "v1";
    String csv =
        "Application Id|User Id|Given Name|Family Name|Broker Id|Broker Name|Function|Broker Access|Branch Access|IA Access|User Effective Date|User End Date|User Last Login\n"
            + "CI|AARABADI|Adil|Aarab|L65|NBIN A DIVISION OF NBF INC.|CIACSITE|MULTCN|||2024/04/05 00:00:00|2099/12/31 00:00:00|2025/08/25 09:17:08";
    byte[] fileBytes = csv.getBytes(StandardCharsets.UTF_8);

    ByteArrayResource resource = new ByteArrayResource(fileBytes);
    Mockito.when(systemTokenFactory.getBearerToken(Mockito.anyString())).thenReturn(STUB_BEARER_TOKEN);
    Mockito.when(reportApiClient.download(Mockito.anyString(), Mockito.any(ReportRequest.class)))
        .thenReturn(org.springframework.http.ResponseEntity.ok(resource));

    Map<String, Map<String, Map<String, String>>> result = service.getSecurityZoneData(s3Url, versionId, "");
    assertNotNull(result);
    assertTrue(result.containsKey("CI"));
    assertTrue(result.get("CI").containsKey("AARABADI"));
  }

  @Test
  void testGetSecurityZoneDataThrowsOnNullResponse() {
    Mockito.when(systemTokenFactory.getBearerToken(Mockito.anyString())).thenReturn(STUB_BEARER_TOKEN);
    Mockito.when(reportApiClient.download(Mockito.anyString(), Mockito.any(ReportRequest.class)))
        .thenReturn(org.springframework.http.ResponseEntity.ok(null));

    assertThrows(FumServiceException.class, () -> service.getSecurityZoneData("s3://bucket/file.csv", "v1", ""));
  }

  @Test
  void testGetOtherDataReturnsMap() {
    Mockito.when(systemTokenFactory.getBearerToken(Mockito.anyString())).thenReturn(STUB_BEARER_TOKEN);
    S3Details details = new S3Details();
    details.setS3Uri("s3://bucket/file.csv");
    details.setVersionId("v1");
    List<S3Details> detailsList = List.of(details);

    Mockito.when(reportApiClient.getS3Details(Mockito.anyString(), Mockito.any(ReportRequest.class)))
        .thenReturn(org.springframework.http.ResponseEntity.ok(detailsList));

    Map<String, String> result = service.getOtherData(List.of("prefix"));
    assertNotNull(result);
    assertEquals("v1", result.get("s3://bucket/file.csv"));
  }

  @Test
  void testRedisCacheEnabled() {
    assertTrue(service.redisCacheEnabled());
    ReflectionTestUtils.setField(service, "enableCache", false);
    assertFalse(service.redisCacheEnabled());
  }

  @Test
  void testConvertCsvFileToMap_whenCsvParseFails_shouldThrowFumServiceException() {
    assertThrows(FumServiceException.class, () -> service.convertCsvFileToMap(null));
  }
}
