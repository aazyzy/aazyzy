package ca.bnc.wealth.api.user.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;
import ca.bnc.wealth.common.exception.Entity.FumConflictException;
import ca.bnc.wealth.common.jpa.entity.enums.AttestationStatusType;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.iam.Attestation;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationFirmStaging;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationSourceData;
import ca.bnc.wealth.common.jpa.entity.iam.AttestationSourceType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationFirmFileRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationFirmStagingRepository;
import ca.bnc.wealth.common.jpa.repo.iam.AttestationRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.s3.S3Service;

class AttestationServiceTest {

  private AttestationService service;
  private AttestationRepository attestationRepository;
  private AttestationFirmStagingRepository attestationFirmStagingRepository;
  private AttestationFirmFileRepository attestationFirmFileRepository;
  private ApplicationDataService applicationDataService;
  private UserExtractService userExtractService;
  private S3Service s3Service;
  private S3PropertyService s3PropertyService;
  private BmaService bmaService;

  @BeforeEach
  void setUp() {
    service = mock(AttestationService.class, Mockito.CALLS_REAL_METHODS);

    attestationRepository = mock(AttestationRepository.class);
    attestationFirmStagingRepository = mock(AttestationFirmStagingRepository.class);
    attestationFirmFileRepository = mock(AttestationFirmFileRepository.class);
    applicationDataService = mock(ApplicationDataService.class);
    userExtractService = mock(UserExtractService.class);
    s3Service = mock(S3Service.class);
    s3PropertyService = mock(S3PropertyService.class);
    bmaService = mock(BmaService.class);
    ReflectionTestUtils.setField(service, "attestationRepository", attestationRepository);
    ReflectionTestUtils.setField(service, "attestationFirmStagingRepository", attestationFirmStagingRepository);
    ReflectionTestUtils.setField(service, "attestationFirmFileRepository", attestationFirmFileRepository);
    ReflectionTestUtils.setField(service, "applicationDataService", applicationDataService);
    ReflectionTestUtils.setField(service, "userExtractService", userExtractService);
    ReflectionTestUtils.setField(service, "s3Service", s3Service);
    ReflectionTestUtils.setField(service, "s3PropertyService", s3PropertyService);
    ReflectionTestUtils.setField(service, "bucket", "bucket");
    ReflectionTestUtils.setField(service, "keyPrefix", "prefix");
    ReflectionTestUtils.setField(service, "bmaService", bmaService);
  }

  @Test
  void testGenerateAttestationCreatesFiles() {
    Long attestationId = 1L;
    Long firmEntityId = 2L;

    // Setup AttestationFirmStaging
    Firm firm = new Firm();
    firm.setFirmId("FIRM1");
    firm.setFirmType(FirmType.NBIN);
    firm.setIdentitySource("source");

    Attestation attestation = new Attestation();
    attestation.setLabel("LABEL");
    attestation.setAttestationId(attestationId);

    AttestationFirmStaging staging = new AttestationFirmStaging();
    staging.setFirm(firm);
    staging.setAttestation(attestation);

    @SuppressWarnings("unchecked")
    Specification<AttestationFirmStaging> anySpec = any(Specification.class);
    when(attestationFirmStagingRepository.findOne(anySpec)).thenReturn(Optional.of(staging));

    // Setup AttestationSourceData
    AttestationSourceData sourceData = new AttestationSourceData();
    AttestationSourceType sourceType = new AttestationSourceType();
    sourceType.setCode("SECURITY_ZONE");
    sourceData.setAttestationSourceType(sourceType);
    sourceData.setReportId("s3://bucket/file.csv");
    sourceData.setReportVersionId("v1");
    attestation.setAttestationSourceDataList(List.of(sourceData));

    when(attestationFirmStagingRepository.saveAndFlush(any(AttestationFirmStaging.class))).thenReturn(staging);

    // Mock ApplicationDataService
    Map<String, Map<String, Map<String, String>>> securityZoneData = new HashMap<>();
    when(applicationDataService.getSecurityZoneData(anyString(), anyString(), anyString())).thenReturn(securityZoneData);

    // Mock UserExtractService
    List<Map<String, String>> userExtractData = List.of(Map.of("header1", "value1"));
    when(userExtractService.getUserExtractData(anyString(), any(), any())).thenReturn(userExtractData);

    when(s3PropertyService.getS3AccessFor()).thenReturn("FIRM_ATTESTATION");


    when(s3Service.getVersionAfterUpload(any(), any(), any(), any(), any())).thenReturn(Pair.of("s3://bucket/prefix/LABEL/FIRM1/FIRM1_LABEL_compass_user_access.csv", "v1"));
    when(s3Service.copyS3Object(any(), any(), any(), any())).thenReturn("v2");

    AttestationSourceData otherSource = new AttestationSourceData();
    otherSource.setReportId("s3://bucket/other.csv");
    otherSource.setReportVersionId("v2");
    AttestationSourceType type = new AttestationSourceType();
    type.setCode("secureZone");
    otherSource.setAttestationSourceType(type);

    attestation.setAttestationSourceDataList(List.of(otherSource));

    try {
      service.generateAttestation(attestationId, firmEntityId, "");
    } catch (Exception e) {
      // Do nothing
    }

    verify(attestationFirmFileRepository, atLeastOnce()).saveAll(any());
  }

  @Test
  void testUpdateStateAndGet_Attestation() {
    Long attestationId = 1L;
    Attestation attestation = new Attestation();
    attestation.setAttestationId(attestationId);
    attestation.setAttestationStatusType(AttestationStatusType.DRAFT);

    AttestationFirmStaging staging = new AttestationFirmStaging();
    staging.setAttestationStatusType(AttestationStatusType.DRAFT);
    List<AttestationFirmStaging> stagingList = List.of(staging);
    attestation.setAttestationFirmStagingList(stagingList);

    when(attestationRepository.save(any(Attestation.class))).thenReturn(attestation);
    when(attestationRepository.findById(attestationId)).thenReturn(Optional.of(attestation));

    Attestation result = service.updateStateToProcessing(attestationId);

    assertEquals(AttestationStatusType.PROCESSING, result.getAttestationStatusType());
    verify(attestationRepository, times(1)).save(attestation);
  }

  @Test
  void testUpdateStateAndGet_Attestation_ThrowsConflictException() {
    Attestation attestation = new Attestation();
    Long attestationId = 1L;
    attestation.setAttestationId(attestationId);
    attestation.setAttestationStatusType(AttestationStatusType.PROCESSING);

    when(attestationRepository.findById(attestationId)).thenReturn(Optional.of(attestation));

    assertThrows(
        FumConflictException.class,
        () -> service.updateStateToProcessing(attestationId));
  }

  @Test
  void testCheckAndUpdateStatus_AllDraft() {
    Attestation attestation = new Attestation();
    Long attestationId = 1L;
    attestation.setAttestationId(attestationId);

    AttestationFirmStaging staging1 = new AttestationFirmStaging();
    staging1.setAttestationStatusType(AttestationStatusType.DRAFT);
    AttestationFirmStaging staging2 = new AttestationFirmStaging();
    staging2.setAttestationStatusType(AttestationStatusType.DRAFT);

    attestation.setAttestationFirmStagingList(List.of(staging1, staging2));

    when(attestationRepository.findById(1L)).thenReturn(Optional.of(attestation));
    when(attestationRepository.saveAndFlush(any(Attestation.class))).thenReturn(attestation);

    service.checkAndUpdateStatus(1L);

    assertEquals(AttestationStatusType.DRAFT, attestation.getAttestationStatusType());
    verify(attestationRepository).saveAndFlush(attestation);
  }

  @Test
  void testCheckAndUpdateStatus_AllSystemError() {
    Attestation attestation = new Attestation();
    Long attestationId = 2L;
    attestation.setAttestationId(attestationId);

    AttestationFirmStaging staging1 = new AttestationFirmStaging();
    staging1.setAttestationStatusType(AttestationStatusType.SYSTEM_ERROR);
    AttestationFirmStaging staging2 = new AttestationFirmStaging();
    staging2.setAttestationStatusType(AttestationStatusType.SYSTEM_ERROR);

    attestation.setAttestationFirmStagingList(List.of(staging1, staging2));

    when(attestationRepository.findById(attestationId)).thenReturn(Optional.of(attestation));
    when(attestationRepository.saveAndFlush(any(Attestation.class))).thenReturn(attestation);

    service.checkAndUpdateStatus(attestationId);

    assertEquals(AttestationStatusType.SYSTEM_ERROR, attestation.getAttestationStatusType());
    verify(attestationRepository).saveAndFlush(attestation);
  }

  @Test
  void testCheckAndUpdateStatus_AllInvalid() {
    Attestation attestation = new Attestation();
    Long attestationId = 3L;
    attestation.setAttestationId(attestationId);

    AttestationFirmStaging staging1 = new AttestationFirmStaging();
    staging1.setAttestationStatusType(AttestationStatusType.INVALID);
    AttestationFirmStaging staging2 = new AttestationFirmStaging();
    staging2.setAttestationStatusType(AttestationStatusType.INVALID);

    attestation.setAttestationFirmStagingList(List.of(staging1, staging2));

    when(attestationRepository.findById(attestationId)).thenReturn(Optional.of(attestation));
    when(attestationRepository.saveAndFlush(any(Attestation.class))).thenReturn(attestation);

    service.checkAndUpdateStatus(attestationId);

    assertEquals(AttestationStatusType.INVALID, attestation.getAttestationStatusType());
    verify(attestationRepository).saveAndFlush(attestation);
  }

  @Test
  void testStatusSystemError() {
    Attestation attestation = new Attestation();
    attestation.setAttestationId(3L);

    AttestationFirmStaging staging1 = new AttestationFirmStaging();
    staging1.setAttestationStatusType(AttestationStatusType.INVALID);
    AttestationFirmStaging staging2 = new AttestationFirmStaging();
    staging2.setAttestationStatusType(AttestationStatusType.SYSTEM_ERROR);

    attestation.setAttestationFirmStagingList(List.of(staging1, staging2));

    when(attestationRepository.findById(3L)).thenReturn(Optional.of(attestation));
    when(attestationRepository.saveAndFlush(any(Attestation.class))).thenReturn(attestation);

    service.checkAndUpdateStatus(3L);

    assertEquals(AttestationStatusType.INVALID, attestation.getAttestationStatusType());
    verify(attestationRepository).saveAndFlush(attestation);
  }

  @Test
  void testStatusInvalid() {
    Attestation attestation = new Attestation();
    attestation.setAttestationId(3L);

    AttestationFirmStaging staging1 = new AttestationFirmStaging();
    staging1.setAttestationStatusType(AttestationStatusType.INVALID);
    AttestationFirmStaging staging2 = new AttestationFirmStaging();
    staging2.setAttestationStatusType(AttestationStatusType.DRAFT);

    attestation.setAttestationFirmStagingList(List.of(staging1, staging2));

    when(attestationRepository.findById(3L)).thenReturn(Optional.of(attestation));
    when(attestationRepository.saveAndFlush(any(Attestation.class))).thenReturn(attestation);

    service.checkAndUpdateStatus(3L);

    assertEquals(AttestationStatusType.INVALID, attestation.getAttestationStatusType());
    verify(attestationRepository).saveAndFlush(attestation);
  }
}
