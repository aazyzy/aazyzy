package ca.bnc.wealth.api.user.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.authorization.system.token.SystemTokenFactory;
import ca.bnc.wealth.api.user.jpa.GenericEmployeeSearchCriteria;
import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.api.user.utils.MockData;
import ca.bnc.wealth.common.authorization.model.FeaturePackageCreateResponse;
import ca.bnc.wealth.common.employee.user_management.model.CreateUserEmployee;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeAssignmentRequest;
import ca.bnc.wealth.common.employee.user_management.model.EmployeePackageRequest;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeGenericSearchResponse;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeUserConfiguration;
import ca.bnc.wealth.common.employee.user_management.model.PatchUserEmployee;
import ca.bnc.wealth.common.employee.user_management.model.PatchUserEmployeeProfile;
import ca.bnc.wealth.common.employee.user_management.model.UpdateUserEmployee;
import ca.bnc.wealth.common.employee.user_management.model.UpdateUserEmployeeProfile;
import ca.bnc.wealth.common.exception.Entity.FumConflictException;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumServiceException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.service.RedisCacheOperationService;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.jpa.entity.enums.AuditEventType;
import ca.bnc.wealth.common.jpa.utils.EnumQueryCriteria;
import org.apache.commons.lang3.tuple.Pair;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.fum.model.UserPreferencesEnum;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.fum.model.UserStateActionEnum;
import ca.bnc.wealth.common.fum.model.UserStateDescriptionEnum;
import ca.bnc.wealth.common.fum.model.UserStateEnum;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackageAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentFeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.Person;
import ca.bnc.wealth.common.jpa.entity.iam.PersonAssignment;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignment;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentFirm;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentRrCodeRange;
import ca.bnc.wealth.common.jpa.repo.iam.FeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PersonAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PersonRepository;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRepository;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import tools.jackson.databind.json.JsonMapper;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jakarta.persistence.EntityManager;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.cache.transaction.TransactionAwareCacheManagerProxy;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.MapPropertySource;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.AbstractPlatformTransactionManager;
import org.springframework.transaction.support.DefaultTransactionStatus;
import org.springframework.transaction.support.TransactionTemplate;

class EmployeeAccessManagementServiceTest {

  private EmployeeAccessManagementService service;
  private IamUserConfigurationRepository iamUserConfigurationRepository;
  private PersonRepository personRepository;
  private PersonAssignmentRepository personAssignmentRepository;
  private UserAssignmentRepository userAssignmentRepository;
  private ResourceRepository resourceRepository;
  private FeaturePackageRepository featurePackageRepository;
  private PackageTemplateRepository packageTemplateRepository;
  private FirmRepository firmRepository;
  private RrCodeService rrCodeService;
  private UserAssignmentService userAssignmentService;
  private AuthorizationClient authorizationClient;
  private SystemTokenFactory systemTokenFactory;
  private AuditLogService auditLogService;
  private ExternalClientService externalClientService;
  private RedisCacheOperationService redisCacheOperationService;
  private EntityManager entityManager;

  private static final String APPLICATION_CX = "CX";
  private static final String STUB_BEARER_TOKEN = "stub-" + UUID.randomUUID();

    private static String randomUsername() {
        return "test-user-" + UUID.randomUUID();
    }

  @BeforeEach
  void setUp() {
    iamUserConfigurationRepository = mock(IamUserConfigurationRepository.class);
    personRepository = mock(PersonRepository.class);
    personAssignmentRepository = mock(PersonAssignmentRepository.class);
    userAssignmentRepository = mock(UserAssignmentRepository.class);
    resourceRepository = mock(ResourceRepository.class);
    featurePackageRepository = mock(FeaturePackageRepository.class);
    packageTemplateRepository = mock(PackageTemplateRepository.class);
    firmRepository = mock(FirmRepository.class);
    rrCodeService = mock(RrCodeService.class);
    userAssignmentService = mock(UserAssignmentService.class);
    authorizationClient = mock(AuthorizationClient.class);
    systemTokenFactory = mock(SystemTokenFactory.class);
    auditLogService = mock(AuditLogService.class);
    externalClientService = mock(ExternalClientService.class);
    redisCacheOperationService = mock(RedisCacheOperationService.class);

    entityManager = mock(EntityManager.class);

    service = new EmployeeAccessManagementService(iamUserConfigurationRepository,
        personRepository, personAssignmentRepository, userAssignmentRepository,
        resourceRepository, featurePackageRepository, packageTemplateRepository, firmRepository,
        rrCodeService, userAssignmentService, authorizationClient,
        systemTokenFactory, auditLogService, externalClientService, redisCacheOperationService);

    ReflectionTestUtils.setField(service, "entityManager", entityManager);

    // Default firm mock used by most create/update tests
    Firm defaultFirm = new Firm();
    defaultFirm.setFirmId("firm-001");
    defaultFirm.setFirmEntityId(100L);
    when(firmRepository.findByFirmId("firm-001")).thenReturn(defaultFirm);

    // Any active-status change now derives the local state from Okta and throws when the profile
    // cannot be read. Default every account to a healthy, fully onboarded Okta profile so tests
    // that are not about Okta are unaffected. Tests asserting a specific derived state override
    // this with stubOktaProfile(..) or cascadeWithOktaProfile(..).
    stubOktaProfile(oktaActiveProfile());
  }

  @Test
  void testGetEmployeesWithPagination_withPersonAssociated() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
        String username = randomUsername();
    userConfig.setSource(APPLICATION_CX);
    userConfig.setUserPreferences(Map.of(UserPreferencesEnum.defaultModule.name(), APPLICATION_CX));
        userConfig.setUsername(username);

    Person person = new Person();
    person.setPersonId(1L);
    person.setFirstName("PersonFirst");
    person.setLastName("PersonLast");
    person.setEmail("person@email.com");
    person.setLanguage(PreferredLanguageType.FR);

    PersonAssignment assignment = new PersonAssignment();
    assignment.setPersonAssignmentId(1L);
    assignment.setPerson(person);
    assignment.setUserId(userConfig.getUserConfigurationId().intValue());

    int pageSize = 10;
    int pageNumber = 1;

    when(iamUserConfigurationRepository.findAll(
        any(ca.bnc.wealth.common.jpa.specification.Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl<>(List.of(userConfig)));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignment));

    EmployeeGenericSearchResponse response = service.getEmployeesWithPagination(pageSize, pageNumber);

    assertEquals(pageSize, response.getPageSize());
    assertEquals(pageNumber, response.getPageNumber());
    assertEquals(1, response.getTotalUsers());

    EmployeeUserConfiguration dto = response.getUsers().get(0);
    assertEquals("PersonFirst", dto.getFirstName());
    assertEquals("PersonLast", dto.getLastName());
    assertEquals("person@email.com", dto.getEmail());
    assertEquals(EmployeeUserConfiguration.LanguageEnum.FR, dto.getLanguage());
    assertEquals(username, dto.getProfile().getShortId());
    assertEquals(APPLICATION_CX, dto.getProfile().getDefaultModule());
    assertEquals(true, dto.getProfile().getActive());
  }

  @Test
  void testGetEmployeesWithPagination_withoutPersonFallsBackToUserConfig() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
        String username = randomUsername();
    userConfig.setSource(APPLICATION_CX);
    userConfig.setUserPreferences(Map.of(UserPreferencesEnum.defaultModule.name(), APPLICATION_CX));
        userConfig.setUsername(username);

    int pageSize = 10;
    int pageNumber = 1;

    when(iamUserConfigurationRepository.findAll(
        any(ca.bnc.wealth.common.jpa.specification.Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl<>(List.of(userConfig)));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());

    EmployeeGenericSearchResponse response = service.getEmployeesWithPagination(pageSize, pageNumber);

    assertEquals(1, response.getTotalUsers());

    EmployeeUserConfiguration dto = response.getUsers().get(0);
    assertEquals(userConfig.getFirstName(), dto.getFirstName());
    assertEquals(userConfig.getLastName(), dto.getLastName());
    assertEquals(userConfig.getEmail(), dto.getEmail());
    assertEquals(userConfig.getPreferredLanguageType().name(), dto.getLanguage().getValue());
    assertEquals(username, dto.getProfile().getShortId());
    assertEquals(APPLICATION_CX, dto.getProfile().getDefaultModule());
  }

  @Test
  void testGetEmployeesWithPagination_nullApplication() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
        userConfig.setUsername(randomUsername());

    int pageSize = 50;
    int pageNumber = 1;

    when(iamUserConfigurationRepository.findAll(
        any(ca.bnc.wealth.common.jpa.specification.Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl<>(List.of(userConfig)));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());

    EmployeeGenericSearchResponse response = service.getEmployeesWithPagination(pageSize, pageNumber);

    assertEquals(pageSize, response.getPageSize());
    assertEquals(pageNumber, response.getPageNumber());
    assertEquals(1, response.getTotalUsers());
  }

  @Test
  void testGetEmployeesWithPagination_emptyResult() {
    int pageSize = 10;
    int pageNumber = 1;

    when(iamUserConfigurationRepository.findAll(
        any(ca.bnc.wealth.common.jpa.specification.Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl<>(List.of()));

    EmployeeGenericSearchResponse response = service.getEmployeesWithPagination(pageSize, pageNumber);

    assertEquals(0, response.getTotalUsers());
    assertNotNull(response.getUsers());
    assertEquals(0, response.getUsers().size());
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetEmployeesWithPagination_alwaysAppliesIdpEmployeeFilter() {
    int pageSize = 50;
    int pageNumber = 1;

    ArgumentCaptor<ca.bnc.wealth.common.jpa.specification.Specification> specCaptor =
        ArgumentCaptor.forClass(ca.bnc.wealth.common.jpa.specification.Specification.class);

    when(iamUserConfigurationRepository.findAll(
        any(ca.bnc.wealth.common.jpa.specification.Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl<>(List.of()));

    service.getEmployeesWithPagination(pageSize, pageNumber);

    verify(iamUserConfigurationRepository).findAll(specCaptor.capture(), any(PageRequest.class));

    Map<String, Pair<EnumQueryCriteria, Object>> fieldValueMap =
        (Map<String, Pair<EnumQueryCriteria, Object>>) ReflectionTestUtils
            .getField(specCaptor.getValue(), "fieldValueMap");

    assertNotNull(fieldValueMap);
    Pair<EnumQueryCriteria, Object> idpCriteria =
        fieldValueMap.get(GenericEmployeeSearchCriteria.IDP.getEntityField());
    assertNotNull(idpCriteria);
    assertEquals(EnumQueryCriteria.IGNORE_CASE_EQUALS, idpCriteria.getKey());
    assertEquals(Constants.IDP_EMP, idpCriteria.getValue());
  }

  @Test
  void testGetEmployeesWithPagination_personWithNullLanguage() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
        String username = randomUsername();
    userConfig.setSource(APPLICATION_CX);
        userConfig.setUsername(username);

    Person person = new Person();
    person.setPersonId(2L);
    person.setFirstName("NoLang");
    person.setLastName("Person");
    person.setEmail("nolang@email.com");
    person.setLanguage(null);

    PersonAssignment assignment = new PersonAssignment();
    assignment.setPersonAssignmentId(2L);
    assignment.setPerson(person);
    assignment.setUserId(userConfig.getUserConfigurationId().intValue());

    when(iamUserConfigurationRepository.findAll(
        any(ca.bnc.wealth.common.jpa.specification.Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl<>(List.of(userConfig)));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignment));

    EmployeeGenericSearchResponse response = service.getEmployeesWithPagination(10, 1);

    EmployeeUserConfiguration dto = response.getUsers().get(0);
    assertEquals("NoLang", dto.getFirstName());
    assertNull(dto.getLanguage());
  }

  @Test
  void testGetEmployeesWithPagination_populatesAssignmentsPackage() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
        String username = randomUsername();
    userConfig.setSource(APPLICATION_CX);
        userConfig.setUsername(username);
    userConfig.setIdpSubject("idp004");

    UserAssignment userAssignment = new UserAssignment();
    userAssignment.setIdpSubject("idp004");
    userAssignment.setAssignmentType(UserAssignmentType.P);
    userAssignment.setAssigneeId(99);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();

    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setPackageTemplate(packageTemplate);

    when(iamUserConfigurationRepository.findAll(
        any(ca.bnc.wealth.common.jpa.specification.Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl<>(List.of(userConfig)));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());
    when(userAssignmentRepository.findFirstByIdpSubjectAndAssignmentType("idp004", UserAssignmentType.P))
        .thenReturn(Optional.of(userAssignment));
    when(featurePackageRepository.findById(99L))
        .thenReturn(Optional.of(featurePackage));

    EmployeeGenericSearchResponse response = service.getEmployeesWithPagination(10, 1);

    EmployeeUserConfiguration dto = response.getUsers().get(0);
    assertNotNull(dto.getProfile().getAssignment());
    assertNotNull(dto.getProfile().getAssignment().getPackage());
    assertEquals(packageTemplate.getName(), dto.getProfile().getAssignment().getPackage().getName());
  }

  @Test
  void testGetEmployeesWithPagination_populatesFeatureSelections() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    String username = randomUsername();
    userConfig.setSource(APPLICATION_CX);
    userConfig.setUsername(username);
    userConfig.setIdpSubject("idp-fs");

    UserAssignment userAssignment = new UserAssignment();
    userAssignment.setIdpSubject("idp-fs");
    userAssignment.setAssignmentType(UserAssignmentType.P);
    userAssignment.setAssigneeId(77);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();

    // Optional, not restricted, selected=true -> included
    Resource optRes = new Resource();
    optRes.setName("OptionalFeature");
    optRes.setRestriction(false);
    PackageTemplateAssignmentResource tpl1 = new PackageTemplateAssignmentResource();
    tpl1.setAssignmentMode(PackageAssignmentMode.O);
    tpl1.setResource(optRes);
    FeaturePackageAssignmentResource fpar1 = new FeaturePackageAssignmentResource();
    fpar1.setSelected(true);
    fpar1.setPackageTemplateAssignmentResource(tpl1);

    // Optional, restricted, selected=false -> included
    Resource restrictedRes = new Resource();
    restrictedRes.setName("RestrictedFeature");
    restrictedRes.setRestriction(true);
    PackageTemplateAssignmentResource tpl2 = new PackageTemplateAssignmentResource();
    tpl2.setAssignmentMode(PackageAssignmentMode.O);
    tpl2.setResource(restrictedRes);
    FeaturePackageAssignmentResource fpar2 = new FeaturePackageAssignmentResource();
    fpar2.setSelected(false);
    fpar2.setPackageTemplateAssignmentResource(tpl2);

    // Optional, not restricted, selected=false -> excluded
    Resource excludedRes = new Resource();
    excludedRes.setName("ExcludedFeature");
    excludedRes.setRestriction(false);
    PackageTemplateAssignmentResource tpl3 = new PackageTemplateAssignmentResource();
    tpl3.setAssignmentMode(PackageAssignmentMode.O);
    tpl3.setResource(excludedRes);
    FeaturePackageAssignmentResource fpar3 = new FeaturePackageAssignmentResource();
    fpar3.setSelected(false);
    fpar3.setPackageTemplateAssignmentResource(tpl3);

    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setPackageTemplate(packageTemplate);
    featurePackage.setFeaturePackageAssignmentResources(List.of(fpar1, fpar2, fpar3));

    when(iamUserConfigurationRepository.findAll(
        any(ca.bnc.wealth.common.jpa.specification.Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl<>(List.of(userConfig)));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());
    when(userAssignmentRepository.findFirstByIdpSubjectAndAssignmentType("idp-fs", UserAssignmentType.P))
        .thenReturn(Optional.of(userAssignment));
    when(featurePackageRepository.findById(77L))
        .thenReturn(Optional.of(featurePackage));

    EmployeeGenericSearchResponse response = service.getEmployeesWithPagination(10, 1);

    EmployeeUserConfiguration dto = response.getUsers().get(0);
    List<String> selections = dto.getProfile().getAssignment().getPackage().getFeatureSelections();
    assertNotNull(selections);
    assertEquals(2, selections.size());
    assertTrue(selections.contains("OptionalFeature"));
    assertTrue(selections.contains("RestrictedFeature"));
  }

  @Test
  void testGetEmployeesWithPagination_populatesFirmRrcodesResources() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setSource(APPLICATION_CX);
    userConfig.setUsername(randomUsername());
    userConfig.setIdpSubject("idp007");
    userConfig.setIdp("IAMi");

    Firm firm = new Firm();
    firm.setFirmId("FIRM001");

    UserAssignmentFirm uaf = new UserAssignmentFirm();
    uaf.setAssignmentType(UserAssignmentType.F);
    uaf.setFirm(firm);
    userConfig.setUserAssignmentFirms(List.of(uaf));

    IamRrCodeRange rrRange = new IamRrCodeRange();
    rrRange.setFromRrCode("AA00");
    rrRange.setToRrCode("BB99");

    UserAssignmentRrCodeRange uarr = new UserAssignmentRrCodeRange();
    uarr.setAssignmentType(UserAssignmentType.R);
    uarr.setIamRrCodeRange(rrRange);
    userConfig.setUserAssignmentRrCodeRanges(List.of(uarr));

    userConfig.setUserAssignmentFeaturePackages(List.of(
        buildFeaturePackageAssignment("MyResource", false, true)));

    when(iamUserConfigurationRepository.findAll(
        any(ca.bnc.wealth.common.jpa.specification.Specification.class), any(PageRequest.class)))
        .thenReturn(new PageImpl<>(List.of(userConfig)));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());

    EmployeeGenericSearchResponse response = service.getEmployeesWithPagination(10, 1);

    EmployeeUserConfiguration dto = response.getUsers().get(0);
    assertNotNull(dto.getProfile().getAssignment());
    assertEquals("FIRM001", dto.getProfile().getAssignment().getFirm());
    assertEquals(1, dto.getProfile().getAssignment().getRrcodes().size());
    assertEquals("AA00-BB99", dto.getProfile().getAssignment().getRrcodes().get(0));
    assertEquals(1, dto.getProfile().getAssignment().getResources().size());
    assertEquals("MyResource", dto.getProfile().getAssignment().getResources().get(0));
  }

  @Test
  void testGetEmployeeUser_foundByIdpSubject() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
        String username = randomUsername();
    userConfig.setSource(APPLICATION_CX);
    userConfig.setUserPreferences(Map.of(UserPreferencesEnum.defaultModule.name(), APPLICATION_CX));
        userConfig.setUsername(username);
        userConfig.setIdpSubject(username);
    userConfig.setIdp("IAMi");
    userConfig.setOssUserId("oss123");
    userConfig.setOssGroupId("grp456");

    Person person = new Person();
    person.setPersonId(1L);
    person.setFirstName("PersonFirst");
    person.setLastName("PersonLast");
    person.setEmail("person@email.com");
    person.setLanguage(PreferredLanguageType.FR);

    PersonAssignment personAssignment = new PersonAssignment();
    personAssignment.setPerson(person);
    personAssignment.setUserId(userConfig.getUserConfigurationId().intValue());

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(username))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(personAssignment));

    EmployeeUserConfiguration dto = service.getEmployeeUser(username);

    assertEquals("PersonFirst", dto.getFirstName());
    assertEquals("PersonLast", dto.getLastName());
    assertEquals("person@email.com", dto.getEmail());
    assertEquals(EmployeeUserConfiguration.LanguageEnum.FR, dto.getLanguage());
    assertEquals(username, dto.getProfile().getShortId());
    assertEquals(APPLICATION_CX, dto.getProfile().getDefaultModule());
    assertNotNull(dto.getLinkedProfiles());
    assertEquals("oss123", dto.getLinkedProfiles().getOss().getUserId());
    assertEquals("grp456", dto.getLinkedProfiles().getOss().getGroupId());
    assertNotNull(dto.getProfile().getAssignment());
  }

  @Test
  void testGetEmployeeUser_fallbackToUsername() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
        String username = randomUsername();
    userConfig.setSource(APPLICATION_CX);
        userConfig.setUsername(username);
    userConfig.setIdpSubject("idp001");
    userConfig.setIdp("IAMi");

        when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(username))
        .thenReturn(Optional.empty());
        when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(username))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());

    EmployeeUserConfiguration dto = service.getEmployeeUser(username);

    assertEquals(userConfig.getFirstName(), dto.getFirstName());
    assertEquals(userConfig.getLastName(), dto.getLastName());
    assertEquals(username, dto.getProfile().getShortId());
  }

  @Test
  void testGetEmployeeUser_notFound() {
    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase("unknown"))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("unknown"))
        .thenReturn(Optional.empty());

    assertThrows(FumNotFoundException.class,
        () -> service.getEmployeeUser("unknown"));
  }

  @Test
  void testGetEmployeeUser_idpNotEmployee_throwsNotFound() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    String username = randomUsername();
    userConfig.setIdp("nbin");
    userConfig.setUsername(username);

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(username))
        .thenReturn(Optional.of(userConfig));

    assertThrows(FumNotFoundException.class,
        () -> service.getEmployeeUser(username));
  }

  @Test
  void testGetEmployeeUser_idpCaseInsensitive_returnsDto() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
        String username = randomUsername();
    userConfig.setSource("ANY");
    userConfig.setIdp("iami");
        userConfig.setUsername(username);

        when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(username))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());

    EmployeeUserConfiguration dto = service.getEmployeeUser(username);

    assertNotNull(dto);
    assertEquals(username, dto.getProfile().getShortId());
  }

  @Test
  void testGetEmployeeUser_populatesPackage() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
        String username = randomUsername();
    userConfig.setSource(APPLICATION_CX);
        userConfig.setUsername(username);
    userConfig.setIdpSubject("idp005");
    userConfig.setIdp("IAMi");

    UserAssignment userAssignment = new UserAssignment();
    userAssignment.setIdpSubject("idp005");
    userAssignment.setAssignmentType(UserAssignmentType.P);
    userAssignment.setAssigneeId(99);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();

    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setPackageTemplate(packageTemplate);

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase("user005"))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());
    when(userAssignmentRepository.findFirstByIdpSubjectAndAssignmentType("idp005", UserAssignmentType.P))
        .thenReturn(Optional.of(userAssignment));
    when(featurePackageRepository.findById(99L))
        .thenReturn(Optional.of(featurePackage));

    EmployeeUserConfiguration dto = service.getEmployeeUser("user005");

    assertNotNull(dto.getProfile().getAssignment());
    assertNotNull(dto.getProfile().getAssignment().getPackage());
    assertEquals(packageTemplate.getName(), dto.getProfile().getAssignment().getPackage().getName());
  }

  @Test
  void testGetEmployeeUser_populatesAssignmentsFirmRrcodesResources() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
        String username = randomUsername();
    userConfig.setSource(APPLICATION_CX);
        userConfig.setUsername(username);
    userConfig.setIdpSubject("idp006");
    userConfig.setIdp("IAMi");

    Firm firm = new Firm();
    firm.setFirmId("FIRM001");

    UserAssignmentFirm uaf = new UserAssignmentFirm();
    uaf.setAssignmentType(UserAssignmentType.F);
    uaf.setFirm(firm);
    userConfig.setUserAssignmentFirms(List.of(uaf));

    IamRrCodeRange rrRange = new IamRrCodeRange();
    rrRange.setFromRrCode("AA00");
    rrRange.setToRrCode("BB99");

    UserAssignmentRrCodeRange uarr = new UserAssignmentRrCodeRange();
    uarr.setAssignmentType(UserAssignmentType.R);
    uarr.setIamRrCodeRange(rrRange);
    userConfig.setUserAssignmentRrCodeRanges(List.of(uarr));

    userConfig.setUserAssignmentFeaturePackages(List.of(
        buildFeaturePackageAssignment("MyResource", false, true)));

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase("user006"))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());

    EmployeeUserConfiguration dto = service.getEmployeeUser("user006");

    assertNotNull(dto.getProfile().getAssignment());
    assertEquals("FIRM001", dto.getProfile().getAssignment().getFirm());
    assertEquals(1, dto.getProfile().getAssignment().getRrcodes().size());
    assertEquals("AA00-BB99", dto.getProfile().getAssignment().getRrcodes().get(0));
    assertEquals(1, dto.getProfile().getAssignment().getResources().size());
    assertEquals("MyResource", dto.getProfile().getAssignment().getResources().get(0));
  }

  @Test
  void testGetEmployeeUser_separatesRestrictedResources() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    String username = randomUsername();
    userConfig.setSource(APPLICATION_CX);
    userConfig.setUsername(username);
    userConfig.setIdpSubject("idp007");
    userConfig.setIdp("IAMi");

    userConfig.setUserAssignmentFeaturePackages(List.of(
        buildFeaturePackageAssignment("MyResource", false, true),
        buildFeaturePackageAssignment("firm_level_access", true, false)));

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase("user007"))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());

    EmployeeUserConfiguration dto = service.getEmployeeUser("user007");

    assertNotNull(dto.getProfile().getAssignment());
    assertEquals(List.of("MyResource"), dto.getProfile().getAssignment().getResources());
    assertEquals(List.of("firm_level_access"),
        dto.getProfile().getAssignment().getRestrictedResources());
  }

  @Test
  void testGetEmployeeUser_rrcodeSameFromTo() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
        String username = randomUsername();
    userConfig.setSource(APPLICATION_CX);
        userConfig.setUsername(username);
    userConfig.setIdpSubject("idp007");
    userConfig.setIdp("IAMi");

    IamRrCodeRange rrRange = new IamRrCodeRange();
    rrRange.setFromRrCode("CC00");
    rrRange.setToRrCode("CC00");

    UserAssignmentRrCodeRange uarr = new UserAssignmentRrCodeRange();
    uarr.setAssignmentType(UserAssignmentType.R);
    uarr.setIamRrCodeRange(rrRange);
    userConfig.setUserAssignmentRrCodeRanges(List.of(uarr));

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase("user007"))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());

    EmployeeUserConfiguration dto = service.getEmployeeUser("user007");

    assertEquals(1, dto.getProfile().getAssignment().getRrcodes().size());
    assertEquals("CC00", dto.getProfile().getAssignment().getRrcodes().get(0));
  }

  @Test
  void testGetEmployeeUser_packageMergedIntoExistingAssignments() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
        String username = randomUsername();
    userConfig.setSource(APPLICATION_CX);
        userConfig.setUsername(username);
    userConfig.setIdpSubject("idp008");
    userConfig.setIdp("IAMi");

    Firm firm = new Firm();
    firm.setFirmId("FIRM002");
    UserAssignmentFirm uaf = new UserAssignmentFirm();
    uaf.setAssignmentType(UserAssignmentType.F);
    uaf.setFirm(firm);
    userConfig.setUserAssignmentFirms(List.of(uaf));

    UserAssignment userAssignment = new UserAssignment();
    userAssignment.setIdpSubject("idp008");
    userAssignment.setAssignmentType(UserAssignmentType.P);
    userAssignment.setAssigneeId(50);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setPackageTemplate(packageTemplate);

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase("user008"))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());
    when(userAssignmentRepository.findFirstByIdpSubjectAndAssignmentType("idp008", UserAssignmentType.P))
        .thenReturn(Optional.of(userAssignment));
    when(featurePackageRepository.findById(50L))
        .thenReturn(Optional.of(featurePackage));

    EmployeeUserConfiguration dto = service.getEmployeeUser("user008");

    assertEquals("FIRM002", dto.getProfile().getAssignment().getFirm());
    assertNotNull(dto.getProfile().getAssignment().getPackage());
    assertEquals(packageTemplate.getName(), dto.getProfile().getAssignment().getPackage().getName());
  }

  @Test
  void testGetEmployeeUser_lastLoginMapped() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
        String username = randomUsername();
    userConfig.setSource(APPLICATION_CX);
        userConfig.setUsername(username);
    userConfig.setIdpSubject("idp009");
    userConfig.setIdp("IAMi");
    userConfig.setLastLoginDate(Timestamp.valueOf("2025-06-15 10:30:00"));

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase("user009"))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());

    EmployeeUserConfiguration dto = service.getEmployeeUser("user009");

    assertNotNull(dto.getProfile().getLastLogin());
    assertEquals(2025, dto.getProfile().getLastLogin().getYear());
    assertEquals(6, dto.getProfile().getLastLogin().getMonthValue());
  }

  @Test
  void testGetEmployeeUser_nullLanguageFallback() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    String username = randomUsername();
    userConfig.setUsername(username);
    userConfig.setIdp("IAMi");
    userConfig.setPreferredLanguageType(null);

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(username))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());

    EmployeeUserConfiguration dto = service.getEmployeeUser(username);

    assertNull(dto.getLanguage());
  }

  @Test
  void testGetEmployeeUser_firmAssignmentWithNullFirm() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    String username = randomUsername();
    userConfig.setUsername(username);
    userConfig.setIdp("IAMi");

    UserAssignmentFirm uaf = new UserAssignmentFirm();
    uaf.setFirm(null);
    userConfig.setUserAssignmentFirms(List.of(uaf));

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(username))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());

    EmployeeUserConfiguration dto = service.getEmployeeUser(username);

    assertNotNull(dto.getProfile().getAssignment());
    assertNull(dto.getProfile().getAssignment().getFirm());
  }

  @Test
  void testGetEmployeeUser_firmResolvedWhenNonFirmRowFirst() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    String username = randomUsername();
    userConfig.setUsername(username);
    userConfig.setIdp("IAMi");

    // The USER_ASSIGNMENT collection returns every assignment type. Simulate a non-firm row
    // (no firm) appearing before the actual firm row; the firm must still be resolved from the
    // type-F row instead of blindly taking the first element.
    UserAssignmentFirm nonFirmRow = new UserAssignmentFirm();
    nonFirmRow.setAssignmentType(UserAssignmentType.S);
    nonFirmRow.setFirm(null);

    Firm firm = new Firm();
    firm.setFirmId("FIRM003");
    UserAssignmentFirm firmRow = new UserAssignmentFirm();
    firmRow.setAssignmentType(UserAssignmentType.F);
    firmRow.setFirm(firm);

    userConfig.setUserAssignmentFirms(List.of(nonFirmRow, firmRow));

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(username))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());

    EmployeeUserConfiguration dto = service.getEmployeeUser(username);

    assertNotNull(dto.getProfile().getAssignment());
    assertEquals("FIRM003", dto.getProfile().getAssignment().getFirm());
  }

  @Test
  void testUpdateAssignments_nullProfile_createsProfileAndAssignment() {
    EmployeeUserConfiguration dto = new EmployeeUserConfiguration();

    UserAssignment userAssignment = new UserAssignment();
    userAssignment.setIdpSubject("reflSubject");
    userAssignment.setAssignmentType(UserAssignmentType.P);
    userAssignment.setAssigneeId(77);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    FeaturePackage featurePackage = new FeaturePackage();
    featurePackage.setPackageTemplate(packageTemplate);

    when(userAssignmentRepository.findFirstByIdpSubjectAndAssignmentType("reflSubject", UserAssignmentType.P))
        .thenReturn(Optional.of(userAssignment));
    when(featurePackageRepository.findById(77L))
        .thenReturn(Optional.of(featurePackage));

    ReflectionTestUtils.invokeMethod(service, "updateAssignments", dto, "reflSubject");

    assertNotNull(dto.getProfile());
    assertNotNull(dto.getProfile().getAssignment());
    assertEquals(packageTemplate.getName(), dto.getProfile().getAssignment().getPackage().getName());
  }

  @Test
  void testCreateEmployee_basicFields() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());
    savedEntity.setUsername(input.getProfile().getShortId());

    Person savedPerson = new Person();
    savedPerson.setPersonId(10L);
    savedPerson.setFirstName(input.getFirstName());
    savedPerson.setLastName(input.getLastName());
    savedPerson.setEmail(input.getEmail());

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);

    service.createEmployee(input, "testUser");

    verify(iamUserConfigurationRepository).save(any(IamUserConfiguration.class));
    verify(personRepository).save(any(Person.class));
    verify(personAssignmentRepository).save(any(PersonAssignment.class));
    verify(packageTemplateRepository, never()).findByType(any());
  }

  @Test
  void testCreateEmployee_withPackages() {
    CreateUserEmployee input = MockData.getCreateUserEmployeeWithAssignments();

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person savedPerson = new Person();
    savedPerson.setPersonId(11L);

    FeaturePackageCreateResponse fpResponse = new FeaturePackageCreateResponse();
    fpResponse.setFeaturePackageId(100L);

    when(packageTemplateRepository.findByType(PackageType.U))
        .thenReturn(List.of(packageTemplate));
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(fpResponse);

    service.createEmployee(input, "testUser");

    verify(iamUserConfigurationRepository).save(any(IamUserConfiguration.class));
    verify(personRepository).save(any(Person.class));
    verify(personAssignmentRepository).save(any(PersonAssignment.class));
    verify(authorizationClient).createFeaturePackage(anyString(), any());
    verify(userAssignmentService).assignFeaturePackageToUser(anyLong(), anyString(), anyLong(), anyString());
  }

  @Test
  void testCreateEmployee_noPackage_nullRrCodes_clearsExistingRrCodes() {
    // When no package is in the request and rrCodes is null, existing RR codes are cleared.
    CreateUserEmployee input = MockData.getCreateUserEmployeeWithAssignments();
    input.getProfile().getAssignment().setRrcodes(null);
    input.getProfile().getAssignment().setPackage(null);

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person savedPerson = new Person();
    savedPerson.setPersonId(11L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);

    service.createEmployee(input, "testUser");

    verify(rrCodeService).assignRrCodesToUser(eq(savedEntity), any(Firm.class), isNull(), anyString(), eq(false));
  }

  @Test
  void testCreateEmployee_nullRrCodes_noFirmLevelAccess_clearsRrCodes() {
    // When rrCodes is null and no firm_level_access, existing RR codes are cleared.
    CreateUserEmployee input = MockData.getCreateUserEmployeeWithAssignments();
    input.getProfile().getAssignment().setRrcodes(null);
    input.getProfile().getAssignment().setPackage(null);

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person savedPerson = new Person();
    savedPerson.setPersonId(11L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);

    service.createEmployee(input, "testUser");

    verify(rrCodeService).assignRrCodesToUser(eq(savedEntity), any(Firm.class), isNull(), anyString(), eq(false));
  }


  @Test
  void testCreateEmployee_firmLevelAccessInFeatureSelections_nullRrCodes_assignsRrCodes() {
    CreateUserEmployee input = MockData.getCreateUserEmployeeWithAssignments();
    input.getProfile().getAssignment().setRrcodes(null);
    input.getProfile().getAssignment().getPackage().setFeatureSelections(List.of("firm_level_access"));

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    Resource flaResource = new Resource();
    flaResource.setName("firm_level_access");
    PackageTemplateAssignmentResource flaPtar = new PackageTemplateAssignmentResource();
    flaPtar.setResource(flaResource);
    packageTemplate.setPackageTemplateAssignmentResources(List.of(flaPtar));


    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person savedPerson = new Person();
    savedPerson.setPersonId(11L);

    FeaturePackageCreateResponse fpResponse = new FeaturePackageCreateResponse();
    fpResponse.setFeaturePackageId(100L);

    when(packageTemplateRepository.findByType(PackageType.U))
        .thenReturn(List.of(packageTemplate));
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(fpResponse);

    service.createEmployee(input, "testUser");

    verify(rrCodeService).assignRrCodesToUser(eq(savedEntity), any(Firm.class), isNull(), anyString(), eq(true));
  }

  @Test
  void testCreateEmployee_firmLevelAccessInFeatureSelections_emptyRrCodes_assignsRrCodes() {
    CreateUserEmployee input = MockData.getCreateUserEmployeeWithAssignments();
    input.getProfile().getAssignment().setRrcodes(List.of());
    input.getProfile().getAssignment().getPackage().setFeatureSelections(List.of("firm_level_access"));

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    Resource flaResource = new Resource();
    flaResource.setName("firm_level_access");
    PackageTemplateAssignmentResource flaPtar = new PackageTemplateAssignmentResource();
    flaPtar.setResource(flaResource);
    packageTemplate.setPackageTemplateAssignmentResources(List.of(flaPtar));


    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person savedPerson = new Person();
    savedPerson.setPersonId(11L);

    FeaturePackageCreateResponse fpResponse = new FeaturePackageCreateResponse();
    fpResponse.setFeaturePackageId(100L);

    when(packageTemplateRepository.findByType(PackageType.U))
        .thenReturn(List.of(packageTemplate));
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(fpResponse);

    service.createEmployee(input, "testUser");

    verify(rrCodeService).assignRrCodesToUser(eq(savedEntity), any(Firm.class), eq(List.of()), anyString(), eq(true));
  }

  @Test
  void testCreateEmployee_noFirmLevelAccessInFeatureSelections_emptyRrCodes_clearsRrCodes() {
    // When package is present but no firm_level_access and rrCodes is empty, clear existing RR codes.
    CreateUserEmployee input = MockData.getCreateUserEmployeeWithAssignments();
    input.getProfile().getAssignment().setRrcodes(List.of());
    input.getProfile().getAssignment().getPackage().setFeatureSelections(List.of("some_other_feature"));

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    Resource otherResource = new Resource();
    otherResource.setName("some_other_feature");
    PackageTemplateAssignmentResource otherPtar = new PackageTemplateAssignmentResource();
    otherPtar.setResource(otherResource);
    packageTemplate.setPackageTemplateAssignmentResources(List.of(otherPtar));


    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person savedPerson = new Person();
    savedPerson.setPersonId(11L);

    FeaturePackageCreateResponse fpResponse = new FeaturePackageCreateResponse();
    fpResponse.setFeaturePackageId(100L);

    when(packageTemplateRepository.findByType(PackageType.U))
        .thenReturn(List.of(packageTemplate));
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(fpResponse);

    service.createEmployee(input, "testUser");

    verify(rrCodeService).assignRrCodesToUser(eq(savedEntity), any(Firm.class), eq(List.of()), anyString(), eq(false));
  }

  @Test
  void testCreateEmployee_firmLevelAccessAndRestrictClientDataAccess_throwsError() {
    CreateUserEmployee input = MockData.getCreateUserEmployeeWithAssignments();
    input.getProfile().getAssignment().setRrcodes(null);
    input.getProfile().getAssignment().getPackage().setFeatureSelections(List.of("firm_level_access"));

    // Build a PackageTemplate that has restrict_client_data_access in its resources
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    Resource flaResource = new Resource();
    flaResource.setName("firm_level_access");
    PackageTemplateAssignmentResource flaPtar = new PackageTemplateAssignmentResource();
    flaPtar.setResource(flaResource);
    Resource restrictResource = new Resource();
    restrictResource.setName("restrict_client_data_access");
    PackageTemplateAssignmentResource restrictPtar = new PackageTemplateAssignmentResource();
    restrictPtar.setResource(restrictResource);
    packageTemplate.setPackageTemplateAssignmentResources(List.of(flaPtar, restrictPtar));

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person savedPerson = new Person();
    savedPerson.setPersonId(11L);

    FeaturePackageCreateResponse fpResponse = new FeaturePackageCreateResponse();
    fpResponse.setFeaturePackageId(100L);

    when(packageTemplateRepository.findByType(PackageType.U))
        .thenReturn(List.of(packageTemplate));
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(fpResponse);

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.createEmployee(input, "testUser"));
    assertEquals(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS, ex.getCode());
    verify(rrCodeService, never()).assignRrCodesToUser(any(), any(), any(), any(), anyBoolean());
  }

  @Test
  void testCreateEmployee_validRrCodes_firmLevelAccess_assignsAllFirmRrCodes() {
    // When firm_level_access is true, provided valid rrCodes are ignored — all firm RR codes are assigned.
    CreateUserEmployee input = MockData.getCreateUserEmployeeWithAssignments();
    input.getProfile().getAssignment().setRrcodes(List.of("RR001", "RR002"));
    input.getProfile().getAssignment().getPackage().setFeatureSelections(List.of("firm_level_access"));

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    Resource flaResource = new Resource();
    flaResource.setName("firm_level_access");
    PackageTemplateAssignmentResource flaPtar = new PackageTemplateAssignmentResource();
    flaPtar.setResource(flaResource);
    packageTemplate.setPackageTemplateAssignmentResources(List.of(flaPtar));

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person savedPerson = new Person();
    savedPerson.setPersonId(11L);

    FeaturePackageCreateResponse fpResponse = new FeaturePackageCreateResponse();
    fpResponse.setFeaturePackageId(100L);

    when(packageTemplateRepository.findByType(PackageType.U))
        .thenReturn(List.of(packageTemplate));
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(fpResponse);

    service.createEmployee(input, "testUser");

    // firm_level_access=true is passed so downstream assigns all firm RR codes
    verify(rrCodeService).assignRrCodesToUser(eq(savedEntity), any(Firm.class),
        eq(List.of("RR001", "RR002")), anyString(), eq(true));
  }

  @Test
  void testCreateEmployee_invalidRrCodes_firmLevelAccess_assignsAllFirmRrCodes() {
    // When firm_level_access is true, provided invalid rrCodes are ignored — all firm RR codes are assigned.
    CreateUserEmployee input = MockData.getCreateUserEmployeeWithAssignments();
    input.getProfile().getAssignment().setRrcodes(List.of("INVALID_CODE"));
    input.getProfile().getAssignment().getPackage().setFeatureSelections(List.of("firm_level_access"));

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    Resource flaResource = new Resource();
    flaResource.setName("firm_level_access");
    PackageTemplateAssignmentResource flaPtar = new PackageTemplateAssignmentResource();
    flaPtar.setResource(flaResource);
    packageTemplate.setPackageTemplateAssignmentResources(List.of(flaPtar));

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person savedPerson = new Person();
    savedPerson.setPersonId(11L);

    FeaturePackageCreateResponse fpResponse = new FeaturePackageCreateResponse();
    fpResponse.setFeaturePackageId(100L);

    when(packageTemplateRepository.findByType(PackageType.U))
        .thenReturn(List.of(packageTemplate));
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(fpResponse);

    service.createEmployee(input, "testUser");

    // firm_level_access=true is passed so downstream ignores invalid rrCodes and assigns all firm RR codes
    verify(rrCodeService).assignRrCodesToUser(eq(savedEntity), any(Firm.class),
        eq(List.of("INVALID_CODE")), anyString(), eq(true));
  }
  @Test
  void testCreateEmployee_nullInput() {
    assertThrows(FumValidationException.class, () -> service.createEmployee(null, "testUser"));
  }

  @Test
  void testCreateEmployee_nullDefaultModule_storesNullPreference() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setDefaultModule(null);

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());
    savedEntity.setUsername(input.getProfile().getShortId());

    Person savedPerson = new Person();
    savedPerson.setPersonId(10L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);

    service.createEmployee(input, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(e ->
        e.getUserPreferences() != null
            && e.getUserPreferences().containsKey("defaultModule")
            && e.getUserPreferences().get("defaultModule") == null));
  }

  @Test
  void testCreateEmployee_invalidDefaultModule_throwsValidation() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setDefaultModule("not_a_real_module");

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.createEmployee(input, "testUser"));
    assertTrue(ex.getMessage().contains("Invalid default module"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testCreateEmployee_invalidLanguage_throwsValidation() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.setLanguage("ENzzz");

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.createEmployee(input, "testUser"));
    assertEquals("error.create.employee.language", ex.getCode());
    assertEquals("Invalid language", ex.getMessage());
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testCreateEmployee_duplicateShortId() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();

    IamUserConfiguration existingUser = new IamUserConfiguration();
    existingUser.setIdpSubject(input.getProfile().getShortId());
    existingUser.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.of(existingUser));

    assertThrows(FumConflictException.class, () -> service.createEmployee(input, "testUser"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testCreateEmployee_duplicateEmail_existingEmpUser() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();

    Person existingPerson = new Person();
    existingPerson.setPersonId(10L);
    existingPerson.setEmail(input.getEmail());

    IamUserConfiguration existingUser = new IamUserConfiguration();
    existingUser.setEmail(input.getEmail());
    existingUser.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.of(existingUser));
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.of(existingPerson));

    FumConflictException ex = assertThrows(FumConflictException.class,
        () -> service.createEmployee(input, "testUser"));
    assertTrue(ex.getMessage().contains(input.getProfile().getShortId()));
    verify(iamUserConfigurationRepository, never()).save(any());
    verify(personRepository, never()).save(any(Person.class));
  }

  @Test
  void testCreateEmployee_existingPersonWithNonEmpUser() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person existingPerson = new Person();
    existingPerson.setPersonId(10L);
    existingPerson.setEmail(input.getEmail());

    IamUserConfiguration existingNonEmpUser = new IamUserConfiguration();
    existingNonEmpUser.setEmail(input.getEmail());
    existingNonEmpUser.setIdp("okta");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmailIgnoreCase(input.getEmail()))
        .thenReturn(Optional.of(existingPerson));
    when(iamUserConfigurationRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.of(existingNonEmpUser));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);

    service.createEmployee(input, "testUser");

    verify(iamUserConfigurationRepository).save(any(IamUserConfiguration.class));
    verify(personRepository, never()).save(any(Person.class));
    verify(personAssignmentRepository).save(any(PersonAssignment.class));
  }

  @Test
  void testCreateEmployee_emailAlreadyLinkedToAnEmployee_throwsValidation() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();

    Person existingPerson = new Person();
    existingPerson.setPersonId(10L);
    existingPerson.setEmail(input.getEmail().toLowerCase());

    IamUserConfiguration linkedEmpUser = new IamUserConfiguration();
    linkedEmpUser.setIdp(Constants.IDP_EMP);

    PersonAssignment empLink = new PersonAssignment();
    empLink.setPerson(existingPerson);
    empLink.setUserId(555);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmailIgnoreCase(input.getEmail()))
        .thenReturn(Optional.of(existingPerson));
    when(personAssignmentRepository.findAllByPersonPersonId(10L))
        .thenReturn(List.of(empLink));
    when(iamUserConfigurationRepository.findById(555L))
        .thenReturn(Optional.of(linkedEmpUser));

    assertThrows(FumValidationException.class, () -> service.createEmployee(input, "testUser"));
    verify(iamUserConfigurationRepository, never()).save(any(IamUserConfiguration.class));
    verify(personRepository, never()).save(any(Person.class));
  }

  @Test
  void testCreateEmployee_invalidPackage() {
    CreateUserEmployee input = MockData.getCreateUserEmployeeWithAssignments();

    when(packageTemplateRepository.findByType(PackageType.U))
        .thenReturn(List.of());

    assertThrows(FumValidationException.class, () -> service.createEmployee(input, "testUser"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testCreateEmployee_missingShortId() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setShortId(null);
    assertThrows(FumValidationException.class, () -> service.createEmployee(input, "testUser"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testCreateEmployee_missingFirstName() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.setFirstName(null);
    assertThrows(FumValidationException.class, () -> service.createEmployee(input, "testUser"));
  }

  @Test
  void testCreateEmployee_blankFirstName() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.setFirstName("   ");
    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.createEmployee(input, "testUser"));
    assertEquals(Constants.EMPLOYEE_REQUIRED_FIELD_CODE, ex.getCode());
    assertTrue(ex.getMessage().contains("firstName"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testCreateEmployee_missingLastName() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.setLastName(null);
    assertThrows(FumValidationException.class, () -> service.createEmployee(input, "testUser"));
  }

  @Test
  void testCreateEmployee_blankLastName() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.setLastName("");
    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.createEmployee(input, "testUser"));
    assertEquals(Constants.EMPLOYEE_REQUIRED_FIELD_CODE, ex.getCode());
    assertTrue(ex.getMessage().contains("lastName"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testCreateEmployee_missingEmail() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.setEmail(null);
    assertThrows(FumValidationException.class, () -> service.createEmployee(input, "testUser"));
  }

  @Test
  void testCreateEmployee_missingLanguage() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.setLanguage(null);
    assertThrows(FumValidationException.class, () -> service.createEmployee(input, "testUser"));
  }

  @Test
  void testCreateEmployee_blankShortId() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setShortId("  ");
    assertThrows(FumValidationException.class, () -> service.createEmployee(input, "testUser"));
  }

  // --- Existing person, no existing user config by email ---

  @Test
  void testCreateEmployee_existingPersonNoExistingUserConfig() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person existingPerson = new Person();
    existingPerson.setPersonId(10L);
    existingPerson.setEmail(input.getEmail());

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmailIgnoreCase(input.getEmail()))
        .thenReturn(Optional.of(existingPerson));
    when(iamUserConfigurationRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);

    service.createEmployee(input, "testUser");

    verify(iamUserConfigurationRepository).save(any(IamUserConfiguration.class));
    verify(personRepository, never()).save(any(Person.class));
    verify(personAssignmentRepository).save(any(PersonAssignment.class));
  }

  // --- Assignments present but packages empty or null ---

  @Test
  void testCreateEmployee_assignmentsWithEmptyPackages() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    EmployeeAssignmentRequest assignments = new EmployeeAssignmentRequest();
    assignments.setFirm("firm-001");
    assignments.setPackage(null);
    input.getProfile().setAssignment(assignments);

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person savedPerson = new Person();
    savedPerson.setPersonId(10L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);

    service.createEmployee(input, "testUser");

    verify(iamUserConfigurationRepository).save(any(IamUserConfiguration.class));
    verify(packageTemplateRepository, never()).findByType(any());
  }

  @Test
  void testCreateEmployee_assignmentsWithNullPackages() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    EmployeeAssignmentRequest assignments = new EmployeeAssignmentRequest();
    assignments.setFirm("firm-001");
    assignments.setPackage(null);
    input.getProfile().setAssignment(assignments);

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person savedPerson = new Person();
    savedPerson.setPersonId(10L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);

    service.createEmployee(input, "testUser");

    verify(iamUserConfigurationRepository).save(any(IamUserConfiguration.class));
    verify(packageTemplateRepository, never()).findByType(any());
  }

  // --- Feature package creation exception propagation ---

  @Test
  void testCreateEmployee_createFeaturePackageThrowsException() {
    CreateUserEmployee input = MockData.getCreateUserEmployeeWithAssignments();
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person savedPerson = new Person();
    savedPerson.setPersonId(11L);

    when(packageTemplateRepository.findByType(PackageType.U))
        .thenReturn(List.of(packageTemplate));
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenThrow(new RuntimeException("Authorization service unavailable"));

    assertThrows(RuntimeException.class, () -> service.createEmployee(input, "testUser"));
  }

  // --- Existing person with non-emp user and packages ---

  @Test
  void testCreateEmployee_existingPersonWithNonEmpUser_withPackages() {
    CreateUserEmployee input = MockData.getCreateUserEmployeeWithAssignments();
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person existingPerson = new Person();
    existingPerson.setPersonId(10L);
    existingPerson.setEmail(input.getEmail());

    IamUserConfiguration existingNonEmpUser = new IamUserConfiguration();
    existingNonEmpUser.setEmail(input.getEmail());
    existingNonEmpUser.setIdp("okta");

    FeaturePackageCreateResponse fpResponse = new FeaturePackageCreateResponse();
    fpResponse.setFeaturePackageId(100L);

    when(packageTemplateRepository.findByType(PackageType.U))
        .thenReturn(List.of(packageTemplate));
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmailIgnoreCase(input.getEmail()))
        .thenReturn(Optional.of(existingPerson));
    when(iamUserConfigurationRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.of(existingNonEmpUser));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(fpResponse);

    service.createEmployee(input, "testUser");

    verify(iamUserConfigurationRepository).save(any(IamUserConfiguration.class));
    verify(personRepository, never()).save(any(Person.class));
    verify(personAssignmentRepository).save(any(PersonAssignment.class));
    verify(authorizationClient).createFeaturePackage(anyString(), any());
    verify(userAssignmentService).assignFeaturePackageToUser(anyLong(), anyString(), anyLong(), anyString());
  }

  // --- Direct tests on @VisibleForTesting methods ---

  @Test
  void testCreatePerson_nullLanguage() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.setLanguage(null);

    Person savedPerson = new Person();
    savedPerson.setPersonId(20L);
    savedPerson.setFirstName(input.getFirstName());
    savedPerson.setLastName(input.getLastName());
    savedPerson.setEmail(input.getEmail());

    when(personRepository.save(any(Person.class))).thenReturn(savedPerson);

    Person result = service.createPerson(input, "testUser");

    assertNotNull(result);
    assertEquals(20L, result.getPersonId());
    verify(personRepository).save(any(Person.class));
  }

  @Test
  void testCreatePerson_setsAllFields() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();

    when(personRepository.save(any(Person.class))).thenAnswer(invocation -> {
      Person p = invocation.getArgument(0);
      p.setPersonId(30L);
      return p;
    });

    Person result = service.createPerson(input, "testUser");

    assertEquals(input.getFirstName(), result.getFirstName());
    assertEquals(input.getLastName(), result.getLastName());
    assertEquals(input.getEmail(), result.getEmail());
    assertEquals(PreferredLanguageType.EN, result.getLanguage());
    assertEquals("testUser", result.getCreatedBy());
    assertNotNull(result.getCreatedDt());
  }

  @Test
  void testCreatePersonAssignment_setsAllFields() {
    Person person = new Person();
    person.setPersonId(10L);

    IamUserConfiguration userConfig = new IamUserConfiguration();
    userConfig.setUserConfigurationId(50L);
    userConfig.setIdpSubject("short001");

    when(personAssignmentRepository.save(any(PersonAssignment.class))).thenAnswer(invocation -> {
      PersonAssignment pa = invocation.getArgument(0);
      return pa;
    });

    service.createPersonAssignment(person, userConfig, "testUser");

    verify(personAssignmentRepository).save(argThat(pa ->
        pa.getPerson().equals(person)
            && pa.getUserId() == 50
            && "testUser".equals(pa.getCreatedBy())
            && pa.getCreatedDt() != null
    ));
  }

  @Test
  void testAssignUserToPackageTemplate_featurePackageCreateReturnsNull_throwsValidation() {
    IamUserConfiguration user = new IamUserConfiguration();
    user.setIdpSubject("short001");
    user.setUserConfigurationId(50L);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();

    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(null);

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.assignUserToPackageTemplate(user, packageTemplate, null, "testUser"));
    assertEquals(Constants.EMPLOYEE_ASSIGNMENTS_FAILED, ex.getCode());

    verify(authorizationClient).createFeaturePackage(anyString(), any());
    verify(userAssignmentService, never()).assignFeaturePackageToUser(anyLong(), anyString(), anyLong(), anyString());
    verify(userAssignmentService, never()).assignResourceToUser(anyLong(), anyString(), anyLong(), anyString());
  }

  @Test
  void testAssignUserToPackageTemplate_noSelections_assignsFullPackage() {
    IamUserConfiguration user = new IamUserConfiguration();
    user.setIdpSubject("short001");
    user.setUserConfigurationId(50L);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();

    FeaturePackageCreateResponse fpResponse = new FeaturePackageCreateResponse();
    fpResponse.setFeaturePackageId(100L);

    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(fpResponse);

    service.assignUserToPackageTemplate(user, packageTemplate, null, "testUser");

    verify(authorizationClient).createFeaturePackage(anyString(), any());
    verify(userAssignmentService).assignFeaturePackageToUser(anyLong(), anyString(), anyLong(), anyString());
    verify(userAssignmentService, never()).assignResourceToUser(anyLong(), anyString(), anyLong(), anyString());
  }

  @Test
  void testAssignUserToPackageTemplate_withSelections_assignsMatchingResource() {
    IamUserConfiguration user = new IamUserConfiguration();
    user.setIdpSubject("short001");
    user.setUserConfigurationId(50L);

    Resource resource = new Resource();
    resource.setName("res-A");
    resource.setResourceId(77L);
    PackageTemplateAssignmentResource ptar = new PackageTemplateAssignmentResource();
    ptar.setResource(resource);
    ptar.setAssignmentMode(PackageAssignmentMode.O);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(List.of(ptar));

    FeaturePackageCreateResponse fpResponse = new FeaturePackageCreateResponse();
    fpResponse.setFeaturePackageId(100L);

    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(fpResponse);

    service.assignUserToPackageTemplate(user, packageTemplate, List.of("res-A"), "testUser");

    verify(authorizationClient).createFeaturePackage(anyString(), any());
    // Selections are now conveyed inside the feature package payload, not as separate resource
    // assignments, so assignResourceToUser is never called from assignUserToPackageTemplate.
    verify(userAssignmentService, never()).assignResourceToUser(anyLong(), anyString(), anyLong(), anyString());
    verify(userAssignmentService).assignFeaturePackageToUser(eq(50L), eq("short001"), eq(100L), eq("testUser"));
  }

  @Test
  void testAssignPackageResources_mandatoryNotInSelections_stillAssigned() {
    IamUserConfiguration user = new IamUserConfiguration();
    user.setIdpSubject("short001");
    user.setUserConfigurationId(50L);

    Resource optional = new Resource();
    optional.setName("res-OPT");
    optional.setResourceId(11L);
    optional.setRestriction(true);
    PackageTemplateAssignmentResource optionalAr = new PackageTemplateAssignmentResource();
    optionalAr.setResource(optional);
    optionalAr.setAssignmentMode(PackageAssignmentMode.O);

    Resource mandatory = new Resource();
    mandatory.setName("res-MAND");
    mandatory.setResourceId(22L);
    PackageTemplateAssignmentResource mandatoryAr = new PackageTemplateAssignmentResource();
    mandatoryAr.setResource(mandatory);
    mandatoryAr.setAssignmentMode(PackageAssignmentMode.M);
    mandatoryAr.setSelectionDefault(true);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(List.of(optionalAr, mandatoryAr));

    service.assignPackageResources(user, packageTemplate, List.of("res-OPT"));

    // Selected optional resource with restriction=true is assigned, and the mandatory resource is assigned even though it was not selected.
    verify(userAssignmentService).assignResourceToUser(eq(50L), eq("short001"), eq(11L), eq("short001"));
    verify(userAssignmentService).assignResourceToUser(eq(50L), eq("short001"), eq(22L), eq("short001"));
  }

  @Test
  void testAssignPackageResources_mandatoryAlsoSelected_assignedOnce() {
    IamUserConfiguration user = new IamUserConfiguration();
    user.setIdpSubject("short001");
    user.setUserConfigurationId(50L);

    Resource mandatory = new Resource();
    mandatory.setName("res-MAND");
    mandatory.setResourceId(22L);
    PackageTemplateAssignmentResource mandatoryAr = new PackageTemplateAssignmentResource();
    mandatoryAr.setResource(mandatory);
    mandatoryAr.setAssignmentMode(PackageAssignmentMode.M);
    mandatoryAr.setSelectionDefault(true);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(List.of(mandatoryAr));

    service.assignPackageResources(user, packageTemplate, List.of("res-MAND"));

    // A resource that is both selected and mandatory is assigned exactly once.
    verify(userAssignmentService, times(1))
        .assignResourceToUser(eq(50L), eq("short001"), eq(22L), eq("short001"));
  }

  @Test
  void testAssignPackageResources_sameNameMandatoryAndOptional_bothAssigned() {
    IamUserConfiguration user = new IamUserConfiguration();
    user.setIdpSubject("short001");
    user.setUserConfigurationId(50L);

    // Same resource name, two template entries: one mandatory (M), one optional (O).
    Resource mandatory = new Resource();
    mandatory.setName("res-DUP");
    mandatory.setResourceId(22L);
    PackageTemplateAssignmentResource mandatoryAr = new PackageTemplateAssignmentResource();
    mandatoryAr.setResource(mandatory);
    mandatoryAr.setAssignmentMode(PackageAssignmentMode.M);
    mandatoryAr.setSelectionDefault(true);

    Resource optional = new Resource();
    optional.setName("res-DUP");
    optional.setResourceId(23L);
    optional.setRestriction(true);
    PackageTemplateAssignmentResource optionalAr = new PackageTemplateAssignmentResource();
    optionalAr.setResource(optional);
    optionalAr.setAssignmentMode(PackageAssignmentMode.O);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(List.of(mandatoryAr, optionalAr));

    // res-DUP is selected -> mandatory entry assigned (always) AND optional entry assigned (selected + restriction=true).
    service.assignPackageResources(user, packageTemplate, List.of("res-DUP"));

    verify(userAssignmentService).assignResourceToUser(eq(50L), eq("short001"), eq(22L), eq("short001"));
    verify(userAssignmentService).assignResourceToUser(eq(50L), eq("short001"), eq(23L), eq("short001"));
  }

  @Test
  void testAssignPackageResources_noSelections_assignsOnlyMandatory() {
    IamUserConfiguration user = new IamUserConfiguration();
    user.setIdpSubject("short001");
    user.setUserConfigurationId(50L);

    Resource optional = new Resource();
    optional.setName("res-OPT");
    optional.setResourceId(11L);
    PackageTemplateAssignmentResource optionalAr = new PackageTemplateAssignmentResource();
    optionalAr.setResource(optional);
    optionalAr.setAssignmentMode(PackageAssignmentMode.O);

    Resource mandatory = new Resource();
    mandatory.setName("res-MAND");
    mandatory.setResourceId(22L);
    PackageTemplateAssignmentResource mandatoryAr = new PackageTemplateAssignmentResource();
    mandatoryAr.setResource(mandatory);
    mandatoryAr.setAssignmentMode(PackageAssignmentMode.M);
    mandatoryAr.setSelectionDefault(true);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(List.of(optionalAr, mandatoryAr));

    // No featureSelections -> only the mandatory resource is assigned.
    service.assignPackageResources(user, packageTemplate, null);

    verify(userAssignmentService).assignResourceToUser(eq(50L), eq("short001"), eq(22L), eq("short001"));
    verify(userAssignmentService, never())
        .assignResourceToUser(eq(50L), eq("short001"), eq(11L), eq("short001"));
  }

  @Test
  void testAssignPackageResources_mandatoryNotSelectionDefault_notAssigned() {
    IamUserConfiguration user = new IamUserConfiguration();
    user.setIdpSubject("short001");
    user.setUserConfigurationId(50L);

    // Mandatory (M) mode but selectionDefault=false -> must NOT be assigned.
    Resource mandatory = new Resource();
    mandatory.setName("res-MAND");
    mandatory.setResourceId(22L);
    PackageTemplateAssignmentResource mandatoryAr = new PackageTemplateAssignmentResource();
    mandatoryAr.setResource(mandatory);
    mandatoryAr.setAssignmentMode(PackageAssignmentMode.M);
    mandatoryAr.setSelectionDefault(false);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(List.of(mandatoryAr));

    service.assignPackageResources(user, packageTemplate, List.of("res-MAND"));

    verify(userAssignmentService, never())
        .assignResourceToUser(anyLong(), anyString(), anyLong(), anyString());
  }

  @Test
  void testAssignPackageResources_optionalSelectionDefault_notAssignedEvenWhenSelected() {
    IamUserConfiguration user = new IamUserConfiguration();
    user.setIdpSubject("short001");
    user.setUserConfigurationId(50L);

    // Optional (O) mode but selectionDefault=true -> must NOT be assigned even when selected.
    Resource optional = new Resource();
    optional.setName("res-OPT");
    optional.setResourceId(11L);
    PackageTemplateAssignmentResource optionalAr = new PackageTemplateAssignmentResource();
    optionalAr.setResource(optional);
    optionalAr.setAssignmentMode(PackageAssignmentMode.O);
    optionalAr.setSelectionDefault(true);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(List.of(optionalAr));

    service.assignPackageResources(user, packageTemplate, List.of("res-OPT"));

    verify(userAssignmentService, never())
        .assignResourceToUser(anyLong(), anyString(), anyLong(), anyString());
  }

  @Test
  void testAssignPackageResources_nullResource_skipped() {
    IamUserConfiguration user = new IamUserConfiguration();
    user.setIdpSubject("short001");
    user.setUserConfigurationId(50L);

    PackageTemplateAssignmentResource nullResourceAr = new PackageTemplateAssignmentResource();
    nullResourceAr.setAssignmentMode(PackageAssignmentMode.M);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(List.of(nullResourceAr));

    service.assignPackageResources(user, packageTemplate, List.of());

    // An assignment with a null resource is skipped without assigning anything.
    verify(userAssignmentService, never())
        .assignResourceToUser(anyLong(), anyString(), anyLong(), anyString());
  }

  @Test
  void testAssignPackageResources_nullTemplateResources_skips() {
    IamUserConfiguration user = new IamUserConfiguration();
    user.setIdpSubject("short001");
    user.setUserConfigurationId(50L);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(null);

    service.assignPackageResources(user, packageTemplate, List.of("res-X"));

    // No template resources -> nothing is assigned and the unknown selection is skipped.
    verify(userAssignmentService, never())
        .assignResourceToUser(anyLong(), anyString(), anyLong(), anyString());
  }

  @Test
  void testCreateFeaturePackage_success() {
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();

    FeaturePackageCreateResponse fpResponse = new FeaturePackageCreateResponse();
    fpResponse.setFeaturePackageId(200L);

    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(fpResponse);

    FeaturePackageCreateResponse result = service.createFeaturePackage(packageTemplate, null, "short001");

    assertNotNull(result);
    assertEquals(200L, result.getFeaturePackageId());
  }

  @Test
  void testCreateFeaturePackage_throwsException() {
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();

    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenThrow(new RuntimeException("Service unavailable"));

    assertThrows(RuntimeException.class,
        () -> service.createFeaturePackage(packageTemplate, null, "short001"));
  }

  @Test
  void testCreateFeaturePackage_sendsOnlyPackageTemplateIdAndAssignments() {
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(List.of(
        assignmentResource(1L, "res-M", 11L, PackageAssignmentMode.M),
        assignmentResource(2L, "res-O", 22L, PackageAssignmentMode.O)));

    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(new FeaturePackageCreateResponse());

    service.createFeaturePackage(packageTemplate, null, "short001");

    ca.bnc.wealth.common.userconfiguration.model.FeaturePackage sent = captureSentFeaturePackage();
    // Only packageTemplateId and assignments are populated.
    assertEquals(1, sent.getPackageTemplateId().intValue());
    assertNull(sent.getPackageName());
    assertNull(sent.getModuleOverrides());
    assertNull(sent.getFeatures());
    assertEquals(2, sent.getAssignments().size());
  }

  @Test
  void testCreateFeaturePackage_mandatorySelectedOptionalNotSelected() {
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(List.of(
        assignmentResource(1L, "res-M", 11L, PackageAssignmentMode.M),
        assignmentResource(2L, "res-O", 22L, PackageAssignmentMode.O)));

    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(new FeaturePackageCreateResponse());

    // No selections: M -> true. O res-O was not requested, so selected = false.
    service.createFeaturePackage(packageTemplate, null, "short001");

    List<ca.bnc.wealth.common.userconfiguration.model.PackageTemplateAssignment> assignments =
        captureSentFeaturePackage().getAssignments();
    assertEquals(Boolean.TRUE, selectedFor(assignments, 1));
    assertEquals(Boolean.FALSE, selectedFor(assignments, 2));
  }

  @Test
  void testCreateFeaturePackage_optionalSelectedWithMatchingMandatory_isTrue() {
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(List.of(
        assignmentResource(1L, "res-X", 11L, PackageAssignmentMode.M),   // same name as O below
        assignmentResource(2L, "res-X", 22L, PackageAssignmentMode.O),   // O + matching M, requested -> false
        assignmentResource(3L, "res-Y", 33L, PackageAssignmentMode.O))); // O only, requested -> true

    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(new FeaturePackageCreateResponse());

    service.createFeaturePackage(packageTemplate, List.of("res-X", "res-Y"), "short001");

    List<ca.bnc.wealth.common.userconfiguration.model.PackageTemplateAssignment> assignments =
        captureSentFeaturePackage().getAssignments();
    assertEquals(3, assignments.size());
    assertEquals(Boolean.TRUE, selectedFor(assignments, 1));   // M always true
    assertEquals(Boolean.TRUE, selectedFor(assignments, 2));   // O requested -> true
    assertEquals(Boolean.TRUE, selectedFor(assignments, 3));   // O requested -> true
  }

  @Test
  void testCreateFeaturePackage_optionalWithMatchingMandatoryButNotSelected_isFalse() {
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(List.of(
        assignmentResource(1L, "res-X", 11L, PackageAssignmentMode.M),
        assignmentResource(2L, "res-X", 22L, PackageAssignmentMode.O)));

    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(new FeaturePackageCreateResponse());

    // res-X not in selections: O entry was not requested, so selected = false.
    service.createFeaturePackage(packageTemplate, List.of(), "short001");

    List<ca.bnc.wealth.common.userconfiguration.model.PackageTemplateAssignment> assignments =
        captureSentFeaturePackage().getAssignments();
    assertEquals(Boolean.TRUE, selectedFor(assignments, 1));
    assertEquals(Boolean.FALSE, selectedFor(assignments, 2));
  }

  @Test
  void testCreateFeaturePackage_nullResourceEntry_stillEmittedFromMode() {
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    PackageTemplateAssignmentResource nullResource = new PackageTemplateAssignmentResource();
    nullResource.setTemplateAssignmentId(99L);
    nullResource.setAssignmentMode(PackageAssignmentMode.M);
    packageTemplate.setPackageTemplateAssignmentResources(List.of(
        nullResource,
        assignmentResource(1L, "res-M", 11L, PackageAssignmentMode.M)));

    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(new FeaturePackageCreateResponse());

    service.createFeaturePackage(packageTemplate, null, "short001");

    List<ca.bnc.wealth.common.userconfiguration.model.PackageTemplateAssignment> assignments =
        captureSentFeaturePackage().getAssignments();
    // Every template row must produce an entry (authorization-api counts them all);
    // a null resource on an M row is still emitted as selected.
    assertEquals(2, assignments.size());
    assertEquals(Boolean.TRUE, selectedFor(assignments, 1));
    assertEquals(Boolean.TRUE, selectedFor(assignments, 99));
  }

  @Test
  void testCreateFeaturePackage_nullTemplateResources_sendsEmptyAssignments() {
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(null);

    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(new FeaturePackageCreateResponse());

    service.createFeaturePackage(packageTemplate, List.of("res-X"), "short001");

    ca.bnc.wealth.common.userconfiguration.model.FeaturePackage sent = captureSentFeaturePackage();
    assertEquals(1, sent.getPackageTemplateId().intValue());
    assertTrue(sent.getAssignments().isEmpty());
  }

  @Test
  void testCreateFeaturePackage_includesUserGroupAssignments() {
    // Both resource (S) and user-group (G) rows live in the same PACKAGE_TEMPLATE_DETAILS
    // collection returned by getPackageTemplateAssignmentResources().
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(List.of(
        assignmentResource(1L, "res-M", 11L, PackageAssignmentMode.M),
        userGroupDetail(2L, PackageAssignmentMode.M),
        userGroupDetail(3L, PackageAssignmentMode.O)));

    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(new FeaturePackageCreateResponse());

    service.createFeaturePackage(packageTemplate, null, "short001");

    List<ca.bnc.wealth.common.userconfiguration.model.PackageTemplateAssignment> assignments =
        captureSentFeaturePackage().getAssignments();
    // Exactly one entry per detail row; user groups (G) are always selected.
    assertEquals(3, assignments.size());
    assertEquals(Boolean.TRUE, selectedFor(assignments, 1));   // M resource
    assertEquals(Boolean.TRUE, selectedFor(assignments, 2));   // M user group
    assertEquals(Boolean.TRUE, selectedFor(assignments, 3));   // O user group - still selected
  }

  @Test
  void testCreateFeaturePackage_allUserGroupsSelectedRegardlessOfMode() {
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(List.of(
        userGroupDetail(1L, PackageAssignmentMode.M),
        userGroupDetail(2L, PackageAssignmentMode.O)));

    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(new FeaturePackageCreateResponse());

    // featureSelections holds resource/feature names and never affects user groups.
    service.createFeaturePackage(packageTemplate, List.of("anything"), "short001");

    List<ca.bnc.wealth.common.userconfiguration.model.PackageTemplateAssignment> assignments =
        captureSentFeaturePackage().getAssignments();
    assertEquals(2, assignments.size());
    assertEquals(Boolean.TRUE, selectedFor(assignments, 1));
    assertEquals(Boolean.TRUE, selectedFor(assignments, 2));
  }

  @Test
  void testCreateFeaturePackage_emitsExactlyOneEntryPerDetailRow() {
    // A template mixing S and G rows must produce one entry per row (no doubling, no skipping),
    // so the request size equals the authorization-api count (ptaugs.size() + ptars.size()).
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(List.of(
        assignmentResource(1L, "res-M", 11L, PackageAssignmentMode.M),
        assignmentResource(2L, "res-O", 22L, PackageAssignmentMode.O),
        userGroupDetail(3L, PackageAssignmentMode.M),
        userGroupDetail(4L, PackageAssignmentMode.O)));

    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(new FeaturePackageCreateResponse());

    service.createFeaturePackage(packageTemplate, null, "short001");

    List<ca.bnc.wealth.common.userconfiguration.model.PackageTemplateAssignment> assignments =
        captureSentFeaturePackage().getAssignments();
    assertEquals(4, assignments.size());
    assertEquals(Boolean.TRUE, selectedFor(assignments, 1));   // M resource - always selected
    assertEquals(Boolean.FALSE, selectedFor(assignments, 2));  // O resource, not requested -> false
    assertEquals(Boolean.TRUE, selectedFor(assignments, 3));   // G user group - always selected
    assertEquals(Boolean.TRUE, selectedFor(assignments, 4));   // G user group - always selected
  }

  @Test
  void testCreateFeaturePackage_nullResourceOmodeEntry_emittedAsNotSelected() {
    // Symmetric to the M-mode case: an O-mode row with a null resource was previously skipped
    // (under-counting -> 400). It must now be emitted, but with selected=false.
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    PackageTemplateAssignmentResource oModeNullResource = new PackageTemplateAssignmentResource();
    oModeNullResource.setTemplateAssignmentId(99L);
    oModeNullResource.setAssignmentMode(PackageAssignmentMode.O);
    oModeNullResource.setAssignmentType(PackageAssignmentType.S);
    packageTemplate.setPackageTemplateAssignmentResources(List.of(
        oModeNullResource,
        assignmentResource(1L, "res-M", 11L, PackageAssignmentMode.M)));

    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(new FeaturePackageCreateResponse());

    service.createFeaturePackage(packageTemplate, null, "short001");

    List<ca.bnc.wealth.common.userconfiguration.model.PackageTemplateAssignment> assignments =
        captureSentFeaturePackage().getAssignments();
    assertEquals(2, assignments.size());
    assertEquals(Boolean.TRUE, selectedFor(assignments, 1));
    assertEquals(Boolean.FALSE, selectedFor(assignments, 99));
  }

  private PackageTemplateAssignmentResource assignmentResource(
      long templateAssignmentId, String resourceName, long resourceId, PackageAssignmentMode mode) {
    Resource resource = new Resource();
    resource.setName(resourceName);
    resource.setResourceId(resourceId);
    PackageTemplateAssignmentResource ar = new PackageTemplateAssignmentResource();
    ar.setTemplateAssignmentId(templateAssignmentId);
    ar.setResource(resource);
    ar.setAssignmentMode(mode);
    ar.setAssignmentType(PackageAssignmentType.S);
    return ar;
  }

  // A user-group (type G) detail row shares the PACKAGE_TEMPLATE_DETAILS table with resource rows
  // and carries no resource association.
  private PackageTemplateAssignmentResource userGroupDetail(
      long templateAssignmentId, PackageAssignmentMode mode) {
    PackageTemplateAssignmentResource ar = new PackageTemplateAssignmentResource();
    ar.setTemplateAssignmentId(templateAssignmentId);
    ar.setAssignmentMode(mode);
    ar.setAssignmentType(PackageAssignmentType.G);
    return ar;
  }

  private ca.bnc.wealth.common.userconfiguration.model.FeaturePackage captureSentFeaturePackage() {
    ArgumentCaptor<ca.bnc.wealth.common.userconfiguration.model.FeaturePackage> captor =
        ArgumentCaptor.forClass(ca.bnc.wealth.common.userconfiguration.model.FeaturePackage.class);
    verify(authorizationClient).createFeaturePackage(anyString(), captor.capture());
    return captor.getValue();
  }

  private Boolean selectedFor(
      List<ca.bnc.wealth.common.userconfiguration.model.PackageTemplateAssignment> assignments,
      int assignmentId) {
    return assignments.stream()
        .filter(a -> a.getAssignmentId() != null && a.getAssignmentId() == assignmentId)
        .map(ca.bnc.wealth.common.userconfiguration.model.PackageTemplateAssignment::getSelected)
        .findFirst()
        .orElse(null);
  }

  @Test
  void testValidatePackages_valid_returnsTemplate() {
    PackageTemplate t1 = MockData.getPackageTemplateEntity();

    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(t1));

    PackageTemplate result = service.validatePackages("Template1");

    assertEquals("Template1", result.getName());
    verify(packageTemplateRepository).findByNameAndType("Template1", PackageType.U);
  }

  @Test
  void testValidatePackages_notFound_throwsException() {
    when(packageTemplateRepository.findByNameAndType("InvalidTemplate", PackageType.U))
        .thenReturn(Optional.empty());

    assertThrows(FumValidationException.class,
        () -> service.validatePackages("InvalidTemplate"));
  }

  private PackageTemplate packageTemplateWithResources(String... resourceNames) {
    PackageTemplate template = MockData.getPackageTemplateEntity();
    List<PackageTemplateAssignmentResource> ars = new ArrayList<>();
    long id = 1L;
    for (String name : resourceNames) {
      Resource resource = new Resource();
      resource.setName(name);
      resource.setResourceId(id++);
      PackageTemplateAssignmentResource ar = new PackageTemplateAssignmentResource();
      ar.setResource(resource);
      ars.add(ar);
    }
    template.setPackageTemplateAssignmentResources(ars);
    return template;
  }

  @Test
  void testValidateFeatureSelections_nullSelections_noException() {
    PackageTemplate template = packageTemplateWithResources("res-A", "res-B");
    assertDoesNotThrow(() -> service.validateFeatureSelections(template, null));
  }

  @Test
  void testValidateFeatureSelections_emptySelections_noException() {
    PackageTemplate template = packageTemplateWithResources("res-A", "res-B");
    assertDoesNotThrow(() -> service.validateFeatureSelections(template, List.of()));
  }

  @Test
  void testValidateFeatureSelections_allBelongToPackage_noException() {
    PackageTemplate template = packageTemplateWithResources("res-A", "res-B");
    assertDoesNotThrow(() -> service.validateFeatureSelections(template, List.of("res-A", "res-B")));
  }

  @Test
  void testValidateFeatureSelections_unknownSelection_throwsValidation() {
    PackageTemplate template = packageTemplateWithResources("res-A", "res-B");

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.validateFeatureSelections(template, List.of("res-A", "res-UNKNOWN")));

    assertEquals(Constants.EMPLOYEE_FEATURE_SELECTION_INVALID_CODE, ex.getCode());
    assertTrue(ex.getMessage().contains("res-UNKNOWN"));
    assertTrue(ex.getMessage().contains("Template1"));
    assertTrue(!ex.getMessage().contains("res-A"));
  }

  @Test
  void testValidateFeatureSelections_nullResourceEntry_ignoredSafely() {
    PackageTemplate template = packageTemplateWithResources("res-A");
    template.getPackageTemplateAssignmentResources().add(new PackageTemplateAssignmentResource());

    assertDoesNotThrow(() -> service.validateFeatureSelections(template, List.of("res-A")));
    assertThrows(FumValidationException.class,
        () -> service.validateFeatureSelections(template, List.of("res-X")));
  }

  @Test
  void testValidateFeatureSelections_nullTemplateResources_anySelectionInvalid() {
    PackageTemplate template = MockData.getPackageTemplateEntity();
    template.setPackageTemplateAssignmentResources(null);

    assertThrows(FumValidationException.class,
        () -> service.validateFeatureSelections(template, List.of("res-A")));
  }

  @Test
  void testCreateEmployee_invalidFeatureSelection_throwsValidation_noUserSaved() {
    CreateUserEmployee input = MockData.getCreateUserEmployeeWithAssignments();
    input.getProfile().getAssignment().getPackage().setFeatureSelections(List.of("res-UNKNOWN"));

    PackageTemplate packageTemplate = packageTemplateWithResources("res-A");
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.createEmployee(input, "testUser"));

    assertEquals(Constants.EMPLOYEE_FEATURE_SELECTION_INVALID_CODE, ex.getCode());
    verify(iamUserConfigurationRepository, never()).save(any());
    verify(authorizationClient, never()).createFeaturePackage(anyString(), any());
  }

  @Test
  void testUpdateOrCreateEmployee_invalidFeatureSelection_throwsValidation() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployeeWithAssignments();
    update.getProfile().getAssignment().getPackage().setFeatureSelections(List.of("res-UNKNOWN"));

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    PackageTemplate packageTemplate = packageTemplateWithResources("res-A");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.updateOrCreateEmployee("raza002", update, "testUser"));

    assertEquals(Constants.EMPLOYEE_FEATURE_SELECTION_INVALID_CODE, ex.getCode());
    verify(authorizationClient, never()).createFeaturePackage(anyString(), any());
  }

  @Test
  void testCreateEmployee_existingPersonWithNullIdpUser() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person existingPerson = new Person();
    existingPerson.setPersonId(10L);
    existingPerson.setEmail(input.getEmail());

    IamUserConfiguration existingUserNullIdp = new IamUserConfiguration();
    existingUserNullIdp.setEmail(input.getEmail());
    existingUserNullIdp.setIdp(null);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmailIgnoreCase(input.getEmail()))
        .thenReturn(Optional.of(existingPerson));
    when(iamUserConfigurationRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.of(existingUserNullIdp));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);

    service.createEmployee(input, "testUser");

    verify(iamUserConfigurationRepository).save(any(IamUserConfiguration.class));
    verify(personRepository, never()).save(any(Person.class));
    verify(personAssignmentRepository).save(any(PersonAssignment.class));
  }

  // --- updateOrCreateEmployee tests ---

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_updatesFields() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    Person person = new Person();
    person.setPersonId(1L);
    person.setFirstName("OldFirst");
    person.setLastName("OldLast");
    person.setEmail("old@nbc.ca");
    person.setLanguage(PreferredLanguageType.EN);

    PersonAssignment assignment = new PersonAssignment();
    assignment.setPerson(person);
    assignment.setUserId(existingEntity.getUserConfigurationId().intValue());

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignment));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(person);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(e ->
        "Jane".equals(e.getFirstName())
            && "Smith".equals(e.getLastName())
            && "jane.smith@nbc.ca".equals(e.getEmail())
            && PreferredLanguageType.FR == e.getPreferredLanguageType()
            && e.getUserPreferences() != null
            && "compass_r2".equals(e.getUserPreferences().get("defaultModule"))
            && Boolean.TRUE.equals(e.getActive())
    ));
    verify(personRepository).save(argThat(p ->
        "Jane".equals(p.getFirstName())
            && "Smith".equals(p.getLastName())
            && "jane.smith@nbc.ca".equals(p.getEmail())
            && PreferredLanguageType.FR == p.getLanguage()
    ));
  }

  @Test
  void testUpdateExistingEmployee_auditAfterSnapshotIsFreshlyReRead() {
    // Regression for the "before equals after" audit skip: the after-snapshot must reflect a
    // fresh DB read (flush + clear + re-fetch), not the stale in-memory entity. We simulate the
    // re-read returning a reassigned firm and assert before != after, plus flush/clear are invoked.
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();

    IamUserConfiguration beforeEntity = MockData.getIamUserConfigurationEntity();
    beforeEntity.setUsername("refresh001");
    beforeEntity.setIdpSubject("refresh001");
    beforeEntity.setIdp("IAMi");
    Firm firmBefore = new Firm();
    firmBefore.setFirmId("FIRM_BEFORE");
    UserAssignmentFirm uafBefore = new UserAssignmentFirm();
    uafBefore.setAssignmentType(UserAssignmentType.F);
    uafBefore.setFirm(firmBefore);
    beforeEntity.setUserAssignmentFirms(List.of(uafBefore));

    IamUserConfiguration reReadEntity = MockData.getIamUserConfigurationEntity();
    reReadEntity.setUsername("refresh001");
    reReadEntity.setIdpSubject("refresh001");
    reReadEntity.setIdp("IAMi");
    Firm firmAfter = new Firm();
    firmAfter.setFirmId("FIRM_AFTER");
    UserAssignmentFirm uafAfter = new UserAssignmentFirm();
    uafAfter.setAssignmentType(UserAssignmentType.F);
    uafAfter.setFirm(firmAfter);
    reReadEntity.setUserAssignmentFirms(List.of(uafAfter));

    Person person = new Person();
    person.setPersonId(1L);
    PersonAssignment assignment = new PersonAssignment();
    assignment.setPerson(person);
    assignment.setUserId(beforeEntity.getUserConfigurationId().intValue());

    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignment));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(beforeEntity);
    when(personRepository.save(any(Person.class))).thenReturn(person);
    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase("refresh001"))
        .thenReturn(Optional.of(reReadEntity));

    service.updateExistingEmployee(beforeEntity, update, "testUser");

    verify(entityManager).flush();
    verify(entityManager).clear();

    ArgumentCaptor<UserConfiguration> beforeCaptor = ArgumentCaptor.forClass(UserConfiguration.class);
    ArgumentCaptor<UserConfiguration> afterCaptor = ArgumentCaptor.forClass(UserConfiguration.class);
    verify(auditLogService).publishEmployeeAudit(eq(AuditEventType.UPDATE),
        beforeCaptor.capture(), afterCaptor.capture());

    assertEquals("FIRM_BEFORE", beforeCaptor.getValue().getFirmId());
    assertEquals("FIRM_AFTER", afterCaptor.getValue().getFirmId());
  }

  @Test
  void testUpdateOrCreateEmployee_notFound_createsNewEmployee() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    update.getProfile().setAssignment(assignment);

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject("raza002");
    savedEntity.setUsername("raza002");

    Person savedPerson = new Person();
    savedPerson.setPersonId(10L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase("raza002"))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.findFirstByEmail(update.getEmail()))
        .thenReturn(Optional.empty());
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(iamUserConfigurationRepository).save(any(IamUserConfiguration.class));
    verify(personRepository).save(any(Person.class));
    verify(personAssignmentRepository).save(any(PersonAssignment.class));
    // Upsert-create path must carry the firm through and assign it (regression guard for NWPI-14501)
    verify(userAssignmentService).assignFirmToUser(anyLong(), eq("raza002"), eq(100L), eq("testUser"));
  }

  @Test
  void testUpdateOrCreateEmployee_createPath_nullFirm_throwsFirmMissing() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    // No assignment provided -> create path must reject the missing firm.
    update.getProfile().setAssignment(null);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase("raza002"))
        .thenReturn(Optional.empty());

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.updateOrCreateEmployee("raza002", update, "testUser"));
    assertEquals(Constants.FIRM_MISSING, ex.getCode());
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testUpdateOrCreateEmployee_createPath_blankFirm_throwsFirmMissing() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("  ");
    update.getProfile().setAssignment(assignment);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase("raza002"))
        .thenReturn(Optional.empty());

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.updateOrCreateEmployee("raza002", update, "testUser"));
    assertEquals(Constants.FIRM_MISSING, ex.getCode());
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testUpdateOrCreateEmployee_nonEmpUser_throwsConflict() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    update.getProfile().setAssignment(assignment);

    IamUserConfiguration existingNonEmpUser = MockData.getIamUserConfigurationEntity();
    existingNonEmpUser.setUsername("raza002");
    existingNonEmpUser.setIdp("okta");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingNonEmpUser));

    // The Short ID is already held by a non-employee profile, so the create path this falls
    // back to is rejected instead of inserting a second row (NWPI-14901).
    FumConflictException ex = assertThrows(FumConflictException.class,
        () -> service.updateOrCreateEmployee("raza002", update, "testUser"));

    assertEquals(Constants.EMPLOYEE_EXISTS_CODE, ex.getCode());
    verify(iamUserConfigurationRepository, never()).save(any(IamUserConfiguration.class));
    verify(personRepository, never()).save(any(Person.class));
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_withPackages() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployeeWithAssignments();
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    FeaturePackageCreateResponse fpResponse = new FeaturePackageCreateResponse();
    fpResponse.setFeaturePackageId(100L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    when(packageTemplateRepository.findByType(PackageType.U))
        .thenReturn(List.of(packageTemplate));
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(fpResponse);
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType("raza002", UserAssignmentType.P))
        .thenReturn(Optional.of(List.of()));

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(iamUserConfigurationRepository).save(any(IamUserConfiguration.class));
    verify(authorizationClient).createFeaturePackage(anyString(), any());
    verify(userAssignmentService).assignFeaturePackageToUser(anyLong(), anyString(), anyLong(), anyString());
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_replacesExistingPackage() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployeeWithAssignments();
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    FeaturePackageCreateResponse fpResponse = new FeaturePackageCreateResponse();
    fpResponse.setFeaturePackageId(100L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    when(packageTemplateRepository.findByType(PackageType.U))
        .thenReturn(List.of(packageTemplate));
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(fpResponse);
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType("raza002", UserAssignmentType.P))
        .thenReturn(Optional.of(List.of()));

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(userAssignmentRepository).deleteUserAssignmentsByIdpSubjectAndAssignmentType("raza002", UserAssignmentType.P);
    verify(authorizationClient).createFeaturePackage(anyString(), any());
    verify(userAssignmentService).assignFeaturePackageToUser(anyLong(), anyString(), anyLong(), anyString());
  }

  @Test
  void testRemoveResourceAssignmentsExceptDwh_preservesDwhResources() {
    UserAssignment dwhAssignment = new UserAssignment();
    dwhAssignment.setAssignmentType(UserAssignmentType.S);
    dwhAssignment.setAssigneeId(10);
    UserAssignment regularAssignment = new UserAssignment();
    regularAssignment.setAssignmentType(UserAssignmentType.S);
    regularAssignment.setAssigneeId(20);
    UserAssignment anotherRegular = new UserAssignment();
    anotherRegular.setAssignmentType(UserAssignmentType.S);
    anotherRegular.setAssigneeId(30);

    Resource dwhResource = new Resource();
    dwhResource.setResourceId(10L);
    dwhResource.setType(Constants.RESOURCE_TYPE_DWH_UI_MODULE);

    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType("raza002", UserAssignmentType.S))
        .thenReturn(Optional.of(List.of(dwhAssignment, regularAssignment, anotherRegular)));
    when(resourceRepository.findByType(Constants.RESOURCE_TYPE_DWH_UI_MODULE))
        .thenReturn(List.of(dwhResource));

    service.removeResourceAssignmentsExceptDwh("raza002");

    ArgumentCaptor<List<UserAssignment>> captor = ArgumentCaptor.forClass(List.class);
    verify(userAssignmentRepository).deleteAll(captor.capture());
    List<UserAssignment> removed = captor.getValue();
    assertEquals(2, removed.size());
    assertTrue(removed.stream().noneMatch(a -> a.getAssigneeId() == 10),
        "dwh_ui_module resource (id=10) must be preserved");
    assertTrue(removed.stream().anyMatch(a -> a.getAssigneeId() == 20));
    assertTrue(removed.stream().anyMatch(a -> a.getAssigneeId() == 30));
  }

  @Test
  void testRemoveResourceAssignmentsExceptDwh_allDwh_removesNothing() {
    UserAssignment dwhAssignment = new UserAssignment();
    dwhAssignment.setAssignmentType(UserAssignmentType.S);
    dwhAssignment.setAssigneeId(10);

    Resource dwhResource = new Resource();
    dwhResource.setResourceId(10L);
    dwhResource.setType(Constants.RESOURCE_TYPE_DWH_UI_MODULE);

    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType("raza002", UserAssignmentType.S))
        .thenReturn(Optional.of(List.of(dwhAssignment)));
    when(resourceRepository.findByType(Constants.RESOURCE_TYPE_DWH_UI_MODULE))
        .thenReturn(List.of(dwhResource));

    service.removeResourceAssignmentsExceptDwh("raza002");

    verify(userAssignmentRepository, never()).deleteAll(any());
  }

  @Test
  void testRemoveResourceAssignmentsExceptDwh_noResourceAssignments_removesNothing() {
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType("raza002", UserAssignmentType.S))
        .thenReturn(Optional.empty());

    service.removeResourceAssignmentsExceptDwh("raza002");

    verify(userAssignmentRepository, never()).deleteAll(any());
    verify(resourceRepository, never()).findByType(anyString());
  }

  @Test
  void testUpdateOrCreateEmployee_packageReassignment_preservesDwhResources() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployeeWithAssignments();
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    FeaturePackageCreateResponse fpResponse = new FeaturePackageCreateResponse();
    fpResponse.setFeaturePackageId(100L);

    UserAssignment dwhAssignment = new UserAssignment();
    dwhAssignment.setAssignmentType(UserAssignmentType.S);
    dwhAssignment.setAssigneeId(10);
    UserAssignment regularAssignment = new UserAssignment();
    regularAssignment.setAssignmentType(UserAssignmentType.S);
    regularAssignment.setAssigneeId(20);

    Resource dwhResource = new Resource();
    dwhResource.setResourceId(10L);
    dwhResource.setType(Constants.RESOURCE_TYPE_DWH_UI_MODULE);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    when(packageTemplateRepository.findByType(PackageType.U))
        .thenReturn(List.of(packageTemplate));
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(fpResponse);
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType("raza002", UserAssignmentType.P))
        .thenReturn(Optional.of(List.of()));
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType("raza002", UserAssignmentType.S))
        .thenReturn(Optional.of(List.of(dwhAssignment, regularAssignment)));
    when(resourceRepository.findByType(Constants.RESOURCE_TYPE_DWH_UI_MODULE))
        .thenReturn(List.of(dwhResource));

    service.updateOrCreateEmployee("raza002", update, "testUser");

    ArgumentCaptor<List<UserAssignment>> captor = ArgumentCaptor.forClass(List.class);
    verify(userAssignmentRepository).deleteAll(captor.capture());
    List<UserAssignment> removed = captor.getValue();
    assertEquals(1, removed.size());
    assertEquals(20, removed.get(0).getAssigneeId().intValue());
    // The dwh_ui_module resource assignment must NOT be removed via the blanket type-S delete.
    verify(userAssignmentRepository, never())
        .deleteUserAssignmentsByIdpSubjectAndAssignmentType("raza002", UserAssignmentType.S);
    verify(userAssignmentService).assignFeaturePackageToUser(anyLong(), anyString(), anyLong(), anyString());
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_noPerson_throwsNotFound() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);

    FumNotFoundException ex = assertThrows(FumNotFoundException.class,
        () -> service.updateOrCreateEmployee("raza002", update, "testUser"));

    assertTrue(ex.getMessage().contains("raza002"));
    verify(iamUserConfigurationRepository).save(any(IamUserConfiguration.class));
    verify(personRepository, never()).save(any(Person.class));
  }

  @Test
  void testUpdateOrCreateEmployee_foundByIdpSubject() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("other");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.empty());
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(e ->
        "Jane".equals(e.getFirstName()) && "Smith".equals(e.getLastName())
    ));
  }

  @Test
  void testToCreateUserEmployee_mapsBasicFields() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();

    CreateUserEmployee result = service.toCreateUserEmployee("raza002", update);

    assertEquals("raza002", result.getProfile().getShortId());
    assertEquals("Jane", result.getFirstName());
    assertEquals("Smith", result.getLastName());
    assertEquals("jane.smith@nbc.ca", result.getEmail());
    assertEquals("FR", result.getLanguage());
    assertEquals("compass_r2", result.getProfile().getDefaultModule());
    assertTrue(result.getProfile().getActive());
  }

  @Test
  void testToCreateUserEmployee_mapsAssignments() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployeeWithAssignments();

    CreateUserEmployee result = service.toCreateUserEmployee("raza002", update);

    assertNotNull(result.getProfile().getAssignment());
    assertEquals("firm-001", result.getProfile().getAssignment().getFirm());
    assertEquals(List.of("RR001", "RR002"), result.getProfile().getAssignment().getRrcodes());
    assertNotNull(result.getProfile().getAssignment().getPackage());
    assertEquals("Template1", result.getProfile().getAssignment().getPackage().getName());
  }

  @Test
  void testToCreateUserEmployee_nullLanguage() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    update.setLanguage(null);

    CreateUserEmployee result = service.toCreateUserEmployee("raza002", update);

    assertNull(result.getLanguage());
  }

  @Test
  void testToCreateUserEmployee_noAssignments() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();

    CreateUserEmployee result = service.toCreateUserEmployee("raza002", update);

    assertNull(result.getProfile().getAssignment());
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_partialNullFields() {
    UpdateUserEmployee update = new UpdateUserEmployee();
    update.setFirstName("NewFirst");
    update.setLastName("NewLast");
    // firstName/lastName are mandatory; email, language and profile left null are not updated

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");
    existingEntity.setFirstName("OldFirst");
    existingEntity.setLastName("OldLast");
    existingEntity.setEmail("old@nbc.ca");
    existingEntity.setSource("CX");
    existingEntity.setActive(true);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(e ->
        "NewFirst".equals(e.getFirstName())
            && "NewLast".equals(e.getLastName())
            && "old@nbc.ca".equals(e.getEmail())
            && "CX".equals(e.getSource())
            && Boolean.TRUE.equals(e.getActive())
    ));
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_invalidDefaultModule_throwsValidation() {
    UpdateUserEmployee update = new UpdateUserEmployee();
    update.setFirstName("Jane");
    update.setLastName("Smith");
    UpdateUserEmployeeProfile profile = new UpdateUserEmployeeProfile();
    profile.setDefaultModule("not_a_real_module");
    update.setProfile(profile);

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.updateOrCreateEmployee("raza002", update, "testUser"));
    assertTrue(ex.getMessage().contains("Invalid default module"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_invalidLanguage_throwsValidation() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    update.setLanguage("ENzzz");

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.updateOrCreateEmployee("raza002", update, "testUser"));
    assertEquals("error.create.employee.language", ex.getCode());
    assertEquals("Invalid language", ex.getMessage());
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_nullFirstName_throwsValidation() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    update.setFirstName(null);

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.updateOrCreateEmployee("raza002", update, "testUser"));
    assertEquals(Constants.EMPLOYEE_REQUIRED_FIELD_CODE, ex.getCode());
    assertTrue(ex.getMessage().contains("firstName"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_blankFirstName_throwsValidation() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    update.setFirstName("   ");

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.updateOrCreateEmployee("raza002", update, "testUser"));
    assertEquals(Constants.EMPLOYEE_REQUIRED_FIELD_CODE, ex.getCode());
    assertTrue(ex.getMessage().contains("firstName"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_nullLastName_throwsValidation() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    update.setLastName(null);

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.updateOrCreateEmployee("raza002", update, "testUser"));
    assertEquals(Constants.EMPLOYEE_REQUIRED_FIELD_CODE, ex.getCode());
    assertTrue(ex.getMessage().contains("lastName"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_blankLastName_throwsValidation() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    update.setLastName("");

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.updateOrCreateEmployee("raza002", update, "testUser"));
    assertEquals(Constants.EMPLOYEE_REQUIRED_FIELD_CODE, ex.getCode());
    assertTrue(ex.getMessage().contains("lastName"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_assignmentsWithEmptyPackages() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    assignment.setPackage(null);
    update.getProfile().setAssignment(assignment);

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(iamUserConfigurationRepository).save(any(IamUserConfiguration.class));
    verify(packageTemplateRepository, never()).findByType(any());
    // Firm reassignment still fires (firmId is set), but package-type deletion must not happen
    verify(userAssignmentRepository).deleteUserAssignmentsByIdpSubjectAndAssignmentType("raza002", UserAssignmentType.F);
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_assignmentsWithNullPackages() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    // package is null
    update.getProfile().setAssignment(assignment);

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(iamUserConfigurationRepository).save(any(IamUserConfiguration.class));
    verify(packageTemplateRepository, never()).findByType(any());
    // Firm reassignment still fires (firmId is set), but package-type deletion must not happen
    verify(userAssignmentRepository).deleteUserAssignmentsByIdpSubjectAndAssignmentType("raza002", UserAssignmentType.F);
  }

  @Test
  void testUpdateOrCreateEmployee_removeExistingPackage_deleteThrows_exceptionRethrown() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployeeWithAssignments();
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    doThrow(new RuntimeException("delete failed"))
        .when(userAssignmentRepository)
        .deleteUserAssignmentsByIdpSubjectAndAssignmentType("raza002", UserAssignmentType.P);

    assertThrows(RuntimeException.class,
        () -> service.updateOrCreateEmployee("raza002", update, "testUser"));
  }

  @Test
  void testDeleteEmployee_foundByIdpSubject_deletesAllRecords() {
    String shortId = "emp001";
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setIdpSubject(shortId);
    userConfig.setUsername(shortId);
    userConfig.setSource(APPLICATION_CX);
    userConfig.setUserPreferences(Map.of(UserPreferencesEnum.defaultModule.name(), APPLICATION_CX));
    userConfig.setOssUserId("oss123");
    userConfig.setOssGroupId("grp456");

    Person person = new Person();
    person.setPersonId(1L);
    person.setFirstName("John");
    person.setLastName("Doe");
    person.setEmail("john@nbc.ca");
    person.setLanguage(PreferredLanguageType.EN);

    PersonAssignment personAssignment = new PersonAssignment();
    personAssignment.setPersonAssignmentId(1L);
    personAssignment.setPerson(person);
    personAssignment.setUserId(userConfig.getUserConfigurationId().intValue());

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(iamUserConfigurationRepository.findById(userConfig.getUserConfigurationId()))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(personAssignment));
    when(personAssignmentRepository.findAllByPersonPersonId(person.getPersonId()))
        .thenReturn(List.of(personAssignment));
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType(shortId, UserAssignmentType.P))
        .thenReturn(Optional.of(List.of()));
    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);

    service.deleteEmployee(shortId);

    verify(entityManager).clear();
    verify(userAssignmentRepository).deleteUserAssignmentsByIdpSubject(shortId);
    verify(personAssignmentRepository).deleteAll(List.of(personAssignment));
    verify(personRepository).delete(person);
    verify(iamUserConfigurationRepository).delete(userConfig);
  }

  @Test
  void testDeleteEmployee_notFound_noDeletion() {
    String shortId = "unknown";

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(shortId))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.empty());

    service.deleteEmployee(shortId);

    verify(userAssignmentRepository, never()).deleteUserAssignmentsByIdpSubject(any());
    verify(iamUserConfigurationRepository, never()).delete(any(IamUserConfiguration.class));
  }

  @Test
  void testDeleteEmployee_foundByUsername() {
    String shortId = "emp002";
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setIdpSubject(shortId);
    userConfig.setUsername(shortId);
    userConfig.setSource(APPLICATION_CX);

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(shortId))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(iamUserConfigurationRepository.findById(userConfig.getUserConfigurationId()))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType(shortId, UserAssignmentType.P))
        .thenReturn(Optional.of(List.of()));

    service.deleteEmployee(shortId);

    verify(userAssignmentRepository).deleteUserAssignmentsByIdpSubject(shortId);
    verify(iamUserConfigurationRepository).delete(userConfig);
  }

  @Test
  void testDeleteEmployee_deletesFeaturePackagesViaAuthApi() {
    String shortId = "emp003";
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setIdpSubject(shortId);
    userConfig.setUsername(shortId);

    UserAssignment ua1 = new UserAssignment();
    ua1.setIdpSubject(shortId);
    ua1.setAssignmentType(UserAssignmentType.P);
    ua1.setAssigneeId(101);

    UserAssignment ua2 = new UserAssignment();
    ua2.setIdpSubject(shortId);
    ua2.setAssignmentType(UserAssignmentType.P);
    ua2.setAssigneeId(102);

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(iamUserConfigurationRepository.findById(userConfig.getUserConfigurationId()))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType(shortId, UserAssignmentType.P))
        .thenReturn(Optional.of(List.of(ua1, ua2)));
    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);

    service.deleteEmployee(shortId);

    verify(authorizationClient).deleteFeaturePackage(STUB_BEARER_TOKEN, 101);
    verify(authorizationClient).deleteFeaturePackage(STUB_BEARER_TOKEN, 102);
    verify(userAssignmentRepository).deleteUserAssignmentsByIdpSubject(shortId);
    verify(iamUserConfigurationRepository).delete(userConfig);
  }

  @Test
  void testDeleteEmployee_featurePackageDeletionFailure_continuesExecution() {
    String shortId = "emp004";
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setIdpSubject(shortId);
    userConfig.setUsername(shortId);

    UserAssignment ua = new UserAssignment();
    ua.setIdpSubject(shortId);
    ua.setAssignmentType(UserAssignmentType.P);
    ua.setAssigneeId(200);

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(iamUserConfigurationRepository.findById(userConfig.getUserConfigurationId()))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType(shortId, UserAssignmentType.P))
        .thenReturn(Optional.of(List.of(ua)));
    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    doThrow(new RuntimeException("Authorization service unavailable"))
        .when(authorizationClient).deleteFeaturePackage(STUB_BEARER_TOKEN, 200);

    service.deleteEmployee(shortId);

    verify(authorizationClient).deleteFeaturePackage(STUB_BEARER_TOKEN, 200);
    verify(userAssignmentRepository).deleteUserAssignmentsByIdpSubject(shortId);
    verify(iamUserConfigurationRepository).delete(userConfig);
  }

  @Test
  void testDeleteEmployee_noPersonAssignments_noPersonRecord() {
    String shortId = "emp005";
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setIdpSubject(shortId);
    userConfig.setUsername(shortId);

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(iamUserConfigurationRepository.findById(userConfig.getUserConfigurationId()))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType(shortId, UserAssignmentType.P))
        .thenReturn(Optional.of(List.of()));

    service.deleteEmployee(shortId);

    verify(personAssignmentRepository, never()).deleteAll(any());
    verify(personRepository, never()).delete(any(Person.class));
    verify(iamUserConfigurationRepository).delete(userConfig);
  }

  @Test
  void testDeleteEmployee_noFeaturePackages() {
    String shortId = "emp006";
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setIdpSubject(shortId);
    userConfig.setUsername(shortId);

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(iamUserConfigurationRepository.findById(userConfig.getUserConfigurationId()))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType(shortId, UserAssignmentType.P))
        .thenReturn(Optional.empty());

    service.deleteEmployee(shortId);

    verify(authorizationClient, never()).deleteFeaturePackage(any(), any());
    verify(userAssignmentRepository).deleteUserAssignmentsByIdpSubject(shortId);
    verify(iamUserConfigurationRepository).delete(userConfig);
  }

  @Test
  void testDeleteEmployee_inactiveUser_stillDeleted() {
    String shortId = "emp-inactive";
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setIdpSubject(shortId);
    userConfig.setUsername(shortId);
    userConfig.setActive(false);

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(iamUserConfigurationRepository.findById(userConfig.getUserConfigurationId()))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType(shortId, UserAssignmentType.P))
        .thenReturn(Optional.of(List.of()));

    service.deleteEmployee(shortId);

    verify(userAssignmentRepository).deleteUserAssignmentsByIdpSubject(shortId);
    verify(iamUserConfigurationRepository).delete(userConfig);
  }

  @Test
  void testDeleteEmployee_userDisappearsAfterClear_noDeletion() {
    // Edge case: another thread deletes the user between the initial find and the re-fetch after clear()
    String shortId = "emp-race";
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setIdpSubject(shortId);
    userConfig.setUsername(shortId);

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    // After entityManager.clear(), findById returns empty (concurrent delete)
    when(iamUserConfigurationRepository.findById(userConfig.getUserConfigurationId()))
        .thenReturn(Optional.empty());
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType(shortId, UserAssignmentType.P))
        .thenReturn(Optional.of(List.of()));

    service.deleteEmployee(shortId);

    // No deletions are performed since userConfig was already gone after clear()
    verify(entityManager).clear();
    verify(userAssignmentRepository, never()).deleteUserAssignmentsByIdpSubject(any());
    verify(iamUserConfigurationRepository, never()).delete(any(IamUserConfiguration.class));
  }

  @Test
  void testDeleteEmployee_verifiesFkSafeDeletionOrdering() {
    String shortId = "emp-order";
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setIdpSubject(shortId);
    userConfig.setUsername(shortId);

    Person person = new Person();
    person.setPersonId(10L);
    person.setFirstName("Order");
    person.setLastName("Test");

    PersonAssignment personAssignment = new PersonAssignment();
    personAssignment.setPersonAssignmentId(1L);
    personAssignment.setPerson(person);
    personAssignment.setUserId(userConfig.getUserConfigurationId().intValue());

    UserAssignment ua = new UserAssignment();
    ua.setIdpSubject(shortId);
    ua.setAssignmentType(UserAssignmentType.P);
    ua.setAssigneeId(55);

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(iamUserConfigurationRepository.findById(userConfig.getUserConfigurationId()))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(personAssignment));
    when(personAssignmentRepository.findAllByPersonPersonId(person.getPersonId()))
        .thenReturn(List.of(personAssignment));
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType(shortId, UserAssignmentType.P))
        .thenReturn(Optional.of(List.of(ua)));
    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);

    service.deleteEmployee(shortId);

    // Verify FK-safe ordering: children deleted before parents
    org.mockito.InOrder inOrder = org.mockito.Mockito.inOrder(
        authorizationClient, userAssignmentRepository, personAssignmentRepository,
        personRepository, iamUserConfigurationRepository);

    // 1. External feature packages first (Auth API call)
    inOrder.verify(authorizationClient).deleteFeaturePackage(STUB_BEARER_TOKEN, 55);
    // 2. User assignments (child of UserConfiguration via idpSubject)
    inOrder.verify(userAssignmentRepository).deleteUserAssignmentsByIdpSubject(shortId);
    // 3. Person assignments (child of Person)
    inOrder.verify(personAssignmentRepository).deleteAll(List.of(personAssignment));
    // 4. Person (child of nothing, but has FK from PersonAssignment)
    inOrder.verify(personRepository).delete(person);
    // 5. UserConfiguration last (parent entity)
    inOrder.verify(iamUserConfigurationRepository).delete(userConfig);
  }

  @Test
  void testDeleteEmployee_personWithMultipleAssignments_allAssignmentsAndPersonDeleted() {
    String shortId = "emp-multi";
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setIdpSubject(shortId);
    userConfig.setUsername(shortId);
    int thisUserId = userConfig.getUserConfigurationId().intValue();

    Person person = new Person();
    person.setPersonId(4602L);
    person.setFirstName("Multi");
    person.setLastName("Person");

    // Link for the employee being deleted
    PersonAssignment thisUserLink = new PersonAssignment();
    thisUserLink.setPersonAssignmentId(1L);
    thisUserLink.setPerson(person);
    thisUserLink.setUserId(thisUserId);

    // Another assignment that references the same Person
    PersonAssignment otherLink = new PersonAssignment();
    otherLink.setPersonAssignmentId(2L);
    otherLink.setPerson(person);
    otherLink.setUserId(thisUserId + 1);

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(iamUserConfigurationRepository.findById(userConfig.getUserConfigurationId()))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(thisUserLink));
    when(personAssignmentRepository.findAllByPersonPersonId(person.getPersonId()))
        .thenReturn(List.of(thisUserLink, otherLink));
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType(shortId, UserAssignmentType.P))
        .thenReturn(Optional.of(List.of()));

    service.deleteEmployee(shortId);

    // ALL of the Person's assignments must be removed (not just the deleted user's link)
    // so the subsequent Person deletion does not violate the fk_person constraint.
    verify(personAssignmentRepository).deleteAll(List.of(thisUserLink, otherLink));
    verify(personRepository).delete(person);
    verify(iamUserConfigurationRepository).delete(userConfig);
  }

  @Test
  void testDeleteEmployee_personSingleAssignment_assignmentAndPersonDeleted() {
    String shortId = "emp-single";
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setIdpSubject(shortId);
    userConfig.setUsername(shortId);
    int thisUserId = userConfig.getUserConfigurationId().intValue();

    Person person = new Person();
    person.setPersonId(7001L);
    person.setFirstName("Single");
    person.setLastName("Owner");

    PersonAssignment thisUserLink = new PersonAssignment();
    thisUserLink.setPersonAssignmentId(1L);
    thisUserLink.setPerson(person);
    thisUserLink.setUserId(thisUserId);

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(iamUserConfigurationRepository.findById(userConfig.getUserConfigurationId()))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(thisUserLink));
    when(personAssignmentRepository.findAllByPersonPersonId(person.getPersonId()))
        .thenReturn(List.of(thisUserLink));
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType(shortId, UserAssignmentType.P))
        .thenReturn(Optional.of(List.of()));

    service.deleteEmployee(shortId);

    verify(personAssignmentRepository).deleteAll(List.of(thisUserLink));
    verify(personRepository).delete(person);
    verify(iamUserConfigurationRepository).delete(userConfig);
  }

  // ==================== patchEmployee tests ====================

  @Test
  void testPatchEmployee_notFound_throwsNotFoundException() {
    String shortId = "unknown";
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setFirstName("NewFirst");

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(shortId))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.empty());

    FumNotFoundException ex = assertThrows(FumNotFoundException.class,
        () -> service.patchEmployee(shortId, patch, "testUser"));
    assertTrue(ex.getMessage().contains(shortId));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testPatchEmployee_nonEmpUser_throwsNotFoundException() {
    String shortId = "non-emp";
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setFirstName("NewFirst");

    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUsername(shortId);
    userConfig.setIdp("ext");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));

    assertThrows(FumNotFoundException.class,
        () -> service.patchEmployee(shortId, patch, "testUser"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testPatchEmployee_profileActive_deactivate_setsActiveFalse() {
    String shortId = "emp001";
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUsername(shortId);
    userConfig.setIdpSubject(shortId);
    userConfig.setIdp("IAMi");
    userConfig.setActive(true);

    PatchUserEmployeeProfile profile = new PatchUserEmployeeProfile();
    profile.setActive(false);
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setProfile(profile);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    // state is derived from Okta, so Okta must report the suspension
    stubOktaProfile(oktaSuspendedProfile());

    service.patchEmployee(shortId, patch, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(uc ->
        Boolean.FALSE.equals(uc.getActive())
            && UserStateEnum.INACTIVE.dbValue.equals(uc.getState())
            && UserStateDescriptionEnum.SUSPENDED.dbValue.equals(uc.getStateDescription())
            && "".equals(uc.getStateAction())
            && uc.getStatusLastUpdated() != null));
    verify(personRepository).save(any(Person.class));
  }

  @Test
  void testPatchEmployee_profileActive_activate_setsActiveTrue() {
    String shortId = "emp002";
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUsername(shortId);
    userConfig.setIdpSubject(shortId);
    userConfig.setIdp("IAMi");
    userConfig.setActive(false);

    PatchUserEmployeeProfile profile = new PatchUserEmployeeProfile();
    profile.setActive(true);
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setProfile(profile);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    // state is derived from Okta, so Okta must report the user as fully active
    stubOktaProfile(oktaActiveProfile());

    service.patchEmployee(shortId, patch, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(uc ->
        Boolean.TRUE.equals(uc.getActive())
            && UserStateEnum.ACTIVE.dbValue.equals(uc.getState())
            && UserStateDescriptionEnum.ACTIVE.dbValue.equals(uc.getStateDescription())
            && "".equals(uc.getStateAction())
            && uc.getStatusLastUpdated() != null));
  }

  @Test
  void testPatchEmployee_noFields_throwsValidation() {
    String shortId = "emp003";
    PatchUserEmployee patch = new PatchUserEmployee();

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.patchEmployee(shortId, patch, "testUser"));
    assertTrue(ex.getMessage().contains("Exactly one field"));
    verify(iamUserConfigurationRepository, never()).findFirstByUsernameIgnoreCase(any());
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testPatchEmployee_foundByIdpSubject_whenUsernameNotFound() {
    String shortId = "emp004";
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUsername(shortId);
    userConfig.setIdpSubject(shortId);
    userConfig.setIdp("IAMi");
    userConfig.setActive(true);

    PatchUserEmployeeProfile profile = new PatchUserEmployeeProfile();
    profile.setActive(false);
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setProfile(profile);

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.empty());
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    stubOktaProfile(oktaSuspendedProfile());

    service.patchEmployee(shortId, patch, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(uc -> Boolean.FALSE.equals(uc.getActive())));
  }

  // -----------------------------------------------------------------------------------------
  // NWPI-14872 - PATCH cascades the SSO account's active state to every linked account
  // -----------------------------------------------------------------------------------------

  private PatchUserEmployee activePatch(boolean active) {
    PatchUserEmployeeProfile profile = new PatchUserEmployeeProfile();
    profile.setActive(active);
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setProfile(profile);
    return patch;
  }

  private Person personWithId(long personId) {
    Person person = new Person();
    person.setPersonId(personId);
    person.setFirstName("OldFirst");
    person.setLastName("OldLast");
    person.setEmail("old@nbc.ca");
    person.setLanguage(PreferredLanguageType.EN);
    return person;
  }

  private PersonAssignment assignmentFor(Person person, Integer userId) {
    PersonAssignment assignment = new PersonAssignment();
    assignment.setPerson(person);
    assignment.setUserId(userId);
    return assignment;
  }

  private IamUserConfiguration linkedAccount(long userConfigurationId, boolean active) {    IamUserConfiguration linked = MockData.getIamUserConfigurationEntity();
    linked.setUserConfigurationId(userConfigurationId);
    linked.setIdpSubject("linked-" + userConfigurationId);
    linked.setUsername("linked-" + userConfigurationId);
    // distinct from the employee row so Okta calls can be told apart per account
    linked.setIdpUserIdentifier("okta-" + userConfigurationId);
    linked.setIdp("IAMi");
    linked.setActive(active);
    return linked;
  }

  @Test
  void testUpdateActiveToLinkedAccounts_deactivate_updatesAndAuditsEveryLinkedAccount() {
    String shortId = "emp-cascade-01";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    Person person = personWithId(1L);
    IamUserConfiguration linkedOne = linkedAccount(5555L, true);
    IamUserConfiguration linkedTwo = linkedAccount(6666L, true);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 1234), assignmentFor(person, 5555),
            assignmentFor(person, 6666)));
    when(iamUserConfigurationRepository.findAllById(List.of(5555L, 6666L)))
        .thenReturn(List.of(linkedOne, linkedTwo));
    stubOktaProfile(oktaSuspendedProfile());

    service.patchEmployee(shortId, activePatch(false), "testUser");

    assertEquals(Boolean.FALSE, linkedOne.getActive());
    assertEquals(Boolean.FALSE, linkedTwo.getActive());
    assertEquals(UserStateEnum.INACTIVE.dbValue, linkedOne.getState());
    assertEquals(UserStateDescriptionEnum.SUSPENDED.dbValue, linkedOne.getStateDescription());
    assertEquals("", linkedOne.getStateAction());
    assertEquals(UserStateEnum.INACTIVE.dbValue, linkedTwo.getState());
    assertEquals(UserStateDescriptionEnum.SUSPENDED.dbValue, linkedTwo.getStateDescription());
    assertEquals("", linkedTwo.getStateAction());
    assertEquals("testUser", linkedOne.getLastUpdatedBy());
    assertEquals("testUser", linkedTwo.getLastUpdatedBy());
    assertNotNull(linkedOne.getStatusLastUpdated());
    assertNotNull(linkedOne.getLastUpdateDate());
    verify(iamUserConfigurationRepository).save(linkedOne);
    verify(iamUserConfigurationRepository).save(linkedTwo);
    // One audit event for the SSO account plus one per cascaded linked account.
    verify(auditLogService, times(3))
        .publishEmployeeAudit(eq(AuditEventType.UPDATE), any(), any());
  }

  @Test
  void testUpdateActiveToLinkedAccounts_activate_doesNotCascadeToLinkedAccounts() {
    // activating the primary/SSO account must NOT activate linked accounts -
    // only a deactivation cascades.
    String shortId = "emp-cascade-02";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    ssoAccount.setActive(false);
    Person person = personWithId(1L);
    IamUserConfiguration linked = linkedAccount(5555L, false);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    stubOktaProfile(oktaActiveProfile());

    service.patchEmployee(shortId, activePatch(true), "testUser");

    assertEquals(Boolean.TRUE, ssoAccount.getActive());
    assertEquals(UserStateEnum.ACTIVE.dbValue, ssoAccount.getState());
    assertEquals(UserStateDescriptionEnum.ACTIVE.dbValue, ssoAccount.getStateDescription());
    // the linked account is left untouched: no fetch of the linked rows, no save
    assertEquals(Boolean.FALSE, linked.getActive());
    verify(iamUserConfigurationRepository, never()).findAllById(any());
    verify(iamUserConfigurationRepository, never()).save(linked);
  }

  @Test
  void testUpdateActiveToLinkedAccounts_noLinkedPerson_skipsCascade() {
    String shortId = "emp-cascade-03";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());

    // No Person row means the cascade returns early; updatePersonFromPatch then rejects the patch.
    assertThrows(FumValidationException.class,
        () -> service.patchEmployee(shortId, activePatch(false), "testUser"));

    verify(personAssignmentRepository, never()).findAllByPersonPersonId(anyLong());
    verify(iamUserConfigurationRepository, never()).findAllById(any());
  }

  @Test
  void testUpdateActiveToLinkedAccounts_onlySsoAccountLinked_skipsCascade() {
    String shortId = "emp-cascade-04";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    Person person = personWithId(1L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 1234)));

    service.patchEmployee(shortId, activePatch(false), "testUser");

    // The SSO account is excluded from its own cascade, leaving nothing to load.
    verify(iamUserConfigurationRepository, never()).findAllById(any());
    verify(auditLogService, times(1))
        .publishEmployeeAudit(eq(AuditEventType.UPDATE), any(), any());
  }

  @Test
  void testUpdateActiveToLinkedAccounts_linkedIdsResolveToNoAccounts_skipsCascade() {
    String shortId = "emp-cascade-05";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    Person person = personWithId(1L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 7777)));
    when(iamUserConfigurationRepository.findAllById(List.of(7777L)))
        .thenReturn(List.of());

    service.patchEmployee(shortId, activePatch(false), "testUser");

    // Only the SSO account's own audit event is published.
    verify(auditLogService, times(1))
        .publishEmployeeAudit(eq(AuditEventType.UPDATE), any(), any());
  }

  @Test
  void testUpdateActiveToLinkedAccounts_ignoresAssignmentsWithNullUserId() {
    String shortId = "emp-cascade-06";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    Person person = personWithId(1L);
    IamUserConfiguration linked = linkedAccount(8888L, true);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, null), assignmentFor(person, 8888)));
    when(iamUserConfigurationRepository.findAllById(List.of(8888L)))
        .thenReturn(List.of(linked));
    stubOktaProfile(oktaSuspendedProfile());

    service.patchEmployee(shortId, activePatch(false), "testUser");

    // once for the active cascade, once for the employee-external group self-heal
    verify(iamUserConfigurationRepository, times(2)).findAllById(List.of(8888L));
    assertEquals(Boolean.FALSE, linked.getActive());
  }

  @Test
  void testUpdateActiveToLinkedAccounts_deduplicatesRepeatedUserIds() {
    String shortId = "emp-cascade-07";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    Person person = personWithId(1L);
    IamUserConfiguration linked = linkedAccount(9999L, true);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 9999), assignmentFor(person, 9999)));
    when(iamUserConfigurationRepository.findAllById(List.of(9999L)))
        .thenReturn(List.of(linked));

    service.patchEmployee(shortId, activePatch(false), "testUser");

    // once for the active cascade, once for the employee-external group self-heal
    verify(iamUserConfigurationRepository, times(2)).findAllById(List.of(9999L));
  }

  @Test
  void testPatchEmployee_activeChange_stampsAuditFieldsOnSsoAccount() {
    String shortId = "emp-cascade-08";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    Person person = personWithId(1L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    stubOktaProfile(oktaSuspendedProfile());

    service.patchEmployee(shortId, activePatch(false), "testUser");

    assertEquals(Boolean.FALSE, ssoAccount.getActive());
    assertNotNull(ssoAccount.getStatusLastUpdated());
    assertEquals("testUser", ssoAccount.getLastUpdatedBy());
    assertNotNull(ssoAccount.getLastUpdateDate());
  }

  @Test
  void testPatchEmployee_activeFalse_pushesStatusToOkta() {
    String shortId = "emp-okta-patch";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    Person person = personWithId(1L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 1234)));

    service.patchEmployee(shortId, activePatch(false), "testUser");

    verify(externalClientService).updateOktaUserStatus(ssoAccount.getIdpUserIdentifier(), false);
  }

  @Test
  void testPatchEmployee_defaultModuleOnly_doesNotCallOkta() {
    String shortId = "emp-okta-patch-module";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    PatchUserEmployeeProfile profile = new PatchUserEmployeeProfile();
    profile.setDefaultModule("users_module");
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setProfile(profile);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));

    service.patchEmployee(shortId, patch, "testUser");

    // no status in the payload -> nothing to tell Okta
    verify(externalClientService, never()).updateOktaUserStatus(anyString(), anyBoolean());
  }

  @Test
  void testPatchEmployee_defaultModuleOnly_doesNotCascadeOrStampStatus() {
    String shortId = "emp-cascade-09";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    PatchUserEmployeeProfile profile = new PatchUserEmployeeProfile();
    profile.setDefaultModule("users_module");
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setProfile(profile);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));

    service.patchEmployee(shortId, patch, "testUser");

    // active was not supplied, so neither the status stamp nor the cascade runs.
    assertNull(ssoAccount.getStatusLastUpdated());
    verify(iamUserConfigurationRepository, never()).findAllById(any());
    // lastUpdatedBy/lastUpdateDate are stamped on every patch regardless of the field changed.
    assertEquals("testUser", ssoAccount.getLastUpdatedBy());
    assertNotNull(ssoAccount.getLastUpdateDate());
  }

  private PersonAssignment linkedPersonAssignment() {
    Person person = new Person();
    person.setPersonId(1L);
    person.setFirstName("OldFirst");
    person.setLastName("OldLast");
    person.setEmail("old@nbc.ca");
    person.setLanguage(PreferredLanguageType.EN);
    PersonAssignment assignment = new PersonAssignment();
    assignment.setPerson(person);
    assignment.setUserId(1234);
    return assignment;
  }

  private IamUserConfiguration empUserConfig(String shortId) {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUsername(shortId);
    userConfig.setIdpSubject(shortId);
    userConfig.setIdp("IAMi");
    userConfig.setActive(true);
    return userConfig;
  }

  // -----------------------------------------------------------------------------------------
  // NWPI-15025 - an email change cascades to every account linked to the same Person
  // -----------------------------------------------------------------------------------------

  private PatchUserEmployee emailPatch(String email) {
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setEmail(email);
    return patch;
  }

  @Test
  void testUpdateEmailOnLinkedAccounts_updatesAndAuditsEveryStaleLinkedAccount() {
    String shortId = "emp-email-01";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    Person person = personWithId(1L);
    IamUserConfiguration linkedOne = linkedAccount(5555L, true);
    IamUserConfiguration linkedTwo = linkedAccount(6666L, true);
    linkedOne.setEmail("stale.one@nbc.ca");
    linkedTwo.setEmail("stale.two@nbc.ca");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 1234), assignmentFor(person, 5555),
            assignmentFor(person, 6666)));
    when(iamUserConfigurationRepository.findAllById(List.of(5555L, 6666L)))
        .thenReturn(List.of(linkedOne, linkedTwo));

    service.patchEmployee(shortId, emailPatch("kamali.arunamanivannan@nbc.ca"), "testUser");

    assertEquals("kamali.arunamanivannan@nbc.ca", linkedOne.getEmail());
    assertEquals("kamali.arunamanivannan@nbc.ca", linkedTwo.getEmail());
    assertEquals("testUser", linkedOne.getLastUpdatedBy());
    assertNotNull(linkedTwo.getLastUpdateDate());
    verify(iamUserConfigurationRepository).save(linkedOne);
    verify(iamUserConfigurationRepository).save(linkedTwo);
    verify(redisCacheOperationService)
        .deleteUserConfigurationCache("linked-5555", 5555, "okta-5555");
    verify(redisCacheOperationService)
        .deleteUserConfigurationCache("linked-6666", 6666, "okta-6666");
    // One audit event for the employee account plus one per cascaded linked account.
    verify(auditLogService, times(3))
        .publishEmployeeAudit(eq(AuditEventType.UPDATE), any(), any());
  }

  @Test
  void testUpdateEmailOnLinkedAccounts_skipsLinkedAccountsAlreadyHoldingTheEmail() {
    String shortId = "emp-email-02";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    Person person = personWithId(1L);
    IamUserConfiguration linked = linkedAccount(5555L, true);
    linked.setEmail("KAMALI.ARUNAMANIVANNAN@nbc.ca");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 5555)));
    when(iamUserConfigurationRepository.findAllById(List.of(5555L)))
        .thenReturn(List.of(linked));

    service.patchEmployee(shortId, emailPatch("kamali.arunamanivannan@nbc.ca"), "testUser");

    verify(iamUserConfigurationRepository, never()).save(linked);
  }

  @Test
  void testPatchEmployee_nonEmailField_doesNotCascadeEmail() {
    String shortId = "emp-email-03";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setFirstName("NewFirst");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));

    service.patchEmployee(shortId, patch, "testUser");

    verify(iamUserConfigurationRepository, never()).findAllById(any());
  }

  @Test
  void testUpdateEmailOnLinkedAccounts_blankEmail_skipsCascade() {
    IamUserConfiguration ssoAccount = empUserConfig("emp-email-04");

    service.updateEmailOnLinkedAccounts(ssoAccount, "  ", "testUser");

    verify(personAssignmentRepository, never()).findAllByPersonPersonId(anyLong());
    verify(iamUserConfigurationRepository, never()).findAllById(any());
  }

  @Test
  void testUpdateOrCreateEmployee_emailChange_cascadesToLinkedAccounts() {
    String shortId = "emp-email-05";
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    IamUserConfiguration existingEntity = empUserConfig(shortId);
    Person person = personWithId(1L);
    IamUserConfiguration linked = linkedAccount(5555L, true);
    linked.setEmail("stale@nbc.ca");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person,
            existingEntity.getUserConfigurationId().intValue())));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 5555)));
    when(iamUserConfigurationRepository.findAllById(List.of(5555L)))
        .thenReturn(List.of(linked));

    service.updateOrCreateEmployee(shortId, update, "testUser");

    assertEquals("jane.smith@nbc.ca", linked.getEmail());
    assertEquals("testUser", linked.getLastUpdatedBy());
    // the active cascade saves the linked account too, so the email cascade is not the only save
    verify(iamUserConfigurationRepository, atLeastOnce()).save(linked);
  }

  @Test
  void testPatchEmployee_firstName_updatesEntityAndPerson() {
    String shortId = "emp010";
    IamUserConfiguration userConfig = empUserConfig(shortId);
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setFirstName("NewFirst");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));

    service.patchEmployee(shortId, patch, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(uc -> "NewFirst".equals(uc.getFirstName())));
    verify(personRepository).save(argThat(p ->
        "NewFirst".equals(p.getFirstName())
            && "testUser".equals(p.getUpdatedBy())
            && p.getUpdatedDt() != null));
  }

  @Test
  void testPatchEmployee_lastName_updatesEntityAndPerson() {
    String shortId = "emp011";
    IamUserConfiguration userConfig = empUserConfig(shortId);
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setLastName("NewLast");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));

    service.patchEmployee(shortId, patch, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(uc -> "NewLast".equals(uc.getLastName())));
    verify(personRepository).save(argThat(p -> "NewLast".equals(p.getLastName())));
  }

  @Test
  void testPatchEmployee_email_updatesEntityAndPerson() {
    String shortId = "emp012";
    IamUserConfiguration userConfig = empUserConfig(shortId);
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setEmail("new@nbc.ca");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));

    service.patchEmployee(shortId, patch, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(uc -> "new@nbc.ca".equals(uc.getEmail())));
    verify(personRepository).save(argThat(p -> "new@nbc.ca".equals(p.getEmail())));
  }

  @Test
  void testPatchEmployee_emailOwnedByAnotherPerson_throwsConflict() {
    String shortId = "emp012c";
    IamUserConfiguration userConfig = empUserConfig(shortId);
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setEmail("Taken@NBC.ca");

    Person otherPerson = new Person();
    otherPerson.setPersonId(99L);
    otherPerson.setEmail("taken@nbc.ca");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(personRepository.findFirstByEmailIgnoreCase("taken@nbc.ca"))
        .thenReturn(Optional.of(otherPerson));
    when(personAssignmentRepository.findFirstByPersonPersonIdAndUserId(99L, 1234))
        .thenReturn(Optional.empty());

    assertThrows(FumConflictException.class,
        () -> service.patchEmployee(shortId, patch, "testUser"));
    verify(iamUserConfigurationRepository, never()).save(any(IamUserConfiguration.class));
    verify(personRepository, never()).save(any(Person.class));
  }

  @Test
  void testPatchEmployee_emailOwnedBySamePerson_isNotAConflict() {
    String shortId = "emp012d";
    IamUserConfiguration userConfig = empUserConfig(shortId);
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setEmail("Old@NBC.ca");

    Person ownPerson = new Person();
    ownPerson.setPersonId(1L);
    ownPerson.setEmail("old@nbc.ca");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(personRepository.findFirstByEmailIgnoreCase("old@nbc.ca"))
        .thenReturn(Optional.of(ownPerson));
    when(personAssignmentRepository.findFirstByPersonPersonIdAndUserId(1L, 1234))
        .thenReturn(Optional.of(linkedPersonAssignment()));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));

    service.patchEmployee(shortId, patch, "testUser");

    verify(personRepository).save(any(Person.class));
  }

  @Test
  void testPatchEmployee_language_updatesEntityAndPerson() {
    String shortId = "emp013";
    IamUserConfiguration userConfig = empUserConfig(shortId);
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setLanguage("FR");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));

    service.patchEmployee(shortId, patch, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(uc ->
        PreferredLanguageType.FR == uc.getPreferredLanguageType()));
    verify(personRepository).save(argThat(p -> PreferredLanguageType.FR == p.getLanguage()));
  }

  @Test
  void testPatchEmployee_invalidLanguage_throwsValidation() {
    String shortId = "emp013";
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setLanguage("ENzzz");

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.patchEmployee(shortId, patch, "testUser"));
    assertEquals("error.create.employee.language", ex.getCode());
    assertEquals("Invalid language", ex.getMessage());
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testPatchEmployee_profileDefaultModule_validValue_setsUserPreferences() {
    String shortId = "emp015";
    IamUserConfiguration userConfig = empUserConfig(shortId);
    PatchUserEmployeeProfile profile = new PatchUserEmployeeProfile();
    profile.setDefaultModule("users_module");
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setProfile(profile);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));

    service.patchEmployee(shortId, patch, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(uc ->
        uc.getUserPreferences() != null
            && "users_module".equals(uc.getUserPreferences().get("defaultModule"))));
  }

  @Test
  void testPatchEmployee_profileDefaultModule_existingPreferencesMap_putsIntoExistingMap() {
    String shortId = "emp016";
    IamUserConfiguration userConfig = empUserConfig(shortId);
    Map<String, String> prefs = new HashMap<>();
    prefs.put("existingKey", "existingValue");
    userConfig.setUserPreferences(prefs);

    PatchUserEmployeeProfile profile = new PatchUserEmployeeProfile();
    profile.setDefaultModule("compass_r2");
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setProfile(profile);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));

    service.patchEmployee(shortId, patch, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(uc ->
        "compass_r2".equals(uc.getUserPreferences().get("defaultModule"))
            && "existingValue".equals(uc.getUserPreferences().get("existingKey"))));
  }

  @Test
  void testPatchEmployee_profileDefaultModule_emptyString_storesNullPreference() {
    String shortId = "emp016b";
    IamUserConfiguration userConfig = empUserConfig(shortId);
    PatchUserEmployeeProfile profile = new PatchUserEmployeeProfile();
    profile.setDefaultModule("");
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setProfile(profile);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));

    service.patchEmployee(shortId, patch, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(uc ->
        uc.getUserPreferences() != null
            && uc.getUserPreferences().containsKey("defaultModule")
            && uc.getUserPreferences().get("defaultModule") == null));
  }

  @Test
  void testPatchEmployee_profileInvalidDefaultModule_throwsValidation() {
    String shortId = "emp017";
    PatchUserEmployeeProfile profile = new PatchUserEmployeeProfile();
    profile.setDefaultModule("invalid_module");
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setProfile(profile);

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.patchEmployee(shortId, patch, "testUser"));
    assertTrue(ex.getMessage().contains("Invalid default module"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testPatchEmployee_multipleTopLevelFields_throwsValidation() {
    String shortId = "emp018";
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setFirstName("A");
    patch.setLastName("B");

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.patchEmployee(shortId, patch, "testUser"));
    assertTrue(ex.getMessage().contains("Exactly one field"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testPatchEmployee_profileNoFields_throwsValidation() {
    String shortId = "emp019";
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setProfile(new PatchUserEmployeeProfile());

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.patchEmployee(shortId, patch, "testUser"));
    assertTrue(ex.getMessage().contains("Exactly one field"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testPatchEmployee_profileMultipleFields_throwsValidation() {
    String shortId = "emp020";
    PatchUserEmployeeProfile profile = new PatchUserEmployeeProfile();
    profile.setDefaultModule("users_module");
    profile.setActive(true);
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setProfile(profile);

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.patchEmployee(shortId, patch, "testUser"));
    assertTrue(ex.getMessage().contains("Exactly one field"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testPatchEmployee_personNotLinked_throwsValidation() {
    String shortId = "emp021";
    IamUserConfiguration userConfig = empUserConfig(shortId);
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setFirstName("NewFirst");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.patchEmployee(shortId, patch, "testUser"));
    assertTrue(ex.getMessage().contains("not found"));
    verify(personRepository, never()).save(any());
  }

  // ==================== getFirm tests ====================

  @Test
  void testGetFirm_nullFirmId_returnsNull() {
    Firm result = service.getFirm(null);
    assertNull(result);
  }

  @Test
  void testGetFirm_firmNotFound_throwsValidation() {
    when(firmRepository.findByFirmId("unknown-firm")).thenReturn(null);

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.getFirm("unknown-firm"));
    assertTrue(ex.getMessage().contains("not found"));
  }

  @Test
  void testGetFirm_firmFound_returnsFirm() {
    Firm firm = new Firm();
    firm.setFirmId("testFirm");
    firm.setFirmEntityId(42L);
    when(firmRepository.findByFirmId("testFirm")).thenReturn(firm);

    Firm result = service.getFirm("testFirm");

    assertNotNull(result);
    assertEquals("testFirm", result.getFirmId());
    assertEquals(42L, result.getFirmEntityId());
  }

  // ==================== createEmployee firm / rrCode validation tests ====================

  @Test
  void testCreateEmployee_nullAssignment_throwsFirmMissing() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setAssignment(null);

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.createEmployee(input, "testUser"));
    assertEquals(Constants.FIRM_MISSING, ex.getCode());
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testCreateEmployee_blankFirm_throwsFirmMissing() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().getAssignment().setFirm("  ");

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.createEmployee(input, "testUser"));
    assertEquals(Constants.FIRM_MISSING, ex.getCode());
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testCreateEmployee_nullFirm_throwsFirmMissing() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().getAssignment().setFirm(null);

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.createEmployee(input, "testUser"));
    assertEquals(Constants.FIRM_MISSING, ex.getCode());
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testCreateEmployee_firmNotFound_throwsValidation() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().getAssignment().setFirm("nonexistent-firm");
    when(firmRepository.findByFirmId("nonexistent-firm")).thenReturn(null);

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.createEmployee(input, "testUser"));
    assertTrue(ex.getMessage().contains("not found"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testCreateEmployee_withRrCodes_callsValidation() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().getAssignment().setRrcodes(List.of("AA00", "BB99"));

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person savedPerson = new Person();
    savedPerson.setPersonId(10L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);

    service.createEmployee(input, "testUser");

    verify(rrCodeService).assignRrCodesToUser(any(IamUserConfiguration.class), any(Firm.class), any(), anyString(), anyBoolean());
  }

  @Test
  void testCreateEmployee_withRrCodes_validationFails_throwsException() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().getAssignment().setRrcodes(List.of("INVALID"));

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(new Person());
    doThrow(new FumValidationException("error.rrRangeCode.invalidFormat", "Invalid RR code"))
        .when(rrCodeService).assignRrCodesToUser(any(IamUserConfiguration.class), any(Firm.class), any(), anyString(), anyBoolean());

    assertThrows(FumValidationException.class, () -> service.createEmployee(input, "testUser"));
    verify(rrCodeService).assignRrCodesToUser(any(IamUserConfiguration.class), any(Firm.class), any(), anyString(), anyBoolean());
  }

  // ==================== handleFirmReassignment edge cases ====================

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_emptyFirmId_skipsFirmReassignment() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("");
    update.getProfile().setAssignment(assignment);

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(iamUserConfigurationRepository).save(any(IamUserConfiguration.class));
    verify(firmRepository, never()).findByFirmId(any());
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_firmReassignment() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    update.getProfile().setAssignment(assignment);

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(firmRepository, times(2)).findByFirmId("firm-001");
    verify(userAssignmentRepository).deleteUserAssignmentsByIdpSubjectAndAssignmentType("raza002", UserAssignmentType.F);
    verify(userAssignmentService).assignFirmToUser(anyLong(), anyString(), anyLong(), anyString());
    // null rrCodes clears existing RR codes
    verify(rrCodeService).assignRrCodesToUser(eq(existingEntity), any(Firm.class), isNull(), anyString(), eq(false));
  }

  @Test
  void testCreateEmployee_assignUserToFirm_verifiesFirmAssignment() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());

    Person savedPerson = new Person();
    savedPerson.setPersonId(10L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);

    service.createEmployee(input, "testUser");

    verify(userAssignmentService).assignFirmToUser(anyLong(), anyString(), eq(100L), anyString());
  }

  // ==================== handleRrCodeReassignment tests ====================

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_withRrCodes_reassignsRrCodes() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    assignment.setRrcodes(List.of("RR001", "RR002"));
    update.getProfile().setAssignment(assignment);

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(rrCodeService).assignRrCodesToUser(any(IamUserConfiguration.class), any(Firm.class), any(), anyString(), anyBoolean());
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_nullRrCodes_clearsRrCodes() {
    // When rrCodes is null and no firm_level_access, existing RR codes are cleared.
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    assignment.setRrcodes(null);
    update.getProfile().setAssignment(assignment);

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(rrCodeService).assignRrCodesToUser(eq(existingEntity), any(Firm.class), isNull(), anyString(), eq(false));
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_emptyRrCodes_reassignsRrCodes() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    assignment.setRrcodes(List.of());
    update.getProfile().setAssignment(assignment);

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(rrCodeService).assignRrCodesToUser(any(IamUserConfiguration.class), any(Firm.class), any(), anyString(), anyBoolean());
  }


  @Test
  void testUpdateOrCreateEmployee_firmLevelAccessInFeatureSelections_nullRrCodes_assignsRrCodes() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    assignment.setRrcodes(null);
    EmployeePackageRequest pkg = new EmployeePackageRequest();
    pkg.setName("Template1");
    pkg.setFeatureSelections(List.of("firm_level_access"));
    assignment.setPackage(pkg);
    update.getProfile().setAssignment(assignment);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    Resource flaResource = new Resource();
    flaResource.setName("firm_level_access");
    PackageTemplateAssignmentResource flaPtar = new PackageTemplateAssignmentResource();
    flaPtar.setResource(flaResource);
    packageTemplate.setPackageTemplateAssignmentResources(List.of(flaPtar));


    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(buildFpResponse());

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(rrCodeService).assignRrCodesToUser(eq(existingEntity), any(Firm.class), isNull(), anyString(), eq(true));
  }

  @Test
  void testUpdateOrCreateEmployee_firmLevelAccessInFeatureSelections_emptyRrCodes_assignsRrCodes() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    assignment.setRrcodes(List.of());
    EmployeePackageRequest pkg = new EmployeePackageRequest();
    pkg.setName("Template1");
    pkg.setFeatureSelections(List.of("firm_level_access"));
    assignment.setPackage(pkg);
    update.getProfile().setAssignment(assignment);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    Resource flaResource = new Resource();
    flaResource.setName("firm_level_access");
    PackageTemplateAssignmentResource flaPtar = new PackageTemplateAssignmentResource();
    flaPtar.setResource(flaResource);
    packageTemplate.setPackageTemplateAssignmentResources(List.of(flaPtar));


    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(buildFpResponse());

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(rrCodeService).assignRrCodesToUser(eq(existingEntity), any(Firm.class), eq(List.of()), anyString(), eq(true));
  }

  @Test
  void testUpdateOrCreateEmployee_firmLevelAccessAndRestrictClientDataAccess_throwsError() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    assignment.setRrcodes(null);
    EmployeePackageRequest pkg = new EmployeePackageRequest();
    pkg.setName("Template1");
    pkg.setFeatureSelections(List.of("firm_level_access"));
    assignment.setPackage(pkg);
    update.getProfile().setAssignment(assignment);

    // Build a PackageTemplate that has restrict_client_data_access in its resources
    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    Resource flaResource = new Resource();
    flaResource.setName("firm_level_access");
    PackageTemplateAssignmentResource flaPtar = new PackageTemplateAssignmentResource();
    flaPtar.setResource(flaResource);
    Resource restrictResource = new Resource();
    restrictResource.setName("restrict_client_data_access");
    PackageTemplateAssignmentResource restrictPtar = new PackageTemplateAssignmentResource();
    restrictPtar.setResource(restrictResource);
    packageTemplate.setPackageTemplateAssignmentResources(List.of(flaPtar, restrictPtar));

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(buildFpResponse());

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.updateOrCreateEmployee("raza002", update, "testUser"));
    assertEquals(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS, ex.getCode());
    verify(rrCodeService, never()).assignRrCodesToUser(any(), any(), any(), any(), anyBoolean());
  }

  @Test
  void testUpdateOrCreateEmployee_noFirmLevelAccess_packagePresent_nullRrCodes_clearsRrCodes() {
    // Package present but no firm_level_access, null rrCodes → clear existing RR codes.
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    assignment.setRrcodes(null);
    EmployeePackageRequest pkg = new EmployeePackageRequest();
    pkg.setName("Template1");
    pkg.setFeatureSelections(List.of("some_other_feature"));
    assignment.setPackage(pkg);
    update.getProfile().setAssignment(assignment);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    Resource otherResource = new Resource();
    otherResource.setName("some_other_feature");
    PackageTemplateAssignmentResource otherPtar = new PackageTemplateAssignmentResource();
    otherPtar.setResource(otherResource);
    packageTemplate.setPackageTemplateAssignmentResources(List.of(otherPtar));


    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(buildFpResponse());

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(rrCodeService).assignRrCodesToUser(eq(existingEntity), any(Firm.class), isNull(), anyString(), eq(false));
  }

  @Test
  void testUpdateOrCreateEmployee_validRrCodes_firmLevelAccess_assignsAllFirmRrCodes() {
    // When firm_level_access is true, provided valid rrCodes are ignored — all firm RR codes are assigned.
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    assignment.setRrcodes(List.of("RR001", "RR002"));
    EmployeePackageRequest pkg = new EmployeePackageRequest();
    pkg.setName("Template1");
    pkg.setFeatureSelections(List.of("firm_level_access"));
    assignment.setPackage(pkg);
    update.getProfile().setAssignment(assignment);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    Resource flaResource = new Resource();
    flaResource.setName("firm_level_access");
    PackageTemplateAssignmentResource flaPtar = new PackageTemplateAssignmentResource();
    flaPtar.setResource(flaResource);
    packageTemplate.setPackageTemplateAssignmentResources(List.of(flaPtar));

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(buildFpResponse());

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(rrCodeService).assignRrCodesToUser(eq(existingEntity), any(Firm.class),
        eq(List.of("RR001", "RR002")), anyString(), eq(true));
  }

  @Test
  void testUpdateOrCreateEmployee_invalidRrCodes_firmLevelAccess_assignsAllFirmRrCodes() {
    // When firm_level_access is true, provided invalid rrCodes are ignored — all firm RR codes are assigned.
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    assignment.setRrcodes(List.of("INVALID_CODE"));
    EmployeePackageRequest pkg = new EmployeePackageRequest();
    pkg.setName("Template1");
    pkg.setFeatureSelections(List.of("firm_level_access"));
    assignment.setPackage(pkg);
    update.getProfile().setAssignment(assignment);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    Resource flaResource = new Resource();
    flaResource.setName("firm_level_access");
    PackageTemplateAssignmentResource flaPtar = new PackageTemplateAssignmentResource();
    flaPtar.setResource(flaResource);
    packageTemplate.setPackageTemplateAssignmentResources(List.of(flaPtar));

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(packageTemplate));
    when(systemTokenFactory.getBearerToken("fum"))
        .thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any()))
        .thenReturn(buildFpResponse());

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(rrCodeService).assignRrCodesToUser(eq(existingEntity), any(Firm.class),
        eq(List.of("INVALID_CODE")), anyString(), eq(true));
  }

  @Test
  void testUpdateOrCreateEmployee_invalidRrCodes_noFirmLevelAccess_delegatesToRrCodeService() {
    // Without firm_level_access, invalid rrCodes are passed to rrCodeService which validates them.
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    assignment.setRrcodes(List.of("INVALID_CODE"));
    update.getProfile().setAssignment(assignment);

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    doThrow(new FumValidationException(Constants.FIRM_RRCODE_INVALID, Constants.FIRM_RRCODE_INVALID_MESSAGE))
        .when(rrCodeService).assignRrCodesToUser(any(IamUserConfiguration.class), any(Firm.class),
            any(), anyString(), anyBoolean());

    assertThrows(FumValidationException.class,
        () -> service.updateOrCreateEmployee("raza002", update, "testUser"));
    verify(rrCodeService).assignRrCodesToUser(eq(existingEntity), any(Firm.class),
        eq(List.of("INVALID_CODE")), anyString(), eq(false));
  }

  @Test
  void testUpdateOrCreateEmployee_emptyRrCodes_noFirmLevelAccess_noPackage_clearsRrCodes() {
    // Empty rrCodes without firm_level_access and no package in payload — DB fallback returns false.
    // assignRrCodesToUser is called with firmLevelAccess=false, which deletes existing and adds none.
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    assignment.setRrcodes(List.of());
    update.getProfile().setAssignment(assignment);

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    when(rrCodeService.hasFirmLevelAccess(existingEntity)).thenReturn(false);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(rrCodeService).assignRrCodesToUser(eq(existingEntity), any(Firm.class),
        eq(List.of()), anyString(), eq(false));
  }
  // ==================== person.setUpdatedBy / setUpdatedDt coverage ====================

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_setsPersonUpdatedByAndDt() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    Person person = new Person();
    person.setPersonId(1L);
    person.setFirstName("OldFirst");
    person.setLastName("OldLast");
    person.setEmail("old@nbc.ca");
    person.setLanguage(PreferredLanguageType.EN);

    PersonAssignment pa = new PersonAssignment();
    pa.setPerson(person);
    pa.setUserId(existingEntity.getUserConfigurationId().intValue());

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(pa));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(person);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(personRepository).save(argThat(p ->
        p.getUpdatedBy() != null && p.getUpdatedDt() != null
    ));
  }

  // ==================== entity.setLastUpdateDate coverage ====================

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_setsLastUpdateDate() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(e ->
        e.getLastUpdateDate() != null
    ));
  }

  // ==================== NWPI-14620 coverage: changed-line gaps ====================

  @Test
  void testCreateEmployee_nullProfile_throwsValidation() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.setProfile(null);

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.createEmployee(input, "testUser"));

    assertTrue(ex.getMessage().contains("profile"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testValidatePackages_emptyName_throwsValidation() {
    when(packageTemplateRepository.findByNameAndType("", PackageType.U))
        .thenReturn(Optional.empty());

    assertThrows(FumValidationException.class, () -> service.validatePackages(""));
  }

  @Test
  void testValidatePackages_nameMismatch_throwsValidation() {
    PackageTemplate template = MockData.getPackageTemplateEntity();
    template.setName("DifferentName");

    when(packageTemplateRepository.findByNameAndType("Template1", PackageType.U))
        .thenReturn(Optional.of(template));

    // Template is present but its name does not match the requested name (case-insensitive).
    assertThrows(FumValidationException.class, () -> service.validatePackages("Template1"));
  }

  @Test
  void testAssignUserToPackageTemplate_selectionNotInTemplate_skipsResource() {
    IamUserConfiguration user = new IamUserConfiguration();
    user.setIdpSubject("short002");
    user.setUserConfigurationId(51L);

    Resource resource = new Resource();
    resource.setName("res-A");
    resource.setResourceId(88L);
    PackageTemplateAssignmentResource ptar = new PackageTemplateAssignmentResource();
    ptar.setResource(resource);

    PackageTemplate packageTemplate = MockData.getPackageTemplateEntity();
    packageTemplate.setPackageTemplateAssignmentResources(List.of(ptar));

    FeaturePackageCreateResponse fpResponse = new FeaturePackageCreateResponse();
    fpResponse.setFeaturePackageId(101L);

    when(systemTokenFactory.getBearerToken("fum")).thenReturn(STUB_BEARER_TOKEN);
    when(authorizationClient.createFeaturePackage(anyString(), any())).thenReturn(fpResponse);

    service.assignUserToPackageTemplate(user, packageTemplate, List.of("res-UNKNOWN"), "testUser");

    // The full feature package is assigned, but the unknown selection is skipped.
    verify(userAssignmentService).assignFeaturePackageToUser(anyLong(), anyString(), anyLong(), anyString());
    verify(userAssignmentService, never()).assignResourceToUser(anyLong(), anyString(), anyLong(), anyString());
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_profileNullDefaultModule_throwsValidation() {
    UpdateUserEmployee update = new UpdateUserEmployee();
    update.setFirstName("Jane");
    update.setLastName("Smith");
    UpdateUserEmployeeProfile profile = new UpdateUserEmployeeProfile();
    profile.setDefaultModule(null);
    profile.setActive(true);
    update.setProfile(profile);

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.updateOrCreateEmployee("raza002", update, "testUser"));

    assertTrue(ex.getMessage().contains("Invalid default module"));
    verify(iamUserConfigurationRepository, never()).save(any());
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_nullActive_skipsSetActive() {
    UpdateUserEmployee update = new UpdateUserEmployee();
    update.setFirstName("Jane");
    update.setLastName("Smith");
    UpdateUserEmployeeProfile profile = new UpdateUserEmployeeProfile();
    profile.setDefaultModule("users_module");
    profile.setActive(null);
    update.setProfile(profile);

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");
    existingEntity.setActive(true);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    // active is null -> the existing active flag is left unchanged.
    verify(iamUserConfigurationRepository).save(argThat(e ->
        Boolean.TRUE.equals(e.getActive())
            && e.getUserPreferences() != null
            && "users_module".equals(e.getUserPreferences().get("defaultModule"))));
  }

  // ==================== state transition on create / update ====================

  @Test
  void testCreateEmployee_activeTrue_setsActiveState() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setActive(true);

    stubCreateEmployeeRepositories(input);

    service.createEmployee(input, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(e ->
        Boolean.TRUE.equals(e.getActive())
            && UserStateEnum.ACTIVE.dbValue.equals(e.getState())
            && UserStateDescriptionEnum.ACTIVE.dbValue.equals(e.getStateDescription())
            && "".equals(e.getStateAction())
            && e.getStatusLastUpdated() != null));
  }

  @Test
  void testCreateEmployee_activeFalse_setsSuspendedState() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setActive(false);

    stubCreateEmployeeRepositories(input);

    service.createEmployee(input, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(e ->
        Boolean.FALSE.equals(e.getActive())
            && UserStateEnum.INACTIVE.dbValue.equals(e.getState())
            && UserStateDescriptionEnum.SUSPENDED.dbValue.equals(e.getStateDescription())
            && "".equals(e.getStateAction())
            && e.getStatusLastUpdated() != null));
  }

  @Test
  void testCreateEmployee_activeNull_defaultsToActiveState() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setActive(null);

    stubCreateEmployeeRepositories(input);

    service.createEmployee(input, "testUser");

    // active omitted -> employee is created active, never with a null state.
    verify(iamUserConfigurationRepository).save(argThat(e ->
        Boolean.TRUE.equals(e.getActive())
            && UserStateEnum.ACTIVE.dbValue.equals(e.getState())
            && UserStateDescriptionEnum.ACTIVE.dbValue.equals(e.getStateDescription())
            && "".equals(e.getStateAction())
            && e.getStatusLastUpdated() != null));
  }

  @Test
  void testCreateEmployee_activeFalse_cascadesSuspendToLinkedAccounts() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setActive(false);

    stubCreateEmployeeRepositories(input);

    Person person = personWithId(1L);
    IamUserConfiguration linked = linkedAccount(5555L, true);
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 5555)));
    when(iamUserConfigurationRepository.findAllById(List.of(5555L)))
        .thenReturn(List.of(linked));
    stubOktaProfile(oktaSuspendedProfile());

    service.createEmployee(input, "testUser");

    // create cascades the requested status to linked accounts, exactly as PUT and PATCH do
    assertEquals(Boolean.FALSE, linked.getActive());
    assertEquals(UserStateEnum.INACTIVE.dbValue, linked.getState());
    assertEquals(UserStateDescriptionEnum.SUSPENDED.dbValue, linked.getStateDescription());
    assertEquals("", linked.getStateAction());
    assertNotNull(linked.getStatusLastUpdated());
    verify(iamUserConfigurationRepository).save(linked);
    // the linked account is a real Okta user, so the suspend must reach Okta too
    verify(externalClientService).updateOktaUserStatus(linked.getIdpUserIdentifier(), false);
  }

  @Test
  void testCreateEmployee_activeTrue_doesNotCascadeToLinkedAccounts() {
    // creating/activating the primary account must not activate linked accounts.
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setActive(true);

    stubCreateEmployeeRepositories(input);
    stubOktaProfile(oktaActiveProfile());

    service.createEmployee(input, "testUser");

    verify(personAssignmentRepository, never()).findAllByPersonPersonId(anyLong());
    verify(iamUserConfigurationRepository, never()).findAllById(any());
  }

  @Test
  void testCreateEmployee_activeNull_doesNotCascadeToLinkedAccounts() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setActive(null);

    stubCreateEmployeeRepositories(input);

    Person person = personWithId(1L);
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 5555)));

    service.createEmployee(input, "testUser");

    // active omitted -> linked accounts are left alone, matching PUT and PATCH
    verify(iamUserConfigurationRepository, never()).findAllById(anyList());
  }

  @Test
  void testCreateEmployee_activeFalse_noLinkedAccounts_skipsCascade() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setActive(false);

    stubCreateEmployeeRepositories(input);

    Person person = personWithId(1L);
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    // the only assignment is the employee just created -> nothing to cascade to
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 1234)));

    service.createEmployee(input, "testUser");

    verify(iamUserConfigurationRepository, never()).findAllById(anyList());
  }

  @Test
  void testCreateEmployee_doesNotPushStatusToOktaForTheEmployeeRow() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setActive(false);

    stubCreateEmployeeRepositories(input);

    service.createEmployee(input, "testUser");

    // the employee row is an internal (IAMi) user with no Okta profile, and it has no linked
    // accounts here, so create must not reach Okta at all
    verify(externalClientService, never()).updateOktaUserStatus(anyString(), anyBoolean());
  }

  @Test
  void testCreateEmployee_activeNull_doesNotCallOkta() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setActive(null);

    stubCreateEmployeeRepositories(input);

    service.createEmployee(input, "testUser");

    // active omitted -> no cascade, so nothing is pushed to Okta
    verify(externalClientService, never()).updateOktaUserStatus(anyString(), anyBoolean());
  }

  @Test
  void testUpdateExistingEmployee_activeFalse_pushesStatusToOkta() {
    IamUserConfiguration entity = empUserConfig("emp-okta-put");
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    update.getProfile().setActive(false);

    Person person = personWithId(1L);
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, entity.getUserConfigurationId().intValue())));
    when(personAssignmentRepository.findAllByPersonPersonId(1L)).thenReturn(List.of());

    service.updateExistingEmployee(entity, update, "testUser");

    verify(externalClientService).updateOktaUserStatus(entity.getIdpUserIdentifier(), false);
  }

  @Test
  void testUpdateExistingEmployee_activeNull_doesNotCallOkta() {
    IamUserConfiguration entity = empUserConfig("emp-okta-put-null");
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    update.getProfile().setActive(null);

    Person person = personWithId(1L);
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, entity.getUserConfigurationId().intValue())));

    service.updateExistingEmployee(entity, update, "testUser");

    verify(externalClientService, never()).updateOktaUserStatus(anyString(), anyBoolean());
  }

  @Test
  void testUpdateOrCreateEmployee_activeFalse_setsSuspendedStateAndCascades() {
    UpdateUserEmployee update = new UpdateUserEmployee();
    update.setFirstName("Jane");
    update.setLastName("Smith");
    UpdateUserEmployeeProfile profile = new UpdateUserEmployeeProfile();
    profile.setDefaultModule("users_module");
    profile.setActive(false);
    update.setProfile(profile);

    IamUserConfiguration existingEntity = empUserConfig("raza002");
    existingEntity.setActive(true);
    Person person = personWithId(1L);
    IamUserConfiguration linked = linkedAccount(5555L, true);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 5555)));
    when(iamUserConfigurationRepository.findAllById(List.of(5555L)))
        .thenReturn(List.of(linked));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    stubOktaProfile(oktaSuspendedProfile());

    service.updateOrCreateEmployee("raza002", update, "testUser");

    assertEquals(Boolean.FALSE, existingEntity.getActive());
    assertEquals(UserStateEnum.INACTIVE.dbValue, existingEntity.getState());
    assertEquals(UserStateDescriptionEnum.SUSPENDED.dbValue, existingEntity.getStateDescription());
    assertEquals("", existingEntity.getStateAction());
    assertNotNull(existingEntity.getStatusLastUpdated());

    // the transition cascades to the linked account, exactly as the PATCH endpoint does
    assertEquals(Boolean.FALSE, linked.getActive());
    assertEquals(UserStateEnum.INACTIVE.dbValue, linked.getState());
    assertEquals(UserStateDescriptionEnum.SUSPENDED.dbValue, linked.getStateDescription());
    verify(iamUserConfigurationRepository).save(linked);
  }

  @Test
  void testUpdateOrCreateEmployee_activeTrue_setsActiveStateAndDoesNotCascade() {
    // PUT activate must only activate the primary/SSO account, not linked accounts.
    UpdateUserEmployee update = new UpdateUserEmployee();
    update.setFirstName("Jane");
    update.setLastName("Smith");
    UpdateUserEmployeeProfile profile = new UpdateUserEmployeeProfile();
    profile.setDefaultModule("users_module");
    profile.setActive(true);
    update.setProfile(profile);

    IamUserConfiguration existingEntity = empUserConfig("raza002");
    existingEntity.setActive(false);
    Person person = personWithId(1L);
    IamUserConfiguration linked = linkedAccount(5555L, false);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);
    stubOktaProfile(oktaActiveProfile());

    service.updateOrCreateEmployee("raza002", update, "testUser");

    assertEquals(Boolean.TRUE, existingEntity.getActive());
    assertEquals(UserStateEnum.ACTIVE.dbValue, existingEntity.getState());
    assertEquals(UserStateDescriptionEnum.ACTIVE.dbValue, existingEntity.getStateDescription());
    assertEquals("", existingEntity.getStateAction());
    assertNotNull(existingEntity.getStatusLastUpdated());

    // the linked account is left untouched: no fetch of the linked rows, no save
    assertEquals(Boolean.FALSE, linked.getActive());
    verify(iamUserConfigurationRepository, never()).findAllById(any());
    verify(iamUserConfigurationRepository, never()).save(linked);
  }

  @Test
  void testUpdateOrCreateEmployee_activeNull_leavesStateUntouched() {
    UpdateUserEmployee update = new UpdateUserEmployee();
    update.setFirstName("Jane");
    update.setLastName("Smith");
    UpdateUserEmployeeProfile profile = new UpdateUserEmployeeProfile();
    profile.setDefaultModule("users_module");
    profile.setActive(null);
    update.setProfile(profile);

    IamUserConfiguration existingEntity = empUserConfig("raza002");
    existingEntity.setActive(true);
    existingEntity.setState(UserStateEnum.ONBOARDING.dbValue);
    existingEntity.setStateDescription(UserStateDescriptionEnum.PENDING_USER_ACTION.dbValue);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    // active omitted -> no state transition is applied.
    assertEquals(UserStateEnum.ONBOARDING.dbValue, existingEntity.getState());
    assertEquals(UserStateDescriptionEnum.PENDING_USER_ACTION.dbValue,
        existingEntity.getStateDescription());
    verify(iamUserConfigurationRepository, never()).findAllById(anyList());
  }

  private void stubCreateEmployeeRepositories(CreateUserEmployee input) {
    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());
    savedEntity.setUsername(input.getProfile().getShortId());

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(input.getProfile().getShortId()))
        .thenReturn(Optional.empty());
    when(personRepository.findFirstByEmail(input.getEmail()))
        .thenReturn(Optional.empty());
    when(personRepository.save(any(Person.class)))
        .thenReturn(personWithId(1L));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_rrcodesPresentFirmNull_usesExistingFirm() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm(null);
    assignment.setRrcodes(List.of("RR001"));
    update.getProfile().setAssignment(assignment);

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");

    // User already has an assigned firm; the update omits the firm and only changes RR codes.
    Firm assignedFirm = new Firm();
    assignedFirm.setFirmId("firm-001");
    UserAssignmentFirm uaf = new UserAssignmentFirm();
    uaf.setAssignmentType(UserAssignmentType.F);
    uaf.setFirm(assignedFirm);
    existingEntity.setUserAssignmentFirms(List.of(uaf));

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    // rrcodes provided but firm omitted -> RR codes are reassigned using the user's existing firm.
    verify(rrCodeService).assignRrCodesToUser(eq(existingEntity), argThat(f ->
        f != null && "firm-001".equals(f.getFirmId())), eq(List.of("RR001")), anyString(), anyBoolean());
  }

  @Test
  void testUpdateOrCreateEmployee_existingEmpUser_rrcodesPresentNoFirmAnywhere_delegatesNullFirm() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm(null);
    assignment.setRrcodes(List.of("RR001"));
    update.getProfile().setAssignment(assignment);

    IamUserConfiguration existingEntity = MockData.getIamUserConfigurationEntity();
    existingEntity.setUsername("raza002");
    existingEntity.setIdpSubject("raza002");
    existingEntity.setIdp("IAMi");
    existingEntity.setUserAssignmentFirms(null);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingEntity));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(existingEntity);

    service.updateOrCreateEmployee("raza002", update, "testUser");

    // No firm in the request and none assigned -> delegate with a null firm so
    // rrCodeService raises the FIRM_MISSING validation error.
    verify(rrCodeService).assignRrCodesToUser(eq(existingEntity), isNull(), eq(List.of("RR001")), anyString(), anyBoolean());
  }

  @Test
  void testToCreateUserEmployee_nullProfile_leavesProfileNull() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    update.setProfile(null);

    CreateUserEmployee result = service.toCreateUserEmployee("raza002", update);

    assertNull(result.getProfile());
    assertEquals("Jane", result.getFirstName());
  }

  @Test
  void testDeleteEmployee_personWithNoAssignments_personDeletedWithoutDeleteAll() {
    String shortId = "emp-noassign";
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setIdpSubject(shortId);
    userConfig.setUsername(shortId);

    Person person = new Person();
    person.setPersonId(9001L);
    person.setFirstName("No");
    person.setLastName("Assign");

    PersonAssignment thisUserLink = new PersonAssignment();
    thisUserLink.setPersonAssignmentId(1L);
    thisUserLink.setPerson(person);
    thisUserLink.setUserId(userConfig.getUserConfigurationId().intValue());

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(iamUserConfigurationRepository.findById(userConfig.getUserConfigurationId()))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(thisUserLink));
    when(personAssignmentRepository.findAllByPersonPersonId(person.getPersonId()))
        .thenReturn(List.of());
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType(shortId, UserAssignmentType.P))
        .thenReturn(Optional.of(List.of()));

    service.deleteEmployee(shortId);

    // Person has no remaining assignments -> deleteAll is skipped but the Person is still removed.
    verify(personAssignmentRepository, never()).deleteAll(any());
    verify(personRepository).delete(person);
  }

  // ==================== NWPI-14901: upper-case Short ID / case-insensitive matching ====================

  @Test
  void testCreateEmployee_shortIdStoredUpperCase() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setShortId("raza002");

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject("RAZA002");
    savedEntity.setUsername("RAZA002");

    Person savedPerson = new Person();
    savedPerson.setPersonId(10L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);

    service.createEmployee(input, "testUser");

    ArgumentCaptor<IamUserConfiguration> captor =
        ArgumentCaptor.forClass(IamUserConfiguration.class);
    verify(iamUserConfigurationRepository).save(captor.capture());
    IamUserConfiguration persisted = captor.getValue();
    assertEquals("RAZA002", persisted.getUsername());
    assertEquals("raza002", persisted.getIdpSubject());
    assertEquals("raza002", persisted.getBngfReferenceId());
  }

  @Test
  void testCreateEmployee_shortIdTrimmedAndUpperCased() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setShortId("  raza002  ");

    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject("RAZA002");
    savedEntity.setUsername("RAZA002");

    Person savedPerson = new Person();
    savedPerson.setPersonId(10L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    when(personRepository.save(any(Person.class)))
        .thenReturn(savedPerson);

    service.createEmployee(input, "testUser");

    ArgumentCaptor<IamUserConfiguration> captor =
        ArgumentCaptor.forClass(IamUserConfiguration.class);
    verify(iamUserConfigurationRepository).save(captor.capture());
    IamUserConfiguration persisted = captor.getValue();
    assertEquals("RAZA002", persisted.getUsername());
    assertEquals("raza002", persisted.getIdpSubject());
    assertEquals("raza002", persisted.getBngfReferenceId());
  }

  @Test
  void testCreateEmployee_paddedShortIdAlreadyTaken_throwsConflict() {
    // The duplicate check must trim: IgnoreCase renders upper(x) = upper(?) but does not trim, so
    // an untrimmed lookup would miss the existing row and the insert would breach the unique index.
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    input.getProfile().setShortId("  raza002  ");

    IamUserConfiguration existing = new IamUserConfiguration();
    existing.setUsername("RAZA002");
    existing.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existing));

    assertThrows(FumConflictException.class, () -> service.createEmployee(input, "testUser"));
    verify(iamUserConfigurationRepository, never()).save(any(IamUserConfiguration.class));
  }

  @Test
  void testCreateEmployee_shortIdHeldByNonEmployee_throwsConflict() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();

    IamUserConfiguration existingNonEmployee = new IamUserConfiguration();
    existingNonEmployee.setUsername("raza002");
    existingNonEmployee.setIdp("nbin");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("raza002"))
        .thenReturn(Optional.of(existingNonEmployee));

    FumConflictException ex = assertThrows(FumConflictException.class,
        () -> service.createEmployee(input, "testUser"));

    assertEquals(Constants.EMPLOYEE_EXISTS_CODE, ex.getCode());
    assertTrue(ex.getMessage().contains("raza002"));
    verify(iamUserConfigurationRepository, never()).save(any(IamUserConfiguration.class));
    verify(personRepository, never()).save(any(Person.class));
  }

  @Test
  void testGetEmployeeUser_shortIdCaseInsensitive_returnsDto() {
    // The row still holds the pre-loader lower-case Short ID; the caller sends it upper case.
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUsername("raza002");
    userConfig.setIdpSubject("raza002");
    userConfig.setIdp("IAMi");

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase("RAZA002"))
        .thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase("RAZA002"))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());

    EmployeeUserConfiguration dto = service.getEmployeeUser("RAZA002");

    assertNotNull(dto);
    assertEquals("raza002", dto.getProfile().getShortId());
    verify(iamUserConfigurationRepository).findFirstByIdpSubjectIgnoreCase("RAZA002");
    verify(iamUserConfigurationRepository).findFirstByUsernameIgnoreCase("RAZA002");
  }

  @Test
  void testPatchEmployee_shortIdCaseInsensitive_updatesExistingEntity() {
    IamUserConfiguration userConfig = empUserConfig("raza002");
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setFirstName("NewFirst");

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase("RAZA002"))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));

    service.patchEmployee("RAZA002", patch, "testUser");

    verify(iamUserConfigurationRepository).save(argThat(uc -> "NewFirst".equals(uc.getFirstName())));
    verify(personRepository).save(argThat(p -> "NewFirst".equals(p.getFirstName())));
  }

  @Test
  void testDeleteEmployee_shortIdCaseInsensitive_deletesExistingProfile() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setIdpSubject("raza002");
    userConfig.setUsername("raza002");

    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase("RAZA002"))
        .thenReturn(Optional.of(userConfig));
    when(iamUserConfigurationRepository.findById(userConfig.getUserConfigurationId()))
        .thenReturn(Optional.of(userConfig));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType("raza002", UserAssignmentType.P))
        .thenReturn(Optional.of(List.of()));

    service.deleteEmployee("RAZA002");

    verify(userAssignmentRepository).deleteUserAssignmentsByIdpSubject("raza002");
    verify(iamUserConfigurationRepository).delete(userConfig);
  }

  private static FeaturePackageCreateResponse buildFpResponse() {
    FeaturePackageCreateResponse r = new FeaturePackageCreateResponse();
    r.setFeaturePackageId(100L);
    return r;
  }

  private static UserAssignmentFeaturePackage buildFeaturePackageAssignment(
      String resourceName, boolean restricted, boolean selected) {
    Resource resource = new Resource();
    resource.setName(resourceName);
    resource.setRestriction(restricted);

    PackageTemplateAssignmentResource ptar = new PackageTemplateAssignmentResource();
    ptar.setResource(resource);

    FeaturePackageAssignmentResource detail = new FeaturePackageAssignmentResource();
    detail.setPackageTemplateAssignmentResource(ptar);
    detail.setSelected(selected);

    FeaturePackage fp = new FeaturePackage();
    fp.setFeaturePackageAssignmentResources(List.of(detail));

    UserAssignmentFeaturePackage uafp = new UserAssignmentFeaturePackage();
    uafp.setAssignmentType(UserAssignmentType.P);
    uafp.setFeaturePackage(fp);
    return uafp;
  }

  /**
   * Builds an OktaUserProfile from JSON. RecoveryQuestion is package-private in commons-ciam, so it
   * cannot be instantiated directly from this package - deserializing mirrors the real Okta payload.
   */
  private static OktaUserProfile oktaProfile(String json) {
    try {
      return JsonMapper.builderWithJackson2Defaults().build().readValue(json,
          OktaUserProfile.class);
    } catch (Exception e) {
      throw new IllegalStateException(e);
    }
  }

  /** An Okta profile for a fully onboarded, active user. */
  private static OktaUserProfile oktaActiveProfile() {
    return oktaProfile("{\"status\":\"ACTIVE\","
        + "\"credentials\":{\"recoveryQuestion\":{\"question\":\"pet\"}},"
        + "\"factors\":[{\"factorType\":\"sms\",\"status\":\"ACTIVE\"}]}");
  }

  /** An Okta profile for a suspended user. */
  private static OktaUserProfile oktaSuspendedProfile() {
    return oktaProfile("{\"status\":\"SUSPENDED\",\"credentials\":{}}");
  }

  /**
   * Stubs every Okta profile read with the same profile. State is derived from Okta, so tests that
   * assert a resulting state must say what Okta reports.
   */
  private void stubOktaProfile(OktaUserProfile profile) {
    when(externalClientService.getOktaUserProfile(anyString(), anyString())).thenReturn(profile);
  }

  /** Wires a single linked account cascade and returns the linked account under test. */
  private IamUserConfiguration cascadeWithOktaProfile(String shortId, OktaUserProfile profile) {
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    ssoAccount.setActive(false);
    Person person = personWithId(1L);
    IamUserConfiguration linked = linkedAccount(5555L, false);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 5555)));
    when(iamUserConfigurationRepository.findAllById(List.of(5555L)))
        .thenReturn(List.of(linked));
    when(externalClientService.getOktaUserProfile("okta-5555", ""))
        .thenReturn(profile);
    return linked;
  }

  @Test
  void testCascade_oktaPasswordExpiredNoFactors_derivesOnboardingStaged() {
    // the QA scenario: deactivating cascades to a linked account that never completed Okta onboarding
    IamUserConfiguration linked = cascadeWithOktaProfile("emp-okta-01",
        oktaProfile("{\"status\":\"PASSWORD_EXPIRED\",\"credentials\":{}}"));

    service.patchEmployee("emp-okta-01", activePatch(false), "testUser");

    assertEquals(UserStateEnum.ONBOARDING.dbValue, linked.getState());
    assertEquals(UserStateDescriptionEnum.STAGED.dbValue, linked.getStateDescription());
    assertEquals(UserStateActionEnum.ONBOARDING.dbValue, linked.getStateAction());
    assertEquals(Boolean.FALSE, linked.getActive());
  }

  @Test
  void testCascade_oktaPasswordExpiredWithInactiveSms_derives2FaPending() {
    IamUserConfiguration linked = cascadeWithOktaProfile("emp-okta-02",
        oktaProfile("{\"status\":\"PASSWORD_EXPIRED\",\"credentials\":{},"
            + "\"factors\":[{\"factorType\":\"sms\",\"status\":\"NOT_SETUP\"}]}"));

    service.patchEmployee("emp-okta-02", activePatch(false), "testUser");

    assertEquals(UserStateEnum.PROVISIONED.dbValue, linked.getState());
    assertEquals(UserStateActionEnum.SET_2FA.dbValue, linked.getStateAction());
  }

  @Test
  void testCascade_oktaPasswordExpiredOnboarded_derivesPasswordExpired() {
    IamUserConfiguration linked = cascadeWithOktaProfile("emp-okta-03",
        oktaProfile("{\"status\":\"PASSWORD_EXPIRED\","
            + "\"credentials\":{\"recoveryQuestion\":{\"question\":\"pet\"}}}"));

    service.patchEmployee("emp-okta-03", activePatch(false), "testUser");

    assertEquals(UserStateEnum.RECOVERY.dbValue, linked.getState());
    assertEquals(UserStateDescriptionEnum.PASSWORD_EXPIRED.dbValue, linked.getStateDescription());
  }

  @Test
  void testCascade_oktaActiveFullyOnboarded_staysActive() {
    IamUserConfiguration linked = cascadeWithOktaProfile("emp-okta-04",
        oktaProfile("{\"status\":\"ACTIVE\","
            + "\"credentials\":{\"recoveryQuestion\":{\"question\":\"pet\"}},"
            + "\"factors\":[{\"factorType\":\"sms\",\"status\":\"ACTIVE\"}]}"));

    service.patchEmployee("emp-okta-04", activePatch(false), "testUser");

    assertEquals(UserStateEnum.ACTIVE.dbValue, linked.getState());
    assertEquals(UserStateDescriptionEnum.ACTIVE.dbValue, linked.getStateDescription());
    assertEquals(Boolean.TRUE, linked.getActive());
  }

  @Test
  void testCascade_oktaActiveNoRecoveryQuestion_derivesOnboardingPending() {
    IamUserConfiguration linked = cascadeWithOktaProfile("emp-okta-05",
        oktaProfile("{\"status\":\"ACTIVE\",\"credentials\":{}}"));

    service.patchEmployee("emp-okta-05", activePatch(false), "testUser");

    assertEquals(UserStateEnum.PROVISIONED.dbValue, linked.getState());
    assertEquals(UserStateDescriptionEnum.PENDING_USER_ACTION.dbValue,
        linked.getStateDescription());
    assertEquals(UserStateActionEnum.ONBOARDING.dbValue, linked.getStateAction());
  }

  @Test
  void testCascade_oktaSuspended_derivesSuspendedOnDeactivate() {
    IamUserConfiguration linked = cascadeWithOktaProfile("emp-okta-06",
        oktaProfile("{\"status\":\"SUSPENDED\",\"credentials\":{}}"));

    service.patchEmployee("emp-okta-06", activePatch(false), "testUser");

    assertEquals(UserStateEnum.INACTIVE.dbValue, linked.getState());
    assertEquals(UserStateDescriptionEnum.SUSPENDED.dbValue, linked.getStateDescription());
    assertEquals(Boolean.FALSE, linked.getActive());
  }

  @Test
  void testCascade_oktaLockedOut_derivesLocked() {
    IamUserConfiguration linked = cascadeWithOktaProfile("emp-okta-07",
        oktaProfile("{\"status\":\"LOCKED_OUT\",\"credentials\":{}}"));

    service.patchEmployee("emp-okta-07", activePatch(false), "testUser");

    assertEquals(UserStateDescriptionEnum.LOCKED.dbValue, linked.getStateDescription());
    assertEquals(UserStateActionEnum.LOCKED.dbValue, linked.getStateAction());
  }

  @Test
  void testCascade_oktaUnknownStatus_derivesDecommissioned() {
    IamUserConfiguration linked = cascadeWithOktaProfile("emp-okta-08",
        oktaProfile("{\"status\":\"DEPROVISIONED\",\"credentials\":{}}"));

    service.patchEmployee("emp-okta-08", activePatch(false), "testUser");

    assertEquals(UserStateEnum.DECOMMISSIONED.dbValue, linked.getState());
  }

  @Test
  void testCascade_oktaProfileUnavailable_throwsServiceException() {
    // getOktaUserProfile swallows transport failures and returns null. State is derived
    // exclusively from Okta, so an unreadable profile now aborts the whole request.
    IamUserConfiguration linked = cascadeWithOktaProfile("emp-okta-09", null);

    FumServiceException ex = assertThrows(FumServiceException.class,
        () -> service.patchEmployee("emp-okta-09", activePatch(false), "testUser"));

    assertEquals(Constants.ERROR_OKTA_STATUS_GET_CODE, ex.getCode());
    // the linked account is never persisted because the derive failed before the save
    verify(iamUserConfigurationRepository, never()).save(linked);
  }

  // -----------------------------------------------------------------------------------------
  // NWPI-15097 - a status change evicts the cached user configuration every CX API checks
  // -----------------------------------------------------------------------------------------

  @Test
  void testPatchEmployee_activeChange_evictsCachedUserConfiguration() {
    String shortId = "emp-cache-01";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    stubOktaProfile(oktaSuspendedProfile());

    service.patchEmployee(shortId, activePatch(false), "testUser");

    verify(redisCacheOperationService).deleteUserConfigurationCache(shortId, 1234, "1234");
  }

  @Test
  void testUpdateExistingEmployee_activeChange_evictsCachedUserConfiguration() {
    String shortId = "emp-cache-02";
    IamUserConfiguration entity = empUserConfig(shortId);
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    update.getProfile().setActive(false);

    Person person = personWithId(1L);
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, entity.getUserConfigurationId().intValue())));
    when(personAssignmentRepository.findAllByPersonPersonId(1L)).thenReturn(List.of());
    stubOktaProfile(oktaSuspendedProfile());

    service.updateExistingEmployee(entity, update, "testUser");

    verify(redisCacheOperationService).deleteUserConfigurationCache(shortId, 1234, "1234");
  }

  @Test
  void testUpdateActiveToLinkedAccounts_evictsEveryLinkedAccountCache() {
    String shortId = "emp-cache-03";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    Person person = personWithId(1L);
    IamUserConfiguration linkedOne = linkedAccount(5555L, true);
    IamUserConfiguration linkedTwo = linkedAccount(6666L, true);
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 1234), assignmentFor(person, 5555),
            assignmentFor(person, 6666)));
    when(iamUserConfigurationRepository.findAllById(List.of(5555L, 6666L)))
        .thenReturn(List.of(linkedOne, linkedTwo));
    stubOktaProfile(oktaSuspendedProfile());

    service.patchEmployee(shortId, activePatch(false), "testUser");

    verify(redisCacheOperationService)
        .deleteUserConfigurationCache("linked-5555", 5555, "okta-5555");
    verify(redisCacheOperationService)
        .deleteUserConfigurationCache("linked-6666", 6666, "okta-6666");
  }

  @Test
  void testPatchEmployee_noActiveChange_doesNotEvictCachedUserConfiguration() {
    String shortId = "emp-cache-04";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    PatchUserEmployeeProfile profile = new PatchUserEmployeeProfile();
    profile.setDefaultModule("users_module");
    PatchUserEmployee patch = new PatchUserEmployee();
    patch.setProfile(profile);
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));

    service.patchEmployee(shortId, patch, "testUser");

    verify(redisCacheOperationService, never())
        .deleteUserConfigurationCache(anyString(), any(), any());
  }

  @Test
  void testDeleteEmployee_evictsCachedUserConfiguration() {
    String shortId = "emp-cache-05";
    IamUserConfiguration userConfig = empUserConfig(shortId);
    when(iamUserConfigurationRepository.findFirstByIdpSubjectIgnoreCase(shortId))
        .thenReturn(Optional.of(userConfig));
    when(iamUserConfigurationRepository.findById(userConfig.getUserConfigurationId()))
        .thenReturn(Optional.of(userConfig));
    when(userAssignmentRepository.findAllByIdpSubjectAndAssignmentType(shortId,
        UserAssignmentType.P)).thenReturn(Optional.of(List.of()));

    service.deleteEmployee(shortId);

    verify(redisCacheOperationService).deleteUserConfigurationCache(shortId, 1234, "1234");
  }

  @Test
  void testPatchEmployee_activeChange_evictsTransactionAwareCacheOnCommit() {
    String shortId = "emp-cache-06";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(linkedPersonAssignment()));
    stubOktaProfile(oktaSuspendedProfile());

    try (AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext()) {
      context.getEnvironment().getPropertySources()
          .addFirst(new MapPropertySource("redis", Map.of("redis.cache.enable", "true")));
      context.register(TransactionAwareRedisCacheConfig.class);
      context.refresh();
      CacheManager cacheManager = context.getBean(CacheManager.class);
      Cache enrich = cacheManager.getCache("UserConfiguration-Enrich");
      Cache usersMe = cacheManager.getCache("UserConfiguration-UsersMe");
      enrich.put(shortId, "inactive");
      usersMe.put(shortId, "inactive");
      EmployeeAccessManagementService cachingService = new EmployeeAccessManagementService(
          iamUserConfigurationRepository, personRepository, personAssignmentRepository,
          userAssignmentRepository, resourceRepository, featurePackageRepository,
          packageTemplateRepository, firmRepository, rrCodeService, userAssignmentService,
          authorizationClient, systemTokenFactory, auditLogService, externalClientService,
          context.getBean(RedisCacheOperationService.class));
      ReflectionTestUtils.setField(cachingService, "entityManager", entityManager);

      new TransactionTemplate(new NoOpTransactionManager()).executeWithoutResult(status -> {
        cachingService.patchEmployee(shortId, activePatch(false), "testUser");
        assertNotNull(enrich.get(shortId));
      });

      assertNull(enrich.get(shortId));
      assertNull(usersMe.get(shortId));
    }
  }

  // Mirrors commons-redis-config, which builds its RedisCacheManager with transactionAware().
  @Configuration(proxyBeanMethods = false)
  @EnableCaching
  static class TransactionAwareRedisCacheConfig {

    @Bean
    CacheManager redisCacheManager() {
      return new TransactionAwareCacheManagerProxy(new ConcurrentMapCacheManager());
    }

    @Bean
    RedisTemplate<?, ?> redisTemplate() {
      return mock(RedisTemplate.class);
    }

    @Bean
    RedisCacheOperationService redisCacheOperationService() {
      return new RedisCacheOperationService();
    }
  }

  private static class NoOpTransactionManager extends AbstractPlatformTransactionManager {

    @Override
    protected Object doGetTransaction() {
      return new Object();
    }

    @Override
    protected void doBegin(Object transaction, TransactionDefinition definition) {
      // no transactional resource
    }

    @Override
    protected void doCommit(DefaultTransactionStatus status) {
      // no transactional resource
    }

    @Override
    protected void doRollback(DefaultTransactionStatus status) {
      // no transactional resource
    }
  }

  private IamUserConfiguration externalLinkedAccount(long userConfigurationId) {
    IamUserConfiguration external = linkedAccount(userConfigurationId, true);
    external.setIdp("okta");
    return external;
  }

  /** Reuses an existing Person whose only linked user is external, as Scenario 2 requires. */
  private Person stubCreateEmployeeOnExistingPerson(CreateUserEmployee input,
      List<PersonAssignment> personLinks) {
    IamUserConfiguration savedEntity = MockData.getIamUserConfigurationEntity();
    savedEntity.setIdpSubject(input.getProfile().getShortId());
    savedEntity.setUsername(input.getProfile().getShortId());

    Person existingPerson = personWithId(10L);
    existingPerson.setEmail(input.getEmail());

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(
        input.getProfile().getShortId())).thenReturn(Optional.empty());
    when(personRepository.findFirstByEmailIgnoreCase(input.getEmail()))
        .thenReturn(Optional.of(existingPerson));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class)))
        .thenReturn(savedEntity);
    // resolves the Person of the employee row just linked
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(existingPerson, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(10L)).thenReturn(personLinks);

    return existingPerson;
  }

  @Test
  void testCreateEmployee_existingPersonWithExternalUsers_assignsEmployeeExternalOktaGroup() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    IamUserConfiguration externalOne = externalLinkedAccount(5555L);
    IamUserConfiguration externalTwo = externalLinkedAccount(6666L);

    Person person = stubCreateEmployeeOnExistingPerson(input,
        List.of(assignmentFor(personWithId(10L), 1234), assignmentFor(personWithId(10L), 5555),
            assignmentFor(personWithId(10L), 6666)));
    // the existing links are external, so the create is allowed to proceed
    when(iamUserConfigurationRepository.findById(5555L)).thenReturn(Optional.of(externalOne));
    when(iamUserConfigurationRepository.findById(6666L)).thenReturn(Optional.of(externalTwo));
    when(iamUserConfigurationRepository.findAllById(List.of(5555L, 6666L)))
        .thenReturn(List.of(externalOne, externalTwo));

    service.createEmployee(input, "testUser");

    assertNotNull(person);
    // the new employee account makes each existing account a secondary account in Okta
    verify(externalClientService).assignOktaUserGroup(externalOne.getIdpUserIdentifier(),
        Constants.EMPLOYEE_EXTERNAL_USER_GROUP);
    verify(externalClientService).assignOktaUserGroup(externalTwo.getIdpUserIdentifier(),
        Constants.EMPLOYEE_EXTERNAL_USER_GROUP);
  }

  @Test
  void testCreateEmployee_existingPersonWithEmpLinkedAccount_skipsEmployeeExternalOktaGroup() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    IamUserConfiguration external = externalLinkedAccount(5555L);
    // a second employee row on the same Person - no Okta profile, never a secondary account
    IamUserConfiguration otherEmp = linkedAccount(7777L, true);

    stubCreateEmployeeOnExistingPerson(input,
        List.of(assignmentFor(personWithId(10L), 1234), assignmentFor(personWithId(10L), 5555),
            assignmentFor(personWithId(10L), 7777)));
    when(iamUserConfigurationRepository.findById(5555L)).thenReturn(Optional.of(external));
    when(iamUserConfigurationRepository.findById(7777L)).thenReturn(Optional.empty());
    when(iamUserConfigurationRepository.findAllById(List.of(5555L, 7777L)))
        .thenReturn(List.of(external, otherEmp));

    service.createEmployee(input, "testUser");

    verify(externalClientService).assignOktaUserGroup(external.getIdpUserIdentifier(),
        Constants.EMPLOYEE_EXTERNAL_USER_GROUP);
    verify(externalClientService, never()).assignOktaUserGroup(otherEmp.getIdpUserIdentifier(),
        Constants.EMPLOYEE_EXTERNAL_USER_GROUP);
  }

  @Test
  void testCreateEmployee_existingPersonWithNoOtherAccounts_skipsEmployeeExternalOktaGroup() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();

    // the only link is the employee row just created -> no secondary account exists
    stubCreateEmployeeOnExistingPerson(input, List.of(assignmentFor(personWithId(10L), 1234)));

    service.createEmployee(input, "testUser");

    verify(externalClientService, never()).assignOktaUserGroup(anyString(), anyString());
  }

  @Test
  void testCreateEmployee_existingPersonWithDecommissionedExternal_skipsEmployeeExternalOktaGroup() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();
    IamUserConfiguration active = externalLinkedAccount(5555L);
    // NWPI-15109: retired by the migration's sunset step - must not regain an entitlement
    IamUserConfiguration decommissioned = externalLinkedAccount(6666L);
    decommissioned.setState(UserStateEnum.DECOMMISSIONED.dbValue);

    stubCreateEmployeeOnExistingPerson(input,
        List.of(assignmentFor(personWithId(10L), 1234), assignmentFor(personWithId(10L), 5555),
            assignmentFor(personWithId(10L), 6666)));
    when(iamUserConfigurationRepository.findById(5555L)).thenReturn(Optional.of(active));
    when(iamUserConfigurationRepository.findById(6666L)).thenReturn(Optional.of(decommissioned));
    when(iamUserConfigurationRepository.findAllById(List.of(5555L, 6666L)))
        .thenReturn(List.of(active, decommissioned));

    service.createEmployee(input, "testUser");

    verify(externalClientService).assignOktaUserGroup(active.getIdpUserIdentifier(),
        Constants.EMPLOYEE_EXTERNAL_USER_GROUP);
    verify(externalClientService, never()).assignOktaUserGroup(
        decommissioned.getIdpUserIdentifier(), Constants.EMPLOYEE_EXTERNAL_USER_GROUP);
  }

  @Test
  void testCreateEmployee_newPerson_skipsEmployeeExternalOktaGroup() {
    CreateUserEmployee input = MockData.getCreateUserEmployee();

    stubCreateEmployeeRepositories(input);

    // a brand new Person has no other account, so there is nothing to mark as secondary
    service.createEmployee(input, "testUser");

    verify(externalClientService, never()).assignOktaUserGroup(anyString(), anyString());
  }

  @Test
  void testPatchEmployee_assignsEmployeeExternalGroupToExternalLinkedAccounts() {
    String shortId = "emp-selfheal-01";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    Person person = personWithId(1L);
    // created before the group existed, so Okta is missing the entitlement
    IamUserConfiguration external = externalLinkedAccount(5555L);
    external.setEmail("stale@nbc.ca");

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 1234), assignmentFor(person, 5555)));
    when(iamUserConfigurationRepository.findAllById(List.of(5555L)))
        .thenReturn(List.of(external));

    service.patchEmployee(shortId, emailPatch("new.email@nbc.ca"), "testUser");

    verify(externalClientService).assignOktaUserGroup(external.getIdpUserIdentifier(),
        Constants.EMPLOYEE_EXTERNAL_USER_GROUP);
  }

  @Test
  void testUpdateExistingEmployee_assignsEmployeeExternalGroupToExternalLinkedAccounts() {
    UpdateUserEmployee update = MockData.getUpdateUserEmployee();
    IamUserConfiguration entity = empUserConfig("emp-selfheal-02");
    Person person = personWithId(1L);
    IamUserConfiguration external = externalLinkedAccount(5555L);

    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 1234), assignmentFor(person, 5555)));
    when(iamUserConfigurationRepository.findAllById(List.of(5555L)))
        .thenReturn(List.of(external));
    when(iamUserConfigurationRepository.save(any(IamUserConfiguration.class))).thenReturn(entity);
    when(personRepository.save(any(Person.class))).thenReturn(person);

    service.updateExistingEmployee(entity, update, "testUser");

    verify(externalClientService).assignOktaUserGroup(external.getIdpUserIdentifier(),
        Constants.EMPLOYEE_EXTERNAL_USER_GROUP);
  }

  @Test
  void testPatchEmployee_noLinkedAccounts_makesNoOktaGroupCall() {
    String shortId = "emp-selfheal-03";
    IamUserConfiguration ssoAccount = empUserConfig(shortId);
    Person person = personWithId(1L);

    when(iamUserConfigurationRepository.findFirstByUsernameIgnoreCase(shortId))
        .thenReturn(Optional.of(ssoAccount));
    when(personAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(assignmentFor(person, 1234)));
    // the employee is the Person's only account - nothing is secondary
    when(personAssignmentRepository.findAllByPersonPersonId(1L))
        .thenReturn(List.of(assignmentFor(person, 1234)));

    service.patchEmployee(shortId, emailPatch("solo@nbc.ca"), "testUser");

    verify(externalClientService, never()).assignOktaUserGroup(anyString(), anyString());
  }

}
