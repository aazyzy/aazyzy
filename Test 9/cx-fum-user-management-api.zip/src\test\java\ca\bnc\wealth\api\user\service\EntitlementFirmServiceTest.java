package ca.bnc.wealth.api.user.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.common.entitlements.user_management.model.Firm;
import ca.bnc.wealth.common.entitlements.user_management.model.FirmsResponse;
import ca.bnc.wealth.common.entitlements.user_management.model.RrCodesResponse;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.iam.FirmAssignmentRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.FinancialEntity;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class EntitlementFirmServiceTest {

    private EntitlementFirmService service;
    private FirmRepository firmRepository;

    @BeforeEach
    void setUp() {
        firmRepository = mock(FirmRepository.class);
        service = new EntitlementFirmService(firmRepository);
    }

    // ==================== getEntitlementFirmsInternals ====================

    @Test
    void testWhenNoFirmsFound_shouldReturnEmptyFirmsList() {
        when(firmRepository.findAllByFirmTypeIn(Set.of(FirmType.NBIN, FirmType.Internal)))
            .thenReturn(Collections.emptyList());

        FirmsResponse response = service.getEntitlementFirmsInternals();

        assertNotNull(response);
        assertNotNull(response.getFirms());
        assertTrue(response.getFirms().isEmpty());
        verify(firmRepository).findAllByFirmTypeIn(Set.of(FirmType.NBIN, FirmType.Internal));
    }

    @Test
    void testWhenFirmsExist_shouldMapBasicFields() {
        ca.bnc.wealth.common.jpa.entity.iam.Firm firmEntity = buildFirmEntity(
            "FIRM-001", "Test Firm", FirmType.NBIN, "A test firm", true);

        when(firmRepository.findAllByFirmTypeIn(Set.of(FirmType.NBIN, FirmType.Internal)))
            .thenReturn(List.of(firmEntity));

        FirmsResponse response = service.getEntitlementFirmsInternals();

        assertNotNull(response);
        assertEquals(1, response.getFirms().size());

        Firm firm = response.getFirms().get(0);
        assertEquals("FIRM-001", firm.getId());
        assertEquals("Test Firm", firm.getName());
        assertEquals("NBIN", firm.getType());
        assertEquals("A test firm", firm.getDescription());
        assertEquals(true, firm.getActive());
    }

    @Test
    void testWhenFirmHasFinancialEntity_shouldMapFinancialFields() {
        ca.bnc.wealth.common.jpa.entity.iam.Firm firmEntity = buildFirmEntity(
            "FIRM-002", "Financial Firm", FirmType.Internal, null, true);

        FinancialEntity fe = new FinancialEntity();
        fe.setBrokerCode("BRK01");
        fe.setBranchNumber("1234");
        fe.setDealerCode("DLR01");
        firmEntity.setFinancialEntity(fe);

        when(firmRepository.findAllByFirmTypeIn(Set.of(FirmType.NBIN, FirmType.Internal)))
            .thenReturn(List.of(firmEntity));

        FirmsResponse response = service.getEntitlementFirmsInternals();

        Firm firm = response.getFirms().get(0);
        assertEquals("BRK01", firm.getBrokerCode());
        assertEquals("1234", firm.getbNumber());
        assertEquals("DLR01", firm.getDealerCode());
    }

    @Test
    void testWhenFirmHasNoFinancialEntity_shouldNotSetFinancialFields() {
        ca.bnc.wealth.common.jpa.entity.iam.Firm firmEntity = buildFirmEntity(
            "FIRM-003", "No Finance Firm", FirmType.NBIN, null, false);
        firmEntity.setFinancialEntity(null);

        when(firmRepository.findAllByFirmTypeIn(Set.of(FirmType.NBIN, FirmType.Internal)))
            .thenReturn(List.of(firmEntity));

        FirmsResponse response = service.getEntitlementFirmsInternals();

        Firm firm = response.getFirms().get(0);
        assertNull(firm.getBrokerCode());
        assertNull(firm.getbNumber());
        assertNull(firm.getDealerCode());
    }

    @Test
    void testWhenFirmHasNullFirmType_shouldMapTypeAsNull() {
        ca.bnc.wealth.common.jpa.entity.iam.Firm firmEntity = buildFirmEntity(
            "FIRM-004", "Null Type Firm", null, null, true);

        when(firmRepository.findAllByFirmTypeIn(Set.of(FirmType.NBIN, FirmType.Internal)))
            .thenReturn(List.of(firmEntity));

        FirmsResponse response = service.getEntitlementFirmsInternals();

        Firm firm = response.getFirms().get(0);
        assertNull(firm.getType());
    }

    @Test
    void testWhenFirmHasSingleRrCode_shouldMapAsCodes() {
        ca.bnc.wealth.common.jpa.entity.iam.Firm firmEntity = buildFirmEntity(
            "FIRM-005", "RR Firm", FirmType.NBIN, null, true);

        IamRrCodeRange rrCodeRange = new IamRrCodeRange();
        rrCodeRange.setFromRrCode("ABC");
        rrCodeRange.setToRrCode("ABC");

        FirmAssignmentRrCodeRange assignment = new FirmAssignmentRrCodeRange();
        assignment.setIamRrCodeRange(rrCodeRange);

        firmEntity.setFirmAssignmentRrCodeRanges(List.of(assignment));

        when(firmRepository.findAllByFirmTypeIn(Set.of(FirmType.NBIN, FirmType.Internal)))
            .thenReturn(List.of(firmEntity));

        FirmsResponse response = service.getEntitlementFirmsInternals();

        Firm firm = response.getFirms().get(0);
        assertNotNull(firm.getRrCodes());
        assertEquals(1, firm.getRrCodes().getCodes().size());
        assertEquals("ABC", firm.getRrCodes().getCodes().get(0));
        assertTrue(firm.getRrCodes().getRanges().isEmpty());
    }

    @Test
    void testWhenFirmHasRrCodeRange_shouldMapAsRanges() {
        ca.bnc.wealth.common.jpa.entity.iam.Firm firmEntity = buildFirmEntity(
            "FIRM-006", "Range Firm", FirmType.NBIN, null, true);

        IamRrCodeRange rrCodeRange = new IamRrCodeRange();
        rrCodeRange.setFromRrCode("AAA");
        rrCodeRange.setToRrCode("ZZZ");

        FirmAssignmentRrCodeRange assignment = new FirmAssignmentRrCodeRange();
        assignment.setIamRrCodeRange(rrCodeRange);

        firmEntity.setFirmAssignmentRrCodeRanges(List.of(assignment));

        when(firmRepository.findAllByFirmTypeIn(Set.of(FirmType.NBIN, FirmType.Internal)))
            .thenReturn(List.of(firmEntity));

        FirmsResponse response = service.getEntitlementFirmsInternals();

        Firm firm = response.getFirms().get(0);
        assertNotNull(firm.getRrCodes());
        assertTrue(firm.getRrCodes().getCodes().isEmpty());
        assertEquals(1, firm.getRrCodes().getRanges().size());
        assertEquals("AAA", firm.getRrCodes().getRanges().get(0).getFrom());
        assertEquals("ZZZ", firm.getRrCodes().getRanges().get(0).getTo());
    }

    @Test
    void testWhenFirmHasMixedRrCodes_shouldSeparateCodesAndRanges() {
        ca.bnc.wealth.common.jpa.entity.iam.Firm firmEntity = buildFirmEntity(
            "FIRM-007", "Mixed Firm", FirmType.Internal, null, true);

        IamRrCodeRange singleCode = new IamRrCodeRange();
        singleCode.setFromRrCode("XYZ");
        singleCode.setToRrCode("XYZ");

        IamRrCodeRange range = new IamRrCodeRange();
        range.setFromRrCode("100");
        range.setToRrCode("200");

        FirmAssignmentRrCodeRange assignment1 = new FirmAssignmentRrCodeRange();
        assignment1.setIamRrCodeRange(singleCode);

        FirmAssignmentRrCodeRange assignment2 = new FirmAssignmentRrCodeRange();
        assignment2.setIamRrCodeRange(range);

        firmEntity.setFirmAssignmentRrCodeRanges(List.of(assignment1, assignment2));

        when(firmRepository.findAllByFirmTypeIn(Set.of(FirmType.NBIN, FirmType.Internal)))
            .thenReturn(List.of(firmEntity));

        FirmsResponse response = service.getEntitlementFirmsInternals();

        Firm firm = response.getFirms().get(0);
        assertEquals(1, firm.getRrCodes().getCodes().size());
        assertEquals("XYZ", firm.getRrCodes().getCodes().get(0));
        assertEquals(1, firm.getRrCodes().getRanges().size());
        assertEquals("100", firm.getRrCodes().getRanges().get(0).getFrom());
        assertEquals("200", firm.getRrCodes().getRanges().get(0).getTo());
    }

    @Test
    void testWhenFirmHasNullRrCodeRanges_shouldReturnEmptyCodesAndRanges() {
        ca.bnc.wealth.common.jpa.entity.iam.Firm firmEntity = buildFirmEntity(
            "FIRM-008", "No RR Firm", FirmType.NBIN, null, true);
        firmEntity.setFirmAssignmentRrCodeRanges(null);

        when(firmRepository.findAllByFirmTypeIn(Set.of(FirmType.NBIN, FirmType.Internal)))
            .thenReturn(List.of(firmEntity));

        FirmsResponse response = service.getEntitlementFirmsInternals();

        Firm firm = response.getFirms().get(0);
        assertNotNull(firm.getRrCodes());
        assertTrue(firm.getRrCodes().getCodes().isEmpty());
        assertTrue(firm.getRrCodes().getRanges().isEmpty());
    }

    @Test
    void testWhenAssignmentHasNullIamRrCodeRange_shouldSkipIt() {
        ca.bnc.wealth.common.jpa.entity.iam.Firm firmEntity = buildFirmEntity(
            "FIRM-009", "Null Range Firm", FirmType.NBIN, null, true);

        FirmAssignmentRrCodeRange assignmentWithNull = new FirmAssignmentRrCodeRange();
        assignmentWithNull.setIamRrCodeRange(null);

        IamRrCodeRange validRange = new IamRrCodeRange();
        validRange.setFromRrCode("DEF");
        validRange.setToRrCode("DEF");

        FirmAssignmentRrCodeRange validAssignment = new FirmAssignmentRrCodeRange();
        validAssignment.setIamRrCodeRange(validRange);

        firmEntity.setFirmAssignmentRrCodeRanges(List.of(assignmentWithNull, validAssignment));

        when(firmRepository.findAllByFirmTypeIn(Set.of(FirmType.NBIN, FirmType.Internal)))
            .thenReturn(List.of(firmEntity));

        FirmsResponse response = service.getEntitlementFirmsInternals();

        Firm firm = response.getFirms().get(0);
        assertEquals(1, firm.getRrCodes().getCodes().size());
        assertEquals("DEF", firm.getRrCodes().getCodes().get(0));
    }

    @Test
    void testWhenMultipleFirmsExist_shouldMapAll() {
        ca.bnc.wealth.common.jpa.entity.iam.Firm firm1 = buildFirmEntity(
            "FIRM-A", "Firm A", FirmType.NBIN, null, true);
        ca.bnc.wealth.common.jpa.entity.iam.Firm firm2 = buildFirmEntity(
            "FIRM-B", "Firm B", FirmType.Internal, null, false);

        when(firmRepository.findAllByFirmTypeIn(Set.of(FirmType.NBIN, FirmType.Internal)))
            .thenReturn(List.of(firm1, firm2));

        FirmsResponse response = service.getEntitlementFirmsInternals();

        assertEquals(2, response.getFirms().size());
        assertEquals("FIRM-A", response.getFirms().get(0).getId());
        assertEquals("FIRM-B", response.getFirms().get(1).getId());
    }

    // ==================== getEntitlementRrCodesInternals ====================

    @Test
    void testGetEntitlementRrCodesInternals_shouldReturnHardCodedRrCodes() {
        RrCodesResponse response = service.getEntitlementRrCodesInternals();

        assertNotNull(response);
        assertNotNull(response.getRrCodes());
        assertEquals(Constants.INTERNAL_RRCODE, response.getRrCodes().get(0));
    }

    // ==================== Helper Methods ====================

    private ca.bnc.wealth.common.jpa.entity.iam.Firm buildFirmEntity(
        String firmId, String name, FirmType firmType, String description, Boolean active) {

        ca.bnc.wealth.common.jpa.entity.iam.Firm firm = new ca.bnc.wealth.common.jpa.entity.iam.Firm();
        firm.setFirmId(firmId);
        firm.setName(name);
        firm.setFirmType(firmType);
        firm.setDescription(description);
        firm.setActive(active);
        firm.setFirmAssignmentRrCodeRanges(Collections.emptyList());
        return firm;
    }
}
