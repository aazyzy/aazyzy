package ca.bnc.wealth.api.user.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import ca.bnc.wealth.common.entitlements.user_management.model.ModulesResponse;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class EntitlementModuleServiceTest {

  private EntitlementModuleService service;

  @BeforeEach
  void setUp() {
    service = new EntitlementModuleService();
  }

  @Test
  void testGetEntitlementModules_returnsDefaultModulesWithoutBlanks() {
    ModulesResponse response = service.getEntitlementModules();

    assertNotNull(response);
    assertNotNull(response.getModules());
    assertEquals(List.of("firm_client_accounts", "users_module", "compass_r2"), response.getModules());
  }

  @Test
  void testGetEntitlementModules_excludesEmptyPlaceholder() {
    ModulesResponse response = service.getEntitlementModules();

    assertFalse(response.getModules().contains(""));
  }
}
