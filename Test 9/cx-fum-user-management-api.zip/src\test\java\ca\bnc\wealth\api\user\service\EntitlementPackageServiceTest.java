package ca.bnc.wealth.api.user.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.entitlements.user_management.model.ModelPackage;
import ca.bnc.wealth.common.entitlements.user_management.model.PackageFeature;
import ca.bnc.wealth.common.entitlements.user_management.model.PackagesResponse;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentUserGroup;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.entity.iam.UserGroup;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class EntitlementPackageServiceTest {

  private PackageTemplateRepository packageTemplateRepository;
  private EntitlementPackageService service;

  @BeforeEach
  void setUp() {
    packageTemplateRepository = mock(PackageTemplateRepository.class);
    service = new EntitlementPackageService(packageTemplateRepository);
  }

  @Test
  void testGetEntitlementPackages_returnsAllPackagesWithFeatures() {
    PackageTemplateAssignmentResource mandatorySelected =
        buildAssignment("Advanced Trading", PackageAssignmentType.S, PackageAssignmentMode.M, true);
    PackageTemplateAssignmentResource optionalUnselected =
        buildAssignment("Basic Reporting", PackageAssignmentType.S, PackageAssignmentMode.O, false);

    PackageTemplate template = buildTemplate(10L, "Premium Trading",
        "Premium trading package with advanced features", true,
        List.of(mandatorySelected, optionalUnselected));
    template.setPackageTemplateAssignmentUserGroups(
        List.of(buildUserGroupAssignment("Trading Group", PackageAssignmentType.G)));

    when(packageTemplateRepository.findAll()).thenReturn(List.of(template));

    PackagesResponse response = service.getEntitlementPackages();

    assertNotNull(response);
    assertNotNull(response.getPackages());
    assertEquals(1, response.getPackages().size());

    ModelPackage dto = response.getPackages().get(0);
    assertEquals("10", dto.getId());
    assertEquals("Premium Trading", dto.getName());
    assertEquals("Premium trading package with advanced features", dto.getDescription());
    assertEquals("Trading Group", dto.getGroup());
    assertEquals(true, dto.getActive());

    assertEquals(2, dto.getFeatures().size());

    PackageFeature feature1 = dto.getFeatures().get(0);
    assertEquals("Advanced Trading", feature1.getResource());
    assertTrue(feature1.getMandatory());
    assertTrue(feature1.getSelected());

    PackageFeature feature2 = dto.getFeatures().get(1);
    assertEquals("Basic Reporting", feature2.getResource());
    assertFalse(feature2.getMandatory());
    assertFalse(feature2.getSelected());

    verify(packageTemplateRepository).findAll();
  }

  @Test
  void testGetEntitlementPackages_emptyList() {
    when(packageTemplateRepository.findAll()).thenReturn(Collections.emptyList());

    PackagesResponse response = service.getEntitlementPackages();

    assertNotNull(response);
    assertNotNull(response.getPackages());
    assertTrue(response.getPackages().isEmpty());

    verify(packageTemplateRepository).findAll();
  }

  @Test
  void testGetEntitlementPackages_nullAssignmentsHandled() {
    PackageTemplate template = buildTemplate(20L, "Empty Package", "No features", false, null);

    when(packageTemplateRepository.findAll()).thenReturn(List.of(template));

    PackagesResponse response = service.getEntitlementPackages();

    assertNotNull(response);
    assertEquals(1, response.getPackages().size());

    ModelPackage dto = response.getPackages().get(0);
    assertEquals("20", dto.getId());
    assertEquals(false, dto.getActive());
    assertNull(dto.getGroup());
    assertNotNull(dto.getFeatures());
    assertTrue(dto.getFeatures().isEmpty());
  }

  @Test
  void testGetEntitlementPackages_groupUsesFirstAssignedUserGroup() {
    PackageTemplate template = buildTemplate(40L, "Multi Group Package", "Has many groups", true,
        Collections.emptyList());
    template.setPackageTemplateAssignmentUserGroups(List.of(
        buildUserGroupAssignment("Primary Group", PackageAssignmentType.G),
        buildUserGroupAssignment("Secondary Group", PackageAssignmentType.G)));

    when(packageTemplateRepository.findAll()).thenReturn(List.of(template));

    PackagesResponse response = service.getEntitlementPackages();

    assertEquals("Primary Group", response.getPackages().get(0).getGroup());
  }

  @Test
  void testGetEntitlementPackages_groupSkipsNullUserGroupAndNonGroupAssignments() {
    PackageTemplateAssignmentUserGroup nullUserGroup = new PackageTemplateAssignmentUserGroup();
    nullUserGroup.setAssignmentType(PackageAssignmentType.G);
    nullUserGroup.setUserGroup(null);

    PackageTemplate template = buildTemplate(50L, "Edge Group Package", "Edge cases", true,
        Collections.emptyList());
    List<PackageTemplateAssignmentUserGroup> userGroupAssignments = new ArrayList<>();
    userGroupAssignments.add(nullUserGroup);
    userGroupAssignments.add(buildUserGroupAssignment("Resolved Group", PackageAssignmentType.G));
    template.setPackageTemplateAssignmentUserGroups(userGroupAssignments);

    when(packageTemplateRepository.findAll()).thenReturn(List.of(template));

    PackagesResponse response = service.getEntitlementPackages();

    assertEquals("Resolved Group", response.getPackages().get(0).getGroup());
  }

  @Test
  void testGetEntitlementPackages_filtersNonResourceAndNullResourceAssignments() {
    PackageTemplateAssignmentResource resourceAssignment =
        buildAssignment("Advanced Trading", PackageAssignmentType.S, PackageAssignmentMode.M, true);
    PackageTemplateAssignmentResource userGroupAssignment =
        buildAssignment("Group Resource", PackageAssignmentType.G, PackageAssignmentMode.M, true);
    PackageTemplateAssignmentResource nullResourceAssignment = new PackageTemplateAssignmentResource();
    nullResourceAssignment.setAssignmentType(PackageAssignmentType.S);
    nullResourceAssignment.setAssignmentMode(PackageAssignmentMode.O);
    nullResourceAssignment.setSelectionDefault(false);

    PackageTemplate template = buildTemplate(30L, "Mixed Package", "Mixed assignments", true,
        List.of(resourceAssignment, userGroupAssignment, nullResourceAssignment));

    when(packageTemplateRepository.findAll()).thenReturn(List.of(template));

    PackagesResponse response = service.getEntitlementPackages();

    ModelPackage dto = response.getPackages().get(0);
    assertEquals(1, dto.getFeatures().size());
    assertEquals("Advanced Trading", dto.getFeatures().get(0).getResource());
  }

  private PackageTemplate buildTemplate(long id, String name, String description, boolean active,
      List<PackageTemplateAssignmentResource> assignments) {
    PackageTemplate template = new PackageTemplate();
    template.setPackageTemplateId(id);
    template.setName(name);
    template.setDescription(description);
    template.setActive(active);
    template.setPackageTemplateAssignmentResources(assignments);
    return template;
  }

  private PackageTemplateAssignmentResource buildAssignment(String resourceName,
      PackageAssignmentType assignmentType, PackageAssignmentMode assignmentMode,
      boolean selectionDefault) {
    Resource resource = new Resource();
    resource.setName(resourceName);

    PackageTemplateAssignmentResource assignment = new PackageTemplateAssignmentResource();
    assignment.setResource(resource);
    assignment.setAssignmentType(assignmentType);
    assignment.setAssignmentMode(assignmentMode);
    assignment.setSelectionDefault(selectionDefault);
    return assignment;
  }

  private PackageTemplateAssignmentUserGroup buildUserGroupAssignment(String userGroupName,
      PackageAssignmentType assignmentType) {
    UserGroup userGroup = new UserGroup();
    userGroup.setName(userGroupName);

    PackageTemplateAssignmentUserGroup assignment = new PackageTemplateAssignmentUserGroup();
    assignment.setUserGroup(userGroup);
    assignment.setAssignmentType(assignmentType);
    return assignment;
  }
}
