package ca.bnc.wealth.api.user.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.common.entitlements.user_management.model.EntitlementResource;
import ca.bnc.wealth.common.entitlements.user_management.model.ResourcesResponse;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class EntitlementResourceServiceTest {

  private ResourceRepository resourceRepository;
  private EntitlementResourceService service;

  @BeforeEach
  void setUp() {
    resourceRepository = mock(ResourceRepository.class);
    service = new EntitlementResourceService(resourceRepository);
  }

  @Test
  void testGetEntitlementResources_returnsAllResources() {
    Resource resource1 = buildResource(1L, "Advanced Trading", "FEATURE", true,
        false, "Access to advanced trading", "Trading", "ADV_TRADING", "Trading functionality", "1.0");
    Resource resource2 = buildResource(2L, "Basic Reporting", "REPORT", true,
        true, "Basic reporting access", "Reporting", "BASIC_RPT", "Reporting functionality", "2.0");

    when(resourceRepository.findAll()).thenReturn(List.of(resource1, resource2));

    ResourcesResponse response = service.getEntitlementResources();

    assertNotNull(response);
    assertNotNull(response.getResources());
    assertEquals(2, response.getResources().size());

    EntitlementResource dto1 = response.getResources().get(0);
    assertEquals("1", dto1.getId());
    assertEquals("Advanced Trading", dto1.getName());
    assertEquals("FEATURE", dto1.getType());
    assertEquals(false, dto1.getRestriction());
    assertEquals("Access to advanced trading", dto1.getDescription());
    assertEquals("Trading", dto1.getGroup());
    assertEquals("ADV_TRADING", dto1.getLabel());
    assertEquals("Trading functionality", dto1.getPurpose());
    assertEquals("1.0", dto1.getVersion());
    assertEquals(true, dto1.getActive());

    EntitlementResource dto2 = response.getResources().get(1);
    assertEquals("2", dto2.getId());
    assertEquals("Basic Reporting", dto2.getName());
    assertEquals("REPORT", dto2.getType());
    assertEquals(true, dto2.getRestriction());
    assertEquals("Basic reporting access", dto2.getDescription());
    assertEquals("Reporting", dto2.getGroup());
    assertEquals("BASIC_RPT", dto2.getLabel());
    assertEquals("Reporting functionality", dto2.getPurpose());
    assertEquals("2.0", dto2.getVersion());
    assertEquals(true, dto2.getActive());

    verify(resourceRepository).findAll();
  }

  @Test
  void testGetEntitlementResources_emptyList() {
    when(resourceRepository.findAll()).thenReturn(Collections.emptyList());

    ResourcesResponse response = service.getEntitlementResources();

    assertNotNull(response);
    assertNotNull(response.getResources());
    assertTrue(response.getResources().isEmpty());

    verify(resourceRepository).findAll();
  }

  @Test
  void testGetEntitlementResources_nullableFieldsHandled() {
    Resource resource = new Resource();
    resource.setResourceId(99L);
    resource.setName("Test Resource");
    resource.setType("FEATURE");
    resource.setActive(false);
    resource.setDescription("Test description");
    resource.setVersion("1.0");
    // groupName, label, purpose, restriction are null

    when(resourceRepository.findAll()).thenReturn(List.of(resource));

    ResourcesResponse response = service.getEntitlementResources();

    assertNotNull(response);
    assertEquals(1, response.getResources().size());

    EntitlementResource dto = response.getResources().get(0);
    assertEquals("99", dto.getId());
    assertEquals("Test Resource", dto.getName());
    assertEquals("FEATURE", dto.getType());
    assertNull(dto.getRestriction());
    assertEquals("Test description", dto.getDescription());
    assertNull(dto.getGroup());
    assertNull(dto.getLabel());
    assertNull(dto.getPurpose());
    assertEquals("1.0", dto.getVersion());
    assertEquals(false, dto.getActive());
  }

  private Resource buildResource(long id, String name, String type, boolean active,
      boolean restriction, String description, String groupName,
      String label, String purpose, String version) {
    Resource resource = new Resource();
    resource.setResourceId(id);
    resource.setName(name);
    resource.setType(type);
    resource.setActive(active);
    resource.setRestriction(restriction);
    resource.setDescription(description);
    resource.setGroupName(groupName);
    resource.setLabel(label);
    resource.setPurpose(purpose);
    resource.setVersion(version);
    return resource;
  }
}
