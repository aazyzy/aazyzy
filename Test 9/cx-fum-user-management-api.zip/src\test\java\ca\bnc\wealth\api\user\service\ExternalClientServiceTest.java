package ca.bnc.wealth.api.user.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;
import ca.bnc.wealth.common.ciam.feign.client.AddOktaUserGroupClient;
import ca.bnc.wealth.common.ciam.feign.client.GetOktaUserGroupsClient;
import ca.bnc.wealth.common.ciam.feign.client.GetOktaUserProfileClient;
import ca.bnc.wealth.common.ciam.feign.client.SuspendOktaUserProfileClient;
import ca.bnc.wealth.common.ciam.feign.client.UnsuspendOktaUserProfileClient;
import ca.bnc.wealth.common.ciam.model.OktaAccessProfile;
import ca.bnc.wealth.common.ciam.model.OktaUserProfile;
import ca.bnc.wealth.common.ciam.security.CiamSystemToken;
import ca.bnc.wealth.common.r2.feign.client.CxUserProfileClient;
import ca.bnc.wealth.common.r2.model.R2UserProfile;

class ExternalClientServiceTest {

  private static final String STUB_BEARER_TOKEN = "stub-" + java.util.UUID.randomUUID();
  private static final String GROUP = "Wealth.CompassX.employee.external";

  private ExternalClientService service;
  private CiamSystemToken ciamSystemToken;
  private CxUserProfileClient cxUserProfileClient;
  private GetOktaUserProfileClient userOktaProfileClient;
  private SuspendOktaUserProfileClient suspendOktaUserProfileClient;
  private UnsuspendOktaUserProfileClient unsuspendOktaUserProfileClient;
  private GetOktaUserGroupsClient getOktaUserGroupsClient;
  private AddOktaUserGroupClient addOktaUserGroupClient;

  @BeforeEach
  void setUp() {
    cxUserProfileClient = Mockito.mock(CxUserProfileClient.class);
    ciamSystemToken = Mockito.mock(CiamSystemToken.class);
    userOktaProfileClient = Mockito.mock(GetOktaUserProfileClient.class);
    suspendOktaUserProfileClient = Mockito.mock(SuspendOktaUserProfileClient.class);
    unsuspendOktaUserProfileClient = Mockito.mock(UnsuspendOktaUserProfileClient.class);
    getOktaUserGroupsClient = Mockito.mock(GetOktaUserGroupsClient.class);
    addOktaUserGroupClient = Mockito.mock(AddOktaUserGroupClient.class);
    service = new ExternalClientService(cxUserProfileClient, ciamSystemToken, userOktaProfileClient,
        suspendOktaUserProfileClient, unsuspendOktaUserProfileClient, getOktaUserGroupsClient,
        addOktaUserGroupClient);

    ReflectionTestUtils.setField(service, "ciamContext", "testContext");
  }

  @Test
  void testGetR2UserProfilesReturnsMap() {
    Mockito.when(ciamSystemToken.getBearerToken()).thenReturn(STUB_BEARER_TOKEN);
    var response = Mockito.mock(org.springframework.http.ResponseEntity.class);
    Mockito.when(cxUserProfileClient.getR2UserProfiles(Mockito.anyString(), Mockito.anyList()))
        .thenReturn(response);
    Mockito.when(response.getBody()).thenReturn(Map.of("idp1", Mockito.mock(R2UserProfile.class)));

    Map<String, R2UserProfile> result = service.getR2UserProfiles(List.of("idp1"), "");
    assertNotNull(result);
    assertTrue(result.containsKey("idp1"));
  }

  @Test
  void testGetR2UserProfilesHandlesException() {
    Mockito.when(ciamSystemToken.getBearerToken()).thenReturn(STUB_BEARER_TOKEN);
    Mockito.when(cxUserProfileClient.getR2UserProfiles(Mockito.anyString(), Mockito.anyList()))
        .thenThrow(new RuntimeException("fail"));

    Map<String, R2UserProfile> result = service.getR2UserProfiles(List.of("idp1"), "");
    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  void testGetSecureZoneIdReturnsValue() {
    OktaAccessProfile accessProfile = Mockito.mock(OktaAccessProfile.class);
    Mockito.when(accessProfile.getBngfSecureZoneId()).thenReturn(new String[] {"zone1", "zone2"});
    OktaUserProfile userProfile = Mockito.mock(OktaUserProfile.class);
    Mockito.when(userProfile.getAccessProfile()).thenReturn(accessProfile);

    Mockito.when(ciamSystemToken.getBearerToken()).thenReturn(STUB_BEARER_TOKEN);
    Mockito.when(userOktaProfileClient.getOktaUserProfile(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
        .thenReturn(userProfile);

    String result = service.getSecureZoneId("userId", "");
    assertEquals("zone1,zone2", result);
  }

  @Test
  void testGetSecureZoneIdReturnsEmptyOnNull() {
    Mockito.when(ciamSystemToken.getBearerToken()).thenReturn(STUB_BEARER_TOKEN);
    Mockito.when(userOktaProfileClient.getOktaUserProfile(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
        .thenReturn(null);

    String result = service.getSecureZoneId("userId", "");
    assertEquals("", result);
  }

  @Test
  void testGetOktaUserProfileReturnsProfile() {
    OktaUserProfile userProfile = Mockito.mock(OktaUserProfile.class);
    Mockito.when(ciamSystemToken.getBearerToken()).thenReturn(STUB_BEARER_TOKEN);
    Mockito.when(userOktaProfileClient.getOktaUserProfile(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
        .thenReturn(userProfile);

    OktaUserProfile result = service.getOktaUserProfile("userId", "");
    assertEquals(userProfile, result);
  }

  @Test
  void testGetOktaUserProfileHandlesException() {
    Mockito.when(ciamSystemToken.getBearerToken()).thenReturn(STUB_BEARER_TOKEN);
    Mockito.when(userOktaProfileClient.getOktaUserProfile(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
        .thenThrow(new RuntimeException("fail"));

    OktaUserProfile result = service.getOktaUserProfile("userId", "");
    assertNull(result);
  }

  @Test
  void testUpdateOktaUserStatusActiveCallsUnsuspend() {
    Mockito.when(ciamSystemToken.getBearerToken()).thenReturn(STUB_BEARER_TOKEN);

    service.updateOktaUserStatus("idpUserId", true);

    Mockito.verify(unsuspendOktaUserProfileClient)
        .unsuspendOktaUserProfile(STUB_BEARER_TOKEN, "testContext", "idpUserId");
    Mockito.verifyNoInteractions(suspendOktaUserProfileClient);
  }

  @Test
  void testUpdateOktaUserStatusInactiveCallsSuspend() {
    Mockito.when(ciamSystemToken.getBearerToken()).thenReturn(STUB_BEARER_TOKEN);

    service.updateOktaUserStatus("idpUserId", false);

    Mockito.verify(suspendOktaUserProfileClient)
        .suspendOktaUserProfile(STUB_BEARER_TOKEN, "testContext", "idpUserId");
    Mockito.verifyNoInteractions(unsuspendOktaUserProfileClient);
  }

  @Test
  void testUpdateOktaUserStatusBlankIdpUserIdSkipsOkta() {
    // employee (IAMi) users have no Okta profile, so no token is fetched and no call is made
    service.updateOktaUserStatus("   ", false);
    service.updateOktaUserStatus(null, true);

    Mockito.verifyNoInteractions(suspendOktaUserProfileClient);
    Mockito.verifyNoInteractions(unsuspendOktaUserProfileClient);
    Mockito.verifyNoInteractions(ciamSystemToken);
  }

  @Test
  void testUpdateOktaUserStatusDoesNotThrowWhenOktaFails() {
    Mockito.when(ciamSystemToken.getBearerToken()).thenReturn(STUB_BEARER_TOKEN);
    Mockito.doThrow(new RuntimeException("okta down"))
        .when(suspendOktaUserProfileClient)
        .suspendOktaUserProfile(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());

    // a rejected lifecycle call must not fail the enclosing employee create/update/patch
    assertDoesNotThrow(() -> service.updateOktaUserStatus("idpUserId", false));

    Mockito.verify(suspendOktaUserProfileClient)
        .suspendOktaUserProfile(STUB_BEARER_TOKEN, "testContext", "idpUserId");
  }

  @Test
  void testUpdateOktaUserStatusDoesNotThrowWhenAlreadyActiveUnsuspendRejected() {
    Mockito.when(ciamSystemToken.getBearerToken()).thenReturn(STUB_BEARER_TOKEN);
    // Okta rejects unsuspend when the user is not SUSPENDED - a no-op, not a failure
    Mockito.doThrow(new RuntimeException("E0000001 Api validation failed"))
        .when(unsuspendOktaUserProfileClient)
        .unsuspendOktaUserProfile(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());

    assertDoesNotThrow(() -> service.updateOktaUserStatus("idpUserId", true));

    Mockito.verify(unsuspendOktaUserProfileClient)
        .unsuspendOktaUserProfile(STUB_BEARER_TOKEN, "testContext", "idpUserId");
  }

  @Test
  void testAssignOktaUserGroupBlankIdpUserIdSkipsOkta() {
    // employee (IAMi) users have no Okta profile, so no token is fetched and no call is made
    service.assignOktaUserGroup("   ", GROUP);
    service.assignOktaUserGroup(null, GROUP);

    Mockito.verifyNoInteractions(getOktaUserGroupsClient);
    Mockito.verifyNoInteractions(addOktaUserGroupClient);
    Mockito.verifyNoInteractions(ciamSystemToken);
  }

  @Test
  void testAssignOktaUserGroupAddsGroupWhenAbsent() {
    Mockito.when(ciamSystemToken.getBearerToken()).thenReturn(STUB_BEARER_TOKEN);
    mockGroupsInOkta(Map.of("groupNames", List.of("Wealth.CompassX.some.other.group")));

    service.assignOktaUserGroup("idpUserId", GROUP);

    Mockito.verify(addOktaUserGroupClient)
        .addUserGroup(STUB_BEARER_TOKEN, "testContext", GROUP, "idpUserId");
  }

  @Test
  void testAssignOktaUserGroupSkipsAddWhenAlreadyPresent() {
    Mockito.when(ciamSystemToken.getBearerToken()).thenReturn(STUB_BEARER_TOKEN);
    mockGroupsInOkta(Map.of("groupNames", List.of(GROUP)));

    service.assignOktaUserGroup("idpUserId", GROUP);

    Mockito.verifyNoInteractions(addOktaUserGroupClient);
  }

  @Test
  void testAssignOktaUserGroupAddsGroupWhenBodyIsNull() {
    Mockito.when(ciamSystemToken.getBearerToken()).thenReturn(STUB_BEARER_TOKEN);
    mockGroupsInOkta(null);

    service.assignOktaUserGroup("idpUserId", GROUP);

    Mockito.verify(addOktaUserGroupClient)
        .addUserGroup(STUB_BEARER_TOKEN, "testContext", GROUP, "idpUserId");
  }

  @Test
  void testAssignOktaUserGroupAddsGroupWhenGroupNamesMissing() {
    Mockito.when(ciamSystemToken.getBearerToken()).thenReturn(STUB_BEARER_TOKEN);
    mockGroupsInOkta(Map.of("somethingElse", List.of("x")));

    service.assignOktaUserGroup("idpUserId", GROUP);

    Mockito.verify(addOktaUserGroupClient)
        .addUserGroup(STUB_BEARER_TOKEN, "testContext", GROUP, "idpUserId");
  }

  @Test
  void testAssignOktaUserGroupDoesNotThrowWhenReadFails() {
    Mockito.when(ciamSystemToken.getBearerToken()).thenReturn(STUB_BEARER_TOKEN);
    Mockito.when(getOktaUserGroupsClient.getOktaUserGroups(Mockito.anyString(),
        Mockito.anyString(), Mockito.anyString())).thenThrow(new RuntimeException("okta down"));

    // the group lives only in Okta, so a failure must not fail the enclosing employee create
    assertDoesNotThrow(() -> service.assignOktaUserGroup("idpUserId", GROUP));

    Mockito.verifyNoInteractions(addOktaUserGroupClient);
  }

  @Test
  void testAssignOktaUserGroupDoesNotThrowWhenAddFails() {
    Mockito.when(ciamSystemToken.getBearerToken()).thenReturn(STUB_BEARER_TOKEN);
    mockGroupsInOkta(Map.of("groupNames", List.of()));
    Mockito.doThrow(new RuntimeException("okta down")).when(addOktaUserGroupClient)
        .addUserGroup(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
            Mockito.anyString());

    assertDoesNotThrow(() -> service.assignOktaUserGroup("idpUserId", GROUP));

    Mockito.verify(addOktaUserGroupClient)
        .addUserGroup(STUB_BEARER_TOKEN, "testContext", GROUP, "idpUserId");
  }

  @SuppressWarnings("unchecked")
  private void mockGroupsInOkta(Object body) {
    var response = Mockito.mock(org.springframework.http.ResponseEntity.class);
    Mockito.when(response.getBody()).thenReturn(body);
    Mockito.when(getOktaUserGroupsClient.getOktaUserGroups(Mockito.anyString(),
        Mockito.anyString(), Mockito.anyString())).thenReturn(response);
  }
}
