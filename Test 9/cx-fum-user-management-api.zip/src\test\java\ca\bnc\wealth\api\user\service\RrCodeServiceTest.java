package ca.bnc.wealth.api.user.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.fum.service.UserAssignmentService;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentRrCodeRange;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.specification.Specification;
import ca.bnc.wealth.common.userconfiguration.model.RRCodeRange;
import java.sql.Timestamp;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RrCodeServiceTest {

  private RrCodeService service;
  private IamRrCodeRangeRepository iamRrCodeRangeRepository;
  private UserAssignmentRrCodeRangeRepository userAssignmentRrCodeRangeRepository;
  private UserAssignmentService userAssignmentService;
  private UserManagementService userManagementService;

  @BeforeEach
  void setUp() {
    iamRrCodeRangeRepository = mock(IamRrCodeRangeRepository.class);
    userAssignmentRrCodeRangeRepository = mock(UserAssignmentRrCodeRangeRepository.class);
    userAssignmentService = mock(UserAssignmentService.class);
    userManagementService = mock(UserManagementService.class);

    when(userManagementService.validateRrCodeByFirmId(any(), any())).thenReturn(true);

    service = new RrCodeService(iamRrCodeRangeRepository,
        userAssignmentRrCodeRangeRepository, userAssignmentService, userManagementService);
  }

  // ==================== assignRrCodesToUser — null firm ====================

  @Test
  void testAssignRrCodesToUser_nullFirm_throwsValidation() {
    IamUserConfiguration user = buildUser("emp001");
    List<String> rrCodes = List.of("RR01");

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.assignRrCodesToUser(user, null, rrCodes, "testUser"));

    assertEquals(Constants.FIRM_MISSING, ex.getCode());
    assertTrue(ex.getMessage().contains("Firm must be provided"));
    verify(userAssignmentService, never()).getUserAssignment(any(), any());
  }

  // ==================== assignRrCodesToUser — invalid rrCodes for firm ====================

  @Test
  void testAssignRrCodesToUser_invalidRrCodes_throwsValidation() {
    IamUserConfiguration user = buildUser("emp013");
    Firm firm = buildFirm("firm-001", 100L);
    List<String> rrCodes = List.of("ZZ99");

    when(userAssignmentService.getUserAssignment("emp013", UserAssignmentType.R))
        .thenReturn(List.of());
    when(userManagementService.validateRrCodeByFirmId("firm-001", rrCodes))
        .thenReturn(false);

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.assignRrCodesToUser(user, firm, rrCodes, "testUser"));

    assertEquals(Constants.FIRM_RRCODE_INVALID, ex.getCode());
    assertEquals(Constants.FIRM_RRCODE_INVALID_MESSAGE, ex.getMessage());
    // Existing assignments are cleared first, but no new ranges are assigned when validation fails.
    verify(userAssignmentRrCodeRangeRepository).deleteAllInBatch(List.of());
    verify(userAssignmentService, never()).assignRrRangesSp(any(Integer.class), anyString(), any(), anyString());
  }

  // ==================== assignRrCodesToUser — null rrCodes list ====================

  @Test
  void testAssignRrCodesToUser_nullRrCodes_clearsExisting() {
    IamUserConfiguration user = buildUser("emp002");
    Firm firm = buildFirm("firm-001", 100L);

    when(userAssignmentService.getUserAssignment("emp002", UserAssignmentType.R))
        .thenReturn(List.of());
    when(userAssignmentService.hasUserAssignment("emp002",
        Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(false);

    service.assignRrCodesToUser(user, firm, null, "testUser");

    // null rrCodes without firm_level_access clears existing RR codes (delete is called)
  }

  // ==================== assignRrCodesToUser — empty rrCodes list ====================

  @Test
  void testAssignRrCodesToUser_emptyRrCodes_deletesExistingButAddsNothing() {
    IamUserConfiguration user = buildUser("emp003");
    Firm firm = buildFirm("firm-001", 100L);

    when(userAssignmentService.getUserAssignment("emp003", UserAssignmentType.R))
        .thenReturn(List.of());
    when(userAssignmentService.hasUserAssignment("emp003",
        Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(false);
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(List.of());

    service.assignRrCodesToUser(user, firm, List.of(), "testUser");

    verify(userAssignmentRrCodeRangeRepository).deleteAllInBatch(List.of());
    verify(userAssignmentService, never()).assignRrRangesSp(any(Integer.class), anyString(), any(), anyString());
  }

  // ==================== assignRrCodesToUser — empty rrCodes + firm-level access assigns all firm ranges ====================

  @Test
  void testAssignRrCodesToUser_emptyRrCodes_firmLevelAccess_assignsAllFirmRanges() {
    IamUserConfiguration user = buildUser("emp014");
    Firm firm = buildFirm("firm-001", 100L);

    IamRrCodeRange firmRange = new IamRrCodeRange();
    firmRange.setRrCodeRangeId(40L);
    firmRange.setFromRrCode("MM00");
    firmRange.setToRrCode("MM99");

    when(userAssignmentService.getUserAssignment("emp014", UserAssignmentType.R))
        .thenReturn(List.of());
    when(userAssignmentService.hasUserAssignment("emp014",
        Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(false);
    when(userAssignmentService.hasUserAssignment("emp014",
        Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(true);
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(firmRange));

    service.assignRrCodesToUser(user, firm, List.of(), "testUser");

    // Even with empty rrCodes, firm-level access should assign all firm ranges
    verify(userAssignmentService).assignRrRangesSp(eq(1), eq("emp014"), argThat(ranges ->
        ranges.size() == 1
            && "MM00".equals(ranges.get(0).getFromRRCode())
            && "MM99".equals(ranges.get(0).getToRRCode())), eq("testUser"));
  }

  // ==================== assignRrCodesToUser — no firm-level access assigns provided codes ====================

  @Test
  void testAssignRrCodesToUser_noFirmLevelAccess_assignsProvidedRanges() {
    IamUserConfiguration user = buildUser("emp004");
    Firm firm = buildFirm("firm-001", 100L);

    when(userAssignmentService.getUserAssignment("emp004", UserAssignmentType.R))
        .thenReturn(List.of());

    service.assignRrCodesToUser(user, firm, List.of("AA00"), "testUser");

    verify(userAssignmentRrCodeRangeRepository).deleteAllInBatch(List.of());
    // Without firm-level access the provided RR codes are assigned directly,
    // and the firm-wide range lookup is never performed.
    verify(iamRrCodeRangeRepository, never()).findAll(any(Specification.class));
    verify(userAssignmentService).assignRrRangesSp(eq(1), eq("emp004"), argThat(ranges ->
        ranges.size() == 1
            && "AA00".equals(ranges.get(0).getFromRRCode())
            && "AA00".equals(ranges.get(0).getToRRCode())), eq("testUser"));
  }

  // ==================== assignRrCodesToUser — firm-level access assigns all firm ranges ====================

  @Test
  void testAssignRrCodesToUser_firmLevelAccess_assignsAllFirmRanges() {
    IamUserConfiguration user = buildUser("emp005");
    Firm firm = buildFirm("firm-001", 100L);

    IamRrCodeRange firmRange1 = new IamRrCodeRange();
    firmRange1.setRrCodeRangeId(20L);
    firmRange1.setFromRrCode("BB11");
    firmRange1.setToRrCode("BB11");

    IamRrCodeRange firmRange2 = new IamRrCodeRange();
    firmRange2.setRrCodeRangeId(21L);
    firmRange2.setFromRrCode("BB22");
    firmRange2.setToRrCode("BB22");

    when(userAssignmentService.getUserAssignment("emp005", UserAssignmentType.R))
        .thenReturn(List.of());
    when(userAssignmentService.hasUserAssignment("emp005",
        Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(false);
    when(userAssignmentService.hasUserAssignment("emp005",
        Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(true);
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(firmRange1, firmRange2));

    service.assignRrCodesToUser(user, firm, List.of("BB11"), "testUser");

    // With firm-level access the full firm range list is fetched and assigned.
    verify(iamRrCodeRangeRepository).findAll(any(Specification.class));
    verify(userAssignmentService).assignRrRangesSp(eq(1), eq("emp005"), argThat(ranges ->
        ranges.size() == 2
            && "BB11".equals(ranges.get(0).getFromRRCode())
            && "BB22".equals(ranges.get(1).getFromRRCode())), eq("testUser"));
  }

  // ==================== assignRrCodesToUser — range with delimiter parses from/to ====================

  @Test
  void testAssignRrCodesToUser_rangeWithDelimiter_parsesFromTo() {
    IamUserConfiguration user = buildUser("emp006");
    Firm firm = buildFirm("firm-001", 100L);

    when(userAssignmentService.getUserAssignment("emp006", UserAssignmentType.R))
        .thenReturn(List.of());

    service.assignRrCodesToUser(user, firm, List.of("CC22-DD33"), "testUser");

    // A delimited code is parsed into distinct from/to bounds.
    verify(userAssignmentService).assignRrRangesSp(eq(1), eq("emp006"), argThat(ranges ->
        ranges.size() == 1
            && "CC22".equals(ranges.get(0).getFromRRCode())
            && "DD33".equals(ranges.get(0).getToRRCode())), eq("testUser"));
  }

  // ==================== assignRrCodesToUser — multiple rrCodes ====================

  @Test
  void testAssignRrCodesToUser_multipleRrCodes_processesEach() {
    IamUserConfiguration user = buildUser("emp007");
    Firm firm = buildFirm("firm-001", 100L);

    when(userAssignmentService.getUserAssignment("emp007", UserAssignmentType.R))
        .thenReturn(List.of());

    service.assignRrCodesToUser(user, firm, List.of("DD33", "EE44"), "testUser");

    verify(userAssignmentService).assignRrRangesSp(eq(1), eq("emp007"), argThat(ranges ->
        ranges.size() == 2
            && "DD33".equals(ranges.get(0).getFromRRCode())
            && "EE44".equals(ranges.get(1).getFromRRCode())), eq("testUser"));
  }

  // ==================== assignRrCodesToUser — deletes existing assignments first ====================

  @Test
  void testAssignRrCodesToUser_deletesExistingAssignmentsBeforeAdding() {
    IamUserConfiguration user = buildUser("emp008");
    Firm firm = buildFirm("firm-001", 100L);

    UserAssignmentRrCodeRange existing1 = new UserAssignmentRrCodeRange();
    existing1.setAssignmentType(UserAssignmentType.R);
    UserAssignmentRrCodeRange existing2 = new UserAssignmentRrCodeRange();
    existing2.setAssignmentType(UserAssignmentType.R);

    when(userAssignmentService.getUserAssignment("emp008", UserAssignmentType.R))
        .thenReturn(List.of(existing1, existing2));

    service.assignRrCodesToUser(user, firm, List.of("FF55"), "testUser");

    verify(userAssignmentRrCodeRangeRepository).deleteAllInBatch(List.of(existing1, existing2));
    verify(userAssignmentService).assignRrRangesSp(eq(1), eq("emp008"), argThat(ranges ->
        ranges.size() == 1 && "FF55".equals(ranges.get(0).getFromRRCode())), eq("testUser"));
  }

  // ==================== assignRrCodesToUser — trims and filters blank codes ====================

  @Test
  void testAssignRrCodesToUser_trimsAndFiltersBlankCodes() {
    IamUserConfiguration user = buildUser("emp009");
    Firm firm = buildFirm("firm-001", 100L);

    when(userAssignmentService.getUserAssignment("emp009", UserAssignmentType.R))
        .thenReturn(List.of());

    // Surrounding whitespace is trimmed and blank entries are filtered out.
    service.assignRrCodesToUser(user, firm, List.of("  GG66  ", "", "   "), "testUser");

    verify(userAssignmentService).assignRrRangesSp(eq(1), eq("emp009"), argThat(ranges ->
        ranges.size() == 1
            && "GG66".equals(ranges.get(0).getFromRRCode())
            && "GG66".equals(ranges.get(0).getToRRCode())), eq("testUser"));
  }

  // ==================== assignRrCodesToUser — no firm access does not query firm ranges ====================

  @Test
  void testAssignRrCodesToUser_noFirmAccess_doesNotQueryFirmRanges() {
    IamUserConfiguration user = buildUser("emp010");
    Firm firm = buildFirm("firm-001", 100L);

    when(userAssignmentService.getUserAssignment("emp010", UserAssignmentType.R))
        .thenReturn(List.of());

    service.assignRrCodesToUser(user, firm, List.of("HH77", "II88"), "testUser");

    // Without firm-level access the firm range lookup is skipped entirely.
    verify(iamRrCodeRangeRepository, never()).findAll(any(Specification.class));
    verify(userAssignmentService).assignRrRangesSp(eq(1), eq("emp010"), argThat(ranges ->
        ranges.size() == 2), eq("testUser"));
  }

  // ==================== assignRrCodesToUser — trailing delimiter falls back to 'from' ====================

  @Test
  void testAssignRrCodesToUser_trailingDelimiter_usesFromAsTo() {
    IamUserConfiguration user = buildUser("emp011");
    Firm firm = buildFirm("firm-001", 100L);

    when(userAssignmentService.getUserAssignment("emp011", UserAssignmentType.R))
        .thenReturn(List.of());

    // "JJ99-" -> the second part is blank, so 'to' falls back to 'from'.
    service.assignRrCodesToUser(user, firm, List.of("JJ99-"), "testUser");

    verify(userAssignmentService).assignRrRangesSp(eq(1), eq("emp011"), argThat(ranges ->
        ranges.size() == 1
            && "JJ99".equals(ranges.get(0).getFromRRCode())
            && "JJ99".equals(ranges.get(0).getToRRCode())), eq("testUser"));
  }

  // ==================== assignRrCodesToUser — firm-level access maps range dates ====================

  @Test
  void testAssignRrCodesToUser_firmLevelAccess_mapsRangeDates() {
    IamUserConfiguration user = buildUser("emp012");
    Firm firm = buildFirm("firm-001", 100L);

    Timestamp created = Timestamp.valueOf("2024-01-01 10:00:00");
    Timestamp updated = Timestamp.valueOf("2024-02-02 11:00:00");

    IamRrCodeRange firmRange = new IamRrCodeRange();
    firmRange.setRrCodeRangeId(30L);
    firmRange.setFromRrCode("KK00");
    firmRange.setToRrCode("KK00");
    firmRange.setCreatedBy("creator");
    firmRange.setLastUpdatedBy("updater");
    firmRange.setCreationDate(created);
    firmRange.setLastUpdateDate(updated);

    when(userAssignmentService.getUserAssignment("emp012", UserAssignmentType.R))
        .thenReturn(List.of());
    when(userAssignmentService.hasUserAssignment("emp012",
        Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(false);
    when(userAssignmentService.hasUserAssignment("emp012",
        Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(true);
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(firmRange));

    service.assignRrCodesToUser(user, firm, List.of("KK00"), "testUser");

    // With firm-level access the firm ranges are mapped to DTOs, including their dates.
    verify(userAssignmentService).assignRrRangesSp(eq(1), eq("emp012"), argThat(ranges ->
        ranges.size() == 1
            && "KK00".equals(ranges.get(0).getFromRRCode())
            && ranges.get(0).getCreationDate() != null
            && ranges.get(0).getLastUpdatedDate() != null), eq("testUser"));
  }

  // ==================== hasFirmLevelAccess — new public method ====================

  @Test
  void testHasFirmLevelAccess_true() {
    IamUserConfiguration user = buildUser("emp100");
    when(userAssignmentService.hasUserAssignment("emp100",
        Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(true);

    assertTrue(service.hasFirmLevelAccess(user));
  }

  @Test
  void testHasFirmLevelAccess_false() {
    IamUserConfiguration user = buildUser("emp101");
    when(userAssignmentService.hasUserAssignment("emp101",
        Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(false);

    assertFalse(service.hasFirmLevelAccess(user));
  }

  // ==================== restrict_client_data_access validation ====================

  @Test
  void shouldThrowExceptionWhenRestrictClientDataAccessAndFirmLevelAccess() {
    IamUserConfiguration user = buildUser("emp200");
    Firm firm = buildFirm("firm-001", 100L);

    when(userAssignmentService.hasUserAssignment("emp200",
        Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(true);
    when(userAssignmentService.hasUserAssignment("emp200",
        Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(true);

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.assignRrCodesToUser(user, firm, List.of("AA01"), "testUser"));

    assertEquals(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS, ex.getCode());
    assertEquals(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_FIRM_LEVEL_ACCESS_MESSAGE, ex.getMessage());
  }

  @Test
  void shouldThrowExceptionWhenRestrictClientDataAccessAndRrCodes() {
    IamUserConfiguration user = buildUser("emp201");
    Firm firm = buildFirm("firm-001", 100L);

    when(userAssignmentService.hasUserAssignment("emp201",
        Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(true);
    when(userAssignmentService.hasUserAssignment("emp201",
        Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(false);

    FumValidationException ex = assertThrows(FumValidationException.class,
        () -> service.assignRrCodesToUser(user, firm, List.of("BB02"), "testUser"));

    assertEquals(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE, ex.getCode());
    assertEquals(Constants.ERROR_RESTRICT_CLIENT_DATA_ACCESS_AND_RRCODE_MESSAGE, ex.getMessage());
  }

  @Test
  void shouldPassWhenRestrictClientDataAccessNoRrCodesNoFirmLevel() {
    IamUserConfiguration user = buildUser("emp202");
    Firm firm = buildFirm("firm-001", 100L);

    when(userAssignmentService.hasUserAssignment("emp202",
        Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(true);
    when(userAssignmentService.hasUserAssignment("emp202",
        Constants.RESOURCE_NAME_FIRM_LEVEL_ACCESS, UserAssignmentType.S)).thenReturn(false);
    when(userAssignmentService.getUserAssignment("emp202", UserAssignmentType.R))
        .thenReturn(List.of());

    // Empty rrCodes should not trigger the validation
    service.assignRrCodesToUser(user, firm, List.of(), "testUser");

    verify(userAssignmentRrCodeRangeRepository).deleteAllInBatch(List.of());
  }

  @Test
  void shouldProceedNormallyWhenNoRestrictClientDataAccess() {
    IamUserConfiguration user = buildUser("emp203");
    Firm firm = buildFirm("firm-001", 100L);

    when(userAssignmentService.hasUserAssignment("emp203",
        Constants.RESOURCE_NAME_RESTRICT_CLIENT_DATA_ACCESS, UserAssignmentType.S)).thenReturn(false);
    when(userAssignmentService.getUserAssignment("emp203", UserAssignmentType.R))
        .thenReturn(List.of());

    service.assignRrCodesToUser(user, firm, List.of("CC03"), "testUser");

    verify(userAssignmentService).assignRrRangesSp(eq(1), eq("emp203"), argThat(ranges ->
        ranges.size() == 1 && "CC03".equals(ranges.get(0).getFromRRCode())), eq("testUser"));
  }

  // ==================== toRrCodeRanges — direct unit tests ====================

  @Test
  void testToRrCodeRanges_nullInput_returnsEmptyList() {
    List<RRCodeRange> result = service.toRrCodeRanges(null);
    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  void testToRrCodeRanges_emptyList_returnsEmptyList() {
    List<RRCodeRange> result = service.toRrCodeRanges(List.of());
    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  void testToRrCodeRanges_singleCode_fromEqualsTo() {
    List<RRCodeRange> result = service.toRrCodeRanges(List.of("AA00"));
    assertEquals(1, result.size());
    assertEquals("AA00", result.get(0).getFromRRCode());
    assertEquals("AA00", result.get(0).getToRRCode());
  }

  @Test
  void testToRrCodeRanges_rangeCode_parsesFromAndTo() {
    List<RRCodeRange> result = service.toRrCodeRanges(List.of("AA00-BB99"));
    assertEquals(1, result.size());
    assertEquals("AA00", result.get(0).getFromRRCode());
    assertEquals("BB99", result.get(0).getToRRCode());
  }

  @Test
  void testToRrCodeRanges_filtersNullAndBlankEntries() {
    List<String> input = new java.util.ArrayList<>();
    input.add(null);
    input.add("");
    input.add("  ");
    input.add("CC11");
    List<RRCodeRange> result = service.toRrCodeRanges(input);
    assertEquals(1, result.size());
    assertEquals("CC11", result.get(0).getFromRRCode());
  }

  @Test
  void testToRrCodeRanges_trimsWhitespace() {
    List<RRCodeRange> result = service.toRrCodeRanges(List.of("  DD22 - EE33  "));
    assertEquals(1, result.size());
    assertEquals("DD22", result.get(0).getFromRRCode());
    assertEquals("EE33", result.get(0).getToRRCode());
  }

  @Test
  void testToRrCodeRanges_multipleEntries() {
    List<RRCodeRange> result = service.toRrCodeRanges(List.of("AA00", "BB11-CC22", "DD33"));
    assertEquals(3, result.size());
    assertEquals("AA00", result.get(0).getFromRRCode());
    assertEquals("BB11", result.get(1).getFromRRCode());
    assertEquals("CC22", result.get(1).getToRRCode());
    assertEquals("DD33", result.get(2).getFromRRCode());
  }

  @Test
  void testToRrCodeRanges_trailingDelimiter_toFallsBackToFrom() {
    List<RRCodeRange> result = service.toRrCodeRanges(List.of("FF55-"));
    assertEquals(1, result.size());
    assertEquals("FF55", result.get(0).getFromRRCode());
    assertEquals("FF55", result.get(0).getToRRCode());
  }

  // ==================== deleteUserRRCodesByIdpSubject ====================

  @Test
  void testDeleteUserRRCodesByIdpSubject_deletesExistingAssignments() {
    UserAssignmentRrCodeRange existing = new UserAssignmentRrCodeRange();
    existing.setAssignmentType(UserAssignmentType.R);

    when(userAssignmentService.getUserAssignment("emp300", UserAssignmentType.R))
        .thenReturn(List.of(existing));

    service.deleteUserRRCodesByIdpSubject("emp300");

    verify(userAssignmentRrCodeRangeRepository).deleteAllInBatch(List.of(existing));
  }

  @Test
  void testDeleteUserRRCodesByIdpSubject_noExisting_deletesEmptyList() {
    when(userAssignmentService.getUserAssignment("emp301", UserAssignmentType.R))
        .thenReturn(List.of());

    service.deleteUserRRCodesByIdpSubject("emp301");

    verify(userAssignmentRrCodeRangeRepository).deleteAllInBatch(List.of());
  }

  // ==================== Helpers ====================

  private IamUserConfiguration buildUser(String idpSubject) {
    IamUserConfiguration user = new IamUserConfiguration();
    user.setUserConfigurationId(1L);
    user.setIdpSubject(idpSubject);
    user.setUsername(idpSubject);
    return user;
  }

  private Firm buildFirm(String firmId, Long firmEntityId) {
    Firm firm = new Firm();
    firm.setFirmId(firmId);
    firm.setFirmEntityId(firmEntityId);
    return firm;
  }
}
