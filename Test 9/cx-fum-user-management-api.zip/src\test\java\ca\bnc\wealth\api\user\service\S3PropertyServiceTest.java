package ca.bnc.wealth.api.user.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import software.amazon.awssdk.regions.Region;

class S3PropertyServiceTest {

  private static final String STUB_S3_SECRET = "stub-" + java.util.UUID.randomUUID();

  @Test
  void testS3PropertyServiceGetters() {
    S3PropertyService service = new S3PropertyService();
    // Use reflection to set private fields for testing
    setField(service, "s3AccessKeyId", "testKeyId");
    setField(service, "s3SecretAccessKey", STUB_S3_SECRET);
    setField(service, "region", "us-east-1");

    assertEquals("FIRM_ATTESTATION", service.getS3AccessFor());
    assertEquals("testKeyId", service.getS3AccessKeyId());
    assertEquals(STUB_S3_SECRET, service.getS3SecretAccessKey());
    assertEquals(Region.of("us-east-1"), service.getS3Region());
  }

  private void setField(Object target, String fieldName, Object value) {
    try {
      var field = target.getClass().getDeclaredField(fieldName);
      field.setAccessible(true);
      field.set(target, value);
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }
}
