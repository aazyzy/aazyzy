package ca.bnc.wealth.api.user.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import ca.bnc.wealth.api.user.utils.Constants;
import ca.bnc.wealth.common.exception.Entity.FumNotFoundException;
import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.enums.FirmAssignmentType;
import ca.bnc.wealth.common.jpa.entity.enums.FirmType;
import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.FirmAssignment;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignment;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentFeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import ca.bnc.wealth.common.jpa.repo.iam.FirmAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.PackageTemplateRepository;
import ca.bnc.wealth.common.jpa.repo.iam.ResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentFeaturePackageRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserAssignmentResourceRepository;
import ca.bnc.wealth.common.jpa.repo.iam.UserConfigSearchMaterializedViewRepository;
import ca.bnc.wealth.common.specialinquiries.user_management.model.FirmsResponse;
import ca.bnc.wealth.common.specialinquiries.user_management.model.UsersResponse;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.jpa.domain.Specification;

@ExtendWith(MockitoExtension.class)
class SpecialInquiriesServiceTest {

  private static final String FIRM_ID = "NBIN";
  private static final String RESOURCE_NAME = "firm_level_access";
  private static final String USER_PACKAGE_NAME = "AdminAll_V1.17";
  private static final String RR_CODE = "AB10";
  // IAM_V2.B36_DECODE('AB10'): A=0, B=1, 1=27, 0=26 -> 1*36^2 + 27*36 + 26
  private static final long RR_CODE_B10 = 2294L;
  private static final long FIRM_ENTITY_ID = 42L;

  @InjectMocks
  private SpecialInquiriesService specialInquiriesService;

  @Mock
  private FirmRepository firmRepository;
  @Mock
  private ResourceRepository resourceRepository;
  @Mock
  private PackageTemplateRepository packageTemplateRepository;
  @Mock
  private UserAssignmentFeaturePackageRepository userAssignmentFeaturePackageRepository;
  @Mock
  private UserAssignmentResourceRepository userAssignmentResourceRepository;
  @Mock
  private UserConfigSearchMaterializedViewRepository userConfigSearchMaterializedViewRepository;
  @Mock
  private IamRrCodeRangeRepository iamRrCodeRangeRepository;
  @Mock
  private UserAssignmentRepository userAssignmentRepository;
  @Mock
  private FirmAssignmentRepository firmAssignmentRepository;

  // ==================== getAllUsers ====================

  @Test
  void testWhenActiveUsersExist_getAllUsersShouldReturnMappedUsers() {
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(view("cpx-john001", "john.doe@nbc.com"),
            view("cpx-jane002", "jane.roe@nbc.com")));

    UsersResponse response = specialInquiriesService.getAllUsers();

    assertEquals(2, response.getUsers().size());
    assertEquals("cpx-john001", response.getUsers().get(0).getIdpSubject());
    assertEquals("active", response.getUsers().get(0).getStatus());
    assertEquals("cpx-jane002", response.getUsers().get(1).getIdpSubject());
  }

  @Test
  void testWhenNoActiveUsers_getAllUsersShouldReturnEmptyList() {
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    UsersResponse response = specialInquiriesService.getAllUsers();

    assertNotNull(response.getUsers());
    assertTrue(response.getUsers().isEmpty());
  }

  // ==================== getUsersByFirm ====================

  @Test
  void testWhenFirmHasUsers_shouldReturnMappedUsers() {
    when(firmRepository.findByFirmId(FIRM_ID)).thenReturn(firmEntity());
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(view("cpx-john001", "john.doe@nbc.com")));

    UsersResponse response = specialInquiriesService.getUsersByFirm(FIRM_ID);

    assertNotNull(response.getUsers());
    assertEquals(1, response.getUsers().size());
    assertEquals("john.doe@nbc.com", response.getUsers().get(0).getEmail());
    assertEquals("EN", response.getUsers().get(0).getPreferredLanguage());
  }

  @Test
  void testWhenFirmHasNoUsers_shouldReturnEmptyList() {
    when(firmRepository.findByFirmId(FIRM_ID)).thenReturn(firmEntity());
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    UsersResponse response = specialInquiriesService.getUsersByFirm(FIRM_ID);

    assertNotNull(response.getUsers());
    assertTrue(response.getUsers().isEmpty());
  }

  @Test
  void testWhenFirmDoesNotExist_shouldThrowNotFound() {
    when(firmRepository.findByFirmId("UNKNOWN")).thenReturn(null);

    FumNotFoundException exception = assertThrows(FumNotFoundException.class,
        () -> specialInquiriesService.getUsersByFirm("UNKNOWN"));

    assertTrue(exception.getMessage().contains(Constants.FIRM_NOT_FOUND_MESSAGE));
    verify(userConfigSearchMaterializedViewRepository, never()).findAll(any(Specification.class));
  }

  // ==================== getUsersByUserPackage ====================

  @Test
  void testWhenUserPackageHasHolders_shouldReturnMappedUsers() {
    when(packageTemplateRepository.findByName(USER_PACKAGE_NAME))
        .thenReturn(Optional.of(packageTemplate(PackageType.U)));
    when(userAssignmentFeaturePackageRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(featurePackageAssignment("cpx-john001")));
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(view("cpx-john001", "john.doe@nbc.com")));

    UsersResponse response = specialInquiriesService.getUsersByUserPackage(USER_PACKAGE_NAME);

    assertEquals(1, response.getUsers().size());
    assertEquals("cpx-john001", response.getUsers().get(0).getIdpSubject());
  }

  @Test
  void testWhenUserPackageHasNoHolders_shouldReturnEmptyListWithoutQueryingUsers() {
    when(packageTemplateRepository.findByName(USER_PACKAGE_NAME))
        .thenReturn(Optional.of(packageTemplate(PackageType.U)));
    when(userAssignmentFeaturePackageRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    UsersResponse response = specialInquiriesService.getUsersByUserPackage(USER_PACKAGE_NAME);

    assertTrue(response.getUsers().isEmpty());
    verify(userConfigSearchMaterializedViewRepository, never()).findAll(any(Specification.class));
  }

  @Test
  void testWhenUserPackageDoesNotExist_shouldThrowNotFoundQuotingTheName() {
    when(packageTemplateRepository.findByName(USER_PACKAGE_NAME)).thenReturn(Optional.empty());

    FumNotFoundException exception = assertThrows(FumNotFoundException.class,
        () -> specialInquiriesService.getUsersByUserPackage(USER_PACKAGE_NAME));

    assertEquals(Constants.USER_PACKAGE_NOT_FOUND, exception.getCode());
    assertTrue(exception.getMessage().contains(USER_PACKAGE_NAME));
  }

  @Test
  void testWhenUserPackageNameIsUnversioned_shouldLookUpThatExactNameOnly() {
    when(packageTemplateRepository.findByName("AdminAll")).thenReturn(Optional.empty());

    assertThrows(FumNotFoundException.class,
        () -> specialInquiriesService.getUsersByUserPackage("AdminAll"));

    // No fallback to a prefix/version-agnostic lookup.
    verify(packageTemplateRepository).findByName("AdminAll");
    verifyNoMoreInteractions(packageTemplateRepository);
  }

  @Test
  void testWhenPackageIsAFirmPackage_shouldThrowValidationQuotingTheName() {
    when(packageTemplateRepository.findByName(USER_PACKAGE_NAME))
        .thenReturn(Optional.of(packageTemplate(PackageType.F)));

    FumValidationException exception = assertThrows(FumValidationException.class,
        () -> specialInquiriesService.getUsersByUserPackage(USER_PACKAGE_NAME));

    assertEquals(Constants.USER_PACKAGE_NOT_USER_TYPE, exception.getCode());
    assertTrue(exception.getMessage().contains(USER_PACKAGE_NAME));
    verify(userAssignmentFeaturePackageRepository, never()).findAll(any(Specification.class));
  }

  @Test
  void testWhenAssignmentHasNoUserConfiguration_shouldBeIgnored() {
    UserAssignmentFeaturePackage orphan = new UserAssignmentFeaturePackage();
    when(packageTemplateRepository.findByName(USER_PACKAGE_NAME))
        .thenReturn(Optional.of(packageTemplate(PackageType.U)));
    when(userAssignmentFeaturePackageRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(orphan));

    UsersResponse response = specialInquiriesService.getUsersByUserPackage(USER_PACKAGE_NAME);

    assertTrue(response.getUsers().isEmpty());
    verify(userConfigSearchMaterializedViewRepository, never()).findAll(any(Specification.class));
  }

  // ==================== getUsersByResource ====================

  @Test
  void testWhenResourceHasUsers_shouldReturnMappedUsers() {
    when(resourceRepository.findFirstByName(RESOURCE_NAME)).thenReturn(Optional.of(new Resource()));
    when(userAssignmentResourceRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(resourceAssignment("cpx-john001")));
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(view("cpx-john001", "john.doe@nbc.com")));

    UsersResponse response = specialInquiriesService.getUsersByResource(RESOURCE_NAME);

    assertEquals(1, response.getUsers().size());
  }

  @Test
  void testWhenResourceDoesNotExist_shouldThrowNotFound() {
    when(resourceRepository.findFirstByName("nope")).thenReturn(Optional.empty());

    assertThrows(FumNotFoundException.class,
        () -> specialInquiriesService.getUsersByResource("nope"));
  }

  @Test
  void testWhenTheSameUserIsAssignedTwice_shouldReturnDistinctUsers() {
    when(resourceRepository.findFirstByName(RESOURCE_NAME)).thenReturn(Optional.of(new Resource()));
    when(userAssignmentResourceRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(resourceAssignment("cpx-john001"), resourceAssignment("cpx-john001")));
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(view("cpx-john001", "john.doe@nbc.com")));

    UsersResponse response = specialInquiriesService.getUsersByResource(RESOURCE_NAME);

    assertEquals(1, response.getUsers().size());
  }

  // ==================== firm + criterion ====================

  @Test
  void testWhenFirmAndUserPackageGiven_shouldValidateBothAndReturnUsers() {
    when(firmRepository.findByFirmId(FIRM_ID)).thenReturn(firmEntity());
    when(packageTemplateRepository.findByName(USER_PACKAGE_NAME))
        .thenReturn(Optional.of(packageTemplate(PackageType.U)));
    when(userAssignmentFeaturePackageRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(featurePackageAssignment("cpx-john001")));
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(view("cpx-john001", "john.doe@nbc.com")));

    UsersResponse response =
        specialInquiriesService.getUsersByFirmAndUserPackage(FIRM_ID, USER_PACKAGE_NAME);

    assertEquals(1, response.getUsers().size());
  }

  @Test
  void testWhenFirmUnknownForFirmAndUserPackage_shouldThrowNotFoundBeforeResolvingPackage() {
    when(firmRepository.findByFirmId("UNKNOWN")).thenReturn(null);

    assertThrows(FumNotFoundException.class,
        () -> specialInquiriesService.getUsersByFirmAndUserPackage("UNKNOWN", USER_PACKAGE_NAME));

    verify(packageTemplateRepository, never()).findByName(any());
  }

  @Test
  void testWhenFirmPackageGivenForFirmAndUserPackage_shouldThrowValidation() {
    when(firmRepository.findByFirmId(FIRM_ID)).thenReturn(firmEntity());
    when(packageTemplateRepository.findByName(USER_PACKAGE_NAME))
        .thenReturn(Optional.of(packageTemplate(PackageType.F)));

    FumValidationException exception = assertThrows(FumValidationException.class,
        () -> specialInquiriesService.getUsersByFirmAndUserPackage(FIRM_ID, USER_PACKAGE_NAME));

    assertEquals(Constants.USER_PACKAGE_NOT_USER_TYPE, exception.getCode());
    verify(userConfigSearchMaterializedViewRepository, never()).findAll(any(Specification.class));
  }

  @Test
  void testWhenFirmAndResourceGiven_shouldValidateBothAndReturnUsers() {
    when(firmRepository.findByFirmId(FIRM_ID)).thenReturn(firmEntity());
    when(resourceRepository.findFirstByName(RESOURCE_NAME)).thenReturn(Optional.of(new Resource()));
    when(userAssignmentResourceRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(resourceAssignment("cpx-john001")));
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(view("cpx-john001", "john.doe@nbc.com")));

    UsersResponse response =
        specialInquiriesService.getUsersByFirmAndResource(FIRM_ID, RESOURCE_NAME);

    assertEquals(1, response.getUsers().size());
  }

  // ==================== getFirmsByFirmType ====================

  @Test
  void testWhenFirmsOfTypeExist_shouldReturnMappedFirms() {
    when(firmRepository.findAllByFirmType(FirmType.IB)).thenReturn(List.of(firmEntity()));

    FirmsResponse response = specialInquiriesService.getFirmsByFirmType("IB");

    assertEquals(1, response.getFirms().size());
    assertEquals(FIRM_ID, response.getFirms().get(0).getFirmId());
    assertEquals("IB", response.getFirms().get(0).getType());
    assertEquals("EN", response.getFirms().get(0).getPreferredLanguage());
    assertEquals(true, response.getFirms().get(0).getActive());
  }

  @Test
  void testWhenNoFirmsOfType_shouldReturnEmptyList() {
    when(firmRepository.findAllByFirmType(FirmType.MFDA)).thenReturn(Collections.emptyList());

    FirmsResponse response = specialInquiriesService.getFirmsByFirmType("MFDA");

    assertTrue(response.getFirms().isEmpty());
  }

  @Test
  void testWhenFirmTypeIsInvalid_shouldThrowValidation() {
    assertThrows(FumValidationException.class,
        () -> specialInquiriesService.getFirmsByFirmType("NOT_A_TYPE"));

    verify(firmRepository, never()).findAllByFirmType(any());
  }

  // ==================== getUsersByRrCodes ====================

  @Test
  void testWhenUsersHoldARangeContainingTheRrCode_shouldReturnThem() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(rrCodeRange(7L)));
    when(userAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(userAssignment("cpx-john001")));
    when(firmAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(view("cpx-john001", "john.doe@nbc.com")));

    UsersResponse response = specialInquiriesService.getUsersByRrCodes(List.of(RR_CODE));

    assertEquals(1, response.getUsers().size());
    assertEquals("cpx-john001", response.getUsers().get(0).getIdpSubject());
    // No firm owns the code, so firm-level access is never looked up.
    verifyNoInteractions(resourceRepository);
  }

  @Test
  void testWhenNoRangeContainsTheRrCodes_shouldReturnEmptyListWithoutFurtherQueries() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    UsersResponse response = specialInquiriesService.getUsersByRrCodes(List.of(RR_CODE));

    assertNotNull(response.getUsers());
    assertTrue(response.getUsers().isEmpty());
    verifyNoInteractions(userAssignmentRepository, firmAssignmentRepository,
        userConfigSearchMaterializedViewRepository);
  }

  @Test
  void testWhenMatchingRangesHaveNoHolderAndNoFirm_shouldReturnEmptyListWithoutQueryingUsers() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(rrCodeRange(7L)));
    when(userAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());
    when(firmAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    UsersResponse response = specialInquiriesService.getUsersByRrCodes(List.of(RR_CODE));

    assertTrue(response.getUsers().isEmpty());
    verifyNoInteractions(userConfigSearchMaterializedViewRepository);
  }

  @Test
  void testWhenTheOwningFirmHasNoFirmLevelAccessHolder_shouldReturnEmptyList() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(rrCodeRange(7L)));
    when(userAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());
    when(firmAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(firmAssignment(FIRM_ENTITY_ID)));
    when(resourceRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(resource(99L)));

    UsersResponse response = specialInquiriesService.getUsersByRrCodes(List.of(RR_CODE));

    assertTrue(response.getUsers().isEmpty());
    verifyNoInteractions(userConfigSearchMaterializedViewRepository);
  }

  @Test
  void testWhenTheFirmLevelAccessResourceIsMissing_shouldNotQueryItsHolders() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(rrCodeRange(7L)));
    when(userAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(userAssignment("cpx-john001")));
    when(firmAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(firmAssignment(FIRM_ENTITY_ID)));
    when(resourceRepository.findAll(any(Specification.class))).thenReturn(Collections.emptyList());
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(view("cpx-john001", "john.doe@nbc.com")));

    UsersResponse response = specialInquiriesService.getUsersByRrCodes(List.of(RR_CODE));

    assertEquals(1, response.getUsers().size());
    // Only the RR code range holder lookup - no empty IN () for the firm-level-access holders.
    verify(userAssignmentRepository, times(1)).findAll(any(Specification.class));
  }

  @ParameterizedTest
  @NullAndEmptySource
  void testWhenNoRrCodeIsGiven_shouldThrowValidation(List<String> rrCodes) {
    FumValidationException exception = assertThrows(FumValidationException.class,
        () -> specialInquiriesService.getUsersByRrCodes(rrCodes));

    assertEquals(Constants.RR_CODES_EMPTY, exception.getCode());
    verifyNoInteractions(iamRrCodeRangeRepository);
  }

  @Test
  void testWhenMoreRrCodesThanTheMaximumAreGiven_shouldThrowValidation() {
    List<String> rrCodes =
        Collections.nCopies(SpecialInquiriesService.MAX_RR_CODES + 1, RR_CODE);

    FumValidationException exception = assertThrows(FumValidationException.class,
        () -> specialInquiriesService.getUsersByRrCodes(rrCodes));

    assertEquals(Constants.RR_CODES_TOO_MANY, exception.getCode());
    verifyNoInteractions(iamRrCodeRangeRepository);
  }

  @Test
  void testWhenExactlyTheMaximumRrCodesAreGiven_shouldAcceptThem() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());
    List<String> rrCodes = Collections.nCopies(SpecialInquiriesService.MAX_RR_CODES, RR_CODE);

    UsersResponse response = specialInquiriesService.getUsersByRrCodes(rrCodes);

    assertTrue(response.getUsers().isEmpty());
  }

  @ParameterizedTest
  @ValueSource(strings = {"AB1", "AB100", "AB-1", "AB 1", "", "   ", "AB1\u0131", "\u0661\u0662\u0663\u0664"})
  void testWhenAnRrCodeIsMalformed_shouldThrowValidationQuotingIt(String malformed) {
    List<String> rrCodes = List.of(RR_CODE, malformed);

    FumValidationException exception = assertThrows(FumValidationException.class,
        () -> specialInquiriesService.getUsersByRrCodes(rrCodes));

    assertEquals(Constants.RR_CODE_INVALID, exception.getCode());
    assertTrue(exception.getMessage().contains(malformed));
    verifyNoInteractions(iamRrCodeRangeRepository);
  }

  @Test
  void testWhenAnRrCodeIsNull_shouldThrowValidation() {
    List<String> rrCodes = Arrays.asList(RR_CODE, null);

    FumValidationException exception = assertThrows(FumValidationException.class,
        () -> specialInquiriesService.getUsersByRrCodes(rrCodes));

    assertEquals(Constants.RR_CODE_INVALID, exception.getCode());
    verifyNoInteractions(iamRrCodeRangeRepository);
  }

  @Test
  void testWhenAnRrCodeIsVeryLong_shouldQuoteItAbbreviated() {
    String malformed = "X".repeat(10_000);

    FumValidationException exception = assertThrows(FumValidationException.class,
        () -> specialInquiriesService.getUsersByRrCodes(List.of(malformed)));

    assertTrue(exception.getMessage().length() < 200);
  }

  // Values are what IAM_V2.B36_DECODE stored for these codes in FROM/TO_RR_CODE_B10 (NPR dev).
  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByRrCodes_shouldMatchRangesContainingAnyCodeDecodedLikeTheDatabase() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByRrCodes(List.of("SPAA", "A2B1", "9999"));

    verifyRangesContainingAnyOf(859_248L, 36_351L, 1_679_615L);
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByRrCodes_shouldIgnoreCaseSurroundingBlanksAndDuplicates() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByRrCodes(List.of(" ab10 ", RR_CODE, "aB10\t"));

    verifyRangesContainingAnyOf(RR_CODE_B10);
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByRrCodes_shouldLookUpRrCodeRangeAssignmentsOfTheMatchingRanges() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(rrCodeRange(7L), rrCodeRange(8L)));
    when(userAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());
    when(firmAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByRrCodes(List.of(RR_CODE));

    ArgumentCaptor<Specification<UserAssignment>> userSpecCaptor =
        ArgumentCaptor.forClass(Specification.class);
    verify(userAssignmentRepository).findAll(userSpecCaptor.capture());
    verifyAssignmentPredicate(userSpecCaptor.getValue(), UserAssignmentType.R, List.of(7, 8));

    ArgumentCaptor<Specification<FirmAssignment>> firmSpecCaptor =
        ArgumentCaptor.forClass(Specification.class);
    verify(firmAssignmentRepository).findAll(firmSpecCaptor.capture());
    verifyAssignmentPredicate(firmSpecCaptor.getValue(), FirmAssignmentType.R, List.of(7, 8));
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByRrCodes_shouldLookUpFirmLevelAccessHoldersByResourceName() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(rrCodeRange(7L)));
    when(userAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());
    when(firmAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(firmAssignment(FIRM_ENTITY_ID)));
    when(resourceRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(resource(99L)));

    specialInquiriesService.getUsersByRrCodes(List.of(RR_CODE));

    ArgumentCaptor<Specification<Resource>> resourceSpecCaptor =
        ArgumentCaptor.forClass(Specification.class);
    verify(resourceRepository).findAll(resourceSpecCaptor.capture());
    Root<Resource> resourceRoot = mock(Root.class);
    CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class);
    Path<Object> namePath = mock(Path.class);
    when(resourceRoot.get("name")).thenReturn(namePath);
    resourceSpecCaptor.getValue()
        .toPredicate(resourceRoot, mock(CriteriaQuery.class), criteriaBuilder);
    verify(criteriaBuilder).equal(namePath, RESOURCE_NAME);

    // First lookup: the RR code range holders. Second: the firm-level-access holders.
    ArgumentCaptor<Specification<UserAssignment>> userSpecCaptor =
        ArgumentCaptor.forClass(Specification.class);
    verify(userAssignmentRepository, times(2)).findAll(userSpecCaptor.capture());
    verifyAssignmentPredicate(
        userSpecCaptor.getAllValues().get(1), UserAssignmentType.S, List.of(99));
  }

  @Test
  @SuppressWarnings("unchecked")
  void testWhenOnlyFirmLevelAccessUsersMatch_shouldRestrictThemToTheOwningFirm() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(rrCodeRange(7L)));
    when(userAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList())
        .thenReturn(List.of(userAssignment("cpx-fla001")));
    when(firmAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(firmAssignment(FIRM_ENTITY_ID)));
    when(resourceRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(resource(99L)));
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(view("cpx-fla001", "fla.user@nbc.com")));

    UsersResponse response = specialInquiriesService.getUsersByRrCodes(List.of(RR_CODE));

    assertEquals(1, response.getUsers().size());
    ArgumentCaptor<Specification<UserConfigSearchMaterializedView>> specCaptor =
        ArgumentCaptor.forClass(Specification.class);
    verify(userConfigSearchMaterializedViewRepository).findAll(specCaptor.capture());

    Root<UserConfigSearchMaterializedView> root = mock(Root.class);
    CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class);
    Path<Object> idpSubjectPath = mock(Path.class);
    Path<Object> firmEntityIdPath = mock(Path.class);
    when(root.get(anyString())).thenReturn(mock(Path.class));
    when(root.get("idpSubject")).thenReturn(idpSubjectPath);
    when(root.get("firmEntityId")).thenReturn(firmEntityIdPath);
    Predicate firmLevelAccessHolders = mock(Predicate.class);
    Predicate inOwningFirm = mock(Predicate.class);
    when(idpSubjectPath.in(Set.of("cpx-fla001"))).thenReturn(firmLevelAccessHolders);
    when(firmEntityIdPath.in(Set.of(FIRM_ENTITY_ID))).thenReturn(inOwningFirm);

    specCaptor.getValue().toPredicate(root, mock(CriteriaQuery.class), criteriaBuilder);

    verify(criteriaBuilder).and(firmLevelAccessHolders, inOwningFirm);
    verify(criteriaBuilder, never()).or(any(Predicate.class), any(Predicate.class));
  }

  @Test
  @SuppressWarnings("unchecked")
  void testWhenHoldersAndFirmLevelAccessUsersMatch_shouldOrTheTwoPopulations() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(rrCodeRange(7L)));
    when(userAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(userAssignment("cpx-john001")))
        .thenReturn(List.of(userAssignment("cpx-fla001")));
    when(firmAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(firmAssignment(FIRM_ENTITY_ID)));
    when(resourceRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(resource(99L)));
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByRrCodes(List.of(RR_CODE));

    ArgumentCaptor<Specification<UserConfigSearchMaterializedView>> specCaptor =
        ArgumentCaptor.forClass(Specification.class);
    verify(userConfigSearchMaterializedViewRepository).findAll(specCaptor.capture());

    Root<UserConfigSearchMaterializedView> root = mock(Root.class);
    CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class);
    Path<Object> idpSubjectPath = mock(Path.class);
    Path<Object> firmEntityIdPath = mock(Path.class);
    when(root.get(anyString())).thenReturn(mock(Path.class));
    when(root.get("idpSubject")).thenReturn(idpSubjectPath);
    when(root.get("firmEntityId")).thenReturn(firmEntityIdPath);
    Predicate holders = mock(Predicate.class);
    Predicate firmLevelAccessHolders = mock(Predicate.class);
    Predicate inOwningFirm = mock(Predicate.class);
    Predicate firmLevelAccessInOwningFirm = mock(Predicate.class);
    when(idpSubjectPath.in(Set.of("cpx-john001"))).thenReturn(holders);
    when(idpSubjectPath.in(Set.of("cpx-fla001"))).thenReturn(firmLevelAccessHolders);
    when(firmEntityIdPath.in(Set.of(FIRM_ENTITY_ID))).thenReturn(inOwningFirm);
    when(criteriaBuilder.and(firmLevelAccessHolders, inOwningFirm))
        .thenReturn(firmLevelAccessInOwningFirm);

    specCaptor.getValue().toPredicate(root, mock(CriteriaQuery.class), criteriaBuilder);

    // Holders keep every firm row; firm-level-access users only their owning firm's row.
    verify(criteriaBuilder).or(holders, firmLevelAccessInOwningFirm);
  }

  // ==================== query predicates ====================

  // USER_ASSIGNMENT is one undiscriminated table shared by every assignment type, so the
  // assignmentType predicate is what keeps the wrong rows out. These tests evaluate the captured
  // Specification so a dropped predicate fails the build.

  @Test
  @SuppressWarnings("unchecked")
  void testGetAllUsers_shouldRestrictQueryToActiveUsersAcrossAllFirms() {
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getAllUsers();

    ArgumentCaptor<Specification<UserConfigSearchMaterializedView>> specCaptor =
        ArgumentCaptor.forClass(Specification.class);
    verify(userConfigSearchMaterializedViewRepository).findAll(specCaptor.capture());

    Root<UserConfigSearchMaterializedView> root = mock(Root.class);
    CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class);
    Path<Boolean> activePath = mock(Path.class);
    when(root.<Boolean>get("active")).thenReturn(activePath);

    specCaptor.getValue().toPredicate(root, mock(CriteriaQuery.class), criteriaBuilder);

    verify(criteriaBuilder).isTrue(activePath);
    verify(root, never()).get("firmId");
    verify(root, never()).get("idpSubject");
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByFirm_shouldRestrictQueryToTheFirm() {
    when(firmRepository.findByFirmId(FIRM_ID)).thenReturn(firmEntity());
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByFirm(FIRM_ID);

    ArgumentCaptor<Specification<UserConfigSearchMaterializedView>> specCaptor =
        ArgumentCaptor.forClass(Specification.class);
    verify(userConfigSearchMaterializedViewRepository).findAll(specCaptor.capture());

    Root<UserConfigSearchMaterializedView> root = mock(Root.class);
    CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class);
    Path<Object> firmIdPath = mock(Path.class);
    when(root.get("firmId")).thenReturn(firmIdPath);

    specCaptor.getValue().toPredicate(root, mock(CriteriaQuery.class), criteriaBuilder);

    verify(criteriaBuilder).equal(firmIdPath, FIRM_ID);
    verify(criteriaBuilder, never()).isTrue(any());
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByUserPackage_shouldRestrictQueryToPackageAssignmentsOfThatTemplate() {
    PackageTemplate template = packageTemplate(PackageType.U);
    when(packageTemplateRepository.findByName(USER_PACKAGE_NAME)).thenReturn(Optional.of(template));
    when(userAssignmentFeaturePackageRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByUserPackage(USER_PACKAGE_NAME);

    ArgumentCaptor<Specification<UserAssignmentFeaturePackage>> specCaptor =
        ArgumentCaptor.forClass(Specification.class);
    verify(userAssignmentFeaturePackageRepository).findAll(specCaptor.capture());

    Root<UserAssignmentFeaturePackage> root = mock(Root.class);
    CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class);
    Path<Object> assignmentTypePath = mock(Path.class);
    Path<Object> featurePackagePath = mock(Path.class);
    Path<Object> packageTemplatePath = mock(Path.class);
    when(root.get("assignmentType")).thenReturn(assignmentTypePath);
    when(root.get("featurePackage")).thenReturn(featurePackagePath);
    when(featurePackagePath.get("packageTemplate")).thenReturn(packageTemplatePath);

    specCaptor.getValue().toPredicate(root, mock(CriteriaQuery.class), criteriaBuilder);

    verify(criteriaBuilder).equal(assignmentTypePath, UserAssignmentType.P);
    verify(criteriaBuilder).equal(packageTemplatePath, template);
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByUserPackage_shouldKeepInactiveHolders() {
    when(packageTemplateRepository.findByName(USER_PACKAGE_NAME))
        .thenReturn(Optional.of(packageTemplate(PackageType.U)));
    when(userAssignmentFeaturePackageRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(featurePackageAssignment("cpx-john001")));
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByUserPackage(USER_PACKAGE_NAME);

    ArgumentCaptor<Specification<UserConfigSearchMaterializedView>> specCaptor =
        ArgumentCaptor.forClass(Specification.class);
    verify(userConfigSearchMaterializedViewRepository).findAll(specCaptor.capture());

    Root<UserConfigSearchMaterializedView> root = mock(Root.class);
    CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class);
    Path<Object> idpSubjectPath = mock(Path.class);
    when(root.get("idpSubject")).thenReturn(idpSubjectPath);

    specCaptor.getValue().toPredicate(root, mock(CriteriaQuery.class), criteriaBuilder);

    verify(idpSubjectPath).in(Set.of("cpx-john001"));
    verify(criteriaBuilder, never()).isTrue(any());
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByResource_shouldRestrictQueryToResourceAssignmentsOfThatName() {
    when(resourceRepository.findFirstByName(RESOURCE_NAME)).thenReturn(Optional.of(new Resource()));
    when(userAssignmentResourceRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByResource(RESOURCE_NAME);

    ArgumentCaptor<Specification<UserAssignmentResource>> specCaptor =
        ArgumentCaptor.forClass(Specification.class);
    verify(userAssignmentResourceRepository).findAll(specCaptor.capture());

    Root<UserAssignmentResource> root = mock(Root.class);
    CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class);
    Path<Object> assignmentTypePath = mock(Path.class);
    Path<Object> resourcePath = mock(Path.class);
    Path<Object> resourceNamePath = mock(Path.class);
    when(root.get("assignmentType")).thenReturn(assignmentTypePath);
    when(root.get("resource")).thenReturn(resourcePath);
    when(resourcePath.get("name")).thenReturn(resourceNamePath);

    specCaptor.getValue().toPredicate(root, mock(CriteriaQuery.class), criteriaBuilder);

    verify(criteriaBuilder).equal(assignmentTypePath, UserAssignmentType.S);
    verify(criteriaBuilder).equal(resourceNamePath, RESOURCE_NAME);
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByResource_shouldKeepInactiveHolders() {
    when(resourceRepository.findFirstByName(RESOURCE_NAME)).thenReturn(Optional.of(new Resource()));
    when(userAssignmentResourceRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(resourceAssignment("cpx-john001")));
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByResource(RESOURCE_NAME);

    ArgumentCaptor<Specification<UserConfigSearchMaterializedView>> specCaptor =
        ArgumentCaptor.forClass(Specification.class);
    verify(userConfigSearchMaterializedViewRepository).findAll(specCaptor.capture());

    Root<UserConfigSearchMaterializedView> root = mock(Root.class);
    CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class);
    Path<Object> idpSubjectPath = mock(Path.class);
    when(root.get("idpSubject")).thenReturn(idpSubjectPath);

    specCaptor.getValue().toPredicate(root, mock(CriteriaQuery.class), criteriaBuilder);

    verify(idpSubjectPath).in(Set.of("cpx-john001"));
    verify(criteriaBuilder, never()).isTrue(any());
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByFirmAndUserPackage_shouldApplyBothIdpSubjectAndFirmPredicates() {
    when(firmRepository.findByFirmId(FIRM_ID)).thenReturn(firmEntity());
    when(packageTemplateRepository.findByName(USER_PACKAGE_NAME))
        .thenReturn(Optional.of(packageTemplate(PackageType.U)));
    when(userAssignmentFeaturePackageRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(featurePackageAssignment("cpx-john001")));
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByFirmAndUserPackage(FIRM_ID, USER_PACKAGE_NAME);

    verifyIdpSubjectAndFirmPredicates();
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByFirmAndResource_shouldApplyBothIdpSubjectAndFirmPredicates() {
    when(firmRepository.findByFirmId(FIRM_ID)).thenReturn(firmEntity());
    when(resourceRepository.findFirstByName(RESOURCE_NAME)).thenReturn(Optional.of(new Resource()));
    when(userAssignmentResourceRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(resourceAssignment("cpx-john001")));
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByFirmAndResource(FIRM_ID, RESOURCE_NAME);

    verifyIdpSubjectAndFirmPredicates();
  }

  @SuppressWarnings("unchecked")
  private void verifyIdpSubjectAndFirmPredicates() {
    ArgumentCaptor<Specification<UserConfigSearchMaterializedView>> specCaptor =
        ArgumentCaptor.forClass(Specification.class);
    verify(userConfigSearchMaterializedViewRepository).findAll(specCaptor.capture());

    Root<UserConfigSearchMaterializedView> root = mock(Root.class);
    CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class);
    Path<Object> idpSubjectPath = mock(Path.class);
    Path<Object> firmIdPath = mock(Path.class);
    when(root.get("idpSubject")).thenReturn(idpSubjectPath);
    when(root.get("firmId")).thenReturn(firmIdPath);

    specCaptor.getValue().toPredicate(root, mock(CriteriaQuery.class), criteriaBuilder);

    verify(idpSubjectPath).in(Set.of("cpx-john001"));
    verify(criteriaBuilder).equal(firmIdPath, FIRM_ID);
    verify(criteriaBuilder, never()).isTrue(any());
  }

  // ==================== NBX exclusion ====================

  // genericSearchWithPagination drops NBX-only users unconditionally (addingNbxUserFilter -
  // SOURCE_NOT_NBX / IS_NULL). Every user-returning endpoint is asserted individually rather than
  // only the shared helper they happen to funnel through today.

  @Test
  @SuppressWarnings("unchecked")
  void testGetAllUsers_shouldExcludeNbxOnlyUsers() {
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getAllUsers();

    verifyNbxUsersExcluded();
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByFirm_shouldExcludeNbxOnlyUsers() {
    when(firmRepository.findByFirmId(FIRM_ID)).thenReturn(firmEntity());
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByFirm(FIRM_ID);

    verifyNbxUsersExcluded();
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByUserPackage_shouldExcludeNbxOnlyUsers() {
    when(packageTemplateRepository.findByName(USER_PACKAGE_NAME))
        .thenReturn(Optional.of(packageTemplate(PackageType.U)));
    when(userAssignmentFeaturePackageRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(featurePackageAssignment("cpx-john001")));
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByUserPackage(USER_PACKAGE_NAME);

    verifyNbxUsersExcluded();
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByResource_shouldExcludeNbxOnlyUsers() {
    when(resourceRepository.findFirstByName(RESOURCE_NAME)).thenReturn(Optional.of(new Resource()));
    when(userAssignmentResourceRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(resourceAssignment("cpx-john001")));
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByResource(RESOURCE_NAME);

    verifyNbxUsersExcluded();
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByFirmAndUserPackage_shouldExcludeNbxOnlyUsers() {
    when(firmRepository.findByFirmId(FIRM_ID)).thenReturn(firmEntity());
    when(packageTemplateRepository.findByName(USER_PACKAGE_NAME))
        .thenReturn(Optional.of(packageTemplate(PackageType.U)));
    when(userAssignmentFeaturePackageRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(featurePackageAssignment("cpx-john001")));
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByFirmAndUserPackage(FIRM_ID, USER_PACKAGE_NAME);

    verifyNbxUsersExcluded();
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByFirmAndResource_shouldExcludeNbxOnlyUsers() {
    when(firmRepository.findByFirmId(FIRM_ID)).thenReturn(firmEntity());
    when(resourceRepository.findFirstByName(RESOURCE_NAME)).thenReturn(Optional.of(new Resource()));
    when(userAssignmentResourceRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(resourceAssignment("cpx-john001")));
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByFirmAndResource(FIRM_ID, RESOURCE_NAME);

    verifyNbxUsersExcluded();
  }

  @Test
  @SuppressWarnings("unchecked")
  void testGetUsersByRrCodes_shouldExcludeNbxOnlyUsers() {
    when(iamRrCodeRangeRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(rrCodeRange(7L)));
    when(userAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(List.of(userAssignment("cpx-john001")));
    when(firmAssignmentRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());
    when(userConfigSearchMaterializedViewRepository.findAll(any(Specification.class)))
        .thenReturn(Collections.emptyList());

    specialInquiriesService.getUsersByRrCodes(List.of(RR_CODE));

    verifyNbxUsersExcluded();
  }

  @SuppressWarnings("unchecked")
  private void verifyNbxUsersExcluded() {
    ArgumentCaptor<Specification<UserConfigSearchMaterializedView>> specCaptor =
        ArgumentCaptor.forClass(Specification.class);
    verify(userConfigSearchMaterializedViewRepository).findAll(specCaptor.capture());

    Root<UserConfigSearchMaterializedView> root = mock(Root.class);
    CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class);
    Path<Object> sourcePath = mock(Path.class);
    when(root.get(anyString())).thenReturn(mock(Path.class));
    when(root.get("source")).thenReturn(sourcePath);

    specCaptor.getValue().toPredicate(root, mock(CriteriaQuery.class), criteriaBuilder);

    verify(criteriaBuilder).isNull(sourcePath);
  }

  // The range query must OR one "FROM_B10 <= code AND code <= TO_B10" predicate per distinct code.
  @SuppressWarnings("unchecked")
  private void verifyRangesContainingAnyOf(long... expectedRrCodesB10) {
    ArgumentCaptor<Specification<IamRrCodeRange>> specCaptor =
        ArgumentCaptor.forClass(Specification.class);
    verify(iamRrCodeRangeRepository).findAll(specCaptor.capture());

    Root<IamRrCodeRange> root = mock(Root.class);
    CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class);
    Path<Long> fromPath = mock(Path.class);
    Path<Long> toPath = mock(Path.class);
    when(root.<Long>get("fromRrCodeB10")).thenReturn(fromPath);
    when(root.<Long>get("toRrCodeB10")).thenReturn(toPath);
    List<Predicate> rangeContainsCode = new ArrayList<>();
    for (long rrCodeB10 : expectedRrCodesB10) {
      Predicate fromAtMostCode = mock(Predicate.class);
      Predicate toAtLeastCode = mock(Predicate.class);
      Predicate containsCode = mock(Predicate.class);
      when(criteriaBuilder.lessThanOrEqualTo(fromPath, rrCodeB10)).thenReturn(fromAtMostCode);
      when(criteriaBuilder.greaterThanOrEqualTo(toPath, rrCodeB10)).thenReturn(toAtLeastCode);
      when(criteriaBuilder.and(fromAtMostCode, toAtLeastCode)).thenReturn(containsCode);
      rangeContainsCode.add(containsCode);
    }

    specCaptor.getValue().toPredicate(root, mock(CriteriaQuery.class), criteriaBuilder);

    verify(criteriaBuilder).or(rangeContainsCode.toArray(Predicate[]::new));
  }

  // USER_ASSIGNMENT / FIRM_ASSIGNMENT hold every assignment type in one table, so a dropped type
  // predicate would let unrelated rows (firms, packages, resources) match the assignee ids.
  @SuppressWarnings("unchecked")
  private static <T> void verifyAssignmentPredicate(
      Specification<T> spec, Enum<?> assignmentType, List<Integer> assigneeIds) {
    Root<T> root = mock(Root.class);
    CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class);
    Path<Object> assignmentTypePath = mock(Path.class);
    Path<Object> assigneeIdPath = mock(Path.class);
    Predicate ofAssignmentType = mock(Predicate.class);
    Predicate ofAssignee = mock(Predicate.class);
    when(root.get("assignmentType")).thenReturn(assignmentTypePath);
    when(root.get("assigneeId")).thenReturn(assigneeIdPath);
    when(criteriaBuilder.equal(assignmentTypePath, assignmentType)).thenReturn(ofAssignmentType);
    when(assigneeIdPath.in(assigneeIds)).thenReturn(ofAssignee);

    spec.toPredicate(root, mock(CriteriaQuery.class), criteriaBuilder);

    verify(criteriaBuilder).and(ofAssignmentType, ofAssignee);
  }

  // ==================== fixtures ====================

  private static Firm firmEntity() {
    Firm firm = new Firm();
    firm.setFirmEntityId(1L);
    firm.setFirmId(FIRM_ID);
    firm.setName("National Bank Independent Network");
    firm.setFirmType(FirmType.IB);
    firm.setDescription("Independent broker firm");
    firm.setPreferredLanguageType(PreferredLanguageType.EN);
    firm.setActive(true);
    return firm;
  }

  private static PackageTemplate packageTemplate(PackageType type) {
    PackageTemplate packageTemplate = new PackageTemplate();
    packageTemplate.setPackageTemplateId(12L);
    packageTemplate.setName(USER_PACKAGE_NAME);
    packageTemplate.setType(type);
    return packageTemplate;
  }

  private static UserAssignmentFeaturePackage featurePackageAssignment(String idpSubject) {
    UserAssignmentFeaturePackage assignment = new UserAssignmentFeaturePackage();
    assignment.setUserConfiguration(userConfiguration(idpSubject));
    assignment.setFeaturePackage(new FeaturePackage());
    return assignment;
  }

  private static UserAssignmentResource resourceAssignment(String idpSubject) {
    UserAssignmentResource assignment = new UserAssignmentResource();
    assignment.setUserConfiguration(userConfiguration(idpSubject));
    assignment.setResource(new Resource());
    return assignment;
  }

  private static IamUserConfiguration userConfiguration(String idpSubject) {
    IamUserConfiguration userConfiguration = new IamUserConfiguration();
    userConfiguration.setIdpSubject(idpSubject);
    return userConfiguration;
  }

  private static IamRrCodeRange rrCodeRange(long rrCodeRangeId) {
    IamRrCodeRange rrCodeRange = new IamRrCodeRange();
    rrCodeRange.setRrCodeRangeId(rrCodeRangeId);
    return rrCodeRange;
  }

  private static UserAssignment userAssignment(String idpSubject) {
    UserAssignment assignment = new UserAssignment();
    assignment.setIdpSubject(idpSubject);
    return assignment;
  }

  private static FirmAssignment firmAssignment(long firmEntityId) {
    FirmAssignment assignment = new FirmAssignment();
    assignment.setFirmEntityId(Math.toIntExact(firmEntityId));
    return assignment;
  }

  private static Resource resource(long resourceId) {
    Resource resource = new Resource();
    resource.setResourceId(resourceId);
    return resource;
  }

  private static UserConfigSearchMaterializedView view(String idpSubject, String email) {
    return UserConfigSearchMaterializedView.builder()
        .userConfigurationId(102355L)
        .idpSubject(idpSubject)
        .email(email)
        .firmId(FIRM_ID)
        .preferredLanguageType(PreferredLanguageType.EN)
        .active(true)
        .build();
  }
}
