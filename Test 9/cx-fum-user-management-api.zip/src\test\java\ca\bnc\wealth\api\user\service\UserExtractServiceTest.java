package ca.bnc.wealth.api.user.service;

import static org.junit.jupiter.api.Assertions.*;

import ca.bnc.wealth.api.user.utils.Constants;
import java.util.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

class UserExtractServiceTest {

  private UserExtractService service;
  private NamedParameterJdbcTemplate jdbcTemplate;
  private ExternalClientService externalClientService;

  @BeforeEach
  void setUp() {
    jdbcTemplate = Mockito.mock(NamedParameterJdbcTemplate.class);
    externalClientService = Mockito.mock(ExternalClientService.class);

    service = new UserExtractService(jdbcTemplate, externalClientService);
    // Inject mocks using reflection
    setField(service, "chunkSize", 100);
    setField(service, "disableDelay", true);
  }

  @Test
  void testGetUserExtractDataReturnsExpectedResult() {
    HashMap<String, Object> map = new HashMap<>(){
      {
        put("FIRM_ID", "F1");
        put("USER_CONFIGURATION_ID", "U1");
        put("IDP_SUBJECT", "S1");
        put("IDP_USER_ID", "I1");
        put("FIRM_NAME", "Firm");
        put("FIRST_NAME", "John");
        put("LAST_NAME", "Doe");
        put("EMAIL", "john@doe.com");
        put("USERNAME", "jdoe");
        put("IS_FIRM_SCOPE", "Y");
        put("RR_RANGES", "R1");
        put("BNGF_REFERENCE_ID", "F1_ID");
        put("STATE_DESCRIPTION", "Active");
      }
    };
    // Mock JDBC and external service responses
    Mockito.when(jdbcTemplate.queryForList(Mockito.anyString(), Mockito.any(MapSqlParameterSource.class)))
        .thenReturn(List.of(map));

    Mockito.when(externalClientService.getR2UserProfiles(Mockito.anyList(), Mockito.anyString()))
        .thenReturn(new HashMap<>());

    Mockito.when(externalClientService.getSecureZoneId(Mockito.anyString(), Mockito.anyString()))
        .thenReturn("SZ1");

    Map<String, Map<String, Map<String, String>>> securityZoneData = new HashMap<>();
    securityZoneData.put("GDI", Map.of("SZ1", Map.of("USER_ID", "U1", "IA_ACCESS", "A1", "USER_EFFECTIVE_DATE", "2023-01-01", "USER_LAST_LOGIN", "2023-06-01")));

    List<Map<String, String>> result = service.getUserExtractData("F1", securityZoneData, "");

    assertNotNull(result);
    assertFalse(result.isEmpty());
    assertEquals("F1", result.get(0).get(Constants.ATTESTATION_HEADER_FIRM_ID));
    assertEquals("jdoe", result.get(0).get(Constants.ATTESTATION_HEADER_COMPASS_USER_ID));
    // Add more assertions as needed
  }

  private void setField(Object target, String fieldName, Object value) {
    try {
      var field = target.getClass().getDeclaredField(fieldName);
      field.setAccessible(true);
      field.set(target, value);
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }
}
