package ca.bnc.wealth.api.user.service;

import ca.bnc.wealth.common.exception.Entity.FumValidationException;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.repo.iam.IamRrCodeRangeRepository;
import ca.bnc.wealth.common.jpa.repo.iam.FirmRepository;
import ca.bnc.wealth.common.jpa.repo.iam.IamUserConfigurationRepository;
import ca.bnc.wealth.common.fum.service.UserSearchViewRefreshService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

public class UserManagementServiceTest {

  private FirmRepository firmRepository;
  private IamUserConfigurationRepository iamUserConfigurationRepository;
  private IamRrCodeRangeRepository iamRrCodeRangeRepository;
  private UserSearchViewRefreshService userSearchViewRefreshService;
  private UserManagementService userManagementService;

  private static final String FIRM_ID = "firmId";
  private static final String IDP_SUBJECT = "idpSubject";

  @BeforeEach
  void setUp() {
    firmRepository = Mockito.mock(FirmRepository.class);
    iamUserConfigurationRepository = Mockito.mock(IamUserConfigurationRepository.class);
    iamRrCodeRangeRepository = Mockito.mock(IamRrCodeRangeRepository.class);
    userSearchViewRefreshService =
        Mockito.mock(UserSearchViewRefreshService.class);

    userManagementService = new UserManagementService(firmRepository, iamUserConfigurationRepository,
        iamRrCodeRangeRepository, userSearchViewRefreshService);

  }

  @Test
  public void validateRrCodeByFirmId_whenValidRrCodeRange_shouldReturnTrue() {
    String rrCodeFromExpected = "AAAA";
    String rrCodeToExpected = "9999";
    List<String> input = List.of(rrCodeFromExpected + "-" + rrCodeToExpected + "," + rrCodeFromExpected);

    when(firmRepository.findAll(any(Specification.class))).thenReturn(List.of(new Firm()));
    when(firmRepository.validRrCodeRangeForFirmId(anyString(), anyString(), anyString())).thenReturn(true);
    boolean response = userManagementService.validateRrCodeByFirmId("firmId", input);

    assertTrue(response);
  }

  @Test
  public void validateRrCodeByFirmId_whenDuplicateRrCodeRange_shouldReturnTrue() {
    String rrCodeFromExpected = "AAAA";
    String rrCodeToExpected = "9999";
    String rrCodeRange = rrCodeFromExpected + "-" + rrCodeToExpected;
    List<String> input = List.of(rrCodeRange + "," + rrCodeRange + "," + rrCodeFromExpected + "," + rrCodeFromExpected
            + "," + rrCodeToExpected + "," + rrCodeToExpected);

    when(firmRepository.findAll(any(Specification.class))).thenReturn(List.of(new Firm()));
    when(firmRepository.validRrCodeRangeForFirmId(anyString(), anyString(), anyString())).thenReturn(true);
    boolean response = userManagementService.validateRrCodeByFirmId(FIRM_ID, input);

    assertTrue(response);
  }

  @Test
  public void validateRrCodeByFirmId_whenInvalidRrCodeRange_shouldReturnFalse() {
    when(firmRepository.findAll(any(Specification.class))).thenReturn(List.of(new Firm()));
    when(firmRepository.validRrCodeRangeForFirmId(anyString(), anyString(), anyString())).thenReturn(false);

    boolean response = userManagementService.validateRrCodeByFirmId(FIRM_ID, List.of("AAAA"));
    assertFalse(response);
  }

  @Test
  public void validateRrCodeByFirmId_whenDbResponseIsNull_shouldReturnFalse() {
    when(firmRepository.findAll(any(Specification.class))).thenReturn(null);

    assertThrows(FumValidationException.class, () -> {userManagementService.validateRrCodeByFirmId(FIRM_ID, List.of("AAAA"));});
  }


  @Test
  public void isValidRrCodeRangeByUser_whenValidRrCodeRange_shouldReturnTrue() {
    String rrCodeFromExpected = "AAAA";
    String rrCodeToExpected = "9999";
    List<String> input = List.of(rrCodeFromExpected + "-" + rrCodeToExpected + "," + rrCodeFromExpected);

    when(iamUserConfigurationRepository.findFirstByIdpSubject(any())).thenReturn(Optional.of(new IamUserConfiguration()));
    when(iamRrCodeRangeRepository.validRrCodeRangeForUser(anyString(), anyString(), anyString())).thenReturn(true);
    boolean response = userManagementService.validateRrCodeByUser(IDP_SUBJECT, input);

    assertTrue(response);
  }

  @Test
  public void isValidRrCodeRangeByUser_whenDuplicateRrCodeRange_shouldReturnTrue() {
    String rrCodeFromExpected = "AAAA";
    String rrCodeToExpected = "9999";
    String rrCodeRange = rrCodeFromExpected + "-" + rrCodeToExpected;
    List<String> input = List.of(rrCodeRange + "," + rrCodeRange + "," + rrCodeFromExpected + "," + rrCodeFromExpected
            + "," + rrCodeToExpected + "," + rrCodeToExpected);

    when(iamUserConfigurationRepository.findFirstByIdpSubject(any())).thenReturn(Optional.of(new IamUserConfiguration()));
    when(iamRrCodeRangeRepository.validRrCodeRangeForUser(anyString(), anyString(), anyString())).thenReturn(true);
    boolean response = userManagementService.validateRrCodeByUser(IDP_SUBJECT, input);

    assertTrue(response);
  }

  @Test
  public void isValidRrCodeRangeByUser_whenInvalidRrCodeRange_shouldReturnFalse() {
    when(iamUserConfigurationRepository.findFirstByIdpSubject(any())).thenReturn(Optional.of(new IamUserConfiguration()));
    when(iamRrCodeRangeRepository.validRrCodeRangeForUser(anyString(), anyString(), anyString())).thenReturn(false);

    boolean response = userManagementService.validateRrCodeByUser(IDP_SUBJECT, List.of("AAAA"));
    assertFalse(response);
  }

  @Test
  public void isValidRrCodeRangeByUser_whenDbResponseIsNull_shouldReturnFalse() {
    when(iamUserConfigurationRepository.findAll(any(Specification.class))).thenReturn(null);
    when(iamRrCodeRangeRepository.findAll(any(Specification.class))).thenReturn(null);
    boolean response = userManagementService.validateRrCodeByUser(IDP_SUBJECT, List.of("AAAA"));
    assertFalse(response);
  }

  @Test
  public void getUniqueRrCodeRangeList_whenNullRrCodeRange_shouldThrowFumValidationException() {
    assertThrows(FumValidationException.class, () -> {
      userManagementService.getUniqueRrCodeRangeList( null);
    });
  }

  @Test
  public void getUniqueRrCodeRangeList_whenEmptyRrCodeRange_shouldThrowFumValidationException() {
    assertThrows(FumValidationException.class, () -> {
      userManagementService.getUniqueRrCodeRangeList(List.of(""));
    });
  }

  @Test
  public void getUniqueRrCodeRangeList_whenInvalidRrCodeRangeFormat_shouldThrowFumMultipleValidationException() {
    assertThrows(FumValidationException.class, () -> {
      userManagementService.getUniqueRrCodeRangeList(List.of("invalid rr codes"));
    });
  }

  @Test
  public void testGetFirm() {
    when(firmRepository.findAll(any(Specification.class))).thenReturn(List.of(new Firm()));
    assertNotNull(userManagementService.getFirm(FIRM_ID));
  }

  @Test
  public void testGetFirm_whenFirmNotFound_shouldReturnNull() {
    when(firmRepository.findAll(any(Specification.class))).thenReturn(null);
    userManagementService.getFirm(FIRM_ID);
    assertEquals(null, userManagementService.getFirm(FIRM_ID));
  }

  @Test
  public void testGetUser() {
    when(iamUserConfigurationRepository.findFirstByIdpSubject(any())).thenReturn(Optional.of(new IamUserConfiguration()));
    assertNotNull(userManagementService.getUser(IDP_SUBJECT));
  }

  @Test
  public void testGetUser_whenUserNotFound_shouldReturnNull() {
    when(iamUserConfigurationRepository.findFirstByIdpSubject(any())).thenReturn(null);
    assertEquals(null, userManagementService.getUser(IDP_SUBJECT));
  }

  // ==================== getUniqueRrCodeRangeList — additional edge cases ====================

  @Test
  public void getUniqueRrCodeRangeList_whenValidInput_shouldReturnDeduplicatedList() {
    List<String> result = userManagementService.getUniqueRrCodeRangeList(
        List.of("AAAA-9999,AAAA-9999,BBBB"));
    // Duplicates removed: AAAA-9999 appears once, BBBB once
    assertEquals(2, result.size());
    assertTrue(result.contains("AAAA-9999"));
    assertTrue(result.contains("BBBB"));
  }

  @Test
  public void getUniqueRrCodeRangeList_whenWhitespaceOnlyEntries_shouldThrowFumValidationException() {
    assertThrows(FumValidationException.class, () -> {
      userManagementService.getUniqueRrCodeRangeList(List.of("   ", "  "));
    });
  }

  @Test
  public void getUniqueRrCodeRangeList_whenMixedValidAndBlank_shouldReturnOnlyValid() {
    List<String> result = userManagementService.getUniqueRrCodeRangeList(
        List.of("AAAA", "   "));
    assertEquals(1, result.size());
    assertEquals("AAAA", result.get(0));
  }

  @Test
  public void getUniqueRrCodeRangeList_whenLowercaseInput_shouldThrowFumValidationException() {
    // Regex requires uppercase: ^[A-Z0-9]{4}(-[A-Z0-9]{4})?$
    assertThrows(FumValidationException.class, () -> {
      userManagementService.getUniqueRrCodeRangeList(List.of("aaaa"));
    });
  }

  @Test
  public void getUniqueRrCodeRangeList_whenThreeCharCode_shouldThrowFumValidationException() {
    assertThrows(FumValidationException.class, () -> {
      userManagementService.getUniqueRrCodeRangeList(List.of("AAA"));
    });
  }

  @Test
  public void getUniqueRrCodeRangeList_whenFiveCharCode_shouldThrowFumValidationException() {
    assertThrows(FumValidationException.class, () -> {
      userManagementService.getUniqueRrCodeRangeList(List.of("AAAAA"));
    });
  }

  // ==================== validateRrCodeByFirmId — null/empty rrCodes ====================

  @Test
  public void validateRrCodeByFirmId_whenNullRrCodes_shouldThrowFumValidationException() {
    when(firmRepository.findAll(any(Specification.class))).thenReturn(List.of(new Firm()));
    assertThrows(FumValidationException.class, () -> {
      userManagementService.validateRrCodeByFirmId(FIRM_ID, null);
    });
  }

  @Test
  public void validateRrCodeByFirmId_whenEmptyRrCodes_shouldThrowFumValidationException() {
    when(firmRepository.findAll(any(Specification.class))).thenReturn(List.of(new Firm()));
    assertThrows(FumValidationException.class, () -> {
      userManagementService.validateRrCodeByFirmId(FIRM_ID, List.of(""));
    });
  }

  @Test
  public void validateRrCodeByFirmId_whenFirmNotFound_shouldThrowFumValidationException() {
    when(firmRepository.findAll(any(Specification.class))).thenReturn(List.of());
    assertThrows(FumValidationException.class, () -> {
      userManagementService.validateRrCodeByFirmId(FIRM_ID, List.of("AAAA"));
    });
  }

  // ==================== validateRrCodeByUser — null/empty rrCodes ====================

  @Test
  public void validateRrCodeByUser_whenNullRrCodes_shouldThrowFumValidationException() {
    when(iamUserConfigurationRepository.findFirstByIdpSubject(any())).thenReturn(Optional.of(new IamUserConfiguration()));
    assertThrows(FumValidationException.class, () -> {
      userManagementService.validateRrCodeByUser(IDP_SUBJECT, null);
    });
  }

  @Test
  public void validateRrCodeByUser_whenEmptyRrCodes_shouldThrowFumValidationException() {
    when(iamUserConfigurationRepository.findFirstByIdpSubject(any())).thenReturn(Optional.of(new IamUserConfiguration()));
    assertThrows(FumValidationException.class, () -> {
      userManagementService.validateRrCodeByUser(IDP_SUBJECT, List.of(""));
    });
  }

  // ==================== isValidRrCodeRangeByUser — single code (no range) ====================

  @Test
  public void isValidRrCodeRangeByUser_whenSingleCode_fromAndToAreSame() {
    when(iamRrCodeRangeRepository.validRrCodeRangeForUser(eq(IDP_SUBJECT), eq("AAAA"), eq("AAAA")))
        .thenReturn(true);
    assertTrue(userManagementService.isValidRrCodeRangeByUser(IDP_SUBJECT, "AAAA"));
  }

  @Test
  public void isValidRrCodeRangeByUser_whenRange_parsesFromAndTo() {
    when(iamRrCodeRangeRepository.validRrCodeRangeForUser(eq(IDP_SUBJECT), eq("AAAA"), eq("ZZZZ")))
        .thenReturn(true);
    assertTrue(userManagementService.isValidRrCodeRangeByUser(IDP_SUBJECT, "AAAA-ZZZZ"));
  }


}
