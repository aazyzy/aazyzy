package ca.bnc.wealth.api.user.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import ca.bnc.wealth.common.employee.user_management.model.EmployeeAssignment;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeUserConfiguration;
import ca.bnc.wealth.common.fum.model.UserPreferencesEnum;
import ca.bnc.wealth.common.jpa.entity.enums.PackageAssignmentMode;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.enums.UserAssignmentType;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.FeaturePackageAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.Firm;
import ca.bnc.wealth.common.jpa.entity.iam.IamRrCodeRange;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplateAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.Resource;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentFeaturePackage;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentResource;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentFirm;
import ca.bnc.wealth.common.jpa.entity.iam.UserAssignmentRrCodeRange;
import ca.bnc.wealth.common.userconfiguration.model.UserConfiguration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

class ApiMapperTest {

  @Test
  void toAuditUserConfiguration_nullInput_returnsEmptyConfig() {
    UserConfiguration result = ApiMapper.toAuditUserConfiguration(null);

    assertNull(result.getUsername());
    assertNull(result.getPreferredLanguage());
    assertNull(result.getUserPreferences());
    assertNull(result.getActive());
  }

  @Test
  void toAuditUserConfiguration_withLanguageAndPreferences_mapsBothFields() {
    Map<String, String> preferences = new HashMap<>();
    preferences.put("defaultModule", "wealth");

    IamUserConfiguration entity = new IamUserConfiguration();
    entity.setUsername("emp001");
    entity.setActive(Boolean.TRUE);
    entity.setPreferredLanguageType(PreferredLanguageType.FR);
    entity.setUserPreferences(preferences);

    UserConfiguration result = ApiMapper.toAuditUserConfiguration(entity);

    assertEquals("emp001", result.getUsername());
    assertEquals("true", result.getActive());
    assertEquals(PreferredLanguageType.FR.name(), result.getPreferredLanguage());
    assertEquals(preferences, result.getUserPreferences());
  }

  @Test
  void toAuditUserConfiguration_nullLanguageAndPreferences_setsNull() {
    IamUserConfiguration entity = new IamUserConfiguration();
    entity.setUsername("emp002");
    entity.setActive(null);
    entity.setPreferredLanguageType(null);
    entity.setUserPreferences(null);

    UserConfiguration result = ApiMapper.toAuditUserConfiguration(entity);

    assertEquals("emp002", result.getUsername());
    assertNull(result.getActive());
    assertNull(result.getPreferredLanguage());
    assertNull(result.getUserPreferences());
  }

  @Test
  void toAuditUserConfiguration_userPreferencesIsDefensiveCopy() {
    Map<String, String> preferences = new HashMap<>();
    preferences.put("defaultModule", "wealth");

    IamUserConfiguration entity = new IamUserConfiguration();
    entity.setUserPreferences(preferences);

    UserConfiguration result = ApiMapper.toAuditUserConfiguration(entity);

    // The mapped map must not alias the entity's map: a later in-place mutation of the
    // entity preferences (as updateUserPreferences does) must not leak into this snapshot.
    assertNotSame(preferences, result.getUserPreferences());
    preferences.put("defaultModule", "mutated");
    assertEquals("wealth", result.getUserPreferences().get("defaultModule"));
  }

  // ---------------------------------------------------------------------------
  // toEmployeeDto - defaultModule now comes from userPreferences (was source)
  // ---------------------------------------------------------------------------

  @Test
  void toEmployeeDto_defaultModuleReadFromUserPreferences() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUsername("raza002");
    Map<String, String> prefs = new HashMap<>();
    prefs.put(UserPreferencesEnum.defaultModule.name(), "compass_r2");
    userConfig.setUserPreferences(prefs);

    EmployeeUserConfiguration dto = ApiMapper.toEmployeeDto(null, userConfig);

    assertEquals("raza002", dto.getProfile().getShortId());
    assertEquals("compass_r2", dto.getProfile().getDefaultModule());
  }

  @Test
  void toEmployeeDto_defaultModuleNullWhenUserPreferencesNull() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUserPreferences(null);

    EmployeeUserConfiguration dto = ApiMapper.toEmployeeDto(null, userConfig);

    assertNull(dto.getProfile().getDefaultModule());
  }

  @Test
  void toEmployeeDto_defaultModuleNullWhenKeyAbsent() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUserPreferences(new HashMap<>());

    EmployeeUserConfiguration dto = ApiMapper.toEmployeeDto(null, userConfig);

    assertNull(dto.getProfile().getDefaultModule());
  }

  // ---------------------------------------------------------------------------
  // toAssignment - RR code ranges filtered by assignmentType == R
  // ---------------------------------------------------------------------------

  @Test
  void toAssignment_includesRrCodeRangeWhenAssignmentTypeR() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUserAssignmentRrCodeRanges(
        List.of(rrCodeAssignment(UserAssignmentType.R, "RR001", "RR005")));

    EmployeeAssignment assignment = ApiMapper.toAssignment(userConfig);

    assertEquals(List.of("RR001-RR005"), assignment.getRrcodes());
  }

  @Test
  void toAssignment_rrCodeRangeCollapsesWhenFromEqualsTo() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUserAssignmentRrCodeRanges(
        List.of(rrCodeAssignment(UserAssignmentType.R, "RR001", "RR001")));

    EmployeeAssignment assignment = ApiMapper.toAssignment(userConfig);

    assertEquals(List.of("RR001"), assignment.getRrcodes());
  }

  @Test
  void toAssignment_excludesRrCodeRangeWhenAssignmentTypeNotR() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUserAssignmentRrCodeRanges(List.of(
        rrCodeAssignment(UserAssignmentType.R, "RR001", "RR005"),
        rrCodeAssignment(UserAssignmentType.S, "RR900", "RR999")));

    EmployeeAssignment assignment = ApiMapper.toAssignment(userConfig);

    assertEquals(List.of("RR001-RR005"), assignment.getRrcodes());
  }

  @Test
  void toAssignment_excludesRrCodeRangeWhenRangeNull() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    UserAssignmentRrCodeRange withoutRange = new UserAssignmentRrCodeRange();
    withoutRange.setAssignmentType(UserAssignmentType.R);
    withoutRange.setIamRrCodeRange(null);
    userConfig.setUserAssignmentRrCodeRanges(List.of(withoutRange));

    EmployeeAssignment assignment = ApiMapper.toAssignment(userConfig);

    assertTrue(assignment.getRrcodes().isEmpty());
  }

  // ---------------------------------------------------------------------------
  // toAssignment - resources filtered by assignmentType == S
  // ---------------------------------------------------------------------------

  @Test
  void toAssignment_includesResourceWhenNotRestrictedAndSelected() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUserAssignmentFeaturePackages(List.of(
        featurePackageAssignment("res-A", false, true)));

    EmployeeAssignment assignment = ApiMapper.toAssignment(userConfig);

    assertEquals(List.of("res-A"), assignment.getResources());
  }

  @Test
  void toAssignment_excludesResourceWhenNotRestrictedAndNotSelected() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUserAssignmentFeaturePackages(List.of(
        featurePackageAssignment("res-A", false, false)));

    EmployeeAssignment assignment = ApiMapper.toAssignment(userConfig);

    assertTrue(assignment.getResources().isEmpty());
  }

  @Test
  void toAssignment_excludesResourceWhenNullFeaturePackages() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUserAssignmentFeaturePackages(null);

    EmployeeAssignment assignment = ApiMapper.toAssignment(userConfig);

    assertNull(assignment.getResources());
  }

  @Test
  void toAssignment_splitsRestrictedResourcesFromFeaturePackageDetails() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUserAssignmentFeaturePackages(List.of(
        featurePackageAssignment("res-A", false, true),
        featurePackageAssignment("firm_level_access", true, false)));

    EmployeeAssignment assignment = ApiMapper.toAssignment(userConfig);

    assertEquals(List.of("res-A"), assignment.getResources());
    assertEquals(List.of("firm_level_access"), assignment.getRestrictedResources());
  }

  @Test
  void toAssignment_excludesNonRestrictedPairWhenRestrictedExists() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    // Same resource name appears as both restricted (!selected) and non-restricted (selected).
    // The non-restricted pair must be excluded from resources.
    userConfig.setUserAssignmentFeaturePackages(List.of(
        featurePackageAssignment("shared_res", false, true),
        featurePackageAssignment("shared_res", true, false)));

    EmployeeAssignment assignment = ApiMapper.toAssignment(userConfig);

    assertTrue(assignment.getResources().isEmpty());
    assertEquals(List.of("shared_res"), assignment.getRestrictedResources());
  }

  @Test
  void toAssignment_includesMandatoryResourceWhenNotRestrictedAndSelected() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUserAssignmentFeaturePackages(List.of(
        featurePackageAssignment("mandatory-res", false, true, PackageAssignmentMode.M)));

    EmployeeAssignment assignment = ApiMapper.toAssignment(userConfig);

    assertEquals(List.of("mandatory-res"), assignment.getResources());
  }

  @Test
  void toAssignment_restrictedMandatoryNotSelectedGoesToRestricted() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUserAssignmentFeaturePackages(List.of(
        featurePackageAssignment("mandatory-restricted", true, false, PackageAssignmentMode.M)));

    EmployeeAssignment assignment = ApiMapper.toAssignment(userConfig);

    assertTrue(assignment.getResources().isEmpty());
    assertEquals(List.of("mandatory-restricted"), assignment.getRestrictedResources());
  }

  // ---------------------------------------------------------------------------
  // toAssignment - firm filtered by assignmentType == F
  // ---------------------------------------------------------------------------

  @Test
  void toAssignment_setsFirmFromTypeFAssignment() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUserAssignmentFirms(List.of(firmAssignment(UserAssignmentType.F, "FIRM001")));

    EmployeeAssignment assignment = ApiMapper.toAssignment(userConfig);

    assertEquals("FIRM001", assignment.getFirm());
  }

  @Test
  void toAssignment_resolvesFirmWhenNonFirmRowAppearsFirst() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    // A non-firm row (no firm) precedes the actual firm row; firm must still resolve.
    UserAssignmentFirm nonFirmRow = new UserAssignmentFirm();
    nonFirmRow.setAssignmentType(UserAssignmentType.S);
    nonFirmRow.setFirm(null);
    userConfig.setUserAssignmentFirms(
        List.of(nonFirmRow, firmAssignment(UserAssignmentType.F, "FIRM001")));

    EmployeeAssignment assignment = ApiMapper.toAssignment(userConfig);

    assertEquals("FIRM001", assignment.getFirm());
  }

  @Test
  void toAssignment_firmNullWhenNoTypeFAssignment() {
    IamUserConfiguration userConfig = MockData.getIamUserConfigurationEntity();
    userConfig.setUserAssignmentFirms(List.of(firmAssignment(UserAssignmentType.S, "FIRM001")));

    EmployeeAssignment assignment = ApiMapper.toAssignment(userConfig);

    assertNull(assignment.getFirm());
  }

  // ---------------------------------------------------------------------------
  // helpers
  // ---------------------------------------------------------------------------

  private static UserAssignmentFirm firmAssignment(UserAssignmentType type, String firmId) {
    Firm firm = new Firm();
    firm.setFirmId(firmId);

    UserAssignmentFirm assignment = new UserAssignmentFirm();
    assignment.setAssignmentType(type);
    assignment.setFirm(firm);
    return assignment;
  }

  private static UserAssignmentRrCodeRange rrCodeAssignment(
      UserAssignmentType type, String from, String to) {
    IamRrCodeRange range = new IamRrCodeRange();
    range.setFromRrCode(from);
    range.setToRrCode(to);

    UserAssignmentRrCodeRange assignment = new UserAssignmentRrCodeRange();
    assignment.setAssignmentType(type);
    assignment.setIamRrCodeRange(range);
    return assignment;
  }

  private static UserAssignmentResource resourceAssignment(
      UserAssignmentType type, String resourceName) {
    return resourceAssignment(type, resourceName, false);
  }

  private static UserAssignmentResource resourceAssignment(
      UserAssignmentType type, String resourceName, boolean restricted) {
    Resource resource = new Resource();
    resource.setName(resourceName);
    resource.setRestriction(restricted);

    UserAssignmentResource assignment = new UserAssignmentResource();
    assignment.setAssignmentType(type);
    assignment.setResource(resource);
    return assignment;
  }

  private static UserAssignmentFeaturePackage featurePackageAssignment(
      String resourceName, boolean restricted, boolean selected) {
    return featurePackageAssignment(resourceName, restricted, selected, PackageAssignmentMode.O);
  }

  private static UserAssignmentFeaturePackage featurePackageAssignment(
      String resourceName, boolean restricted, boolean selected, PackageAssignmentMode mode) {
    Resource resource = new Resource();
    resource.setName(resourceName);
    resource.setRestriction(restricted);

    PackageTemplateAssignmentResource ptar = new PackageTemplateAssignmentResource();
    ptar.setResource(resource);
    ptar.setAssignmentMode(mode);

    FeaturePackageAssignmentResource detail = new FeaturePackageAssignmentResource();
    detail.setPackageTemplateAssignmentResource(ptar);
    detail.setSelected(selected);

    FeaturePackage fp = new FeaturePackage();
    fp.setFeaturePackageAssignmentResources(List.of(detail));

    UserAssignmentFeaturePackage uafp = new UserAssignmentFeaturePackage();
    uafp.setAssignmentType(UserAssignmentType.P);
    uafp.setFeaturePackage(fp);
    return uafp;
  }

  // --- toFeatureSelections tests ---

  @Test
  void toFeatureSelections_nullList_returnsEmptyList() {
    List<String> result = ApiMapper.toFeatureSelections(null);
    assertTrue(result.isEmpty());
  }

  @Test
  void toFeatureSelections_emptyList_returnsEmptyList() {
    List<String> result = ApiMapper.toFeatureSelections(List.of());
    assertTrue(result.isEmpty());
  }

  @Test
  void toFeatureSelections_optionalNotRestrictedAndSelected_included() {
    Resource resource = new Resource();
    resource.setName("Analytics");
    resource.setRestriction(false);

    PackageTemplateAssignmentResource templateDetail = new PackageTemplateAssignmentResource();
    templateDetail.setAssignmentMode(PackageAssignmentMode.O);
    templateDetail.setResource(resource);

    FeaturePackageAssignmentResource detail = new FeaturePackageAssignmentResource();
    detail.setSelected(true);
    detail.setPackageTemplateAssignmentResource(templateDetail);

    List<String> result = ApiMapper.toFeatureSelections(List.of(detail));

    assertEquals(List.of("Analytics"), result);
  }

  @Test
  void toFeatureSelections_optionalRestrictedAndNotSelected_included() {
    Resource resource = new Resource();
    resource.setName("RestrictedFeature");
    resource.setRestriction(true);

    PackageTemplateAssignmentResource templateDetail = new PackageTemplateAssignmentResource();
    templateDetail.setAssignmentMode(PackageAssignmentMode.O);
    templateDetail.setResource(resource);

    FeaturePackageAssignmentResource detail = new FeaturePackageAssignmentResource();
    detail.setSelected(false);
    detail.setPackageTemplateAssignmentResource(templateDetail);

    List<String> result = ApiMapper.toFeatureSelections(List.of(detail));

    assertEquals(List.of("RestrictedFeature"), result);
  }

  @Test
  void toFeatureSelections_optionalNotRestrictedAndNotSelected_excluded() {
    Resource resource = new Resource();
    resource.setName("Excluded");
    resource.setRestriction(false);

    PackageTemplateAssignmentResource templateDetail = new PackageTemplateAssignmentResource();
    templateDetail.setAssignmentMode(PackageAssignmentMode.O);
    templateDetail.setResource(resource);

    FeaturePackageAssignmentResource detail = new FeaturePackageAssignmentResource();
    detail.setSelected(false);
    detail.setPackageTemplateAssignmentResource(templateDetail);

    List<String> result = ApiMapper.toFeatureSelections(List.of(detail));

    assertTrue(result.isEmpty());
  }

  @Test
  void toFeatureSelections_optionalRestrictedAndSelected_excluded() {
    Resource resource = new Resource();
    resource.setName("Excluded");
    resource.setRestriction(true);

    PackageTemplateAssignmentResource templateDetail = new PackageTemplateAssignmentResource();
    templateDetail.setAssignmentMode(PackageAssignmentMode.O);
    templateDetail.setResource(resource);

    FeaturePackageAssignmentResource detail = new FeaturePackageAssignmentResource();
    detail.setSelected(true);
    detail.setPackageTemplateAssignmentResource(templateDetail);

    List<String> result = ApiMapper.toFeatureSelections(List.of(detail));

    assertTrue(result.isEmpty());
  }

  @Test
  void toFeatureSelections_mandatoryResource_excluded() {
    Resource resource = new Resource();
    resource.setName("Mandatory");
    resource.setRestriction(false);

    PackageTemplateAssignmentResource templateDetail = new PackageTemplateAssignmentResource();
    templateDetail.setAssignmentMode(PackageAssignmentMode.M);
    templateDetail.setResource(resource);

    FeaturePackageAssignmentResource detail = new FeaturePackageAssignmentResource();
    detail.setSelected(true);
    detail.setPackageTemplateAssignmentResource(templateDetail);

    List<String> result = ApiMapper.toFeatureSelections(List.of(detail));

    assertTrue(result.isEmpty());
  }

  @Test
  void toFeatureSelections_mixedDetails_returnsOnlyMatchingResourceNames() {
    Resource optionalSelected = new Resource();
    optionalSelected.setName("Feature1");
    optionalSelected.setRestriction(false);

    Resource restrictedNotSelected = new Resource();
    restrictedNotSelected.setName("Feature2");
    restrictedNotSelected.setRestriction(true);

    Resource mandatoryRes = new Resource();
    mandatoryRes.setName("Mandatory");
    mandatoryRes.setRestriction(false);

    PackageTemplateAssignmentResource tpl1 = new PackageTemplateAssignmentResource();
    tpl1.setAssignmentMode(PackageAssignmentMode.O);
    tpl1.setResource(optionalSelected);

    PackageTemplateAssignmentResource tpl2 = new PackageTemplateAssignmentResource();
    tpl2.setAssignmentMode(PackageAssignmentMode.O);
    tpl2.setResource(restrictedNotSelected);

    PackageTemplateAssignmentResource tpl3 = new PackageTemplateAssignmentResource();
    tpl3.setAssignmentMode(PackageAssignmentMode.M);
    tpl3.setResource(mandatoryRes);

    FeaturePackageAssignmentResource d1 = new FeaturePackageAssignmentResource();
    d1.setSelected(true);
    d1.setPackageTemplateAssignmentResource(tpl1);

    FeaturePackageAssignmentResource d2 = new FeaturePackageAssignmentResource();
    d2.setSelected(false);
    d2.setPackageTemplateAssignmentResource(tpl2);

    FeaturePackageAssignmentResource d3 = new FeaturePackageAssignmentResource();
    d3.setSelected(true);
    d3.setPackageTemplateAssignmentResource(tpl3);

    List<String> result = ApiMapper.toFeatureSelections(List.of(d1, d2, d3));

    assertEquals(2, result.size());
    assertTrue(result.contains("Feature1"));
    assertTrue(result.contains("Feature2"));
  }
}
