package ca.bnc.wealth.api.user.utils;

import ca.bnc.wealth.common.jpa.entity.enums.PackageType;
import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.iam.IamUserConfiguration;
import ca.bnc.wealth.common.jpa.entity.iam.PackageTemplate;
import ca.bnc.wealth.common.employee.user_management.model.CreateUserEmployee;
import ca.bnc.wealth.common.employee.user_management.model.CreateUserEmployeeProfile;
import ca.bnc.wealth.common.employee.user_management.model.EmployeeAssignmentRequest;
import ca.bnc.wealth.common.employee.user_management.model.EmployeePackageRequest;
import ca.bnc.wealth.common.employee.user_management.model.UpdateUserEmployee;
import ca.bnc.wealth.common.employee.user_management.model.UpdateUserEmployeeProfile;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

public class MockData {

  public static IamUserConfiguration getIamUserConfigurationEntity() {
    IamUserConfiguration iamUserConfiguration = new IamUserConfiguration();
    iamUserConfiguration.setIdpSubject("idpSubject");
    iamUserConfiguration.setIdpUserIdentifier("1234");
    iamUserConfiguration.setIdp("nbin");
    iamUserConfiguration.setUserConfigurationId(1234L);
    iamUserConfiguration.setActive(true);
    iamUserConfiguration.setPreferredLanguageType(PreferredLanguageType.EN);
    iamUserConfiguration.setOssUserId("123");
    iamUserConfiguration.setOssGroupId("123");
    iamUserConfiguration.setFirstName("firstName");
    iamUserConfiguration.setLastName("lastName");
    iamUserConfiguration.setEmail("email@email.com");
    return iamUserConfiguration;
  }

  public static PackageTemplate getPackageTemplateEntity() {
    PackageTemplate packageTemplate = new PackageTemplate();
    packageTemplate.setPackageTemplateId(1L);
    packageTemplate.setName("Template1");
    packageTemplate.setDescription("Description1");
    packageTemplate.setType(PackageType.U);
    packageTemplate.setUpdateDate(Timestamp.from(Instant.now()));
    return packageTemplate;
  }

  public static CreateUserEmployee getCreateUserEmployee() {
    CreateUserEmployee employee = new CreateUserEmployee();
    employee.setFirstName("John");
    employee.setLastName("Doe");
    employee.setEmail("john.doe@nbc.ca");
    employee.setLanguage("EN");

    CreateUserEmployeeProfile profile = new CreateUserEmployeeProfile();
    profile.setShortId("raza002");
    profile.setDefaultModule("compass_r2");
    profile.setActive(true);

    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    profile.setAssignment(assignment);

    employee.setProfile(profile);
    return employee;
  }

  public static CreateUserEmployee getCreateUserEmployeeWithAssignments() {
    CreateUserEmployee employee = getCreateUserEmployee();

    EmployeePackageRequest packageRequest = new EmployeePackageRequest();
    packageRequest.setName("Template1");

    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    assignment.setRrcodes(List.of("RR001", "RR002"));
    assignment.setPackage(packageRequest);

    employee.getProfile().setAssignment(assignment);
    return employee;
  }

  public static UpdateUserEmployee getUpdateUserEmployee() {
    UpdateUserEmployee update = new UpdateUserEmployee();
    update.setFirstName("Jane");
    update.setLastName("Smith");
    update.setEmail("jane.smith@nbc.ca");
    update.setLanguage("FR");

    UpdateUserEmployeeProfile profile = new UpdateUserEmployeeProfile();
    profile.setDefaultModule("compass_r2");
    profile.setActive(true);
    update.setProfile(profile);
    return update;
  }

  public static UpdateUserEmployee getUpdateUserEmployeeWithAssignments() {
    UpdateUserEmployee update = getUpdateUserEmployee();

    EmployeePackageRequest packageRequest = new EmployeePackageRequest();
    packageRequest.setName("Template1");

    EmployeeAssignmentRequest assignment = new EmployeeAssignmentRequest();
    assignment.setFirm("firm-001");
    assignment.setRrcodes(List.of("RR001", "RR002"));
    assignment.setPackage(packageRequest);

    update.getProfile().setAssignment(assignment);
    return update;
  }
}
