package ca.bnc.wealth.api.user.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import ca.bnc.wealth.common.jpa.entity.enums.PreferredLanguageType;
import ca.bnc.wealth.common.jpa.entity.iam.UserConfigSearchMaterializedView;
import ca.bnc.wealth.common.specialinquiries.user_management.model.UserConfiguration;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;

class SpecialInquiriesMapperTest {

  private static final Timestamp CREATED = Timestamp.valueOf(LocalDateTime.of(2026, 1, 2, 3, 4, 5));
  private static final Timestamp UPDATED = Timestamp.valueOf(LocalDateTime.of(2026, 6, 7, 8, 9, 10));

  @Test
  void testWhenViewIsFullyPopulated_shouldMapEveryMaterializedField() {
    UserConfigSearchMaterializedView view = UserConfigSearchMaterializedView.builder()
        .userConfigurationId(102355L)
        .idpUserIdentifier("00u14qkped3OHVyBM0h8")
        .idpSubject("cpx-john001")
        .idp("nbc")
        .username("john.doe")
        .ossUserId("ACOH123")
        .ossGroupId("ACOH123H")
        .firstName("John")
        .lastName("Doe")
        .email("john.doe@nbc.com")
        .active(true)
        .state("onboarding")
        .stateDescription("Staged")
        .stateAction("Onboarding")
        .preferredLanguageType(PreferredLanguageType.FR)
        .firmId("NBIN")
        .userGroupName("Wealth.CompassX")
        .userGroupDescription("Trader")
        .accessProfileSet(true)
        .source("nbx")
        .createdBy("PM105")
        .lastUpdatedBy("PM106")
        .creationDate(CREATED)
        .lastUpdateDate(UPDATED)
        .build();

    UserConfiguration result = SpecialInquiriesMapper.toUserConfiguration(view);

    assertEquals(102355, result.getUserConfigurationId());
    assertEquals("00u14qkped3OHVyBM0h8", result.getIdpUserId());
    assertEquals("cpx-john001", result.getIdpSubject());
    assertEquals("nbc", result.getIdp());
    assertEquals("john.doe", result.getUsername());
    assertEquals("ACOH123", result.getOssUserId());
    assertEquals("ACOH123H", result.getOssGroupId());
    assertEquals("John", result.getFirstName());
    assertEquals("Doe", result.getLastName());
    assertEquals("john.doe@nbc.com", result.getEmail());
    assertEquals("active", result.getStatus());
    assertEquals("onboarding", result.getState());
    assertEquals("Staged", result.getStateDescription());
    assertEquals("Onboarding", result.getStateAction());
    assertEquals("FR", result.getPreferredLanguage());
    assertEquals("NBIN", result.getFirmId());
    assertEquals("Wealth.CompassX", result.getUserGroup());
    assertEquals("Trader", result.getUserGroupDescription());
    assertEquals(true, result.getAccessProfileSet());
    assertEquals("nbx", result.getSource());
    assertEquals("PM105", result.getCreatedBy());
    assertEquals("PM106", result.getLastUpdatedBy());
    assertEquals(CREATED.toLocalDateTime(), result.getCreationDate());
    assertEquals(UPDATED.toLocalDateTime(), result.getLastUpdatedDate());
  }

  @Test
  void testWhenViewIsPopulated_shouldMirrorDeprecatedOssAliases() {
    UserConfigSearchMaterializedView view = UserConfigSearchMaterializedView.builder()
        .userConfigurationId(1L)
        .ossUserId("ACOH123")
        .ossGroupId("ACOH123H")
        .active(true)
        .build();

    UserConfiguration result = SpecialInquiriesMapper.toUserConfiguration(view);

    assertEquals("ACOH123", result.getOssId());
    assertEquals("ACOH123H", result.getOssProxyId());
  }

  @Test
  void testWhenUserIsInactive_shouldMapStatusAndDeprecatedActiveToInactive() {
    UserConfigSearchMaterializedView view = UserConfigSearchMaterializedView.builder()
        .userConfigurationId(1L)
        .active(false)
        .build();

    UserConfiguration result = SpecialInquiriesMapper.toUserConfiguration(view);

    assertEquals("inactive", result.getStatus());
    assertEquals("inactive", result.getActive());
  }

  @Test
  void testWhenNullableColumnsAreNull_shouldNotFail() {
    UserConfigSearchMaterializedView view = UserConfigSearchMaterializedView.builder().build();

    UserConfiguration result = SpecialInquiriesMapper.toUserConfiguration(view);

    assertNull(result.getUserConfigurationId());
    assertNull(result.getPreferredLanguage());
    assertNull(result.getCreationDate());
    assertNull(result.getLastUpdatedDate());
    assertEquals("inactive", result.getStatus());
  }

  @Test
  void testFieldsNotCarriedByTheMaterializedView_shouldStayNull() {
    UserConfigSearchMaterializedView view = UserConfigSearchMaterializedView.builder()
        .userConfigurationId(1L)
        .active(true)
        .build();

    UserConfiguration result = SpecialInquiriesMapper.toUserConfiguration(view);

    // Same nulls as POST /user-conf/users/genericSearchWithPagination returns.
    assertNull(result.getSecureZoneIds());
    assertNull(result.getFirmName());
    assertNull(result.getFirmType());
    assertNull(result.getCompassR2Id());
    assertNull(result.getFeaturePackage());
    assertNull(result.getResources());
    assertNull(result.getRestrictedResources());
    assertNull(result.getRrCodes());
    assertNull(result.getRrCodeRanges());
    assertNull(result.getRoleScopeType());
    assertNull(result.getUserRole());
  }
}
