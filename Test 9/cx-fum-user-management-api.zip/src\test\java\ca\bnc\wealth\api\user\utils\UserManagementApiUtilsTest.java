package ca.bnc.wealth.api.user.utils;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class UserManagementApiUtilsTest {

  @Test
  void testGetFileNameFromS3UrlWithValidUrl() {
    String s3Url = "s3://bucket/folder/file.csv";
    String result = UserManagementApiUtils.getFileNameFromS3Url(s3Url);
    assertEquals("file.csv", result);
  }

  @Test
  void testGetFileNameFromS3UrlWithNoSlash() {
    String s3Url = "file.csv";
    String result = UserManagementApiUtils.getFileNameFromS3Url(s3Url);
    assertEquals("file.csv", result);
  }

  @Test
  void testGetFileNameFromS3UrlWithNull() {
    String result = UserManagementApiUtils.getFileNameFromS3Url(null);
    assertNull(result);
  }

  @Test
  void testGetFileNameFromS3UrlWithTrailingSlash() {
    String s3Url = "s3://bucket/folder/";
    String result = UserManagementApiUtils.getFileNameFromS3Url(s3Url);
    assertEquals("", result);
  }
}